'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const [fixture,choicePath,matchedPath,out]=process.argv.slice(2),root=read(fixture).compositionEnvelope;
const seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{const v=c.lifecycle.restore(e);assert(v.ok,JSON.stringify(v));assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}











function input(family,test=()=>true){
 const a=menu().find(a=>a.family===family&&test(a));assert(a,family);return execute(a);
}

const known=read(choicePath).rows,comparison=read(matchedPath).rows[0];
const plan=comparison.sides.find(x=>x.label==='analysis-first').actions,demand=load('randomizer/game/ai/resource-demand'),sv=load('randomizer/game/ai/state-value');
const deck=load('randomizer/game/cards/deck');
function payEnergy(actions){
 const need={kind:'scan',required:{credits:1,energy:2}},payment=demand.paymentCards(state(),seat,need,2);
 assert.equal(payment.length,2);
 actions.push(input('quick_trade',a=>a.target.tradeId==='cards-for-energy'));
 for(const id of payment)actions.push(input('choose_payment',a=>a.target.cardInstanceId===id&&a.target.select===true));
 actions.push(input('choose_payment',a=>a.target.confirm===true));return payment;
}
function knownValue(){
 const s=structuredClone(state()),a=s.aliens.chong,b=s.aliens.amiba;
 a.displayedCardIndex=null;a.cardDeck.fill(null);
 b.displayedCardHidden=b.displayedCardIndex!==null;b.displayedCardIndex=null;b.cardDeck.fill(null);
 const publicIds=new Set(JSON.parse(root.committedState).cards.publicCards.filter(Boolean).map(c=>c.id));
 s.cards.publicCards=s.cards.publicCards.map(c=>c&&publicIds.has(c.id)?c:null);
 s.cards.drawPileCardIds.fill(null);
 return sv.evaluateStateValue(buildRuleObservation(s,s.meta.seed,seat),seat).total;
}
try{
 const rows=[];
 for(const color of ['pink','yellow','blue']){
  restore(root);
  const actions=[execute(known.find(r=>r.action.target.traceType===color).action),input('end_turn')];
  assert.equal(state().turn.turnNumber,9);
  for(const a of plan.slice(0,15))actions.push(execute(a));
  const beforeFunding=assets(),paid=color!=='yellow'?payEnergy(actions):null;
  if(color==='yellow')for(const a of plan.slice(15,17))actions.push(execute(a));
  const beforeScan=assets();
  for(const a of plan.slice(17))actions.push(execute(a));
  const end=save(),after=assets(),fixedValue=knownValue();
  restore(root);actions.forEach(execute);assert.deepEqual(save(),end);restore(root);
  rows.push({color,actions,end,after,beforeFunding,beforeScan,paid,fixedValue,replayExact:true});
  console.log(JSON.stringify({color,inputs:actions.length,paid,score:after.wallet.score,established:after.realized,data:after.wallet.availableData,hand:after.wallet.handSize,
   publicity:after.wallet.publicity,blue:after.blue,fixedValue}));
 }
 fs.writeFileSync(out,JSON.stringify({scope:'Same Amiba3 root, follow with same analysis, purple research, known scan, trace, task, and Native replay. Exact energy payment with public held cards when missing one data.',rows},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
