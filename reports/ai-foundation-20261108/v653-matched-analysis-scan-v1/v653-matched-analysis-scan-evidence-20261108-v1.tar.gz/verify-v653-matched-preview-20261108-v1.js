'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const [nativePath,purplePath,out]=process.argv.slice(2),read=f=>JSON.parse(fs.readFileSync(f)),requireHere=n=>require(path.resolve(n));
const {previewMatchedAnalysisScan}=requireHere('randomizer/game/ai/local-decision-plans'),{buildRuleObservation}=requireHere('randomizer/app/rule-observation');
const stateValue=requireHere('randomizer/game/ai/state-value'),data=requireHere('randomizer/game/data');
const native=read(nativePath),purple=read(purplePath),seatId='player-white';
function readState(e){return JSON.parse(e.committedState);}
function score(s){return stateValue.evaluateStateValue(buildRuleObservation(s,s.meta.seed,seatId),seatId).total;}
function assets(s){
 const p=s.players.players.find(x=>x.id===seatId),view=buildRuleObservation(s,s.meta.seed,seatId);
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserved:p.reservedCards.map(c=>c.id),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),
  traceCounts:view.selfState.traceCounts,established:view.publicState.players.find(x=>x.playerId===seatId).finalScore,
  completedTaskCount:p.completedTaskCount,sectorWins:s.data.sectorSettlements.winsByPlayerId[seatId],turn:s.turn.turnNumber,value:score(s)};
}
const stable=x=>x&&typeof x==='object'?(Array.isArray(x)?x.map(stable):Object.fromEntries(Object.keys(x).sort().map(k=>[k,stable(x[k])]))):x;
const info=s=>stateValue.evaluateStateValue(buildRuleObservation(s,s.meta.seed,seatId),seatId);
const rows=[];
for(const w of native.rows){
 const state=readState(w.origin),before=JSON.stringify(state),p=state.players.players.find(x=>x.id===seatId);
 const knownCards=new Set([...p.hand,...p.reservedCards,...state.cards.publicCards.filter(Boolean)].map(c=>c.id)),knownTech=(id,stack)=>stack.bonusId!=null;
 const result=previewMatchedAnalysisScan({state,seatId,knownCards,knownTech,amibaOffer:9,chongOffer:{slotId:2,displayedCardIndex:9}});
 assert.equal(JSON.stringify(state),before);
 assert(result,'proof unavailable');
 const actual={analysis:w.sides.find(s=>s.label==='analysis-first').end,scan:w.sides.find(s=>s.label==='scan-first').end,
  research:purple.rows.find(s=>s.world===w.index).end};
 const scopes=[];
 for(const [label,e] of Object.entries(actual)){
  const q=assets(result[label].state),a=assets(readState(e)),diffs=Object.keys(a).filter(k=>k!=='value'&&JSON.stringify(stable(q[k]))!==JSON.stringify(stable(a[k])));
  if(diffs.length)console.log(JSON.stringify({world:w.index,label,diffs:diffs.map(k=>[k,q[k],a[k]])}));
  assert(!diffs.length,label);
  const fresh=info(result[label].state),formal=info(readState(e));
  assert.equal(result[label].value,fresh.total);
  const valueDiff=Object.keys(formal.components).filter(k=>fresh.components[k]!==formal.components[k]).map(k=>[k,fresh.components[k],formal.components[k]]);
  console.log(JSON.stringify({label,world:w.index,previewValue:q.value,nativeValue:a.value,valueDiff}));
  scopes.push({label,assets:q,nativeValue:a.value,valueDiff,income:result[label].dataIncome,sector:result[label].sector,analysis:result[label].analysis});
 }
 assert.deepEqual(scopes.map(x=>x.assets.value),[160,157,160]);
 rows.push({world:w.index,tileId:result.tileId,task:result.task,scopes});
}
fs.writeFileSync(out,JSON.stringify({scope:'Pure fixed state previews match three Native action orders; all hidden future rewards masked.',rows},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({worlds:rows.length,nativeInputs:0,values:rows[0].scopes.map(x=>[x.label,x.assets.value])}));
