'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n));
const {createSeededRandom}=load('randomizer/game/random');
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation');
const plans=load('randomizer/game/ai/local-decision-plans'),rds=load('randomizer/game/effects/residual-domain-session');
const [source,out]=process.argv.slice(2),from=JSON.parse(fs.readFileSync(source)),seat='player-white';
const seed=JSON.parse(from.rows[0].end.committedState).meta.seed;
const native=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,w)=>buildRuleObservation(s,seed,w?.playerId)});
native.newGame({seed});const c=native.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),owner=s=>s.players.players.find(p=>p.id===seat);
function act(w){
 const d=c.inspect().session?.decision,v=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(v);assert.deepEqual(v.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:v})
  :v.phase==='quick'?c.inputPort.submitQuickAction(v):c.inputPort.submitAction(v);
 assert(r.ok,JSON.stringify(r));return v;
}
function assets(){
 const s=state(),p=owner(s),v=c.projection({role:'player',playerId:seat}).state;
 return {turn:s.turn.turnNumber,round:s.turn.roundNumber,fossilTasks:s.aliens.chong.transportTasksByRocketId,completedFossils:s.aliens.chong.completedTransports,tech:p.techState,probes:s.pieces.rockets.filter(r=>r.playerId===seat),wallet:p.resources,hand:p.hand.map(c=>c.cardId),reserved:p.reservedCards.map(c=>c.cardId),
  income:p.income,computer:p.dataState.placedTokens.filter(t=>t.placementKind==='computer').length,blue:p.dataState.placedTokens.filter(t=>t.placementKind==='blueBonus').length,
  completedTaskCount:p.completedTaskCount,traceCounts:v.selfState.traceCounts,
  pending:c.inspect().session?.decision?.kind,projectedFinal:v.publicState.players.find(x=>x.playerId===seat).finalScore};
}
try{
 const r=from.rows[0];restore(r.origin);
 const fixed=r.inputs.slice(0,2);fixed.forEach(act);
 const e=save(),s=state(),actions=menu(),task=actions.find(a=>a.family==='complete_task');
 const {cardInstanceId:cardId,ruleId:taskId}=task.target,preview=plans.finalRoundReadyTask?.({state:s,seatId:seat,cardId,taskId})??null;
 const settlement=rds.queryCardSettlement(s,seat,{kind:'task',cardInstanceId:cardId,ruleId:taskId});
 const end=actions.find(a=>a.family==='end_turn');act(end);const pending=save();
 const o={seatId:seat,source:{seed},compositionEnvelope:e,pendingEnvelope:pending,task,preview,settlement,bonuses:s.turn.cardTurnEventBonuses,exact:false};
 restore(r.origin);fixed.forEach(act);assert.deepEqual(save(),e);act(end);assert.deepEqual(save(),pending);restore(r.origin);o.exact=true;
 fs.writeFileSync(out,JSON.stringify(o,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({task:task.target,preview,settlement,bonuses:o.bonuses,queue:pending.session?.session?.queue?.map(x=>[x.type,x.payload])}));
}finally{c.dispose();}
