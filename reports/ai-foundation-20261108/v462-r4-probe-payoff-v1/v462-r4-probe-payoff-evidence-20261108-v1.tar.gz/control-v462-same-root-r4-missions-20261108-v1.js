'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n));
const {createSeededRandom}=load('randomizer/game/random');
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation');
const pc=load('randomizer/game/ai/probe-capital'),weights=load('randomizer/game/ai/state-value').DEFAULT_WEIGHTS;
const [source,out]=process.argv.slice(2),from=JSON.parse(fs.readFileSync(source)),seat='player-white';
const seed=from.source.seed;
const native=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,w)=>buildRuleObservation(s,seed,w?.playerId)});
native.newGame({seed});const c=native.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),owner=s=>s.players.players.find(p=>p.id===seat);
function act(w){
 const d=c.inspect().session?.decision,v=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(v);assert.deepEqual(v.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:v})
  :v.phase==='quick'?c.inputPort.submitQuickAction(v):c.inputPort.submitAction(v);
 assert(r.ok,JSON.stringify(r));return v;
}
function assets(){
 const s=state(),p=owner(s),v=c.projection({role:'player',playerId:seat}).state;
 return {turn:s.turn.turnNumber,round:s.turn.roundNumber,fossilTasks:s.aliens.chong.transportTasksByRocketId,completedFossils:s.aliens.chong.completedTransports,tech:p.techState,probes:s.pieces.rockets.filter(r=>r.playerId===seat),wallet:p.resources,hand:p.hand.map(c=>c.cardId),reserved:p.reservedCards.map(c=>c.cardId),
  income:p.income,computer:p.dataState.placedTokens.filter(t=>t.placementKind==='computer').length,blue:p.dataState.placedTokens.filter(t=>t.placementKind==='blueBonus').length,
  completedTaskCount:p.completedTaskCount,traceCounts:v.selfState.traceCounts,
  pending:c.inspect().session?.decision?.kind,projectedFinal:v.publicState.players.find(x=>x.playerId===seat).finalScore};
}
try{
 const origin=from.compositionEnvelope,rows=[];
 for(const [planet,kind] of [['saturn','land'],['mercury','land'],['venus','orbit'],['venus','land']]){
  restore(origin);const initial=state(),p=owner(initial),inputs=[];
  const goal=pc.requirements(pc.factsFromState(initial,p)).find(g=>g.planetId===planet&&g.endpointFamily===kind&&g.requirementId.endsWith(':planet'));
  assert(goal);
  const pay=pc.funding(p.resources,{...goal.endpointFacts.cost,energy:(goal.endpointFacts.cost.energy||0)+goal.route.cost},weights);
  assert(pay&&pay.creditPurchases===0);
  const pick=(family,pred=()=>true)=>{
   const list=menu(),x=list.find(a=>a.family===family&&pred(a.target,a));assert(x,JSON.stringify(list.map(a=>[a.family,a.target])));inputs.push(act(x));
  };
  for(let i=0;i<pay.energyPurchases;i++)pick('quick_trade',t=>t.tradeId==='credits-for-energy');
  for(const m of goal.route.path){
   pick('move',t=>t.rocketId===6&&t.deltaX===m.deltaX&&t.deltaY===m.deltaY);
   pick('choose_payment',t=>t.kind==='move-payment'&&!t.cardIds.length);
  }
  pick(kind,t=>!t.planetId||t.planetId===planet);
  if(save().session&&menu().some(a=>a.target?.planetId===planet&&a.target?.actionType===kind))
   pick('choose_target',t=>t.planetId===planet&&(kind!=='land'||t.landTarget?.type==='planet'));
  const after=assets(),end=save(),decision=menu().map(a=>[a.family,a.summary,a.target]);
  restore(origin);inputs.forEach(act);assert.deepEqual(save(),end);
  rows.push({kind:planet+'-'+kind,origin,goal,pay,inputs,after,end,decision});
  console.log(JSON.stringify({planet,kind,route:goal.route.cost,wallet:after.wallet,projected:after.projectedFinal,
   decision:decision.slice(0,2).map(x=>x[1]),pay:pay.spend}));
 }
 restore(origin);
 fs.writeFileSync(out,JSON.stringify({scope:'Four explicitly named funded primary missions from the same initial V445 R4 state. No route directions searched.',rows,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
