'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n));
const {createSeededRandom}=load('randomizer/game/random');
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation');
const {passiveAgent}=load('tools/research-human405-round1');
const [source,out]=process.argv.slice(2),from=JSON.parse(fs.readFileSync(source)),seat='player-white';
const seed=JSON.parse(from.rows[0].end.committedState).meta.seed;
const native=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,w)=>buildRuleObservation(s,seed,w?.playerId)});
native.newGame({seed});const c=native.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),owner=s=>s.players.players.find(p=>p.id===seat);
function act(w){
 const d=c.inspect().session?.decision,v=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(v);assert.deepEqual(v.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:v})
  :v.phase==='quick'?c.inputPort.submitQuickAction(v):c.inputPort.submitAction(v);
 assert(r.ok,JSON.stringify(r));return v;
}
function assets(){
 const s=state(),p=owner(s),v=c.projection({role:'player',playerId:seat}).state;
 return {turn:s.turn.turnNumber,round:s.turn.roundNumber,fossilTasks:s.aliens.chong.transportTasksByRocketId,completedFossils:s.aliens.chong.completedTransports,tech:p.techState,probes:s.pieces.rockets.filter(r=>r.playerId===seat),wallet:p.resources,hand:p.hand.map(c=>c.cardId),reserved:p.reservedCards.map(c=>c.cardId),
  income:p.income,computer:p.dataState.placedTokens.filter(t=>t.placementKind==='computer').length,blue:p.dataState.placedTokens.filter(t=>t.placementKind==='blueBonus').length,
  completedTaskCount:p.completedTaskCount,traceCounts:v.selfState.traceCounts,
  pending:c.inspect().session?.decision?.kind,projectedFinal:v.publicState.players.find(x=>x.playerId===seat).finalScore};
}
try{
 const rows=[];
 for(const r of from.rows){
  restore(r.end);const inputs=[],decisions=[];
  const choose=(family,pred=()=>true)=>{
   const list=menu(),a=list.find(a=>a.family===family&&pred(a.target,a));
   assert(a,JSON.stringify(list.map(a=>[a.family,a.summary,a.target])));
   inputs.push(act(a));return a;
  };
  const end=()=>{
   choose('end_turn');
   while(save().session){
    const list=menu(),task=list.find(x=>x.family==='accept_optional_effect'&&x.target?.choiceId?.startsWith('confirm:task:'));
    assert(task,JSON.stringify(list.map(x=>[x.family,x.summary,x.target])));
    inputs.push(act(task));
   }
  };
  const record=label=>decisions.push({label,input:inputs.length,asset:assets(),end:save()});
  const afterLand=assets();
  if(r.kind==='venus-orbit'){
   choose('choose_card',t=>t.choiceId?.startsWith('income:')&&t.cardInstanceId==='card-30-pass-3-1');
   choose('card_corner',t=>t.cardInstanceId==='card-70-0');
   const b9=owner(state()).hand.find(c=>c.cardId==='b_9.webp');
   const dataSource=state().cards.publicCards.find(c=>c.cardId==='dlc_14.png');
   assert(b9&&dataSource&&assets().wallet.availableData===1);
   choose('industry',t=>t.abilityId==='deepspace_swap_cards');
   choose('choose_card',t=>t.cardInstanceId===b9.id);
   choose('choose_card',t=>t.cardInstanceId===dataSource.id);
   choose('card_corner',t=>t.cardInstanceId===dataSource.id);
  }else{
   choose('choose_target',t=>t.traceType==='yellow'&&t.stateExtra===true);
   if(save().session)choose('accept_optional_effect',t=>t.ruleId==='amiba0-yellow-data');
  }
  assert(assets().computer===3||assets().computer===4);
  for(let slot=assets().computer+1;slot<=6;slot++){
   choose('place_data');
   if(save().session)choose('choose_target',t=>t.target==='computer');
   if(save().session)choose('choose_card',t=>t.cardInstanceId==='card-60-0');   assert.equal(assets().computer,slot);
  }
  end();record('first-main');
  for(let i=0;state().turn.currentPlayerId!==seat||save().session;i++){
   assert(i<20);
   const list=menu(),actor=list[0]?.actorId;
   assert(actor&&actor!==seat&&list.every(a=>a.actorId===actor));
   const p=passiveAgent(actor).decide({legalActions:list,observation:c.projection({role:'player',playerId:actor}).state});
   inputs.push(act(list.find(a=>a.actionId===p.actionId)));
  }
  record('before-analysis');
  choose('analyze');
  const analysisChoices=menu().map(x=>[x.family,x.summary,x.target]);
  choose('choose_target',t=>t.traceType==='blue'&&t.stateExtra===true);
  end();record('second-main');
  const final=save();
  restore(r.end);inputs.forEach(act);assert.deepEqual(save(),final);
  rows.push({kind:r.kind,afterLand,origin:r.end,inputs,decisions,analysisChoices,end:final});
  console.log(JSON.stringify({kind:r.kind,states:decisions.map(x=>[x.label,x.asset.wallet,x.asset.computer,x.asset.blue,x.asset.completedTaskCount,x.asset.projectedFinal]),probes:assets().probes.length,options:analysisChoices.map(a=>a[1])}));
 }
 restore(from.rows[0].end);
 fs.writeFileSync(out,JSON.stringify({scope:'Matched two R4 white mains, same fixed analysis and comparable paid missions; Venus orbit requires distinct known funding. All optional decisions from published information and opponents passive.',rows,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
