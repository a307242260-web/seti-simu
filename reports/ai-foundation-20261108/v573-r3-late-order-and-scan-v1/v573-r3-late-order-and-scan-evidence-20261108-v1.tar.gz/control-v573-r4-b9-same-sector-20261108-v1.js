'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[sourceA,sourceB,out]=process.argv.slice(2),ref=read(sourceA).rows.find(r=>r.label==='6:0:1-sector-2-a'),alternate=read(sourceB).rows[0],seat='player-white',seed=JSON.parse(ref.root.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}


function control(r){
 restore(r.root);const origin=save(),start=assets(),accepted=[];
 for(const a of ref.accepted.slice(0,6))accepted.push(execute(a.action));
 const afterCommon=assets(),pinkMenu=menu().filter(a=>a.phase==='conditional');
 const pink=pinkMenu.find(a=>a.target?.alienSlotId===2&&a.target?.traceType==='pink');
 if(pink)accepted.push(execute(pink));
 const after=assets(),end=save();
 restore(origin);accepted.forEach(execute);assert.deepEqual(save(),end);restore(origin);
 return {goal:r.label,origin,originHash:hash(origin),accepted,start,afterCommon,pinkMenu,after,end,replayExact:true};
}
try{
 const rows=[ref,alternate].map(control);
 assert.deepEqual(rows[0].start.hand,rows[1].start.hand);
 assert.deepEqual(rows[0].start.market,rows[1].start.market);
 assert.deepEqual(rows[0].origin.rng,rows[1].origin.rng);
 assert(rows[0].pinkMenu.some(a=>a.target?.alienSlotId===2&&a.target?.traceType==='pink'));
 assert(!rows[1].pinkMenu.some(a=>a.target?.alienSlotId===2&&a.target?.traceType==='pink'));
 for(const r of rows)console.log(JSON.stringify({goal:r.goal,startSignals:r.start.signals,afterSignals:r.afterCommon.signals,afterWallet:r.after.wallet,afterHand:r.after.hand,pinkMenu:r.pinkMenu.map(x=>x.summary),reveal:r.after.aliens.slots[1].revealed}));
 fs.writeFileSync(out,JSON.stringify({scope:'Identical fixed R4 B9, signal targets, launch and final scan after two distinct R3 blue sector choices; compare Native pink eligibility before looking at reward.',rows},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
