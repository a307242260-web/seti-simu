'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[fixture,out]=process.argv.slice(2),ref=read(fixture),seat='player-white',seed=JSON.parse(ref.rows[0].origin.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}


const origin=ref.rows.find(x=>x.step===235).origin;
const options=()=>menu().map(a=>[a.family,a.summary,a.target]);
function control(trace){
 restore(origin);const accepted=[];
 const one=(f,t=()=>true)=>{
  const a=menu().find(x=>x.family===f&&t(x.target||{},x));
  assert(a,JSON.stringify({f,options:options()}));
  accepted.push({action:execute(a),asset:assets()});
 };
 one('analyze');
 one('choose_target',t=>t.speciesId==='amiba'&&t.position===trace);
 if(menu().some(x=>x.family==='choose_card'))one('choose_card',t=>t.source==='display'&&t.cardIndex===2);
 const afterAnalysis=assets();
 one('end_turn');
 one('play_card',t=>t.cardInstanceId==='alien-amiba-5-12');
 const marketMenu=options();
 one('choose_card',t=>t.source==='public'&&t.slotIndex===0);
 const symbols=options();
 one('choose_target',t=>t.region==='red'&&t.slotId==='red_2');
 const after=assets(),end=save();
 restore(origin);accepted.forEach(r=>execute(r.action));assert.deepEqual(save(),end);restore(origin);
 return {goal:'analyze-first-blue'+trace,afterAnalysis,after,accepted,marketMenu,symbols,end,replayExact:true};
}
try{
 const rows=[3,2].map(control);
 for(const r of rows)console.log(JSON.stringify({goal:r.goal,analysis:r.afterAnalysis.wallet,ending:r.after.wallet,hand:r.after.hand,market:r.after.market,publicActions:r.accepted.map(x=>x.action.summary),symbols:r.symbols}));
 fs.writeFileSync(out,JSON.stringify({scope:'Change only order of the last two official R3 mains, using visible targets; compare same checkpoint and verify exact replay.',originHash:hash(origin),rows},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
