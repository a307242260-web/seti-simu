'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const [repo,out,only]=process.argv.slice(2),arch=p=>path.resolve(repo,p);
const record=read(arch('reports/research/cf2d3b6a.a5cf6a37.quick-400.json')),source=read(arch(record.savePath)),opening=read(arch('reports/ai-foundation-20261023/human405-white-only-opening-20261030-v1.json')),seat='player-white',seed=record.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}

const pc=load('randomizer/game/ai/probe-capital');
try{
 const start=read(arch(opening.checkpointPath));
 assert.equal(start.replayCursor.stepIndex,23);
 assert.equal(crypto.createHash('sha256').update(fs.readFileSync(arch(opening.checkpointPath))).digest('hex'),opening.checkpointSha256);
 restore(start.coreState.compositionEnvelope);
 const rows=[];
 for(let i=23;i<source.replaySteps.length;i++){
  if(i+1>=218&&i+1<=256){
   const a=assets();
   rows.push({step:i+1,action:source.replaySteps[i].action,asset:a,menu:menu(),origin:save(),
    routes:pc.requirements(pc.factsFromState(state(),player())).filter(g=>g.endpointFamily==='land'&&g.requirementId.endsWith(':planet')).map(g=>({planet:g.planetId,route:g.route,cost:g.endpointFacts.cost}))});
  }
  execute(source.replaySteps[i].action);
 }
 assert.equal(save().committedState,source.committedState);assert.deepEqual(save().session,source.session);
 for(const r of rows)console.log(JSON.stringify({i:r.step,a:r.action.summary,r:[r.asset.wallet.score,r.asset.wallet.credits,r.asset.wallet.energy,r.asset.wallet.publicity,r.asset.wallet.availableData],hand:r.asset.hand.map(x=>x[1]),computer:r.asset.computer,blue:r.asset.blue,probe:r.asset.probes.map(x=>[x.sectorX,x.sectorY]),alt:r.menu.filter(x=>x.family===r.action.family).map(x=>x.summary),knownChong:r.asset.knownChongOffer}));
 fs.writeFileSync(out,JSON.stringify({scope:'Native official V541 replay and late decision roots',rows,replayExact:true},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
