'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const [archiveRoot,recordPath,openingPath,out]=process.argv.slice(2),arch=p=>path.resolve(archiveRoot,p);
const r=read(arch(recordPath)),source=read(arch(r.savePath)),opening=read(arch(openingPath)),seat='player-white',seed=r.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random'),{buildRuleObservation}=load('randomizer/app/rule-observation');
const {passiveAgent}=load('tools/research-human405-round1'),pc=load('randomizer/game/ai/probe-capital'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const view=(id=seat)=>c.projection({role:'player',playerId:id}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,board:p.resources.score,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).length,blue:p.dataState.placedTokens.filter(t=>t.placementKind==='blueBonus').length,
  probes:s.pieces.rockets.filter(x=>x.playerId===seat),traces:v.selfState.traceCounts,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>[x.id,x.cardId])};
}
const corners=['card-65-0','alien-amiba-2-14','card-67-0'];
function control(origin,keep){
 restore(origin);
 const inputs=[],stage={},checkpoints={},supply=[];
 const take=a=>{const b=execute(a);inputs.push(b);return b;};
 const choose=(f,p=()=>true)=>{const a=menu().find(a=>a.family===f&&p(a.target,a));assert(a,JSON.stringify({f,menu:menu().map(a=>[a.family,a.summary,a.target])}));return take(a);};
 const record=n=>{stage[n]=assets();checkpoints[n]=save();};
 const applyEndTurn=()=>{
  choose('end_turn');
  while(save().session)choose('accept_optional_effect',t=>t.choiceId?.startsWith('confirm:task:'));
 };
 const fill=(cap)=>{
  while(assets().computer<cap&&player().resources.availableData){
   choose('place_data');if(save().session)choose('choose_target',t=>t.target==='computer');
   if(save().session)choose('choose_card',t=>t.choiceId?.startsWith('income:')&&t.cardInstanceId==='card-60-0');
  }
 };
 const waitWhite=()=>{
  for(let n=0;state().turn.currentPlayerId!==seat||save().session;n++){
   assert(n<25);const actions=menu(),actor=actions[0]?.actorId;
   assert(actor&&actor!==seat&&actions.every(x=>x.actorId===actor));
   const {actionId}=passiveAgent(actor).decide({legalActions:actions,observation:view(actor)});
   take(actions.find(a=>a.actionId===actionId));
  }
 };
 record('origin');
 for(const id of corners.slice(0,corners.length-keep))choose('card_corner',t=>t.cardInstanceId===id);
 fill(4);applyEndTurn();record('r3BeforePass');
 assert.equal(stage.r3BeforePass.hand.length,keep?keep+1:0);
 if(!keep)assert.deepEqual(save(),read(arch(r.roundEnds.at(-1).checkpointPath)).coreState.compositionEnvelope);
 choose('pass');choose('choose_card',t=>t.choiceId==='card-30-pass-3-1');
 if(!keep){assert.equal(save().committedState,source.committedState);assert.deepEqual(save().session,source.session);}
 waitWhite();record('r4BeforeMain');
 const p=player(),goal=pc.requirements(pc.factsFromState(state(),p)).find(g=>g.planetId==='saturn'&&g.endpointFamily==='land'&&g.requirementId.endsWith(':planet'));
 assert(goal);
 const need=(goal.endpointFacts.cost.energy||0)+goal.route.cost;
 assert(p.resources.credits>=(goal.endpointFacts.cost.credits||0)+2*Math.max(0,need-p.resources.energy),JSON.stringify({keep,resources:p.resources,need,cost:goal.endpointFacts.cost}));
 while(player().resources.energy<need)choose('quick_trade',t=>t.tradeId==='credits-for-energy');
 for(const m of goal.route.path){
  choose('move',t=>t.rocketId===6&&t.deltaX===m.deltaX&&t.deltaY===m.deltaY);
  choose('choose_payment',t=>t.kind==='move-payment'&&!t.cardIds.length);
 }
 choose('land',t=>!t.planetId||t.planetId==='saturn');
 if(save().session&&menu().some(a=>a.target?.planetId==='saturn'&&a.target?.actionType==='land'))
  choose('choose_target',t=>t.planetId==='saturn'&&t.landTarget?.type==='planet');
 choose('choose_target',t=>t.traceType==='yellow'&&t.stateExtra===true&&t.alienSlotId===1);
 if(save().session)choose('accept_optional_effect',t=>t.ruleId==='amiba0-yellow-data');
 record('r4AfterLand');
 let shortage=Math.max(0,6-assets().computer-player().resources.availableData);
 for(const id of corners.slice(corners.length-keep, corners.length-keep+shortage)){
  choose('card_corner',t=>t.cardInstanceId===id);supply.push(id);
 }
 fill(6);assert.equal(assets().computer,6);
 applyEndTurn();record('r4EndFirstMain');
 waitWhite();choose('analyze');choose('choose_target',t=>t.traceType==='blue'&&t.stateExtra===true&&t.alienSlotId===1);
 applyEndTurn();record('r4EndSecondMain');waitWhite();record('r4BeforeThirdMain');
 const end=save();restore(origin);inputs.forEach(execute);assert.deepEqual(save(),end);restore(origin);
 return {keep,inputs,stage,checkpoints,supply,shortage,route:goal.route,replayExact:true};
}
try{
 const start=read(arch(opening.checkpointPath));assert.equal(start.replayCursor.stepIndex,23);
 assert.equal(crypto.createHash('sha256').update(fs.readFileSync(arch(opening.checkpointPath))).digest('hex'),opening.checkpointSha256);
 restore(start.coreState.compositionEnvelope);
 for(const x of source.replaySteps.slice(23,244))execute(x.action);
 assert.equal(state().turn.roundNumber,3);assert.equal(state().turn.turnNumber,15);assert.equal(player().resources.availableData,1);
 const origin=save(),rows=[];
 for(const keep of [0,1,2,3]){
  const row=control(origin,keep);rows.push(row);
  const {r3BeforePass:a,r4BeforeMain:b,r4AfterLand:f,r4BeforeThirdMain:z}=row.stage;
  console.log(JSON.stringify({keep,shortage:row.shortage,inputs:row.inputs.length,round3:[a.board,a.realized,a.wallet.credits,a.wallet.energy,a.income.energy,a.computer,a.hand.map(x=>x[1])],
   initialR4:[b.wallet.credits,b.wallet.energy],afterLand:[f.wallet.credits,f.wallet.energy,f.wallet.availableData],
   thirdMain:[z.board,z.realized,z.wallet.credits,z.wallet.energy,z.wallet.publicity,z.wallet.availableData,z.income.energy,z.hand.map(x=>x[1])]}));
 }
 fs.writeFileSync(out,JSON.stringify({scope:'Single official V534 R3 root, after input 244. Keep successive known data cards, compared at R3 before PASS and same two fixed Production R4 mains. No Autonomous rerun.',recordPath,openingPath,originHash:hash(origin),rows},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
