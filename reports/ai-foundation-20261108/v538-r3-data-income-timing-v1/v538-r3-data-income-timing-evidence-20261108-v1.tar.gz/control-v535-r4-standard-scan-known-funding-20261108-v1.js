'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n)),{createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random'),{buildRuleObservation}=load('randomizer/app/rule-observation');
const [source,out]=process.argv.slice(2),ref=JSON.parse(fs.readFileSync(source)),root=ref.end,seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,state=()=>{const e=save();return e.session?.session?.workingState||JSON.parse(e.committedState);},player=s=>s.players.players.find(p=>p.id===seat),menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function apply(expected){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===expected.actionId);assert(a,expected.actionId);assert.deepEqual(a.target,expected.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
 :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(r.ok,JSON.stringify(r));return a;
}
function choose(accepted,predicate){
 const a=menu().find(predicate);assert(a,JSON.stringify(menu().map(a=>[a.family,a.summary,a.target])));accepted.push(apply(a));return a;
}
function asset(){
 const s=state(),p=player(s),v=c.projection({role:'player',playerId:seat}).state;
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(h=>[h.id,h.cardId]),final:v.publicState.players.find(p=>p.playerId===seat).finalScore,turn:s.turn.turnNumber,
  completed:p.completedTaskCount,probes:s.pieces.rockets.filter(r=>r.playerId===seat),data:p.dataState};
}
try{
 restore(root);const accepted=[],before=asset();
 const action=(family,p=()=>true)=>choose(accepted,a=>a.family===family&&p(a.target,a));
 const data=load('randomizer/game/data'),scan=load('randomizer/game/actions/scan-effects'),cost=scan.getStandardScanCost(player(state()));
 assert.equal(before.turn,6);
 while(player(state()).resources.energy<cost.energy)action('quick_trade',t=>t.tradeId==='credits-for-energy');
 action('scan');
 for(let n=0;save().session;n++){
  assert(n<16);const a=menu();
  const candidate=a.find(x=>x.target?.mode==='skip')
   ||a.find(x=>x.target?.nebulaId&&x.family==='choose_target')
   ||a.find(x=>x.family==='choose_card'&&x.target?.nebulaId&&state().cards.publicCards.some(c=>c?.id===x.target.cardInstanceId&&['b_16.webp','dlc_16.png'].includes(c.cardId)))
   ||a.find(x=>x.target?.done||x.target?.skip);
  assert(candidate,JSON.stringify(a.map(x=>[x.family,x.target])));action(candidate.family,(t,x)=>x.actionId===candidate.actionId);
 }
 const afterScan=asset();
 if(process.env.SETI_V535_LATE_PURCHASE){
  assert.equal(afterScan.wallet.availableData,3);
  const supplier=state().cards.publicCards.find(c=>c?.cardId==='dlc_15.png');assert(supplier);
  action('quick_trade',t=>t.tradeId==='publicity-for-card');
  action('choose_card',t=>t.source==='public'&&t.cardInstanceId===supplier.id);
  action('card_corner',t=>t.cardInstanceId===supplier.id);
 }
 while(player(state()).resources.availableData&&data.listComputerPlacedTokens(player(state())).length<4){
  action('place_data');action('choose_target',t=>t.target==='computer');
  if(save().session){const wanted=player(state()).hand.find(c=>c.cardId===process.env.SETI_V535_INCOME);
   assert(wanted);action('choose_card',t=>t.cardInstanceId===wanted.id);}
 }
 const end=save(),after=asset();
 restore(root);accepted.forEach(apply);assert.deepEqual(save(),end);restore(root);
 fs.writeFileSync(out,JSON.stringify({scope:'Native standard scan, without playing a salary-drawn card or using an unknown data corner; common printed public choices',before,afterScan,accepted,after,end,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({before:before.wallet,afterScan:afterScan.wallet,after:after.wallet,handIncome:after.income.handSize,score:after.final,actions:accepted.map(a=>[a.family,a.summary])}));
}finally{c.dispose();}
