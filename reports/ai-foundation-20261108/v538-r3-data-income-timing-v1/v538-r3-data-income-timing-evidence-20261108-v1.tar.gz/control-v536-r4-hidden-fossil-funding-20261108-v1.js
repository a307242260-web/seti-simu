'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const [dir,out]=process.argv.slice(2), load=p=>require(path.resolve(p)), seat='player-white';
const read=(stem)=>JSON.parse(fs.readFileSync(path.join(dir,stem+'-20261108-v1.json'))), hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random'),{buildRuleObservation}=load('randomizer/app/rule-observation');
const scan=load('randomizer/game/actions/scan-effects'),chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const refs={
 early:{landing:read('v504-r214-income-and-fossil'),delivery:read('v504-r214-income-protected-delivery')},
 late:{landing:read('v510-r4-moved-no-purchase'),delivery:read('v510-r4-moved-no-purchase-delivery')},
};
const referenceScan=read('v535-r4-paid-income-standard-scan');
const seed=JSON.parse(refs.early.landing.origin.committedState).meta.seed;
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope;
const state=()=>{const e=save();return e.session?.session?.workingState||JSON.parse(e.committedState);};
const player=()=>state().players.players.find(p=>p.id===seat);
const menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const observation=()=>c.projection({role:'player',playerId:seat}).state;
function restore(e){assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);}
function execute(expected){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===expected.actionId&&x.actorId===expected.actorId);
 assert(a,JSON.stringify({missing:expected,menu:menu().map(x=>[x.family,x.summary,x.target])}));assert.deepEqual(a.target,expected.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(r.ok,JSON.stringify(r));return a;
}
function assign(source,selected){
 const e=structuredClone(source),s=JSON.parse(e.committedState),a=s.aliens.chong,{jupiter,saturn}=a.planetFossilIds;
 assert.equal(e.session,null);assert.equal(s.turn.roundNumber,3);
 if(saturn.includes(selected))return e;
 const swap='fossil_07';assert(jupiter.includes(selected)&&saturn.includes(swap));
 for(const id of [selected,swap])assert.deepEqual(a.fossilsById[id].visibleToPlayerIds,[]);
 jupiter[jupiter.indexOf(selected)]=swap;saturn[saturn.indexOf(swap)]=selected;
 a.fossilsById[selected].planetId='saturn';a.fossilsById[swap].planetId='jupiter';
 a.initialConfiguration.fossilOrder=a.initialConfiguration.fossilOrder.map(id=>id===swap?selected:id===selected?swap:id);
 assert.deepEqual(a.initialConfiguration.fossilOrder.slice(0,6),[...jupiter,...saturn]);
 e.committedState=JSON.stringify(s);return e;
}
function assets(){
 const p=player(),s=state(),v=observation().publicState.players.find(p=>p.playerId===seat);
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId,c.discardActionCode]),
  board:p.resources.score,realized:v.finalScore,completed:p.completedTaskCount,computer:data.listComputerPlacedTokens(p).length,
  market:s.cards.publicCards.map(c=>[c.id,c.cardId]),turn:[s.turn.roundNumber,s.turn.turnNumber]};
}
function caseRun(label,ref,id,baseline){
 const origin=assign(ref.landing.origin,id);restore(origin);
 assert.deepEqual(menu(),baseline.menu);assert.deepEqual(observation(),baseline.observation);
 assert.deepEqual(JSON.parse(origin.committedState).aliens.chong.fossilsById[id].visibleToPlayerIds,[]);
 const accepted=[],stage={origin:assets()},boundaries={};
 const take=a=>{const b=execute(a);accepted.push(b);return b;};
 const choose=(family,p=()=>true)=>{const a=menu().find(a=>a.family===family&&p(a.target,a));assert(a,JSON.stringify({family,menu:menu().map(a=>[a.family,a.summary,a.target])}));return take(a);};
 const snapshot=name=>{stage[name]=assets();boundaries[name]=hash(save());};
 for(const a of ref.landing.accepted){
  if(a.target?.fossilId==='fossil_07'){
   const offered=menu().filter(x=>x.target?.fossilId).map(x=>x.target.fossilId);
   assert(offered.includes(id));stage.offered=offered;choose('choose_target',t=>t.fossilId===id);
  }else take(a);
 }
 if(id==='fossil_07')assert.deepEqual(save(),ref.landing.end);
 snapshot('beforeDelivery');
 for(const a of ref.delivery.accepted)take(a);
 // The variable reward is first granted on delivery. Resolve a free public pick
 // only from an actual opened menu, using the same public B16 for both lines.
 if(save().session){
  stage.rewardMenu=menu().map(a=>[a.family,a.summary,a.target]);
  choose('choose_card',t=>t.publicSlotIndex===0&&t.cardInstanceId==='card-64-0');
 }
 assert.equal(save().session,null);
 assert.equal(player().completedTaskCount,stage.beforeDelivery.completed+1);
 assert(state().aliens.chong.fossilsById[id].taskCompleted);
 if(id==='fossil_07')assert.deepEqual(save(),ref.delivery.end);
 snapshot('afterDelivery');
 const cost=scan.getStandardScanCost(player()),wallet=player().resources;
 const needCredits=cost.credits+2*Math.max(0,cost.energy-wallet.energy);
 stage.scanBudget={cost,needCredits,shortfall:Math.max(0,needCredits-wallet.credits),supportedByExistingWallet:wallet.credits>=needCredits};
 if(stage.scanBudget.shortfall){
  assert.equal(label,'late');assert.equal(stage.scanBudget.shortfall,1);
  // Quote without treating the incoming salary cards as known before R4.
  // After observing both cards, sacrifice one free-pick B16 when present,
  // otherwise the R4-drawn DLC14, plus the R4-drawn B9 in either case.
  const ids=[id==='fossil_03'?'card-64-0':'card-68-0','card-69-0'].sort();
  choose('quick_trade',t=>t.tradeId==='cards-for-credit');
  stage.fundingMenu=menu().map(a=>[a.family,a.summary,a.target]);
  for(const card of ids)choose('choose_payment',t=>t.kind==='discard-hand-card'&&t.select&&t.cardInstanceId===card);
  choose('choose_payment',t=>t.confirm);
  snapshot('afterFallbackFunding');
 }
 if(player().resources.credits>=needCredits){
  while(player().resources.energy<cost.energy)choose('quick_trade',t=>t.tradeId==='credits-for-energy');
  choose('scan');take(referenceScan.accepted[3]);
  for(let i=0;save().session;i++){
   assert(i<10);const available=menu(),a=available.find(a=>a.family==='choose_card'&&a.target?.nebulaId&&['card-64-0','card-66-0'].includes(a.target?.cardInstanceId))
    ||available.find(a=>a.target?.done||a.target?.skip);
   assert(a,JSON.stringify(available.map(a=>[a.family,a.summary,a.target])));take(a);
  }
  snapshot('afterScan');
  if(label==='late'&&player().resources.availableData+data.listComputerPlacedTokens(player()).length<4){
   choose('quick_trade',t=>t.tradeId==='publicity-for-card');
   choose('choose_card',t=>t.source==='public'&&t.cardInstanceId==='card-67-0');
   choose('card_corner',t=>t.cardInstanceId==='card-67-0');
  }
  if(id==='fossil_03'&&player().resources.availableData+data.listComputerPlacedTokens(player()).length<4){
   choose('card_corner',t=>t.cardInstanceId==='card-30-pass-3-1');
  }
  while(player().resources.availableData&&data.listComputerPlacedTokens(player()).length<4){
   choose('place_data');choose('choose_target',t=>t.target==='computer');
   if(save().session)choose('choose_card',t=>t.cardInstanceId==='alien-chong-2-13');
  }
  snapshot('afterInvestment');
  if(id==='fossil_07'){
   const ref=read(label==='early'?'v535-r4-paid-income-standard-scan':'v535-r4-late-purchase-standard-scan');
   assert.deepEqual(save(),ref.end);
  }
 }
 const end=save();restore(origin);accepted.forEach(execute);assert.deepEqual(save(),end);restore(origin);
 return {label,selected:id,reward:chong.getFossilReward(id),originHash:hash(origin),boundaries,stage,accepted,
  replayExact:true,observationAndMenuEqual:true};
}
try{
 const rows=[];
 for(const [label,ref] of Object.entries(refs)){
  restore(ref.landing.origin);const base={menu:menu(),observation:observation()};
  for(const num of [7,6,1,2,5,3]){
   const id='fossil_0'+num;
   const r=caseRun(label,ref,id,base);rows.push(r);
   const {beforeDelivery:b,afterDelivery:a,afterInvestment:z,scanBudget:s}=r.stage;
   console.log(label,id,JSON.stringify({before:[b.wallet.credits,b.wallet.energy],delivery:[a.wallet.credits,a.wallet.energy,a.wallet.availableData,a.board],scanShort:s.shortfall,after:z&&[z.wallet.credits,z.wallet.energy,z.wallet.publicity,z.wallet.availableData,z.board,z.realized,z.income.handSize],inputs:r.accepted.length}));
  }
 }
 fs.writeFileSync(out,JSON.stringify({seed,scope:'Fixed legal paired R4 paths from each R3 income decision; six possible unrevealed planet-fossil rewards (initial panel unchanged). No policy change or new complete game.',inputs:rows.reduce((n,r)=>n+r.accepted.length,0),rows},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
