'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const [result,out]=process.argv.slice(2),o=JSON.parse(fs.readFileSync(result)),load=n=>require(path.resolve(n));
const e=load('randomizer/game/end-game-scoring'),ce=load('randomizer/game/cards/effects'),seat='player-white';
assert(o.replayExact&&o.rootAndRngRestored);assert.equal(o.rows.length,3);
const rows=o.rows.map(row=>{
 assert.equal(row.stop.reason,'end-of-matched-turn');assert(row.accepted.every(a=>a.n<=256&&a.ms<=600));
 const s=JSON.parse(row.end.committedState),p=s.players.players.find(x=>x.id===seat),details=e.computePlayerFinalScore({...s,players:s.players.players,cardEffects:ce,getCardTypeCode:c=>ce.getRuntimeCardTypeCode(c,ce.getCardModel(c)?.cardType)},p);
 assert.equal(details.baseScore,row.after.wallet.score);assert.equal(details.totalScore,row.after.final);
 return {label:row.label,actions:row.accepted.length,maxNativeInputs:Math.max(...row.accepted.map(a=>a.n)),
   maxMilliseconds:Math.max(...row.accepted.map(a=>a.ms)),wallet:p.resources,income:p.income,hand:p.hand.map(c=>c.cardId),
   tech:p.techState,data:p.dataState,details,scanWins:s.data.sectorSettlements.winsByPlayerId[seat]};
});
assert.deepEqual(rows.map(r=>[r.details.baseScore,r.details.totalScore,r.details.tileScoresById.a,r.income.handSize]),[[141,206,22,3],[144,192,11,2],[144,203,22,3]]);
assert.deepEqual(rows.slice(1).map(r=>r.details.tileScore-r.details.tileScoresById.a),[37,37]);
assert.deepEqual(rows.slice(1).map(r=>r.details.cardScore),[0,0]);
fs.writeFileSync(out,JSON.stringify({scope:'Independent exact rule score breakdown from stored end of the same matched third turn; not terminal scores',rows},null,2)+'\n',{flag:'wx'});
