'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),z=require('node:zlib');
const load=n=>require(path.resolve(n)),read=p=>JSON.parse(fs.readFileSync(p));
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random'),{buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),value=load('randomizer/game/ai/state-value'),search=load('randomizer/game/ai/decision-search'),agent=load('randomizer/game/ai/search-agent');
const [fixture,expectedPath,out]=process.argv.slice(2),f=read(fixture),expected=JSON.parse(z.gunzipSync(fs.readFileSync(expectedPath))),seat=f.seatId,seed=f.source.seed;
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope;
assert(c.lifecycle.restore(f.compositionEnvelope).ok);const root=save(),p=createAnalysisPort({composition:c,seatId:seat,maxCacheEntries:0}),proofs=new Map(),blindProofs=new Map(),rows=[];
const evaluate=value.createStateValueEvaluator(seat),opts={evaluate,...agent.OPTIONS,modelKey:evaluate.modelKey,budget:agent.BUDGET};
const signature=o=>o.roots.map(r=>[r.actionId,r.value,r.realization===0?0:r.realization,r.preparationDebt]);
function materializeData(current,goalId){
 const plan=p.resourceSpec(current)?.plans.find(x=>x.goal.id===goalId);
 assert(plan,`no native policy for ${goalId}: ${JSON.stringify(p.resourceSpec(current)?.plans.map(x=>x.goal.id))}`);
 const actual=p.expandResourcePlan(current,plan,()=>null);
 assert(actual.complete);assert.notEqual(actual.node.status,'plan-infeasible');
 return actual;
}
function endOrBoundary(current,rows){
 if(current.status==='stable'){
  const end=current.legalActions.find(a=>a.family==='end_turn');assert(end);
  current=p.expand(current,end.actionId);rows.push(end.actionId);
  while(current.status==='decision'){
   const fixed=p.localDecisionSpec(current);assert.equal(fixed?.kind,'fixed-final-mark');
   current=p.expand(current,fixed.selectedActionId);rows.push(fixed.selectedActionId);
  }
 }
 return current;
}
try{
 const wrapped={...p,turnTailBoundary(node,spec){if(spec.r4DeepSpaceDataTail)proofs.set(spec,node);return p.turnTailBoundary(node,spec);},
  incomePlanBoundary(node,spec){if(spec.r4RevealedChongIncome)blindProofs.set(spec,node);return p.incomePlanBoundary(node,spec);}};
 const r=search.searchDecision({port:wrapped,root:p.openRoot(),...opts});
 assert(r.complete);assert.deepEqual(signature(r),signature(expected));
 assert.deepEqual([r.actionId,r.value,r.realization===0?0:r.realization,r.preparationDebt],[expected.actionId,expected.value,expected.realization,expected.preparationDebt]);
 for(const[spec,node]of [...proofs,...blindProofs]){
  const source=evaluate.details(p.valueObservation(node));let current=node,actualActions=[];
  if(spec.goal){
   const actual=materializeData(current,spec.goal.id);actualActions.push(...actual.prefixes.map(q=>q.action.actionId));current=actual.node;
   assert.equal(current.status,'information-barrier');assert(['hidden_card_draw','hidden_card_reveal'].includes(current.boundary));
   const beforeHand=p.valueObservation(node).selfState.hand,afterHand=p.valueObservation(current).selfState.hand;
   assert.equal(afterHand.length,beforeHand.length);assert.equal(afterHand.filter(c=>c.hidden).length,beforeHand.filter(c=>c.hidden).length+1);
  }else{
   for(const step of spec.dataPlans){
    const actual=materializeData(current,step.goal.id);
    actualActions.push(...actual.prefixes.map(q=>q.action.actionId));current=actual.node;
    if(step.bluePublicPick){
      assert(actualActions.includes(step.bluePublicPick.cardActionId));
      for(const after of step.bluePublicPick.continuingDataPlans||[]){
       const suffix=materializeData(current,after.goal.id);
       actualActions.push(...suffix.prefixes.map(q=>q.action.actionId));current=suffix.node;
      }
    }
   }
   current=endOrBoundary(current,actualActions);
  }
  const actual=evaluate.details(p.valueObservation(current));
  const row={type:spec.goal?'blind':'data',kind:spec.kind,goals:spec.goal?[spec.goal.id]:spec.dataPlans.map(s=>s.goal.id),
   paid:actualActions.length,declared:spec.requiredNativeInputs,actual:actual.value,declaredValue:value.sumValueParts([source.value,spec.netGain]),
   actualPurposeDelta:value.sumValueParts([actual.unrealizedPurposeValue,-source.unrealizedPurposeValue]),declaredPurposeDelta:spec.unrealizedPurposeDelta,boundary:current.status};
  assert.equal(row.actual,row.declaredValue,JSON.stringify(row));
  assert.equal(row.actualPurposeDelta,row.declaredPurposeDelta,JSON.stringify(row));
  assert.equal(row.paid,row.declared,JSON.stringify(row));
  rows.push(row);
 }
 assert.deepEqual(save(),root);
 fs.writeFileSync(out,JSON.stringify({scope:'For every new scalar closure in the named root, replay original typed Native actions from the same fork, compare boundary value and value detail and input count',rows,rootAndRngUnchanged:true},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({rows:rows.length,data:proofs.size,blind:blindProofs.size,nativeReplayInputs:rows.reduce((n,x)=>n+x.paid,0),rootAndRngUnchanged:true}));
}finally{p.close();c.dispose();}
