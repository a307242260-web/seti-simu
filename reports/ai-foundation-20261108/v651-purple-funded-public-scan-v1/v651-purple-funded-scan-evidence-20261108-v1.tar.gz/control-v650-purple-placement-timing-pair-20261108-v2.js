'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[source,out]=process.argv.slice(2),rowsIn=read(source).rows,root=rowsIn.find(r=>r.goal==='place-0-before-purple').end,seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{const v=c.lifecycle.restore(e);assert(v.ok,JSON.stringify(v));assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}











function input(family,test=()=>true){
 const a=menu().find(a=>a.family===family&&test(a));assert(a,family);return execute(a);
}

const ref=read(path.join(path.dirname(source),'v650-a0-prefix-21-autonomy-20261108-v1.json')).row;
try{
 const actions=ref.accepted.map(x=>x.action),scan=actions.findIndex(a=>a.family==='scan'),end=actions.findIndex((a,i)=>i>scan&&a.family==='end_turn');
 assert.equal(scan,14);assert(end>scan);
 const rows=[];
 for(const count of [0,1,2,3]){
  const origin=rowsIn.find(r=>r.goal===`place-${count}-before-purple`).end,executed=[];
  restore(origin);
  for(const a of [...actions.slice(0,2),...actions.slice(2+2*count,scan)])executed.push(execute(a));
  const beforeScan=assets(),scanStart=save();
  for(const a of actions.slice(scan,end+1))executed.push(execute(a));
  const afterScan=assets(),next=save();
  restore(origin);executed.forEach(execute);assert.deepEqual(save(),next);
  rows.push({count,beforeScan,afterScan,scanStart,next,executed,replayExact:true});
 }
 const [none,one,two,three]=rows;
 for(const [a,b] of [[none,one],[none,two],[none,three]]){
  for(const stage of ['beforeScan','afterScan']){
   const x=a[stage],y=b[stage];
   assert.deepEqual({...x.wallet,publicity:0},{...y.wallet,publicity:0});
   assert.deepEqual([x.tech,x.hand,x.computer,x.blue,x.income,x.traceCounts],[y.tech,y.hand,y.computer,y.blue,y.income,y.traceCounts]);
  }
 }
 assert.deepEqual(rows.map(x=>[x.beforeScan.wallet.publicity,x.afterScan.wallet.publicity]),[[6,10],[6,10],[5,9],[5,9]]);
 restore(root);
 fs.writeFileSync(out,JSON.stringify({scope:'Native Purple1, same funded scan, same trace and task; only placement timing differs.',rows},null,2)+'\n',{flag:'wx'});
 for(const r of rows)console.log(JSON.stringify([r.count,r.beforeScan.wallet,r.afterScan.wallet,r.afterScan.hand.map(h=>h[1])]));
}finally{c.dispose();}
