'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[source,out]=process.argv.slice(2),rowsIn=read(source).rows,root=rowsIn.find(r=>r.goal==='place-1-before-purple').end,seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{const v=c.lifecycle.restore(e);assert(v.ok,JSON.stringify(v));assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}











function input(family,test=()=>true){
 const a=menu().find(a=>a.family===family&&test(a));assert(a,family);return execute(a);
}

const value=load('randomizer/game/ai/state-value'),measure=()=>value.evaluateStateValue(view(),seat).total;
try{
 const base=read(path.join(path.dirname(source),'v650-place-one-cost-20261108-v1.json')).quote;
 const graph=read(path.join(path.dirname(source),'v651-place-one-cost-20261108-v1.json')).quote;
 assert.deepEqual(graph.roots,base.roots);assert.equal(graph.n,227);assert.equal(base.n,259);
 const byId=new Map(graph.lines.map(l=>[l.node,l])),paths=new Map([[0,[]]]),queue=[0];
 for(let i=0;i<queue.length;i++)for(const e of byId.get(queue[i]).edges){
  if(paths.has(e.target)||e.turnTailPlanValue||e.knownIncomePlan)continue;
  paths.set(e.target,[...paths.get(queue[i]),...(e.steps?.length?e.steps:[e.actionId])]);queue.push(e.target);
 }
 const rows=[];
 for(const l of graph.lines)for(const e of l.edges){
  const proof=e.turnTailPlanValue;if(proof?.computerThenQuietEnd?.placements!==2)continue;
  restore(root);const ids=paths.get(l.node);assert(ids,l.node);
  for(const id of ids){const a=menu().find(a=>a.actionId===id);assert(a,id);execute(a);}
  const before=save(),prior=assets(),v0=measure(),actions=[];
  for(let i=0;i<2;i++){actions.push(input('place_data'),input('choose_target',a=>a.target.target==='computer'));}
  actions.push(input('end_turn'));
  const end=save(),after=assets(),net=measure()-v0;
  assert.equal(net,proof.netGain,JSON.stringify({node:l.node,net,proof}));
  assert.deepEqual(after.computer,[1,2,3]);assert.equal(after.wallet.availableData,0);
  assert.equal(actions.length,proof.requiredNativeInputs);
  restore(before);actions.forEach(execute);assert.deepEqual(save(),end);
  rows.push({node:l.node,upstreamInputs:ids,actions,prior,after,net,proof,replayExact:true});
 }
 assert.equal(rows.length,8);restore(root);
 fs.writeFileSync(out,JSON.stringify({scope:'Independently Native-replay all eight newly certified two-placement tails and compare exact scalar deltas.',
 originalNative:base.n,certifiedNative:graph.n,rootRankingExact:true,rows},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({old:base.n,new:graph.n,values:rows.map(x=>x.net),exact:true}));
}finally{c.dispose();}
