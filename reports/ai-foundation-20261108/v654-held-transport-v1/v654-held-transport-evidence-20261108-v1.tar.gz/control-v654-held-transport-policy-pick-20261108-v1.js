'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const [fixture,referencePath,out]=process.argv.slice(2),root=read(fixture).compositionEnvelope;
const seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{const v=c.lifecycle.restore(e);assert(v.ok,JSON.stringify(v));assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}











function input(family,test=()=>true){
 const a=menu().find(a=>a.family===family&&test(a));assert(a,family);return execute(a);
}

const ref=read(referencePath).rows[0];
function mask(i){
 const e=structuredClone(root),s=JSON.parse(e.committedState);
 if(i){const pile=s.cards.drawPileCardIds,deck=s.aliens.chong.cardDeck;
  [pile[0],pile[i]]=[pile[i],pile[0]];[deck[0],deck[i]]=[deck[i],deck[0]];e.committedState=JSON.stringify(s);
 }
 return e;
}
try{
 const rows=[];
 for(const w of [0]){
  const origin=mask(w);restore(origin);
  const actions=[],cuts=[];const record=label=>cuts.push({label,after:assets(),end:save(),menu:menu()});
  const refAt=i=>actions.push(execute(ref.actions[i-1]));
  const pay=code=>{const id=player().hand.find(c=>c.cardId===code)?.id;assert(id);
    actions.push(input('choose_payment',a=>a.target.cardIds?.length===1&&a.target.cardIds[0]===id));};
  assert.equal(player().industryRoundMarkRound,3);
  refAt(1);refAt(2);
  actions.push(input('choose_card',a=>a.actionId==='choose_card:345c28fb'));
  refAt(4);refAt(5);refAt(6);record('before-blue-research');
  refAt(7);pay('chong_2.webp');refAt(9);refAt(10);refAt(11);refAt(12);refAt(13);refAt(14);
  record('before-transport');
  refAt(15);pay('chong_7.webp');
  actions.push(input('play_card',a=>a.target.cardInstanceId===player().hand.find(c=>c.cardId==='chong_3.webp')?.id));
  refAt(18);refAt(19);
  record('landed-before-new-information');
  const after=assets(),end=save();assert(after.wallet.score>=100);
  restore(origin);actions.forEach(execute);assert.deepEqual(save(),end);restore(origin);
  rows.push({world:w,goal:'held-without-swap-'+w,actions,cuts,after,end,replayExact:true});
  console.log(JSON.stringify({world:w,inputs:actions.length,score:after.wallet.score,known:cuts.map(x=>[x.label,x.after.wallet,x.after.probes.map(r=>[r.id,r.sectorX,r.sectorY])])}));
 }
 fs.writeFileSync(out,JSON.stringify({scope:'Native earlier visible Chong3 transported using only existing two distinct alien movement payers and held publicity; company exchange was spent and no refill paid any input.',rows},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
