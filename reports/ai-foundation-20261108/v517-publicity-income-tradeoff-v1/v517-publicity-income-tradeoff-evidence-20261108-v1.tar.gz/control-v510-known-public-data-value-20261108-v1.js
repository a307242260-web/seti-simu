'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n)),read=p=>JSON.parse(fs.readFileSync(p));
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random'),{buildRuleObservation}=load('randomizer/app/rule-observation'),rules=load('randomizer/game/rule-composition'),value=load('randomizer/game/ai/state-value');
const [source,controlled,out]=process.argv.slice(2),f=read(source),v=read(controlled),root=f.compositionEnvelope,seat=f.seatId,seed=f.source.seed;
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,w)=>buildRuleObservation(s,seed,w?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,state=()=>{const e=save();return e.session?.session?.workingState||JSON.parse(e.committedState);},owner=s=>s.players.players.find(p=>p.id===seat),menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
const observe=()=>c.projection({role:'player',playerId:seat}).state;
function act(expected){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===expected.actionId);assert(a,expected.actionId);assert.deepEqual(a.target,expected.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
 :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(r.ok,JSON.stringify(r));return a;
}
function must(predicate){const a=menu().find(predicate);assert(a);return act(a);}
try{
 restore(root);
 const publicOrigin=observe(),known=new Set(publicOrigin.publicState.board.publicCards.map(c=>c.id));
 const rows=[];
 const samePrice=input=>input.actionId;
 for(const kind of ['pass-without-purchase','pay-and-place']){
  restore(root);const accepted=[],steps=kind==='pay-and-place'?v.accepted.slice(2):[];
  for(const a of steps)accepted.push(act(a));
  if(kind==='pay-and-place')assert.deepEqual(save(),v.end);else assert.deepEqual(save(),root);
  const r3=save();
  function row(label){
   const live=observe(),masked=rules.sanitizeHiddenInformationObservation(publicOrigin,live,{code:'hidden_card_reveal'});
   if(kind==='pay-and-place')assert(masked.publicState.board.publicCards.some(card=>card?.hidden)&&live.publicState.board.publicCards.some(c=>c?.id&&!known.has(c.id)));
   const maskedValue=value.evaluateStateValue(masked,seat),fullValue=value.evaluateStateValue(live,seat);
   const p=owner(state());return {label,maskedValue,fullValue,wallet:p.resources,income:p.income,hand:p.hand.map(h=>h.cardId),computer:p.dataState.placedTokens.filter(t=>t.placementKind==='computer').length,market:masked.publicState.board.publicCards.map(c=>c?.cardId??null)};
  }
  const before=row('before-pass');
  accepted.push(must(a=>a.family==='pass'));
  const passive=row('pass-pending');
  accepted.push(must(a=>a.family==='choose_card'&&a.target?.choiceId==='card-30-pass-3-1'));
  const paid=row('next-income');
  const end=save();restore(root);accepted.forEach(act);assert.deepEqual(save(),end);restore(root);
  rows.push({kind,accepted,before,passive,paid,r3,end});
 }
 const [n,y]=rows;
 const componentDelta=Object.fromEntries(Object.entries(y.before.maskedValue.components).map(([k,x])=>[k,x-n.before.maskedValue.components[k]]));
 const outRow={scope:'Compare completed fixed plan and no purchase at the same pre-PASS phase; evaluate only the knowledge available at the original root, and match the same Native PASS reserve choice.',
  root,rows,componentDelta,pointDelta:y.before.maskedValue.total-n.before.maskedValue.total,postIncomeDelta:y.paid.maskedValue.total-n.paid.maskedValue.total,replayExact:true,rootAndRngRestored:true};
 fs.writeFileSync(out,JSON.stringify(outRow,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({componentDelta,pointDelta:outRow.pointDelta,postIncomeDelta:outRow.postIncomeDelta,rows:rows.map(r=>[r.kind,r.before.maskedValue.total,r.passive.maskedValue.total,r.paid.maskedValue.total,r.paid.wallet,r.paid.income,r.paid.computer])}));
}finally{c.dispose();}
