'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n)),read=p=>JSON.parse(fs.readFileSync(p));
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random'),{buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const [official,retained,paid,out]=process.argv.slice(2);
const fixtures=[
 ['official',read(official).rows.find(o=>o.kind==='route-before-research').end],
 ['retained-publicity',read(retained).end],
 ['paid-income',read(paid).end]
];
const seat='player-white',seed=JSON.parse(fixtures[0][1].committedState).meta.seed;
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,state=()=>{const e=save();return e.session?.session?.workingState||JSON.parse(e.committedState);},menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function apply(expected){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===expected.actionId&&x.actorId===seat);assert(a,expected.actionId);assert.deepEqual(a.target,expected.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
 :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);assert(r.ok,JSON.stringify(r));return a;
}
function asset(){
 const s=state(),p=s.players.players.find(p=>p.id===seat),v=c.projection({role:'player',playerId:seat}).state;
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(h=>[h.id,h.cardId]),final:v.publicState.players.find(p=>p.playerId===seat).finalScore,turn:s.turn.turnNumber,
  main:p.mainActionCompleted,completed:p.completedTaskCount,probes:s.pieces.rockets.filter(x=>x.playerId===seat),data:p.dataState};
}
try{
 const rows=[];
 for(const [label,root] of fixtures){
  restore(root);assert.equal(state().turn.roundNumber,4);assert.equal(state().turn.currentPlayerId,seat);assert.equal(state().turn.turnNumber,6);
  assert.equal(state().turn.passedPlayerIds.length,3);assert.equal(asset().main,false);assert.equal(save().session,null);
  const before=asset(),accepted=[];let checkpoint,stop=null;
  for(let i=0;i<60;i++){
   if(state().turn.turnNumber!==before.turn||state().turn.currentPlayerId!==seat){
    stop={reason:'end-of-matched-turn'};break;
   }
   const origin=save(),port=createAnalysisPort({composition:c,seatId:seat,maxCacheEntries:0});
   try{
    const agent=createSearchAgent({seatId:seat,analysisPort:port});if(checkpoint)agent.loadCheckpoint(checkpoint);
    const actions=menu(),r=agent.decide({seatId:seat,legalActions:actions}),q=r.search,n=q.diagnostics.nativeExecutions,ms=q.rootAndSearchMilliseconds;
    checkpoint=structuredClone(agent.createCheckpoint());
    assert.deepEqual(save(),origin);
    const action=actions.find(a=>a.actionId===r.actionId);
    if(!q.complete||q.unresolved.length||n>256||ms>600){stop={reason:'gate',n,ms,actionId:r.actionId};break;}
    assert(action);
    if(action.family==='pass'){stop={reason:'chose-pass',n,ms};break;}
    accepted.push({action:apply(action),n,ms,after:asset()});
   }finally{port.close();}
  }
  assert(stop);const end=save(),after=asset();restore(root);accepted.forEach(a=>apply(a.action));assert.deepEqual(save(),end);restore(root);
  rows.push({label,root,before,accepted,after,stop,end});
 }
 fs.writeFileSync(out,JSON.stringify({scope:'Standard V509 policy on the same round 4 white turn 6, after two fixed main actions in each route and after optional fossil delivery where available; no full-game run.',rows,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(rows.map(r=>[r.label,r.stop,r.after.wallet,r.after.final,r.after.hand.map(x=>x[1]),Object.keys(r.after.tech.ownedTiles).length,
  r.accepted.map(a=>[a.action.family,a.action.summary]),Math.max(0,...r.accepted.map(a=>a.n)),Math.max(0,...r.accepted.map(a=>a.ms))])));
}finally{c.dispose();}
