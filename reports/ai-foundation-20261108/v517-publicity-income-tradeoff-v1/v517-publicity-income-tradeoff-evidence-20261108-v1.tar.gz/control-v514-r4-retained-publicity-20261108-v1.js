'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n)),{createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random'),{buildRuleObservation}=load('randomizer/app/rule-observation');
const [source,out]=process.argv.slice(2),ref=JSON.parse(fs.readFileSync(source)),root=ref.end,seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,state=()=>{const e=save();return e.session?.session?.workingState||JSON.parse(e.committedState);},player=s=>s.players.players.find(p=>p.id===seat),menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function apply(expected){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===expected.actionId);assert(a,expected.actionId);assert.deepEqual(a.target,expected.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
 :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(r.ok,JSON.stringify(r));return a;
}
function choose(accepted,predicate){
 const a=menu().find(predicate);assert(a,JSON.stringify(menu().map(a=>[a.family,a.summary,a.target])));accepted.push(apply(a));return a;
}
function asset(){
 const s=state(),p=player(s),v=c.projection({role:'player',playerId:seat}).state;
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(h=>[h.id,h.cardId]),final:v.publicState.players.find(p=>p.playerId===seat).finalScore,turn:s.turn.turnNumber,
  completed:p.completedTaskCount,probes:s.pieces.rockets.filter(r=>r.playerId===seat),data:p.dataState};
}
try{
 restore(root);const rows=[];
 for(const target of ['purple2','purple3']){
  restore(root);const accepted=[],before=asset();
  if(!menu().some(a=>a.family==='research_tech')){rows.push({target,available:false,before,reason:'unfunded-publicity',legal:menu().map(a=>[a.family,a.summary])});continue;}
  choose(accepted,a=>a.family==='research_tech');
  const open=menu().filter(a=>a.family==='choose_target'&&a.target.tileId===target);
  if(!open.length){rows.push({target,available:false});continue;}
  choose(accepted,a=>a.family==='choose_target'&&a.target.tileId===target);
  for(let i=0;save().session;i++){
   assert(i<12);
   const supplier=state().cards.publicCards.find(c=>c?.cardId==='dlc_15.png');
   choose(accepted,a=>supplier&&a.target?.choiceId==='pick:'+supplier.id||a.target?.choiceId?.startsWith('confirm:')||a.target?.choiceId?.startsWith('skip:'));
  }
  const end=save(),after=asset();assert(after.tech.ownedTiles[target]);
  restore(root);accepted.forEach(apply);assert.deepEqual(save(),end);rows.push({target,available:true,before,accepted,after,end});
 }
 restore(root);
 fs.writeFileSync(out,JSON.stringify({scope:'Normal publicity-funded purple technology in the same third R4 main after the fixed delivery; legal menu independently checked.',rows,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(rows.map(x=>[x.target,x.available,x.after?.wallet,x.after?.final,x.accepted?.map(a=>[a.family,a.summary])])));
}finally{c.dispose();}
