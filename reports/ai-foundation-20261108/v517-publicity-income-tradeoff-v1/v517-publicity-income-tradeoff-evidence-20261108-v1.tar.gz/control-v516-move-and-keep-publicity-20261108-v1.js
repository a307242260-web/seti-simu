'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n)),{createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random'),{buildRuleObservation}=load('randomizer/app/rule-observation');
const [source,out,cornerCard='chong_7.webp']=process.argv.slice(2),ref=JSON.parse(fs.readFileSync(source)),base=ref.rows.find(r=>r.choice.position===9).end,seat='player-white',seed=JSON.parse(base.committedState).meta.seed;
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,state=()=>{const e=save();return e.session?.session?.workingState||JSON.parse(e.committedState);},player=s=>s.players.players.find(p=>p.id===seat),menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);},accepted=[],stages=[];
function apply(expected){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===expected.actionId);assert(a,expected.actionId);assert.deepEqual(a.target,expected.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(r.ok,JSON.stringify(r));return a;
}
function choose(predicate){
 const a=menu().find(predicate);assert(a,JSON.stringify(menu().map(a=>[a.family,a.summary,a.target])));accepted.push(apply(a));return a;
}
function snap(label){
 const s=state(),p=player(s),v=c.projection({role:'player',playerId:seat}).state;
 stages.push({label,input:accepted.length,wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(h=>[h.id,h.cardId]),final:v.publicState.players.find(p=>p.playerId===seat).finalScore,turn:s.turn.turnNumber,
  completed:p.completedTaskCount,probes:s.pieces.rockets.filter(r=>r.playerId===seat),pool:p.dataState,market:s.cards.publicCards.map(x=>[x.id,x.cardId])});
}
try{
 restore(base);assert(menu().every(a=>a.actorId===seat));snap('before');
 const corner=player(state()).hand.find(c=>c.cardId===cornerCard);assert(corner);
 choose(a=>a.family==='move'&&a.target.rocketId===6&&a.target.deltaX===0&&a.target.deltaY===1);
 choose(a=>a.family==='choose_payment'&&a.target.kind==='move-payment'&&a.target.cardIds.length===1&&a.target.cardIds[0]===corner.id);
 assert(!save().session);snap('toward-saturn');
 assert(!save().session&&menu().some(a=>a.family==='pass'));assert.equal(player(state()).resources.publicity,3);
 const end=save();restore(base);accepted.forEach(apply);assert.deepEqual(save(),end);restore(base);
 fs.writeFileSync(out,JSON.stringify({scope:'Same R3 one-step movement paid by Chong2; keep existing 3 publicity and Chong7, no purchase before PASS.',base,accepted,stages,end,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({stages:stages.map(s=>[s.label,s.wallet,s.income,s.hand,s.final,s.probes.map(r=>[r.sectorX,r.sectorY])]),accepted:accepted.map(a=>[a.family,a.summary])}));
}finally{c.dispose();}
