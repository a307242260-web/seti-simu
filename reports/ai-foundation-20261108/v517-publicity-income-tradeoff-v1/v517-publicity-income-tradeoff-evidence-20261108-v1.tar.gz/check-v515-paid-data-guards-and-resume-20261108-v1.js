'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=n=>require(path.resolve(n)),read=p=>JSON.parse(fs.readFileSync(p)),hash=v=>crypto.createHash('sha256').update(JSON.stringify(v)).digest('hex');
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random'),{buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent'),{createStateValueEvaluator}=load('randomizer/game/ai/state-value'),search=load('randomizer/game/ai/decision-search'),policy=load('randomizer/game/ai/search-agent');
const [fixture,stages,control,out]=process.argv.slice(2),f=read(fixture),p=read(stages).states,x=read(control),root=f.compositionEnvelope,seat=f.seatId,seed=f.source.seed;
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
const view=()=>c.projection({role:'player',playerId:seat}).state;
function change(envelope,alter){
 assert.equal(envelope.session,null);
 const state=JSON.parse(envelope.committedState);alter(state,state.players.players.find(v=>v.id===seat));return {...envelope,committedState:JSON.stringify(state)};
}
function native(a){
 const d=c.inspect().session?.decision,r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
 :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(r.ok,JSON.stringify(r));
}
function sample(e,checkpoint=null,agentMode=false){
 if(JSON.stringify(save())!==JSON.stringify(e))restore(e);const port=createAnalysisPort({composition:c,seatId:seat,maxCacheEntries:0}),start=performance.now();
 try{
  let r,a,saved;
  if(agentMode){
   const agent=createSearchAgent({seatId:seat,analysisPort:port});if(checkpoint)agent.loadCheckpoint(checkpoint);
   const d=agent.decide({seatId:seat,legalActions:menu()});r=d.search;a=menu().find(a=>a.actionId===d.actionId);saved=agent.createCheckpoint();
  }else{const evaluate=createStateValueEvaluator(seat);r=search.searchDecision({port,root:port.openRoot(),evaluate,modelKey:evaluate.modelKey,budget:policy.BUDGET,...policy.OPTIONS});a=menu().find(a=>a.actionId===r.actionId);}
  const ms=performance.now()-start;
  assert(a&&r.complete&&!r.unresolved.length&&r.diagnostics.nativeExecutions<=256&&ms<=600);
  assert.deepEqual(save(),e);
  return {r,a,saved,ms};
 }finally{port.close();}
}
const rotate=s=>{const deck=s.cards.drawPileCardIds;assert(deck.length>3&&deck[0]!==deck[2]);[deck[0],deck[2]]=[deck[2],deck[0]];};
try{
 restore(root);const obs=view(),actions=menu(),rotated=change(root,rotate);restore(rotated);assert.deepEqual(view(),obs);assert.deepEqual(menu(),actions);
 const variants={
  plain:root,hiddenReplacement:rotated,
  noSupplier:change(root,s=>{s.cards.publicCards[1]=null;}),
  noIncomeCard:change(root,(s,p)=>{p.hand=p.hand.filter(c=>c.cardId!=='dlc_25.png');p.resources.handSize=p.hand.length;}),
  oneFewerComputerSlot:change(root,(s,p)=>{p.dataState.placedTokens=p.dataState.placedTokens.filter(c=>c.placementKind!=='computer'||c.placementSlot!==3);}),
  opponentStillActive:change(root,s=>{s.turn.passedPlayerIds=s.turn.passedPlayerIds.filter(id=>id!=='player-green');}),
  insufficientPublicity:change(root,(s,p)=>{p.resources.publicity=2;})
 };
 const rows=[],known=[];
 for(const [label,e] of Object.entries(variants)){
  const {r,a,ms}=sample(e),goal=r.lines[0]?.cardPickPolicy?.goal,pay=r.roots.find(x=>x.actionId==='quick_trade:71814d67');
  if(['plain','hiddenReplacement'].includes(label)){
   assert.equal(goal?.kind,'paid-public-data-income');assert.equal(pay.value,179);assert.equal(r.value,179.5);assert.equal(a.family,'pass');
   known.push(r.roots.map(x=>[x.actionId,x.value,x.completion]));
  }else assert.notEqual(goal?.kind,'paid-public-data-income');
  rows.push({label,goal:goal?.kind??null,selected:a.actionId,value:r.value,paidValue:pay?.value??null,native:r.diagnostics.nativeExecutions,ms});
 }
 assert.deepEqual(known[0],known[1]);
 const resumed=[];let checkpoint,firstCheckpoint;restore(p[0].compositionEnvelope);
 for(let i=0;i<5;i++){
  const e=save(),{a,saved,r,ms}=sample(e,checkpoint,true),expected=x.accepted[i+3];
  assert.equal(a.actionId,expected.actionId);assert.deepEqual(a.target,expected.target);
  if(i){assert.equal(r.diagnostics.nativeExecutions,0);assert(r.reusedCoverage);}
  else firstCheckpoint=structuredClone(saved);
  native(a);
  checkpoint=structuredClone(saved);resumed.push({step:i+1,actionId:a.actionId,native:r.diagnostics.nativeExecutions,ms,reused:!!r.reusedCoverage});
 }
 const actual=save();assert.equal(hash(actual),hash(x.end),'settled actual state and RNG must match fixed control');
 const invalidated=sample(change(p[1].compositionEnvelope,rotate),firstCheckpoint,true);
 assert(!invalidated.r.reusedCoverage&&invalidated.r.diagnostics.nativeExecutions>0);
 resumed.push({alteredHiddenDeckReuseDenied:true,fallbackAction:invalidated.a.actionId,native:invalidated.r.diagnostics.nativeExecutions});
 restore(root);
 fs.writeFileSync(out,JSON.stringify({scope:'Proof and refusal on exact candidate plan, legal menu fingerprint and full Native/RNG reuse across actual applications',rootSha256:hash(root),rows,resumed,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({rows,resumed}));
}finally{c.dispose();}
