'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n)),read=p=>JSON.parse(fs.readFileSync(p));
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random'),{buildRuleObservation}=load('randomizer/app/rule-observation'),rules=load('randomizer/game/rule-composition'),value=load('randomizer/game/ai/state-value');
const [source,controlled,out]=process.argv.slice(2),f=read(source),v=read(controlled),root=f.compositionEnvelope,seat=f.seatId,seed=f.source.seed;
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,w)=>buildRuleObservation(s,seed,w?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,state=()=>{const e=save();return e.session?.session?.workingState||JSON.parse(e.committedState);},owner=s=>s.players.players.find(p=>p.id===seat),menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
const observe=()=>c.projection({role:'player',playerId:seat}).state;
function act(expected){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===expected.actionId);assert(a,expected.actionId);assert.deepEqual(a.target,expected.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
 :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(r.ok,JSON.stringify(r));return a;
}
function must(predicate){const a=menu().find(predicate);assert(a);return act(a);}
try{
 restore(root);const states=[];
 for(const [i,a] of v.accepted.slice(2).entries()){
  act(a);states.push({seatId:seat,source:{seed,input:i+1,phase:a.family},compositionEnvelope:save()});
 }
 assert.deepEqual(save(),v.end);restore(root);
 fs.writeFileSync(out,JSON.stringify({states,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
