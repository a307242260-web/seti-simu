'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[source,out]=process.argv.slice(2),rowsIn=read(source).rows,root=rowsIn.find(r=>r.goal==='funding-prefix-8').end,seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{const v=c.lifecycle.restore(e);assert(v.ok,JSON.stringify(v));assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}










const accepted=read(path.join(path.dirname(source),'v634-funding-prefix-8-autonomy-20261108-v1.json')).row.accepted.slice(0,6).map(r=>r.action);
const clean=x=>JSON.parse(JSON.stringify(x,(k,v)=>/milliseconds/i.test(k)?undefined:v));
function check(e){
 restore(e);
 const legal=menu(),p=createAnalysisPort({composition:c,seatId:seat,maxCacheEntries:0});
 try {
  const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:legal}).search;
  assert(q.complete&&!q.unresolved.length&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600);
  assert.deepEqual(save(),e);
  return {action:legal.find(a=>a.actionId===q.actionId),n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,
    value:q.value,roots:clean(q.roots),quotes:q.lines.flatMap(r=>r.knownTransportPreparation?[r.knownTransportPreparation]:[]),lines:clean(q.lines)};
 } finally {p.close();}
}
try{
 const rows=[],original=check(root);
 assert.equal(original.value,168.5);assert.equal(original.quotes.length,1);assert.equal(original.action.actionId,accepted[0].actionId);
 rows.push({label:'root',q:original});restore(root);
 const cuts=[];
 for(const a of accepted.slice(0,5)){execute(a);cuts.push(save());}
 for(let i=0;i<cuts.length;i++){
  const q=check(cuts[i]);assert.equal(q.action.actionId,accepted[i+1].actionId,i);
  if(i<4)assert(q.quotes.length===1,i);
  rows.push({label:'cold-'+(i+1),q});
 }
 const mut=(fn)=>{const e=structuredClone(root),s=JSON.parse(e.committedState);fn(s,s.players.players.find(p=>p.id===seat));e.committedState=JSON.stringify(s);return e;};
 const alternate=mut(s=>{
  const pile=s.cards.drawPileCardIds;[pile[0],pile[1]]=[pile[1],pile[0]];
  const b=s.tech.stacks.blue1.bonusQueue;[b[1],b[2]]=[b[2],b[1]];
  const x=s.aliens.chong,j=x.planetFossilIds.jupiter,t=x.planetFossilIds.saturn,j0=j[0],t0=t[0];
  assert.deepEqual(x.fossilsById[j0].visibleToPlayerIds,[]);assert.deepEqual(x.fossilsById[t0].visibleToPlayerIds,[]);
  j[0]=t0;t[0]=j0;x.fossilsById[j0].planetId='saturn';x.fossilsById[t0].planetId='jupiter';
  x.initialConfiguration.fossilOrder=x.initialConfiguration.fossilOrder.map(id=>id===j0?t0:id===t0?j0:id);
 });
 const hidden=check(alternate);
 assert.deepEqual([hidden.action,hidden.n,hidden.roots,hidden.quotes,hidden.lines],[original.action,original.n,original.roots,original.quotes,original.lines]);
 rows.push({label:'hidden',q:hidden});
 const strip=(p,id)=>{p.hand=p.hand.filter(c=>c.cardId!==id);p.resources.handSize=p.hand.length;};
 for(const [label,e] of [
  ['no-supplier',mut((s,p)=>strip(p,'chong_3.webp'))],['no-extra-move',mut((s,p)=>strip(p,'chong_2.webp'))],
  ['another-seat-active',mut(s=>{s.turn.passedPlayerIds=s.turn.passedPlayerIds.filter(id=>id!=='player-green');})],
  ['one-data-missing',mut((s,p)=>{p.dataState.poolTokens.pop();p.resources.availableData--;})],
  ['no-public-payer',mut(s=>{s.cards.publicCards[0]=null;s.cards.publicCards[1]=null;})]
 ]){const q=check(e);assert.equal(q.quotes.length,0,label);rows.push({label,q});}
 restore(root);
 fs.writeFileSync(out,JSON.stringify({scope:'Current turn fixed preparation: cold restores, hidden permutations and no-purpose controls.',rows},null,2)+'\n',{flag:'wx'});
 for(const {label,q} of rows)console.log(JSON.stringify([label,q.action.summary,q.value,q.n,q.ms,q.quotes.length]));
} finally{c.dispose();}
