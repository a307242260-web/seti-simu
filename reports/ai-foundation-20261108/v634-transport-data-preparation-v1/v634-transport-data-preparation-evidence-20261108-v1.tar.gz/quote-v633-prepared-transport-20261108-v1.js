'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=p=>require(path.resolve('randomizer/game',p)),seat='player-white';
const pk=load('production-kernel'),rd=load('ai/resource-demand'),lp=load('ai/local-decision-plans'),values=load('ai/state-value'),moves=load('abilities/rocket'),tech=load('tech/resolver');
const cards=load('cards/deck'),effects=load('cards/effects'),science=load('effects/science-session'),turn=load('turn-flow'),players=load('players'),data=load('data'),scoring=load('end-game-scoring');
const [input,out]=process.argv.slice(2),source=require(input);
const owner=s=>s.players.players.find(p=>p.id===seat);
function total(s,p){
 const score=scoring.computePlayerFinalScore({...s,players:s.players.players,aliens:structuredClone(s.aliens),finalScoring:structuredClone(s.finalScoring),cardEffects:effects,
 getCardTypeCode:c=>effects.getRuntimeCardTypeCode(c,effects.getCardModel(c)?.cardType)},p).totalScore;
 const w=values.DEFAULT_WEIGHTS;
 return values.sumValueParts([score,values.technologyCapital(p.techState,3),rd.planningCapital(s,p),
   ...Object.keys(w).map(k=>(p.resources[k]+p.income[k])*w[k])]);
}
function clone(s){
 const q=structuredClone(s);
 q.cards.drawPileCardIds.fill(null);
 for(const stack of Object.values(q.tech.stacks))stack.bonusQueue=stack.bonusQueue.map((v,i)=>i===stack.bonusIndex?v:null);
 return q;
}
function preview(source){
 const original=JSON.stringify(source),state=clone(source),p=owner(state);
 const placement=data.listComputerPlacedTokens(p).map(t=>t.placementSlot);
 if(placement.length!==5||p.resources.availableData!==1)return {failure:'computer-and-data'};
 const pure=p.hand.filter(c=>{
  const r=cards.getDiscardActionRewardForCard(c);
  return r?.gain?.publicity===1&&Object.keys(r.gain).length===1&&!r.dataCount;
 });
 const partial=p.hand.filter(c=>cards.getDiscardActionMoveRewardForCard(c)?.movementPoints===1&&effects.getCardModel(c)?.playEffects?.[0]?.type==='chong_probe_planet_fossil_reward');
 const plain=p.hand.filter(c=>{
  const r=cards.getDiscardActionMoveRewardForCard(c);return r?.movementPoints===1&&!Object.keys(r.gain).length;
 });
 if(pure.length!==1||partial.length!==1||plain.length!==1)return {failure:'payment'};
 const routes=moves.listPlayerMoveChoices(state,p,{maxPoints:1}).flatMap(({rocketId,deltaX,deltaY})=>{
  const s=structuredClone(state),q=owner(s);
  const r=moves.moveProbe(s,{rocketId,deltaX,deltaY,movementPoints:1,cost:{},source:'move'});
  return r.ok&&q.resources.publicity===p.resources.publicity+1?[{s,r}]:[];
 });
 if(routes.length!==1)return {failure:'not-one-purposeful-move',n:routes.length};
 const {s,r}=routes[0],q=owner(s);
 for(const c of [partial[0],pure[0]])assert(cards.discardFromHandAtIndex(q,q.hand.findIndex(x=>x.id===c.id)).ok);
 players.gainResources(q,{publicity:1});
 const ctx=science.createActionContext(s,seat),rotate=tech.rotateForResearch(ctx,1);
 assert(rotate.ok);
 const legal=science.listResearchChoices(s,seat,{skipRotate:true}).find(c=>c.target.tileId==='blue1'&&c.target.blueSlot===3);
 assert(legal);
 const research=science.executeResearchChoice(s,seat,legal,{skipRotate:true});
 assert(research.ok&&!research.awaitingCardSelection);
 q.mainActionCompleted=true;
 const blue=lp.previewBlueCompletion({state:s,seatId:seat,goal:{id:'data:blue:3',kind:'blue-data',blueSlot:3,required:{}}});
 assert(blue.available&&blue.requiredNativeInputs===2);
 const quiet=lp.quietEndCompletion({state:s,seatId:seat});
 s.players.players=s.players.players.map(a=>a===q?blue.player:a);
 const next=turn.advanceTurnAfterPlayerAction(s,seat);
 assert(next.turnAdvanced&&!next.roundAdvanced&&next.nextPlayerId===seat);
 const funded=owner(s);funded.mainActionCompleted=false;
 let directory;
 const route=rd.heldLandingGoal({state:s,seatId:seat,compareTiming:()=>{throw Error('Unexpected timing');},candidates:()=>directory??=(pk.getProbeRouteRequirements(s,seat)?.candidates||[])});
 assert(route?.embeddedMove);
 const landing=directory.find(c=>route.id.startsWith(c.requirementId+':held-transport:'));
 const reward=landing.targetBenefit.score+0.5*landing.targetBenefit.dataCount+0.5*landing.publicityStops-3;
 assert.equal(JSON.stringify(source),original);
 return {raw:total(source,owner(source)),base:total(s,funded),reward,total:total(s,funded)+reward,route:route.id,
  move:r.payload,rotateEvents:rotate.events,researchEvents:research.events,quiet,tech:funded.techState,resources:funded.resources};
}
const rows=source.rows.map(r=>({label:r.label,...preview(JSON.parse(r.end.committedState))}));
fs.writeFileSync(out,JSON.stringify({scope:'Pure Native rule previews of funded research and landing; no move/turn tree; dark deck and next bonus masked before query.',rows},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(rows.map(r=>[r.label,r.failure??null,r.raw,r.base,r.reward,r.total,r.rotateEvents])));
