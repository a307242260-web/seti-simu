'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[source,out]=process.argv.slice(2),rowsIn=read(source).rows,root=rowsIn.find(r=>r.goal==='funding-prefix-4').end,seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{const v=c.lifecycle.restore(e);assert(v.ok,JSON.stringify(v));assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}










function replay(goal,cardId,place){
 restore(root);const actions=[];
 const input=(family,test=()=>true)=>{const a=menu().find(a=>a.family===family&&test(a));assert(a,family);actions.push(execute(a));};
 if(cardId){
  input('industry',a=>a.target.abilityId==='deepspace_swap_cards');
  input('choose_card',a=>a.target.cardInstanceId==='card-64-0');
  input('choose_card',a=>a.target.cardInstanceId===cardId);
 }
 if(place){input('place_data');input('choose_target',a=>a.target.target==='computer');}
 input('end_turn');
 const end=save(),after=assets();restore(root);actions.forEach(execute);assert.deepEqual(save(),end);
 return {goal,actions,after,end,replayExact:true};
}
try{
 const rows=[replay('swap-to-16-and-place','card-66-0',true),replay('swap-to-20-and-place','card-62-0',true),
  replay('swap-only','card-66-0',false),replay('place-only',null,true)];
 restore(root);
 fs.writeFileSync(out,JSON.stringify({scope:'Native shorter preparation route: direct company exchange for public move payer, without replenishment or blue use.',rows},null,2)+'\n',{flag:'wx'});
 for(const r of rows)console.log(JSON.stringify([r.goal,r.actions.length,r.after.wallet.availableData,r.after.hand.map(c=>c[1]),r.after.computer,r.after.blue]));
}finally{c.dispose();}
