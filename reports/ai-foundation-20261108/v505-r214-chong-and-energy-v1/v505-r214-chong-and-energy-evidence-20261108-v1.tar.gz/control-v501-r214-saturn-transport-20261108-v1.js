'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n)),read=p=>JSON.parse(fs.readFileSync(p));
const {createSeededRandom}=load('randomizer/game/random'),{createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port');
const {createSearchAgent}=load('randomizer/game/ai/search-agent');
const [source,out,mode='normal']=process.argv.slice(2),ref=read(source),base=ref.rows.find(r=>r.choice.position===9).end,seat='player-white',seed=JSON.parse(base.committedState).meta.seed;
const sourceState=JSON.parse(base.committedState);
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function act(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===seat);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
 :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(r.ok,JSON.stringify(r));return a;
}
function assets(e){
 const s=e.session?.session?.workingState||JSON.parse(e.committedState),p=s.players.players.find(q=>q.id===seat),
  v=c.projection({role:'player',playerId:seat}).state;
 return {turn:s.turn.turnNumber,wallet:p.resources,income:p.income,hand:p.hand.map(h=>[h.id,h.cardId]),data:p.dataState,tech:p.techState,
  probes:s.pieces.rockets.filter(x=>x.playerId===seat),wins:s.data.sectorSettlements.winsByPlayerId[seat],traces:v.selfState.traceCounts,
  projectedFinal:v.publicState.players.find(q=>q.playerId===seat).finalScore};
}
const pc=load('randomizer/game/ai/probe-capital'),weights=load('randomizer/game/ai/state-value').DEFAULT_WEIGHTS;
function raw(){
 const e=save();
 return e.session?.session?.workingState||JSON.parse(e.committedState);
}
function step(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId);
 assert(a);assert.deepEqual(a.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
 :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(r.ok,JSON.stringify(r));return a;
}
function selection(accepted,f,p=()=>true){
 const a=menu().find(a=>a.family===f&&p(a.target,a));assert(a,JSON.stringify(menu().map(a=>[a.family,a.target])));
 accepted.push(step(a));return a;
}
function getSaturn(){
 const s=raw(),p=s.players.players.find(x=>x.id===seat);
 return pc.requirements(pc.factsFromState(s,p)).find(g=>g.planetId==='saturn'&&g.endpointFamily==='land');
}
function move(accepted,d,card=null){
 selection(accepted,'move',t=>t.rocketId===6&&t.deltaX===d.deltaX&&t.deltaY===d.deltaY);
 selection(accepted,'choose_payment',t=>t.kind==='move-payment'
  &&(card?t.cardIds.length===1&&t.cardIds[0]===card:t.cardIds.length===0));
 assert.equal(save().session,null);
}
function advance(accepted){
 selection(accepted,'pass');
 selection(accepted,'choose_card',t=>t.kind==='pass-reserve-card'&&t.choiceId==='card-30-pass-3-1');
 assert.equal(raw().turn.roundNumber,4);assert.equal(save().session,null);
 for(let i=0;raw().turn.currentPlayerId!==seat||save().session;i++){
  assert(i<20);
  const decision=c.inspect().session?.decision;
  const a=decision?decision.choices.find(x=>x.family==='accept_optional_effect'&&x.target?.choiceId?.startsWith('skip:'))
    ||decision.choices.find(x=>x.family==='choose_card')
    :menu().find(x=>x.family==='pass');
  assert(a,JSON.stringify(menu()));
  accepted.push(step(a));
 }
}
try{
 const origin=base,accepted=[],stages=[];
 restore(origin);
 const record=label=>{const e=save(),s=raw(),a=assets(e);stages.push({label,input:accepted.length,asset:{...a,fossils:s.aliens.chong.fossilsById,tasks:s.aliens.chong.transportTasksByRocketId,rawProbes:s.pieces.rockets.filter(x=>x.playerId===seat)},end:e});};
 record('before-pass');
 advance(accepted);record('after-income');
 const goal=getSaturn();assert(goal);
 for(const d of goal.route.path)move(accepted,d);
 assert.equal(getSaturn().route.cost,0);record('arrived-at-saturn');
 const held=card=>raw().players.players.find(p=>p.id===seat).hand.find(c=>c.cardId===card);
 const play=held('chong_9.webp');assert(play);
 selection(accepted,'play_card',t=>t.cardInstanceId===play.id);
 selection(accepted,'choose_target',t=>t.planetId==='saturn'&&!t.satelliteId);
 for(let i=0;save().session;i++){
  assert(i<12);
  const list=menu();
  const a=list.find(a=>a.target?.fossilId==='fossil_07')
   ||list.find(a=>a.target?.traceType==='yellow'&&a.target.stateExtra===true&&a.target.alienSlotId===1)
   ||list.find(a=>a.target?.ruleId==='amiba0-yellow-data')
   ||list.find(a=>a.target?.choiceId?.startsWith('confirm:'));
  assert(a,JSON.stringify(list.map(x=>[x.family,x.summary,x.target])));
  accepted.push(step(a));
 }
 record('saturn-fossil-attached');
 while(assets(save()).data.placedTokens.filter(t=>t.placementKind==='computer').length<6&&assets(save()).wallet.availableData){
  selection(accepted,'place_data');
  if(save().session)selection(accepted,'choose_target',t=>t.target==='computer');
  if(save().session)selection(accepted,'choose_card',t=>t.cardInstanceId===held('dlc_25.png')?.id);
 }
 selection(accepted,'end_turn');
 while(save().session)selection(accepted,'accept_optional_effect',t=>t.choiceId?.startsWith('confirm:'));
 record('first-main');
 for(let i=0;raw().turn.currentPlayerId!==seat||save().session;i++){
  assert(i<20);
  const d=c.inspect().session?.decision,a=d?d.choices.find(x=>x.target?.choiceId?.startsWith('skip:'))||d.choices.find(x=>x.family==='choose_card'):menu().find(x=>x.family==='pass');
  assert(a,JSON.stringify(menu()));accepted.push(step(a));
 }
 if(menu().some(a=>a.family==='analyze')){
  selection(accepted,'analyze');selection(accepted,'choose_target',t=>t.traceType==='blue'&&t.stateExtra===true&&t.alienSlotId===1);
  selection(accepted,'end_turn');record('second-main');
 }
 const end=save();restore(origin);accepted.forEach(step);assert.deepEqual(save(),end);restore(origin);
 fs.writeFileSync(out,JSON.stringify({scope:'Existing R214 Blue9 hand invested under Native R4 same PASS choice, Saturn transport and same free analysis when affordable; no AI run.',origin,accepted,stages,end,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(stages.map(x=>[x.label,x.asset.wallet,x.asset.income,x.asset.hand.map(c=>c[1]),Object.values(x.asset.tasks||{}).map(t=>[t.fossilId,t.destinationPlanetId,t.cardId]),x.asset.projectedFinal])));
}finally{c.dispose();}
