'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n)),{createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random'),{buildRuleObservation}=load('randomizer/app/rule-observation'),rocket=load('randomizer/game/rockets'),ability=load('randomizer/game/abilities/rocket'),solar=load('randomizer/solar-system/core');
const [source,out]=process.argv.slice(2),root=JSON.parse(fs.readFileSync(source)).end,seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,state=()=>{const e=save();return e.session?.session?.workingState||JSON.parse(e.committedState);},player=s=>s.players.players.find(p=>p.id===seat),menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);},accepted=[],stages=[];
function apply(expected){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===expected.actionId);assert(a,expected.actionId);assert.deepEqual(a.target,expected.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(r.ok,JSON.stringify(r));return a;
}
function choose(predicate){
 const a=menu().find(predicate);assert(a,JSON.stringify(menu().map(a=>[a.family,a.target])));accepted.push(apply(a));return a;
}
function owned(){const s=state(),p=player(s),f=s.aliens.chong.fossilsById.fossil_07,v=c.projection({role:'player',playerId:seat}).state;
 return {wallet:p.resources,income:p.income,hand:p.hand.map(h=>[h.id,h.cardId]),final:v.publicState.players.find(p=>p.playerId===seat).finalScore,turn:s.turn.turnNumber,
  completed:p.completedTaskCount,fossil:f,transport:s.aliens.chong.transportTasksByRocketId,coord:rocket.getRocketSectorCoordinate(s.pieces.rockets.find(x=>x.fossilId==='fossil_07')||{})};}
function snap(label){stages.push({label,input:accepted.length,...owned()});}
function pathToEarth(s){
 const ship=s.pieces.rockets.find(r=>r.fossilId==='fossil_07'&&r.playerId===seat),earth=solar.collectPlanetLocations(s.solarSystem).find(p=>p.planetId==='earth');
 assert(ship&&earth);
 const queue=[{at:rocket.getRocketSectorCoordinate(ship),cost:0,path:[]}],seen=new Set();
 while(queue.length){
  queue.sort((a,b)=>a.cost-b.cost||a.path.length-b.path.length);
  const n=queue.shift(),id=n.at.x+','+n.at.y;if(seen.has(id))continue;seen.add(id);
  if(n.at.x===earth.x&&n.at.y===earth.y)return {rocketId:ship.id,earth:{x:earth.x,y:earth.y},...n};
  const cost=ability.getRequiredMovePointsFromCoordinate(s,player(s),n.at);
  for(const d of ability.MOVE_DIRECTIONS){
   const a=rocket.canMoveFromCoordinate(s.pieces,n.at,d.deltaX,d.deltaY,ship.id);
   if(a.ok)queue.push({at:a.to,cost:n.cost+cost,path:[...n.path,{...d,cost,from:n.at,to:a.to}]});
  }
 }
 throw new Error('No legal Earth route');
}
function settleOptional(main=false){
 for(let n=0;save().session;n++){
  assert(n<15);
  const actions=menu(),preferred=actions.find(a=>a.target?.cardInstanceId==='alien-chong-9-15'||a.target?.fossilId==='fossil_07')
   ||actions.find(a=>a.target?.choiceId?.startsWith(main?'skip:':'confirm:'))
   ||actions.find(a=>a.target?.choiceId?.startsWith('skip:'));
  assert(preferred,JSON.stringify(actions.map(a=>[a.family,a.summary,a.target])));choose(a=>a===preferred||a.actionId===preferred.actionId);
 }
}
try{
 restore(root);
 for(let n=0;state().turn.currentPlayerId!==seat||save().session;n++){
  assert(n<20);const d=c.inspect().session?.decision;
  choose(a=>d?a.target?.choiceId?.startsWith('skip:')||a.family==='choose_card':a.family==='pass');
 }
 snap('before-payment');const route=pathToEarth(state());
 for(const d of route.path){
  while(player(state()).resources.energy<d.cost){
   choose(a=>a.family==='quick_trade'&&a.target?.tradeId==='credits-for-energy');
  }
  choose(a=>a.family==='move'&&a.target.rocketId===route.rocketId&&a.target.deltaX===d.deltaX&&a.target.deltaY===d.deltaY);
  choose(a=>a.family==='choose_payment'&&a.target.kind==='move-payment'&&a.target.cardIds.length===0);
  settleOptional();
 }
 snap('arrived');assert.equal(owned().fossil.status,'delivered');
 choose(a=>a.family==='complete_task'&&a.target.cardInstanceId==='alien-chong-9-15');settleOptional();
 snap('claimed');assert(owned().fossil.taskCompleted);assert.equal(owned().completed,stages[0].completed+1);
 const end=save();restore(root);accepted.forEach(apply);assert.deepEqual(save(),end);restore(root);
 fs.writeFileSync(out,JSON.stringify({scope:'Known Earth destination and geometry; pay using existing energy and credits. Fixed legal Native transport and settlement.',route,accepted,stages,end,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({route,stages:stages.map(s=>[s.label,s.wallet,s.final,s.fossil.status,s.completed]),accepted:accepted.map(a=>[a.family,a.summary])}));
}finally{c.dispose();}
