'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),z=require('node:zlib'),crypto=require('node:crypto');
const read=f=>JSON.parse(fs.readFileSync(f)),hash=v=>crypto.createHash('sha256').update(JSON.stringify(v)).digest('hex'),load=f=>require(path.resolve(f));
const [historyPath,savePath,offerPath,autonomyPath,fixedPath,out,maskedPath]=process.argv.slice(2),
 history=read(historyPath),formal=read(savePath),offer=read(offerPath),auto=read(autonomyPath).rows[0],fixed=read(fixedPath).rows.find(r=>r.choice.position===9),
 seat=offer.seatId,seed=offer.source.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random'),
 {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),
 {createStateValueEvaluator}=load('randomizer/game/ai/state-value'),search=load('randomizer/game/ai/decision-search'),agent=load('randomizer/game/ai/search-agent');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({}),
 restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function act(expected){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===expected.actionId&&x.actorId===expected.actorId);
 assert(a,expected.actionId);assert.deepEqual(a.target,expected.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
 :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(r.ok,JSON.stringify(r));
}
function change(root,rot){
 const e=structuredClone(root),committed=JSON.parse(e.committedState),s=e.session.session,states=new Set([committed,s.baseState,s.workingState,s.committedState,...s.undoFrames.map(u=>u.stateBefore)].filter(Boolean));
 for(const state of states){
  const a=state.aliens.chong,d=a.cardDeck,raw=a.initialConfiguration.cardDeck;
  const remaining=new Set(d);assert(d.every(id=>raw.includes(id)));const n=rot%d.length,newDeck=[...d.slice(n),...d.slice(0,n)];
  a.cardDeck=newDeck;let i=0;a.initialConfiguration.cardDeck=raw.map(id=>remaining.has(id)?newDeck[i++]:id);
  assert.equal(i,d.length);
 }
 e.committedState=JSON.stringify(committed);return e;
}
function subset(o){
 const graph=structuredClone(o);
 function prune(x){if(!x||typeof x!=='object')return;for(const k of Object.keys(x)){if(/milliseconds/i.test(k))delete x[k];else prune(x[k]);}}prune(graph);
 return graph;
}
try{
 restore(history.rows[179].compositionEnvelope);
 for(let i=179;i<214;i++){const step=formal.replaySteps[i-1];assert.equal(step.stepIndex,i-1);act(step.action);}
 assert.deepEqual(save(),history.rows[214].compositionEnvelope);
 const officialRootHash=hash(save());
 restore(offer.compositionEnvelope);assert.deepEqual(auto.root,save());assert.deepEqual(fixed.end,auto.end);
 assert.equal(auto.accepted[0].action.target.choiceId,'chong:display:9');assert.equal(auto.stop.reason,'settled-before-pass');
 const legal=menu(),observation=c.projection({role:'player',playerId:seat}).state,baseline=[],results=[];
 for(const rot of [0,1,3,5]){
  const e=rot?change(offer.compositionEnvelope,rot):offer.compositionEnvelope;restore(e);
  assert.deepEqual(menu(),legal);assert.deepEqual(c.projection({role:'player',playerId:seat}).state,observation);
  if(rot===1)fs.writeFileSync(maskedPath,JSON.stringify({...offer,compositionEnvelope:e})+'\n',{flag:'wx'});
  const p=createAnalysisPort({composition:c,seatId:seat,maxCacheEntries:0});
  try{
   const t=performance.now(),root=p.openRoot(),evaluate=createStateValueEvaluator(seat),r=search.searchDecision({port:p,root,evaluate,...agent.OPTIONS,modelKey:evaluate.modelKey,budget:agent.BUDGET}),ms=performance.now()-t;
   assert.deepEqual(save(),e);assert(r.complete&&!r.unresolved.length&&ms<=600&&r.diagnostics.nativeExecutions<=256);
   assert.equal(legal.find(a=>a.actionId===r.actionId).target.choiceId,'chong:display:9');
   const norm=subset(r);if(rot)assert.deepEqual(norm,baseline[0]);else baseline.push(norm);
   results.push({rotation:rot,hiddenDeckHash:hash(e.session.session.workingState.aliens.chong.cardDeck),
    actionId:r.actionId,value:r.value,ms,native:r.diagnostics.nativeExecutions,normalizedGraphSha256:hash(norm)});
  }finally{p.close();}
 }
 assert.equal(new Set(results.map(x=>x.hiddenDeckHash)).size,4);
 fs.writeFileSync(out,JSON.stringify({officialRootHash,replayedInputs:[179,213],conditionedAutonomyExact:true,legalMenuAndObservationUnchanged:true,rootAndRngUnchanged:true,results},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({officialRootHash,conditionedAutonomyExact:true,results}));
}finally{c.dispose();}
