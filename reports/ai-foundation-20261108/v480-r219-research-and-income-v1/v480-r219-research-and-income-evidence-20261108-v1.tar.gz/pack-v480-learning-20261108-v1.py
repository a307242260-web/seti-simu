from pathlib import Path
import gzip, hashlib, io, json, tarfile
b=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names='''
v474-matched-r3-third-main-20261108-v1.json
capture-v475-actual-r3-tails-20261108-v1.js
v475-actual-r3-tails-20261108-v1.json
control-v476-actual-trace-development-20261108-v1.js
v476-r190-trace-development-20261108-v1.json
v476-r214-trace-development-20261108-v1.json
control-v477-actual-221-market-development-20261108-v1.js
v477-r221-market-development-20261108-v1.json
control-v478-actual-r219-research-20261108-v1.js
v478-r219-research-development-20261108-v1.json
control-v479-actual-r219-blue-before-launch-20261108-v1.js
v479-r219-blue-before-launch-20261108-v1.json
contract-v480-three-known-corners-20261108-v1.md
v480-three-known-corners-20261108-v1.patch
v480-source-manifest-20261108-v1.json
measure-v406-gate-root-20261108-v1.js
v480-analysis-zero-pool-20261108-v1.json
v480-v445-analysis-zero-pool-20261108-v1.json.gz
v480-candidate-analysis-zero-pool-20261108-v1.json.gz
v480-actual-r219-fixture-20261108-v1.json
v480-candidate-actual-r219-20261108-v1.json.gz
v480-actual-r227-fixture-20261108-v1.json
v480-candidate-actual-r227-20261108-v1.json.gz
control-v480-analysis-candidate-autonomy-20261108-v1.js
v480-analysis-candidate-autonomy-20261108-v1.json
control-v481-masked-r219-refill-20261108-v1.js
v481-masked-r219-refill-20261108-v1.json
control-v481-masked-final-analysis-20261108-v1.js
v481-masked-final-analysis-20261108-v1.json
pack-v480-learning-20261108-v1.py
'''.split()
def load(n):return json.loads((b/n).read_bytes())
def row(q):
 a=q['after']
 return [a['wallet']['score'],len(a['tech']['ownedTiles']),a['income']['credits'],a['income']['energy'],a['income']['handSize'],a['income']['additionalPublicScan'],len(a['probes']),a['projectedFinal']]
for n,exp in [('v480-analysis-candidate-autonomy-20261108-v1.json',[[118,6,7,4,2,1,1,164]]),('v481-masked-final-analysis-20261108-v1.json',[[118,6,7,4,2,1,1,164]]),('v481-masked-r219-refill-20261108-v1.json',[[116,6,7,3,2,1,1,162]]*3)]:
 q=load(n);assert q['replayExact'] and q['rootAndRngRestored'];assert [row(r) for r in q['rows']]==exp
 for r in q['rows']:
  assert r['stop']['reason']=='settled-before-pass' and max(x['n'] for x in r['accepted'])<=256 and max(x['ms'] for x in r['accepted'])<=600
n,m=load('v480-analysis-candidate-autonomy-20261108-v1.json'),load('v481-masked-final-analysis-20261108-v1.json')
assert {k:v for k,v in n['rows'][0]['after'].items() if k!='knownDisplay'}=={k:v for k,v in m['rows'][0]['after'].items() if k!='knownDisplay'}
assert m['initialPublicObservationEqual'] and n['rows'][0]['after']['knownDisplay']!=m['rows'][0]['after']['knownDisplay']
assert [x['action'] for x in n['rows'][0]['accepted']]==[x['action'] for x in m['rows'][0]['accepted']]
q=load('v481-masked-r219-refill-20261108-v1.json')
assert q['originalDecision']==q['maskedDecision'] and q['initialPublicObservationEqual']
idx={'files':{n:sha(b/n) for n in names},'baseSource':'db2cb29a5dabfb19d5863d22cca7344318490dd0',
 'formalRecord':'reports/research/78044e14.db2cb29a.quick-400.json','strategy':'V480 isolated, apply archived patch on V445 source; no production admission in this archive.',
 'reproduction':[
  'Extract archive to a fresh directory A. From a clean V445 checkout, keep cwd at its root. Outputs ending .new are new paths.',
  'node "$A/capture-v475-actual-r3-tails-20261108-v1.js" "$A/v474-matched-r3-third-main-20261108-v1.json" reports/research/78044e14.db2cb29a.quick-400.json "$A/captured.new" (use formal V445 result checkout with the same runtime).',
  'V476, V477, V478 and V479 controls: their argv shows the archived capture and root input number, plus fresh output. Use V445 runtime.',
  'For candidate tests use an isolated V445 checkout and apply v480-three-known-corners-20261108-v1.patch; use the archived manifest to verify every runtime file.',
  'node "$A/measure-v406-gate-root-20261108-v1.js" "$A/v480-analysis-zero-pool-20261108-v1.json" "$A/cold.new"',
  'node "$A/control-v480-analysis-candidate-autonomy-20261108-v1.js" "$A/v480-analysis-zero-pool-20261108-v1.json" "$A/normal.new"',
  'node "$A/control-v481-masked-final-analysis-20261108-v1.js" "$A/v480-analysis-zero-pool-20261108-v1.json" "$A/final-masked.new"',
  'node "$A/control-v481-masked-r219-refill-20261108-v1.js" "$A/v475-actual-r3-tails-20261108-v1.json" 219 "$A/refill-masked.new"']}
archive=b/'v480-r219-research-and-income-evidence-20261108-v1.tar.gz'
with archive.open('xb') as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for name,raw in [(n,(b/n).read_bytes()) for n in names]+[('evidence-index.json',(json.dumps(idx,indent=2,ensure_ascii=False)+'\n').encode())]:
  t=tarfile.TarInfo(name);t.size=len(raw);tar.addfile(t,io.BytesIO(raw))
with tarfile.open(archive) as tar:
 assert all(hashlib.sha256(tar.extractfile(n).read()).hexdigest()==h for n,h in idx['files'].items())
print(len(names),archive.stat().st_size,sha(archive))
