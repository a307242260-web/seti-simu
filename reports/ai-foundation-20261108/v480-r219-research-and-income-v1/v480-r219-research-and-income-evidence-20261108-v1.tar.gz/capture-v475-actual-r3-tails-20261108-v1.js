'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n));
const {createSeededRandom}=load('randomizer/game/random');
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation');
const [source,recordPath,out]=process.argv.slice(2),seat='player-white';
const ref=JSON.parse(fs.readFileSync(source)),record=JSON.parse(fs.readFileSync(recordPath)),seed=record.seed;
const history=JSON.parse(fs.readFileSync(record.savePath)).replaySteps;
const native=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,w)=>buildRuleObservation(s,seed,w?.playerId)});
native.newGame({seed});const c=native.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),owner=s=>s.players.players.find(p=>p.id===seat);
function act(w){
 const d=c.inspect().session?.decision,v=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(v);assert.deepEqual(v.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:v})
  :v.phase==='quick'?c.inputPort.submitQuickAction(v):c.inputPort.submitAction(v);
 assert(r.ok,JSON.stringify(r));return v;
}
function assets(){
 const s=state(),p=owner(s),v=c.projection({role:'player',playerId:seat}).state;
 return {turn:s.turn.turnNumber,round:s.turn.roundNumber,fossilTasks:s.aliens.chong.transportTasksByRocketId,completedFossils:s.aliens.chong.completedTransports,tech:p.techState,probes:s.pieces.rockets.filter(r=>r.playerId===seat),wallet:p.resources,hand:p.hand.map(c=>c.cardId),reserved:p.reservedCards.map(c=>c.cardId),
  income:p.income,computer:p.dataState.placedTokens.filter(t=>t.placementKind==='computer').length,blue:p.dataState.placedTokens.filter(t=>t.placementKind==='blueBonus').length,
  completedTaskCount:p.completedTaskCount,traceCounts:v.selfState.traceCounts,
  pending:c.inspect().session?.decision?.kind,projectedFinal:v.publicState.players.find(x=>x.playerId===seat).finalScore};
}


try{
 const origin=ref.rows.find(r=>r.mode==='actual').end;
 const anchors=new Set([179,180,186,187,189,190,193,203,209,211,214,217,219,221,227,235,236,248,250,254]);
 const rows={},accepted=[];
 restore(origin);
 for(let i=179;i<=254;i++){
  if(anchors.has(i))rows[i]={seatId:seat,source:{seed,recordInput:i},compositionEnvelope:save(),asset:assets(),
    menu:menu().map(x=>[x.actionId,x.family,x.summary,x.target])};
  if(i===254)break;
  accepted.push(act(history[i-1].action));
 }
 const final=save(),official=JSON.parse(fs.readFileSync(record.roundEnds.find(r=>r.round===3).checkpointPath)).coreState.compositionEnvelope;
 assert.deepEqual(final,official);
 restore(origin);accepted.forEach(act);assert.deepEqual(save(),final);restore(origin);
 fs.writeFileSync(out,JSON.stringify({scope:'Official V445 root 179 through R3 pre-PASS, only recorded inputs; independent replay and known menus',rows,accepted,
  replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
 for(const i of [179,186,190,214,221,227,236,254]){const x=rows[i];console.log(JSON.stringify([i,x.asset.wallet,x.asset.knownDisplay,
  x.asset.hand,x.menu.filter(a=>a[1]==='choose_target'||a[1]==='choose_card').map(x=>x[2])]));}
}finally{c.dispose();}
