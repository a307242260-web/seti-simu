'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const [repo,out]=process.argv.slice(2),arch=p=>path.resolve(repo,p),d='reports/ai-foundation-20261107/committed-computer-recovery-v323-v1/';
const file='reports/research/cf2d3b6a.a5cf6a37.quick-400.json',record=read(arch(file)),source=read(arch(record.savePath)),opening=read(arch('reports/ai-foundation-20261023/human405-white-only-opening-20261030-v1.json')),seat='player-white',seed=record.seed;
const old=read(arch(d+'v323-round2-blue1-native-continuations-20261107-v1.json')),prior=read(arch(old.source));
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{passiveAgent}=load('tools/research-human405-round1');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
const eAction=w=>w.action||w;
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===(w.actionId||w.id)&&x.actorId===(w.actorId||w.actor));
 assert(a,JSON.stringify({w,legal:menu().map(x=>[x.summary,x.target])}));assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function asset(){
 const s=state(),p=player(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  data:p.dataState,probes:s.pieces.rockets.filter(r=>r.playerId===seat),alien:v.publicState.board.aliens,traces:v.selfState.traceCounts,
  wins:s.data.sectorSettlements.winsByPlayerId[seat],score:v.publicState.players.find(x=>x.playerId===seat).finalScore,
  market:s.cards.publicCards.map(c=>c&&[c.id,c.cardId]),round:s.turn.roundNumber,turn:s.turn.turnNumber};
}
const emit=(label,r2,r3)=>console.log(JSON.stringify({label,r2:{wallet:r2.wallet,income:r2.income,hand:r2.hand,score:r2.score},r3:{wallet:r3.wallet,hand:r3.hand,market:r3.market,score:r3.score}}));
try{
 const start=read(arch(opening.checkpointPath));assert.equal(start.replayCursor.stepIndex,23);
 assert.equal(crypto.createHash('sha256').update(fs.readFileSync(arch(opening.checkpointPath))).digest('hex'),opening.checkpointSha256);
 restore(start.coreState.compositionEnvelope);
 source.replaySteps.slice(23,103).map(eAction).forEach(execute);
 const researchRoot=save();assert.deepEqual(researchRoot,prior.research.source);
 execute(source.replaySteps[103].action);const origin=save(),originMenu=menu();
 assert.equal(source.replaySteps[104].action.target.tileId,'blue3');
 assert(originMenu.some(a=>a.target?.tileId==='blue1'&&a.target?.blueSlot===2));
 const branches=[];
 // The formal reference is a Native replay of archived actions, no new AI decisions.
 {
  const actions=[];
  for(const w of source.replaySteps.slice(104,127))actions.push(execute(w.action));
  const roundEnd=save(),r2Asset=asset();
  assert.deepEqual(roundEnd,read(arch(record.roundEnds[1].checkpointPath)).coreState.compositionEnvelope);
  for(const w of source.replaySteps.slice(127,135))actions.push(execute(w.action));
  const end=save(),r3Asset=asset();
  branches.push({label:'formal-blue3',actions,roundEnd,r2Asset,end,r3Asset});emit('formal-blue3',r2Asset,r3Asset);
 }
 restore(origin);
 const common=old.commonActions.slice(1).map(execute),commonRoot=save();assert.deepEqual(commonRoot,old.common.envelope);
 for(const row of old.cases){
  restore(commonRoot);const actions=[...common];let roundEnd,r2Asset;
  for(const w of row.actions){
   if(w.family==='pass'&&w.actor===seat){roundEnd=save();r2Asset=asset();assert.deepEqual(roundEnd,row.end.envelope);}
   if(w.actor!==seat){
    const legal=menu();const {actionId}=passiveAgent(w.actor).decide({legalActions:legal,observation:view(w.actor)});
    assert.equal(actionId,w.id);
   }
   actions.push(execute(w));
  }
  const end=save(),r3Asset=asset();assert.deepEqual(end,row.startR3.envelope);
  branches.push({label:row.label,actions,roundEnd,r2Asset,end,r3Asset});emit(row.label,r2Asset,r3Asset);
 }
 for(const b of branches){restore(origin);b.actions.forEach(execute);assert.deepEqual(save(),b.end);}restore(origin);
 fs.writeFileSync(out,JSON.stringify({scope:'Exact V541 research choice before input 105, same slot Blue1 vs archived formal Blue3. Revalidate all existing known blue1 funding prefixes and original passive contract under current rule engine without repeating any registered AI experiment.',origin,originMenu,originHash:hash(origin),researchRoot,oldRootExact:true,oldBlue1NativeEndpointsExact:true,branches,replayExact:true},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
