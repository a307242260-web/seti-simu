'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[fixture,out]=process.argv.slice(2),ref=read(fixture),origin=ref.rows[0].end,seat='player-white',seed=JSON.parse(origin.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}

const accepted=[],snapshot=()=>menu().map(x=>[x.family,x.summary,x.target]);
function take(test){
 const a=menu().find(test);assert(a,JSON.stringify(snapshot()));
 accepted.push({action:execute(a),asset:assets()});
}
const one=(f,t=()=>true)=>take(a=>a.family===f&&t(a.target||{},a));
function put(target){one('place_data');one('choose_target',target);}
try{
 restore(origin);
 one('choose_target',(t,a)=>t.planetId==='jupiter'&&a.summary.includes('2数据'));
 one('quick_trade',t=>t.tradeId==='publicity-for-card');
 one('choose_card',t=>t.cardInstanceId==='card-49-0');
 one('card_corner',t=>t.cardInstanceId==='card-49-0');
 put(t=>t.target==='blueBonus'&&t.blueSlot===2);
 put(t=>t.target==='computer');
 put(t=>t.target==='computer');
 one('end_turn');
 one('analyze');
 const after=assets(),choices=snapshot(),end=save();
 restore(origin);accepted.forEach(r=>execute(r.action));assert.deepEqual(save(),end);restore(origin);
 fs.writeFileSync(out,JSON.stringify({originHash:hash(origin),rows:[{goal:'jupiter-chong-analysis-menu',accepted,after,choices,end,replayExact:true}]},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({wallet:after.wallet,hand:after.hand,choices}));
}finally{c.dispose();}
