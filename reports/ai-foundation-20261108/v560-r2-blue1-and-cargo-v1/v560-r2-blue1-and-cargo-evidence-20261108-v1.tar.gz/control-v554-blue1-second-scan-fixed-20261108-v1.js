'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[fixture,graph,out]=process.argv.slice(2),ref=read(fixture),origin=ref.compositionEnvelope,q=JSON.parse(z.gunzipSync(fs.readFileSync(graph))),seat=ref.seatId,seed=ref.source.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}
function route(goal){
 const take=(ids,acc)=>{
  for(const id of ids){
   const a=menu().find(x=>x.actionId===id&&x.actorId===seat);assert(a,JSON.stringify({id,menu:menu().map(x=>[x.summary,x.target])}));
   acc.push({action:execute(a),asset:assets()});
  }
 };
 restore(origin);
 const start=assets(),accepted=[],edge=q.lines[0].edges.find(x=>x.resourcePlan?.goal.id===goal);
 assert(edge);assert.equal(q.lines[edge.target].value,126);
 take(edge.steps,accepted);
 let line=q.lines[edge.target],seen=new Set();
 while(line?.edges?.length&&!seen.has(line.node)){
  seen.add(line.node);
  const next=[...line.edges].filter(x=>q.lines[x.target].value===line.value).sort((a,b)=>(q.lines[a.target].distance+a.cost)-(q.lines[b.target].distance+b.cost))[0];
  assert(next?.steps,JSON.stringify(line));
  take(next.steps,accepted);line=q.lines[next.target];
 }
 assert(['turn-boundary','information-barrier'].includes(line.status));const end=save(),after=assets();
 restore(origin);accepted.forEach(r=>execute(r.action));assert.deepEqual(save(),end);restore(origin);
 return {goal,start,accepted,after,end,stop:line.status,replayExact:true};
}
try{
 const rows=['scan:sector:sector-2-b','scan:sector:sector-3-b'].map(route);
 fs.writeFileSync(out,JSON.stringify({scope:'Compare both equally quoted second-scan target flows by fixed Native replay from the over-limit root. Do not submit an AI decision on the failed root.',originHash:hash(origin),rows,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
 for(const r of rows)console.log(JSON.stringify({goal:r.goal,steps:r.accepted.map(x=>x.action.summary),wallet:r.after.wallet,income:r.after.income,hand:r.after.hand,tech:r.after.tech,computer:r.after.computer,blue:r.after.blue,probes:r.after.probes,knownChongOffer:r.after.knownChongOffer,score:r.after.realized}));
}finally{c.dispose();}
