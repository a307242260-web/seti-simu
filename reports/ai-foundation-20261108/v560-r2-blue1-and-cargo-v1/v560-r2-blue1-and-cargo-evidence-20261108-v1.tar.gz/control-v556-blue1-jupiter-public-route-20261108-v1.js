'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[fixture,graph,out]=process.argv.slice(2),ref=read(fixture),origin=ref.compositionEnvelope,q=JSON.parse(z.gunzipSync(fs.readFileSync(graph))),seat=ref.seatId,seed=ref.source.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}
const base=read(process.argv[5]);
function take(accepted,test){
 const a=menu().find(test);
 assert(a,JSON.stringify(menu().map(x=>[x.summary,x.target])));
 accepted.push({action:execute(a),asset:assets()});
}
function route(b){
 restore(origin);
 const start=assets(),accepted=[];
 for(const {action:a} of b.accepted) {
  take(accepted,x=>x.actorId===seat&&(a.target?.mode==='move'
   ? x.target?.mode==='move'&&x.target.rocketId===5&&x.target.deltaX===1&&x.target.deltaY===0
   :x.actionId===a.actionId));
 }
 const afterScan=assets();
 take(accepted,x=>x.family==='move'&&x.target?.rocketId===5&&x.target.deltaX===1&&x.target.deltaY===0);
 take(accepted,x=>x.family==='choose_payment'&&x.target?.kind==='move-payment'&&x.target.cardIds?.length===0);
 const afterTravel=assets();
 const chong2=afterTravel.hand.find(x=>x[1]==='chong_2.webp');
 assert(chong2);
 take(accepted,x=>x.family==='play_card'&&x.target?.cardInstanceId===chong2[0]);
 const choices=menu().map(x=>[x.family,x.summary,x.target]);
 const after=assets(),end=save();
 restore(origin);accepted.forEach(r=>execute(r.action));assert.deepEqual(save(),end);restore(origin);
 return {goal:b.goal,start,accepted,afterScan,afterTravel,after,choices,end,replayExact:true};
}
try{
 const rows=[route(base.rows[0])];
 fs.writeFileSync(out,JSON.stringify({scope:'Change only the known scan movement to Jupiter approach; check paid final move and actual Chong 2 menu.',rows,originHash:hash(origin)},null,2)+'\n',{flag:'wx'});
 for(const r of rows)console.log(JSON.stringify({goal:r.goal,afterScan:r.afterScan.wallet,afterTravel:r.afterTravel.wallet,probes:r.afterTravel.probes,hand:r.afterTravel.hand,choices:r.choices}));
}finally{c.dispose();}
