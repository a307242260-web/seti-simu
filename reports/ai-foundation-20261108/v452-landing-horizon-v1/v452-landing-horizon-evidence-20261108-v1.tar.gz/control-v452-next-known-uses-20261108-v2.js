'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n));
const {createSeededRandom}=load('randomizer/game/random');
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation');
const [comparison,out]=process.argv.slice(2),a=JSON.parse(fs.readFileSync(comparison));
const seat='player-white',seed=JSON.parse(a.rows[0].end.committedState).meta.seed;
const native=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,w)=>buildRuleObservation(s,seed,w?.playerId)});
native.newGame({seed});const c=native.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),owner=s=>s.players.players.find(p=>p.id===seat);
function act(w){
 const d=c.inspect().session?.decision,v=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(v);assert.deepEqual(v.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:v})
  :v.phase==='quick'?c.inputPort.submitQuickAction(v):c.inputPort.submitAction(v);
 assert(r.ok,JSON.stringify(r));return v;
}
function assets(){
 const s=state(),p=owner(s),v=c.projection({role:'player',playerId:seat}).state;
 return {turn:s.turn.turnNumber,wallet:p.resources,hand:p.hand.map(c=>c.cardId),reserved:p.reservedCards.map(c=>c.cardId),
  income:p.income,computer:p.dataState.placedTokens.filter(t=>t.placementKind==='computer').length,blue:p.dataState.placedTokens.filter(t=>t.placementKind==='blueBonus').length,
  pending:c.inspect().session?.decision?.kind,projectedFinal:v.publicState.players.find(x=>x.playerId===seat).finalScore};
}
try{
 const rows=[];
 for(const [r,purpose] of [[a.rows[0],'blue-1'],[a.rows[0],'known-score'],[a.rows[1],'launch']]){
  restore(r.end);const accepted=[],choices=[];
  const pick=(family,test=()=>true)=>{
   const list=menu(),x=list.find(a=>a.family===family&&test(a.target,a));assert(x,JSON.stringify(list.map(a=>[a.family,a.summary,a.target])));
   accepted.push(act(x));return x;
  };
  if(r.planet==='mercury')pick('end_turn');
  const initial=assets(),families=menu().map(x=>x.family);
  if(r.planet==='mercury'){
   assert(!families.includes('analyze'),JSON.stringify(families));
   assert.equal(initial.computer,4);
   assert.equal(initial.wallet.energy,0);
   for(let slot=5;slot<=6;slot++){
    pick('place_data');
    if(save().session)pick('choose_target',t=>t.target==='computer'&&(t.computerSlot==null||t.computerSlot===slot));
   }
   assert.equal(assets().computer,6);
   pick('analyze');
   if(save().session){
    choices.push(menu().map(x=>[x.family,x.summary,x.target]));
    pick('choose_target',t=>purpose==='known-score'?t.stateExtra===true&&t.traceType==='blue':t.speciesId==='amiba'&&t.traceType==='blue'&&t.position===1);
   }
  }else{
   assert(families.includes('launch')&&!families.includes('analyze'));
   pick('launch');
  }
  const after=assets(),end=save();
  restore(r.end);accepted.forEach(act);assert.deepEqual(save(),end);
  rows.push({purpose,planet:r.planet,origin:r.end,accepted,initial,after,choices,end});
  console.log(JSON.stringify({purpose,planet:r.planet,turns:[initial.turn,after.turn],wallet:after.wallet,income:after.income,
    projected:after.projectedFinal,actions:accepted.map(a=>a.summary),choices}));
 }
 restore(a.rows[0].end);
 fs.writeFileSync(out,JSON.stringify({scope:'First known main after the compared landings: fund Mercury analysis by filling the last two computer slots; existing free-analysis company, compare immediately funded Titania launch; no claim of optimal R3 suffix',rows,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
