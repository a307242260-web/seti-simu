'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n));
const {createSeededRandom}=load('randomizer/game/random');
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation');
const [source,recordPath,out]=process.argv.slice(2),seat='player-white';
const ref=JSON.parse(fs.readFileSync(source)),record=JSON.parse(fs.readFileSync(recordPath)),seed=record.seed;
const history=JSON.parse(fs.readFileSync(record.savePath)).replaySteps;
const native=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,w)=>buildRuleObservation(s,seed,w?.playerId)});
native.newGame({seed});const c=native.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),owner=s=>s.players.players.find(p=>p.id===seat);
function act(w){
 const d=c.inspect().session?.decision,v=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(v);assert.deepEqual(v.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:v})
  :v.phase==='quick'?c.inputPort.submitQuickAction(v):c.inputPort.submitAction(v);
 assert(r.ok,JSON.stringify(r));return v;
}
function assets(){
 const s=state(),p=owner(s),v=c.projection({role:'player',playerId:seat}).state;
 return {turn:s.turn.turnNumber,round:s.turn.roundNumber,fossilTasks:s.aliens.chong.transportTasksByRocketId,completedFossils:s.aliens.chong.completedTransports,tech:p.techState,probes:s.pieces.rockets.filter(r=>r.playerId===seat),wallet:p.resources,hand:p.hand.map(c=>c.cardId),reserved:p.reservedCards.map(c=>c.cardId),
  income:p.income,computer:p.dataState.placedTokens.filter(t=>t.placementKind==='computer').length,blue:p.dataState.placedTokens.filter(t=>t.placementKind==='blueBonus').length,
  completedTaskCount:p.completedTaskCount,traceCounts:v.selfState.traceCounts,
  pending:c.inspect().session?.decision?.kind,projectedFinal:v.publicState.players.find(x=>x.playerId===seat).finalScore};
}


try{
 const rows=[];
 for(const r of ref.rows){
  restore(r.end);const accepted=[],states=[];
  const submit=a=>accepted.push(act(a));
  for(let i=157;i<=165;i++){
   const expected=history[i-1].action,list=menu();
   let found=list.find(a=>a.actionId===expected.actionId);
   if(!found&&i===163&&r.mode!=='actual'){
    const card=owner(state()).hand.find(c=>c.cardId==='dlc_31.png');assert(card);
    found=list.find(a=>a.family==='play_card'&&a.target.cardInstanceId===card.id);
   }
   assert(found,JSON.stringify([i,expected.summary,list.map(a=>[a.summary,a.target])]));
   submit(found);
  }
  states.push({label:'same-DLC31-Mars-and-yellow',asset:assets(),end:save()});
  if(r.mode==='actual'){
   for(let i=166;i<=171;i++)submit(history[i-1].action);
  }else{
   assert.equal(assets().computer,6);
   assert(!menu().some(a=>a.family==='analyze'));
   const endTurn=menu().find(a=>a.family==='end_turn');assert(endTurn);submit(endTurn);
   if(save().session){const mark=menu().find(a=>a.target?.tileId==="a");assert(mark,JSON.stringify(menu().map(a=>a.summary)));submit(mark);}   assert(!save().session);
  }
  const end=save();states.push({label:'after-second-own-end',asset:assets(),end});
  restore(r.end);accepted.forEach(act);assert.deepEqual(save(),end);
  rows.push({mode:r.mode,origin:r.end,accepted,states,end});
  console.log(JSON.stringify({mode:r.mode,stages:states.map(x=>[x.label,x.asset.wallet,x.asset.computer,x.asset.blue,x.asset.projectedFinal,x.asset.hand])}));
 }
 restore(ref.rows[0].end);
 fs.writeFileSync(out,JSON.stringify({scope:'V445 R2 analysis deferral branches; same actual opponent inputs and same R3 Mars landing, compare B101 income availability before deferred analysis',rows,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
