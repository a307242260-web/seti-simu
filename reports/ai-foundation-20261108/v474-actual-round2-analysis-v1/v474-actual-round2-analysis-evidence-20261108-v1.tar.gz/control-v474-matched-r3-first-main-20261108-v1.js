'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n));
const {createSeededRandom}=load('randomizer/game/random');
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation');
const [source,recordPath,out]=process.argv.slice(2),seat='player-white';
const ref=JSON.parse(fs.readFileSync(source)),record=JSON.parse(fs.readFileSync(recordPath)),seed=record.seed;
const history=JSON.parse(fs.readFileSync(record.savePath)).replaySteps;
const native=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,w)=>buildRuleObservation(s,seed,w?.playerId)});
native.newGame({seed});const c=native.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),owner=s=>s.players.players.find(p=>p.id===seat);
function act(w){
 const d=c.inspect().session?.decision,v=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(v);assert.deepEqual(v.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:v})
  :v.phase==='quick'?c.inputPort.submitQuickAction(v):c.inputPort.submitAction(v);
 assert(r.ok,JSON.stringify(r));return v;
}
function assets(){
 const s=state(),p=owner(s),v=c.projection({role:'player',playerId:seat}).state;
 return {turn:s.turn.turnNumber,round:s.turn.roundNumber,fossilTasks:s.aliens.chong.transportTasksByRocketId,completedFossils:s.aliens.chong.completedTransports,tech:p.techState,probes:s.pieces.rockets.filter(r=>r.playerId===seat),wallet:p.resources,hand:p.hand.map(c=>c.cardId),reserved:p.reservedCards.map(c=>c.cardId),
  income:p.income,computer:p.dataState.placedTokens.filter(t=>t.placementKind==='computer').length,blue:p.dataState.placedTokens.filter(t=>t.placementKind==='blueBonus').length,
  completedTaskCount:p.completedTaskCount,traceCounts:v.selfState.traceCounts,
  pending:c.inspect().session?.decision?.kind,projectedFinal:v.publicState.players.find(x=>x.playerId===seat).finalScore};
}


try{
 const rows=[];
 for(const r of ref.branches){
  restore(r.end);const accepted=[],states=[];
  const submit=a=>accepted.push(act(a));
  for(let i=130;i<=144;i++)submit(history[i-1].action);
  states.push({label:'same-scan-and-launch-route',asset:assets(),end:save()});
  const select=(family,test=()=>true)=>{
   const list=menu(),a=list.find(a=>a.family===family&&test(a.target,a));assert(a,JSON.stringify(list.map(x=>[x.family,x.summary,x.target])));submit(a);
  };
  if(r.mode==='actual'){
   for(let i=145;i<=156;i++)submit(history[i-1].action);
  }else{
   const root=state();
   const offer=root.cards.publicCards.find(c=>c.cardId==='dlc_31.png');
   assert(offer);
   if(assets().computer===4)for(let i=0;i<2;i++){select('place_data');select('choose_target',t=>t.target==='computer');}
   assert.equal(assets().computer,6);
   assert(owner(state()).dataState.placedTokens.some(t=>t.blueSlot===2));
   const outgoing=owner(state()).hand.find(c=>c.cardId==='dlc_32.png');assert(outgoing);
   select('industry',t=>t.abilityId==='deepspace_swap_cards');
   select('choose_card',t=>t.cardInstanceId===outgoing.id);
   select('choose_card',t=>t.cardInstanceId===offer.id);
   select('end_turn');
   if(save().session)select('choose_target',t=>t.tileId==='a');
  }
  const end=save();states.push({label:'same-visible-DLC31-and-first-own-end',asset:assets(),end});
  restore(r.end);accepted.forEach(act);assert.deepEqual(save(),end);
  rows.push({mode:r.mode,origin:r.end,accepted,states,end});
  console.log(JSON.stringify({mode:r.mode,stages:states.map(x=>[x.label,x.asset.wallet,x.asset.computer,x.asset.blue,x.asset.projectedFinal,x.asset.hand])}));
 }
 restore(ref.branches[0].end);
 fs.writeFileSync(out,JSON.stringify({scope:'V445 R2 analysis deferral branches; same actual opponent inputs and first R3 scan/launch route, same known DLC31, different legal supplier',rows,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
