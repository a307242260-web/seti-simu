'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n));
const {createSeededRandom}=load('randomizer/game/random');
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation');
const [openingPath,recordPath,out]=process.argv.slice(2),seat='player-white';
const open=JSON.parse(fs.readFileSync(openingPath)),record=JSON.parse(fs.readFileSync(recordPath)),seed=record.seed;
const history=JSON.parse(fs.readFileSync(record.savePath)).replaySteps;
const from={compositionEnvelope:open.coreState.compositionEnvelope,source:{seed}};
const native=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,w)=>buildRuleObservation(s,seed,w?.playerId)});
native.newGame({seed});const c=native.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),owner=s=>s.players.players.find(p=>p.id===seat);
function act(w){
 const d=c.inspect().session?.decision,v=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(v);assert.deepEqual(v.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:v})
  :v.phase==='quick'?c.inputPort.submitQuickAction(v):c.inputPort.submitAction(v);
 assert(r.ok,JSON.stringify(r));return v;
}
function assets(){
 const s=state(),p=owner(s),v=c.projection({role:'player',playerId:seat}).state;
 return {turn:s.turn.turnNumber,round:s.turn.roundNumber,fossilTasks:s.aliens.chong.transportTasksByRocketId,completedFossils:s.aliens.chong.completedTransports,tech:p.techState,probes:s.pieces.rockets.filter(r=>r.playerId===seat),wallet:p.resources,hand:p.hand.map(c=>c.cardId),reserved:p.reservedCards.map(c=>c.cardId),
  income:p.income,computer:p.dataState.placedTokens.filter(t=>t.placementKind==='computer').length,blue:p.dataState.placedTokens.filter(t=>t.placementKind==='blueBonus').length,
  completedTaskCount:p.completedTaskCount,traceCounts:v.selfState.traceCounts,
  pending:c.inspect().session?.decision?.kind,projectedFinal:v.publicState.players.find(x=>x.playerId===seat).finalScore};
}


try{
 const origin=from.compositionEnvelope;
 assert.equal(open.replayCursor.stepIndex,23);
 const observed=[97,104,116,121,125,128,130],milestones=[],accepted=[];
 restore(origin);
 for(let i=24;i<=129;i++){
  if(observed.includes(i))milestones.push({beforeInput:i,asset:assets(),end:save()});
  const w=history[i-1].action;accepted.push(act(w));
 }
 milestones.push({beforeInput:130,asset:assets(),end:save()});
 const exact=JSON.parse(fs.readFileSync(record.roundEnds.find(x=>x.round===2).checkpointPath)).coreState.compositionEnvelope;
 assert.deepEqual(milestones.find(x=>x.beforeInput===128).end,exact);
 const root=milestones.find(x=>x.beforeInput===121).end,branches=[];
 for(const mode of ['actual','no-fill','fill-no-analysis']){
  restore(root);const xs=[],pick=(f,pred=()=>true)=>{
   const list=menu(),a=list.find(x=>x.family===f&&pred(x.target));assert(a,JSON.stringify(list.map(x=>[x.family,x.target])));xs.push(act(a));
  };
  if(mode!=='no-fill')for(let i=121;i<=124;i++)xs.push(act(history[i-1].action));
  if(mode==='actual')for(let i=125;i<=127;i++)xs.push(act(history[i-1].action));
  const prePass=assets(),passRoot=save();
  pick('pass');
  pick('choose_card',t=>t.kind==='pass-reserve-card'&&t.cardId==='b_101.webp');
  const postPick=assets(),end=save();
  restore(root);xs.forEach(act);assert.deepEqual(save(),end);
  branches.push({mode,prePass,passRoot,postPick,end,actions:xs});
  console.log(JSON.stringify({mode,prePass:[prePass.wallet.score,prePass.wallet.availableData,prePass.computer],
   postPick:[postPick.round,postPick.wallet.score,postPick.wallet.credits,postPick.wallet.energy,postPick.wallet.availableData,postPick.computer],hand:postPick.hand}));
 }
 const end=save();
 restore(origin);accepted.forEach(act);assert.deepEqual(save(),milestones.at(-1).end);restore(origin);
 fs.writeFileSync(out,JSON.stringify({scope:'Actual V445 second-round tail. Same PASS choice, vary only whether to fill computer and use the last second-round main on analysis.',source:origin,milestones,branches,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
