'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[source,out]=process.argv.slice(2),rowsIn=read(source).rows,root=rowsIn.find(r=>r.goal==='funding-prefix-14').end,seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{const v=c.lifecycle.restore(e);assert(v.ok,JSON.stringify(v));assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}










const pk=load('randomizer/game/production-kernel'),rd=load('randomizer/game/ai/resource-demand'),deck=load('randomizer/game/cards/deck'),effects=load('randomizer/game/cards/effects');
const pick=(predicate)=>menu().find(predicate);
const choose=(family,predicate=()=>true)=>pick(a=>a.family===family&&predicate(a));
function fixed(move,payerId){
 restore(root);const start=assets(),acts=[execute(move)];
 const payment=choose('choose_payment',a=>a.target.cardIds?.length===1&&a.target.cardIds[0]===payerId);
 if(!payment)return {stop:'payment-missing',acts};
 acts.push(execute(payment));
 const afterMove=assets(),payer=player().hand.find(c=>deck.getDiscardActionRewardForCard(c)?.gain?.publicity===1);
 const corner=choose('card_corner',a=>a.target.cardInstanceId===payer?.id);
 if(!corner)return {stop:'no-publicity-corner',acts,afterMove};
 acts.push(execute(corner));
 const beforeResearch=assets(),begin=choose('research_tech');
 if(!begin)return {stop:'insufficient-publicity',acts,afterMove,beforeResearch};
 acts.push(execute(begin));
 const tile=choose('choose_target',a=>a.target.tileId==='blue1'&&a.target.blueSlot===3);
 assert(tile);acts.push(execute(tile));
 const blue=()=>choose('choose_target',a=>a.target.target==='blueBonus'&&a.target.blueSlot===3);
 acts.push(execute(choose('place_data')),execute(blue()),execute(choose('end_turn')));
 const end=save(),after=assets(),s=state();
 const candidates=()=>pk.getProbeRouteRequirements(s,seat)?.candidates||[];
 const route=rd.heldLandingGoal({state:s,seatId:seat,candidates,compareTiming:()=>{throw Error('timing not expected');}});
 restore(root);acts.forEach(execute);assert.deepEqual(save(),end);
 return {stop:'funded',acts,afterMove,beforeResearch,after,route,end};
}
try {
 restore(root);
 const moves=menu().filter(a=>a.family==='move'),p=player(),model=effects.getCardModel;
 const plain=p.hand.find(c=>model(c)?.playEffects?.length===1&&model(c).playEffects[0].type==='chong_probe_planet_fossil_reward');
 assert(plain);
 const rows=moves.map(move=>({mode:'direction',summary:move.summary,payer:plain.cardId,...fixed(move,plain.id)}));
 const funded=rows.filter(r=>r.route?.embeddedMove);
 assert.equal(funded.length,1);
 const selected=moves.find(m=>m.summary===funded[0].summary);
 restore(root);execute(selected);
 const payers=menu().filter(a=>a.family==='choose_payment'&&a.target.cardIds?.length===1).map(a=>a.target.cardIds[0]);
 restore(root);
 const cards=new Map(player().hand.map(c=>[c.id,c.cardId]));
 for(const id of payers.filter(id=>id!==plain.id)){
  rows.push({mode:'payment',summary:selected.summary,payer:cards.get(id),...fixed(selected,id)});
 }
 restore(root);
 fs.writeFileSync(out,JSON.stringify({scope:'Same R3 root; compare exact four current directions with one fixed payer, then payment identities only on the sole funded direction. No opponent or hidden reward estimates.',rootHash:hash(root),rows},null,2)+'\n',{flag:'wx'});
 for(const r of rows)console.log(JSON.stringify([r.mode,r.summary,r.payer,r.stop,r.afterMove?.wallet.publicity,r.afterMove?.wallet.score,r.route?.id]));
} finally {c.dispose();}
