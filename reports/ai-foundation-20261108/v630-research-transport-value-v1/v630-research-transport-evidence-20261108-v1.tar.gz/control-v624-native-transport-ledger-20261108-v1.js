'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[source,out]=process.argv.slice(2),rowsIn=read(source).rows,root=rowsIn.find(r=>r.goal==='blue1').end,seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{const v=c.lifecycle.restore(e);assert(v.ok,JSON.stringify(v));assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}










const value=load('randomizer/game/ai/state-value'),pk=load('randomizer/game/production-kernel');
const accepted=read(path.join(path.dirname(source),'v623-blue1-tech-autonomy-20261108-v1.json')).row.accepted.slice(0,14).map(x=>x.action);
const pick=(predicate)=>{const a=menu().find(predicate);assert(a);return a;};
function snapshot(label){
 const s=state(),p=player(),v=view(),q=value.evaluateStateValue(v,seat),rewards=(pk.getProbeRouteRequirements(s,seat)?.candidates||[]).filter(a=>a.rocketId===6&&a.planetId==='saturn'&&a.endpointFamily==='land'&&a.endpointTarget?.type==='planet');
 return {label,total:q.total,parts:q.components,wallet:p.resources,phase:c.inspect().session?.decision?.kind||null,
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),
  choices:c.inspect().session?.decision?.choices?.map(a=>a.summary)||[],routes:rewards.map(a=>({route:a.requirementId,cost:a.required,benefit:a.targetBenefit,rewards:a.endpointFacts.rewards}))};
}
try{
 const rows=[];
 restore(root);rows.push(snapshot('blue1:after-research'));
 for(const [i,a] of accepted.entries()){execute(a);rows.push(snapshot('blue1:'+String(i+1)+':'+a.summary));}
 const endpoint=save();
 restore(root);for(const a of accepted)execute(a);assert.deepEqual(save(),endpoint);
 for(const id of ['orange3','blue4']){
  restore(rowsIn.find(r=>r.goal===id).end);
  rows.push(snapshot(id+':after-research'));
  execute(pick(a=>a.family==='end_turn'));rows.push(snapshot(id+':after-end'));
 }
 restore(root);execute(pick(a=>a.family==='end_turn'));rows.push(snapshot('blue1:without-cash'));
 restore(root);
 fs.writeFileSync(out,JSON.stringify({scope:'Exact Native fixed transport prefix and blind-reward-free public score; comparison of alternative technology wallets.',rows},null,2)+'\n',{flag:'wx'});
 for(const x of rows)console.log(JSON.stringify([x.label,x.total,x.parts.realizedScore,x.parts.currentEndGameBonus,x.parts.probePotential,x.parts.analysisPotential,x.wallet.credits,x.wallet.energy,x.wallet.availableData,x.wallet.handSize,x.wallet.publicity]));
}finally{c.dispose();}
