'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[source,out]=process.argv.slice(2),rowsIn=read(source).rows,root=rowsIn.find(r=>r.goal==='funding-prefix-17').end,seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{const v=c.lifecycle.restore(e);assert(v.ok,JSON.stringify(v));assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}










const menuSample=read(path.join(path.dirname(source),'v622-before-blue1-menu-20261108-v1.json')).rows[0].end;
function decide(e){
 restore(e); const legal=menu(),p=createAnalysisPort({composition:c,seatId:seat,maxCacheEntries:0});
 try{
  const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:legal}).search;
  assert(q.complete&&!q.unresolved.length&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600);
  assert.deepEqual(save(),e);
  return {n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,selected:legal.find(a=>a.actionId===q.actionId).summary,
    roots:q.roots,quote:q.lines.flatMap(r=>r.knownResearchTransport?[r.knownResearchTransport]:[]),
    graph:q.lines.map(r=>JSON.parse(JSON.stringify(r,(k,v)=>/milliseconds/i.test(k)?undefined:v)))};
 }finally{p.close();}
}
try {
 const funded=rowsIn.find(r=>r.goal==='funding-prefix-16').end;
 const movement=rowsIn.find(r=>r.goal==='funding-prefix-14').end;
 restore(movement);const move=menu().find(a=>a.family==='move'&&a.target.deltaY===1);assert(move);
 execute(move);const pay=save();restore(root);
 const mutate=(e,fn)=>{const m=structuredClone(e),s=JSON.parse(e.committedState);fn(s,s.players.players.find(p=>p.id===seat));m.committedState=JSON.stringify(s);return m;};
 const hidden=mutate(root,(s,p)=>{
  const q=s.tech.stacks.blue1.bonusQueue;[q[1],q[2]]=[q[2],q[1]];
  const pile=s.cards.drawPileCardIds;[pile[0],pile[1]]=[pile[1],pile[0]];
  const x=s.aliens.chong, j=x.planetFossilIds.jupiter,t=x.planetFossilIds.saturn, j0=j[0],t0=t[0];
  assert.deepEqual(x.fossilsById[j0].visibleToPlayerIds,[]);assert.deepEqual(x.fossilsById[t0].visibleToPlayerIds,[]);
  j[0]=t0;t[0]=j0;x.fossilsById[j0].planetId='saturn';x.fossilsById[t0].planetId='jupiter';
  x.initialConfiguration.fossilOrder=x.initialConfiguration.fossilOrder.map(id=>id===j0?t0:id===t0?j0:id);
 });
 const strip=(s,p,cardId)=>{p.hand=p.hand.filter(c=>c.cardId!==cardId);p.resources.handSize=p.hand.length;};
 const rows=[
  ['root',root,true,'研究科技'],['paid-choice',menuSample,true,'研究 blue1（蓝槽 3）'],['one-publicity',funded,true,'dlc_25.png：弃牌角标'],
  ['hidden',hidden,true,'研究科技'],['no-supplier',mutate(root,(s,p)=>strip(s,p,'chong_3.webp')),false],
  ['no-transport-payer',mutate(root,(s,p)=>strip(s,p,'dlc_20.png')),false],
  ['no-publicity-payer',mutate(funded,(s,p)=>strip(s,p,'dlc_25.png')),false],
  ['paid-move',pay,true,'弃 1 张移动牌'],['prepare-with-move',movement,true,'移动探测器 6 向外'],
  ['no-prepay-card',mutate(movement,(s,p)=>strip(s,p,'chong_2.webp')),false],
  ['other-active',mutate(root,s=>{s.turn.passedPlayerIds=s.turn.passedPlayerIds.filter(id=>id!=='player-green');}),false]
 ].map(([label,e,wants,selected])=>{
  const q=decide(e);assert.equal(Boolean(q.quote.length),wants,label);if(selected)assert.equal(q.selected,selected,label);
  if(wants)assert(q.quote.every(v=>v.value===6.5&&v.landingScore===8&&v.landData===2&&v.movePublicity===1));
  if(label==='paid-move'){restore(e);const chosen=menu().find(a=>a.actionId===q.roots.find(x=>x.value===168.5)?.actionId);assert.deepEqual(chosen?.target.cardIds,['alien-chong-2-6']);}
  return {label,q};
 });
 const [a,b]=[rows[0].q,rows[3].q];
 assert.deepEqual([a.n,a.roots,a.quote,a.graph],[b.n,b.roots,b.quote,b.graph]);
 restore(root);
 fs.writeFileSync(out,JSON.stringify({scope:'Native transport quote cold roots; private permutations preserve all graph and ranking fields except timing.',rows},null,2)+'\n',{flag:'wx'});
 for(const {label,q} of rows) console.log(JSON.stringify([label,q.selected,q.n,q.ms,q.quote.length]));
} finally {c.dispose();}
