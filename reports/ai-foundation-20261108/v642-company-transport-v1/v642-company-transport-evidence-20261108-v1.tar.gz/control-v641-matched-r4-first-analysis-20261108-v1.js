'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[source,out,...comparisons]=process.argv.slice(2),root=read(source).end,seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}








function branch(file){
 const e=read(file).end;restore(e);const before=assets(),accepted=[];
 function take(f,p=()=>true){const a=menu().find(a=>a.family===f&&p(a.target,a));assert(a,JSON.stringify({f,menu:menu().map(a=>[a.family,a.summary,a.target])}));accepted.push(execute(a));return a;}
 const card=id=>player().hand.find(c=>c.cardId===id)?.id;
 if(before.computer.length===2){
  const incoming=state().cards.publicCards.find(c=>c.cardId==='dlc_15.png');
  assert(incoming&&card('b_9.webp'));
  take('industry',t=>t.abilityId==='deepspace_swap_cards');
  take('choose_card',t=>t.cardInstanceId===card('b_9.webp'));
  take('choose_card',t=>t.cardInstanceId===incoming.id);
  take('card_corner',t=>t.cardInstanceId===card('dlc_15.png'));
 }
 take('card_corner',t=>t.cardInstanceId===card('b_111.webp'));
 for(let i=before.computer.length;i<6;i++){
  take('place_data');
  if(save().session&&menu().some(a=>a.target?.target==='computer'))take('choose_target',t=>t.target==='computer');
  if(i===3)take('choose_card',t=>t.cardInstanceId===card('dlc_14.png'));
 }
 const beforeAnalyze=assets();assert(beforeAnalyze.computer.length===6&&beforeAnalyze.income.energy===4);
 take('analyze');
 const picks=menu().map(a=>[a.summary,a.target]);
 const a=menu().find(a=>a.target?.speciesId==='chong'&&a.target?.traceType==='blue'&&a.target?.position===8);
 const target=a||menu().find(a=>a.target?.speciesId==='amiba'&&a.target?.traceType==='blue'&&a.target?.position===3);
 assert(target,JSON.stringify(picks));take('choose_target',t=>t.choiceId===target.target.choiceId);
 if(save().session)take('choose_card',t=>t.source==='display');
 const after=assets(),end=save();
 restore(e);accepted.forEach(execute);assert.deepEqual(save(),end);restore(e);
 return {file,before,beforeAnalyze,after,picks,accepted,end,replayExact:true};
}
try{
 const rows=[source,...comparisons].map(branch);
 assert.equal(new Set(rows.map(r=>r.after.wallet.score)).size,1);
 assert.equal(new Set(rows.map(r=>r.after.realized)).size,1);
 restore(root);
 fs.writeFileSync(out,JSON.stringify({scope:'Matched first R4 analyze and permanent +1 energy income after the same fossil delivery; use only available cards, all differences retained.',rows},null,2)+'\n',{flag:'wx'});
 for(const r of rows)console.log(JSON.stringify({file:path.basename(r.file),steps:r.accepted.length,score:r.after.wallet.score,realized:r.after.realized,money:r.after.wallet.credits,energy:r.after.wallet.energy,income:r.after.income,hand:r.after.hand.map(x=>x[1]),data:r.after.wallet.availableData,choices:r.accepted.slice(-3).map(a=>a.summary)}));
}finally{c.dispose();}
