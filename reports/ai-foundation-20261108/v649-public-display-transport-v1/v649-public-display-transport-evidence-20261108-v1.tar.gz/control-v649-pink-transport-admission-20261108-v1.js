'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[source,out]=process.argv.slice(2),rowsIn=read(source).rows,root=rowsIn.find(r=>r.goal==='a0-prefix-38').end,seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{const v=c.lifecycle.restore(e);assert(v.ok,JSON.stringify(v));assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}










const clean=x=>JSON.parse(JSON.stringify(x,(k,v)=>/milliseconds/i.test(k)?undefined:v));
function run(e){
 restore(e);
 const actions=menu(),port=createAnalysisPort({composition:c,seatId:seat,maxCacheEntries:0});
 try{
  const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:actions}).search;
  assert(q.complete&&!q.unresolved.length&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600);
  assert.deepEqual(save(),e);
  return {action:actions.find(a=>a.actionId===q.actionId),value:q.value,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,
    roots:clean(q.roots),lines:clean(q.lines),quotes:q.lines.flatMap(l=>l.knownDisplayedTransport?[l.knownDisplayedTransport]:[])};
 }finally{port.close();}
}
function mutate(envelope,fn){
 const e=structuredClone(envelope),s=JSON.parse(e.committedState);
 for(const state of [s,e.session?.session?.workingState,e.session?.session?.baseState].filter(Boolean))fn(state,state.players.players.find(p=>p.id===seat));
 e.committedState=JSON.stringify(s);return e;
}
try{
 const rows=[],measure=(label,e)=>{const q=run(e);rows.push({label,q});return q;};
 const normal=measure('pink',root);assert.equal(normal.value,163);assert.equal(normal.action.target.speciesId,'chong');assert.equal(normal.action.target.position,4);
 assert(normal.quotes.length===2&&normal.quotes.every(q=>q.gain===5&&q.competing===6.5&&q.route.value===11.5&&q.paymentCardId==='card-62-0'));
 const publicChoices=read(source).rows.find(r=>r.goal==='a0-prefix-37');
 const scanMenu=measure('scan-menu',publicChoices.end);assert.equal(scanMenu.value,163);assert.equal(scanMenu.action.target.nebulaId,'sector-3-a');
 const hidden=measure('hidden',mutate(root,s=>{
  const deck=s.cards.drawPileCardIds;[deck[0],deck[1]]=[deck[1],deck[0]];
  const a=s.aliens.chong,b=a.cardDeck,k=a.initialConfiguration.cardDeck.length-b.length;
  [b[0],b[1]]=[b[1],b[0]];a.initialConfiguration.cardDeck=[...a.initialConfiguration.cardDeck.slice(0,k),...b];
  const queue=s.tech.stacks.blue1.bonusQueue;[queue[1],queue[2]]=[queue[2],queue[1]];
  const j=a.planetFossilIds.jupiter,t=a.planetFossilIds.saturn,j0=j[0],t0=t[0];
  assert.deepEqual(a.fossilsById[j0].visibleToPlayerIds,[]);assert.deepEqual(a.fossilsById[t0].visibleToPlayerIds,[]);
  j[0]=t0;t[0]=j0;a.fossilsById[j0].planetId='saturn';a.fossilsById[t0].planetId='jupiter';
  a.initialConfiguration.fossilOrder=a.initialConfiguration.fossilOrder.map(id=>id===j0?t0:id===t0?j0:id);
 }));
 assert.deepEqual([hidden.action,hidden.n,hidden.roots,hidden.lines],[normal.action,normal.n,normal.roots,normal.lines]);
 for(const [label,change] of [
  ['missing-market-payer',s=>{s.cards.publicCards[1]=null;}],
  ['no-data',(_s,p)=>{if(p.dataState.poolTokens.length){p.dataState.poolTokens.pop();p.resources.availableData--;}}],
  ['another-seat-active',s=>{s.turn.passedPlayerIds=s.turn.passedPlayerIds.filter(id=>id!=='player-green');}],
  ['different-visible-display',s=>{const a=s.aliens.chong,b=a.cardDeck,k=a.initialConfiguration.cardDeck.length-b.length;
    const current=a.displayedCardIndex;assert.equal(current,3);a.displayedCardIndex=b[0];b[0]=current;
    a.initialConfiguration.cardDeck=[...a.initialConfiguration.cardDeck.slice(0,k-1),a.displayedCardIndex,...b];}]
 ])assert.equal(measure(label,mutate(root,change)).quotes.length,0,label);
 restore(root);
 fs.writeFileSync(out,JSON.stringify({scope:'Native trace decision; simultaneous private deck, technology and fossil permutations; unfunded public counterexamples.',rows},null,2)+'\n',{flag:'wx'});
 for(const {label,q} of rows)console.log(JSON.stringify([label,q.action.summary,q.value,q.n,q.ms,q.quotes.length]));
}finally{c.dispose();}
