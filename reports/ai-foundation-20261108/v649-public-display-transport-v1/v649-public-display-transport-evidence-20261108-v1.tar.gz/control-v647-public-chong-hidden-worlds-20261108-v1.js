'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[source,out]=process.argv.slice(2),rowsIn=read(source).rows,root=rowsIn.find(r=>r.goal==='a0-prefix-38').end,seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{const v=c.lifecycle.restore(e);assert(v.ok,JSON.stringify(v));assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}










const rules=load('randomizer/game/rule-composition'),contract=load('randomizer/app/simulation-contract');
function rotateHidden(e){
 const envelope=structuredClone(e),committed=JSON.parse(envelope.committedState);
 for(const s of [committed,envelope.session?.session?.workingState,envelope.session?.session?.baseState].filter(Boolean)){
  const a=s.aliens.chong,b=a.cardDeck;assert(b.length>=2);
  const k=a.initialConfiguration.cardDeck.length-b.length;
  [b[0],b[1]]=[b[1],b[0]];a.initialConfiguration.cardDeck=[...a.initialConfiguration.cardDeck.slice(0,k),...b];
 }
 envelope.committedState=JSON.stringify(committed);return envelope;
}
function check(e){
 restore(e);const p=createAnalysisPort({composition:c,seatId:seat,maxCacheEntries:0});
 try{
  p.setResourcePlanning(true);p.setMovementPlanning(true);p.setCardPickPlanning(true);
  p.setDecisionPlanning({finalMarkPlanning:true,scanPlanning:true});
  const r=p.openRoot(),v=r.observation,offer=v.publicState.board.aliens.chongOffer;
  assert.deepEqual(offer,{slotId:2,displayedCardIndex:3});
  const next=p.expand(r,r.legalActions.find(a=>a.target.speciesId==='chong'&&a.target.position===4).actionId);
  const selected=next.legalActions.find(a=>a.target.choiceId==='chong:display:3');
  const blind=next.legalActions.find(a=>a.target.choiceId==='chong:blind');
  assert(selected&&blind);
  const picked=p.expand(next,selected.actionId),unknown=p.expand(next,blind.actionId);
  assert(picked.observation.selfState.hand.some(c=>c.cardId==='chong_3.webp'&&c.id));
  assert.deepEqual(picked.observation.publicState.board.aliens.chongOffer,{slotId:2,displayedCardIndex:null});
  assert(!unknown.observation.selfState.hand.some(c=>c.cardId==='chong_3.webp'));
  assert(unknown.observation.selfState.hand.some(c=>c.hidden&&!c.cardId));
  assert.deepEqual(unknown.observation.publicState.board.aliens.chongOffer,offer);
  const raw=structuredClone(state().aliens);raw.aliens['2'].revealed=false;
  assert(!Object.hasOwn(contract.sanitizeAlienPublicState(raw),'chongOffer'));
  const without=structuredClone(v);without.publicState.board.aliens.slots[1].revealed=false;without.publicState.board.aliens.chongOffer=null;
  assert.equal(rules.sanitizeHiddenInformationObservation(without,v,{code:'alien_reveal'}).publicState.board.aliens.chongOffer,null);
  assert.deepEqual(save(),e);
  return {pickedHand:picked.observation.selfState.hand,afterPick:picked.observation.publicState.board.aliens.chongOffer,
   blindHand:unknown.observation.selfState.hand,afterBlind:unknown.observation.publicState.board.aliens.chongOffer};
 }finally{p.close();}
}
try{
 const original=check(root),hidden=check(rotateHidden(root));assert.deepEqual(hidden,original);
 fs.writeFileSync(out,JSON.stringify({scope:'Root-known Chong display and its acquired Native instance only. Hidden blind/refill and unrevealed species absent.',original,hidden},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({actualKnownCard:original.pickedHand.find(c=>c.cardId==='chong_3.webp')?.id,afterPick:original.afterPick,blindOpaque:true,unrevealedNoOffer:true,rootUnchanged:true}));
}finally{c.dispose();}
