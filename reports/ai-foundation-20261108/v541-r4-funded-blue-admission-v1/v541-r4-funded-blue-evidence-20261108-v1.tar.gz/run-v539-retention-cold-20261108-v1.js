'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=f=>require(path.resolve(f));
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const [archive,out,index,trace]=process.argv.slice(2),a=JSON.parse(fs.readFileSync(archive)),row=a.rows[Number(index)],seat='player-white',seed=JSON.parse(row.root.committedState).meta.seed;
if(trace)process.env.SETI_V539_TRACE=trace;
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition;assert(c.lifecycle.restore(row.root).ok);assert.deepEqual(c.lifecycle.save().envelope,row.root);
const p=createAnalysisPort({composition:c,seatId:seat,maxCacheEntries:0}),agent=createSearchAgent({seatId:seat,analysisPort:p});
try{
 const legalActions=c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
 const selected=agent.decide({seatId:seat,legalActions});
 const q=selected.search;assert.deepEqual(c.lifecycle.save().envelope,row.root);
 const norm=q.roots.map(x=>[x.actionId,x.value,x.realization===0?0:x.realization]);
 assert.deepEqual(norm,row.firstSearch.roots.map(x=>[x.actionId,x.value,x.realization===0?0:x.realization]));
 assert.equal(q.actionId,row.firstSearch.actionId);assert.equal(q.value,row.firstSearch.value);
 assert(q.complete&&!q.unresolved.length);
 const graph={rootSha256:crypto.createHash('sha256').update(JSON.stringify(row.root)).digest('hex'),label:row.label,legalActions,search:q};
 fs.writeFileSync(out,z.gzipSync(JSON.stringify(graph)+'\n'),{flag:'wx'});
 console.log(JSON.stringify({label:row.label,value:q.value,native:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,tail:q.diagnostics.provedTurnTailInputs,complete:q.complete,selected:legalActions.find(a=>a.actionId===q.actionId)?.summary}));
}finally{p.close();c.dispose();}
