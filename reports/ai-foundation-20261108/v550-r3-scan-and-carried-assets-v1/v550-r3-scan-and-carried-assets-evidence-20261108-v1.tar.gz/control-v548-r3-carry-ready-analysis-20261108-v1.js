'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const [archiveRoot,recordPath,openingPath,out]=process.argv.slice(2),arch=p=>path.resolve(archiveRoot,p);
const r=read(arch(recordPath)),source=read(arch(r.savePath)),opening=read(arch(openingPath)),seat='player-white',seed=r.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random'),{buildRuleObservation}=load('randomizer/app/rule-observation');
const {passiveAgent}=load('tools/research-human405-round1'),pc=load('randomizer/game/ai/probe-capital'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const view=(id=seat)=>c.projection({role:'player',playerId:id}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,board:p.resources.score,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).length,blue:p.dataState.placedTokens.filter(t=>t.placementKind==='blueBonus').length,
  probes:s.pieces.rockets.filter(x=>x.playerId===seat),traces:v.selfState.traceCounts,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>[x.id,x.cardId])};
}
try{
 const start=read(arch(opening.checkpointPath));assert.equal(start.replayCursor.stepIndex,23);
 assert.equal(crypto.createHash('sha256').update(fs.readFileSync(arch(opening.checkpointPath))).digest('hex'),opening.checkpointSha256);
 restore(start.coreState.compositionEnvelope);
 for(const x of source.replaySteps.slice(23,241))execute(x.action);
 assert.equal(state().turn.roundNumber,3);assert.equal(state().turn.turnNumber,15);
 assert.equal(source.replaySteps[241].action.family,'analyze');
 const origin=save(),r3Asset=assets(),legals=menu(),actions=[];
 const take=a=>{const b=execute(a);actions.push(b);return b;};
 const choose=(f,p=()=>true)=>{const a=menu().find(a=>a.family===f&&p(a.target,a));assert(a,JSON.stringify({f,menu:menu().map(a=>[a.family,a.summary,a.target])}));return take(a);};
 const waitWhite=()=>{
  for(let n=0;state().turn.currentPlayerId!==seat||save().session;n++){
   assert(n<25);const list=menu(),actor=list[0]?.actorId;
   assert(actor&&actor!==seat&&list.every(x=>x.actorId===actor));
   const {actionId}=passiveAgent(actor).decide({legalActions:list,observation:view(actor)});
   take(list.find(a=>a.actionId===actionId));
  }
 };
 choose('pass');choose('choose_card',t=>t.choiceId==='card-30-pass-3-1');
 waitWhite();
 const end=save(),after=assets();
 restore(origin);actions.forEach(execute);assert.deepEqual(save(),end);restore(origin);
 fs.writeFileSync(out,JSON.stringify({scope:'Before actual R3 input 242: use legal PASS rather than final analysis, preserve filled computer and hand; same reserve and passive policy through first R4 white main.',origin,originHash:hash(origin),r3Asset,legals,actions,end,after,replayExact:true},null,2)+'\n',{flag:'wx'});
 for(const a of [r3Asset,after])console.log(JSON.stringify({wallet:a.wallet,hand:a.hand.map(x=>x[1]),income:a.income,computer:a.computer,blue:a.blue,probe:a.probes.map(p=>[p.sectorX,p.sectorY]),score:a.realized,turn:a.turn}));
}finally{c.dispose();}
