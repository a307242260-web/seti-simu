'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const [repo,out,only]=process.argv.slice(2),arch=p=>path.resolve(repo,p);
const record=read(arch('reports/research/cf2d3b6a.a5cf6a37.quick-400.json')),source=read(arch(record.savePath)),opening=read(arch('reports/ai-foundation-20261023/human405-white-only-opening-20261030-v1.json')),seat='player-white',seed=record.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}
function fixedTech(origin,tileId){
 restore(origin);const start=assets(),a=menu().find(x=>x.family==='choose_target'&&x.target?.tileId===tileId);assert(a,tileId);
 const fixed=execute(a),fixedEnvelope=save(),afterFixed=assets(),accepted=[],stages=[],coldRoots=[];
 let checkpoint,stop;
 for(let i=0;i<135;i++){
  const e=save(),s=state(),actions=menu();assert.equal(s.turn.roundNumber,3);assert(s.turn.currentPlayerId===seat&&actions.every(a=>a.actorId===seat));
  const port=createAnalysisPort({composition:c,seatId:seat,maxCacheEntries:0});
  try{
   const agent=createSearchAgent({seatId:seat,analysisPort:port});if(checkpoint)agent.loadCheckpoint(checkpoint);
   const r=agent.decide({seatId:seat,legalActions:actions}),q=r.search,chosen=actions.find(x=>x.actionId===q.actionId);
   const n=q.diagnostics.nativeExecutions,ms=q.rootAndSearchMilliseconds;
   assert.deepEqual(save(),e);
   const over=!q.complete||q.unresolved.length||n>256||ms>600;
   if(over||['scan','research_tech','play_card','analyze','land','pass'].includes(chosen?.family)&&!e.session){
    coldRoots.push({index:i+1,action:chosen,asset:assets(),before:e,n,ms,value:q.value,diagnostics:q.diagnostics,
     roots:q.roots.map(r=>[actions.find(a=>a.actionId===r.actionId)?.summary,r.value,r.realization,r.completion])});
   }
   if(over){stop={reason:'gate',n,ms,selected:chosen?.summary,complete:q.complete};break;}
   assert(chosen);
   if(chosen.family==='pass'){stop={reason:'settled-before-pass',n,ms};break;}
   checkpoint=structuredClone(agent.createCheckpoint());
   const input=execute(chosen);
   accepted.push({action:input,n,ms,value:q.value});
   if(input.family==='end_turn'&&!save().session)stages.push({input:i+1,asset:assets(),checkpoint:save()});
  }finally{port.close();}
 }
 assert(stop);
 const end=save(),after=assets();
 restore(origin);execute(fixed);accepted.forEach(r=>execute(r.action));assert.deepEqual(save(),end);restore(origin);
 return {tileId,start,fixed,fixedEnvelope,afterFixed,accepted,stages,coldRoots,stop,after,end,replayExact:true};
}
try{
 const start=read(arch(opening.checkpointPath));assert.equal(start.replayCursor.stepIndex,23);
 assert.equal(crypto.createHash('sha256').update(fs.readFileSync(arch(opening.checkpointPath))).digest('hex'),opening.checkpointSha256);
 restore(start.coreState.compositionEnvelope);
 for(const x of source.replaySteps.slice(23,193))execute(x.action);
 assert.equal(source.replaySteps[193].action.target.tileId,'purple1');
 assert.equal(state().turn.roundNumber,3);assert.equal(state().turn.passedPlayerIds.length,3);
 const origin=save(),legal=menu(),rows=[];
 for(const tile of only?[only]:['purple2','orange4','orange2']){
  const row=fixedTech(origin,tile);rows.push(row);
  const a=row.after;console.log(JSON.stringify({tile,stop:row.stop,inputs:row.accepted.length,maxN:Math.max(row.stop.n,...row.accepted.map(x=>x.n)),maxMs:Math.max(row.stop.ms,...row.accepted.map(x=>x.ms)),
   wallet:a.wallet,income:a.income,tech:Object.keys(a.tech.ownedTiles),hand:a.hand.map(h=>h[1]),computer:a.computer,blue:a.blue,probes:a.probes.map(r=>[r.id,r.sectorX,r.sectorY,r.fossilId]),realized:a.realized,
   trace:a.traceCounts,main:row.coldRoots.map(x=>x.action?.summary)}));
 }
 const baseline=record.roundEnds.at(-1);
 fs.writeFileSync(out,JSON.stringify({scope:'One intervention on exact V541 input 194 (research tile only); production controls the remainder of R3. No official rerun or PASS card/income.',origin,originHash:hash(origin),legal,baseline,rows},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
