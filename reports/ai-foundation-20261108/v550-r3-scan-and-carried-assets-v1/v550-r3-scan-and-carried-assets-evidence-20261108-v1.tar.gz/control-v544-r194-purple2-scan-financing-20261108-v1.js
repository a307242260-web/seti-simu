'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const [source,out]=process.argv.slice(2),ref=read(source),seat='player-white',seed=JSON.parse(ref.origin.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation');
const data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=()=>c.projection({role:'player',playerId:seat}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,JSON.stringify(w));assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
const recorded=[],stages={};
const available=()=>menu().map(a=>[a.family,a.summary,a.target]);
function act(f,p=()=>true){
 const a=menu().find(a=>a.family===f&&p(a.target,a));assert(a,JSON.stringify({f,menu:available()}));const b=execute(a);recorded.push(b);return b;
}
const pcard=id=>player().hand.find(c=>c.cardId===id);
const place=(blue=0)=>{
 act('place_data');
 act('choose_target',t=>blue?t.target==='blueBonus'&&t.blueSlot===blue:t.target==='computer');
 if(save().session&&menu().some(x=>x.target?.choiceId?.startsWith('income:')))act('choose_card',t=>t.cardInstanceId===pcard('amiba_1.webp')?.id);
};
function assets(){
 const p=player(),s=state(),o=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],traceCounts:o.selfState.traceCounts,knownMarket:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),
  realized:o.publicState.players.find(x=>x.playerId===seat).finalScore,round:s.turn.roundNumber,turn:s.turn.turnNumber};
}
function end(){act('end_turn');assert.equal(save().session,null);}
function snap(label){stages[label]={input:recorded.length,asset:assets(),envelope:save()};}
function replay(origin,actions,expected){restore(origin);actions.forEach(execute);assert.deepEqual(save(),expected);restore(origin);}
try{
 restore(ref.origin);
 act('choose_target',t=>t.tileId==='purple2');snap('after-research');
 place();place();place(1);snap('after-energy');
 // One fixed payment for the credit gap; preserve the known money income
 // source and the remaining alien play card. No further discard combinations.
 act('quick_trade',t=>t.tradeId==='cards-for-credit');
 for(const id of ['b_16.webp','amiba_7.webp']){
  const card=pcard(id);assert(card);act('choose_payment',t=>t.select&&t.cardInstanceId===card.id);
 }
 act('choose_payment',t=>t.confirm);end();snap('before-scan');
 const commonInputs=recorded.slice();
 act('scan');snap('main-scan-opened');
 const opt=menu().find(a=>a.family==='choose_target'&&a.target?.nebulaId==='sector-3-a')||menu().find(a=>a.family==='choose_target'&&a.target?.nebulaId);
 assert(opt,JSON.stringify(available()));act(opt.family,(t,a)=>a.actionId===opt.actionId);
 act('choose_card',t=>t.cardInstanceId==='card-61-0'&&t.nebulaId);snap('after-public-scan');
 for(let i=0;!menu().some(a=>a.target?.skip===true&&menu().some(x=>x.target?.nebulaId));i++){
  assert(i<9,JSON.stringify(available()));
  const x=menu().find(a=>a.target?.skip===true||a.target?.done===true||a.target?.mode==='skip');assert(x,JSON.stringify(available()));
  act(x.family,(t,a)=>a.actionId===x.actionId);
 }
 const sameScanPrefix=recorded.slice(),choiceRoot=save(),choiceMenu=available(),rows=[];
 for(const extra of [false,true]){
  restore(choiceRoot);recorded.length=0;
  const a=menu().find(a=>extra?a.target?.nebulaId:a.target?.skip===true);
  assert(a,JSON.stringify(available()));act(a.family,(t,x)=>x.actionId===a.actionId);
  for(let i=0;save().session;i++){
   assert(i<12,JSON.stringify(available()));const next=menu().find(a=>a.target?.stateExtra===true&&a.target?.alienSlotId===1)
    ||menu().find(a=>a.target?.choiceId?.startsWith('confirm:'))
    ||menu().find(a=>a.target?.skip||a.target?.done);
   assert(next,JSON.stringify(available()));act(next.family,(t,a)=>a.actionId===next.actionId);
  }
  const afterScan=assets(),postScanMenu=available();
  while(player().resources.availableData&&data.listComputerPlacedTokens(player()).length<4)place();
  end();const finish=assets(),endState=save(),actions=[...recorded];
  replay(choiceRoot,actions,endState);
  rows.push({extra,actions,afterScan,postScanMenu,finish,end:endState});
  console.log(JSON.stringify({extra,wallet:finish.wallet,income:finish.income,computer:finish.computer,blue:finish.blue,hand:finish.hand,afterScan:afterScan.wallet,probes:finish.probes.length,score:finish.realized}));
 }
 replay(ref.origin,sameScanPrefix,choiceRoot);
 fs.writeFileSync(out,JSON.stringify({scope:'Exact Purple 2 alternate research root. Compare common funded scan with or without its last optional Mercury signal, using only visible choices. No AI intervention or official repeat.',originHash:hash(ref.origin),stages,commonInputs,sameScanPrefix,choiceRoot,choiceMenu,rows,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
