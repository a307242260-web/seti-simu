'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const [repo,out]=process.argv.slice(2),read=p=>JSON.parse(fs.readFileSync(path.join(repo,p))),sha=p=>crypto.createHash('sha256').update(fs.readFileSync(path.join(repo,p))).digest('hex');
const t='reports/ai-foundation-20261105/third-round-teacher-v1/',src=t+'teacher-third-current-replay-20261105-v2.json',current=read(src);
const state=x=>({credits:x.player.resources.credits,energy:x.player.resources.energy,publicity:x.player.resources.publicity,data:x.player.resources.availableData,
 score:x.player.resources.score,hand:x.player.hand.map(c=>c.cardId),income:x.player.income,
 computer:x.player.dataState.placedTokens.filter(t=>t.placementKind==='computer').map(t=>t.placementSlot),
 blue:x.player.dataState.placedTokens.filter(t=>t.placementKind==='blueBonus').map(t=>t.blueSlot),
 probes:(x.probes||[]).map(p=>[p.id,p.sectorX,p.sectorY,p.fossilId||null])});
const ledger=current.rows.map(x=>({input:x.input??x.historicalInput,action:x.action,before:state(x.before),after:state(x.after)}));
const at=n=>ledger.find(r=>r.input===n);const window=(a,b)=>ledger.filter(x=>x.input>=a&&x.input<=b);
const scans=[[185,190],[202,208],[223,229]].map(([a,b])=>{
 const rows=window(a,b),moves=rows.filter(x=>x.action.target?.mode==='move');
 assert.equal(moves.length,1);
 return {start:a,end:b,resourcesBefore:at(a).before,resourcesAfter:at(b).after,
  dataGainDuringScan:at(b).after.data-at(a).before.data,probeMove:moves.map(x=>[x.before.probes,x.after.probes]),
  sectors:rows.filter(x=>x.action.target?.nebulaId).map(x=>x.action.target.nebulaId)};
});
assert.deepEqual(scans.map(s=>s.dataGainDuringScan),[4,4,3]);
assert.deepEqual(at(229).after.hand.filter(c=>!at(229).before.hand.includes(c)),['chong_3.webp']);
assert.equal(at(234).after.credits-at(234).before.credits,1);
assert.equal(at(235).before.credits-at(235).after.credits,1);
assert.equal(at(243).after.probes.at(-1)?.[3],'fossil_07');
const r='reports/research/cf2d3b6a.a5cf6a37.quick-400.json',rr=read(r),s=read(rr.savePath),raw=s.replaySteps;
const traces=fs.readFileSync(path.join(repo,rr.agentTracePath),'utf8').trim().split('\n').map(JSON.parse);
const before=n=>{const a=raw[n-1].action,x=traces.find(q=>q.actionId===a.actionId&&q.context.stateVersion===a.stateVersion&&q.context.decisionVersion===a.decisionVersion);assert(x);return x;};
const a=before(193),named=a.search.lines[0].edges.filter(x=>x.resourcePlan?.goal.kind==='research_tech').map(e=>[e.resourcePlan.goal.tileId,e.resourcePlan.goal.blueSlot??null,a.search.lines[e.target].value]);
assert.equal(named.find(q=>q[0]==='purple1')[2],166.5);assert.equal(named.find(q=>q[0]==='purple2')[2],157);
const wallet=n=>{const v=before(n).context.observation;return v.publicState.players.find(p=>p.playerId==='player-white');};
assert.equal(wallet(195).availableData-wallet(194).availableData,2);
fs.writeFileSync(out,JSON.stringify({teacherReplay:src,teacherReplaySha256:sha(src),teacherCheckpoint:current.roundEnd.checkpointPath,teacherCheckpointSha256:sha(current.roundEnd.checkpointPath),
 v541Record:r,v541RecordSha256:sha(r),v541Trace:rr.agentTracePath,v541TraceSha256:sha(rr.agentTracePath),scans,
 relevantTeacherRows:ledger.filter(x=>[194,199,200,207,208,219,221,226,228,229,231,234,235,237,238,239,240,241,242,243,244].includes(x.input)),
 v541ResearchRoot:{input:193,rankedTiles:named,afterPurple1Data:wallet(195).availableData,beforePurple1Data:wallet(194).availableData},
 v541BeforeFinalAnalysis:{input:242,assets:wallet(242)}},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({teacherScanData:scans.map(x=>x.dataGainDuringScan),blindTransportCard:'chong_3.webp',nativeResearchChoices:named.length}));
