'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const [source,out]=process.argv.slice(2),ref=read(source),seat='player-white',seed=JSON.parse(ref.end.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation');
const data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=()=>c.projection({role:'player',playerId:seat}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,JSON.stringify(w));assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
const recorded=[],stages={};
const available=()=>menu().map(a=>[a.family,a.summary,a.target]);
function act(f,p=()=>true){
 const a=menu().find(a=>a.family===f&&p(a.target,a));assert(a,JSON.stringify({f,menu:available()}));const b=execute(a);recorded.push(b);return b;
}
const pcard=id=>player().hand.find(c=>c.cardId===id);
const place=(blue=0)=>{
 act('place_data');
 act('choose_target',t=>blue?t.target==='blueBonus'&&t.blueSlot===blue:t.target==='computer');
 if(save().session&&menu().some(x=>x.target?.choiceId?.startsWith('income:')))act('choose_card',t=>t.cardInstanceId===pcard('amiba_1.webp')?.id);
};
function assets(){
 const p=player(),s=state(),o=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],traceCounts:o.selfState.traceCounts,knownMarket:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),
  realized:o.publicState.players.find(x=>x.playerId===seat).finalScore,round:s.turn.roundNumber,turn:s.turn.turnNumber};
}
function end(){act('end_turn');assert.equal(save().session,null);}
function snap(label){stages[label]={input:recorded.length,asset:assets(),envelope:save()};}
function replay(origin,actions,expected){restore(origin);actions.forEach(execute);assert.deepEqual(save(),expected);restore(origin);}
try{
 const origin=ref.stages['main-scan-opened'].envelope,rows=[];
 restore(origin);
 const sectors=menu().filter(a=>a.family==='choose_target'&&a.target?.nebulaId);
 assert(sectors.length>0&&sectors.length<=4);
 for(const sector of sectors){
  restore(origin);recorded.length=0;act(sector.family,(t,a)=>a.actionId===sector.actionId);
  const publicRoot=save(),visible=menu().filter(a=>a.family==='choose_card'&&a.target?.cardInstanceId==='card-61-0'&&a.target?.nebulaId);
  assert(visible.length>0&&visible.length<=3);
  for(const card of visible){
   restore(publicRoot);recorded.length=1;
   act(card.family,(t,a)=>a.actionId===card.actionId);
   const pc=load('randomizer/game/ai/probe-capital'),saturn=()=>pc.requirements(pc.factsFromState(state(),player())).find(g=>g.planetId==='saturn'&&g.endpointFamily==='land'&&g.requirementId.endsWith(':planet'));
   const notifications=[];
   for(let i=0;save().session;i++){
    assert(i<14,JSON.stringify(available()));const list=menu();
    const path=saturn()?.route.path,step=path?.[0];
    const a=step&&list.find(a=>a.target?.mode==='move'&&a.target.rocketId===6&&a.target.deltaX===step.deltaX&&a.target.deltaY===step.deltaY)
     ||list.find(a=>a.target?.traceType==='pink'&&a.target?.alienSlotId===2)
     ||list.find(a=>a.target?.source==='display'&&a.family==='choose_card')
     ||list.find(a=>a.target?.stateExtra===true&&a.target?.alienSlotId===1)
     ||list.find(a=>a.target?.choiceId?.startsWith('confirm:'))
     ||list.find(a=>a.target?.skip||a.target?.done||a.target?.mode==='skip');
    assert(a,JSON.stringify(available()));notifications.push([a.summary,list.map(q=>q.summary)]);act(a.family,(t,x)=>x.actionId===a.actionId);
   }
   const endState=save(),asset=assets(),actions=recorded.slice();replay(origin,actions,endState);
   rows.push({sector:sector.target.nebulaId,publicSector:card.target.nebulaId,actions,asset,notifications,end:endState});
   console.log(JSON.stringify({sector:sector.summary,public:card.summary,actions:actions.map(a=>a.summary),wallet:asset.wallet,trace:asset.traceCounts,score:asset.realized,probe:asset.probes.map(p=>[p.sectorX,p.sectorY]),hand:asset.hand.map(h=>h[1])}));
  }
 }
 fs.writeFileSync(out,JSON.stringify({scope:'Exact early Orange1 scan choice. Each legal base scan target and each place for the single already named public source. Only one destination-directed move; no external or AI search.',origin,rows,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
