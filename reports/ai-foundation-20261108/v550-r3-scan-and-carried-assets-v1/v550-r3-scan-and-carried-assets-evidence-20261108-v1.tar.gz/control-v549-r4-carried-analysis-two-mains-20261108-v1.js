'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const [source,out]=process.argv.slice(2),ref=read(source),seat='player-white',seed=JSON.parse(ref.end.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random'),{buildRuleObservation}=load('randomizer/app/rule-observation');
const {passiveAgent}=load('tools/research-human405-round1'),pc=load('randomizer/game/ai/probe-capital'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const view=(id=seat)=>c.projection({role:'player',playerId:id}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,board:p.resources.score,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).length,blue:p.dataState.placedTokens.filter(t=>t.placementKind==='blueBonus').length,
  probes:s.pieces.rockets.filter(x=>x.playerId===seat),traces:v.selfState.traceCounts,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>[x.id,x.cardId])};
}
function branch(origin,source){
 restore(origin);const accepted=[],stages={};let goal;
 const take=a=>{const b=execute(a);accepted.push(b);return b;};
 const pick=(f,p=()=>true)=>{const a=menu().find(a=>a.family===f&&p(a.target,a));assert(a,JSON.stringify({f,menu:menu().map(a=>[a.family,a.summary,a.target])}));return take(a);};
 const record=n=>{stages[n]={input:accepted.length,asset:assets(),envelope:save()};};
 const hand=id=>player().hand.find(c=>c.cardId===id);
 const endTurn=()=>{pick('end_turn');while(save().session)pick('accept_optional_effect',t=>t.choiceId?.startsWith('confirm:task:'));};
 const place=(blue=null)=>{
  pick('place_data');if(save().session)pick('choose_target',t=>blue?t.target==='blueBonus'&&t.blueSlot===blue:t.target==='computer');
  if(save().session)pick('choose_card',t=>t.choiceId?.startsWith('income:')&&t.cardInstanceId===hand('dlc_25.png')?.id);
 };
 const waitWhite=()=>{
  for(let n=0;state().turn.currentPlayerId!==seat||save().session;n++){
   assert(n<25);const list=menu(),actor=list[0]?.actorId;
   assert(actor&&actor!==seat&&list.every(a=>a.actorId===actor));
   const {actionId}=passiveAgent(actor).decide({legalActions:list,observation:view(actor)});
   take(list.find(a=>a.actionId===actionId));
  }
 };
 record('r4Start');
 pick('analyze');pick('choose_target',t=>t.speciesId==='amiba'&&t.traceType==='blue'&&t.position===3);
 pick('choose_card',t=>t.source==='display'&&t.cardIndex===2);record('afterAnalyze');
 if(source==='data'){
  assert.equal(player().resources.availableData,1);
  pick('card_corner',t=>t.cardInstanceId===hand('dlc_17.png')?.id);
  place();place(1);
 }
 endTurn();waitWhite();record('beforeLanding');
 goal=pc.requirements(pc.factsFromState(state(),player())).find(g=>g.planetId==='saturn'&&g.endpointFamily==='land'&&g.requirementId.endsWith(':planet'));assert(goal);
 const need=(goal.endpointFacts.cost.energy||0)+goal.route.cost;
 while(player().resources.energy<need)pick('quick_trade',t=>t.tradeId==='credits-for-energy');
 for(const m of goal.route.path){
  pick('move',t=>t.rocketId===6&&t.deltaX===m.deltaX&&t.deltaY===m.deltaY);
  pick('choose_payment',t=>t.kind==='move-payment'&&!t.cardIds.length);
 }
 pick('land',t=>!t.planetId||t.planetId==='saturn');
 if(save().session&&menu().some(a=>a.target?.planetId==='saturn'&&a.target?.actionType==='land'))
  pick('choose_target',t=>t.planetId==='saturn'&&t.landTarget?.type==='planet');
 pick('choose_target',t=>t.traceType==='yellow'&&t.stateExtra===true&&t.alienSlotId===1);
 if(save().session)pick('accept_optional_effect',t=>t.ruleId==='amiba0-yellow-data');
 record('afterLand');
 while(assets().computer<4&&player().resources.availableData)place();
 assert.equal(assets().computer,4);endTurn();waitWhite();record('r4BeforeThirdMain');
 const end=save();restore(origin);accepted.forEach(execute);assert.deepEqual(save(),end);restore(origin);
 return{source,accepted,stages,end,route:goal.route};
}
try{
 const rows=['cash','data'].map(x=>branch(ref.end,x));
 fs.writeFileSync(out,JSON.stringify({scope:'Same legal R4 first two main actions in the carry counterfactual (analyze first, Saturn second); compare money versus one already held data card to pay the known energy gap.',originHash:hash(ref.end),rows,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
 for(const r of rows)console.log(JSON.stringify({source:r.source,inputs:r.accepted.length,stages:Object.entries(r.stages).map(([k,{asset:a}])=>[k,a.board,a.realized,a.wallet.credits,a.wallet.energy,a.wallet.availableData,a.computer,a.blue,a.income.energy,a.hand.map(h=>h[1])])}));
}finally{c.dispose();}
