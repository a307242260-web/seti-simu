'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const [source,out]=process.argv.slice(2),ref=read(source),seat='player-white',seed=JSON.parse(ref.origin.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation');
const data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=()=>c.projection({role:'player',playerId:seat}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,JSON.stringify(w));assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
const recorded=[],stages={};
const available=()=>menu().map(a=>[a.family,a.summary,a.target]);
function act(f,p=()=>true){
 const a=menu().find(a=>a.family===f&&p(a.target,a));assert(a,JSON.stringify({f,menu:available()}));const b=execute(a);recorded.push(b);return b;
}
const pcard=id=>player().hand.find(c=>c.cardId===id);
const place=(blue=0)=>{
 act('place_data');
 act('choose_target',t=>blue?t.target==='blueBonus'&&t.blueSlot===blue:t.target==='computer');
 if(save().session&&menu().some(x=>x.target?.choiceId?.startsWith('income:')))act('choose_card',t=>t.cardInstanceId===pcard('amiba_1.webp')?.id);
};
function assets(){
 const p=player(),s=state(),o=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],traceCounts:o.selfState.traceCounts,knownMarket:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),
  realized:o.publicState.players.find(x=>x.playerId===seat).finalScore,round:s.turn.roundNumber,turn:s.turn.turnNumber};
}
function end(){act('end_turn');assert.equal(save().session,null);}
function snap(label){stages[label]={input:recorded.length,asset:assets(),envelope:save()};}
function replay(origin,actions,expected){restore(origin);actions.forEach(execute);assert.deepEqual(save(),expected);restore(origin);}
try{
 restore(ref.origin);
 act('choose_target',t=>t.tileId==='orange1');snap('after-research');
 act('choose_card',t=>t.cardInstanceId==='card-60-0');snap('after-public-pick');
 const card=state().cards.publicCards.find(c=>c?.cardId==='dlc_17.png');
 assert(card,JSON.stringify(assets()));
 act('industry',t=>t.abilityId==='deepspace_swap_cards');
 act('choose_card',t=>t.cardInstanceId===pcard('b_16.webp')?.id);
 act('choose_card',t=>t.cardInstanceId===card.id);
 for(const id of ['amiba_7.webp','dlc_17.png'])act('card_corner',t=>t.cardInstanceId===pcard(id)?.id);
 place();place(1);place();place();place();end();snap('before-scan');
 assert.deepEqual([player().resources.credits,player().resources.energy],[1,2]);
 assert.equal(assets().probes.length,1);
 act('scan');snap('main-scan-opened');
 const first=menu().find(a=>a.family==='choose_target'&&a.target?.nebulaId==='sector-3-a')||menu().find(a=>a.family==='choose_target'&&a.target?.nebulaId);
 assert(first,JSON.stringify(available()));act(first.family,(t,a)=>a.actionId===first.actionId);
 act('choose_card',t=>t.cardInstanceId==='card-61-0'&&t.nebulaId);
 const pc=load('randomizer/game/ai/probe-capital');
 const saturn=()=>{const s=state();return pc.requirements(pc.factsFromState(s,player())).find(g=>g.planetId==='saturn'&&g.endpointFamily==='land'&&g.requirementId.endsWith(':planet'));};
 for(let i=0;save().session;i++){
  assert(i<15,JSON.stringify(available()));const choices=menu();
  if(choices.some(a=>a.target?.traceType==='pink')&&choices.some(a=>a.target?.alienSlotId===2)){
   snap('before-pink');act('choose_target',t=>t.traceType==='pink'&&t.alienSlotId===2);
   snap('after-reveal-start');continue;
  }
  const path=saturn()?.route?.path,step=path?.[0];
  const preferred=step&&choices.find(a=>a.target?.mode==='move'&&a.target.rocketId===6&&a.target.deltaX===step.deltaX&&a.target.deltaY===step.deltaY)
    ||choices.find(a=>a.target?.source==='display'&&a.family==='choose_card')
    ||choices.find(a=>a.target?.stateExtra===true&&a.target?.alienSlotId===1)
    ||choices.find(a=>a.target?.choiceId?.startsWith('confirm:'))
    ||choices.find(a=>a.target?.skip||a.target?.done||a.target?.mode==='skip');
  assert(preferred,JSON.stringify(available()));act(preferred.family,(t,a)=>a.actionId===preferred.actionId);
 }
 snap('after-scan');end();snap('after-scan-end');
 const e=save();replay(ref.origin,recorded,e);
 fs.writeFileSync(out,JSON.stringify({scope:'Exact earlier Orange 1 launch, legal payment after known refill, known native scan and one named Saturn movement only; hand back before any further action.',originHash:hash(ref.origin),stages,recorded,end:e,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
 for(const [name,{asset} ] of Object.entries(stages))console.log(name,JSON.stringify({wallet:asset.wallet,computer:asset.computer,blue:asset.blue,probe:asset.probes.map(p=>[p.sectorX,p.sectorY]),market:asset.knownMarket,hand:asset.hand,score:asset.realized}));
 console.log(recorded.map(a=>a.summary).join(' / '));
}finally{c.dispose();}
