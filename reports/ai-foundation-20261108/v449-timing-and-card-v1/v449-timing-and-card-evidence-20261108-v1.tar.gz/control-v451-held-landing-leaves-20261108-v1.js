'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n));
const {createSeededRandom}=load('randomizer/game/random');
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation');
const [fixture,comparison,search,out]=process.argv.slice(2);
const f=JSON.parse(fs.readFileSync(fixture)),a=JSON.parse(fs.readFileSync(comparison)),seat=f.seatId,seed=f.source.seed;
const g=JSON.parse(require('node:zlib').gunzipSync(fs.readFileSync(search)));
const native=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,w)=>buildRuleObservation(s,seed,w?.playerId)});
native.newGame({seed});const c=native.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),owner=s=>s.players.players.find(p=>p.id===seat);
function act(w){
 const d=c.inspect().session?.decision,v=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(v);assert.deepEqual(v.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:v})
  :v.phase==='quick'?c.inputPort.submitQuickAction(v):c.inputPort.submitAction(v);
 assert(r.ok,JSON.stringify(r));return v;
}
function assets(){
 const s=state(),p=owner(s),v=c.projection({role:'player',playerId:seat}).state;
 return {wallet:p.resources,hand:p.hand.map(c=>c.cardId),reserved:p.reservedCards.map(c=>c.cardId),
  income:p.income,computer:p.dataState.computerSlots,blue:p.dataState.blueBonusSlots,
  pending:c.inspect().session?.decision?.kind,projectedFinal:v.publicState.players.find(x=>x.playerId===seat).finalScore};
}
try{
 const rows=[];
 for(const planet of ['mercury','uranus']){
  const landing=a.rows.find(r=>r.goal.requirementId.endsWith(planet==='mercury'?':mercury:planet':':uranus:titania'));
  const plan=g.roots.find(r=>r.goal?.kind==='held-landing-route'&&r.goal.planetId===planet);
  assert(landing&&plan);
  restore(f.compositionEnvelope);landing.accepted.forEach(act);assert.deepEqual(JSON.parse(JSON.stringify(save())),landing.end);
  const before=assets(),accepted=[];
  const l=g.lines.find(x=>x.node===plan.target);
  assert.equal(l.value,plan.value);
  const edges=l.edges.filter(e=>g.lines.find(n=>n.node===e.target).value===plan.value);
  assert.equal(edges.length,1);
  const follow=edges[0];
  for(const id of follow.steps||[follow.actionId]){
   const a=menu().find(x=>x.actionId===id);assert(a,JSON.stringify(menu().map(x=>[x.actionId,x.target])));accepted.push(act(a));
  }
  // A quiet tail proves the end and mark without a successor envelope.
  // Execute the one proven mark using the actual Native menu.
  if(follow.turnTailPlanValue?.markedTiles.length){
   const ids=follow.turnTailPlanValue.markedTiles;
   for(const tile of ids){
    const a=menu().find(a=>a.target?.tileId===tile);assert(a);accepted.push(act(a));
   }
  }
  const after=assets(),end=save(),graphBoundary=g.lines.find(n=>n.node===follow.target).boundary;
  restore(f.compositionEnvelope);landing.accepted.forEach(act);accepted.forEach(act);assert.deepEqual(save(),end);
  rows.push({planet,landing:landing.end,before,accepted,after,end,graphBoundary,searchValue:plan.value});
  console.log(JSON.stringify({planet,value:plan.value,boundary:graphBoundary,actions:accepted.map(x=>[x.family,x.summary,x.target]),wallet:after.wallet,
   projected:after.projectedFinal,pending:after.pending}));
 }
 restore(f.compositionEnvelope);
 fs.writeFileSync(out,JSON.stringify({scope:'Matched known winning leaves after exact held landings; physical hidden-draw identities must not enter the model',rows,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
