'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n)),read=p=>JSON.parse(fs.readFileSync(p));
const {createSeededRandom}=load('randomizer/game/random');
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation');
const pc=load('randomizer/game/ai/probe-capital'),weights=load('randomizer/game/ai/state-value').DEFAULT_WEIGHTS;
const effects=load('randomizer/game/cards/effects');
const [first,early,late,out]=process.argv.slice(2),a=read(first),b=read(early),z=read(late),seat='player-white';
const original=a.rows.find(r=>r.kind==='recorded').end,seed=JSON.parse(original.committedState).meta.seed;
const native=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,w)=>buildRuleObservation(s,seed,w?.playerId)});
native.newGame({seed});const c=native.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),owner=s=>s.players.players.find(p=>p.id===seat);
function act(w){
 const d=c.inspect().session?.decision,v=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(v);assert.deepEqual(v.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:v})
  :v.phase==='quick'?c.inputPort.submitQuickAction(v):c.inputPort.submitAction(v);
 assert(r.ok,JSON.stringify(r));return v;
}
function assets(){
 const s=state(),p=owner(s),v=c.projection({role:'player',playerId:seat}).state;
 return {turn:s.turn.turnNumber,wallet:p.resources,hand:p.hand.map(c=>c.cardId),reserved:p.reservedCards.map(c=>c.cardId),
  probes:s.pieces.rockets.filter(r=>r.playerId===seat),income:p.income,projectedFinal:v.publicState.players.find(x=>x.playerId===seat).finalScore};
}
try{
 const roots=[{kind:'recorded',timing:'early',origin:original},...b.rows.map(x=>({kind:x.kind,timing:'early',origin:x.beforeRouteEnvelope})),
  ...z.rows.map(x=>({kind:x.kind,timing:'wait',origin:x.beforeRouteEnvelope}))],rows=[];
 for(const root of roots){
  restore(root.origin);const before=assets(),accepted=[];
  const choose=(f,pred=()=>true)=>{
   const x=menu().find(a=>a.family===f&&pred(a.target,a));
   assert(x,JSON.stringify(menu().map(a=>[a.family,a.target])));accepted.push(act(x));return x;
  };
  const s=state(),p=owner(s),card=p.hand.find(c=>c.cardId==='dlc_31.png');
  assert(card);assert.deepEqual(effects.getCardPlayCost(card),{credits:1});
  const goal=pc.requirements(pc.factsFromState(s,p)).find(g=>g.requirementId.endsWith(':land:uranus:titania'));
  assert(goal);
  const payment=pc.funding(p.resources,{credits:1,energy:goal.route.cost},weights);
  assert(payment);
  for(let i=0;i<payment.energyPurchases;i++)choose('quick_trade',t=>t.tradeId==='credits-for-energy');
  for(let i=0;i<payment.creditPurchases;i++)choose('quick_trade',t=>t.tradeId==='energy-for-credit');
  const rocket=Number(goal.requirementId.split(':')[0]);
  for(const m of goal.route.path){
   choose('move',t=>t.rocketId===rocket&&t.deltaX===m.deltaX&&t.deltaY===m.deltaY);
   choose('choose_payment',t=>t.kind==='move-payment'&&!t.cardIds.length);
  }
  choose('play_card',t=>t.cardInstanceId===card.id);
  choose('choose_target',t=>t.planetId==='uranus'&&t.landTarget?.satelliteId==='titania');
  choose('end_turn');
  if(save().session)choose('choose_target',t=>t.tileId==='a');
  assert(!save().session);const after=assets(),end=save();
  assert.equal(after.wallet.score,before.wallet.score+25);assert(after.reserved.includes(card.cardId));
  restore(root.origin);accepted.forEach(act);assert.deepEqual(save(),end);
  rows.push({...root,before,goal,payment,accepted,after,end});
  console.log(JSON.stringify({kind:root.kind,timing:root.timing,route:goal.route.cost,wallet:[after.wallet.score,after.wallet.credits,after.wallet.energy,after.wallet.publicity],projection:after.projectedFinal,hand:after.hand}));
 }
 restore(original);
 fs.writeFileSync(out,JSON.stringify({scope:'Each exact held DLC31 root: use the same Uranus Titania mission, follow fixed paid path then Native card landing; no additional round simulation',rows,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
