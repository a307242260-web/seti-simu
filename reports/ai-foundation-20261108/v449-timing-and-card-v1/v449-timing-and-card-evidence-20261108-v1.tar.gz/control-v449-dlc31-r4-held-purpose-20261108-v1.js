'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n)),read=p=>JSON.parse(fs.readFileSync(p));
const {createSeededRandom}=load('randomizer/game/random');
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation');
const pc=load('randomizer/game/ai/probe-capital'),weights=load('randomizer/game/ai/state-value').DEFAULT_WEIGHTS;
const effects=load('randomizer/game/cards/effects');
const [matched,card,historical,out]=process.argv.slice(2),a=read(matched),b=read(card),actions=read(historical).replaySteps,seat='player-white';
const original=a.rows.find(r=>r.kind==='recorded').later.end,seed=JSON.parse(original.committedState).meta.seed;
const native=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,w)=>buildRuleObservation(s,seed,w?.playerId)});
native.newGame({seed});const c=native.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),owner=s=>s.players.players.find(p=>p.id===seat);
function act(w){
 const d=c.inspect().session?.decision,v=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(v);assert.deepEqual(v.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:v})
  :v.phase==='quick'?c.inputPort.submitQuickAction(v):c.inputPort.submitAction(v);
 assert(r.ok,JSON.stringify(r));return v;
}
function assets(){
 const s=state(),p=owner(s),v=c.projection({role:'player',playerId:seat}).state;
 return {turn:s.turn.turnNumber,wallet:p.resources,hand:p.hand.map(c=>c.cardId),reserved:p.reservedCards.map(c=>c.cardId),
  probes:s.pieces.rockets.filter(r=>r.playerId===seat),income:p.income,projectedFinal:v.publicState.players.find(x=>x.playerId===seat).finalScore};
}
try{
 const rows=[];
 for(const [kind,origin] of [['held',original],['played',b.rows.find(r=>r.kind==='recorded'&&r.timing==='early').end]]){
  restore(origin);const accepted=[];
  for(let i=153;i<=194;i++)accepted.push(act(actions[i-1].action));
  const end=save(),after=assets(),root=state(),p=owner(root);
  const choices=menu().map(a=>[a.family,a.summary,a.target]);
  restore(origin);accepted.forEach(act);assert.deepEqual(save(),end);
  rows.push({kind,origin,accepted,end,after,choices,knownTech:root.tech.stacks.orange3.bonusId,stock:p.dataState});
  console.log(JSON.stringify({kind,wallet:after.wallet,hand:after.hand,reserved:after.reserved,projection:after.projectedFinal,choices}));
 }
 restore(original);
 fs.writeFileSync(out,JSON.stringify({scope:'Only replay the already recorded R4 prefix (inputs153–194), after changing DLC31 use at R3. No additional decisions.',rows,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
