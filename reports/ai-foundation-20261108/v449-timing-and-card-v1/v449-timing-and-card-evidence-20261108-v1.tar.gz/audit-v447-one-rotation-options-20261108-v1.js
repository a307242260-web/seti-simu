'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n)),read=p=>JSON.parse(fs.readFileSync(p));
const pc=load('randomizer/game/ai/probe-capital'),turn=load('randomizer/game/turn-flow'),ability=load('randomizer/game/abilities/rocket'),rockets=load('randomizer/game/rockets');
const src=JSON.parse(read(process.argv[2]).stop.e.committedState),seat='player-white',owner=s=>s.players.players.find(p=>p.id===seat),baseline=JSON.stringify(src);
function rotated(s){
 const copy=structuredClone(s),rotation=turn.rotateSolarSystem(copy,1,seat,{captureSnapshots:false});
 assert(rotation.ok);
 const r=turn.advanceTurnAfterPlayerAction(copy,seat,{passed:true});assert(r.roundAdvanced);
 return copy;
}
function endpoints(s){
 const p=owner(s),wallet={credits:p.resources.credits+p.income.credits,energy:p.resources.energy+p.income.energy};
 const goals=pc.requirements(pc.factsFromState(s,p)).map(g=>{
  const score=g.endpointFacts.rewards.reduce((n,e)=>n+(e.type==='gain_resources'?(e.options?.gain?.score||0):0),0);
  const cost={credits:g.endpointFacts.cost.credits||0,energy:(g.endpointFacts.cost.energy||0)+g.route.cost};
  return {id:g.requirementId,kind:g.endpointFamily,cost,score,net:score-cost.credits-cost.energy,
   funded:cost.credits<=wallet.credits&&cost.energy<=wallet.energy,path:g.route.path};
 });
 return {wallet,pub:p.resources.publicity,goals:goals.filter(g=>g.funded&&g.net>0).sort((a,b)=>b.net-a.net||a.id.localeCompare(b.id))};
}
const noMove=endpoints(rotated(src)),rows=[];
for(const d of ability.MOVE_DIRECTIONS){
 const copy=structuredClone(src),rocket=copy.pieces.rockets.find(r=>r.playerId===seat);
 const context={state:copy,pieces:copy.pieces,players:copy.players,solarSystem:copy.solarSystem,turn:copy.turn,planets:copy.planets};
 const moved=ability.moveProbe(context,{rocketId:rocket.id,deltaX:d.deltaX,deltaY:d.deltaY,movementPoints:1,cost:{energy:1},source:'move'});
 if(moved.ok)rows.push({direction:d.id,events:moved.events,after:endpoints(rotated(copy))});
}
assert.equal(JSON.stringify(src),baseline);
fs.writeFileSync(process.argv[3],JSON.stringify({noMove,rows},null,2)+'\n',{flag:'wx'});
console.log(noMove.goals.map(g=>[g.id,g.cost,g.net,g.path[0]]));
for(const r of rows)console.log(r.direction,r.after.pub,r.after.goals.map(g=>[g.id,g.cost,g.net]));
