'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n));
const {createSeededRandom}=load('randomizer/game/random');
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation');
const pc=load('randomizer/game/ai/probe-capital');
const {DEFAULT_WEIGHTS,createStateValueEvaluator}=load('randomizer/game/ai/state-value');
const {createAnalysisPort}=load('randomizer/game/ai/analysis-port');
const {getCardPlayCost}=load('randomizer/game/cards/effects');
const [fixture,out]=process.argv.slice(2),f=JSON.parse(fs.readFileSync(fixture)),seat=f.seatId,seed=f.source.seed;
const native=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,w)=>buildRuleObservation(s,seed,w?.playerId)});
native.newGame({seed});const c=native.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),owner=s=>s.players.players.find(p=>p.id===seat);
function act(w){
 const d=c.inspect().session?.decision,v=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(v);assert.deepEqual(v.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:v})
  :v.phase==='quick'?c.inputPort.submitQuickAction(v):c.inputPort.submitAction(v);
 assert(r.ok,JSON.stringify(r));return v;
}
function assets(){
 const s=state(),p=owner(s),v=c.projection({role:'player',playerId:seat}).state;
 return {wallet:p.resources,hand:p.hand.map(c=>c.cardId),reserved:p.reservedCards.map(c=>c.cardId),
  income:p.income,projectedFinal:v.publicState.players.find(x=>x.playerId===seat).finalScore};
}
try{
 restore(f.compositionEnvelope);
 const root=save(),s=state(),p=owner(s),supplier=pc.heldLandingCard({hand:p.hand,round:s.turn.roundNumber},DEFAULT_WEIGHTS);
 assert(supplier);const card=supplier.card,cardCost=getCardPlayCost(card),before=assets(),rows=[];
 for(const goal of pc.requirements(pc.factsFromState(s,p)).filter(g=>g.endpointFamily==='land'&&g.route.path.length)){
  const [, ,planetId,satelliteId]=goal.requirementId.split(':'),rocketId=Number(goal.requirementId.split(':')[0]);
  const payment=pc.funding(p.resources,{...cardCost,energy:goal.route.cost},DEFAULT_WEIGHTS);
  if(!payment||payment.creditPurchases)continue;
  restore(root);const accepted=[];
  const pick=(family,test=()=>true)=>{
   const x=menu().find(a=>a.family===family&&test(a.target,a));assert(x,JSON.stringify(menu().map(a=>[a.family,a.target])));
   accepted.push(act(x));
  };
  for(let i=0;i<payment.energyPurchases;i++)pick('quick_trade',t=>t.tradeId==='credits-for-energy');
  for(const m of goal.route.path){
   pick('move',t=>t.rocketId===rocketId&&t.deltaX===m.deltaX&&t.deltaY===m.deltaY);
   pick('choose_payment',t=>t.kind==='move-payment'&&!t.cardIds.length);
  }
  pick('play_card',t=>t.cardInstanceId===card.id);
  pick('choose_target',t=>t.rocketId===rocketId&&t.planetId===planetId&&t.landTarget?.satelliteId===(satelliteId==='planet'?undefined:satelliteId));
  // Observe the full landing before arbitrary turn-end choices. Menus
  // created by a threshold are evidence, not silently scored as rewards.
  const end=save(),after=assets(),pending=c.inspect().session?.decision||null;
  const q=createAnalysisPort({composition:c,seatId:seat,maxCacheEntries:0});
  let value;
  try{value=createStateValueEvaluator(seat)(q.openRoot().observation);}finally{q.close();}
  restore(root);accepted.forEach(act);assert.deepEqual(save(),end);
  rows.push({goal,payment,before,after,pending,value,accepted,end});
  console.log(JSON.stringify({goal:goal.requirementId,path:goal.route.cost,value,score:after.wallet.score,
   credit:after.wallet.credits,energy:after.wallet.energy,publicity:after.wallet.publicity,data:after.wallet.availableData,projected:after.projectedFinal,pending:pending?.kind}));
 }
 restore(root);
 fs.writeFileSync(out,JSON.stringify({scope:'Exact Native landing outcomes from the same historical 142 root; no end-turn effects chosen',fixture,replayExact:true,rootAndRngRestored:true,rows},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
