'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n)),read=p=>JSON.parse(fs.readFileSync(p));
const {createSeededRandom}=load('randomizer/game/random');
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation');
const endScore=load('randomizer/game/end-game-scoring'),effects=load('randomizer/game/cards/effects');
const [recordFile,progressFile,out]=process.argv.slice(2),r=read(recordFile),progress=read(progressFile),history=read(r.savePath).replaySteps;
const r3=progress.roundStarts[3],begin=r3.envelope,final=r.roundEnds.find(row=>row.round===3),original=read(final.checkpointPath).coreState.compositionEnvelope;
const seed=r.seed,seat='player-white';
const env=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});
env.newGame({seed});
const c=env.composition,save=()=>c.lifecycle.save().envelope;
function restore(e){assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);}
function actual(raw){
 const d=c.inspect().session?.decision,menu=d?.choices||c.inputPort.enumerateActions({});
 const action=menu.find(a=>a.actionId===raw.actionId&&a.actorId===raw.actorId);
 assert(action,JSON.stringify(menu.map(a=>[a.family,a.summary,a.target])));assert.deepEqual(action.target,raw.target);
 const q=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:action})
  :action.phase==='quick'?c.inputPort.submitQuickAction(action):c.inputPort.submitAction(action);
 assert(q.ok,JSON.stringify(q));return action;
}
function value(e){
 const s=structuredClone(e.session?.session?.workingState||JSON.parse(e.committedState)),p=s.players.players.find(x=>x.id===seat);
 const result=endScore.computePlayerFinalScore({...s,players:s.players.players,cardEffects:effects,
  getCardTypeCode:card=>effects.getRuntimeCardTypeCode(card,effects.getCardModel(card)?.cardType)},p);
 const next=structuredClone(p);next.completedTaskCount=(p.completedTaskCount||0)+1;
 return {result,completedTaskCount:p.completedTaskCount,orbitLandCount:endScore.countOrbitOrLandMarkers(p,s.planets,s),
  c1ValueOneMoreTask:endScore.getFormulaBaseValue('c1',next,s)*endScore.getSlotMultiplier('c1',1),
  slots:s.finalScoring.tiles,publicity:p.resources.publicity,
  reservedTasks:p.reservedCards.flatMap(c=>(effects.getCardModel(c)?.tasks||[]).map(t=>({card:c.cardId,condition:t.condition,
    completed:!!c.cardEffectState?.completedTaskIds?.includes(t.id)})))};
}
try{
 const rows=[];
 for(const replacement of [null,156,178]){
  restore(begin);const accepted=[];let fork=null;
  for(let i=r3.beforeInput;i<final.beforeInput;i++){
   let action=history[i-1].action;
   if(i===replacement){
    const d=c.inspect().session?.decision,x=d.choices.find(a=>a.target?.tileId==='c');
    assert(x&&x.actorId===seat);
    fork={input:i,before:save(),original:action,replacement:x,valueBefore:value(save())};action=x;
   }
   accepted.push(actual(action));
  }
  const end=save();if(!replacement)assert.deepEqual(end,original);
  restore(begin);accepted.forEach(actual);assert.deepEqual(save(),end);
  const scoring=value(end);
  const s=JSON.parse(end.committedState),b=JSON.parse(original.committedState);
  const changedStateKeys=Object.keys(s).filter(k=>JSON.stringify(s[k])!==JSON.stringify(b[k]));
  rows.push({replacement,fork,accepted,end,scoring,changedStateKeys});
  console.log(JSON.stringify({replacement,score:scoring.result.totalScore,tileScores:scoring.result.tileScoresById,
   tasks:scoring.completedTaskCount,orbitLand:scoring.orbitLandCount,c1IfOneMore:scoring.c1ValueOneMoreTask,changedStateKeys}));
 }
 restore(begin);
 fs.writeFileSync(out,JSON.stringify({scope:'V445 formal endgame mark choice at input156 or178; only one native choice changed, exact later actions, R3 PASS not submitted',source:begin,rows,replayExact:true},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
