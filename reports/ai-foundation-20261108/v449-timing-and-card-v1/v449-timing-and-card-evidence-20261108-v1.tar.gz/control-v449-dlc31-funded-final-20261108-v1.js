'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n)),read=p=>JSON.parse(fs.readFileSync(p));
const {createSeededRandom}=load('randomizer/game/random');
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation');
const pc=load('randomizer/game/ai/probe-capital'),weights=load('randomizer/game/ai/state-value').DEFAULT_WEIGHTS;
const effects=load('randomizer/game/cards/effects');
const [source,historical,out]=process.argv.slice(2),a=read(source),actions=read(historical).replaySteps,seat='player-white';
const original=a.rows.find(r=>r.kind==='held').end,seed=JSON.parse(original.committedState).meta.seed;
const native=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,w)=>buildRuleObservation(s,seed,w?.playerId)});
native.newGame({seed});const c=native.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),owner=s=>s.players.players.find(p=>p.id===seat);
function act(w){
 const d=c.inspect().session?.decision,v=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(v);assert.deepEqual(v.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:v})
  :v.phase==='quick'?c.inputPort.submitQuickAction(v):c.inputPort.submitAction(v);
 assert(r.ok,JSON.stringify(r));return v;
}
function assets(){
 const s=state(),p=owner(s),v=c.projection({role:'player',playerId:seat}).state;
 return {turn:s.turn.turnNumber,wallet:p.resources,hand:p.hand.map(c=>c.cardId),reserved:p.reservedCards.map(c=>c.cardId),
  probes:s.pieces.rockets.filter(r=>r.playerId===seat),income:p.income,projectedFinal:v.publicState.players.find(x=>x.playerId===seat).finalScore};
}
try{
 const rows=[];
 for(const kind of ['held','visit','orbit']){
  const origin=a.rows.find(r=>r.kind===(kind==='held'?'held':'played')).end;
  restore(origin);const accepted=[];let named=null;
  const pick=(f,pred=()=>true)=>{
   const x=menu().find(a=>a.family===f&&pred(a.target,a));assert(x,JSON.stringify(menu().map(a=>[a.family,a.target])));
   accepted.push(act(x));return x;
  };
  const finish=()=>{
   pick('end_turn');
   while(save().session){
    const x=menu().find(a=>a.family==='accept_optional_effect'&&a.target?.choiceId?.startsWith('confirm:task:'))
      ||menu().find(a=>a.family==='accept_optional_effect'&&a.target?.choiceId?.startsWith('skip:'));
    assert(x,JSON.stringify(menu().map(a=>[a.family,a.target])));accepted.push(act(x));
   }
  };
  if(kind==='held'){
   for(let i=195;i<=201;i++)accepted.push(act(actions[i-1].action));
  }else{
   pick('launch');
   const s=state(),p=owner(s);
   named=pc.requirements(pc.factsFromState(s,p)).find(g=>g.planetId==='venus'&&g.endpointFamily==='orbit');
   assert(named&&named.route.cost===2);
   const limit=named.route.cost+(kind==='orbit'?(named.endpointFacts.cost.energy||0):0);
   const pay=pc.funding(p.resources,{credits:kind==='orbit'?named.endpointFacts.cost.credits||0:0,energy:limit},weights);
   assert(pay&&pay.creditPurchases===0);
   for(let i=0;i<pay.energyPurchases;i++)pick('quick_trade',t=>t.tradeId==='credits-for-energy');
   const rocket=Number(named.requirementId.split(':')[0]);
   for(const m of named.route.path){
    pick('move',t=>t.rocketId===rocket&&t.deltaX===m.deltaX&&t.deltaY===m.deltaY);
    pick('choose_payment',t=>t.kind==='move-payment'&&!t.cardIds.length);
   }
   assert.equal(assets().wallet.publicity,6);
   finish();
   if(kind==='orbit'){pick('orbit',t=>t.planetId==='venus'&&t.rocketId===rocket);finish();}
   pick('research_tech');pick('choose_target',t=>t.tileId==='orange3');finish();
   pick('pass');
  }
  const after=assets(),end=save();assert(state().turn.gameEnded);
  restore(origin);accepted.forEach(act);assert.deepEqual(save(),end);
  rows.push({kind,origin,accepted,named,after,end});
  console.log(JSON.stringify({kind,score:after.projectedFinal,board:after.wallet.score,credits:after.wallet.credits,energy:after.wallet.energy,
   publicity:after.wallet.publicity,probes:after.probes.length,reserved:after.reserved,steps:accepted.length}));
 }
 restore(original);
 fs.writeFileSync(out,JSON.stringify({scope:'Controlled endgame suffix only, all R2/R3 official records unchanged; compare held DLC31 last use against visit or Venus orbit funded by early card use',rows,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
