'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n)),read=p=>JSON.parse(fs.readFileSync(p));
const {createSeededRandom}=load('randomizer/game/random'),{createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port');
const {createSearchAgent}=load('randomizer/game/ai/search-agent');
const [source,out,mode='normal']=process.argv.slice(2),ref=read(source),base=ref.compositionEnvelope,seat='player-white',seed=JSON.parse(base.committedState).meta.seed;
const sourceState=JSON.parse(base.committedState);
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function act(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===seat);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
 :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(r.ok,JSON.stringify(r));return a;
}
function assets(e){
 const s=e.session?.session?.workingState||JSON.parse(e.committedState),p=s.players.players.find(q=>q.id===seat),
  v=c.projection({role:'player',playerId:seat}).state;
 return {turn:s.turn.turnNumber,wallet:p.resources,income:p.income,hand:p.hand.map(h=>[h.id,h.cardId]),data:p.dataState,tech:p.techState,
  probes:s.pieces.rockets.filter(x=>x.playerId===seat),wins:s.data.sectorSettlements.winsByPlayerId[seat],traces:v.selfState.traceCounts,
  projectedFinal:v.publicState.players.find(q=>q.playerId===seat).finalScore};
}
const pc=load('randomizer/game/ai/probe-capital'),weights=load('randomizer/game/ai/state-value').DEFAULT_WEIGHTS;
function raw(){
 const e=save();
 return e.session?.session?.workingState||JSON.parse(e.committedState);
}
function step(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId);
 assert(a);assert.deepEqual(a.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
 :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(r.ok,JSON.stringify(r));return a;
}
const historical=read(process.argv[4]).replaySteps;
function pick(out,f,p=()=>true){
 const x=menu().find(a=>a.family===f&&p(a.target,a));assert(x,JSON.stringify(menu().map(a=>[a.family,a.target])));
 out.push(step(x));return x;
}
function actual(out,lo,hi){
 for(let i=lo;i<=hi;i++)out.push(step(historical[i-1].action));
}
function pass(out){
 pick(out,'pass');pick(out,'choose_card',t=>t.kind==='pass-reserve-card'&&t.choiceId==='card-29-pass-2-5');
 assert.equal(raw().turn.roundNumber,3);assert.equal(save().session,null);
}
function whiteStart(out){
 for(let i=0;raw().turn.currentPlayerId!==seat||save().session;i++){
  assert(i<20);
  const known=historical[125+i]?.action,decision=c.inspect().session?.decision;
  const x=known&&menu().find(a=>a.actionId===known.actionId)
    ||(decision?decision.choices.find(a=>a.family==='accept_optional_effect'&&a.target?.choiceId?.startsWith('skip:'))
      ||decision.choices.filter(a=>a.family==='choose_card').sort((a,b)=>a.actionId.localeCompare(b.actionId))[0]
      :menu().find(a=>a.family==='pass'));
  assert(x&&(decision?x.actorId===decision.ownerId:x.family==='pass'));
  out.push(step(x));
 }
}
function jupiter(){
 const s=raw(),p=s.players.players.find(x=>x.id===seat);
 const goal=pc.requirements(pc.factsFromState(s,p)).find(g=>g.planetId==='jupiter'&&g.endpointFamily==='land'&&g.requirementId.endsWith(':planet'));
 if(!goal)return null;
 const cost={...goal.endpointFacts.cost,energy:(goal.endpointFacts.cost.energy||0)+goal.route.cost};
 return {goal,cost,payment:pc.funding(p.resources,cost,weights)};
}
try{
 const rows=[];
 for(const kind of ['pass-now','land-only','recorded']){
  restore(base);const accepted=[];
  if(kind==='land-only')actual(accepted,105,108);
  if(kind==='recorded')actual(accepted,105,123);
  const beforePass=assets(save()),beforePassEnvelope=save();
  pass(accepted);
  const afterSalary=assets(save()),afterSalaryEnvelope=save(),beforeOtherPass=jupiter();
  whiteStart(accepted);
  const firstWhite=assets(save()),firstWhiteEnvelope=save(),afterOtherPass=jupiter();
  const deferred=[];
  if(kind==='pass-now'&&afterOtherPass?.payment){
   for(let i=0;i<afterOtherPass.payment.energyPurchases;i++)pick(deferred,'quick_trade',t=>t.tradeId==='credits-for-energy');
   for(let i=0;i<afterOtherPass.payment.creditPurchases;i++)pick(deferred,'quick_trade',t=>t.tradeId==='energy-for-credit');
   for(const m of afterOtherPass.goal.route.path){
    pick(deferred,'move',t=>t.rocketId===4&&t.deltaX===m.deltaX&&t.deltaY===m.deltaY);
    pick(deferred,'choose_payment',t=>t.kind==='move-payment'&&!t.cardIds.length);
   }
   pick(deferred,'land');
   const target=menu().find(a=>a.family==='choose_target'&&a.target?.planetId==='jupiter'&&!a.target?.satelliteId);
   if(target)deferred.push(step(target));
   const yellow=menu().find(a=>a.family==='choose_target'&&a.target?.traceType==='yellow'&&a.target?.alienSlotId===1);
   if(yellow)deferred.push(step(yellow));
  }
  const settled=assets(save()),end=save();
  restore(base);accepted.forEach(step);deferred.forEach(step);assert.deepEqual(save(),end);
  rows.push({kind,accepted,deferred,beforePass,beforePassEnvelope,afterSalary,afterSalaryEnvelope,firstWhite,firstWhiteEnvelope,beforeOtherPass,afterOtherPass,settled,end});
  const x=a=>[a.wallet.score,a.wallet.credits,a.wallet.energy,a.wallet.publicity,a.wallet.availableData,a.hand.length,a.probes.length,a.income.credits];
  console.log(JSON.stringify({kind,beforePass:x(beforePass),afterSalary:x(afterSalary),firstWhite:x(firstWhite),settled:x(settled),beforeOtherPass:beforeOtherPass?.cost,afterOtherPass:afterOtherPass?.cost,deferred:deferred.map(a=>a.summary)}));
 }
 restore(base);
 fs.writeFileSync(out,JSON.stringify({scope:'Archived V189 exact root before input105 on the current native rules. Same PASS card; three fixed timing controls. No new policy query.',source:base,rows,rootAndRngRestored:true,nativeReplayExact:true},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
