'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n)),read=p=>JSON.parse(fs.readFileSync(p));
const {createSeededRandom}=load('randomizer/game/random'),{createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port');
const {createSearchAgent}=load('randomizer/game/ai/search-agent');
const [source,out,mode='normal']=process.argv.slice(2),ref=read(source),base=ref.rows[0].origin,seat='player-white',seed=JSON.parse(base.committedState).meta.seed;
const sourceState=JSON.parse(base.committedState);
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function act(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===seat);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
 :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(r.ok,JSON.stringify(r));return a;
}
function assets(e){
 const s=e.session?.session?.workingState||JSON.parse(e.committedState),p=s.players.players.find(q=>q.id===seat),
  v=c.projection({role:'player',playerId:seat}).state;
 return {turn:s.turn.turnNumber,wallet:p.resources,income:p.income,hand:p.hand.map(h=>[h.id,h.cardId]),data:p.dataState,tech:p.techState,
  probes:s.pieces.rockets.filter(x=>x.playerId===seat),wins:s.data.sectorSettlements.winsByPlayerId[seat],traces:v.selfState.traceCounts,
  projectedFinal:v.publicState.players.find(q=>q.playerId===seat).finalScore};
}
const pc=load('randomizer/game/ai/probe-capital'),weights=load('randomizer/game/ai/state-value').DEFAULT_WEIGHTS;
function raw(){
 const e=save();
 return e.session?.session?.workingState||JSON.parse(e.committedState);
}
function step(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId);
 assert(a);assert.deepEqual(a.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
 :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(r.ok,JSON.stringify(r));return a;
}
const historical=read(process.argv[4]).replaySteps;
function pick(out,f,p=()=>true){
 const x=menu().find(a=>a.family===f&&p(a.target,a));assert(x,JSON.stringify(menu().map(a=>[a.family,a.target])));
 out.push(step(x));return x;
}
function actual(out,lo,hi){
 for(let i=lo;i<=hi;i++)out.push(step(historical[i-1].action));
}
function pass(out){
 pick(out,'pass');pick(out,'choose_card',t=>t.kind==='pass-reserve-card'&&t.choiceId==='card-29-pass-2-5');
 assert.equal(raw().turn.roundNumber,3);assert.equal(save().session,null);
}
function whiteStart(out,offset=125){
 for(let i=0;raw().turn.currentPlayerId!==seat||save().session;i++){
  assert(i<20);
  const known=historical[offset+i]?.action,decision=c.inspect().session?.decision;
  const x=known&&menu().find(a=>a.actionId===known.actionId)
    ||(decision?decision.choices.find(a=>a.family==='accept_optional_effect'&&a.target?.choiceId?.startsWith('skip:'))
      ||decision.choices.filter(a=>a.family==='choose_card').sort((a,b)=>a.actionId.localeCompare(b.actionId))[0]
      :menu().find(a=>a.family==='pass'));
  assert(x&&(decision?x.actorId===decision.ownerId:x.family==='pass'));
  out.push(step(x));
 }
}
function jupiter(){
 const s=raw(),p=s.players.players.find(x=>x.id===seat);
 const goal=pc.requirements(pc.factsFromState(s,p)).find(g=>g.planetId==='jupiter'&&g.endpointFamily==='land'&&g.requirementId.endsWith(':planet'));
 if(!goal)return null;
 const cost={...goal.endpointFacts.cost,energy:(goal.endpointFacts.cost.energy||0)+goal.route.cost};
 return {goal,cost,payment:pc.funding(p.resources,cost,weights)};
}
const cardRules=load('randomizer/game/cards/deck');
function launchWithoutMove(out){pick(out,'launch');pick(out,'end_turn');}
function attempt(out){
 const s=raw(),p=s.players.players.find(x=>x.id===seat);
 const goal=pc.requirements(pc.factsFromState(s,p)).find(g=>g.planetId==='uranus'&&g.endpointFamily==='land'&&g.requirementId.endsWith(':titania'));
 if(!goal)return {kind:'route-not-available'};
 const cost={...goal.endpointFacts.cost,energy:(goal.endpointFacts.cost.energy||0)+goal.route.cost};
 let payment=pc.funding(p.resources,cost,weights),card=null;
 if(!payment&&goal.route.path.length){
  card=p.hand.find(c=>cardRules.getDiscardActionMoveRewardForCard(c)?.movementPoints===1);
  if(card)payment=pc.funding(p.resources,{...cost,energy:cost.energy-1},weights);
 }
 if(!payment)return {kind:'insufficient-funding',goal,cost,hand:p.hand.map(c=>[c.id,c.cardId])};
 for(let i=0;i<payment.energyPurchases;i++)pick(out,'quick_trade',t=>t.tradeId==='credits-for-energy');
 for(let i=0;i<payment.creditPurchases;i++)pick(out,'quick_trade',t=>t.tradeId==='energy-for-credit');
 const rocket=Number(goal.requirementId.split(':')[0]);
 for(const [i,m] of goal.route.path.entries()){
  pick(out,'move',t=>t.rocketId===rocket&&t.deltaX===m.deltaX&&t.deltaY===m.deltaY);
  pick(out,'choose_payment',t=>t.kind==='move-payment'&&(card&&i===0?t.cardIds.length===1&&t.cardIds[0]===card.id:!t.cardIds.length));
 }
 pick(out,'land');
 const target=menu().find(a=>a.family==='choose_target'&&a.target?.landTarget?.satelliteId==='titania'&&a.target?.planetId==='uranus');
 assert(target,JSON.stringify(menu()));out.push(step(target));
 pick(out,'end_turn');
 if(save().session)pick(out,'choose_target',t=>t.tileId==='a');
 assert(!save().session);
 return {kind:'settled',goal,cost,payment,card:card?.cardId||null};
}
try{
 const rows=[];
 for(const row of ref.rows){
  const origin=row.kind==='pass-now'?row.end:row.origin,accepted=[];restore(origin);
  if(row.kind==='land-only'){actual(accepted,109,123);whiteStart(accepted,135);}
  launchWithoutMove(accepted);
  whiteStart(accepted,135);
  actual(accepted,139,141);
  const beforeRoute=assets(save()),beforeRouteEnvelope=save(),result=attempt(accepted);
  const end=save(),settled=assets(end);
  restore(origin);accepted.forEach(step);assert.deepEqual(save(),end);
  rows.push({kind:row.kind,origin,accepted,beforeRoute,beforeRouteEnvelope,result,end,settled});
  const x=a=>[a.wallet.score,a.wallet.credits,a.wallet.energy,a.wallet.publicity,a.wallet.availableData,a.hand.length,a.probes.length,a.income.credits,Object.keys(a.tech.ownedTiles).length];
  console.log(JSON.stringify({kind:row.kind,before:x(beforeRoute),paid:result.kind,cost:result.cost,after:x(settled),turn:settled.turn,
   payment:result.payment,card:result.card,actions:accepted.map(a=>a.summary)}));
 }
 restore(base);
 fs.writeFileSync(out,JSON.stringify({scope:'Same R2 timing comparisons but defer the initial outbound movement until after B101 Orange4; exact Native costs, no future hidden assumptions',rows,nativeReplayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
