'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[source,out]=process.argv.slice(2),rowsIn=read(source).rows,root=rowsIn.find(r=>r.goal==='a0-prefix-38').end,seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{const v=c.lifecycle.restore(e);assert(v.ok,JSON.stringify(v));assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}










const {evaluateStateValue}=load('randomizer/game/ai/state-value');
function step(family,test=()=>true){
 const a=menu().find(x=>x.family===family&&test(x));assert(a,JSON.stringify(menu().map(x=>[x.family,x.summary])));
 return execute(a);
}
function record(label){
 const a=assets(),q=evaluateStateValue(view(),seat);
 return {label,value:q.total,parts:q.components,wallet:a.wallet,income:a.income,computer:a.computer,blue:a.blue,hand:a.hand,trace:a.traceCounts,
  previewScore:a.realized,pending:menu().map(x=>[x.family,x.summary])};
}
try{
 const rows=[];
 for(const species of ['amiba','chong']){
  restore(root);const actions=[],r=[];
  actions.push(step('choose_target',x=>x.target.speciesId===species&&x.target.position===4));r.push(record('after-trace'));
  actions.push(step('choose_card',x=>x.target.source==='display'));r.push(record('after-display'));
  actions.push(step('complete_task',x=>x.summary.includes('dlc_9')));r.push(record('after-task'));
  actions.push(step('end_turn'));r.push(record('next-turn'));
  const end=save();restore(root);actions.forEach(execute);assert.deepEqual(save(),end);
  rows.push({goal:species,actions,stages:r,end,replayExact:true});
 }
 restore(root);
 fs.writeFileSync(out,JSON.stringify({scope:'Same exact pink marker menu and the same task/end, while each side receives its actual original display card.',rows},null,2)+'\n',{flag:'wx'});
 for(const r of rows)console.log(JSON.stringify({species:r.goal,summary:r.stages.map(x=>[x.label,x.value,x.parts])}));
}finally{c.dispose();}
