'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[source,out]=process.argv.slice(2),rowsIn=read(source).rows,root=rowsIn.find(r=>r.goal==='funding-prefix-1').end,seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{const v=c.lifecycle.restore(e);assert(v.ok,JSON.stringify(v));assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}











const clean=x=>JSON.parse(JSON.stringify(x,(k,v)=>/milliseconds/i.test(k)?undefined:v));
function check(e){
 restore(e);const legal=menu(),port=createAnalysisPort({composition:c,seatId:seat,maxCacheEntries:0});
 try{
  const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:legal}).search;
  assert(q.complete&&!q.unresolved.length&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600);
  assert.deepEqual(save(),e);
  return {action:legal.find(a=>a.actionId===q.actionId),value:q.value,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,
    quotes:q.lines.flatMap(r=>r.knownTransportPreparation?[r.knownTransportPreparation]:[]),roots:clean(q.roots),lines:clean(q.lines)};
 }finally{port.close();}
}
const mut=fn=>{const e=structuredClone(root),s=JSON.parse(e.committedState);fn(s,s.players.players.find(p=>p.id===seat));e.committedState=JSON.stringify(s);return e;};
try{
 const rows=[];
 const collect=(label,e,test)=>{const q=check(e);test(q);rows.push({label,q});return q;};
 const original=collect('before-research',root,q=>{
  assert.equal(q.action.family,'research_tech');assert.equal(q.value,173.5);assert.equal(q.quotes.length,1);
  assert.equal(q.quotes[0].publicPaymentCard,'card-62-0');
  assert.deepEqual(q.quotes[0].route.knownYellowTrace,{slotId:2,position:2,score:5});
  const lines=q.lines.flatMap(l=>l.edges||[]);
  assert(lines.some(e=>e.resourcePlan?.goal.swapOutId==='card-64-0'&&e.cost===6&&e.goalStatus==='boundary'));
 });
 collect('cold-native-paid-research-menu',rowsIn.find(r=>r.goal==='funding-prefix-2').end,q=>{
  assert.equal(q.action.target.tileId,'orange1');assert.equal(q.value,173.5);
  assert.equal(q.quotes[0].publicPaymentCard,'card-62-0');
 });
 collect('cold-native-public-reward-menu',rowsIn.find(r=>r.goal==='funding-prefix-3').end,q=>{
  assert.equal(q.action.target.cardInstanceId,'card-60-0');
 });
 collect('hidden',mut(s=>{
  const pile=s.cards.drawPileCardIds;[pile[0],pile[1]]=[pile[1],pile[0]];
  const b=s.tech.stacks.orange1.bonusQueue;[b[1],b[2]]=[b[2],b[1]];
  const f=s.aliens.chong.initialConfiguration.fossilOrder;
  const j=s.aliens.chong.planetFossilIds.jupiter,t=s.aliens.chong.planetFossilIds.saturn,j0=j[0],t0=t[0];
  assert.deepEqual(s.aliens.chong.fossilsById[j0].visibleToPlayerIds,[]);assert.deepEqual(s.aliens.chong.fossilsById[t0].visibleToPlayerIds,[]);
  j[0]=t0;t[0]=j0;s.aliens.chong.fossilsById[j0].planetId='saturn';s.aliens.chong.fossilsById[t0].planetId='jupiter';
  s.aliens.chong.initialConfiguration.fossilOrder=f.map(id=>id===j0?t0:id===t0?j0:id);
 }),q=>assert.deepEqual([q.action,q.value,q.n,q.roots,q.lines],[original.action,original.value,original.n,original.roots,original.lines]));
 collect('newly-replaced-card-is-not-funding',mut(s=>{s.cards.publicCards[1]=null;}),q=>assert(!q.quotes.length));
 collect('one-data-missing',mut((s,p)=>{p.dataState.poolTokens.pop();p.resources.availableData--;}),q=>assert(!q.quotes.length));
 collect('another-seat-active',mut(s=>{s.turn.passedPlayerIds=s.turn.passedPlayerIds.filter(id=>id!=='player-green');}),q=>assert(!q.quotes.length));
 restore(root);
 fs.writeFileSync(out,JSON.stringify({scope:'Single same-turn Native preparation; original root, restored paid and reward menus, hidden permutations and unfunded cases.',rows},null,2)+'\n',{flag:'wx'});
 for(const {label,q} of rows)console.log(JSON.stringify([label,q.action.summary,q.value,q.n,q.ms,q.quotes.length]));
}finally{c.dispose();}
