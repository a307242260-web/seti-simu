'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[source,out]=process.argv.slice(2),rowsIn=read(source).rows,root=rowsIn[0].end,seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}





const pc=load('randomizer/game/ai/probe-capital');
const raw=()=>menu().map(a=>[a.family,a.summary,a.target]);
const rootBranch=rowsIn.find(r=>r.goal==='r190-chong9-funded-pink-chong-dlc_25.png');
function control(reward){
 const origin=rootBranch.end;restore(origin);const accepted=[],stages={};
 const one=(f,t=()=>true)=>{
  const a=menu().find(a=>a.family===f&&t(a.target||{},a));assert(a,JSON.stringify({f,menu:raw()}));accepted.push(execute(a));
 };
 const at=n=>{stages[n]={asset:assets(),choices:raw(),end:save()};};
 const held=id=>player().hand.find(c=>c.cardId===id)?.id;
 const goal=pc.requirements(pc.factsFromState(state(),player())).find(g=>g.planetId==='saturn'&&g.endpointFamily==='land'&&g.requirementId.endsWith(':planet'));
 assert.equal(goal.route.cost,2);assert(goal.route.path.every(m=>m.requiredMovePoints===1));
 const [m1,m2]=goal.route.path,rocket=assets().probes[0].id;
 one('move',t=>t.rocketId===rocket&&t.deltaX===m1.deltaX&&t.deltaY===m1.deltaY);
 one('choose_payment',t=>t.kind==='move-payment'&&t.cardIds.length===1&&t.cardIds[0]===held('chong_9.webp'));
 one('play_card',t=>t.cardInstanceId===held('chong_3.webp'));
 at('chong3-free-move-menu');
 one('choose_target',t=>t.rocketId===rocket&&t.deltaX===m2.deltaX&&t.deltaY===m2.deltaY);
 one('choose_target',t=>t.planetId==='saturn'&&t.landTarget?.type==='planet');
 at('yellow-menu');
 if(reward==='amiba')one('choose_target',t=>t.traceType==='yellow'&&t.alienSlotId===1&&t.stateExtra);
 else one('choose_target',t=>t.traceType==='yellow'&&t.speciesId==='chong'&&t.position===4);
 if(menu().some(a=>a.target?.source==='display'))one('choose_card',t=>t.source==='display');
 if(menu().some(a=>a.target?.ruleId==='amiba0-yellow-data'))one('accept_optional_effect',t=>t.ruleId==='amiba0-yellow-data');
 at('actual-fossil-menu');
 const fossil=menu().find(a=>a.target?.fossilId==='fossil_07')||menu().find(a=>a.target?.fossilId);
 assert(fossil,JSON.stringify(raw()));one(fossil.family,t=>t.fossilId===fossil.target.fossilId);
 at('after-cargo');
 const end=save(),after=assets();restore(origin);accepted.forEach(execute);assert.deepEqual(save(),end);restore(origin);
 return {goal:'early-r3-saturn-transport-'+reward,accepted,stages,after,end,originHash:hash(origin),replayExact:true};
}
try{
 const rows=['amiba','chong'].map(control);
 for(const r of rows)console.log(JSON.stringify({goal:r.goal,wallet:r.after.wallet,probes:r.after.probes,tech:Object.keys(r.after.tech.ownedTiles),hand:r.after.hand,realized:r.after.realized,menus:r.stages['actual-fossil-menu'].choices}));
 fs.writeFileSync(out,JSON.stringify({scope:'Use actual held Chong3; one move paid with known Chong9, the second from Chong3. Choose only actually exposed fossil at landing.',rows},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
