'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[source,out]=process.argv.slice(2),rowsIn=read(source).rows,root=rowsIn[0].end,seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}




const pc=load('randomizer/game/ai/probe-capital');
const raw=()=>menu().map(a=>[a.family,a.summary,a.target]);
function control(row,pickCard){
 const origin=row.end;restore(origin);const accepted=[],stages={};
 const one=(f,t=()=>true)=>{
  const a=menu().find(a=>a.family===f&&t(a.target||{},a));assert(a,JSON.stringify({f,menu:raw()}));accepted.push(execute(a));
 };
 const at=n=>{stages[n]={asset:assets(),choices:raw(),routes:pc.requirements(pc.factsFromState(state(),player())).filter(g=>g.endpointFamily==='land'&&['saturn','jupiter'].includes(g.planetId)).map(g=>[g.planetId,g.requirementId,g.route]),end:save()};};
 const held=id=>player().hand.find(c=>c.cardId===id)?.id;
 const shown=id=>state().cards.publicCards.find(c=>c?.cardId===id)?.id;
 const place=(target,slot)=>{
  one('place_data');one('choose_target',t=>t.target===target&&(!slot||t.blueSlot===slot));
 };
 one('end_turn');
 one('research_tech');one('choose_target',t=>t.tileId==='orange1');
 one('choose_card',t=>t.cardInstanceId===shown(pickCard));
 const knownData=shown('dlc_17.png');assert(knownData);
 one('industry',t=>t.abilityId==='deepspace_swap_cards');
 one('choose_card',t=>t.cardInstanceId===held('b_16.webp'));
 one('choose_card',t=>t.cardInstanceId===knownData);
 one('card_corner',t=>t.cardInstanceId===held('dlc_17.png'));
 place('computer');place('blueBonus',2);one('choose_card',t=>t.cardInstanceId===shown('dlc_20.png'));one('end_turn');
 at('after-orange1');
 const rocket=assets().probes[0].id,moveCard=held(pickCard==='dlc_20.png'?pickCard:'chong_2.webp');
 assert(moveCard);
 const move=(dx,dy,card)=>{
  one('move',t=>t.rocketId===rocket&&t.deltaX===dx&&t.deltaY===dy);
  one('choose_payment',t=>t.kind==='move-payment'&&t.cardIds.length===1&&t.cardIds[0]===card);
 };
 move(0,1,moveCard);
 if(assets().wallet.publicity<6){
  const source=held('amiba_9.webp')||held('dlc_25.png');
  if(source)one('card_corner',t=>t.cardInstanceId===source);
 }
 at('before-blue-research');
 if(assets().wallet.publicity>=6){
  one('research_tech');one('choose_target',t=>t.tileId==='blue1'&&t.blueSlot===3);
  place('blueBonus',3);
  at('after-blue1');one('end_turn');at('next-main');
 }
 const end=save(),after=assets();restore(origin);accepted.forEach(execute);assert.deepEqual(save(),end);restore(origin);
 return {goal:row.goal+'-'+pickCard,originHash:hash(origin),accepted,stages,after,end,replayExact:true};
}
try{
 const rows=[control(rowsIn[0],'dlc_25.png')];
 for(const r of rows)console.log(JSON.stringify({goal:r.goal,steps:r.accepted.length,stages:Object.entries(r.stages).map(([k,{asset:a,routes}])=>[k,a.wallet,a.hand.map(x=>x[1]),routes.map(x=>[x[1],x[2].cost])])}));
 fs.writeFileSync(out,JSON.stringify({scope:'From the A0-first scan funding, swap a known unneeded B16 for a real visible data corner, keeping two otherwise discarded cards.',rows},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
