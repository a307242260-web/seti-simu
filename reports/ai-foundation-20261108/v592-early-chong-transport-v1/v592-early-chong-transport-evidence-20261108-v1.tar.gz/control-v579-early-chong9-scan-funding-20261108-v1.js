'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[ledger,source,out]=process.argv.slice(2),ref=read(ledger),root=read(source).rows[1].end,seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}



const raw=()=>menu().map(a=>[a.family,a.summary,a.target]);
function control(species){
 restore(root);const accepted=[],stages={};
 const one=(f,t=()=>true)=>{
  const a=menu().find(a=>a.family===f&&t(a.target||{},a));assert(a,JSON.stringify({f,menu:raw()}));accepted.push(execute(a));
 };
 const at=n=>{stages[n]={asset:assets(),choices:raw(),end:save()};};
 const held=id=>player().hand.find(c=>c.cardId===id)?.id;
 one('quick_trade',t=>t.tradeId==='cards-for-energy');
 const use=[held('chong_7.webp'),held('b_16.webp')];
 for(const id of use)one('choose_payment',t=>t.kind==='discard-hand-card'&&t.cardInstanceId===id);
 if(save().session)one('choose_payment',t=>t.kind==='confirm'||t.confirm);
 at('after-energy');
 one('end_turn');
 one('scan');
 one('choose_target',t=>t.nebulaId==='sector-3-a');
 one('choose_card',t=>t.cardInstanceId==='card-61-0'&&t.nebulaId==='sector-3-a');
 at('pink-menu');
 one('choose_target',t=>t.speciesId===species&&t.position===4);
 one('choose_card',t=>t.source==='display'&&t.choiceId.startsWith(species+':'));
 if(menu().some(a=>a.target?.ruleId==='amiba0-pink-data'))one('accept_optional_effect',t=>t.ruleId==='amiba0-pink-data');
 if(menu().some(a=>a.target?.ruleId==='dlc9-three-sector-wins'))one('complete_task',t=>t.ruleId==='dlc9-three-sector-wins');
 at('after-pink');
 const end=save(),after=assets();restore(root);accepted.forEach(execute);assert.deepEqual(save(),end);restore(root);
 return {goal:'r190-chong9-funded-pink-'+species,accepted,stages,after,end,replayExact:true};
}
try{
 const rows=['chong','amiba'].map(control);
 for(const r of rows)console.log(JSON.stringify({goal:r.goal,after:r.after.wallet,hand:r.after.hand,off:r.after.knownChongOffer,trace:r.after.traceCounts}));
 fs.writeFileSync(out,JSON.stringify({scope:'From actual Chong blue9, fund known shortfall with two held cards, compare two known pink rewards at exact scan.',rootHash:hash(root),rows},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
