'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[ledger,out]=process.argv.slice(2),ref=read(ledger),root=ref.rows.find(r=>r.step===172).origin,seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}


const refAction=i=>ref.rows.find(r=>r.step===i).action;
const options=()=>menu().map(a=>[a.family,a.summary,a.target]);
function arm(trace){
 restore(root);const accepted=[],stages={};
 const take=a=>{assert(a,JSON.stringify(options()));const x=execute(a);accepted.push(x);return x;};
 const one=(f,t=()=>true)=>take(menu().find(a=>a.family===f&&t(a.target||{},a)));
 const formal=(from,to)=>{for(let i=from;i<=to;i++){const w=refAction(i),a=menu().find(a=>a.actorId===w.actorId&&a.family===w.family&&JSON.stringify(a.target)===JSON.stringify(w.target)); if(!a)throw Error(JSON.stringify({i,expected:w.target,choices:options()}));take(a);}};
 const at=label=>{stages[label]={asset:assets(),menu:options(),end:save()};};
 const display=species=>one('choose_card',t=>t.source==='display'&&t.choiceId.startsWith(species+':'));
 const put=(target,slot)=>{one('place_data');one('choose_target',t=>t.target===target&&(!slot||t.blueSlot===slot));};
 formal(179,179);at('a0-symbol');one('choose_target',t=>t.region==='blue'&&t.slotId==='blue_3');formal(181,185);
 formal(172,174);one('choose_target',t=>t.alienSlotId===2&&t.traceType==='pink');
 if(menu().some(x=>x.target?.ruleId==='amiba0-pink-data'))one('accept_optional_effect',t=>t.ruleId==='amiba0-pink-data');
 at('after-dlc19-pink');one('end_turn');
 if(save().session)one('choose_target',t=>t.choiceId==='final:b');
 formal(186,189);at('analysis-trace');
 if(trace==='amiba')formal(190,190);else one('choose_target',t=>t.speciesId==='chong'&&t.position===9);
 display(trace);one('end_turn');at('after-analysis');
 formal(193,203);at('after-cash-income');
 if(assets().wallet.availableData)formal(204,205);
 else {
  const shortage=assets().wallet.energy<2;
  if(shortage&&assets().wallet.credits>=3)one('quick_trade',t=>t.tradeId==='credits-for-energy');
 }
 at('scan-funding');
 if(assets().wallet.energy>=2&&assets().wallet.credits>=1){
  formal(210,213);at('second-pink');
  const target=menu().find(x=>x.target?.speciesId===trace&&x.target?.position===4);
  assert(target,JSON.stringify(options()));take(target);
  display(trace);
  if(menu().some(x=>x.target?.ruleId==='amiba0-pink-data'))one('accept_optional_effect',t=>t.ruleId==='amiba0-pink-data');
  at('after-second-pink');
  if(menu().some(x=>x.target?.ruleId==='dlc9-three-sector-wins'))formal(217,217);
  at('after-task');
 }
 const end=save(),after=assets();
 restore(root);accepted.forEach(execute);assert.deepEqual(save(),end);restore(root);
 return {goal:'r172-a0-first-'+trace,accepted,stages,after,end,replayExact:true};
}
try{
 const rows=[arm('chong')];
 for(const r of rows)console.log(JSON.stringify({goal:r.goal,steps:r.accepted.length,stages:Object.entries(r.stages).map(([k,{asset:a}])=>[k,a.wallet,a.hand.map(h=>h[1]),a.market,a.knownChongOffer])}));
 fs.writeFileSync(out,JSON.stringify({scope:'Exchange the order of the A0 and DLC19 mains; check actual A0 pink data, exact research/income and second scan with known Chong reward.',rootHash:hash(root),rows},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
