'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[source,out]=process.argv.slice(2),root=read(source).end,seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}






const outRows=[];
function control(choice){
 restore(root);const accepted=[],stages={};
 const one=(f,t=()=>true)=>{
  const a=menu().find(a=>a.family===f&&t(a.target||{},a));
  assert(a,JSON.stringify({f,menu:menu().map(a=>[a.family,a.summary,a.target])}));accepted.push(execute(a));
 };
 const saveAt=n=>stages[n]={asset:assets(),end:save(),choices:menu()};
 saveAt('delivery');
 one('place_data');one('choose_target',t=>t.target==='computer');
 one('analyze');saveAt('analysis-menu');
 if(choice==='chong')one('choose_target',t=>t.speciesId==='chong'&&t.position===8);
 else one('choose_target',t=>t.speciesId==='amiba'&&t.position===3);
 if(menu().some(x=>x.target?.source==='display'))one('choose_card',t=>t.source==='display');
 saveAt('analysis-completed');
 const after=assets(),end=save();restore(root);accepted.forEach(execute);assert.deepEqual(save(),end);restore(root);
 return {goal:'delivery-analysis-'+choice,accepted,after,stages,end,replayExact:true};
}
try{
 const rows=['chong','amiba'].map(control);
 for(const r of rows)console.log(JSON.stringify({goal:r.goal,wallet:r.after.wallet,final:r.after.realized,hand:r.after.hand,computer:r.after.computer,blue:r.after.blue,turn:r.after.turn}));
 fs.writeFileSync(out,JSON.stringify({scope:'Actual delivered cargo funds one already reachable free analysis. Compare two visible blue trace rewards after Native delivery.',rows},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
