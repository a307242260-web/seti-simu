'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[ledger,controls,out]=process.argv.slice(2),ref=read(ledger),root=ref.rows.find(r=>r.step===172).origin,seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}




const fixed=read(controls).rows[0].accepted;
const clean=x=>JSON.parse(JSON.stringify(x,(k,v)=>/milliseconds/i.test(k)?undefined:v));
const raw=()=>menu().map(a=>[a.family,a.summary,a.target]);
function mask(order){
 const e=structuredClone(root),s=JSON.parse(e.committedState);
 assert(!s.aliens.chong.revealInitialized&&e.session===null);
 if(order){
  const deck=s.aliens.chong.initialConfiguration.cardDeck,ordinary=s.cards.drawPileCardIds;
  if(order===1)[deck[0],deck[4]]=[deck[4],deck[0]];
  else [deck[2],deck[5]]=[deck[5],deck[2]];
  [ordinary[0],ordinary[1]]=[ordinary[1],ordinary[0]];
 }
 e.committedState=JSON.stringify(s);return e;
}
function quote(e){
 restore(e);const legal=menu(),observation=view(),port=createAnalysisPort({composition:c,seatId:seat,maxCacheEntries:0});
 try{
  const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:legal}).search;
  assert(q.complete&&!q.unresolved.length&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600);
  assert.deepEqual(save(),e);
  return {legal,observation,selected:q.actionId,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,
   roots:q.roots,lines:clean(q.lines)};
 }finally{port.close();}
}
function control(origin,order){
 restore(origin);const accepted=[],stages={};
 const take=(family,p=()=>true)=>{
  const a=menu().find(x=>x.family===family&&p(x.target||{},x));
  assert(a,JSON.stringify({family,menu:raw()}));accepted.push(execute(a));
 };
 const same=a=>take(a.family,(t,x)=>x.actorId===a.actorId&&JSON.stringify(t)===JSON.stringify(a.target||{}));
 const at=n=>{stages[n]={asset:assets(),end:save(),choices:raw()};};
 if(order==='a0-first'){
  fixed.slice(0,7).forEach(same);at('first');
  fixed.slice(7,14).forEach(same);
 }else if(order==='scan-first-amiba'){
  for(let i=172;i<=185;i++){
   const w=ref.rows.find(r=>r.step===i).action;
   same(w);if(i===178)at('first');
  }
 }else{
  fixed.slice(7,11).forEach(same);take('end_turn');take('choose_target',t=>t.choiceId==='final:b');
  at('first');fixed.slice(0,7).forEach(same);
 }
 const end=save(),after=assets();
 restore(origin);accepted.forEach(execute);assert.deepEqual(save(),end);restore(origin);
 return {order,accepted,stages,end,after,replayExact:true};
}
try{
 const variants=[];
 for(let i=0;i<=2;i++){
  const origin=mask(i),q=quote(origin);
  if(i){
   const b=variants[0].q;assert.deepEqual(q.observation,b.observation);assert.deepEqual(q.legal,b.legal);
   assert.deepEqual([q.selected,q.n,q.roots,q.lines],[b.selected,b.n,b.roots,b.lines]);
  }
  const rows=['a0-first','scan-first-second','scan-first-amiba'].map(o=>control(origin,o));
  assert.equal(rows[0].after.wallet.availableData-rows[1].after.wallet.availableData,1);
  variants.push({i,origin,originHash:hash(origin),q,rows});
 }
 for(const v of variants)console.log(JSON.stringify({mask:v.i,n:v.q.n,rows:v.rows.map(r=>[r.order,r.after.wallet,r.after.hand.map(h=>h[1]),r.after.knownChongOffer,r.after.realized])}));
 fs.writeFileSync(out,JSON.stringify({scope:'Exact R172 same two mains, two reveal orders for same species plus recorded Amiba first; swap only hidden cards, compare Native public root and whole decision graph.',variants},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
