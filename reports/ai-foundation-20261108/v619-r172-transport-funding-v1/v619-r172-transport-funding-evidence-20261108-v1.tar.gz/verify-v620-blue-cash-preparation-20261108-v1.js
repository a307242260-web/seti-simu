'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[source,out]=process.argv.slice(2),rowsIn=read(source).rows,root=rowsIn.find(r=>r.goal==='funding-prefix-19').end,seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{const v=c.lifecycle.restore(e);assert(v.ok,JSON.stringify(v));assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}







const clean=x=>JSON.parse(JSON.stringify(x,(k,v)=>/milliseconds/i.test(k)?undefined:v));
function quote(e){
 restore(e);const legal=menu(),viewBefore=view(),p=createAnalysisPort({composition:c,seatId:seat,maxCacheEntries:0});
 try{
  const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:legal}).search;
  assert(q.complete&&!q.unresolved.length&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600);
  assert.deepEqual(save(),e);
  const plan=q.lines[0].resourcePolicy?.plans?.find(x=>x.goal?.knownTransport)||null;
  return {legal,observation:viewBefore,plan,action:q.actionId,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,lines:clean(q.lines),roots:q.roots};
 }finally{p.close();}
}
try{
 const a=quote(root);assert(a.plan?.goal.blueSlot===3);
 const samples=[{label:'exact',root,q:a}];
 const mask=structuredClone(root),s=JSON.parse(mask.committedState),pile=s.cards.drawPileCardIds,fossils=s.aliens.chong,{jupiter,saturn}=fossils.planetFossilIds;
 [pile[0],pile[1]]=[pile[1],pile[0]];
 const x=jupiter[0],y=saturn[0];assert.deepEqual(fossils.fossilsById[x].visibleToPlayerIds,[]);assert.deepEqual(fossils.fossilsById[y].visibleToPlayerIds,[]);
 jupiter[0]=y;saturn[0]=x;fossils.fossilsById[x].planetId='saturn';fossils.fossilsById[y].planetId='jupiter';
 fossils.initialConfiguration.fossilOrder=fossils.initialConfiguration.fossilOrder.map(v=>v===x?y:v===y?x:v);
 mask.committedState=JSON.stringify(s);const b=quote(mask);
 assert.deepEqual([a.legal,a.observation,a.lines,a.roots,a.action,a.n],[b.legal,b.observation,b.lines,b.roots,b.action,b.n]);
 samples.push({label:'hidden',root:mask,q:b});
 restore(root);const start=menu().find(a=>a.family==='place_data');assert(start);
 execute(start);const pending=save(),p=quote(pending);
 assert(p.plan?.goal.blueSlot===3&&p.legal.find(a=>a.actionId===p.action)?.target?.blueSlot===3);
 samples.push({label:'cold-slot-choice',root:pending,q:p});
 for(const mode of ['no-supplier','no-plain-payer','other-active']){
  const e=structuredClone(root),s=JSON.parse(e.committedState),p=s.players.players.find(x=>x.id===seat);
  if(mode==='other-active')s.turn.passedPlayerIds=s.turn.passedPlayerIds.filter(id=>id!=='player-green');
  else {const id=mode==='no-supplier'?'chong_3.webp':'dlc_20.png';p.hand=p.hand.filter(c=>c.cardId!==id);p.resources.handSize=p.hand.length;}
  e.committedState=JSON.stringify(s);const q=quote(e);assert.equal(q.plan,null);
  samples.push({label:mode,root:e,q});
 }
 restore(root);
 for(const v of samples)console.log(JSON.stringify([v.label,v.q.n,v.q.ms,v.q.action,v.q.plan?.goal.knownTransport]));
 fs.writeFileSync(out,JSON.stringify({scope:'Exact Native post-research cash prep, two hidden domains changed without search effects; cold pending slot and absent source/payer/solo turn controls.',samples},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
