'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[source,out]=process.argv.slice(2),rowsIn=read(source).rows,root=rowsIn[0].end,seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{const v=c.lifecycle.restore(e);assert(v.ok,JSON.stringify(v));assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}





const pc=load('randomizer/game/ai/probe-capital');
const raw=()=>menu().map(a=>[a.family,a.summary,a.target]);
const rootBranch=rowsIn.find(r=>r.goal==='r172-a0-first-chong-dlc_25.png');

const clean=x=>JSON.parse(JSON.stringify(x,(k,v)=>/millisecond|timingMs/i.test(k)?undefined:v));
function disguise(origin,pair){
 const out=structuredClone(origin),s=JSON.parse(out.committedState),a=s.aliens.chong,{saturn,jupiter}=a.planetFossilIds;
 assert.equal(out.session,null);
 for(const [si,ji] of pair){
  const x=saturn[si],y=jupiter[ji];
  assert.deepEqual(a.fossilsById[x].visibleToPlayerIds,[]);assert.deepEqual(a.fossilsById[y].visibleToPlayerIds,[]);
  saturn[si]=y;jupiter[ji]=x;a.fossilsById[x].planetId='jupiter';a.fossilsById[y].planetId='saturn';
  a.initialConfiguration.fossilOrder=a.initialConfiguration.fossilOrder.map(id=>id===x?y:id===y?x:id);
 }
 assert.deepEqual(a.initialConfiguration.fossilOrder.slice(0,6),[...jupiter,...saturn]);
 out.committedState=JSON.stringify(s);return out;
}
function quote(e){
 restore(e);
 const observation=view(),legal=menu(),port=createAnalysisPort({composition:c,seatId:seat,maxCacheEntries:0});
 try{
  const result=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:legal}),q=result.search;
  assert(q.complete&&q.unresolved.length===0&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600);
  assert.deepEqual(save(),e);
  const line=q.lines[0].edges.find(x=>x.resourcePlan?.goal.embeddedMove);
  return {observation,legal,ms:q.rootAndSearchMilliseconds,n:q.diagnostics.nativeExecutions,actionId:q.actionId,value:q.value,
   goal:line?.resourcePlan?.goal||null,graph:clean({lines:q.lines,roots:q.roots,unresolved:q.unresolved,selectionPlan:q.selectionPlan,diagnostics:q.diagnostics})};
 }finally{port.close();}
}
try{
 const origin=rootBranch.end,b=quote(origin),arms=[{goal:'same-actual-fossils',end:origin,quote:b}];
 assert(b.goal?.planetId==='saturn'&&b.n>0);
 for(const [i,pairs] of [[[0,0]],[[1,1],[2,2]]].entries()){
  const e=disguise(origin,pairs),m=quote(e);
  assert.deepEqual(m.observation,b.observation);assert.deepEqual(m.legal,b.legal);
  assert.deepEqual(m.graph.lines,b.graph.lines);assert.deepEqual(m.graph.roots,b.graph.roots);
  assert.deepEqual([m.n,m.actionId,m.value,m.goal],[b.n,b.actionId,b.value,b.goal]);
  arms.push({goal:'mask-'+(i+1),end:e,quote:m});
 }
 for(const mode of ['fee','payment']){
  const e=structuredClone(origin),s=JSON.parse(e.committedState),p=s.players.players.find(p=>p.id===seat);
  if(mode==="fee"){p.resources.credits=0;p.blueBonusResources.credits=0;}else {p.hand=p.hand.filter(c=>c.cardId!=='dlc_20.png');p.resources.handSize=p.hand.length;}
  e.committedState=JSON.stringify(s);const m=quote(e);assert.equal(m.goal,null);arms.push({goal:'missing-'+mode,end:e,quote:m});
 }
 restore(origin);
 for(const r of arms)console.log(JSON.stringify([r.goal,r.quote.n,r.quote.ms,r.quote.value,r.quote.goal?.id]));
 fs.writeFileSync(out,JSON.stringify({scope:'Cold exact root and two substitutions of still-hidden fossils; real legal menus, graph, identity and limits; remove separately fee or spare move source as controls.',rows:arms},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
