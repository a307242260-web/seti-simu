'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const z=require('node:zlib'),[fixture,trace,cargo,out]=process.argv.slice(2),root=read(fixture).compositionEnvelope,seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}




const traceRows=fs.readFileSync(trace,'utf8').trim().split('\n').map(x=>JSON.parse(x));
const by=new Map(traceRows.map(x=>[x.to,x]));
function paths(){
 return traceRows.filter(x=>x.summary==='结算 b_117.webp').flatMap(x=>{
  const p=[];let n=x.from;
  while(by.has(n)){const z=by.get(n);p.push(z);n=z.from;}
  return n===0?[p.reverse()]:[];
 });
}
const sig=a=>[a.family,a.target];
const translate=z=>{const a=menu().find(x=>JSON.stringify(sig(x))===JSON.stringify(sig(z)));assert(a,JSON.stringify(z));return a;};
function policy(){
 const before=save(),port=createAnalysisPort({composition:c,seatId:seat,maxCacheEntries:0});
 try{
  port.setResourcePlanning(true);port.setDecisionPlanning(true);
  const node=port.openRoot(),r=port.localDecisionSpec(node);
  assert.deepEqual(save(),before);return r;
 }finally{port.close();}
}
try{
 const rows=[];
 for(const raw of paths()){
  restore(root);const fixed=raw.map(x=>execute(translate(x)));
  const origin=save(),before=assets(),proof=policy(),alternatives=[];
  assert.equal(proof?.reason,'greedy-free-known-task-score-credit');
  for(const choice of menu()){
   restore(origin);const accepted=[execute(choice)],after=assets(),end=save();
   restore(origin);accepted.forEach(execute);assert.deepEqual(save(),end);
   alternatives.push({summary:choice.summary,target:choice.target,after,end});
  }
  const [yes,no]=alternatives.sort((a,b)=>Number(a.target.choiceId.startsWith('skip:'))-Number(b.target.choiceId.startsWith('skip:')));
  assert.equal(yes.after.wallet.score-no.after.wallet.score,3);
  assert.equal(yes.after.wallet.credits-no.after.wallet.credits,1);
  for(const k of ['hand','income','tech','computer','blue','probes','signals','traceCounts'])assert.deepEqual(yes.after[k],no.after[k]);
  rows.push({originHash:hash(origin),fixed,origin,before,proof,alternatives});
 }
 assert.equal(rows.length,4);
 const carry=read(cargo).rows[0];restore(carry.origin);execute(carry.accepted[0]);
 const negative={origin:save(),proof:policy(),offers:menu()};
 assert(negative.offers.some(a=>a.target?.choiceId?.endsWith(':b117-orbit-land-count-task')));
 assert.notEqual(negative.proof?.reason,'greedy-free-known-task-score-credit');
 restore(root);
 fs.writeFileSync(out,JSON.stringify({scope:'Direct Native confirm/skip comparison on each existing live known end task; active cargo negative control keeps native choice.',rows,negative},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({rows:rows.length,claimGain:[3,1],cargoPreservesChoice:true}));
}finally{c.dispose();}
