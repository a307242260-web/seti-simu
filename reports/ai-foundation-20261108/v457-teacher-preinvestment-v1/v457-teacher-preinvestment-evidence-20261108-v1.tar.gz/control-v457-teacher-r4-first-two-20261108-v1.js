'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n));
const {createSeededRandom}=load('randomizer/game/random');
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation');
const [checkpoint,history,out]=process.argv.slice(2),source=JSON.parse(fs.readFileSync(checkpoint));
const original=source.coreState.compositionEnvelope,historical=JSON.parse(fs.readFileSync(history)).replaySteps,seat='player-white';
const seed=JSON.parse(original.committedState).meta.seed;
const native=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,w)=>buildRuleObservation(s,seed,w?.playerId)});
native.newGame({seed});const c=native.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),owner=s=>s.players.players.find(p=>p.id===seat);
function act(w){
 const d=c.inspect().session?.decision,v=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(v);assert.deepEqual(v.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:v})
  :v.phase==='quick'?c.inputPort.submitQuickAction(v):c.inputPort.submitAction(v);
 assert(r.ok,JSON.stringify(r));return v;
}
function assets(){
 const s=state(),p=owner(s),v=c.projection({role:'player',playerId:seat}).state;
 return {turn:s.turn.turnNumber,round:s.turn.roundNumber,fossilTasks:s.aliens.chong.transportTasksByRocketId,completedFossils:s.aliens.chong.completedTransports,tech:p.techState,probes:s.pieces.rockets.filter(r=>r.playerId===seat),wallet:p.resources,hand:p.hand.map(c=>c.cardId),reserved:p.reservedCards.map(c=>c.cardId),
  income:p.income,computer:p.dataState.placedTokens.filter(t=>t.placementKind==='computer').length,blue:p.dataState.placedTokens.filter(t=>t.placementKind==='blueBonus').length,
  pending:c.inspect().session?.decision?.kind,projectedFinal:v.publicState.players.find(x=>x.playerId===seat).finalScore};
}
try{
 restore(original);
 const start=assets(),accepted=[],whiteTurns=[];
 for(let i=245;i<=264;i++){
  const w=historical[i-1].action;
  const a=act(w);accepted.push(a);
  if(a.actorId===seat&&(a.family==='end_turn'||i===246))whiteTurns.push({historicalInput:i,asset:assets(),end:save()});
 }
 const end=save();restore(original);accepted.forEach(act);assert.deepEqual(save(),end);restore(original);
 fs.writeFileSync(out,JSON.stringify({scope:'R3 teacher pre-PASS to first two actual R4 white mains, current Native actions and RNG',start,accepted,whiteTurns,end,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({start,rows:whiteTurns.map(r=>[r.historicalInput,r.asset])}));
}finally{c.dispose();}
