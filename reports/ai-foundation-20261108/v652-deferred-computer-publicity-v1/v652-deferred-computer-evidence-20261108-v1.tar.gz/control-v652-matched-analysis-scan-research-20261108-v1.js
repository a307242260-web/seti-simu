'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const [fixture,scanRef,analysisRef,out]=process.argv.slice(2),root=read(fixture).compositionEnvelope;
const seat='player-white',seed=JSON.parse(root.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{const v=c.lifecycle.restore(e);assert(v.ok,JSON.stringify(v));assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}











function input(family,test=()=>true){
 const a=menu().find(a=>a.family===family&&test(a));assert(a,family);return execute(a);
}

const ordered=(label,origin)=>{
 restore(origin);const actions=[],stages=[];
 const take=(family,valid=()=>true)=>{const a=menu().find(a=>a.family===family&&valid(a.target,a));
   assert(a,JSON.stringify({family,menu:menu().map(x=>[x.family,x.summary,x.target])})); actions.push(execute(a));};
 const append=a=>actions.push(execute(a));
 const at=name=>stages.push({name,actionCount:actions.length,assets:assets()});
 if(label==='scan-first'){
   const planned=read(scanRef).row.accepted.slice(0,35).map(x=>x.action);
   assert.deepEqual(planned.filter(x=>x.phase==='main').map(x=>x.family),['scan','analyze','research_tech']);
   planned.forEach((a,i)=>{append(a);if([14,30,34].includes(i))at(['scan','analyze','research'][[14,30,34].indexOf(i)]);});
 }else{
   take('analyze');
   const planned=read(analysisRef).row.accepted.slice(0,20).map(x=>x.action);
   assert.deepEqual(planned.filter(x=>x.phase==='main').map(x=>x.family),['research_tech','scan']);
   planned.forEach((a,i)=>{append(a);if(i===2||i===16)at(i===2?'analyze':'research');});
   take('choose_target',t=>t.choiceId==='trace:1:pink:amiba:4');
   take('choose_card',t=>t.choiceId==='amiba:display:9');
   take('complete_task',t=>t.cardInstanceId==='card-15-0'&&t.ruleId==='dlc9-three-sector-wins');
   take('end_turn');at('scan');
 }
 const end=save(),after=assets();assert(!end.session);
 restore(origin);actions.forEach(execute);assert.deepEqual(save(),end);restore(origin);
 return {label,actions,stages,end,after,replayExact:true};
};
function mask(index){
 const e=structuredClone(root),s=JSON.parse(e.committedState);
 assert(!e.session&&s.aliens.chong.displayedCardIndex===9&&s.aliens.amiba.displayedCardIndex===9);
 if(index){
   const deck=s.aliens.chong.cardDeck,ordinary=s.cards.drawPileCardIds;
   [deck[0],deck[index]]=[deck[index],deck[0]];
   [ordinary[0],ordinary[index]]=[ordinary[index],ordinary[0]];
   e.committedState=JSON.stringify(s);
 }
 return e;
}
const retained=a=>[a.wallet,a.income,a.tech,a.hand,a.reserve,a.computer,a.blue,a.probes,a.sectorWins,a.signals,a.traceCounts,a.marks,a.realized,a.turn,a.market.slice(0,2)];
try{
 const rows=[];
 for(const index of [0,1,2]){
   const origin=mask(index);restore(origin);const obs=view(),legal=menu();
   if(index){assert.deepEqual(obs,rows[0].obs);assert.deepEqual(legal,rows[0].legal);}
   const sides=['scan-first','analysis-first'].map(label=>ordered(label,origin));
   if(index)for(let i=0;i<2;i++){assert.deepEqual(retained(sides[i].after),retained(rows[0].sides[i].after));assert.deepEqual(sides[i].actions,rows[0].sides[i].actions);}
   rows.push({index,origin,obs,legal,sides});
 }
 assert.deepEqual(rows[0].sides.map(r=>r.after.turn),[[3,12],[3,12]]);
 for(const r of rows[0].sides)console.log(JSON.stringify({order:r.label,inputs:r.actions.length,after:r.after.wallet,income:r.after.income,hand:r.after.hand,computer:r.after.computer,blue:r.after.blue,established:r.after.realized,turn:r.after.turn,stages:r.stages.map(s=>[s.name,s.assets.wallet,s.assets.realized])}));
 fs.writeFileSync(out,JSON.stringify({scope:'Same three R3 mains with same publicly offered Amiba9 and Chong9, same scanner and two signals, same sector, and same DLC9 task. Only payment and order may differ. Future Chong and ordinary cards are not read by either fixed policy.',rows},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
