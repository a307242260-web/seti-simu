'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),hash=require('node:crypto');
const read=n=>JSON.parse(fs.readFileSync(n)),load=n=>require(path.resolve(n));
const [ledgerFile,branchFile,out]=process.argv.slice(2),ledger=read(ledgerFile),branch=read(branchFile);
const git=(p)=>cp.execFileSync('git',['--git-dir=/Users/bilibili/code/seti-simu/.git','show','e0abae4c4:'+p],{maxBuffer:20*1024*1024});
const opening=JSON.parse(git('reports/ai-foundation-20261023/human405-white-only-opening-20261030-v1.checkpoint.json'));
const savePath='seti-saves/seti-save-research-ai-search-v649-white-first3-20261108-b8beae1c-quick-400-v115.json';
const ref=JSON.parse(git(savePath)),seat='player-white',seed=JSON.parse(opening.coreState.compositionEnvelope.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {createSeededRandom}=load('randomizer/game/random'),{buildRuleObservation}=load('randomizer/app/rule-observation');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});
k.newGame({seed});const c=k.composition,get=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const key=a=>JSON.parse(JSON.stringify([a.schemaVersion,a.actionId,a.actorId,a.family,a.phase,a.target,a.payload]));
const sha=x=>hash.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const scope=(e)=>JSON.parse(JSON.stringify(e,(k,v)=>typeof v==='string'&&e.session?.session?.sessionId&&(v===e.session.session.sessionId||v.startsWith(e.session.session.sessionId+':'))?
  'active-session'+v.slice(e.session.session.sessionId.length):v));
function execute(expected){
 const a=menu().find(a=>a.actionId===expected.actionId&&a.actorId===expected.actorId);assert(a);assert.deepEqual(key(a),key(expected));
 const d=c.inspect().session?.decision,result=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(result.ok,JSON.stringify(result.error));return a;
}
function restore(e){assert(c.lifecycle.restore(e).ok);assert.deepEqual(get(),e);}
try{
 const rows=[];restore(opening.coreState.compositionEnvelope);
 assert.deepEqual(ref.replaySteps.slice(0,23).map(r=>key(r.action)),opening.replaySteps.map(r=>key(r.action)));
 for(let index=23;index<175;index++){
  const step=index+1, recorded=ref.replaySteps[index].action;
  if([172,175].includes(step)){
   const before=get(),expected=ledger.rows.find(x=>x.step===step);assert.deepEqual(scope(before),scope(expected.origin));
   assert.deepEqual(key(recorded),key(expected.action));
   const obs=c.projection({role:'player',playerId:seat}).state;
   assert.equal(obs.publicState.board.aliens.slots.filter(x=>x.revealed).length,1);
   const row={step,goal:'r'+step+'-standard',end:before,legal:menu(),recorded,publicState:obs.publicState,selfState:obs.selfState,hash:sha(before)};
   rows.push(row);
   if(step===175){
    const alternative=branch.rows.find(r=>r.goal==='r175-reveal-second');execute(alternative.action);
    assert.deepEqual(scope(get()),scope(alternative.end));row.verifiedRevealSuccessor=get();restore(before);
   }
  }
  execute(recorded);
 }
 assert.equal(rows.length,2);
 fs.writeFileSync(out,JSON.stringify({scope:'Original V649 standard record with Native replay from 23-input opening and cross-version equality; R175 alternative explicitly verified as fixed control.',savePath,rows},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(rows.map(r=>[r.step,r.recorded.summary,r.legal.length,r.hash])));
}finally{c.dispose();}
