'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=p=>require(path.resolve(p)),read=p=>JSON.parse(fs.readFileSync(p)),hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const [source,out,label]=process.argv.slice(2),ref=read(source),direct=label==='only-blue1',initial=direct?ref.origin:(ref.branches||ref.rows).find(x=>(x.label||x.goal)===label)?.end;
assert(initial&&!['formal-blue3'].includes(label));const seat='player-white',seed=JSON.parse(initial.committedState).meta.seed;
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition'),{createSeededRandom}=load('randomizer/game/random');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const {passiveAgent}=load('tools/research-human405-round1');
const chong=load('randomizer/game/aliens/chong'),data=load('randomizer/game/data');
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,view=(pid=seat)=>c.projection({role:'player',playerId:pid}).state,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),player=()=>state().players.players.find(p=>p.id===seat);
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function execute(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const v=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(v.ok,JSON.stringify(v));return a;
}
function assets(){
 const p=player(),s=state(),v=view();
 return {wallet:p.resources,income:p.income,tech:p.techState,hand:p.hand.map(c=>[c.id,c.cardId]),reserve:p.reservedCards.map(c=>[c.id,c.cardId]),
  computer:data.listComputerPlacedTokens(p).map(t=>t.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(t=>t.blueSlot),probes:s.pieces.rockets.filter(x=>x.playerId===seat),
  sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],signals:Object.entries(s.data.nebulae).map(([id,x])=>[id,x.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  traceCounts:v.selfState.traceCounts,aliens:v.publicState.board.aliens,marks:s.finalScoring,realized:v.publicState.players.find(p=>p.playerId===seat).finalScore,
  turn:[s.turn.roundNumber,s.turn.turnNumber],market:s.cards.publicCards.map(x=>x&&[x.id,x.cardId]),knownChongOffer:chong.isChongRevealedSlot(s.aliens,2)?s.aliens.chong.displayedCardIndex:null};
}
function autonomous(origin){
 restore(origin);const start=assets(),accepted=[],stages=[],coldRoots=[],roundEnds={};
 let checkpoint,stop;
 for(let i=0;i<240;i++){
  const e=save(),s=state(),actions=menu(),owner=actions[0]?.actorId;
  assert([2,3].includes(s.turn.roundNumber)&&actions.length&&actions.every(a=>a.actorId===owner));
  if(owner!==seat){
   const r=passiveAgent(owner).decide({legalActions:actions,observation:view(owner)}),a=actions.find(x=>x.actionId===r.actionId);
   assert(a);accepted.push({action:execute(a),passive:true,round:s.turn.roundNumber});continue;
  }
  const port=createAnalysisPort({composition:c,seatId:seat,maxCacheEntries:0});
  try{
   const agent=createSearchAgent({seatId:seat,analysisPort:port});if(checkpoint)agent.loadCheckpoint(checkpoint);
   const r=agent.decide({seatId:seat,legalActions:actions}),q=r.search,chosen=actions.find(x=>x.actionId===q.actionId);
   const n=q.diagnostics.nativeExecutions,ms=q.rootAndSearchMilliseconds;
   assert.deepEqual(save(),e);
   const over=!q.complete||q.unresolved.length||n>256||ms>600;
   if(over||['scan','research_tech','play_card','analyze','land','pass'].includes(chosen?.family)&&!e.session){
    coldRoots.push({index:i+1,action:chosen,asset:assets(),before:e,n,ms,value:q.value,diagnostics:q.diagnostics,
     roots:q.roots.map(r=>[actions.find(a=>a.actionId===r.actionId)?.summary,r.value,r.realization,r.completion])});
   }
   if(over){stop={reason:'gate',n,ms,selected:chosen?.summary,complete:q.complete};break;}
   assert(chosen);
   if(chosen.family==='pass'){
    roundEnds[s.turn.roundNumber]={asset:assets(),envelope:e};
    if(s.turn.roundNumber===3){stop={reason:'settled-before-pass',n,ms};break;}
   }
   checkpoint=structuredClone(agent.createCheckpoint());
   const input=execute(chosen);
   accepted.push({action:input,round:s.turn.roundNumber,n,ms,value:q.value});
   if(input.family==='end_turn'&&!save().session)stages.push({input:i+1,asset:assets(),checkpoint:save()});
  }finally{port.close();}
 }
 assert(stop);
 const end=save(),after=assets();
 restore(origin);accepted.forEach(r=>execute(r.action));assert.deepEqual(save(),end);restore(origin);
 return {start,accepted,stages,coldRoots,roundEnds,stop,after,end,replayExact:true};
}
try{
 let origin=initial,fixed=null;
 if(direct){restore(initial);fixed=execute(menu().find(x=>x.target?.tileId==='blue1'&&x.target?.blueSlot===2));origin=save();restore(initial);}
 const row=autonomous(origin),a=row.after,white=row.accepted.filter(x=>!x.passive);
 fs.writeFileSync(out,JSON.stringify({scope:'On V652 prototype policy, independently resume a pre-research Native control, keep default passive opponents; stop before the first unqualified decision or R3 PASS.',source,label,originHash:hash(origin),origin,fixed,row},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({label,stop:row.stop,inputs:row.accepted.length,maxN:Math.max(row.stop.n,...white.map(x=>x.n)),maxMs:Math.max(row.stop.ms,...white.map(x=>x.ms)),
  wallet:a.wallet,income:a.income,tech:Object.keys(a.tech.ownedTiles),hand:a.hand.map(h=>h[1]),computer:a.computer,blue:a.blue,probes:a.probes.map(r=>[r.id,r.sectorX,r.sectorY,r.fossilId]),realized:a.realized,
  trace:a.traceCounts,roundEnds:Object.fromEntries(Object.entries(row.roundEnds).map(([k,v])=>[k,v.asset.wallet.score])),main:row.coldRoots.map(x=>x.action?.summary)}));
}finally{c.dispose();}
