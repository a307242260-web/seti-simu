from pathlib import Path
import gzip,hashlib,io,json,tarfile
b=Path(__file__).resolve().parent
def read(n):
 p=b/n
 return json.loads(gzip.decompress(p.read_bytes()) if n.endswith('.gz') else p.read_bytes())
def name(n,s='json'):return n+'-20261108-v1.'+s
def h(blob):return hashlib.sha256(blob).hexdigest()
files=set()
def use(n,s='json'):
 k=name(n,s);files.add(k);return read(k) if s in ('json','json.gz') else None
for n in ('control-v483-r227-route-publicity','control-v484-r227-fourth-saturn','control-v458-saturn-to-analysis','control-v485-r227-takeover','control-v486-r227-analysis-traces','control-v486-r227-analysis-cash-floor','capture-v488-cold-swap-menus','measure-v406-gate-root'):
 use(n,'js')
for n,s in [('contract-v487-r227-late-known-swap','md'),('contract-v489-r227-exact-publicity','md'),('v487-known-swap','patch'),('v488-known-swap','patch'),('v489-route-payment','patch'),('v488-targeted-node-verified','log'),('pack-v489-r227-evidence','py')]:
 use(n,s)
for n in ('v480-actual-r227-fixture','v453-matched-r227','v486-r227-analysis-traces','v486-r227-analysis-cash-floor','v484-r227-fourth-saturn','v487-r227-route-before-swap','v487-runtime-manifest','v488-runtime-manifest','v489-runtime-manifest'):
 use(n)
def short(a):return [a['wallet']['score'],a['wallet']['credits'],a['wallet']['energy'],a['wallet']['publicity'],a['wallet']['availableData'],len(a['hand'])]
for n in ('v483-r227-route-publicity','v483-r227-route-publicity-mask'):
 j=use(n);assert j['replayExact'] and j['rootAndRngRestored']
 a,m=j['rows'];assert a['variant']=='saturn' and m['stop']['reason']=='movement-does-not-fund-research'
 assert a['after']['wallet']['score']==116 and a['after']['income']['energy']==4
j=use('v484-r227-fourth-analysis')
assert [short(r['decisions'][-1]['asset']) for r in j['rows']]==[[135,8,0,1,1,3],[135,8,0,2,1,3],[135,6,1,2,0,3],[135,8,1,2,1,3]]
for n in ('v485-r227-takeover','v487-r227-takeover','v487-r227-takeover-mask','v488-r227-takeover','v488-r227-takeover-mask'):
 j=use(n);assert j['replayExact'] and j['rootAndRngRestored']
 assert [r['after']['income']['energy'] for r in j['rows']]==([3,4,4] if n.startswith('v488') else [3,3,4] if n.startswith('v487') else [3,3,3])
 for r in j['rows']:
  assert r['stop']['reason']=='settled-before-pass'
  assert max(a['n'] for a in r['accepted'])<=256 and max(a['ms'] for a in r['accepted'])<=600
for n in ('after-blue1','after-route','after-swap','ready-analysis','pending-outgoing','pending-incoming','missing-credit-supply'):
 use('v488-'+n)
 r=use('v488-'+n+'-cold','json.gz');assert r['complete'] and not r['unresolved'] and r['diagnostics']['nativeExecutions']<=256
for n in ('v488-official-r227','v489-official-r227','v489-after-route','v482-v480-before-swap','v487-v480-route-before-swap','v487-candidate-before-swap'):
 r=use(n+'-cold','json.gz');assert r['complete'] and not r['unresolved']
for ver,steps,val in [('v488',['card_corner:7735e5d3','card_corner:792e4fd7'],174),('v489',['card_corner:ac30be37'],178.5)]:
 r=use(ver+'-after-route-cold','json.gz');assert r['actionId']=='quick_trade:12411a2c'
 e=next(x for x in r['lines'][0]['edges'] if x.get('resourcePlan',{}).get('goal',{}).get('id')=='tech:blue1:3')
 assert e['steps'][:len(steps)]==steps and e['steps'][len(steps)].startswith('research_tech:')
 assert next(x for x in r['roots'] if (x.get('goal') or {}).get('id')=='tech:blue1:3')['value']==val
assert 'SUMMARY unit passed=5 failed=0 total=5' in (b/name('v488-targeted-node-verified','log')).read_text()
idx={'baseSource':'8455b2ceed18ef78b1cdee70ec8603c3b5fbcec4','status':'controlled native proof and isolated candidates only','officialRecord':'reports/research/9534c441.8455b2ce.quick-400.json','files':{n:h((b/n).read_bytes()) for n in sorted(files)},
 'reproduce':['Use V480 runtime, all asset packs and Native API; scripts take fixture paths and a fresh output path.',
 'V483 accepts the R227 fixture, output, optionally mask. V484 takes the prior matched R227 report, V483 output and output path. Then V458 takes the V484 landing report and output path.',
 'For V487, V488 or V489 apply its patch to a separate copy of V480, verify its manifest, then use the V485 checkpoint handover runner and V406 single-root timing tool. V488 cold menu fixtures can be rebuilt from the V488 takeover output.']}
p=b/name('v488-r227-route-and-income-evidence','tar.gz')
with p.open('xb') as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as g,tarfile.open(fileobj=g,mode='w') as t:
 for n,data in [(n,(b/n).read_bytes()) for n in sorted(files)]+[('evidence-index.json',(json.dumps(idx,ensure_ascii=False,indent=2)+'\n').encode())]:
  m=tarfile.TarInfo(n);m.size=len(data);t.addfile(m,io.BytesIO(data))
with tarfile.open(p) as t:assert all(h(t.extractfile(n).read())==x for n,x in idx['files'].items())
print(len(files),p.stat().st_size)
