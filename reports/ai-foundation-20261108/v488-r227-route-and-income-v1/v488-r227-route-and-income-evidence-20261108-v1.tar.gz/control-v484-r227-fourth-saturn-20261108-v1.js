'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n)),read=p=>JSON.parse(fs.readFileSync(p));
const {createSeededRandom}=load('randomizer/game/random'),{createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port');
const {createSearchAgent}=load('randomizer/game/ai/search-agent');
const [matched,advancePath,out]=process.argv.slice(2),ref=read(matched),r3=read(advancePath);
const base=r3.rows[0].root,seat='player-white',seed=JSON.parse(base.committedState).meta.seed;
const sourceState=JSON.parse(base.committedState);
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function act(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===seat);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
 :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(r.ok,JSON.stringify(r));return a;
}
function assets(e){
 const s=e.session?.session?.workingState||JSON.parse(e.committedState),p=s.players.players.find(q=>q.id===seat),
  v=c.projection({role:'player',playerId:seat}).state;
 return {turn:s.turn.turnNumber,wallet:p.resources,income:p.income,hand:p.hand.map(h=>[h.id,h.cardId]),data:p.dataState,tech:p.techState,
  probes:s.pieces.rockets.filter(x=>x.playerId===seat),wins:s.data.sectorSettlements.winsByPlayerId[seat],traces:v.selfState.traceCounts,
  projectedFinal:v.publicState.players.find(q=>q.playerId===seat).finalScore};
}
const pc=load('randomizer/game/ai/probe-capital'),weights=load('randomizer/game/ai/state-value').DEFAULT_WEIGHTS;
function raw(){
 const e=save();
 return e.session?.session?.workingState||JSON.parse(e.committedState);
}
function step(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId);
 assert(a);assert.deepEqual(a.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
 :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(r.ok,JSON.stringify(r));return a;
}
function selection(accepted,f,p=()=>true){
 const a=menu().find(a=>a.family===f&&p(a.target,a));assert(a,JSON.stringify(menu().map(a=>[a.family,a.target])));
 accepted.push(step(a));return a;
}
function getSaturn(){
 const s=raw(),p=s.players.players.find(x=>x.id===seat);
 return pc.requirements(pc.factsFromState(s,p)).find(g=>g.planetId==='saturn'&&g.endpointFamily==='land');
}
function move(accepted,d,card=null){
 selection(accepted,'move',t=>t.rocketId===6&&t.deltaX===d.deltaX&&t.deltaY===d.deltaY);
 selection(accepted,'choose_payment',t=>t.kind==='move-payment'
  &&(card?t.cardIds.length===1&&t.cardIds[0]===card:t.cardIds.length===0));
 assert.equal(save().session,null);
}
function advance(accepted){
 selection(accepted,'pass');
 selection(accepted,'choose_card',t=>t.kind==='pass-reserve-card'&&t.choiceId==='card-30-pass-3-1');
 assert.equal(raw().turn.roundNumber,4);assert.equal(save().session,null);
 for(let i=0;raw().turn.currentPlayerId!==seat||save().session;i++){
  assert(i<20);
  const decision=c.inspect().session?.decision;
  const a=decision?decision.choices.find(x=>x.family==='accept_optional_effect'&&x.target?.choiceId?.startsWith('skip:'))
    ||decision.choices.find(x=>x.family==='choose_card')
    :menu().find(x=>x.family==='pass');
  assert(a,JSON.stringify(menu()));
  accepted.push(step(a));
 }
}
try{
 const variants=ref.rows.map(r=>[r.name,r.end]);
 variants.push(['route-before-research',r3.rows.find(r=>r.variant==='saturn').end]);
 const rows=[];
 for(const [kind,origin] of variants){
  const accepted=[];
  restore(origin);
  const beforeSalary=assets(save());advance(accepted);
  const afterSalary=assets(save()),afterSalaryEnvelope=save();
  const goal=getSaturn();assert(goal);const path=goal.route.path,remaining=goal.route.cost+(goal.endpointFacts.cost.energy||0);
  const paidCard=kind==='research-retain'?'card-62-0':null;
  const need=Math.max(0,remaining-assets(save()).wallet.energy-Number(Boolean(paidCard)));
  for(let i=0;i<need;i++)selection(accepted,'quick_trade',t=>t.tradeId==='credits-for-energy');
  for(let i=0;i<path.length;i++)move(accepted,path[i],i===0?paidCard:null);
  const beforeLanding=assets(save()),landRequirement=getSaturn();
  assert.equal(landRequirement.route.cost,0);
  selection(accepted,'land');
  const conditional=menu().find(a=>a.family==='choose_target'&&a.target.planetId==='saturn'&&!a.target.satelliteId);
  if(conditional)accepted.push(step(conditional));
  const afterLanding=assets(save()),end=save();
  restore(origin);accepted.forEach(step);assert.deepEqual(save(),end);
  rows.push({kind,origin,accepted,afterSalaryEnvelope,beforeSalary,afterSalary,beforeLanding,afterLanding,need,goal,end});
  console.log(JSON.stringify({kind,need,pathCost:goal.route.cost,score:afterLanding.wallet.score,
   beforeLand:[beforeLanding.wallet.credits,beforeLanding.wallet.energy,beforeLanding.wallet.publicity,beforeLanding.wallet.handSize],
   afterLand:[afterLanding.wallet.credits,afterLanding.wallet.energy,afterLanding.wallet.publicity,afterLanding.wallet.handSize]}));
 }
 restore(base);
 fs.writeFileSync(out,JSON.stringify({scope:'Native same PASS card and same Saturn landing after matched formal R227 variants; movement card used only in branch retaining it. Stop at yellow reward.',rows,replayExact:true},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
