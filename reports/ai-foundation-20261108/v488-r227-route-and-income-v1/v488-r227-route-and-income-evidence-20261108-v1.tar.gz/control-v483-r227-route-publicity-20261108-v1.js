'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n));
const {createSeededRandom}=load('randomizer/game/random');
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation');
const {createAnalysisPort}=load('randomizer/game/ai/analysis-port');
const {createSearchAgent}=load('randomizer/game/ai/search-agent');
const pc=load('randomizer/game/ai/probe-capital');
const [fixture,out,mode='normal']=process.argv.slice(2),entry=JSON.parse(fs.readFileSync(fixture));
const seat=entry.seatId,seed=entry.source.seed;
const native=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,w)=>buildRuleObservation(s,seed,w?.playerId)});
native.newGame({seed});const c=native.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),owner=s=>s.players.players.find(p=>p.id===seat);
function act(w){
 const d=c.inspect().session?.decision,v=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(v);assert.deepEqual(v.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:v})
  :v.phase==='quick'?c.inputPort.submitQuickAction(v):c.inputPort.submitAction(v);
 assert(r.ok,JSON.stringify(r));return v;
}
function assets(){
 const s=state(),p=owner(s),v=c.projection({role:'player',playerId:seat}).state;
 return {turn:s.turn.turnNumber,round:s.turn.roundNumber,knownDisplay:s.aliens.amiba.displayedCardIndex,sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],tech:p.techState,probes:s.pieces.rockets.filter(r=>r.playerId===seat),wallet:p.resources,hand:p.hand.map(c=>c.cardId),reserved:p.reservedCards.map(c=>c.cardId),
  income:p.income,computer:p.dataState.placedTokens.filter(t=>t.placementKind==='computer').length,blue:p.dataState.placedTokens.filter(t=>t.placementKind==='blueBonus').length,
  pending:c.inspect().session?.decision?.kind,projectedFinal:v.publicState.players.find(x=>x.playerId===seat).finalScore};
}
try{
 const rows=[];
 const original=entry.compositionEnvelope;restore(original);
 const root=structuredClone(original);
 if(mode==='mask'){
  const obs=buildRuleObservation(state(),seed,seat,menu()),s=JSON.parse(root.committedState);
  const pile=s.cards.drawPileCardIds,deck=s.aliens.amiba.cardDeck;
  [pile[0],pile[4]]=[pile[4],pile[0]];[deck[0],deck[deck.length-1]]=[deck[deck.length-1],deck[0]];
  root.committedState=JSON.stringify(s);restore(root);
  assert.deepEqual(buildRuleObservation(state(),seed,seat,menu()),obs);
 }
 for(const variant of ['saturn','mercury']){
  restore(root);
  const accepted=[],fixed=[],stage=[],start=assets();let stop,agentCheckpoint;
  const pick=(f,p=()=>true)=>{
   const list=menu(),a=list.find(x=>x.family===f&&p(x.target,x));
   assert(a,JSON.stringify(list.map(a=>[a.family,a.summary,a.target])));fixed.push(act(a));return a;
  };
  const hand=card=>owner(state()).hand.find(c=>c.cardId===card);
  const chooseHeld=(f,card)=>{const c=hand(card);assert(c);return pick(f,t=>t.cardInstanceId===c.id);};
  const choosePublic=card=>{const c=state().cards.publicCards.find(c=>c?.cardId===card);assert(c);return pick('choose_card',t=>t.cardInstanceId===c.id||Number.isInteger(t.slotIndex)&&state().cards.publicCards[t.slotIndex]?.id===c.id);};
  const research=(tile,slot)=>{pick('research_tech');pick('choose_target',t=>t.tileId===tile&&(slot==null||t.blueSlot===slot));};
  const place=slot=>{pick('place_data');pick('choose_target',t=>slot?t.target==='blueBonus'&&t.blueSlot===slot:t.target==='computer');};
  const finish=label=>{pick('end_turn');assert(!save().session);stage.push({label,asset:assets(),end:save()});};
  const goal=()=>pc.requirements(pc.factsFromState(state(),owner(state()))).find(g=>g.planetId===variant&&g.endpointFamily==='land');
  const initialRoute=goal().route;
  const direction=initialRoute.path[0];
  pick('move',t=>t.rocketId===6&&t.deltaX===direction.deltaX&&t.deltaY===direction.deltaY);
  pick('choose_payment',t=>t.kind==='move-payment'&&t.cardIds.length===1&&t.cardIds[0]===hand('dlc_20.png')?.id);
  const moveState=assets();
  stage.push({label:'purposeful-move',asset:moveState,end:save(),initialRoute,afterRoute:goal().route});
  if(moveState.wallet.publicity<4){
   const end=save();restore(root);fixed.forEach(act);assert.deepEqual(save(),end);
   rows.push({variant,mode,root,start,fixed,stage,after:moveState,end,accepted,stop:{reason:'movement-does-not-fund-research'}});
   console.log(JSON.stringify({variant,mode,stop:'movement-does-not-fund-research',publicity:moveState.wallet.publicity}));
   continue;
  }
  chooseHeld('card_corner','amiba_9.webp');
  research('blue1',3);place(3);
  assert.equal(assets().wallet.credits,1);finish('blue1-funds-card');
  chooseHeld('play_card','amiba_5.webp');choosePublic('dlc_17.png');
  pick('choose_target',t=>t.slotId==='red_2');
  pick('industry',t=>t.abilityId==='deepspace_swap_cards');
  chooseHeld('choose_card','b_16.webp');choosePublic('dlc_15.png');
  finish('a5-and-known-data');
  stage.push({label:'known-analysis-root',asset:assets(),end:save(),route:goal().route});
  const afterChoice=assets();
  for(let i=0;i<120;i++){
   const e=save(),s=state(),port=createAnalysisPort({composition:c,seatId:seat,maxCacheEntries:0});
   try{
    assert.equal(s.turn.roundNumber,3);
    const list=menu();
    assert(list.every(a=>a.actorId===seat));
    const agent=createSearchAgent({seatId:seat,analysisPort:port});
    if(agentCheckpoint)agent.loadCheckpoint(agentCheckpoint);
    const decision=agent.decide({seatId:seat,legalActions:list}),q=decision.search;
    agentCheckpoint=structuredClone(agent.createCheckpoint());
    assert.deepEqual(save(),e);
    const picked=list.find(x=>x.actionId===decision.actionId);assert(picked);
    const n=q.diagnostics.nativeExecutions,ms=q.rootAndSearchMilliseconds;
    if(!q.complete||q.unresolved.length||n>256||ms>600){stop={reason:'gate',n,ms};break;}
    if(picked.family==='pass'){stop={reason:'settled-before-pass',n,ms};break;}
    const action=act(picked);accepted.push({action,n,ms,value:q.value,after:assets()});
   }finally{port.close();}
  }
  assert(stop);
  const after=assets(),end=save();
  restore(root);fixed.forEach(act);accepted.forEach(x=>act(x.action));assert.deepEqual(save(),end);
  rows.push({mode,variant,root,start,fixed,stage,afterChoice,accepted,after,stop,end});
  console.log(JSON.stringify({mode,variant,stop,n:Math.max(stop.n,...accepted.map(x=>x.n)),ms:Math.max(stop.ms,...accepted.map(x=>x.ms)),
    wallet:after.wallet,income:after.income,projected:after.projectedFinal,probes:after.probes.length,
    tech:Object.keys(after.tech.ownedTiles),hand:after.hand,computer:after.computer,blue:after.blue}));
  }
 restore(original);
 fs.writeFileSync(out,JSON.stringify({scope:'Exact formal R227: fixed one paid step toward a named endpoint before Blue1, use one known data swap, then final analysis; V480 autonomously resolves remaining plans to PASS.',rows,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
