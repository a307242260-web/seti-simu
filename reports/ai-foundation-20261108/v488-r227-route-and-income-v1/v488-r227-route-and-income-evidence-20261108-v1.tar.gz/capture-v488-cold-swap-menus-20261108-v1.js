'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n));
const {createSeededRandom}=load('randomizer/game/random');
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation');
const {createAnalysisPort}=load('randomizer/game/ai/analysis-port');
const {createSearchAgent}=load('randomizer/game/ai/search-agent');
const [fixture,out]=process.argv.slice(2),entry=JSON.parse(fs.readFileSync(fixture));
const seat='player-white',seed=JSON.parse(entry.rows[0].root.committedState).meta.seed;
const native=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,w)=>buildRuleObservation(s,seed,w?.playerId)});
native.newGame({seed});const c=native.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),owner=s=>s.players.players.find(p=>p.id===seat);
function act(w){
 const d=c.inspect().session?.decision,v=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(v);assert.deepEqual(v.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:v})
  :v.phase==='quick'?c.inputPort.submitQuickAction(v):c.inputPort.submitAction(v);
 assert(r.ok,JSON.stringify(r));return v;
}
function assets(){
 const s=state(),p=owner(s),v=c.projection({role:'player',playerId:seat}).state;
 return {turn:s.turn.turnNumber,round:s.turn.roundNumber,knownDisplay:s.aliens.amiba.displayedCardIndex,sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],tech:p.techState,probes:s.pieces.rockets.filter(r=>r.playerId===seat),wallet:p.resources,hand:p.hand.map(c=>c.cardId),reserved:p.reservedCards.map(c=>c.cardId),
  income:p.income,computer:p.dataState.placedTokens.filter(t=>t.placementKind==='computer').length,blue:p.dataState.placedTokens.filter(t=>t.placementKind==='blueBonus').length,
  pending:c.inspect().session?.decision?.kind,projectedFinal:v.publicState.players.find(x=>x.playerId===seat).finalScore};
}
try{
 const q=entry.rows.find(r=>r.cut==='after-a5-before-swap');
 restore(q.root);
 const emit=name=>{
  const target=path.join(out,name+'-20261108-v1.json'),raw=JSON.stringify({seatId:seat,source:{seed},compositionEnvelope:save()})+'\n';
  if(fs.existsSync(target))assert.equal(fs.readFileSync(target,'utf8'),raw);
  else fs.writeFileSync(target,raw,{flag:'wx'});
 };
 const prefix=q.accepted.slice(0,4).map(r=>r.action);
 assert.deepEqual(prefix.map(a=>a.family),['industry','choose_card','choose_card','end_turn']);
 const stages=['pending-outgoing','pending-incoming','after-swap','ready-analysis'];
 prefix.forEach((a,i)=>{act(a);emit('v488-'+stages[i]);});
 restore(q.root);
 const deck=load('randomizer/game/cards/deck');
 const s=state(),p=s.cards.publicCards.findIndex(c=>c.cardId==='dlc_15.png');
 const i=s.cards.drawPileCardIds.indexOf('b_9.webp');
 assert(p>=0&&i>=0);
 const {cardName,src,...instance}=deck.createCardInstance(deck.getCatalogEntryForCard({cardId:'b_9.webp'}),0);
 const old=s.cards.publicCards[p];
 s.cards.publicCards[p]={...instance,id:old.id,faceUp:true};
 s.cards.drawPileCardIds[i]=old.cardId;
 assert(c.lifecycle.restore({...q.root,committedState:JSON.stringify(s)}).ok);
 const canonical=state();
 assert.deepEqual(canonical.cards.publicCards.map(c=>c.cardId),s.cards.publicCards.map(c=>c.cardId));
 assert.deepEqual(canonical.cards.drawPileCardIds,s.cards.drawPileCardIds);
 assert.deepEqual(canonical.meta.rng,s.meta.rng);
 emit('v488-missing-credit-supply');
 restore(q.root);
}finally{c.dispose();}
