'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n));
const {createSeededRandom}=load('randomizer/game/random');
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation');
const {createAnalysisPort}=load('randomizer/game/ai/analysis-port');
const {createSearchAgent}=load('randomizer/game/ai/search-agent');
const [fixture,out,mode='normal']=process.argv.slice(2),entry=JSON.parse(fs.readFileSync(fixture));
const seat=entry.seatId,seed=entry.source.seed;
const native=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,w)=>buildRuleObservation(s,seed,w?.playerId)});
native.newGame({seed});const c=native.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),owner=s=>s.players.players.find(p=>p.id===seat);
function act(w){
 const d=c.inspect().session?.decision,v=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(v);assert.deepEqual(v.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:v})
  :v.phase==='quick'?c.inputPort.submitQuickAction(v):c.inputPort.submitAction(v);
 assert(r.ok,JSON.stringify(r));return v;
}
function assets(){
 const s=state(),p=owner(s),v=c.projection({role:'player',playerId:seat}).state;
 return {turn:s.turn.turnNumber,round:s.turn.roundNumber,knownDisplay:s.aliens.amiba.displayedCardIndex,sectorWins:s.data.sectorSettlements.winsByPlayerId[seat],tech:p.techState,probes:s.pieces.rockets.filter(r=>r.playerId===seat),wallet:p.resources,hand:p.hand.map(c=>c.cardId),reserved:p.reservedCards.map(c=>c.cardId),
  income:p.income,computer:p.dataState.placedTokens.filter(t=>t.placementKind==='computer').length,blue:p.dataState.placedTokens.filter(t=>t.placementKind==='blueBonus').length,
  pending:c.inspect().session?.decision?.kind,projectedFinal:v.publicState.players.find(x=>x.playerId===seat).finalScore};
}
try{
 const root=entry.compositionEnvelope,inputs=[];
 restore(root);
 const pick=(family,pred=()=>true)=>{
   const a=menu().find(a=>a.family===family&&pred(a.target,a));
   assert(a,JSON.stringify(menu().map(a=>a.summary)));
   inputs.push(act(a));return a;
 };
 const held=(family,id)=>pick(family,t=>t.cardInstanceId===owner(state()).hand.find(c=>c.cardId===id)?.id);
 const put=()=>{pick('place_data');pick('choose_target',t=>t.target==='computer');};
 const afterAnalysis=()=>{
  pick('analyze');pick('choose_target',t=>t.speciesId==='amiba'&&t.traceType==='blue'&&t.position===3);
  pick('choose_card',t=>t.source==='display'&&t.cardIndex===2);held('card_corner','amiba_2.webp');
  assert.equal(assets().wallet.availableData,3);for(let i=0;i<3;i++)put();
  assert.equal(assets().wallet.publicity,4);pick('end_turn');
 };
 afterAnalysis();
 pick('industry');held('choose_card','b_16.webp');
 pick('choose_card',t=>t.cardInstanceId===state().cards.publicCards.find(c=>c.cardId==='dlc_15.png').id);
 held('card_corner','dlc_15.png');held('card_corner','amiba_9.webp');
 pick('research_tech');pick('choose_target',t=>t.tileId==='blue1'&&t.blueSlot===3);
 const beforePlace=assets();
 assert.equal(beforePlace.computer,3);assert.equal(beforePlace.wallet.availableData,1);assert.equal(beforePlace.wallet.credits,0);
 pick('place_data');
 const choices=menu();
 assert(choices.some(x=>x.target.target==='computer'));
 assert(!choices.some(x=>x.target.target==='blueBonus'&&x.target.blueSlot===3));
 const minimum=load('randomizer/game/data').getRequiredComputerSlotForBlueBonus(3);assert.equal(minimum,5);
 const end=save();restore(root);inputs.forEach(act);assert.deepEqual(save(),end);restore(root);
 fs.writeFileSync(out,JSON.stringify({scope:'Analysis-first cash prerequisite from the exact R227 root. The slot cannot pay at computer3; choosing computer4 uses the sole pool token.',root,inputs,beforePlace,choices,minimum,end,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({computer:beforePlace.computer,minimum,availableData:beforePlace.wallet.availableData,choices:choices.map(x=>x.summary)}));
}finally{c.dispose();}
