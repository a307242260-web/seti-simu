from pathlib import Path
import gzip,hashlib,io,json,tarfile
b=Path(__file__).parent.resolve()
sha=lambda data:hashlib.sha256(data).hexdigest()
names=set()
def file(n,s):
 f=n+'-20261108-v1.'+s;names.add(f);return (b/f).read_bytes()
def use(n,s='json'):
 q=file(n,s);return json.loads(gzip.decompress(q) if s=='json.gz' else q)
def key(x):
 return json.dumps(x,sort_keys=True,separators=(',',':'))
def norm(x):
 if isinstance(x,dict):return {k:norm(v) for k,v in x.items() if k!='milliseconds'}
 if isinstance(x,list):return list(map(norm,x))
 return x
for n in ('control-v480-analysis-candidate-autonomy','control-v485-r227-takeover','capture-v493-r227-cold-recovery','measure-v406-gate-root'):
 file(n,'js')
for n in ('contract-v490-known-blue-cash-followup','contract-v491-route-funded-research'):
 file(n,'md')
for n,s in [('v495-route-funded-research','patch'),('v495-source-manifest','json'),('pack-v495-r227-route-evidence','py'),('verify-v495-route-funding-browser','py')]:
 file(n,s)
for n in ('v480-actual-r227-fixture','v492-official-r227-mask-fixture','v483-r227-route-publicity','v483-r227-route-publicity-mask','v484-r227-fourth-analysis','v490-r227-takeover','v490-r227-takeover-mask'):
 use(n)
for tag,suffix in [('normal',''),('mask','-mask')]:
 g=use('v495-r227-autonomy'+suffix);assert g['replayExact'] and g['rootAndRngRestored']
 q=g['rows'][0];wallet=q['after']['wallet'];assert [wallet['score'],wallet['energy'],wallet['publicity'],q['after']['income']['energy'],len(q['after']['tech']['ownedTiles']),len(q['after']['probes'])]==[116,1,1,4,6,1]
 assert len(q['accepted'])==31 and q['accepted'][0]['action']['actionId']=='move:c16025a6'
 assert q['stop']['reason']=='settled-before-pass' and max(a['n'] for a in q['accepted'])<=256 and max(a['ms'] for a in q['accepted'])<=600
 v=use('v483-r227-route-publicity'+suffix)['rows'][0]
 assert [a['action'] for a in q['accepted']]==v['fixed']+[a['action'] for a in v['accepted']] and q['end']==v['end']
a=use('v495-official-r227-cold','json.gz');m=use('v495-official-r227-mask-cold','json.gz')
assert norm(a)==norm(m)
assert a['actionId']=='move:c16025a6' and a['value']==190.5 and a['complete'] and not a['unresolved']
assert next(q for q in a['roots'] if q['actionId']=='quick_trade:12411a2c')['value']==190
x=next(q for q in a['roots'] if q['actionId']==a['actionId']);assert x['completion']=='complete'
assert x['goal']['movementFunding']['waitPoints']==3 and x['goal']['movementFunding']['remainingPoints']==2
for n in ('pending-move-payment','after-move','after-publicity-corner','pending-blue-research','after-blue-research','blue-data-input','blue-data-settlement','missing-credit-supply'):
 use('v493-'+n)
 ver='v494' if n in ('blue-data-settlement','missing-credit-supply') else 'v493'
 q=use(ver+'-'+n+'-cold','json.gz')
 assert q['complete'] and not q['unresolved'] and q['diagnostics']['nativeExecutions']<=256
 if n=='missing-credit-supply':assert q['actionId']=='quick_trade:12411a2c' and q['value']==190
 else:assert q['value']==190.5
for n in ('v490-after-route-cold','v490-official-r227-cold','v491-official-r227-cold','v492-official-r227-cold'):
 use(n,'json.gz')
base=use('v494-r227-credit-refill-mask')
bad=use('v494-r227-credit-refill-mask-autonomy')['rows'][0]
good=use('v495-r227-credit-refill-autonomy')['rows'][0]
assert bad['after']['income']['energy']==3 and good['after']['income']['energy']==4
assert good['after']['wallet']['score']==116 and good['accepted'][0]['action']['actionId']=='move:c16025a6'
extra=use('v495-r227-credit-refill-cold','json.gz')
assert [extra['actionId'],extra['value'],extra['diagnostics']['nativeExecutions']]==['move:c16025a6',190.5,90]
negative=use('v495-missing-credit-supply-cold','json.gz')
assert negative['actionId']=='quick_trade:12411a2c' and negative['value']==190 and not any(e.get('resourcePlan',{}).get('goal',{}).get('movementFunding') for e in negative['lines'][0]['edges'])
idx={'scope':'V495 Production candidate and causal control; standard only after source admission.',
 'baseSource':'8455b2ceed18ef78b1cdee70ec8603c3b5fbcec4',
 'files':{n:sha((b/n).read_bytes()) for n in sorted(names)},
 'reproduce':['Extract archive; verify the v495 source manifest after applying its patch to the exact V480 source (all assets required).',
 'Use the v406 cold script with either formal r227 fixture and a fresh output. Use the v480 takeover runner with the same fixture. The v493 capture script accepts the takeover output and destination directory. v483 and v484 controls and frozen original are also in the preceding source evidence.']}
out=b/'v495-r227-route-autonomy-evidence-20261108-v1.tar.gz'
with out.open('xb') as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as gz,tarfile.open(fileobj=gz,mode='w') as t:
 for n,data in [(n,(b/n).read_bytes()) for n in sorted(names)]+[('evidence-index.json',(json.dumps(idx,ensure_ascii=False,indent=2)+'\n').encode())]:
  m=tarfile.TarInfo(n);m.size=len(data);t.addfile(m,io.BytesIO(data))
with tarfile.open(out) as t:assert all(sha(t.extractfile(n).read())==v for n,v in idx['files'].items())
print(len(names),out.stat().st_size)
