'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n));
const {createSeededRandom}=load('randomizer/game/random');
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation');
const scan=load('randomizer/game/actions/scan-effects'),pc=load('randomizer/game/ai/probe-capital'),weights=load('randomizer/game/ai/state-value').DEFAULT_WEIGHTS;
const [source,out]=process.argv.slice(2),from=JSON.parse(fs.readFileSync(source)),seat='player-white';
const seed=JSON.parse(from.rows[0].end.committedState).meta.seed;
const native=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,w)=>buildRuleObservation(s,seed,w?.playerId)});
native.newGame({seed});const c=native.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),owner=s=>s.players.players.find(p=>p.id===seat);
function act(w){
 const d=c.inspect().session?.decision,v=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(v);assert.deepEqual(v.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:v})
  :v.phase==='quick'?c.inputPort.submitQuickAction(v):c.inputPort.submitAction(v);
 assert(r.ok,JSON.stringify(r));return v;
}
function assets(){
 const s=state(),p=owner(s),v=c.projection({role:'player',playerId:seat}).state;
 return {turn:s.turn.turnNumber,round:s.turn.roundNumber,fossilTasks:s.aliens.chong.transportTasksByRocketId,completedFossils:s.aliens.chong.completedTransports,tech:p.techState,probes:s.pieces.rockets.filter(r=>r.playerId===seat),wallet:p.resources,hand:p.hand.map(c=>c.cardId),reserved:p.reservedCards.map(c=>c.cardId),
  income:p.income,computer:p.dataState.placedTokens.filter(t=>t.placementKind==='computer').length,blue:p.dataState.placedTokens.filter(t=>t.placementKind==='blueBonus').length,
  completedTaskCount:p.completedTaskCount,traceCounts:v.selfState.traceCounts,
  pending:c.inspect().session?.decision?.kind,projectedFinal:v.publicState.players.find(x=>x.playerId===seat).finalScore};
}

try{
 const rows=[];
 for(const r of from.rows){
  restore(r.end);const inputs=[],record=[];
  const choose=(family,pred=()=>true)=>{
   const list=menu(),a=list.find(a=>a.family===family&&pred(a.target,a));
   assert(a,JSON.stringify(list.map(a=>[a.family,a.summary,a.target])));inputs.push(act(a));return a;
  };
  const initial=assets();
  choose('choose_target',t=>t.nebulaId==='sector-4-a');
  const first=menu();record.push(first.map(x=>[x.family,x.summary,x.target]));
  choose('choose_card',(t,a)=>a.summary.startsWith('dlc_14.png →'));
  for(let i=0;save().session;i++){
   assert(i<8);
   const list=menu();record.push(list.map(x=>[x.family,x.summary,x.target]));
   const a=list.find(x=>x.target?.traceType&&x.target.stateExtra===true)
     ||list.find(x=>x.target?.choiceId?.startsWith('confirm:trigger:'))
     ||list.find(x=>x.target?.done||x.target?.skip||x.target?.mode==='skip');
   assert(a,JSON.stringify(list.map(x=>[x.family,x.summary,x.target])));inputs.push(act(a));
  }
  choose('end_turn');
  assert(!save().session);
  const end=save(),after=assets();
  restore(r.end);inputs.forEach(act);assert.deepEqual(save(),end);
  rows.push({kind:r.kind,origin:r.end,initial,inputs,after,end,record});
  console.log(JSON.stringify({kind:r.kind,after:after.wallet,projected:after.projectedFinal,actions:inputs.map(x=>x.summary)}));
 }
 restore(from.rows[0].end);
 fs.writeFileSync(out,JSON.stringify({scope:'Same fixed third-main scan and one public card on two already funded R4 branches.',rows,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
