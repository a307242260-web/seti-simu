'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n));
const {createSeededRandom}=load('randomizer/game/random');
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation');
const scan=load('randomizer/game/actions/scan-effects'),pc=load('randomizer/game/ai/probe-capital'),weights=load('randomizer/game/ai/state-value').DEFAULT_WEIGHTS;
const [source,out]=process.argv.slice(2),from=JSON.parse(fs.readFileSync(source)),seat='player-white';
const seed=JSON.parse(from.rows[0].end.committedState).meta.seed;
const native=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,w)=>buildRuleObservation(s,seed,w?.playerId)});
native.newGame({seed});const c=native.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),owner=s=>s.players.players.find(p=>p.id===seat);
function act(w){
 const d=c.inspect().session?.decision,v=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(v);assert.deepEqual(v.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:v})
  :v.phase==='quick'?c.inputPort.submitQuickAction(v):c.inputPort.submitAction(v);
 assert(r.ok,JSON.stringify(r));return v;
}
function assets(){
 const s=state(),p=owner(s),v=c.projection({role:'player',playerId:seat}).state;
 return {turn:s.turn.turnNumber,round:s.turn.roundNumber,fossilTasks:s.aliens.chong.transportTasksByRocketId,completedFossils:s.aliens.chong.completedTransports,tech:p.techState,probes:s.pieces.rockets.filter(r=>r.playerId===seat),wallet:p.resources,hand:p.hand.map(c=>c.cardId),reserved:p.reservedCards.map(c=>c.cardId),
  income:p.income,computer:p.dataState.placedTokens.filter(t=>t.placementKind==='computer').length,blue:p.dataState.placedTokens.filter(t=>t.placementKind==='blueBonus').length,
  completedTaskCount:p.completedTaskCount,traceCounts:v.selfState.traceCounts,
  pending:c.inspect().session?.decision?.kind,projectedFinal:v.publicState.players.find(x=>x.playerId===seat).finalScore};
}

try{
 const rows=[];
 for(const r of from.rows.slice(0,2)){
  restore(r.end);const inputs=[],record=[];
  const choose=(family,pred=()=>true)=>{
   const list=menu(),a=list.find(a=>a.family===family&&pred(a.target,a));
   assert(a,JSON.stringify(list.map(a=>[a.family,a.summary,a.target])));inputs.push(act(a));return a;
  };
  const initial=assets(),s=state(),p=owner(s),cost=scan.getStandardScanCost(p),cash=pc.funding(p.resources,cost,weights);
  if(cash){for(let i=0;i<cash.energyPurchases;i++)choose('quick_trade',t=>t.tradeId==='credits-for-energy');}
  else{
   assert.equal(r.kind,'mercury-land');
   choose('place_data');choose('choose_target',t=>t.target==='computer');
   choose('place_data');choose('choose_target',t=>t.target==='blueBonus'&&t.blueSlot===1);
   assert.equal(assets().wallet.energy,1);
   choose('quick_trade',t=>t.tradeId==='cards-for-energy');
   for(const cardId of ['card-30-pass-3-1','card-70-0'])
    choose('choose_payment',t=>t.cardInstanceId===cardId&&t.select);
   choose('choose_payment',t=>t.confirm===true||t.choiceId==='confirm');
  }
  const funded=assets();
  assert(funded.wallet.energy>=cost.energy&&funded.wallet.credits>=cost.credits);
  choose('scan');
  record.push(menu().map(a=>[a.family,a.summary,a.target]));
  const end=save(),after=assets();
  restore(r.end);inputs.forEach(act);assert.deepEqual(save(),end);
  rows.push({kind:r.kind,origin:r.end,initial,cost,cash,funded,inputs,after,end,record});
  console.log(JSON.stringify({kind:r.kind,cost,cash,funded:funded.wallet,after:after.wallet,menu:record[0].map(x=>x[1])}));
 }
 restore(from.rows[0].end);
 fs.writeFileSync(out,JSON.stringify({scope:'Two exact R4 outcomes, demonstrate cash vs fixed known data/card preparation for the same third main standard scan, stop at first scan menu.',rows,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
