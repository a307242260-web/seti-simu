'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n)),read=p=>JSON.parse(fs.readFileSync(p));
const {createSeededRandom}=load('randomizer/game/random'),{createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port');
const {evaluateStateValue}=load('randomizer/game/ai/state-value');
const [source,official,swapped,plain,out,mode='normal']=process.argv.slice(2),ref=read(source),base=ref.compositionEnvelope,seat='player-white',seed=JSON.parse(base.committedState).meta.seed;
const sourceState=JSON.parse(base.committedState);
const reorder=(a,i,j)=>{assert(a[i]!==a[j]);[a[i],a[j]]=[a[j],a[i]];};
const hidden=mode==='permuted-hidden';
const originalObservation=buildRuleObservation(sourceState,seed,seat);
if(hidden){
 reorder(sourceState.cards.drawPileCardIds,0,8);
 reorder(sourceState.aliens.amiba.cardDeck,0,2);
 reorder(sourceState.tech.stacks.blue1.bonusQueue,1,2);
 assert.deepEqual(buildRuleObservation(sourceState,seed,seat),originalObservation);
}
const origin=hidden?{...base,committedState:JSON.stringify(sourceState)}:base;
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function act(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===seat);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
 :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(r.ok,JSON.stringify(r));return a;
}
function assets(e){
 const s=e.session?.session?.workingState||JSON.parse(e.committedState),p=s.players.players.find(q=>q.id===seat),
  v=c.projection({role:'player',playerId:seat}).state;
 return {turn:s.turn.turnNumber,wallet:p.resources,income:p.income,hand:p.hand.map(h=>[h.id,h.cardId]),data:p.dataState,tech:p.techState,
  probes:s.pieces.rockets.filter(x=>x.playerId===seat),wins:s.data.sectorSettlements.winsByPlayerId[seat],traces:v.selfState.traceCounts,
  projectedFinal:v.publicState.players.find(q=>q.playerId===seat).finalScore};
}
try{
 const ref=read(official),history=read(ref.savePath).replaySteps,expected=read(swapped),rows=[];
 for(const [name,actions,knownExpected] of [
  ['official',history.slice(226,253).map(r=>r.action),null],
  ['research-swap',[...expected.fixed,...expected.accepted.map(x=>x.action)],expected],
  ['research-retain',(()=>{const q=read(plain);return [...q.fixed,...q.accepted.map(x=>x.action)];})(),read(plain)]
 ]){
  restore(origin);
  const checkpoints=[],accepted=[];
  for(const w of actions){
   const a=act(w);accepted.push(a);
   if(a.family!=='end_turn')continue;
   const e=save();assert(!e.session);
   const port=createAnalysisPort({composition:c,seatId:seat,maxCacheEntries:0});
   let value;
   try{value=evaluateStateValue(port.openRoot().observation,seat);}finally{port.close();}
   checkpoints.push({input:accepted.length,asset:assets(e),value,end:e});
  }
  assert.equal(checkpoints.length,3);
  const end=save();
  if(knownExpected&&!hidden)assert.deepEqual(JSON.parse(JSON.stringify(end)),knownExpected.stop.e);
  else if(!knownExpected){
   assert.equal(actions.at(-1).family,'end_turn');
   assert.equal(history[253].action.family,'pass');
  }
  restore(origin);accepted.forEach(act);assert.deepEqual(save(),end);
  rows.push({name,accepted,checkpoints,end});
  console.log(JSON.stringify({name,rounds:checkpoints.map(({asset:s,value:v})=>({turn:s.turn,
   wallet:[s.wallet.score,s.wallet.credits,s.wallet.energy,s.wallet.publicity,s.wallet.availableData],hand:s.hand.map(h=>h[1]),
   income:[s.income.credits,s.income.energy,s.income.handSize,s.income.additionalPublicScan],
   tech:Object.keys(s.tech.ownedTiles).length,computer:s.data.placedTokens.filter(t=>t.placementKind==='computer').length,
   blue:s.data.placedTokens.filter(t=>t.placementKind==='blueBonus').length,final:s.projectedFinal,model:v.total}))}));
 }
 restore(origin);
 fs.writeFileSync(out,JSON.stringify({mode,source:origin,scope:'Formal V445 exact 227 root, three matched Native own-main-action counts. V446 control paths reused, no new autonomous match.',rows,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
