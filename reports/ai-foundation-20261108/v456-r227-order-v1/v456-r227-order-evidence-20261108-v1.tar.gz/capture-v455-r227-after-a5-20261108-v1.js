'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n)),read=p=>JSON.parse(fs.readFileSync(p));
const {createSeededRandom}=load('randomizer/game/random'),{createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port');

const [source,swapped,out,mode='normal']=process.argv.slice(2),ref=read(source),base=ref.compositionEnvelope,seat='player-white',seed=JSON.parse(base.committedState).meta.seed;
const sourceState=JSON.parse(base.committedState);
const reorder=(a,i,j)=>{assert(a[i]!==a[j]);[a[i],a[j]]=[a[j],a[i]];};
const hidden=mode==='permuted-hidden';
const originalObservation=buildRuleObservation(sourceState,seed,seat);
if(hidden){
 reorder(sourceState.cards.drawPileCardIds,0,8);
 reorder(sourceState.aliens.amiba.cardDeck,0,2);
 reorder(sourceState.tech.stacks.blue1.bonusQueue,1,2);
 assert.deepEqual(buildRuleObservation(sourceState,seed,seat),originalObservation);
}
const origin=hidden?{...base,committedState:JSON.stringify(sourceState)}:base;
const k=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,v)=>buildRuleObservation(s,seed,v?.playerId)});k.newGame({seed});
const c=k.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
function act(w){
 const d=c.inspect().session?.decision,a=menu().find(x=>x.actionId===w.actionId&&x.actorId===seat);
 assert(a,w.summary);assert.deepEqual(a.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
 :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
 assert(r.ok,JSON.stringify(r));return a;
}
function assets(e){
 const s=e.session?.session?.workingState||JSON.parse(e.committedState),p=s.players.players.find(q=>q.id===seat),
  v=c.projection({role:'player',playerId:seat}).state;
 return {turn:s.turn.turnNumber,wallet:p.resources,income:p.income,hand:p.hand.map(h=>[h.id,h.cardId]),data:p.dataState,tech:p.techState,
  probes:s.pieces.rockets.filter(x=>x.playerId===seat),wins:s.data.sectorSettlements.winsByPlayerId[seat],traces:v.selfState.traceCounts,
  projectedFinal:v.publicState.players.find(q=>q.playerId===seat).finalScore};
}
try{
 restore(origin);
 const q=read(swapped),first=q.fixed.slice(0,10);first.forEach(act);
 assert.equal(first.at(-1).target.slotId,'red_2');
 assert.equal(menu().find(a=>a.family==='industry').target.abilityId,'deepspace_swap_cards');
 const before=assets(save()),end=save();
 restore(origin);first.forEach(act);assert.deepEqual(save(),end);restore(origin);
 fs.writeFileSync(out,JSON.stringify({seatId:seat,source:{seed,scope:'Exact formal R227, research then public A5; before company/end turn',mode},
 compositionEnvelope:end,before,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
 console.log(before.wallet,before.hand);
}finally{c.dispose();}
