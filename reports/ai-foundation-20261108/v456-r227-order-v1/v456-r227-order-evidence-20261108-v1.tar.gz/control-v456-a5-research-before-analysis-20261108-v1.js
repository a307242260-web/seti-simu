'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const load=n=>require(path.resolve(n));
const {createSeededRandom}=load('randomizer/game/random');
const {createSimulationRuleComposition}=load('randomizer/training/simulation-rule-composition');
const {buildRuleObservation}=load('randomizer/app/rule-observation');
const {createAnalysisPort}=load('randomizer/game/ai/analysis-port');
const {createSearchAgent}=load('randomizer/game/ai/search-agent');
const [comparison,out]=process.argv.slice(2),a=JSON.parse(fs.readFileSync(comparison));
const seat='player-white',seed=JSON.parse(a.rows[0].end.committedState).meta.seed;
const native=createSimulationRuleComposition({seed,random:createSeededRandom(seed),activePlayerCount:4,trustedProjectionReader:true,
 projectCounterfactualState:(s,w)=>buildRuleObservation(s,seed,w?.playerId)});
native.newGame({seed});const c=native.composition,save=()=>c.lifecycle.save().envelope,menu=()=>c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
const restore=e=>{assert(c.lifecycle.restore(e).ok);assert.deepEqual(save(),e);};
const state=()=>save().session?.session?.workingState||JSON.parse(save().committedState),owner=s=>s.players.players.find(p=>p.id===seat);
function act(w){
 const d=c.inspect().session?.decision,v=menu().find(x=>x.actionId===w.actionId&&x.actorId===w.actorId);
 assert(v);assert.deepEqual(v.target,w.target);
 const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:v})
  :v.phase==='quick'?c.inputPort.submitQuickAction(v):c.inputPort.submitAction(v);
 assert(r.ok,JSON.stringify(r));return v;
}
function assets(){
 const s=state(),p=owner(s),v=c.projection({role:'player',playerId:seat}).state;
 return {turn:s.turn.turnNumber,round:s.turn.roundNumber,tech:p.techState,probes:s.pieces.rockets.filter(r=>r.playerId===seat),wallet:p.resources,hand:p.hand.map(c=>c.cardId),reserved:p.reservedCards.map(c=>c.cardId),
  income:p.income,computer:p.dataState.placedTokens.filter(t=>t.placementKind==='computer').length,blue:p.dataState.placedTokens.filter(t=>t.placementKind==='blueBonus').length,
  pending:c.inspect().session?.decision?.kind,projectedFinal:v.publicState.players.find(x=>x.playerId===seat).finalScore};
}
try{
 const rows=[];
 for(const method of ['blue-now','hold-pool']){
  const root=a.rows.find(r=>r.name==='official').checkpoints[0].end;
  restore(root);
  const accepted=[],start=assets(),fixed=[];let stop,agentCheckpoint;
  const pick=(family,predicate=()=>true)=>{
   const list=menu(),x=list.find(a=>a.family===family&&predicate(a.target));
   assert(x,JSON.stringify(list.map(a=>[a.family,a.summary,a.target])));fixed.push(act(x));
  };
  pick('card_corner',t=>t.cardInstanceId==='alien-amiba-9-5');
  pick('card_corner',t=>t.cardInstanceId==='card-60-0');
  pick('research_tech');
  pick('choose_target',t=>t.tileId==='blue1'&&t.blueSlot===3);
  if(method==='blue-now'){
   pick('place_data');pick('choose_target',t=>t.target==='blueBonus'&&t.blueSlot===3);
  }
  pick('end_turn');const first=assets();

  for(let i=0;i<35;i++){
   const e=save(),s=state(),port=createAnalysisPort({composition:c,seatId:seat,maxCacheEntries:0});
   try{
    assert.equal(s.turn.roundNumber,3);
    const list=menu();
    assert(list.every(a=>a.actorId===seat));
    const agent=createSearchAgent({seatId:seat,analysisPort:port});
    if(agentCheckpoint)agent.loadCheckpoint(agentCheckpoint);
    const decision=agent.decide({seatId:seat,legalActions:list}),q=decision.search;
    agentCheckpoint=structuredClone(agent.createCheckpoint());
    assert.deepEqual(save(),e);
    const picked=list.find(x=>x.actionId===decision.actionId);assert(picked);
    const n=q.diagnostics.nativeExecutions,ms=q.rootAndSearchMilliseconds;
    if(!q.complete||q.unresolved.length||n>256||ms>600){stop={reason:'gate',n,ms};break;}
    if(picked.family==='pass'){stop={reason:'settled-before-pass',n,ms};break;}
    const action=act(picked);accepted.push({action,n,ms,value:q.value,after:assets()});
   }finally{port.close();}
  }
  assert(stop);
  const after=assets(),end=save();
  restore(root);fixed.forEach(act);accepted.forEach(x=>act(x.action));assert.deepEqual(save(),end);
  rows.push({method,root,start,first,fixed,accepted,after,stop,end});
  console.log(JSON.stringify({method,stop,n:Math.max(stop.n,...accepted.map(x=>x.n)),ms:Math.max(stop.ms,...accepted.map(x=>x.ms)),
    wallet:after.wallet,income:after.income,projected:after.projectedFinal,probes:after.probes.length,
    tech:Object.keys(after.tech.ownedTiles),actions:accepted.map(x=>x.action.summary)}));
 }
 restore(a.rows[0].end);
 fs.writeFileSync(out,JSON.stringify({scope:'Formal V445 A5 first, fixed research second using A9 and DLC25 as publicity, Native autonomy to R3 pre-PASS.',rows,replayExact:true,rootAndRngRestored:true},null,2)+'\n',{flag:'wx'});
}finally{c.dispose();}
