"""Prepare a clean committed registry and preserve the separate dirty catalog."""
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'reports/ai-foundation-20261119'
runtime = Path(json.loads((DATA / 'v486-random20-runtime-preflight-20261119-v1.json').read_text())['runtime'])
VERSION = 'v486-teaching-current-full-20261119'
parent = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()
paths = ['reports/iteration/versions.json', 'reports/iteration/registry.json', 'reports/robot-iteration.html']
before = {p: (ROOT / p).read_bytes() for p in paths}
sha = lambda b: hashlib.sha256(b).hexdigest()
frozen_versions = json.loads((runtime / paths[0]).read_text())['versions']
entry = copy.deepcopy(next(v for v in frozen_versions if v['id'] == VERSION))
entry.update(name='v486教学盘：272分，策略未改', baseline='ai-search-current-full-baseline-20261118',
             baselineEligible=False,
             summary='现行源码首次固定23输入教学整局：272分，16.426秒，逐轮盘面15/48/118/192。最大256输入/446.740ms，354个行动及四轮Native/RNG与历史272记录精确一致；没有策略改动。')
lib_path = 'tools/robot-iteration-lib.js'
lib = subprocess.check_output(['git', 'show', parent + ':' + lib_path], cwd=ROOT)
assert lib == (ROOT / lib_path).read_bytes() == (runtime / lib_path).read_bytes()
template_path = 'reports/iteration/page-template.html'
template = subprocess.check_output(['git', 'show', parent + ':' + template_path], cwd=ROOT)
base = Path(tempfile.mkdtemp(prefix='seti-teaching-registry-', dir='/private/tmp'))
result = {'parent': parent, 'version': VERSION, 'beforeWorkingHashes': {p: sha(b) for p, b in before.items()},
          'sharedIndexSha256': sha((ROOT / '.git/index').read_bytes()), 'builds': {}}
for kind in ['head', 'working']:
    build = base / kind
    (build / 'tools').mkdir(parents=True)
    (build / 'reports/iteration').mkdir(parents=True)
    (build / lib_path).write_bytes(lib)
    (build / template_path).write_bytes(template)
    (build / 'randomizer').symlink_to(runtime / 'randomizer', target_is_directory=True)
    (build / 'assets').symlink_to(ROOT / 'assets', target_is_directory=True)
    (build / 'seti-saves').symlink_to(ROOT / 'seti-saves', target_is_directory=True)
    (build / 'reports/research').symlink_to(ROOT / 'reports/research', target_is_directory=True)
    (build / '.git').write_text('gitdir: ' + str(ROOT / '.git') + '\n')
    for folder in (ROOT / 'reports/iteration').iterdir():
        if folder.is_dir():
            (build / 'reports/iteration' / folder.name).symlink_to(folder, target_is_directory=True)
    original = json.loads(subprocess.check_output(['git', 'show', parent + ':' + paths[0]], cwd=ROOT)) \
        if kind == 'head' else json.loads(before[paths[0]])
    catalog = copy.deepcopy(original)
    assert not any(v['id'] == VERSION for v in catalog['versions'])
    assert any(v['id'] == entry['baseline'] for v in catalog['versions'])
    catalog['versions'].insert(0, copy.deepcopy(entry))
    assert catalog['versions'][1:] == original['versions']
    (build / paths[0]).write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + '\n')
    env = dict(os.environ, GIT_INDEX_FILE=str(build / 'private-index'), GIT_OPTIONAL_LOCKS='0')
    subprocess.run(['git', 'read-tree', parent], cwd=ROOT, env=env, check=True, capture_output=True)
    script = "const lib=require('./tools/robot-iteration-lib');const r=lib.buildRegistry({generateReports:false});console.log(JSON.stringify({versions:r.registry.versions.length,generated:r.generated.length}));"
    completed = subprocess.run(['node', '-e', script], cwd=build, env=env, capture_output=True, text=True, timeout=120)
    assert completed.returncode == 0, completed.stderr
    metadata = json.loads(completed.stdout.strip())
    assert metadata['generated'] == 0
    registry = json.loads((build / paths[1]).read_text())
    version = next(v for v in registry['versions'] if v['id'] == VERSION)
    assert version['aiGeneration'] == 'v2' and version['baselineEligible'] is False
    assert version['completeness']['record'] and version['completeness']['save'] and version['completeness']['report']
    assert len(version['results']) == 1 and version['results'][0]['terminal']
    assert version['results'][0]['scores']['player-white'] == 272
    assert version['results'][0]['scoreSource'] == 'save-final'
    if kind == 'working':
        assert set(registry) == set(json.loads(before[paths[1]]))
        html = before[paths[2]].decode()
        start = html.index('const ALL_REGISTRY = ') + len('const ALL_REGISTRY = ')
        _, count = json.JSONDecoder().raw_decode(html[start:])
        encoded = json.dumps(registry, ensure_ascii=False, indent=2).replace('<', '\\u003c')
        updated = html[:start] + encoded + html[start + count:]
        (build / paths[2]).write_text(updated)
        assert updated[:start] == html[:start] and updated[start + len(encoded):] == html[start + count:]
    result['builds'][kind] = {'directory': str(build), 'paths': {p: sha((build / p).read_bytes()) for p in paths},
                             'priorCatalogEntriesPreserved': True, 'metadata': metadata}
for p, content in before.items():
    assert (ROOT / p).read_bytes() == content, p
assert sha((ROOT / '.git/index').read_bytes()) == result['sharedIndexSha256']
output = Path('/private/tmp/seti-teaching-registry-20261119-prepared.json')
assert not output.exists()
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
