'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
const instrumented=path.resolve('randomizer/game/ai/decision-search.js');
const changes=[];
function inject(text,needle,code){
 assert.equal(text.split(needle).length,2,needle);
 return text.replace(needle,code+'\n'+needle);
}
const extensions=Module._extensions['.js'];
Module._extensions['.js']=(m,file)=>{
 if(file!==instrumented)return extensions(m,file);
 let content=fs.readFileSync(file,'utf8');
 content=inject(content,'        const regionNeedsTail=tailKind!==',
  '        globalThis.auditBlueTailAttempt(currentIndex,alternative.resourcePlan,incumbent,transitions,entry.node);');
 content=inject(content,'          let fixed=port.expandResourcePlan',
  '          const auditBlueBefore=alternative.resourcePlan.goal.id==="data:blue:2"?port.getDiagnostics().submissionCount:null;');
 content=inject(content,'          const newInputs=fixed.newSubmissions??fixed.submissions;',
  '          if(auditBlueBefore!==null)globalThis.auditBlueTailCost(currentIndex,alternative.firstActionId,auditBlueBefore,port.getDiagnostics().submissionCount);');
 content=inject(content,'    const roots = root.legalActions.map(action => {','    globalThis.auditBlueTailGraph(nodes, lines);');
 const original='      if (BOUNDARIES.has(node.status) && (!incumbent || value > incumbent.value)) incumbent = { node: index, value };';
 assert(content.includes(original));
 content=content.replace(original,[
  '      if (BOUNDARIES.has(node.status) && (!incumbent || value > incumbent.value)) {',
  '        incumbent = { node: index, value };',
  '        globalThis.auditBlueTailIncumbent(index,value,node.status,transitions);',
  '      }'].join('\n'));
 m._compile(content,file);
};
const {readZ,writeZ,open}=require('./controlled-r3');
const [fixture,output]=process.argv.slice(2);
const seat='player-white',root=readZ(fixture)[9].root,m=open(root);
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const port=createAnalysisPort({composition:m.c,seatId:seat});
const attempts=new Map(),results=[];
globalThis.auditBlueTailAttempt=(index,plan,incumbent,transitions,node)=>{
 if(plan?.goal?.id!=='data:blue:2')return;
 const key=JSON.stringify([index,plan.firstActionId]);
 assert(!attempts.has(key),key);
 attempts.set(key,{incumbent:incumbent&&{...incumbent},transitions,barrier:node.informationBoundary?.code});
};
globalThis.auditBlueTailCost=(index,actionId,before,after)=>{
 const item=attempts.get(JSON.stringify([index,actionId]));
 assert(item);
 item.nativeBefore=before;
 item.nativeInputs=after-before;
};
globalThis.auditBlueTailGraph=(nodes,lines)=>{
 for(const line of lines){
  for(const edge of line.edges){
   if(!edge.continuedBlueTail?.closed)continue;
   const key=JSON.stringify([line.node,edge.actionId]);
   const before=attempts.get(key);
   assert(before,key);
   const leaf=lines[edge.target],direct=line.edges.find(e=>e.actionId.startsWith('end_turn:'));
   assert(direct,key);
   results.push({source:line.node,terminal:edge.target,direct:direct.target,value:leaf.value,directValue:lines[direct.target].value,steps:edge.steps,
    newInputs:edge.newInputs,...before, incumbentStatus:before.incumbent&&nodes[before.incumbent.node].node.status});
  }
 }
};
globalThis.auditBlueTailIncumbent=(index,value,status,n)=>{
 changes.push({index,value,status,n});
};
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);
 assert.deepEqual(m.save(),root);
 assert.equal(results.length,127);
 const isShort=row=>row.steps.length===6&&row.value-row.directValue===1;
 const short=results.filter(isShort);
 assert.equal(short.length,84);
 const summary=group=>({count:group.length,missing:group.filter(x=>!x.incumbent).length,
  strictlyBeaten:group.filter(x=>x.incumbent?.value>x.value).length,equal:group.filter(x=>x.incumbent?.value===x.value).length,
  slackHalf:group.filter(x=>x.incumbent?.value>x.value+.5).length,slackOne:group.filter(x=>x.incumbent?.value>x.value+1).length,
  slackTwo:group.filter(x=>x.incumbent?.value>x.value+2).length,slackFour:group.filter(x=>x.incumbent?.value>x.value+4).length,
  slackEight:group.filter(x=>x.incumbent?.value>x.value+8).length,withNative:group.filter(x=>x.incumbent?.value>x.value&&!x.incumbentStatus?.endsWith('-value')).length,
  atRootWinner:group.filter(x=>x.incumbent?.value===q.value).length,
  nativeCost:group.reduce((sum,x)=>sum+x.nativeInputs,0),
  strictNativeCost:group.filter(x=>x.incumbent?.value>x.value).reduce((sum,x)=>sum+x.nativeInputs,0),
  strictNewSteps:group.filter(x=>x.incumbent?.value>x.value).reduce((sum,x)=>sum+x.newInputs,0)});
 const audit={all:summary(results),short:summary(short),other:summary(results.filter(x=>!isShort(x)))};
 writeZ(output,{results,changes,audit,decision:{actionId:q.actionId,value:q.value,native:q.diagnostics.nativeExecutions,nodes:q.diagnostics.graphNodes,complete:q.complete,ms:q.rootAndSearchMilliseconds}});
 console.log(JSON.stringify({audit,changes},null,2));
}finally{port.close();m.dispose();}
