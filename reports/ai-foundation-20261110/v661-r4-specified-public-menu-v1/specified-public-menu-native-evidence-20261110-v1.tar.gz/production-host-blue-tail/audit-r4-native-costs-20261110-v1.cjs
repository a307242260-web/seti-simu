'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
const instrumented=path.resolve('randomizer/game/ai/analysis-port.js');
const native=[],extensions=Module._extensions['.js'];
const rejected=new WeakMap();
globalThis.auditFixedReject=(session,action,method,source)=>{
 if(session&&action){
  let indexed=rejected.get(session);
  if(!indexed)rejected.set(session,indexed=new Map());
  const key=action.actionId,row=indexed.get(key)||{};
  indexed.set(key,row);
  if(!row[method])row[method]=source;
 }
 return null;
};
globalThis.auditNativeInput=(action,head,session,version,turn)=>{
 const target=action.target||{};
 const selected=head?.payload?.options?.selected;
 const kind=target.tradeId||target.kind||target.actionType||target.ruleId||
   (target.choiceId?.includes(':')?target.choiceId.split(':')[0]:target.choiceId)||null;
 const parent=session?.journal?.actions?.[0]?.action;
 native.push({actionId:action.actionId,family:action.family,summary:action.summary,kind,head:head?.type||null,
   selected:selected??null,mode:head?.payload?.options?.mode??null,target,version,turn,
   parent:parent&&[parent.family,parent.summary,parent.target?.kind||parent.target?.tradeId]||null,
   rejections:session&&rejected.get(session)?.get(action.actionId),
   queue:session?.queue.map(e=>[e.type,e.kind,e.payload?.options?.mode??null]),
   undoFrames:session?.undoFrames.length,irreversible:session?.irreversibleBarrier?.code||null});
};
Module._extensions['.js']=(m,file)=>{
 if(file!==instrumented)return extensions(m,file);
 let code=fs.readFileSync(file,'utf8');
 for(const method of ['previewQuietSpecifiedScan','previewQuietPublicScan','previewFixedBluePickSettlement']){
  const begin=code.indexOf('    function '+method+'('),end=code.indexOf('\n    function ',begin+1);
  assert(begin>=0&&end>begin);
  const part=code.slice(begin,end).split('\n').map((line,i)=>line.replaceAll('return null;',
   'return globalThis.auditFixedReject(stored.envelope.session?.session,action,'+JSON.stringify(method)+','+
   JSON.stringify([i+1,line.trim().slice(0,160)])+');')).join('\n');
  code=code.slice(0,begin)+part+code.slice(end);
 }
 const needle='      submissionCount += 1;';
 assert.equal(code.split(needle).length,2);
 m._compile(code.replace(needle,
  '      globalThis.auditNativeInput(current,head,session,session?.baseVersion,session?.workingState?.turn?.turnNumber);\n'+needle),file);
};
const {readZ,writeZ,open}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const args=process.argv.slice(2),output=args.shift(),seat='player-white',rows=[];
function counts(list,key){
 const m=new Map();
 for(const item of list){const k=key(item);m.set(k,(m.get(k)||0)+1);}
 return [...m].sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0]));
}
while(args.length){
 const fixture=args.shift(),key=args.shift(),root=readZ(fixture)[key].root;
 const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat});
 native.length=0;
 try{
  const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length);
  assert.deepEqual(m.save(),root);
  assert.equal(q.diagnostics.nativeExecutions,native.length);
  const cost=counts(native,e=>[e.family,e.head||e.kind,e.head?e.kind:null,e.mode].filter(Boolean).join(' / '));
  const parents=counts(native,e=>e.parent?e.parent.filter(Boolean).join(' / '):'(stable)');
  const d=port.getDiagnostics();
  const data={key,actionId:q.actionId,value:q.value,native:q.diagnostics.nativeExecutions,nodes:q.diagnostics.graphNodes,ms:q.rootAndSearchMilliseconds,cost,parents,diagnostics:d,actions:[...native]};
  rows.push(data);
  console.log(JSON.stringify({key,native:data.native,nodes:data.nodes,ms:Math.round(data.ms),cost:cost.slice(0,14),
   timings:d.milliseconds??d.timing??null}));
 }finally{port.close();m.dispose();}
}
writeZ(output,rows);
