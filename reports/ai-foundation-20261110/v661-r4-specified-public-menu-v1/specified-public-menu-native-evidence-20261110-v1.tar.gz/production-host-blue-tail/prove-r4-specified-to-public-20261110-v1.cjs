'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),crypto=require('node:crypto');
const {readZ,writeZ,open}=require('./controlled-r3');
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
let code=fs.readFileSync(file,'utf8');
const marker='        provedQuietSpecifiedScans++;';
assert.equal(code.split(marker).length,2);
code=code.replace(marker,[
 '        if(taskSession.queue[1].payload?.options?.mode==="public"){',
 '          globalThis.auditSpecifiedToPublic(stored,requested,nodes.get(child),child);',
 '        }',
 marker
].join('\n'));
mod._compile(code,file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const args=process.argv.slice(2),output=args.shift(),rows=[],snapshots={},decisions=[];
function save(e){const key=crypto.createHash('sha256').update(JSON.stringify(e)).digest('hex');snapshots[key]??=e;return key;}
let key;
globalThis.auditSpecifiedToPublic=(s,a,child,n)=>{
 rows.push({key,proved:true,action:a,family:a.family,target:a.target,barrier:s.informationBarrier??null,
  envelopes:save(s.envelope),nextEnvelope:save(child.envelope),nextBarrier:child.informationBarrier??null,
  nextMenu:n.legalActions.map(x=>[x.family,x.target]),nextEffect:child.envelope.session?.session?.queue[0]?.type,
  nextMode:child.envelope.session?.session?.queue[0]?.payload?.options?.mode});
};
while(args.length){
 const fixture=args.shift();key=args.shift();
 const root=readZ(fixture)[key].root,seat='player-white',m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat});
 try{
  const n=rows.length,q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
  assert(rows.slice(n).every(r=>r.nextEffect==='science_domain_scan_step'&&r.nextMode==='public'));
  decisions.push({key,rows:rows.length-n,n:q.diagnostics.nativeExecutions,nodes:q.diagnostics.graphNodes,value:q.value,actionId:q.actionId});
 }finally{port.close();m.dispose();}
}
writeZ(output,{rows,snapshots,decisions});
console.log(JSON.stringify(decisions));
