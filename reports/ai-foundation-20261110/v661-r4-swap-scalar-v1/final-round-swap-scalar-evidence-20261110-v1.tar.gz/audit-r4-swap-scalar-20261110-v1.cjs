'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),crypto=require('node:crypto');
const [source,official,which,mode,out]=process.argv.slice(2),load=n=>require(path.resolve(n));
const original=Module._extensions['.js'];
const counters={printed:0,swaps:0,offers:0,positive:0,negative:0,shortcut:0,missionQuotes:0,handSensitive:0,sourceQuotes:0};
const audit=mode==='audit';
const legacy=process.argv[7];
globalThis.recordMission=(q)=>{
 counters.shortcut++;counters.handSensitive+=q.sensitive;
 const original=q.quote;return {...q,quote(...args){counters.missionQuotes++;return original(...args);}};
};
globalThis.verifyKnownSwap=(current,previous)=>{
 assert.deepEqual(current,previous);
 counters.swaps++;counters.offers+=current.length;counters.positive+=current.filter(r=>r.gain>0).length;counters.negative+=current.filter(r=>r.gain<0).length;
};
globalThis.verifySourceCapital=(current,previous)=>{
 assert.equal(current,previous);counters.sourceQuotes++;
};
globalThis.verifyPrinted=(actual,expected,card,effects)=>{
 const {hasPlay,preparesIncome,...rest}=actual;const nodes=effects.buildPlayEffects(card);
 assert.deepEqual(rest,expected);assert.equal(hasPlay,nodes.length>0);
 assert.equal(preparesIncome,nodes.some(e=>['card_research_tech','card_income','card_tuck_played_card_to_income','card_discard_any_for_income'].includes(e.type)));
 counters.printed++;
};
if(audit)Module._extensions['.js']=(m,p)=>{
 if(p.endsWith('/randomizer/game/ai/resource-demand.js')){
  let code=fs.readFileSync(p,'utf8');
  const old=fs.readFileSync(path.join(legacy,'randomizer/game/ai/resource-demand.js'),'utf8');
  const a='  function knownSwapPortfolioQuotes(', b='  function movementToolPlan(';
  const c='  function planningCapital(state,p){', d='  function planningAnalysisCapital(';
  const before=old.split(a)[1].split(b)[0].replace('knownSourceCapital??planningCapital(state,p)','knownSourceCapital??previousPlanningCapital(state,p)');
  const fullPlan=old.split(c)[1].split(d)[0];
  assert.equal(code.split(a).length,2);assert.equal(code.split(b).length,2);assert.equal(code.split(c).length,2);
  code=code.replace(a,'  function currentKnownSwapPortfolioQuotes(')
   .replace(c,'  function currentPlanningCapital(state,p){')
   .replace('const mission=probeCapital.prepareFinalRoundSwapMission(state,p);','const mission=globalThis.recordMission(probeCapital.prepareFinalRoundSwapMission(state,p));')
   .replace(b,`  function previousKnownSwapPortfolioQuotes(${before}  function previousPlanningCapital(state,p){${fullPlan}
    function planningCapital(state,p){
     const actual=currentPlanningCapital(state,p);
     globalThis.verifySourceCapital(actual,previousPlanningCapital(state,p));return actual;
    }
    function knownSwapPortfolioQuotes(...args){
     const actual=currentKnownSwapPortfolioQuotes(...args);
     globalThis.verifyKnownSwap(actual,previousKnownSwapPortfolioQuotes(...args));return actual;
    }\n`+b);
  return m._compile(code,p);
 }
 if(p.endsWith('/randomizer/game/ai/card-pick-planning.js')){
  let code=fs.readFileSync(p,'utf8');
  const old=fs.readFileSync(path.join(legacy,'randomizer/game/ai/card-pick-planning.js'),'utf8');
  const a='  function facts(card){', b='  const creditTrade=';
  const prior=old.split(a)[1].split(b)[0];
  code=code.replace(a,'  function currentFacts(card){').replace(b,`  function previousFacts(card){${prior}
   function facts(card){const actual=currentFacts(card);globalThis.verifyPrinted(actual,previousFacts(card),card,effects);return actual;}\n`+b);
  return m._compile(code,p);
 }
 return original(m,p);
};
const {open,seat}=require('./native-late-r3'),agent=load('randomizer/game/ai/search-agent'),
 {createAnalysisPort}=load('randomizer/game/ai/analysis-port');
const fixture=JSON.parse(z.gunzipSync(fs.readFileSync(source))),root=which==='official'?JSON.parse(fs.readFileSync(official)).checkpoint:
 fixture.rows.find(r=>r.summary.i===Number(which)).root;
const m=open(root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=agent.createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 const semantic={actionId:q.actionId,value:q.value,realization:q.realization,preparationDebt:q.preparationDebt,roots:q.roots,lines:q.lines,
  transitions:q.diagnostics.transitions,nativeExecutions:q.diagnostics.nativeExecutions};
 const canonical=x=>Array.isArray(x)?x.map(canonical):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,canonical(x[k])])):x;
 const graph=crypto.createHash('sha256').update(JSON.stringify(canonical(semantic))).digest('hex');
 
 const r={which,mode,graph,counters,ms:q.rootAndSearchMilliseconds,native:q.diagnostics.nativeExecutions,logical:q.diagnostics.transitions,
  eval:q.diagnostics.valueEvaluations,nodes:q.lines.length,rootAndRngExact:true};
 fs.writeFileSync(out,JSON.stringify(r,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(r));
}finally{p.close();m.dispose();}
