'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto'),z=require('node:zlib'),Module=require('node:module');
const [teacher,official,which,out]=process.argv.slice(2);
const orig=Module._extensions['.js'];
const counts={},results={};let extraMs=0;
const key=v=>crypto.createHash('sha256').update(JSON.stringify(v,(_,x)=>x===undefined?{__undefined:true}:Object.is(x,-0)?{__negativeZero:true}:x)).digest('hex');
const brief=({turn,players,cards,pieces,finalScoring},seat)=>{const p=players.players.find(q=>q.id===seat);return {round:turn.roundNumber,thresholds:finalScoring.thresholds,claimed:Object.values(finalScoring.tiles).flatMap(t=>t.marks).filter(m=>m.playerId===seat).map(m=>m.threshold),passed:(turn.passedPlayerIds||[]).includes(seat)||p.passCompletionPending,main:p.mainActionCompleted,w:p.resources,hand:p.hand.map(c=>[c.id,c.cardId]),market:cards.publicCards.map(c=>[c?.id,c?.cardId]),probes:pieces.rockets.filter(q=>q.playerId===seat).map(q=>[q.id,q.kind,q.sectorX,q.sectorY]),spent:p.industryRoundMarkRound===turn.roundNumber};};
function record(kind,data,ms){
 const a=counts[kind]||={calls:0,ms:0};a.calls++;a.ms+=ms;
 (results[kind]||=[]).push(data);
}
globalThis.profileSwap=(label,args,run)=>{
 const at=performance.now(),startExtra=extraMs,result=run(),ms=performance.now()-at-(extraMs-startExtra);
 const beforeExtras=performance.now();
 let data;
 if(label==='swap'){const [state,seat]=args;data={...brief(state,seat),fixed:result?.goal.kind||null,gain:result?.goal.netGain};}
 if(label==='scope'){const [state,seat,outgoing,offered,supplied]=args;data={...brief(state,seat),outgoing:outgoing.id,offered:offered.map(c=>c.id),returned:result.map(r=>[r.card.id,r.gain]),supplied:supplied!==null};}
 if(label==='before'||label==='offer'){const [facts]=args;data={key:key(facts),value:label==='offer'?result.total:result,
  round:facts.round,passing:facts.passing,c:facts.player.credits,e:facts.player.energy,h:facts.hand.map(c=>[c.id,c.cardId]),m:facts.board.publicCards.map(c=>[c?.id,c?.cardId]),main:facts.mainActionCompleted,n:facts.board.rockets.filter(q=>q.playerId===facts.player.id).length};}
 record(label,data,ms);
 extraMs+=performance.now()-beforeExtras;
 return result;
};
Module._extensions['.js']=(m,p)=>{
 let code;
 if(p.endsWith('/randomizer/game/ai/resource-demand.js')){
  code=fs.readFileSync(p,'utf8');
  const a='function knownSwapPortfolioQuotes({state,seatId,outgoing,offered},knownSourceCapital=null){';
  const b='function knownSwapPortfolioQuotes(input,capital=null){const {state,seatId,outgoing,offered}=input;return globalThis.profileSwap("scope",[state,seatId,outgoing,offered,capital],()=>originalKnownSwapPortfolioQuotes(input,capital));}\n  function originalKnownSwapPortfolioQuotes({state,seatId,outgoing,offered},knownSourceCapital=null){';
  const substitutions=[[a,b],['source=valueFacts(state,p),before=knownSourceCapital??planningCapital(state,p)','source=valueFacts(state,p),before=knownSourceCapital??globalThis.profileSwap("before",[source],()=>planningCapital(state,p))'],['return{card:incoming,gain:stateValue.purposeCapital(preview).total-before};','return{card:incoming,gain:globalThis.profileSwap("offer",[preview],()=>stateValue.purposeCapital(preview)).total-before};']];
  for(const [a,b] of substitutions){assert.equal(code.split(a).length,2);code=code.replace(a,b);}
 }else if(p.endsWith('/randomizer/game/ai/card-pick-planning.js')){
  code=fs.readFileSync(p,'utf8');
  const a='function swapIntent(state,seatId,endpoints,outgoingId=null,committed=false,knownSourceCapital=null){';
  assert.equal(code.split(a).length,2);
  code=code.replace(a,'function swapIntent(state,seatId,...rest){return globalThis.profileSwap("swap",[state,seatId],()=>originalSwapIntent(state,seatId,...rest));}\n    '+a.replace('swapIntent','originalSwapIntent'));
 }else return orig(m,p);
 return m._compile(code,p);
};
const load=n=>require(path.resolve(n)),{open,seat}=require('./native-late-r3'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const root=which==='official'?JSON.parse(fs.readFileSync(official)).checkpoint:JSON.parse(z.gunzipSync(fs.readFileSync(teacher))).rows.find(r=>r.summary.i===Number(which)).root;
const m=open(root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 const unique=Object.fromEntries(['before','offer'].map(k=>[k,new Set((results[k]||[]).map(v=>v.key)).size]));
 const report={which,action:q.actionId,value:q.value,counts,unique,native:q.diagnostics.nativeExecutions,results};
 fs.writeFileSync(out,JSON.stringify(report)+'\n',{flag:'wx'});
 console.log(JSON.stringify({...report,results:undefined}));
}finally{p.close();m.dispose();}
