'use strict';
const fs = require('node:fs'), path = require('node:path'), assert = require('node:assert/strict');
const { open, z, seat } = require('./native-late-r3');
const probe = require(path.resolve('randomizer/game/ai/probe-capital'));
const values = require(path.resolve('randomizer/game/ai/state-value'));
const deck = require(path.resolve('randomizer/game/cards/deck'));
const [fixture, out] = process.argv.slice(2);
const { root, end, actions } = JSON.parse(z.gunzipSync(fs.readFileSync(fixture)));
const m = open(root), W = values.DEFAULT_WEIGHTS;
const byTarget = q => q.candidates.find(r => r.id.endsWith(':neptune:triton'));
try {
    const observation = m.owner(seat), facts = probe.factsFromObservation(observation, seat);
    const state = m.state(), own = m.player(), { board } = facts;
    const quote = f => probe.quote({...f, investment: () => 0}, W);
    const mission = probe.prepareFinalRoundSwapMission(state, own);
    const full = quote(facts), old = byTarget(full);
    const publicValue = values.evaluateStateValue(observation, seat).total;
    for (const a of actions) m.apply(a);
    assert.deepEqual(m.save(), end);
    const actual = values.evaluateStateValue(m.owner(seat), seat).total;
    m.restore(root); assert.deepEqual(m.save(), root);
    const results = { funded: old.funded, selected: full.selected, target: old, publicValue, actual,
        swapValue: mission.quote(own.hand, board.publicCards), fullValue: full.value };
    if (out) fs.writeFileSync(out, JSON.stringify(results, null, 2) + '\n', {flag:'wx'});
    console.log(JSON.stringify({funded:old.funded, publicValue, actual, selected:full.selected?.id,
        targetValue:old.value, targetPayment:old.payment, swapValue:results.swapValue}));
    assert(old.funded, 'known exchange can pay the one remaining energy needed for landing');
    assert.deepEqual(old.payment.spend, {credits:0,energy:2});
    assert.equal(old.payment.exchangeCardIds.length, 2);
    assert.equal(old.payment.cornerCardIds.length, 3);
    assert.equal(new Set([...old.payment.exchangeCardIds,...old.payment.cornerCardIds]).size, 5);
    assert(old.payment.cornerCardIds.every(id => deck.getDiscardActionMoveRewardForCard(facts.hand.find(c => c.id === id))?.movementPoints===1));
    assert(old.payment.exchangeCardIds.every(id => !deck.getDiscardActionMoveRewardForCard(facts.hand.find(c => c.id === id))));
    assert.equal(old.value, 19);
    assert.equal(full.selected.id, old.id);
    assert.equal(results.swapValue, full.value);
    assert.equal(values.evaluateStateValue(observation, seat).components.probePotential, full.value);
    assert.deepEqual(full, quote(probe.factsFromState(state, own)));
    assert.equal(byTarget(quote({...facts,uncontestedRound:false})).funded,false);
    assert.equal(byTarget(quote({...facts,pendingNativeEffects:true})).funded,false);
    assert.equal(byTarget(quote({...facts,turnCardBonusCount:1})).funded,false);
    assert.equal(byTarget(quote({...facts,player:{...facts.player,energy:1}})).funded,false);
    const isMove = c => deck.getDiscardActionMoveRewardForCard(c)?.movementPoints===1;
    assert.equal(byTarget(quote({...facts,hand:facts.hand.map(c=>!isMove(c)&&c.id!==old.payment.exchangeCardIds[0]?{...c,hidden:true}:c)})).funded,false);
    const extra = {...facts.hand.find(isMove),id:'additional-known-corner'};
    const withExtra = byTarget(quote({...facts,hand:[...facts.hand,extra]}));
    assert.equal(withExtra.payment.cornerCardIds.length,3,'cannot turn a fourth move icon into landing energy');
    assert.equal(withExtra.payment.exchangeCardIds.length,2);
    let exchangeIndex=0, moveIndex=0;
    for (const action of actions) {
        if (action.target.kind==='discard-hand-card') {
            const id=old.payment.exchangeCardIds[exchangeIndex++];
            m.act('choose_payment',a=>a.target.cardInstanceId===id&&a.target.select);
        } else if (action.target.kind==='move-payment'&&action.target.cardIds?.length) {
            const id=old.payment.cornerCardIds[moveIndex++];
            m.act('choose_payment',a=>a.target.cardIds?.length===1&&a.target.cardIds[0]===id);
        } else m.apply(action);
    }
    assert.equal(exchangeIndex,2);assert.equal(moveIndex,3);
    const result=m.facts();
    assert.equal(result.wallet.score,176);
    assert.equal(result.wallet.energy,0);
    assert.equal(values.evaluateStateValue(m.owner(seat), seat).total,actual);
    m.restore(root);
    assert.deepEqual(m.save(),root);
} finally {
    m.dispose();
}
