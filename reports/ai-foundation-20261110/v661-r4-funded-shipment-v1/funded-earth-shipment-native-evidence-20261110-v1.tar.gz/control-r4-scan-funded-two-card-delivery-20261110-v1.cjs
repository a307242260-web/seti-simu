'use strict';
const fs=require('node:fs'),z=require('node:zlib'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const src=JSON.parse(z.gunzipSync(fs.readFileSync(process.argv[2]))).aiFromTeacher265;
const out={};const coord=(m)=>{const p=m.state().pieces.rockets.find(p=>p.id===6);return p?[p.sectorX,p.sectorY]:null;};
for(const mode of ['skip','use-free','use-free-orthogonal']){
 const m=open(src.root),accepted=[],steps=[],save=(action)=>{accepted.push(action);return action;};
 const act=(family,test)=>save(m.act(family,test)),trade=id=>act('quick_trade',a=>a.target?.tradeId===id);
 const dir=(dx,dy)=>act('choose_target',a=>a.target?.rocketId===6&&a.target.deltaX===dx&&a.target.deltaY===dy);
 const facts=()=>{const x=m.facts();return {turn:x.turn,wallet:x.wallet,hand:x.hand,market:x.market,position:coord(m),rng:x.rng,final:x.final};};
 try{
  for(const a of src.accepted.slice(0,29))save(m.apply(a));
  const start=m.save(),f=facts();
  assert.deepEqual(f.position,[2,3]);assert.equal(f.wallet.energy,0);assert.equal(f.wallet.publicity,3);
  assert.equal(f.market[1][1],'dlc_27.png');assert.equal(f.hand.length,2);
  if(mode==='skip')save(m.apply(src.accepted[29]));
  else if(mode==='use-free')dir(0,-1);
  else dir(-1,0);
  for(const a of src.accepted.slice(30,38))save(m.apply(a));
  const startNext=m.save();steps.push({when:'after-scan-tail',...facts()});
  assert(m.facts().wallet.publicity>=3);
  trade('publicity-for-card');
  act('choose_card',a=>a.target.cardInstanceId===f.market[1][0]);
  const afterPick=m.save();steps.push({when:'after-known-pick',...facts()});
  save(m.play('dlc_27.png'));
  assert.equal(m.facts().wallet.energy,1);
  const afterCard=m.save();steps.push({when:'after-energy-card',...facts()});
  trade('cards-for-energy');
  for(const [id] of f.hand)act('choose_payment',a=>a.target.cardInstanceId===id&&a.target.select);
  act('choose_payment',a=>a.target.confirm);
  const afterTrade=m.save();steps.push({when:'after-known-trade',...facts()});
  assert.equal(m.facts().wallet.energy,2);
  for(const [dx,dy] of mode==='use-free-orthogonal'?[[0,-1],[0,-1]]:[[-1,0],[0,-1]]){
   trade('energy-for-move');dir(dx,dy);
  }
  const beforeClaim=m.save();steps.push({when:'after-two-moves',...facts()});
  const claim=m.menu().find(a=>a.family==='complete_task'&&a.target?.ruleId==='transport');
  assert.equal(Boolean(claim),mode!=='skip');
  if(claim)save(m.apply(claim));
  const afterClaim=m.save();steps.push({when:'after-claim',...facts()});
  act('end_turn');act('pass');
  const terminal=m.save(),s=m.state(),score=s.match.finalScores.find(p=>p.playerId===seat);
  assert(s.turn.gameEnded&&s.match.finalScoringSettled);
  m.restore(src.root);for(const a of accepted)m.apply(a);assert.deepEqual(m.save(),terminal);
  out[mode]={start,startNext,afterPick,afterCard,afterTrade,beforeClaim,afterClaim,terminal,score,accepted,steps,exact:true};
 }finally{m.dispose();}
}
fs.writeFileSync(process.argv[3],z.gzipSync(JSON.stringify(out)+'\n'),{flag:'wx'});
for(const [mode,v] of Object.entries(out))console.log(JSON.stringify({mode,score:v.score,inputs:v.accepted.length,steps:v.steps.map(x=>[x.when,x.turn,x.wallet.energy,x.wallet.credits,x.wallet.publicity,x.wallet.availableData,x.position])}));
