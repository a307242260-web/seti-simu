'use strict';
const path=require('node:path'),fs=require('node:fs'),Module=require('node:module');
const current=Module._extensions['.js'],target=path.resolve('randomizer/game/ai/analysis-port.js');
Module._extensions['.js']=(m,file)=>file===target?m._compile(fs.readFileSync(process.env.SETI_R3_PORT,'utf8'),file):current(m,file);
