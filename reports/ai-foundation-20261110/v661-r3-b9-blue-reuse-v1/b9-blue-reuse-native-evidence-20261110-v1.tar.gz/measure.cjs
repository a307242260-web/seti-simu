'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),Module=require('node:module'),crypto=require('node:crypto');
const [variant,mode,output,...select]=process.argv.slice(2);
const ai=path.resolve('randomizer/game/ai'),file=path.join(ai,'analysis-port.js'),load=Module._extensions['.js'];
let witnesses;
const key=(envelope,action)=>crypto.createHash('sha256').update(JSON.stringify([envelope,action])).digest('hex');
globalThis.captureR3Blue=(a,source,next,node,parent)=>{
 if(!a||!source||!next||!['place_data','choose_target','choose_card','complete_task'].includes(a.family))return;
 const h=source.session?.session?.queue?.[0],t=source.session?.session?.workingState.turn;
 if((t??JSON.parse(source.committedState).turn).roundNumber!==3
    ||a.family==='choose_target'&&a.target?.choiceId!=='data:blueBonus:2'
    ||a.family==='choose_card'&&h?.payload?.blueBonusSource!==true)return;
 witnesses[key(source,a)]={source,a,expected:next,choices:node.legalActions,status:node.status,boundary:node.boundary,prior:parent.status};
};
Module._extensions['.js']=(m,f)=>{
 if(f!==file)return load(m,f);
 let src=fs.readFileSync(variant==='base'?f:path.resolve(variant),'utf8');
 if(mode==='trace'){
  const anchor='    function expand(node, actionId, previewOnly = false) {';
  assert.equal(src.split(anchor).length,2);
  src=src.replace(anchor,`    function expand(node,actionId,previewOnly=false){
      const result=expandUnchecked(node,actionId,previewOnly);
      if(result)globalThis.captureR3Blue(node.legalActions.find(a=>a.actionId===actionId),nodes.get(node)?.envelope,nodes.get(result)?.envelope,result,node);
      return result;
    }
    function expandUnchecked(node, actionId, previewOnly = false) {`);
 }
 return m._compile(src,f);
};
const {readZ,writeZ,open,short}=require('./controlled-r3'),{createAnalysisPort}=require(file),{createSearchAgent}=require(path.join(ai,'search-agent'));
const fixtures=readZ(__dirname+'/early-reveal-orders-20261110-v1.json.gz'),
 shadow=readZ(__dirname+'/early-reveal-hidden-controls-20261110-v1.json.gz'),
 r=readZ(__dirname+'/early-reveal-matched-funding-20261110-v1.json.gz');
const roots={B9:shadow.rows['draw-b9'].rows[0].end,original:r.same.original.cuts.at(-1).envelope,
  dlc17:r.same['draw-dlc17'].cuts.at(-1).envelope,chong8:r.same['display-chong8-next'].cuts.at(-1).envelope,
  beforeYellow:fixtures.fixes[14].origin,beforeBlue9:fixtures.fixes[17].origin};
const official=JSON.parse(fs.readFileSync(__dirname+'/v661-first3-checkpoints.json','utf8'));
for(const [round,row] of Object.entries(official.roundStarts))roots['official-R'+round]=row.envelope;
const results={};
for(const id of select.length?select:Object.keys(roots)){
 const root=roots[id],m=open(root),seat='player-white';
 const port=createAnalysisPort({composition:m.c,seatId:seat});
 witnesses={};
 try{
  const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
  const {actionId,value,roots,edges}=q,a=q.analysis;
  results[id]={root,q:{actionId,value,roots,edges,graph:q.graph,diagnostics:q.diagnostics},ms:q.rootAndSearchMilliseconds,analysis:a,witnesses};
  console.log(id,JSON.stringify({a:m.menu().find(x=>x.actionId===actionId)?.summary,v:value,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,graph:q.diagnostics.graphNodes,
   proved:[a?.provedFinalDataMenuInputs,a?.provedBlueTwoPickInputs,a?.provedBluePickSettlements],captured:Object.keys(witnesses).length}));
 }finally{port.close();m.dispose();}
}
writeZ(output,results);
