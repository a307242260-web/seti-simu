'use strict';
const {isDeepStrictEqual}=require('node:util');
function diff(a,b,root=''){
 if(Object.is(a,b))return [];
 if(typeof a!==typeof b||!a||!b||typeof a!=='object'||Array.isArray(a)!==Array.isArray(b))return [[root,String(a).slice(0,110),String(b).slice(0,110)]];
 const out=[];
 for(const k of new Set([...Object.keys(a),...Object.keys(b)])){
  out.push(...diff(a[k],b[k],root+'/'+k));
  if(out.length>20)break;
 }
 return out;
}
function equivalent(a,b){return isDeepStrictEqual(a,b);}
function normalize(value){
 if(Array.isArray(value))return value.map(normalize);
 if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,k==='committedState'&&typeof v==='string'?normalize(JSON.parse(v)):k==='undoFrames'?[]:normalize(v)]));
 return typeof value==='string'?value.replace(/^effect-session-\d+/,'effect-session-local'):value;
}
module.exports={diff,equivalent,normalize};
