'use strict';
const assert=require('node:assert/strict'),{readZ,open}=require('./controlled-r3');
const {diff,equivalent,normalize}=require('./diff.cjs');
const [file,from='0',to='200']=process.argv.slice(2);
const {witnesses,root}=readZ(file).B9,rows=Object.values(witnesses).slice(Number(from),Number(to)),counts={};
for(const w of rows){
 const m=open(root);
 try {
  assert(m.c.lifecycle.restore(w.source).ok);
  const origin=normalize(m.save()),saved=normalize(w.source);
  if(!equivalent(origin,saved))throw Error(JSON.stringify(['restore',w.a.family,diff(origin,saved)]));
  assert(m.menu().some(a=>a.actionId===w.a.actionId));
  m.apply(w.a);
  const after=m.save();
  const a=normalize(after),b=normalize(w.expected);
  if(!equivalent(a,b))throw Error(JSON.stringify([w.a.family,w.a.summary,diff(a,b)]));
  // When the search deliberately closes on hidden information, its legal set
  // is a filtered subset of the real Production menu, not a new decision.
  const native=new Set(m.menu().map(a=>a.actionId));
  assert(w.choices.every(a=>native.has(a.actionId)),w.a.summary);
  counts[w.a.family]=(counts[w.a.family]||0)+1;
 } finally{m.dispose();}
}
console.log(JSON.stringify({from:Number(from),to:Number(to),verified:rows.length,counts}));
