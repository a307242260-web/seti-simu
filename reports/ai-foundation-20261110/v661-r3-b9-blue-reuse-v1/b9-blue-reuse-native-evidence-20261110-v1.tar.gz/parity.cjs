'use strict';
const assert=require('node:assert/strict'),crypto=require('node:crypto'),{readZ,writeZ}=require('./controlled-r3'),{normalize,diff,equivalent}=require('./diff.cjs');
const [before,after,output]=process.argv.slice(2),base=readZ(before),test=readZ(after);
function ordered(v){if(Array.isArray(v))return v.map(ordered);if(v&&typeof v==='object')return Object.fromEntries(Object.keys(v).sort().map(k=>[k,ordered(v[k])]));return v;}
const hash=v=>crypto.createHash('sha256').update(JSON.stringify(ordered(normalize(v)))).digest('hex');
const rows={};
for(const id of Object.keys(base)){
 const a=base[id],b=test[id];
 for(const f of ['actionId','value','roots','edges','graph'])assert.deepEqual(b.q[f],a.q[f],id+'/'+f);
 assert.deepEqual(b.root,a.root);
 const index=new Map(Object.values(a.witnesses).map(w=>[hash([w.source,w.a]),w]));
 assert.equal(index.size,Object.keys(a.witnesses).length);
 assert.equal(index.size,Object.keys(b.witnesses).length);
 for(const x of Object.values(b.witnesses)){
  const y=index.get(hash([x.source,x.a]));
  assert(y,x.a.summary);
  const left=normalize(x),right=normalize(y);
  if(!equivalent(left,right))throw Error(JSON.stringify([x.a.summary,diff(left,right)]));
 }
 rows[id]={n:[a.q.diagnostics.nativeExecutions,b.q.diagnostics.nativeExecutions],ms:[a.ms,b.ms],graph:b.q.diagnostics.graphNodes,inputs:index.size,exact:true};
 console.log(id,rows[id]);
}
writeZ(output,rows);
