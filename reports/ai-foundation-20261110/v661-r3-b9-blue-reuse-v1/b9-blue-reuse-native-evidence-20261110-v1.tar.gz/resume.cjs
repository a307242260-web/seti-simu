'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,runCases}=require('./controlled-r3');
const [source,measurement,output]=process.argv.slice(2),prior=readZ(source).rows['draw-b9'].rows[0],cold=readZ(measurement).B9;
assert.deepEqual(prior.end,cold.root);
assert(cold.q.diagnostics.nativeExecutions<=256&&cold.ms<=600);
writeZ(output,runCases(prior.end,[['B9-recovered',()=>{}]]));
