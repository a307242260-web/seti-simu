'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const [source,positions,out]=process.argv.slice(2),base=readZ(source).rows.find(r=>r.label==='scan-then-end-turn').start,d=readZ(positions),b=open(d.e);
const observation=b.owner('player-white'),rows={};b.dispose();
for(const name of ['immediate-b16','immediate-dlc17','next-amiba','b16-and-next-amiba']){
 const e=structuredClone(base),s=JSON.parse(e.committedState),pile=s.cards.drawPileCardIds,amiba=s.aliens.amiba.cardDeck;
 const swap=(x,i,j)=>{assert(i>=0&&j>=0&&x[i]&&x[j]&&x[i]!==x[j]);[x[i],x[j]]=[x[j],x[i]];};
 if(name.includes('b16'))swap(pile,0,pile.indexOf('b_16.webp'));
 if(name.includes('dlc17'))swap(pile,0,pile.indexOf('dlc_17.png'));
 if(name.includes('amiba')){
  // A5 is already displayed; leave it alone even if held in the top deck slot.
  const indices=amiba.map((v,i)=>v===5?-1:i).filter(i=>i>=0);swap(amiba,indices[0],indices[1]);
 }
 e.committedState=createStateStore(s).serialize().serialized;const m=open(e);let mid,q,action;
 try{
  action=m.act('analyze');mid=m.save();assert.deepEqual(m.owner('player-white'),observation);
  assert.deepEqual(m.menu(),d.menu);
  const {checkpoint,...u}=m.automatic();q=u;assert(q.complete&&q.n<=256&&q.ms<=600);
  for(const f of ['actionId','value','roots'])assert.deepEqual(JSON.parse(JSON.stringify(f==='actionId'?q.a.actionId:q[f])),d.q[f],f);
  assert.deepEqual(m.save(),mid);
 }finally{m.dispose();}
 const r=runCases(mid,['trace:2:blue','trace:1:blue:amiba:3'].map(id=>[id,h=>h.act('choose_target',x=>x.target.choiceId===id)]));
 assert.deepEqual(r.failures,[]);rows[name]={e,action,mid,q,...r};
 console.log(name,JSON.stringify(r.rows.map(a=>[a.label,a.stop,a.settled?.summary.wallet[0],a.settled?.summary.established,a.settled?.summary.income])));
}
writeZ(out,rows);
