'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,runCases}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port')),{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [source,out]=process.argv.slice(2),d=readZ(source),ref=d.rows.find(r=>r.label==='start-analysis-after-scan'),e=ref.start;
const m=open(e),menu=m.menu(),port=createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});let q;
try{
 q=createSearchAgent({seatId:'player-white',analysisPort:port}).decide({seatId:'player-white',legalActions:menu}).search;
 assert(q.complete&&!q.unresolved.length&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600);
 assert.equal(q.actionId,ref.actions[0].action.actionId);assert.deepEqual(m.save(),e);
 console.log(menu.map(a=>[a.summary,a.target.choiceId,q.roots.find(b=>b.actionId===a.actionId)?.value]));
}finally{port.close();m.dispose();}
// Do not repeat the archived winner: replay its stored actions as the reference.
const cases=menu.filter(a=>a.actionId!==q.actionId).map(a=>[a.target.choiceId,h=>h.take(h.m.apply(a))]);
const r=runCases(e,cases);assert.deepEqual(r.failures,[]);writeZ(out,{e,menu,q,reference:ref,...r});
