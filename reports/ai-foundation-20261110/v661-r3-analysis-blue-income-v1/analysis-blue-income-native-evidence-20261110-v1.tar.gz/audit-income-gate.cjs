'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),Module=require('node:module');
const [infile,out]=process.argv.slice(2),src=path.resolve('randomizer/game/ai/analysis-port.js'),m=new Module(src,module);
m.filename=src;m.paths=Module._nodeModulePaths(path.dirname(src));Module._cache[src]=m;
let source=fs.readFileSync(src,'utf8');
const key='          goals=goals.filter(g=>g.kind!=="income"||incomeTail.selected);';assert.equal(source.split(key).length,2);
source=source.replace(key,`          const debugOwner=state.players.players.find(x=>x.id===seatId);
          if(node.status==='stable'&&state.turn.roundNumber===3&&state.turn.turnNumber===13&&debugOwner.resources.availableData===3
            &&debugOwner.resources.score===74&&data.listComputerPlacedTokens(debugOwner).length===0&&debugOwner.hand.some(x=>x.cardId==='amiba_5.webp'))
            globalThis.debugIncome({serial:stored.serial,node:node.status,barrier:stored.informationBarrier,intent:stored.intent,goal,incomeTail,
             currency:[debugOwner.resources.credits,debugOwner.resources.energy],hand:debugOwner.hand.map(c=>[c.id,c.cardId,knownCards(stored.envelope).has(c.id)]),
             currentKnown:[...knownCards(stored.envelope)],task:node.legalActions.filter(a=>a.family==='complete_task'),
             inert:hasPostMainInertReservations(state,hasOwnVisitSource(state),true,true),ownVisit:hasOwnVisitSource(state)});
`+key);
m._compile(source,src);m.loaded=true;
const {open,readZ,writeZ}=require('./controlled-r3'),{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const d=readZ(infile),host=open(d.e),rows=[];globalThis.debugIncome=x=>rows.push(x);
const p=m.exports.createAnalysisPort({composition:host.c,seatId:'player-white',maxCacheEntries:0});
try{
 const r=createSearchAgent({seatId:'player-white',analysisPort:p}).decide({seatId:'player-white',legalActions:host.menu()}).search;
 assert.deepEqual(JSON.parse(JSON.stringify(r.roots)),d.q.roots);assert.deepEqual(host.save(),d.e);
}finally{p.close();host.dispose();}
assert(rows.length);for(const r of rows)console.log(JSON.stringify({...r,currentKnown:r.currentKnown.length}));writeZ(out,rows);
