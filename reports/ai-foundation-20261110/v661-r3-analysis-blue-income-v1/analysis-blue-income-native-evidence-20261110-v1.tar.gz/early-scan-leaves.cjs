'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port')),{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [src,out]=process.argv.slice(2),g=readZ(src),r=g.rows.find(r=>r.label==='get-a5-then-end-turn'),m=open(r.start),seat='player-white';
const p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const menu=m.menu(),q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:menu}).search;
 assert(q.complete&&!q.unresolved.length&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600);
 assert.equal(q.actionId,r.roots[0].action.actionId);assert.deepEqual(m.save(),r.start);
 const line=new Map(q.lines.map(l=>[l.node,l])),paths={};
 for(const a of menu.filter(a=>a.family==='scan'||a.actionId===q.actionId)){
  const root=q.roots.find(u=>u.actionId===a.actionId),ls=[];
  let l=line.get(root.target);for(let i=0;i<q.lines.length&&l;i++){
   const edge=l.edges.find(e=>line.get(e.target)?.value===l.value);
   ls.push({node:l.node,status:l.status,boundary:l.boundary,value:l.value,edge,planSummary:l.planSummary});
   if(!edge)break;l=line.get(edge.target);
  }
  paths[a.family]={a,root,ls};
  console.log(a.family,JSON.stringify([root.value,ls.map(x=>[x.status,x.boundary,x.value,x.edge?.steps,x.planSummary?.kind,x.edge?.turnTailPlanValue?.kind])]));
 }
 writeZ(out,{e:r.start,menu,q,paths});
}finally{p.close();m.dispose();}
