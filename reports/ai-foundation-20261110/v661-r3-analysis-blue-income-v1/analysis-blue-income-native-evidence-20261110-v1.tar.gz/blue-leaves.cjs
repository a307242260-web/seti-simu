'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {evaluateStateValue}=require(path.resolve('randomizer/game/ai/state-value'));
const [src,out]=process.argv.slice(2),d=readZ(src),lines=new Map(d.q.lines.map(l=>[l.node,l])),seat='player-white',rows={};
for(const key of ['trace:2:blue','trace:1:blue:amiba:3']){
 const m=open(d.e),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0}),acts=[];let leaf;
 try{
  let node=port.openRoot();port.setMovementPlanning(true);port.setResourcePlanning(true);port.setCardPickPlanning(true);port.setDecisionPlanning({finalMarkPlanning:true,scanPlanning:true,rankKnownFossilTraces:false});
  const step=a=>{acts.push(a);node=port.expand(node,a.actionId);};
  const first=node.legalActions.find(a=>a.target.choiceId===key),r=d.q.roots.find(x=>x.actionId===first.actionId);
  const path=(edge)=>edge.steps.forEach(id=>{const a=node.legalActions.find(a=>a.actionId===id);assert(a,id);step(a);});
  path(lines.get(0).edges.find(x=>x.actionId===first.actionId));
  for(let l=lines.get(r.target);;){
   const edge=l.edges.find(e=>lines.get(e.target)?.value===l.value);assert(edge);
   if(edge.turnTailPlanValue){
    leaf={value:l.value,certificate:edge.turnTailPlanValue};
    if(leaf.certificate.kind==='blue-end-turn'){
     step(node.legalActions.find(a=>a.actionId===leaf.certificate.firstActionId));
     step(node.legalActions.find(a=>a.family==='place_data'));
     step(node.legalActions.find(a=>a.target.blueSlot===leaf.certificate.scoredCornerBlueCurrency.blueSlot));
    }break;
   }
   path(edge);l=lines.get(edge.target);
  }
  const obs=port.valueObservation(node),value=evaluateStateValue(obs,seat);
  assert.equal(value.total,leaf.value);
  rows[key]={acts,leaf,obs,value};assert.deepEqual(m.save(),d.e);
  console.log(key,JSON.stringify([value.total,value.components,obs.publicState.players.find(x=>x.playerId===seat),obs.selfState.hand.map(x=>[x.id,x.cardId,x.hidden]),acts.map(a=>a.summary)]));
 }finally{port.close();m.dispose();}
}
writeZ(out,rows);
