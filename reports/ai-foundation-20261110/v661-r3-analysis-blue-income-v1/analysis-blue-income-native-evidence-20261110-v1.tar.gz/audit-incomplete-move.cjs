'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),Module=require('node:module');
const [infile,out]=process.argv.slice(2),src=path.resolve('randomizer/game/ai/analysis-port.js'),m=new Module(src,module);
m.filename=src;m.paths=Module._nodeModulePaths(path.dirname(src));Module._cache[src]=m;
let source=fs.readFileSync(src,'utf8');
const key='          goals=goals.filter(g=>g.kind!=="income"||incomeTail.selected);';assert.equal(source.split(key).length,2);
source=source.replace(key,`          const debugOwner=state.players.players.find(x=>x.id===seatId);
          if(node.status==='stable'&&state.turn.roundNumber===3&&state.turn.turnNumber===13&&debugOwner.resources.availableData===3
            &&debugOwner.resources.score===74&&data.listComputerPlacedTokens(debugOwner).length===0&&debugOwner.hand.some(x=>x.cardId==='amiba_5.webp'))
            if(stored.intent?.free===true&&stored.intent.path.length===0&&incomeTail.selected){
              const variants={paid:{...stored.intent,free:false},expired:{...stored.intent,startedTurn:stored.intent.startedTurn-1},
                pending:{...stored.intent,path:[{from:{x:4,y:1},to:{x:3,y:1},deltaX:-1,deltaY:0}]}};
              const checked={};
              for(const [name,move] of Object.entries(variants)){
                const other=createNode(stored.envelope,null,node.legalActions,node.status,stored.informationBarrier,move);
                const result=resourceSpec(other);
                checked[name]={selected:result?.incomeTail?.selected??null,reason:result?.incomeTail?.reason??null};
              }
              globalThis.debugIncome({checked,selected:incomeTail.selected});
            }
`+key);
m._compile(source,src);m.loaded=true;
const {open,readZ,writeZ}=require('./controlled-r3'),{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const d=readZ(infile),host=open(d.e),rows=[];globalThis.debugIncome=x=>rows.push(x);
const p=m.exports.createAnalysisPort({composition:host.c,seatId:'player-white',maxCacheEntries:0});
try{
 const r=createSearchAgent({seatId:'player-white',analysisPort:p}).decide({seatId:'player-white',legalActions:host.menu()}).search;
 assert.deepEqual(JSON.parse(JSON.stringify(r.roots)),d.q.roots);assert.deepEqual(host.save(),d.e);
}finally{p.close();host.dispose();}
assert(rows.length);for(const r of rows){
 for(const q of Object.values(r.checked))assert.deepEqual(q,{selected:false,reason:'income-tail-needs-additional-funding'});
 console.log(JSON.stringify(r));
}writeZ(out,rows);
