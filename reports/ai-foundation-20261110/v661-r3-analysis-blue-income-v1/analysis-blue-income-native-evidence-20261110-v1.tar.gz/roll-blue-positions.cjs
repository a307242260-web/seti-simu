'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [src,prior,out]=process.argv.slice(2),d=readZ(src),older=readZ(prior),seat='player-white';
function next(m,e){
 const actions=[],checkpoints=[];const push=(a,method)=>actions.push({action:a,method});
 const other=()=>{const s=[];m.advanceOpponents(s);s.forEach(a=>push(a,'passive'));};
 const summarize=()=>short(m);
 push(m.act('pass'),'fixed');push(m.act('choose_card',a=>a.target.cardId==='b_111.webp'),'fixed');other();
 assert.equal(m.facts().round,4);assert(!m.save().session);
 const opening=m.save(),openingSummary=summarize();let last=openingSummary.turn,stop=null,cache=null;
 for(let i=0;i<150;i++){
  if(m.menu()[0]?.actorId!==seat){other();continue;}
  const s=summarize();
  if(!m.save().session&&s.turn>last){last=s.turn;checkpoints.push({e:m.save(),s});if(checkpoints.length===2){stop='two-turns';break;}}
  const q=m.automatic(cache);
  if(!q.complete||q.n>256||q.ms>600){stop={kind:'gate',n:q.n,ms:q.ms,action:q.a};break;}
  cache=q.checkpoint;actions.push({action:m.apply(q.a),method:'autonomous',n:q.n,ms:q.ms,value:q.value});
  if(q.a.family==='pass'){stop='autonomous-pass';break;}
 }
 assert(stop);const end=m.save();m.restore(e);actions.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),end);
 return {opening,openingSummary,actions,checkpoints,end,stop};
}
const rows={};
for(const r of [d.reference,...d.rows]){
 const key=r.prefix.length===1?r.label:'ordinary-second-species';
 if(key==='trace:1:blue:amiba:3'){
  const saved=older['c-marker-same-scan-autonomous-income'];assert(saved);
  assert.deepEqual(saved.e,r.settled.state);
  rows[key]={...saved,reused:true};console.log(key,JSON.stringify([saved.stop,saved.checkpoints.map(p=>p.s)]));continue;
 }
 if(!r.settled)continue;
 const e=r.settled.state,m=open(e);
 try{
  rows[key]={e,...next(m,e)};
  const x=rows[key];console.log(key,JSON.stringify([x.stop,x.checkpoints.map(p=>p.s)]));
 }finally{m.dispose();}
}
writeZ(out,rows);
