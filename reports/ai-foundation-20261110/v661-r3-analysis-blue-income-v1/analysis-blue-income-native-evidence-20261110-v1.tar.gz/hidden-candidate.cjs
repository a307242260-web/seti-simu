'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ}=require('./controlled-r3');
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port')),{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [src,out]=process.argv.slice(2),d=readZ(src),seat='player-white',base=open(d.e),obs=base.owner(seat),menu=base.menu(),rows={};base.dispose();
for(const world of ['ordinary','amiba','both']){
 const e=structuredClone(d.e),s=JSON.parse(e.committedState);
 const swap=(list,i,j)=>{assert(list[i]&&list[j]&&list[i]!==list[j]);[list[i],list[j]]=[list[j],list[i]];};
 if(world!=='amiba')swap(s.cards.drawPileCardIds,0,2);
 if(world!=='ordinary'){
  const hidden=s.aliens.amiba.cardDeck.map((v,i)=>v===s.aliens.amiba.displayedCardIndex?-1:i).filter(i=>i>=0);
  swap(s.aliens.amiba.cardDeck,hidden[0],hidden[1]);
 }
 e.committedState=createStateStore(s).serialize().serialized;
 const m=open(e),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  assert.deepEqual(m.owner(seat),obs);assert.deepEqual(m.menu(),menu);
  const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:menu}).search;
  assert(q.complete&&!q.unresolved.length&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600);
  for(const k of ['actionId','value','roots','lines','unresolved','candidates','sharedPrefixGraph'])assert.deepEqual(JSON.parse(JSON.stringify(q[k])),d.q[k],world+'/'+k);
  assert.deepEqual(m.save(),e);rows[world]={e,q};console.log(world,q.diagnostics.nativeExecutions,q.rootAndSearchMilliseconds);
 }finally{port.close();m.dispose();}
}
writeZ(out,rows);
