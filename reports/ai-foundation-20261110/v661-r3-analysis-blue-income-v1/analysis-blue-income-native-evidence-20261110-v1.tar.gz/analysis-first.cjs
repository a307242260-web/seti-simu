'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [src,markFile,out]=process.argv.slice(2),ref=readZ(src).teacher.rows.find(r=>r.label==='c'),mark=readZ(markFile),original=mark.original.mark;
const m=open(original),earlier=[];let start,base;
try{
 ref.prefix.forEach(a=>earlier.push(m.apply(a)));
 for(const {action:a} of ref.actions){if(a.target?.choiceId==='trace:2:blue')break;earlier.push(m.apply(a));}
 start=m.save();base=short(m);assert(m.menu().some(a=>a.target.choiceId==='trace:1:blue:amiba:3'));
}finally{m.dispose();}
const blue3=h=>h.act('choose_target',x=>x.target.choiceId==='trace:1:blue:amiba:3');
const collect=h=>{blue3(h);h.act('choose_card',a=>a.target.choiceId==='amiba:display:5');h.act('accept_optional_effect',a=>a.target.choiceId.startsWith('confirm:trigger:alien-amiba-9-'));};
const end=h=>{collect(h);h.act('end_turn');};
const scan=mark.rows['draw-b16'].rows[1].prefix.slice(1,5);
const matched=(h,n)=>{end(h);for(const a of scan.slice(0,n)){
 const b=h.m.menu().find(b=>a.actorId===b.actorId&&a.family===b.family&&JSON.stringify(a.target)===JSON.stringify(b.target));assert(b,a.summary);h.take(h.m.apply(b));
}};
const r=runCases(start,[['only-earlier-blue3',blue3],['get-a5-then-end-turn',end],['get-a5-then-start-scan',h=>matched(h,1)],['get-a5-then-same-scan',h=>matched(h,4)]]);
console.log('start',JSON.stringify(base));writeZ(out,{original,earlier,start,base,...r});
