'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),rows={};
for(const [k,r] of Object.entries(d)){
 const plan=r.goals.find(x=>x.g.planetId==='mercury'),e=r.next,m=open(e),actions=[];
 try{
  const id=Number(plan.g.requirementId.split(':')[0]),put=a=>actions.push(a);
  const buy=plan.payment?.energyPurchases??Math.floor(m.facts().wallet.credits/2);
  for(let i=0;i<buy;i++)put(m.act('quick_trade',a=>a.target.tradeId==='credits-for-energy'));
  for(const step of plan.g.route.path){
   put(m.act('move',a=>a.target.rocketId===id&&a.target.deltaX===step.deltaX&&a.target.deltaY===step.deltaY));
   put(m.act('choose_payment',a=>a.target.choiceId==='energy'));
  }
  const at=short(m),menu=m.menu(),land=menu.find(a=>a.family==='land');
  if(land){put(m.apply(land));assert(plan.payment);assert.equal(m.facts().wallet.score,r.s.wallet[0]+12);}
  else assert(!plan.payment);
  const end=m.save(),s=short(m);
  m.restore(e);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  rows[k]={e,actions,at,s,end,goal:plan.g.requirementId,landed:!!land};
  console.log(k,JSON.stringify([r.s.wallet,at.wallet,s.wallet,!!land]));
 }finally{m.dispose();}
}
writeZ(out,rows);
