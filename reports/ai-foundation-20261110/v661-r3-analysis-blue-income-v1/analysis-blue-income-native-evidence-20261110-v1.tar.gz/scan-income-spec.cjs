'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {evaluateStateValue}=require(path.resolve('randomizer/game/ai/state-value'));
const [src,pairs,out]=process.argv.slice(2),d=readZ(src),r=readZ(pairs),seat='player-white',rows={};
const target=r.pairs.find(x=>x.s.wallet[0]===74),first=d.menu.find(a=>a.family==='scan');
const native=open(d.e),pathToScan=[first,...target.steps],results=[];
try{
 for(const a of pathToScan){const next=native.menu().find(x=>x.family===a.family&&JSON.stringify(x.target)===JSON.stringify(a.target));assert(next,a.summary);results.push(native.apply(next));}
 assert.deepEqual(native.save(),target.end);
}finally{native.dispose();}
function probe(e,prefix){
 const m=open(e),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  let node=port.openRoot();port.setResourcePlanning(true);port.setCardPickPlanning(true);port.setMovementPlanning(true);port.setDecisionPlanning({finalMarkPlanning:true,scanPlanning:true});
  const step=(f,p=()=>true)=>{const a=node.legalActions.find(a=>a.family===f&&p(a));assert(a,JSON.stringify([f,node.legalActions.map(a=>a.summary)]).slice(0,500));node=port.expand(node,a.actionId);return a;};
  for(const a of prefix)step(a.family,b=>JSON.stringify(b.target)===JSON.stringify(a.target));
  const obs=port.valueObservation(node),spec=port.resourceSpec(node),mark=node.boundary,forced=[];
  forced.push(step('card_corner',a=>a.summary.includes('amiba_7.webp')));
  const afterCorner=port.resourceSpec(node);
  for(let i=0;i<4;i++){forced.push(step('place_data'));forced.push(step('choose_target',a=>a.target.target==='computer'));}
  forced.push(step('choose_card',a=>a.summary==='收入 amiba_5.webp'));
  const leaf=port.valueObservation(node),value=evaluateStateValue(leaf,seat);
  assert.deepEqual(m.save(),e);
  return {mark,obs,spec,afterCorner,forced,leaf,value};
 }finally{port.close();m.dispose();}
}
rows.hidden=probe(d.e,results);rows.public=probe(target.end,[]);
for(const [k,r] of Object.entries(rows))console.log(k,JSON.stringify({mark:r.mark,after:r.afterCorner?.incomeTail,before:r.spec?.incomeTail,plans:r.spec?.plans.map(p=>[p.goal.kind,p.goal.incomeCardId,p.goal.blueSlot]),value:r.value}).slice(0,9800));
writeZ(out,{e:d.e,scan:results,scanEnd:target.end,rows});
