# 第三轮蓝位及扫描收入复现

具备 Production 规则与 assets 的源码根运行 `node <解包路径>/verify-blue.cjs`。它独立重放所有归档动作并核对精确状态，不重跑正式实验。基线为 `e27c9dd78`，候选修改为本档案相同提交的 `analysis-port.js`。测试夹具及回归在源码的 `randomizer/game/ai/scan-income-after-free-move.*`。

脚本参数顺序写在文件头。基线上用 `blue-positions.cjs`、`roll-blue-positions.cjs`、`hidden-blue.cjs`、`roll-hidden-blue.cjs` 建立五种蓝位和四组暗牌对照；`blue-leaves.cjs` 复放估值叶；`analysis-first.cjs`、`reverse-scan.cjs`、`roll-reverse-best.cjs` 验证先分析后扫描；`landing-wallet.cjs`、`matched-closure.cjs`、`native-mercury.cjs` 核对第四轮付款。用 `early-scan-leaves.cjs` 在基线和候选分别生成原根搜索；`audit-income-gate.cjs` 为基线故障归因，`audit-incomplete-move.cjs`、`hidden-candidate.cjs`、`parity.cjs` 为候选对照。脚本均写入新的输出路径，回放既有成绩不重新登记实验。
