'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,short}=require('./controlled-r3');
const probe=require(path.resolve('randomizer/game/ai/probe-capital')),{DEFAULT_WEIGHTS}=require(path.resolve('randomizer/game/ai/state-value'));
const [src,leafFile,ends,out]=process.argv.slice(2),base=readZ(src),leaves=readZ(leafFile),r4=readZ(ends),seat='player-white',rows={};
const ids=['trace:2:blue','trace:1:blue:amiba:3'];
function choices(m){
 const p=m.player(),f=probe.factsFromState(m.state(),p),wallet={credits:p.resources.credits,energy:p.resources.energy};
 return probe.requirements(f).filter(g=>g.endpointFamily==='land').map(g=>{
  const cost={...g.endpointFacts.cost,energy:(g.endpointFacts.cost.energy||0)+g.route.cost};
  return {g,cost,payment:probe.funding(wallet,cost,DEFAULT_WEIGHTS)};
 });
}
for(const k of ids){
 const m=open(base.e);try{
  const prefix=[];const push=x=>prefix.push(x);const take=a=>{
   const b=m.menu().find(x=>x.family===a.family&&JSON.stringify(x.target)===JSON.stringify(a.target));assert(b,a.summary);push(m.apply(b));
  };
  leaves[k].acts.forEach(take);const evaluated=m.save(),before=short(m);
  const reference=base.rows.find(r=>r.label===ids[1]).actions.map(x=>x.action);
  const index=reference.findIndex(a=>a.summary==='收入 amiba_5.webp');assert(index>=0);
  const stop=reference.findIndex(a=>a.family==='pass');assert(stop>index);
  reference.slice(index+1,stop).forEach(take);m.advanceOpponents(prefix);
  push(m.act('pass'));
  push(m.act('choose_card',a=>a.target.cardId==='b_111.webp'));
  m.advanceOpponents(prefix);assert.equal(m.facts().round,4);
  const next=m.save(),s=short(m),goals=choices(m);assert.deepEqual(m.save(),next);
  m.restore(base.e);prefix.forEach(m.apply);assert.deepEqual(m.save(),next);
  rows['matched/'+k]={root:base.e,evaluated,before,next,s,goals,prefix};
 }finally{m.dispose();}

}
for(const [k,r] of Object.entries(rows))console.log(k,JSON.stringify([r.s.wallet,r.goals.map(x=>[x.g.planetId,x.g.route.cost,x.cost,x.payment])]).slice(0,6800));
writeZ(out,rows);
