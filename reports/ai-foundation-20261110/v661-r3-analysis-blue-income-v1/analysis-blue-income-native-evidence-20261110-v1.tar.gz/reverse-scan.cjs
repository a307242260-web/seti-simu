'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),r=d.rows.find(r=>r.label==='get-a5-then-start-scan'),e=r.start;
const known=d.rows.find(r=>r.label==='get-a5-then-same-scan').prefix.slice(-3).map(a=>a.target.choiceId),m=open(e),pairs=[];
try{
 const old=m.facts().wins?.length||0;
 for(const a of m.menu()){
  m.restore(e);m.apply(a);const bRoot=m.save();
  for(const b of m.menu().filter(a=>a.target.nebulaId)){
   m.restore(bRoot);m.apply(b);
   const c=m.act('choose_target',x=>x.target.choiceId==='scan4:skip');
   pairs.push({steps:[a,b,c],end:m.save(),s:short(m),newWins:(m.facts().wins?.length||0)-old});
  }
 }
}finally{m.dispose();}
assert.equal(pairs.length,18);
const branches=pairs.filter(p=>JSON.stringify(p.steps.map(a=>a.target.choiceId))!==JSON.stringify(known));assert.equal(branches.length,17);
const samples=runCases(e,branches.map((p,i)=>[i,h=>{p.steps.forEach(a=>h.take(h.m.apply(a)));assert.deepEqual(h.m.save(),p.end);}]));
assert.deepEqual(samples.failures,[]);writeZ(out,{e,pairs,known,...samples});
