'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ}=require('./controlled-r3');
const dir=process.argv[2]||__dirname,load=n=>readZ(path.join(dir,n+'-20261110-v1.json.gz'));
let replays=0,inputs=0,maxNative=0,maxMs=0;
function replay(e,steps,end,settled){
 const m=open(e);try{
  let saw=false;
  for(const u of steps){const a=u.action||u;
   if(u.n!==undefined){assert(u.n<=256&&u.ms<=600);maxNative=Math.max(maxNative,u.n);maxMs=Math.max(maxMs,u.ms);}
   if(settled&&a.actorId==='player-white'&&a.family==='pass'&&m.facts().round===3){saw=true;assert.deepEqual(m.save(),settled.state);}
   m.apply(a);inputs++;
  }
  if(settled)assert(saw);assert.deepEqual(m.save(),end);replays++;
 }finally{m.dispose();}
}
function group(e,g){assert.deepEqual(g.failures,[]);for(const r of g.rows){replay(e,r.prefix,r.start);replay(r.start,r.actions,r.end,r.settled);}}
function fourth(g){for(const r of Object.values(g)){assert.equal(r.stop,'two-turns');replay(r.e,r.actions,r.end);}}
const root=load('blue-positions-r3'),r4=load('blue-positions-r4');
group(root.e,root);replay(root.reference.start,root.reference.actions,root.reference.end,root.reference.settled);fourth(r4);
assert.deepEqual(root.rows.map(r=>r.settled.summary.income[1]),[3,3,3,4]);
const hidden=load('blue-hidden-r3'),hidden4=load('blue-hidden-r4');
for(const [key,r] of Object.entries(hidden)){
 replay(r.e,[r.action],r.mid);group(r.mid,r);
 assert.equal(hidden4[key+'/trace:1:blue:amiba:3'].checkpoints[1].s.established,163);
 assert([152,154].includes(hidden4[key+'/trace:2:blue'].checkpoints[1].s.established));
}
fourth(hidden4);
const early=load('blue-analysis-first'),scan=load('blue-reverse-scan');replay(early.original,early.earlier,early.start);group(early.start,early);group(scan.e,scan);
for(const p of scan.pairs){replay(scan.e,p.steps,p.end);assert.equal(p.s.wallet[4],3);assert.equal(p.newWins,0);}
fourth(load('blue-reverse-r4'));
for(const name of ['blue-landing-wallet','blue-matched-closure'])for(const r of Object.values(load(name)))if(r.prefix)replay(r.root,r.prefix,r.next);
for(const name of ['blue-native-mercury','blue-native-matched'])for(const r of Object.values(load(name)))replay(r.e,r.actions,r.end);
const before=load('blue-early-scan-leaves'),after=load('blue-early-scan-candidate'),parity=load('blue-candidate-parity');
assert.equal(before.q.actionId,after.q.actionId);assert.equal(before.paths.scan.root.value,143.25);assert.equal(after.paths.scan.root.value,142+5/6);
assert.equal(after.paths.scan.ls[0].edge.resourcePlan.goal.incomeCardId,'alien-amiba-5-9');
assert.equal(after.paths.scan.ls[0].edge.goalStatus,'completed');assert.equal(Object.keys(parity).length,89);
assert.equal(Object.keys(load('blue-candidate-hidden')).length,3);
for(const row of load('blue-candidate-guard'))for(const q of Object.values(row.checked))assert.equal(q.selected,false);
console.log({replays,inputs,maxNative,maxMs,formalRoots:Object.keys(parity).length,oldRootNative:before.q.diagnostics.nativeExecutions,newRootNative:after.q.diagnostics.nativeExecutions});
