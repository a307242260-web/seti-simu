'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),V=require(path.resolve('randomizer/game/ai/state-value')),P=require(path.resolve('randomizer/game/ai/probe-capital'));
const {checkpoint:root}=JSON.parse(fs.readFileSync(process.argv[3])),m=open(root);
try{
 const prefix=[m.act('place_data'),m.act('choose_target',a=>a.target.target==='computer')];
 const common=m.save(),entries=[];
 for(const id of ['alien-chong-6-16','alien-chong-2-8','card-30-pass-3-1']){
  m.restore(common);
  const a=m.menu().find(a=>a.family==='choose_card'&&a.target.cardInstanceId===id);
  if(!a)continue;
  m.apply(a);const end=m.save(),facts=m.facts(),value=V.evaluateStateValue(m.owner(seat),seat);
  const q=P.quote({...P.factsFromObservation(m.owner(seat),seat),investment:()=>0},V.DEFAULT_WEIGHTS);
  const remaining=m.menu().find(a=>a.family==='play_card'&&a.target.cardInstanceId==='alien-chong-6-16');
  let cardEndpoint=null;
  if(remaining){
   m.apply(remaining);const target=m.menu().find(a=>a.target.landTarget?.satelliteId==='enceladus'&&a.target.rocketId===7);
   if(target){m.apply(target);cardEndpoint={actions:[remaining,target],end:m.save(),facts:m.facts(),menu:m.menu().map(x=>x.summary)};}
  }
  m.restore(common);m.apply(a);assert.deepEqual(m.save(),end);
  if(cardEndpoint){for(const input of cardEndpoint.actions)m.apply(input);assert.deepEqual(m.save(),cardEndpoint.end);}
  entries.push({a,end,facts,value,quote:q.selected,cardEndpoint});
 }
 m.restore(root);assert.deepEqual(m.save(),root);
 fs.writeFileSync(process.argv[4],z.gzipSync(JSON.stringify({root,prefix,common,entries,rootAndRngExact:true})),{flag:'wx'});
 console.log(JSON.stringify(entries.map(x=>({income:x.a.summary,wallet:x.facts.wallet,hand:x.facts.hand.map(y=>y[1]),value:x.value.total,quote:x.quote?.id,cardEndpoint:x.cardEndpoint?.facts.wallet}))));
}finally{m.dispose();}
