'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),V=require(path.resolve('randomizer/game/ai/state-value'));
const d=JSON.parse(z.gunzipSync(fs.readFileSync(process.argv[3]))),root=d.paths.scan[0].end,m=open(root);
const normal=d.paths.scan[1].inputs;
assert.equal(normal[0].target.tradeId,'credits-for-energy');assert.equal(normal[1].family,'land');
assert.equal(normal[2].target.landTarget?.satelliteId,'enceladus');
const plain=[],card=[],fallbacks=[];
const push=(rows,a)=>rows.push({a,end:m.save(),facts:m.facts(),v:V.evaluateStateValue(m.owner(seat),seat)});
const go=(rows,family,cond)=>push(rows,m.act(family,cond));
const cardId='alien-chong-6-16';
try{
 for(const a of normal)push(plain,m.apply(a));
 m.restore(root);
 go(card,'play_card',a=>a.target.cardInstanceId===cardId);
 go(card,'choose_target',a=>a.target.actionType==='land'&&a.target.landTarget?.satelliteId==='enceladus'&&a.target.rocketId===7);
 const land={normal:plain[2].facts,card:card[1].facts};
 assert.equal(land.normal.wallet.score,land.card.wallet.score);
 assert.equal(land.card.wallet.credits-land.normal.wallet.credits,1);
 assert.equal(land.card.wallet.energy-land.normal.wallet.energy,1);
 assert.equal(land.normal.wallet.handSize-land.card.wallet.handSize,1);
 for(const a of normal.slice(3)){
  const match=m.menu().find(x=>x.actionId===a.actionId&&x.actorId===a.actorId);
  if(!match)break;
  assert(!match.target.fossilId&&match.target.source!=='blind');
  push(card,m.apply(match));
 }
 const beforeFossil=m.save(),menu=m.menu(),pending=m.c.inspect().session?.decision;
 const missing=normal[card.length+1]?.summary;
 const legalFossils=menu.filter(a=>a.target?.fossilId);
 for(const fossil of legalFossils){
  m.restore(beforeFossil);const rows=[];push(rows,m.apply(fossil));
  for(const a of normal.slice(card.length+1)){
   const match=m.menu().find(x=>x.actionId===a.actionId&&x.actorId===a.actorId);
   if(!match)break;
   assert(!match.target.fossilId&&match.target.source!=='blind');
   push(rows,m.apply(match));
  }
  fallbacks.push({rows,stop:m.menu().map(a=>[a.family,a.summary]),facts:m.facts()});
 }
 for(const [start,rows] of [[root,plain],[root,card],...fallbacks.map(x=>[beforeFossil,x.rows])]){
  m.restore(start);for(const {a,end} of rows){m.apply(a);assert.deepEqual(m.save(),end);}
 }
 m.restore(root);assert.deepEqual(m.save(),root);
 const result={root,plain,card,menu,pending:Boolean(pending),fallbacks,missing,rootAndRngExact:true};
 fs.writeFileSync(process.argv[4],z.gzipSync(JSON.stringify(result)),{flag:'wx'});
 console.log(JSON.stringify({plain:plain.map(s=>s.a.summary),card:card.map(s=>s.a.summary),menu:menu.map(a=>a.summary),missing,
  normalWallet:land.normal.wallet,cardWallet:land.card.wallet,publicRewardState:[plain[card.length].facts.wallet,card.at(-1).facts.wallet],
  fossilOutcomes:fallbacks.map(x=>[x.rows.map(s=>s.a.summary),x.facts.wallet,x.facts.taskCount]),rootAndRngExact:true}));
}finally{m.dispose();}
