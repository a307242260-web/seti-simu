'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),V=require(path.resolve('randomizer/game/ai/state-value')),P=require(path.resolve('randomizer/game/ai/probe-capital'));
const read=p=>JSON.parse(z.gunzipSync(fs.readFileSync(p)));
const witness=read(process.argv[3]),fees=read(process.argv[4]),m=open(witness.root);
const roots=[['ordinary',fees.plain.at(-1).end],...fees.fallbacks.map((r,i)=>['held-'+(i+1),r.rows.at(-1).end])];
const entries=[];
try{
 for(const [label,root] of roots){
  m.restore(root);
  const rows=[];
  for(const turn of witness.paths.scan.slice(2,5)){
   const actions=[];
   for(const expected of turn.inputs){
    const a=m.menu().find(a=>a.actionId===expected.actionId&&a.actorId===expected.actorId);
    if(!a){actions.push({missing:expected,menu:m.menu()});break;}
    m.apply(a);actions.push({a,end:m.save()});
   }
   const o=m.owner(seat),f=P.factsFromObservation(o,seat),v=V.evaluateStateValue(o,seat);
   const quote=P.quote({...f,investment:()=>0},V.DEFAULT_WEIGHTS).selected;
   rows.push({actions,facts:m.facts(),v,quote});
   if(actions.at(-1)?.missing)break;
  }
  m.restore(root);for(const {actions} of rows)for(const {a,end} of actions)if(a){m.apply(a);assert.deepEqual(m.save(),end);}
  entries.push({label,root,rows});
 }
 m.restore(witness.root);assert.deepEqual(m.save(),witness.root);
 fs.writeFileSync(process.argv[5],z.gzipSync(JSON.stringify({entries,rootExact:true})),{flag:'wx'});
 for(const x of entries)console.log(JSON.stringify({label:x.label,rows:x.rows.map(r=>({score:r.facts.wallet.score,wallet:r.facts.wallet,hand:r.facts.hand.map(c=>c[1]),v:r.v.total,probe:r.quote?.id,net:r.quote?.value,missing:r.actions.at(-1)?.missing?.summary}))}));
}finally{m.dispose();}
