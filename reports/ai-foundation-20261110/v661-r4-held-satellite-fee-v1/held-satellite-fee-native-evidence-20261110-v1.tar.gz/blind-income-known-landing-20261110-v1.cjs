'use strict';
const fs=require('node:fs'),z=require('node:zlib'),assert=require('node:assert/strict');
const {open}=require(process.argv[2]);
const root=JSON.parse(fs.readFileSync(process.argv[3])).checkpoint;
const fees=JSON.parse(z.gunzipSync(fs.readFileSync(process.argv[4])));
const m=open(root),results=[];
const incomeId='alien-chong-2-8';
try{
 for(const swap of [false,true]){
  const state=JSON.parse(root.committedState),pile=state.cards.drawPileCardIds;
  assert(pile.length>=2);
  if(swap)[pile[0],pile[1]]=[pile[1],pile[0]];
  const before=swap?{...root,committedState:JSON.stringify(state)}:root;
  const actions=[];
  const go=(family,test)=>{const a=m.act(family,test);actions.push({a,end:m.save()});};
  m.restore(before);
  const ids=new Set(m.player().hand.map(c=>c.id));
  go('place_data');
  go('choose_target',a=>a.target.target==='computer');
  go('choose_card',a=>a.target.cardInstanceId===incomeId);
  const fresh=m.player().hand.find(c=>!ids.has(c.id));assert(fresh?.cardId);const incomeEnd=m.save();
  for(const {a} of fees.card){
   const legal=m.menu().find(x=>x.family===a.family&&x.actorId===a.actorId&&require('node:util').isDeepStrictEqual(x.target,a.target));assert(legal,a.summary);
   assert.notEqual(legal.target.cardInstanceId,fresh.id);
   assert(!legal.target.cardIds?.includes(fresh.id));
   m.apply(legal);actions.push({a:legal,end:m.save()});
  }
  const facts=m.facts(),menu=m.menu().map(a=>[a.actionId,a.target]);
  assert(facts.hand.some(([id])=>id===fresh.id));
  assert(menu.length&&menu.every(([,t])=>t.fossilId));
  m.restore(before);
  for(const {a,end} of actions){m.apply(a);assert.deepEqual(m.save(),end);}
  results.push({swap,before,fresh,incomeEnd,actions,facts,menu});
 }
 const [x,y]=results;assert.notEqual(x.fresh.cardId,y.fresh.cardId);
 assert.deepEqual(x.actions.map(a=>a.a.actionId),y.actions.map(a=>a.a.actionId));
 const scoped=v=>({...v.facts,hand:v.facts.hand.filter(([id])=>id!==v.fresh.id)});
 assert.deepEqual(scoped(x),scoped(y));assert.deepEqual(x.menu,y.menu);
 m.restore(root);assert.deepEqual(m.save(),root);
 fs.writeFileSync(process.argv[5],z.gzipSync(JSON.stringify({root,results,knownOutcomeAndRngExact:true})),{flag:'wx'});
 console.log(JSON.stringify({draws:results.map(x=>x.fresh.cardId),inputs:x.actions.map(x=>x.a.summary),score:x.facts.wallet.score,
  wallet:x.facts.wallet,menu:x.menu,knownOutcomeAndRngExact:true}));
}finally{m.dispose();}
