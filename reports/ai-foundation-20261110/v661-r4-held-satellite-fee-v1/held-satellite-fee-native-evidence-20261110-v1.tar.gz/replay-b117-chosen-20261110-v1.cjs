'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),V=require(path.resolve('randomizer/game/ai/state-value'));
const {root,paths}=JSON.parse(z.gunzipSync(fs.readFileSync(process.argv[3])));
const m=open(root);
try{
 const actual=m.automatic(),initialTurn=m.facts().turn;
 assert(actual.complete);
 const ids=actual.checkpoint?.plan.rows.map(r=>r.actionId)||[actual.a.actionId],steps=[];
 assert.equal(ids[0],actual.a.actionId);
 for(const id of ids){
  const a=m.menu().find(a=>a.actionId===id);if(!a)throw Error('MISSING PROVED INPUT '+id);
  assert.notEqual(a.family,'pass');m.apply(a);
  steps.push({a,end:m.save(),facts:m.facts(),value:V.evaluateStateValue(m.owner(seat),seat)});
  if(m.facts().turn!==initialTurn)break;
 }
 const final=m.save();m.restore(root);
 for(const {a,end} of steps){m.apply(a);assert.deepEqual(m.save(),end);}
 assert.deepEqual(m.save(),final);m.restore(root);assert.deepEqual(m.save(),root);
 const turns=[];
 // Replay same Native landing and close the actual task menu both ways.
 const scanRoot=paths.scan[0].end,landingInputs=paths.scan[1].inputs;
 m.restore(scanRoot);
 const prefix=landingInputs.slice(0,-1);
 assert(landingInputs.at(-1).target.choiceId.startsWith('confirm:task:'));
 for(const action of prefix)m.apply(action);
 const pending=m.save(),known=()=>V.evaluateStateValue(m.owner(seat),seat),before=m.facts();
 const alternatives=m.menu().filter(a=>a.target.choiceId.includes(':task:'));
 assert.equal(alternatives.length,2);
 for(const a of alternatives){
  m.restore(pending);m.apply(a);const end=m.save(),f=m.facts(),value=known();
  m.restore(pending);m.apply(a);assert.deepEqual(m.save(),end);
  turns.push({a,end,f,value});
 }
 const claim=turns.find(x=>x.a.target.choiceId.startsWith('confirm')),skip=turns.find(x=>x.a.target.choiceId.startsWith('skip'));
 assert.equal(claim.f.wallet.score-skip.f.wallet.score,3);
 assert.equal(claim.f.wallet.credits-skip.f.wallet.credits,1);
 assert.equal(claim.f.taskCount-skip.f.taskCount,1);
 assert.deepEqual(claim.f.rng,skip.f.rng);
 m.restore(root);assert.deepEqual(m.save(),root);
 fs.writeFileSync(process.argv[4],z.gzipSync(JSON.stringify({root,steps,result:{value:actual.value,ms:actual.ms,n:actual.n,roots:actual.roots},
  task:{scanRoot,prefix,pending,before,turns},exact:true})),{flag:'wx'});
 console.log(JSON.stringify({actions:steps.map(x=>x.a.summary),last:steps.at(-1).facts.turn,start:initialTurn,value:actual.value,inputs:actual.n,ms:actual.ms,
  task:turns.map(t=>({choice:t.a.target.choiceId,score:t.f.wallet.score,credits:t.f.wallet.credits,task:t.f.taskCount,value:t.value.total}))}));
}finally{m.dispose();}
