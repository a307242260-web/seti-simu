'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const [file,out,expected]=process.argv.slice(2),src=path.resolve('randomizer/game/ai/analysis-port.js'),s=fs.readFileSync(src,'utf8'),m=new Module(src,module);
m.filename=src;m.paths=Module._nodeModulePaths(path.dirname(src));Module._cache[src]=m;
const at='      submissionCount += 1;';
assert.equal(s.split(at).length,2);
m._compile(s.replace(at,'      globalThis.captureNativeInput(current,session);\n'+at),src);m.loaded=true;
const rows=[],{open}=require('./native-late-r3');
const data=JSON.parse(file.endsWith('.gz')?z.gunzipSync(fs.readFileSync(file)):fs.readFileSync(file)),root=data.checkpoint||data.rows[0].root;
const p=open(root);
globalThis.captureNativeInput=(a,s)=>{
 const h=s?.queue?.[0],top=s?.journal?.actions?.[0]?.action;
 rows.push({action:a.family,summary:a.summary,target:a.target,queue:h?.type||'stable',owner:h?.ownerId,optional:h?.payload?.kind,
  top:top?.family||a.family,topSummary:top?.summary||a.summary,
  next:s?.queue?.[1]?.type??null,after:s?.queue?.[2]?.type??null,barrier:s?.irreversibleBarrier?.code});
};
try{
 const r=p.automatic();assert.equal(rows.length,r.n);assert.equal(r.n,Number(expected));assert(r.complete);assert.deepEqual(p.save(),root);
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({rows,value:r.value,action:r.a,native:r.n,rootExact:true})+'\n'),{flag:'wx'});
 const inc=(obj,key)=>obj[key]=(obj[key]||0)+1;
 const families={},menus={},contexts={};
 for(const row of rows){inc(families,row.action);inc(menus,row.queue+' '+row.action);inc(contexts,row.queue+' / '+row.topSummary+' / '+row.summary);}
 const top=n=>Object.entries(n).sort((a,b)=>b[1]-a[1]).slice(0,18);
 console.log(JSON.stringify({native:r.n,value:r.value,families:top(families),menus:top(menus),contexts:top(contexts)}));
}finally{p.dispose();}
