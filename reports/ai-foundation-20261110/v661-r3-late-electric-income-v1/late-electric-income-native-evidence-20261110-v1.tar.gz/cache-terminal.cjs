'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,writeZ,runCases}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [evidence,source,formal,continued,out]=process.argv.slice(2),base=readZ(evidence),old=readZ(source);
const d=readZ(formal).roots,anchor=base[10],prior=base[9].warm.checkpoint;
const m=open(anchor.warm.e),id='player-white';
let resumed;
function decide(cache){
 const port=createAnalysisPort({composition:m.c,seatId:id,maxCacheEntries:0});
 try{
  const agent=createSearchAgent({seatId:id,analysisPort:port}),e=m.save();agent.loadCheckpoint(cache);
  const q=agent.decide({seatId:id,legalActions:m.menu()}).search;
  assert.deepEqual(m.save(),e);
  assert(q.complete&&!q.unresolved.length&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600);
  return {q,checkpoint:agent.createCheckpoint()};
 }finally{port.close();}
}
const steps=[];
const normalize=e=>JSON.parse(JSON.stringify(e).split(e.session?.session?.sessionId||'__no_effect_session__').join('effect-session-X'));
try{
 resumed=decide(prior).q;
 assert.equal(resumed.actionId,anchor.cold.q.actionId);assert.equal(resumed.value,173);
 assert.equal(resumed.diagnostics.planContinuation,'fixed-blue-prefix-competing-income');
 assert.equal(resumed.diagnostics.nativeExecutions,3);
 let cache=null;m.restore(d[242].e);
 for(let k=242;k<=258;k++){
  const q=decide(cache);cache=q.checkpoint;
  assert.deepEqual(normalize(m.save()),normalize(d[k].e),'formal envelope #'+k);
  assert.equal(q.q.actionId,d[k].action.actionId,'formal #'+k);
  steps.push({k,decision:q.q,action:m.apply(d[k].action)});
 }
 assert.deepEqual(normalize(m.save()),normalize(d[259].e));
}finally{m.dispose();}
const r=readZ(continued);assert.deepEqual(r.root,old.ready);
assert.deepEqual(r.rows[0].settled.summary.income,[7,4,2,1]);
console.log('warm repair',resumed.diagnostics.planContinuation,resumed.diagnostics.nativeExecutions,'official actions preserved',steps.length);
writeZ(out,{resumed,prior,anchor:anchor.warm.e,officialStart:d[242].e,officialEnd:d[259].e,steps,root:old.ready});
