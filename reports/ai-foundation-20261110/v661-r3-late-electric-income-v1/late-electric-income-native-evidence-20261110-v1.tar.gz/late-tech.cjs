'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const [f,out]=process.argv.slice(2),d=readZ(f),cases={};
for(const index of [227]){
 const e=d.roots[index].e,m=open(e);
 let options,q,s;
 try{
  s=short(m);assert.equal(s.probes.length,1);assert.equal(s.wallet[0],98);
  options=m.menu();const {checkpoint,...p}=m.automatic();q=p;
  assert(q.complete&&q.n<=256&&q.ms<=600);assert.deepEqual(m.save(),e);
  console.log('root',index,q.n,q.ms,q.a.summary,q.roots.map(r=>[options.find(a=>a.actionId===r.actionId)?.summary,r.value]));
 }finally{m.dispose();}
 const fixed=options.filter(a=>a.actionId!==q.a.actionId);
 cases[index]={e,q,options,s,...runCases(e,fixed.map(a=>[a.summary,h=>h.take(h.m.apply(a))]))};
}
writeZ(out,cases);
