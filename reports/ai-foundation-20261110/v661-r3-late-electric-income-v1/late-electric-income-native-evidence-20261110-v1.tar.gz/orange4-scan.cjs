'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src)[227],e=d.e,m=open(e),prefix=[];
const take=a=>{prefix.push(a);return a;};
const act=(f,p)=>take(m.act(f,p));
const choice=id=>act('choose_target',a=>a.target.choiceId===id);
const computer=()=>{act('place_data');choice('data:computer');};
let analysis,ready,readyFacts,scan,scanOpened,results=[];
try{
 choice('tech:orange4');
 computer();computer();act('end_turn');
 act('analyze');choice('trace:1:blue:amiba:3');act('choose_card',a=>a.target.source==='display');analysis=m.save();
 computer();act('place_data');choice('data:blueBonus:1');
 act('end_turn');
 act('quick_trade',a=>a.target.tradeId==='cards-for-credit');
 for(const id of ['b_16.webp','amiba_5.webp'])act('choose_payment',a=>a.summary===id);
 act('choose_payment',a=>a.summary.includes('确认弃牌'));
 ready=m.save();readyFacts=short(m);
 assert.deepEqual(readyFacts.wallet.slice(1,3),[1,2]);
 assert.deepEqual(readyFacts.hand.toSorted(),['amiba_2.webp','dlc_25.png']);
 assert.deepEqual(readyFacts.probes,d.s.probes.map(()=>[4,2,undefined]));
 scan=m.act('scan');const post=m.save();scanOpened=post;
 for(const first of m.menu()){
  m.restore(post);m.apply(first);const after=m.save(),moves=m.menu();
  for(const second of moves.filter(a=>a.target.nebulaId)){
   m.restore(after);m.apply(second);
   results.push({first,second,e:m.save(),summary:short(m),menu:m.menu()});
  }
 }
 assert(results.length>0);
 for(const r of results){m.restore(post);[r.first,r.second].forEach(m.apply);assert.deepEqual(m.save(),r.e);}
 console.log('before',readyFacts);
 console.log('pairs',results.map(r=>[r.first.summary,r.second.summary,r.summary.wallet,r.menu.filter(a=>a.target.choiceId?.startsWith('trace:')).map(a=>a.summary)]));
}finally{m.dispose();}
const trace=r=>r.menu.some(a=>a.target.choiceId?.startsWith('trace:'));
const good=results.filter(trace);
const test=runCases(ready,[
 ['wallet-ready',()=>{}],
 ...good.map((r,i)=>['sector-'+i,h=>[scan,r.first,r.second].forEach(a=>h.take(h.m.apply(a)))])
]);
writeZ(out,{e,prefix,analysis,ready,readyFacts,scan,scanOpened,results,...test});
