'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),r=d.rows[0],m=open(r.start);
let root,observed,ready,menu,q;
try{
 r.actions.slice(0,9).forEach(x=>m.apply(x.action));
 root=m.save();observed=short(m);
 const {checkpoint,...cold}=m.automatic();q=cold;assert(q.complete&&q.n<=256&&q.ms<=600);
 m.act('place_data');ready=m.save();menu=m.menu();
}finally{m.dispose();}
const rows=runCases(ready,[['computer4-insert-dlc25',h=>{
 h.act('choose_target',a=>a.target.choiceId==='data:computer');
 const c=h.m.player().hand.find(c=>c.cardId==='dlc_25.png');
 h.act('choose_card',a=>a.target.cardInstanceId===c.id);
}]]);
console.log('selection',observed,q.a.summary,q.value,q.roots,menu.map(x=>[x.summary,x.target]));
writeZ(out,{root,observed,q,ready,menu,...rows});
