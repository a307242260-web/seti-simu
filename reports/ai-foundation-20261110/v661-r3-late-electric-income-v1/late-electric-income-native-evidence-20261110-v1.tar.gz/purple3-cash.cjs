'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [f,out]=process.argv.slice(2),d=readZ(f)[227],p=d.rows.find(r=>r.label==='研究 purple3'),m=open(p.start),roots={};
try{
 for(const [i,x] of p.actions.entries()){if([0,6].includes(i))roots[i]=m.save();m.apply(x.action);}
 assert.deepEqual(m.save(),p.end);
}finally{m.dispose();}
const tr=(h,ids)=>{
 h.act('quick_trade',a=>a.target.tradeId==='cards-for-credit');
 ids.forEach(id=>h.act('choose_payment',a=>a.summary===id));
 h.act('choose_payment',a=>a.summary.includes('确认弃牌'));
};
const ch=(h,s)=>h.act('choose_target',a=>a.target.choiceId===s);
function red4(h,pick){
 h.take(h.m.play('amiba_5.webp'));h.take(h.m.pick(pick));ch(h,'symbol:red_2');h.cut('after-amiba');
}
function analyze(h){
 h.act('analyze');ch(h,'trace:1:blue:amiba:3');h.act('choose_card',a=>a.target.source==='display');h.cut('analysis');
}
const source=roots[6],test=runCases(source,[
 ['save-dlc25-pay-b16-dlc17',h=>{tr(h,['b_16.webp','dlc_17.png']);h.cut('same-cash');}],
 ['save-dlc25-pick-known-dlc15',h=>{tr(h,['b_16.webp','dlc_17.png']);red4(h,'dlc_15.png');}],
 ['save-dlc25-prove-electric-income',h=>{
  tr(h,['b_16.webp','dlc_17.png']);red4(h,'dlc_15.png');h.act('end_turn');analyze(h);
  for(const id of ['dlc_15.png','amiba_2.webp'])h.take(h.m.corner(id));
  assert.equal(h.m.facts().wallet.availableData,4);
  for(let j=0;j<4;j++){h.act('place_data');ch(h,'data:computer');}
  const card=h.m.player().hand.find(c=>c.cardId==='dlc_25.png');assert(card);
  h.act('choose_card',a=>a.target.cardInstanceId===card.id);h.cut('income');
 }],
 ['skip-amiba5-scan-b16-save-dlc25',h=>{
  tr(h,['amiba_5.webp','dlc_17.png']);h.take(h.m.play('b_16.webp'));h.cut('scan');
 }],
]);
writeZ(out,{roots,...test});
