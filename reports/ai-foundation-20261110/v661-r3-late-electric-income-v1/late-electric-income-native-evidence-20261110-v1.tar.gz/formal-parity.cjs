'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),{open,readZ,writeZ}=require('./controlled-r3');
const [nativePath,savePath,formal,early,out]=process.argv.slice(2),record=JSON.parse(fs.readFileSync(savePath)),native=JSON.parse(fs.readFileSync(nativePath));
const m=open(native.roundStarts[1].envelope),rows={};
function measure(k){
 const e=m.save(),q=m.automatic(),{a,roots,n,ms,value,complete}=q;
 assert.deepEqual(m.save(),e);
 rows[k]={a,roots,n,ms,value,complete};
}
try{
 for(let i=native.roundStarts[1].beforeInput;i<=native.roundStarts[3].beforeInput;i++){
  const a=record.replaySteps[i-1].action;
  if(a.actorId==='player-white'&&['main','conditional','turn_control'].includes(a.phase))measure('opening:'+i);
  m.apply(a);
 }
 for(const [k,r] of Object.entries(readZ(early).rows))if([172,186,189,190,193,203,205,214].includes(Number(k))){
  m.restore(r.e);measure('early:'+k);
 }
 for(const [k,r] of Object.entries(readZ(formal).roots))if([219,220,227,235,242,245,247,255,258].includes(Number(k))){
  m.restore(r.e);measure('later:'+k);
 }
}finally{m.dispose();}
console.log('roots',Object.keys(rows).length,'largest',Math.max(...Object.values(rows).map(q=>q.n)),'ms',Math.max(...Object.values(rows).map(q=>q.ms)),'exceeded',Object.entries(rows).filter(([k,q])=>!q.complete||q.n>256||q.ms>600).map(([k,q])=>[k,q.n,q.ms]));
writeZ(out,rows);
