'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),rows=[];
assert.equal(d.results.length,18);
for(const r of d.results){
 const m=open(r.e);
 try{
  const action=m.act('choose_target',a=>a.target.choiceId==='scan4:skip');
  const end=m.save(),f=short(m),menu=m.menu();
  assert.equal(f.wallet[4],2);assert(!menu.some(a=>a.target.choiceId?.startsWith('trace:')));
  assert.deepEqual(m.facts().wins,openWins(d.ready));
  m.restore(r.e);m.apply(action);assert.deepEqual(m.save(),end);
  rows.push({root:r.e,action,end,f,first:r.first.summary,second:r.second.summary});
 }finally{m.dispose();}
}
function openWins(e){const m=open(e);try{return m.facts().wins;}finally{m.dispose();}}
writeZ(out,rows);
console.log(rows.length,'two data with no extra sector victory after full finalization');
