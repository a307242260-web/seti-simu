'use strict';
const path=require('node:path'),assert=require('node:assert/strict');
const {open,readZ,writeZ,short}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [src,out]=process.argv.slice(2),r=readZ(src).rows[0],m=open(r.start),rows=[];
const id='player-white';
function decide(checkpoint){
 const port=createAnalysisPort({composition:m.c,seatId:id,maxCacheEntries:0});
 try{
  const agent=createSearchAgent({seatId:id,analysisPort:port}),e=m.save(),menu=m.menu();agent.loadCheckpoint(checkpoint);
  const q=agent.decide({seatId:id,legalActions:menu}).search;
  assert.deepEqual(m.save(),e);
  return {e,menu,checkpoint:agent.createCheckpoint(),q};
 }finally{port.close();}
}
try{
 let cache=null;
 for(const [i,u] of r.actions.slice(0,13).entries()){
  assert.equal(u.action.actorId,id);
  const warm=decide(cache),cold=[3,4,8,9,10,11].includes(i)&&decide(null);
  assert.equal(warm.q.actionId,u.action.actionId);
  const describe=r=>r&&[r.menu.find(a=>a.actionId===r.q.actionId)?.summary,r.q.value,r.q.diagnostics.nativeExecutions,r.q.diagnostics.planContinuation];
  console.log(i,JSON.stringify([describe(warm),describe(cold)]));
  cache=warm.checkpoint;
  rows.push({i,summary:short(m),action:u.action,warm,...(cold?{cold}:{})});
  m.apply(u.action);
 }
}finally{m.dispose();}
assert(rows.some(r=>r.cold&&r.cold.q.actionId!==r.warm.q.actionId));
writeZ(out,rows);
