'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ}=require('./controlled-r3');
const dir=process.argv[2]||__dirname,load=name=>readZ(path.join(dir,name+'-20261110-v1.json.gz'));
const tech=load('late-tech')[227],purple=load('purple3-cash'),scan=load('orange4-scan'),finalized=load('orange4-scan-finalized');
const income=load('orange4-income'),old=load('scan-plan-reuse'),candidate=load('orange4-candidate'),terminal=load('cache-terminal');
const r4=load('late-supply-r4'),formal=load('formal-cache-parity'),base=load('324-formal-parity');
const metrics={replays:0,inputs:0,autonomous:0,maxNative:0,maxMs:0,scanPairs:0,formalCold:89,formalCached:17};
const normalize=e=>JSON.parse(JSON.stringify(e).split(e.session?.session?.sessionId||'__no_effect_session__').join('effect-session-X'));
function replay(e,steps,end,settled,renumber=false){
 const m=open(e);
 try{
  let passed=false;
  for(const u of steps){
   if(u.n!==undefined){
    assert(u.n<=256&&u.ms<=600);metrics.autonomous++;metrics.maxNative=Math.max(metrics.maxNative,u.n);metrics.maxMs=Math.max(metrics.maxMs,u.ms);
   }
   const a=u.action||u;
   if(settled&&a.family==='pass'&&a.actorId==='player-white'&&m.facts().round===3){assert.deepEqual(m.save(),settled.state);passed=true;}
   m.apply(a);metrics.inputs++;
  }
  if(settled)assert(passed);
  if(renumber)assert.deepEqual(normalize(m.save()),normalize(end));
  else assert.deepEqual(m.save(),end);
  metrics.replays++;
 }finally{m.dispose();}
}
function group(e,g){
 assert.deepEqual(g.failures,[]);
 for(const r of g.rows){replay(e,r.prefix,r.start);replay(r.start,r.actions,r.end,r.settled);}
}
group(tech.e,tech);group(purple.roots[6],purple);group(scan.ready,scan);group(income.ready,income);group(candidate.root,candidate);
replay(scan.e,scan.prefix,scan.ready);replay(scan.ready,[scan.scan],scan.scanOpened,null,true);
assert.equal(finalized.length,18);
for(const [i,r] of scan.results.entries()){
 replay(scan.scanOpened,[r.first,r.second],r.e);
 const f=finalized[i];assert.deepEqual(f.root,r.e);replay(f.root,[f.action],f.end);assert.equal(f.f.wallet[4],2);
 metrics.scanPairs++;
}
replay(terminal.officialStart,terminal.steps,terminal.officialEnd,null,true);
for(const r of Object.values(r4))replay(r.e,r.actions,r.end);
assert.deepEqual(old[10].warm.e,terminal.anchor);
assert.equal(old[10].warm.q.diagnostics.planContinuation,'hit');
assert.equal(old[10].warm.q.value,172.5);
assert.equal(terminal.resumed.diagnostics.planContinuation,'fixed-blue-prefix-competing-income');
assert.equal(terminal.resumed.actionId,old[10].cold.q.actionId);
assert.equal(terminal.resumed.value,173);assert.equal(terminal.resumed.diagnostics.nativeExecutions,3);
assert.deepEqual(income.rows[0].settled.state,candidate.rows[0].settled.state);
assert.deepEqual(candidate.rows[0].settled.summary.income,[7,4,2,1]);
assert.deepEqual(Object.keys(formal),Object.keys(base));assert.equal(Object.keys(formal).length,89);
for(const [k,r] of Object.entries(formal)){
 for(const p of ['a','n','value','roots','complete'])assert.deepEqual(r[p],base[k][p]);
 assert(r.complete&&r.n<=256&&r.ms<=600);
}
assert.deepEqual(Object.values(r4).map(x=>x.stop?.n||x.checkpoints.at(-1).s.established),[197,338,174,257]);
console.log(JSON.stringify(metrics));
