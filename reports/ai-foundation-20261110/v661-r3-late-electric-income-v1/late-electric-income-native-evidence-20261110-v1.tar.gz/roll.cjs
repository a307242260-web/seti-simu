'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [tech,purple,orange,blue,out]=process.argv.slice(2),rows={};
const selected=[readZ(tech)[227].rows.find(r=>r.label==='研究 blue1（蓝槽 4）'),
 readZ(purple).rows.find(r=>r.label==='save-dlc25-pick-known-dlc15'),
 readZ(orange).rows[0],readZ(blue).rows[0]];
for(const r of selected){
 const e=r.settled.state,m=open(e),actions=[],checkpoints=[];
 const take=(a,method)=>actions.push({action:a,method});
 const other=()=>{const seq=[];m.advanceOpponents(seq);seq.forEach(a=>take(a,'passive'));};
 try{
  take(m.act('pass'),'fixed');take(m.act('choose_card',a=>a.target.cardId==='b_111.webp'),'fixed');other();
  assert.equal(m.facts().round,4);assert(!m.save().session);
  const opening=m.save();let last=m.facts().turn,cache=null,stop;
  for(let i=0;i<140;i++){
   if(m.menu()[0]?.actorId!=='player-white'){other();continue;}
   const s=short(m);
   if(!m.save().session&&s.turn>last){
    last=s.turn;checkpoints.push({e:m.save(),s});if(checkpoints.length===2){stop='two-turns';break;}
   }
   const q=m.automatic(cache);
   if(!q.complete||q.n>256||q.ms>600){stop={kind:'gate',n:q.n,ms:q.ms,action:q.a};break;}
   cache=q.checkpoint;actions.push({action:m.apply(q.a),method:'autonomous',n:q.n,ms:q.ms,value:q.value});
   if(q.a.family==='pass'){stop='autonomous-pass';break;}
  }
  assert(stop);
  const end=m.save();m.restore(e);actions.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),end);
  rows[r.label]={e,opening,actions,checkpoints,end,stop};
  console.log(r.label,JSON.stringify(stop),JSON.stringify(checkpoints.map(x=>x.s)));
 }finally{m.dispose();}
}
writeZ(out,rows);
