'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const res=require(path.resolve('randomizer/game/effects/residual-domain-session'));
const d=JSON.parse(z.gunzipSync(fs.readFileSync(process.argv[2])));
const rows=d.rows.filter(r=>r.family==='accept_optional_effect'&&r.origin==='land');
assert.equal(rows.length,20);
const checks=[];
function freeze(obj){if(obj&&typeof obj==='object'&&!Object.isFrozen(obj)){Object.values(obj).forEach(freeze);Object.freeze(obj);}return obj;}
for(const r of rows){
 const before=freeze(d.snapshots[r.envelopes]),after=d.snapshots[r.nextEnvelope],session=before.session.session;
 const known=new Set(session.workingState.players.players.find(p=>p.id===seat).reservedCards.map(c=>c.id));
 const next=res.previewQuietAmibaYellowLanding(session,r.action,known);
 assert(next,r.summary);assert.equal(after.session,null);
 assert.deepEqual(next,JSON.parse(after.committedState),r.summary);
 const m=open(before);
 try{
  m.apply(r.action);
  assert.equal(m.save().session,null);
  assert.deepEqual(JSON.parse(m.save().committedState),next);
  assert.deepEqual(m.menu().map(x=>[x.family,x.target]),r.nextMenu);
  assert.deepEqual(m.state().meta.rngState,session.workingState.meta.rngState);
 }finally{m.dispose();}
 for(const modified of [
  {...session,irreversibleBarrier:{code:'hidden_card_draw'}},
  {...session,queue:[...session.queue,...session.queue]},
  {...session,workingState:{...session.workingState,turn:{...session.workingState.turn,roundNumber:3}}},
  {...session,workingState:{...session.workingState,turn:{...session.workingState.turn,cardTurnEventBonuses:[{}]}}},
  {...session,queue:[{...session.queue[0],payload:{...session.queue[0].payload,matches:[...session.queue[0].payload.matches,...session.queue[0].payload.matches]}}]},
 ])assert.equal(res.previewQuietAmibaYellowLanding(freeze(modified),r.action,known),null);
 assert.equal(res.previewQuietAmibaYellowLanding(session,r.action,new Set()),null);
 checks.push({state:r.envelopes,next:r.nextEnvelope,choice:r.action.target.choiceId,nativeExact:true,menuExact:true,rngExact:true,fallbacks:6});
}
console.log(JSON.stringify({pairs:rows.length/2,inputs:rows.length,fallbacks:6*rows.length}));
fs.writeFileSync(process.argv[3],JSON.stringify(checks,null,2)+'\n',{flag:'wx'});

