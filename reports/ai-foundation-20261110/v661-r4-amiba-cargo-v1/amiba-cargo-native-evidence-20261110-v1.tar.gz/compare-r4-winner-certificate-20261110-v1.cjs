'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const {checkpoint:source}=JSON.parse(fs.readFileSync(process.argv[2]));
const load=n=>require(path.resolve(n)),m=open(source),port=load('randomizer/game/ai/analysis-port').createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
const agent=load('randomizer/game/ai/search-agent').createSearchAgent({seatId:seat,analysisPort:port});
try{
 const q=agent.decide({seatId:seat,legalActions:m.menu()}).search,cp=agent.createCheckpoint();
 assert(q.complete&&cp.plan);assert.deepEqual(m.save(),source);
 const safeRows=cp.plan.rows.map(({actionId,value,realization,preparationDebt,distance,committedGoal,action})=>({actionId,value,realization,preparationDebt,distance,committedGoal,action:action?.family}));
 const w=q.lines[0].retainedWitness;
 const data={action:q.actionId,value:q.value,realization:q.realization,preparationDebt:q.preparationDebt,native:q.diagnostics.nativeExecutions,
  planRows:safeRows,checkpoint:cp,walk:q.lines.map((r,i)=>({i,action:r.bestActionId,edges:r.edges.filter(x=>x.turnTailPlanValue?.computerFiveForeignBlue).map(x=>x.actionId)})).filter(x=>x.edges.length)};
 fs.writeFileSync(process.argv[3],JSON.stringify(data,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({...data,checkpoint:undefined,walk:undefined}));
}finally{port.close();m.dispose();}
