from pathlib import Path
import gzip,json,statistics,subprocess,sys,tempfile
w,b,f,h,out=map(Path,sys.argv[1:])
root=w/'v661-r4-full-preflight-20261109-v1.json'
raw=lambda name: json.load(gzip.open(w/name,'rt'))
first=raw('teacher-r4-first-four-cold-20261110-reuse.json.gz')
later=raw('candidate-r4-active-task-preview-native-20261109-v1.json.gz')
movement=raw('teacher-r4-ready-transport-cold-20261109-v1.json.gz')
rows={r['decision']['input']:r['before'] for r in first['rows']}
rows.update({r['input']:r['root'] for r in later['rows']})
for r in movement['rows']:
 i=r['summary']['i']
 if i in rows:assert rows[i]==r['root'],i
 else:rows[i]=r['root']
modes=[f'root-{i}' for i in sorted(rows)]+['root-official']
with tempfile.TemporaryDirectory() as t:
 target=Path(t)/'teacher.json.gz'
 with gzip.open(target,'wt') as fh:json.dump({'rows':[{'summary':{'i':i},'root':r} for i,r in rows.items()]},fh)
 log=[]
 choices=[('base',b),('candidate',f)]
 for mode in modes:
  for rep in range(3):
   pair=[]
   for label,cwd in (choices if rep%2==0 else choices[::-1]):
    output=Path(t)/f'{mode}-{label}-{rep}.json.gz'
    subprocess.run(['node',str(h/'verify-cargo-research-corner-20261109-v1.cjs'),str(target),str(root),mode,str(output)],cwd=cwd,check=True,capture_output=True)
    q=json.load(gzip.open(output,'rt'))
    assert q['complete'] and q['rootExact'] and not q['unresolved']
    pair.append(q)
    log.append({'version':label,'rep':rep,**{k:q[k] for k in ('mode','native','ms','value','action','rootExact','complete','unresolved')}})
   assert all(pair[0].get(k)==pair[1].get(k) for k in ('action','value','retained','complete','unresolved','plan')),mode
  per=[r for r in log if r['mode']==mode]
  for label,_ in choices:
   sub=[r for r in per if r['version']==label]; ms=[r['ms'] for r in sub]
   print(mode,label,'native',sorted({r['native'] for r in sub}),'median',round(statistics.median(ms),1),
    'range',[round(min(ms),1),round(max(ms),1)],'gate',all(r['native']<=256 and r['ms']<=600 for r in sub),flush=True)
 with out.open('x') as dest:json.dump(log,dest,ensure_ascii=False,indent=2)

