'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),crypto=require('node:crypto');
const [source,official,which,mode,out]=process.argv.slice(2),load=n=>require(path.resolve(n));
const original=Module._extensions['.js'];
const counters={observations:0,hidden:0,menus:0,menuActions:0};
const audit=mode==='audit';
if(audit)Module._extensions['.js']=(m,p)=>{
 let code;
 if(p.endsWith('/randomizer/game/ai/analysis-port.js')){
  code=fs.readFileSync(p,'utf8');
  const at='      observationCount += 1;';
  const hook=`      if(valueOnly){
        const raw=project(fork.composition||fork,false);
        const full=barrier&&ruleComposition.isHiddenInformationBarrier(barrier)
          ?ruleComposition.sanitizeHiddenInformationObservation(rootObservation,raw,barrier,knownCards(envelope)):raw;
        globalThis.verifyValueProjection(visible,full,Boolean(barrier));
      }\n`;
  assert.equal(code.split(at).length,2);
  code=code.replace(at,hook+at);
 }else if(p.endsWith('/randomizer/game/production-composition.js')){
  code=fs.readFileSync(p,'utf8');
  const at='        return standardAction.ALL_FAMILIES.flatMap(family=>byFamily.get(family));';
  const hook=`        const prior=[["quick_trade","play_card"],scienceSession.ACTION_FAMILIES,probeTurnSession.ACTION_FAMILIES,
          residualDomainSession.ACTION_FAMILIES,conditionalFamilies].flatMap(families=>families.flatMap(family=>ownedRegistry.enumerate(context,{...request,family})));
        const ordered=standardAction.ALL_FAMILIES.flatMap(family=>prior.filter(a=>a.family===family));
        globalThis.verifyMenu(standardAction.ALL_FAMILIES.flatMap(family=>byFamily.get(family)),ordered);\n`;
  assert.equal(code.split(at).length,2);
  code=code.replace(at,hook+at);
 }else return original(m,p);
 return m._compile(code,p);
};
const {open,seat}=require('./native-late-r3'),agent=load('randomizer/game/ai/search-agent'),
 {createAnalysisPort}=load('randomizer/game/ai/analysis-port'),value=load('randomizer/game/ai/state-value');
globalThis.verifyValueProjection=(small,full,hidden)=>{
 const copy=x=>{const {securedEndGameBonus,...r}=x;return r;};
 assert.equal(small.publicState.players.length,1);
 assert.deepEqual(copy(small.publicState.players[0]),copy(full.publicState.players.find(p=>p.playerId===seat)));
 assert.deepEqual(small.selfState,full.selfState);
 assert.deepEqual(small.publicState.board,full.publicState.board);
 assert.deepEqual(value.evaluateStateValue(small,seat),value.evaluateStateValue(full,seat));
 assert.equal(value.supportsLegacyValueProof(small),value.supportsLegacyValueProof(full));
 counters.observations++;if(hidden)counters.hidden++;
};
globalThis.verifyMenu=(current,original)=>{
 assert.deepEqual(current,original);counters.menus++;counters.menuActions+=current.length;
};
const fixture=JSON.parse(z.gunzipSync(fs.readFileSync(source))),root=which==='official'?JSON.parse(fs.readFileSync(official)).checkpoint:
 fixture.rows.find(r=>r.summary.i===Number(which)).root;
const m=open(root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=agent.createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 const semantic={actionId:q.actionId,value:q.value,realization:q.realization,preparationDebt:q.preparationDebt,roots:q.roots,lines:q.lines,
  transitions:q.diagnostics.transitions,nativeExecutions:q.diagnostics.nativeExecutions};
 const canonical=x=>Array.isArray(x)?x.map(canonical):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,canonical(x[k])])):x;
 const graph=crypto.createHash('sha256').update(JSON.stringify(canonical(semantic))).digest('hex');
 if(audit)assert(counters.observations>0&&counters.menus>0);
 const r={which,mode,graph,counters,ms:q.rootAndSearchMilliseconds,native:q.diagnostics.nativeExecutions,logical:q.diagnostics.transitions,
  eval:q.diagnostics.valueEvaluations,nodes:q.lines.length,rootAndRngExact:true};
 fs.writeFileSync(out,JSON.stringify(r,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(r));
}finally{p.close();m.dispose();}
