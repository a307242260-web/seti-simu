'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const load=x=>require(path.resolve(x)),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),
 agentApi=load('randomizer/game/ai/search-agent'),search=load('randomizer/game/ai/decision-search'),value=load('randomizer/game/ai/state-value');
const [source,official,mode,out]=process.argv.slice(2);
const {rows,accepted}=JSON.parse(z.gunzipSync(fs.readFileSync(source)));
const roots=Object.fromEntries(rows.map(row=>[String(row.summary.i),row.root]));
roots.official=JSON.parse(fs.readFileSync(official)).checkpoint;
const start=performance.now();
function run(m,prior,budget){
 const before=m.save(),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  let checkpoint,q;
  if(budget)q=search.searchDecision({port:p,root:p.openRoot(),evaluate:value.createStateValueEvaluator(seat),budget:{...agentApi.BUDGET,...budget},...agentApi.OPTIONS});
  else{
   const ai=agentApi.createSearchAgent({seatId:seat,analysisPort:p});if(prior)ai.loadCheckpoint(prior);
   q=ai.decide({seatId:seat,legalActions:m.menu()}).search;checkpoint=ai.createCheckpoint();
  }
  assert.deepEqual(m.save(),before);
  const action=m.menu().find(a=>a.actionId===q.actionId);
  const retained=q.roots.map(r=>[r.actionId,r.completion,r.value,r.realization,r.preparationDebt]);
  const plan=q.lines[0]?.edges.find(e=>e.resourcePlan?.goal.kind==='cargo-research-corner')?.resourcePlan?.goal;
  return {action,checkpoint,retained,plan,complete:q.complete,stop:q.stopReason,unresolved:q.unresolved.length,native:q.diagnostics.nativeExecutions,
    ms:q.rootAndSearchMilliseconds??q.diagnostics.milliseconds,value:q.value,continuation:q.diagnostics.planContinuation};
 }finally{p.close();}
}
let result;
if(mode.startsWith('root-')){
 const name=mode.slice(5),m=open(roots[name]);try{
  const q=run(m);
  result={mode,...q,checkpoint:undefined,rootExact:true};
 }finally{m.dispose();}
}else if(mode.startsWith('limit-')){
 const name=mode.slice(6),m=open(roots[name]);try{
  const q=run(m,null,{transitions:256});
  assert(!q.complete&&!q.action&&q.stop==='transition-budget'&&q.unresolved>0);
  result={mode,...q,rootExact:true};
 }finally{m.dispose();}
}else if(mode.startsWith('cold-paid-')){
 const witness=JSON.parse(z.gunzipSync(fs.readFileSync(process.argv[6]))),want=Number(mode.at(-1)),m=open(roots['317']);
 try{
  let paid=0,expected;
  for(const [i,step] of witness.steps.entries()){
   m.apply(step.a);
   if(step.a.family==='quick_trade'&&step.a.target.tradeId==='energy-for-move'&&++paid===want){expected=witness.steps[i+1].a;break;}
  }
  assert(expected);
  const q=run(m);
  assert.equal(q.action.actionId,expected.actionId);
  assert(q.plan?.paid);
  result={mode,...q,checkpoint:undefined,rootExact:true};
 }finally{m.dispose();}
}else if(mode==='continuation'){
 const m=open(roots['317']),steps=[];let checkpoint;
 try{
  for(let i=0;i<30;i++){
   const q=run(m,checkpoint);assert(q.complete&&q.action&&q.checkpoint);
   const {action:a}=q;
   if(i===0)assert.equal(a.actionId,accepted[317-301].actionId);
   if(i===1)assert.equal(a.actionId,accepted[318-301].actionId);
   if(i>0&&q.native)console.error(JSON.stringify({i,action:a.summary,native:q.native,continuation:q.continuation}));
   m.apply(a);
   steps.push({a,native:q.native,continuation:q.continuation,value:q.value,committedGoal:q.checkpoint.plan.rows.find(row=>row.actionId===a.actionId)?.committedGoal});
   checkpoint=JSON.parse(JSON.stringify(q.checkpoint));
   if(a.family==='end_turn')break;
  }
  assert.equal(steps.at(-1).a.family,'end_turn');
  assert.equal(steps.filter(s=>s.a.family==='complete_task'&&s.a.target.ruleId==='transport').length,2);
  assert.equal(steps.filter(s=>s.a.family==='quick_trade'&&s.a.target.tradeId==='energy-for-move').length,2);
  const end=m.save(),f=m.facts();
  assert.equal(Object.keys(m.state().aliens.chong.transportTasksByRocketId).length,0);
  m.restore(roots['317']);for(const s of steps)m.apply(s.a);assert.deepEqual(m.save(),end);
  result={mode,steps,end,board:f.wallet.score,established:f.final,wallet:f.wallet,tech:f.tech.ownedTiles,exact:true};
 }finally{m.dispose();}
}else throw Error('UNKNOWN_MODE');
result.harnessMs=performance.now()-start;
fs.writeFileSync(out,z.gzipSync(JSON.stringify(result)+'\n'),{flag:'wx'});
console.log(JSON.stringify({mode,chosen:result.action?.summary,tech:result.steps?.find(s=>s.a.target?.tileId)?.a.summary,value:result.value,inputs:result.native,ms:result.ms,stop:result.stop,steps:result.steps?.map(s=>[s.a.summary,s.native,s.continuation]),board:result.board,established:result.established}));
