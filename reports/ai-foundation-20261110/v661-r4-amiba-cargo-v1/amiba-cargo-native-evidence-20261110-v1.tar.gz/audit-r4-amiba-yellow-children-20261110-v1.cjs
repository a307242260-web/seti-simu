'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3'),{checkpoint}=require('./v661-r4-full-preflight-20261109-v1.json');
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const m=open(checkpoint),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&q.value===205.5);assert.deepEqual(m.save(),checkpoint);
 const getId=(e)=>e.actionId;
 const reach=(source)=>{const keys=new Set([source]);const search=[source];for(const id of search)for(const e of q.lines[id].edges){if(!keys.has(e.target)){keys.add(e.target);search.push(e.target);}}return keys;};
 const byId=new Map(JSON.parse(z.gunzipSync(fs.readFileSync(process.argv[3]))).rows.filter(r=>r.family==='accept_optional_effect'&&r.origin==='land').map(r=>[r.action.actionId,r.action.target.choiceId]));
 const results=[];
 for(const line of q.lines){
   if(!line.edges.some(e=>byId.has(e.actionId)))continue;
   const split=line.edges.map(e=>{
    const reachSet=reach(e.target),next=q.lines[e.target];
    return {choice:byId.get(e.actionId),target:e.target,v:next.value,r:next.realization,d:next.preparationDebt,reachable:[...reachSet],subgraph:reachSet.size,immediate:next.edges.map(x=>[getId(x),q.lines[x.target].value])};
   });
   results.push({index:line.node,split});
 }
 console.log(JSON.stringify(results.map(x=>x.split.map(e=>[e.choice.slice(0,55),e.v,e.r,e.d,e.subgraph,e.immediate.length]))));
 fs.writeFileSync(process.argv[2],JSON.stringify({results,native:q.diagnostics.nativeExecutions,proof:q.analysis.provedAmibaYellowLandingInputs,logical:q.diagnostics.transitions,graphNodes:q.diagnostics.graphNodes,peakFrontier:q.diagnostics.peakFrontier},null,2)+'\n',{flag:'wx'});
}finally{port.close();m.dispose();}

