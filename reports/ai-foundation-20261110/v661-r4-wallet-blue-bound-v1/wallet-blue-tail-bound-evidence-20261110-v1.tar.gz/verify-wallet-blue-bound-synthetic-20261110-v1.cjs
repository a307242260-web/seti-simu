'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ}=require('./controlled-r3');
const {evaluateStateValue}=require(path.resolve('randomizer/game/ai/state-value'));
const {sanitizeHiddenInformationObservation}=require(path.resolve('randomizer/game/rule-composition'));
const [a,b,out]=process.argv.slice(2),before=readZ(a)['keep-amiba9'],after=readZ(b)['keep-amiba9'],seat='player-white';
const m=open(before.root),rootObservation=m.owner(seat),base=new Map(before.before.map(r=>[r.key,r])),result=[];
const masked=known=>sanitizeHiddenInformationObservation(rootObservation,m.owner(seat),{code:'hidden_card_reveal'},known);
try{
 for(const r of after.candidate.filter(q=>q.closed)){
  const prev=base.get(r.key),spec=prev.synthetic;assert(prev&&spec);assert.equal(prev.value,r.upperBound);assert(r.upperBound<r.incumbent.value);
  assert.equal(spec.kind,'blue-end-turn');assert.equal(spec.requiredNativeInputs,6);
  const {cardId,continuingDataPlans}=spec.bluePublicPick;
  assert.equal(continuingDataPlans.length,1);assert.equal(continuingDataPlans[0].goal.id,'data:blue:3');
  m.restore(prev.source);
  const v0=evaluateStateValue(masked(prev.known),seat).total;
  const acts=[m.act('place_data'),m.act('choose_target',a=>a.target.blueSlot===2),m.act('choose_card',a=>a.target.cardInstanceId===cardId),
   m.act('place_data'),m.act('choose_target',a=>a.target.blueSlot===3),m.act('end_turn')];
  assert(!m.save().session&&m.state().turn.currentPlayerId!==seat);
  const v1=evaluateStateValue(masked(prev.known),seat).total;
  assert.equal(v0,r.currentValue);assert.equal(v1,r.upperBound);assert.equal(v1-v0,spec.netGain);
  const end=m.save();m.restore(prev.source);acts.forEach(q=>m.apply(q));assert.deepEqual(m.save(),end);
  result.push({key:r.key,v0,v1,gain:v1-v0,incumbent:r.incumbent.value,acts});
 }
 assert.equal(result.length,26);
 writeZ(out,{paths:result.length,inputs:result.reduce((a,b)=>a+b.acts.length,0),result});
 console.log(JSON.stringify({paths:result.length,inputs:result.reduce((a,b)=>a+b.acts.length,0)}));
}finally{m.dispose();}
