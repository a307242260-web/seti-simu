'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),Module=require('node:module');
const ai=path.resolve('randomizer/game/ai'),portFile=path.join(ai,'analysis-port.js'),searchFile=path.join(ai,'decision-search.js');
const extensions=Module._extensions['.js'],captured=new WeakMap(),byIndex=new Map(),quoted=[];
const hash=v=>crypto.createHash('sha256').update(JSON.stringify(v)).digest('hex');
globalThis.walletBoundNode=(node,stored,actionSetKey,known)=>captured.set(node,{stored,actionSetKey,known});
globalThis.walletBoundIndexed=(i,node)=>byIndex.set(i,node);
globalThis.walletBoundQuoted=(i,node,plan,proof,currentValue,upperBound,incumbent)=>quoted.push({i,node,plan,proof,currentValue,upperBound,incumbent:{...incumbent}});
Module._extensions['.js']=(m,f)=>{
 if(f!==portFile&&f!==searchFile)return extensions(m,f);
 let s=fs.readFileSync(f,'utf8');
 const after=(a,b)=>{assert.equal(s.split(a).length,2);s=s.replace(a,a+b);};
 if(f===portFile){
  after('      nodeCount += 1;\n      return node;'.split('\n')[0]+'\n','      globalThis.walletBoundNode(node,nodes.get(node),actionSetKey,()=>knownCards(envelope));\n');
 }else{
  const a='      if(initializeDeferred){configured.queued=nodes[index].queued;nodes[index]=configured;}else nodes.push(configured);';
  after(a,'\n      globalThis.walletBoundIndexed(index,node);');
  const start=s.indexOf('const proof=port.foreignBlueTwoUpperBound');
  if(start>=0){
   const q='            const currentValue=valueForNode(entry.node),upperBound=exactTailSum(currentValue,proof.netGain);';
   const i=s.indexOf(q,start);assert(i>start);
   s=s.slice(0,i+q.length)+'\n            globalThis.walletBoundQuoted(currentIndex,entry.node,alternative.resourcePlan,proof,currentValue,upperBound,incumbent);'+s.slice(i+q.length);
  }
 }
 m._compile(s,f);
};
const {open,readZ,writeZ}=require('./controlled-r3'),{createAnalysisPort}=require(portFile),{createSearchAgent}=require(path.join(ai,'search-agent'));
const [fixture,mode,out]=process.argv.slice(2),{rows}=readZ(fixture),result={},seat='player-white';
function key(i){
 const n=byIndex.get(i),{stored,actionSetKey}=captured.get(n);
 assert(!stored.envelope.session);
 return hash([stored.physicalKey,stored.intent,stored.resourceControl,stored.cardControl,actionSetKey(n.legalActions)]);
}
for(const name of ['keep-amiba9','research-orange3']){
 const root=rows[name].stages.round4.state,m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat});
 quoted.length=0;byIndex.clear();
 try{
  const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete);assert.deepEqual(m.save(),root);
  const candidate=[];const before=[];const meta={value:q.value,n:q.diagnostics.nativeExecutions,nodes:q.diagnostics.graphNodes,roots:q.roots};
  if(mode==='candidate'){
   for(const r of quoted){
    const line=q.lines[r.i],closed=line.actionBounds?.some(x=>x.actionId===r.plan.firstActionId&&x.proof===r.proof.proof);
    candidate.push({key:key(r.i),...r,node:undefined,closed:!!closed,source:captured.get(r.node).stored.envelope});
   }
  }else{
   for(const line of q.lines){
    const edge=line.edges.find(x=>x.resourcePlan?.goal.id==='data:blue:2'
     ||x.turnTailPlanValue?.bluePublicPick&&x.turnTailPlanValue.kind==='blue-end-turn');
    if(!edge||!byIndex.has(line.node)||byIndex.get(line.node).status!=='stable')continue;
    const target=q.lines[edge.target];
    if(target.value===null)continue;
    const steps=[...(edge.steps||[])],seen=new Set();let cur=target;
    while(cur.edges.length){
     if(seen.has(cur.node))break;
     seen.add(cur.node);
     const tails=cur.edges.filter(x=>q.lines[x.target].value===target.value&&q.lines[x.target].distance<cur.distance);
     if(!tails.length)break;
     const a=tails.sort((x,y)=>x.cost+q.lines[x.target].distance-y.cost-q.lines[y.target].distance)[0];
     steps.push(...(a.steps?.length?a.steps:[a.actionId]));cur=q.lines[a.target];
    }
    before.push({key:key(line.node),goal:edge.resourcePlan?.goal.id||'data:blue:2',value:target.value,steps,status:cur.status,synthetic:edge.turnTailPlanValue,known:edge.turnTailPlanValue?[...captured.get(byIndex.get(line.node)).known()]:undefined,
     leaf:cur.edges.length?null:cur.node,source:captured.get(byIndex.get(line.node)).stored.envelope,end:captured.get(byIndex.get(cur.node))?.stored.envelope});
   }
  }
  result[name]={root,meta,candidate,before};
  console.log(JSON.stringify({name,...meta,roots:undefined,quoted:candidate.length,pruned:candidate.filter(x=>x.closed).length,before:before.length,
   possibleLate:candidate.filter(x=>!x.closed&&x.upperBound<q.value).length}));
 }finally{port.close();m.dispose();}
}
writeZ(out,result);
