'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,open}=require('./controlled-r3');
const [before,after,out]=process.argv.slice(2),a=readZ(before),b=readZ(after),result=[];
function normalize(e,tokens){
 const x=structuredClone(e);x.committedState=JSON.parse(x.committedState);
 const s=x.session?.session;if(s){
  s.undoFrames=[];
  if(s.sessionId){
   const walk=v=>typeof v==='string'?v.replaceAll(s.sessionId,'@session'):Array.isArray(v)?v.map(walk):
    v&&typeof v==='object'?Object.fromEntries(Object.entries(v).map(([k,o])=>[k,walk(o)])):v;
   x.session=walk(x.session);
  }
 }
 if(tokens){
  for(const state of [x.committedState,x.session?.session?.workingState,x.session?.session?.baseState]){
   if(!state)continue;delete state.meta.sequences.dataToken;
   for(const p of state.players.players){
    const d=p.dataState;
    const norm=(q,pool)=>{const z={...q};delete z.id;delete z.index;if(pool)delete z.slotIndex;return z;};
    d.poolTokens=d.poolTokens.map(q=>norm(q,true));
    d.placedTokens=d.placedTokens.map(q=>norm(q,false)).sort((v,w)=>v.placementKind.localeCompare(w.placementKind)
     ||(v.placementSlot??v.blueSlot)-(w.placementSlot??w.blueSlot));
   }
  }
 }
 return x;
}
for(const [k,afterGraph] of Object.entries(b)){
 const original=new Map(a[k].before.map(r=>[r.key,r]));
 assert.equal(a[k].meta.value,afterGraph.meta.value);
 const pruned=afterGraph.candidate.filter(r=>r.closed);if(!pruned.length)continue;
 const m=open(original.get(pruned[0].key).source);
 try{
  for(const r of pruned){
   const prev=original.get(r.key);assert(prev?.end);
   assert.equal(prev.value,r.upperBound);assert(r.incumbent.value>r.upperBound);
   assert([4,6].includes(prev.steps.length));assert.equal(prev.status,'information-barrier');
   assert(m.c.lifecycle.restore(prev.source).ok);assert.deepEqual(m.save(),prev.source);
   const actions=prev.steps.map(id=>{const a=m.menu().find(q=>q.actionId===id);assert(a);return m.apply(a);});
   const actual=m.save();assert(!actual.session);assert.notEqual(m.state().turn.currentPlayerId,'player-white');
   let comparison='exact';
   try{assert.deepEqual(normalize(actual,false),normalize(prev.end,false));}
   catch(error){assert.deepEqual(normalize(actual,true),normalize(prev.end,true),String(error).slice(0,500));comparison='interchangeable-data-token-identity';}
   result.push({key:r.key,upperBound:r.upperBound,incumbent:r.incumbent.value,steps:actions.map(q=>q.summary),comparison});
  }
 }finally{m.dispose();}
}
const summary={paths:result.length,inputs:result.reduce((n,r)=>n+r.steps.length,0),comparisons:{}};
for(const r of result)summary.comparisons[r.comparison]=(summary.comparisons[r.comparison]||0)+1;
writeZ(out,{summary,result});console.log(JSON.stringify(summary));
