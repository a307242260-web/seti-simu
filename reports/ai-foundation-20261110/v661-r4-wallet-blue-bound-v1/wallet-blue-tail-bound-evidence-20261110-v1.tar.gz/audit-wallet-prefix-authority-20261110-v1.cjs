'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
const ai=path.resolve('randomizer/game/ai'),file=path.join(ai,'analysis-port.js'),original=Module._extensions['.js'];
let index=new Map(),count=0,exact=[],equivalent=[],exactCommit=[],last=null,actual=0,reusedActual=0,actualSerial=new Set();
const family=a=>a.actionId.split(':')[0];
globalThis.countWalletPrefix=(stored,node,action,key,actionSetKey)=>{
 count++;
 const identity=stored.identity,id=action.actionId,serial=stored.serial;
 const map=index.get(identity)||new Map();index.set(identity,map);
 const seen=map.get(id)||new Map();map.set(id,seen);
 last={stored,node,action,seen,serial,key};
 if(seen.has(serial))return;
 for(const prior of seen.values()){
  equivalent.push({previous:prior.stored.serial,current:serial,family:family(action),status:node.status,
   sameMenus:actionSetKey(node.legalActions)===actionSetKey(prior.node.legalActions)});
  const authority=e=>[e.committedState,e.session];
  if(JSON.stringify(authority(prior.stored.envelope))===JSON.stringify(authority(stored.envelope))
   &&JSON.stringify(prior.stored.informationBarrier)===JSON.stringify(stored.informationBarrier)
   &&actionSetKey(node.legalActions)===actionSetKey(prior.node.legalActions)){
   exact.push({previous:prior.stored.serial,current:serial,family:family(action)});
  }else if(!stored.envelope.session&&!prior.stored.envelope.session)
   exactCommit.push({previous:prior.stored.serial,current:serial,family:family(action)});
 }
 seen.set(serial,{stored,node});
};
globalThis.markWalletNative=()=>{
 actual++;
 if(!last)return;
 if([...last.seen.keys()].some(x=>x!==last.serial&&actualSerial.has(x+':'+last.action.actionId)))reusedActual++;
 actualSerial.add(last.serial+':'+last.action.actionId);
};
Module._extensions['.js']=(m,f)=>{
 if(f!==file)return original(m,f);
 let s=fs.readFileSync(f,'utf8');
 const a='      const key = expansionKey(stored,actionId);',b='      submissionCount += 1;';
 assert.equal(s.split(a).length,2);assert.equal(s.split(b).length,2);
 s=s.replace(a,a+'\n      globalThis.countWalletPrefix(stored,node,requested,key,actionSetKey);');
 m._compile(s.replace(b,'      globalThis.markWalletNative();\n'+b),f);
};
const {readZ,writeZ,open}=require('./controlled-r3'),{createAnalysisPort}=require(file),{createSearchAgent}=require(path.join(ai,'search-agent'));
const [fixture,out]=process.argv.slice(2),{rows}=readZ(fixture),seat='player-white',result={};
for(const k of ['keep-amiba9','research-orange3']){
 index=new Map();count=0;exact=[];equivalent=[];exactCommit=[];last=null;actual=0;reusedActual=0;actualSerial=new Set();
 const root=rows[k].stages.round4.state,m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat});
 try{
  const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete);assert.deepEqual(m.save(),root);assert.equal(actual,q.diagnostics.nativeExecutions);
  const uniqueKeys=[...index.values()].reduce((n,m)=>n+[...m.values()].reduce((q,t)=>q+t.size,0),0);
  const data={count,uniqueKeys,n:actual,
   repeatedEquivalent:equivalent.length,repeatedWithSameMenus:equivalent.filter(e=>e.sameMenus).length,
   repeatedExact:exact.length,repeatedEquivalentCommitted:exactCommit.length,reusedActual,equivalent,exact,exactCommit};
  result[k]=data;
  console.log(JSON.stringify({k,count,uniqueKeys:data.uniqueKeys,n:data.n,equiv:equivalent.length,
   sameMenus:data.repeatedWithSameMenus,exact:exact.length,reusedActual}));
 }finally{port.close();m.dispose();}
}
writeZ(out,result);
