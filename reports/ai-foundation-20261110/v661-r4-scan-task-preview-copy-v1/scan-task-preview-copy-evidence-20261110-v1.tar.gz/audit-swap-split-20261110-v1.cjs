'use strict';
const fs=require('node:fs'),Module=require('node:module'),assert=require('node:assert/strict'),path=require('node:path');
const js=Module._extensions['.js'],fileName='/randomizer/game/ai/probe-capital.js';
const original=fs.readFileSync(path.join(__dirname,'probe-capital-original-20261110-v1.js'),'utf8');
const cut=(s)=>s.slice(s.indexOf('  function prepareFinalRoundSwapMission('),s.indexOf('  function quoteValue('));
const before=cut(original).replace('prepareFinalRoundSwapMission','baselineSwapMission');
const counts={portfolios:0,quotes:0,filtered:0,fixedEndpoints:0,variableEndpoints:0,evaluationCallsSaved:0};
globalThis.auditSwapSplit=(a,b)=>{counts.filtered++;counts.fixedEndpoints+=a;counts.variableEndpoints+=b;return{seen:false,count:a};};
globalThis.auditSwapReuse=o=>{if(o.seen)counts.evaluationCallsSaved+=o.count;o.seen=true;};
process.on('exit',()=>console.error('SWAP_SPLIT_AUDIT '+JSON.stringify(counts)));
Module._extensions['.js']=(mod,file)=>{
 if(!file.endsWith(fileName))return js(mod,file);
 let src=fs.readFileSync(file,'utf8');const body=cut(src);
 src=src.replace(body,body.replace('function prepareFinalRoundSwapMission','function candidateSwapMission')
  .replace('let fixedValue;','let fixedValue;const audit=globalThis.auditSwapSplit(fixed.length,variable.length);')
  .replace('Math.max(fixedValue??=','(globalThis.auditSwapReuse(audit), Math.max(fixedValue??=')
  .replace('variable,moveGoals));','variable,moveGoals)));')+before+`
 function prepareFinalRoundSwapMission(state, player) {
  const old=baselineSwapMission(state,player),next=candidateSwapMission(state,player);countsSplit.portfolios++;
  assertSplit.equal(old.sensitive,next.sensitive);
  return {...next,quote(hand,publicCards){
   const a=old.quote(hand,publicCards),b=next.quote(hand,publicCards);countsSplit.quotes++;assertSplit.equal(a,b);return b;
  }};
 }
 `);
 src=src.replace('  function baselineSwapMission','  const countsSplit=globalThis.swapSplitCounts,assertSplit=require("node:assert/strict");\n  function baselineSwapMission');
 globalThis.swapSplitCounts=counts;mod._compile(src,file);
};
