'use strict';
const fs=require('node:fs'),Module=require('node:module'),path=require('node:path'),assert=require('node:assert/strict');
const js=Module._extensions['.js'],records=[];
Module._extensions['.js']=function(mod,file){
 if(!file.endsWith('/randomizer/game/ai/analysis-port.js'))return js(mod,file);
 const src=fs.readFileSync(file,'utf8');
 const marker='      return {proof:"seti-quiet-final-claim-and-handover-equivalence-v1"';
 assert.equal(src.split(marker).length,2);
 const hook=`globalThis.captureQuietClaim(stored.envelope,
  [action,policy.actions[0]],[node.legalActions.find(a=>a.actionId===endId),confirm],
  x,y,stored.informationBarrier);`;
 mod._compile(src.replace(marker,hook+marker),file);
};
globalThis.captureQuietClaim=(envelope,early,late,x,y,barrier)=>records.push({
 root:{...envelope,committedState:envelope.committedState},early,late,x,y,barrier
});
const {open,seat,z}=require('./native-compact-20261110-v1.cjs');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent,OPTIONS,BUDGET}=require(path.resolve('randomizer/game/ai/search-agent'));
const {searchDecision}=require(path.resolve('randomizer/game/ai/decision-search'));
const {createStateValueEvaluator}=require(path.resolve('randomizer/game/ai/state-value'));
const [file,out,extra]=process.argv.slice(2),{checkpoint:root}=JSON.parse(fs.readFileSync(file)),m=open(root);
const p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
 const count=q.lines.flatMap(l=>l.quietClaimEquivalences||[]).length;
 assert(q.complete&&!q.unresolved.length&&count>0&&count===records.length);assert.deepEqual(m.save(),root);
 const omittedMarkCases=q.lines.filter(l=>l.edges.some(e=>e.actionId.startsWith('complete_task:')
   &&q.lines[e.target]?.status==='decision')).length;
 const previewed=records.slice();
 let nativeInputs=0,masked=0;
 const native=m.c.counterfactualPort.createFork(root,{branchKey:'audit-quiet-claim',restoreRandomState:true}).composition;
 try{
  for(const r of previewed){
   if(r.barrier)masked++;
   for(const [actions,expected] of [[r.early,r.x],[r.late,r.y]]){
     // Preview roots are already-isolated Native states. Restore them
     // exactly, without save-import defaults that would change the input.
     const restored=native.lifecycle.restore(r.root,{trustedFork:true,silent:true,inPlace:true,skipProjection:true});
     assert(restored.ok,restored.message);
     for(const recorded of actions){
       const decision=native.inspect().session?.decision;
       const a=(decision?.choices||native.inputPort.enumerateActions({})).find(a=>a.actionId===recorded.actionId);
       assert(a,recorded.summary);assert.deepEqual(a.target,recorded.target);
       const options={skipProjection:true,omitTrustedResult:true};
       const result=decision?native.inputPort.submitDecision({decisionId:decision.decisionId,decisionVersion:decision.decisionVersion,ownerId:decision.ownerId,choice:a},options)
         :a.phase==='quick'?native.inputPort.submitQuickAction(a,options):native.inputPort.submitAction(a,options);
       assert(result.ok,result.message);nativeInputs++;
     }
     const actual=native.lifecycle.save({trustedFork:true}).envelope;assert.equal(actual.session,null);
     try{assert.deepEqual(JSON.parse(actual.committedState),expected);}catch{
       const a=JSON.parse(actual.committedState),changed=Object.keys(a).filter(k=>JSON.stringify(a[k])!==JSON.stringify(expected[k]));
       throw Error('NATIVE_CLAIM_DIFF '+JSON.stringify([nativeInputs,changed,a.meta,expected.meta]));
     }
   }
  }
 }finally{native.dispose();}
 m.restore(root);assert.deepEqual(m.save(),root);
 let finite=null;
 if(extra){
   const evaluate=createStateValueEvaluator(seat),r=p.openRoot();
   const qFinite=searchDecision({port:p,root:r,evaluate,modelKey:evaluate.modelKey,...OPTIONS,budget:{...BUDGET,nodes:20000}});
   finite={complete:qFinite.complete,claims:qFinite.lines.flatMap(l=>l.quietClaimEquivalences||[]).length,graphNodes:qFinite.diagnostics.graphNodes};
   assert(finite.complete&&finite.claims===0);
 }
 const result={count,nativeInputs,masked,omittedMarkCases,finite,selected:q.actionId,value:q.value,rootExact:true};
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({result,examples:[previewed[0],previewed.find(r=>r.barrier)].filter(Boolean)})),{flag:'wx'});
 console.log(JSON.stringify(result));
}finally{p.close();m.dispose();delete globalThis.captureQuietClaim;}
