'use strict';
const fs=require('node:fs'),Module=require('node:module'),assert=require('node:assert/strict');
const js=Module._extensions['.js'];
const checks={
 'analysis-port.js':{previewQuietSpecifiedScan:['p.dataState','p.reservedCards','base.data','base.aliens']},
 'local-decision-plans.js':{previewKnownPositiveTaskSettlement:['p.reservedCards','state.aliens'],previewForeignTurnAfterQuietHandoffs:['state.turn']},
};
const audited={};
globalThis.verifyPreviewCopy=(source,copy,name)=>{
 assert.deepEqual(copy,structuredClone(source));assert.equal(JSON.stringify(copy),JSON.stringify(source));
 const seen=new WeakMap();
 function detached(a,b){
  if(a===null||typeof a!=='object')return;
  assert.notEqual(a,b);
  if(seen.has(a)){assert.equal(seen.get(a),b);return;}
  seen.set(a,b);
  for(const k of Object.keys(a))detached(a[k],b[k]);
 }
 detached(source,copy);audited[name]=(audited[name]||0)+1;
 return copy;
};
process.on('exit',()=>console.error('COPY_AUDIT '+JSON.stringify(audited)));
Module._extensions['.js']=(mod,file)=>{
 const key=file.split('/randomizer/game/ai/')[1],fields=checks[key]; if(!fields)return js(mod,file);
 let src=fs.readFileSync(file,'utf8');
 for(const [name,terms] of Object.entries(fields)){
  const start=src.indexOf('function '+name+'(');assert(start>=0);
  const len=src.slice(start+1).search(/\n +function /); assert(len>=0);
  const end=start+1+len;
  let body=src.slice(start,end);
  for(const term of terms){
   const expr='copyForkData('+term+')';assert.equal(body.split(expr).length,2);
   body=body.replace(expr,'globalThis.verifyPreviewCopy('+term+','+expr+','+JSON.stringify(name+':'+term)+')');
  }
  src=src.slice(0,start)+body+src.slice(end);
 }
 mod._compile(src,file);
};
