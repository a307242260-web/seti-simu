'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),Module=require('node:module');
const ai=path.resolve('randomizer/game/ai'),file=path.join(ai,'analysis-port.js'),load=Module._extensions['.js'];
let current='',rows=[],snapshots=[],indices=new WeakMap();
const idx=e=>{if(!indices.has(e)){indices.set(e,snapshots.length);snapshots.push(e);}return indices.get(e);};
globalThis.recordWalletFixed=(kind,stored,node,action,after,child)=>{
 const s=stored.envelope.session?.session,barrier=after.informationBarrier||null;
 if(['move-menu','move-payment'].includes(kind)&&!stored.informationBarrier)return;
 if(kind==='specified-to-public'&&s?.queue[1]?.payload?.options?.mode!=='public')return;
 if(kind==='public-tail'&&!(s?.queue.length===2&&s.queue[1].type==='science_domain_scan_finalize'))return;
 if(kind==='purple'&&!['launch','skip'].includes(action.target.mode))return;
 const market=after.envelope.session?.session?.workingState?.cards?.publicCards||JSON.parse(after.envelope.committedState).cards.publicCards;
 const beforeMarket=s?.workingState?.cards?.publicCards||JSON.parse(stored.envelope.committedState).cards.publicCards;
 const exposed=barrier?.code==='hidden_card_reveal'?market.filter((c,i)=>c&&!beforeMarket[i]).map(c=>c.id):[];
 rows.push({key:current,kind,action,source:idx(stored.envelope),target:idx(after.envelope),beforeBarrier:stored.informationBarrier,
  barrier,legal:child.legalActions.map(a=>[a.actionId,a.family,a.target,a.payload]),exposed,view:exposed.length?child.observation:null});
};
Module._extensions['.js']=(m,f)=>{
 if(f!==file)return load(m,f);
 let s=fs.readFileSync(f,'utf8');
 for(const [counter,kind] of [['provedMoveMenus','move-menu'],['provedMovePayments','move-payment'],['provedQuietSpecifiedScans','specified-to-public'],
  ['provedPublicScanChoices','public-tail'],['provedScan4QuietMoves','purple']]){
  const a='        '+counter+'++;';
  assert.equal(s.split(a).length,2);
  s=s.replace(a,`        globalThis.recordWalletFixed(${JSON.stringify(kind)},stored,node,requested,nodes.get(child),child);\n`+a);
 }
 m._compile(s,f);
};
const {readZ,writeZ,open}=require('./controlled-r3'),{createAnalysisPort}=require(file),{createSearchAgent}=require(path.join(ai,'search-agent'));
const [input,out]=process.argv.slice(2),{rows:fixtures}=readZ(input),seat='player-white',results={};
for(const k of ['keep-amiba9','research-orange3']){
 current=k;
 const root=fixtures[k].stages.round4.state,m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat});
 try{
  const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete);assert.deepEqual(m.save(),root);
  results[k]={root,chosen:q.actionId,value:q.value,n:q.diagnostics.nativeExecutions,roots:q.roots};
 }finally{port.close();m.dispose();}
}
const counts={};
for(const r of rows){const key=r.key+':'+r.kind;counts[key]=(counts[key]||0)+1;}
writeZ(out,{counts,results,rows,snapshots});console.log(JSON.stringify(counts));
