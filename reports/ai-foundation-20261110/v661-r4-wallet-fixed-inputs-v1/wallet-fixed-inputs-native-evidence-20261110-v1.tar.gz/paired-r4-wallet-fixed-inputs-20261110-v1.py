from pathlib import Path
import gzip,json,subprocess,sys
root=Path(sys.argv[1]).resolve()
out=Path(sys.argv[2]).resolve()
fixture=Path(sys.argv[3]).resolve()
tool=root/'probe-r4-wallet-shipment-20261110-v1.cjs'
pairs=[]
for i,order in enumerate((('460','462'),('462','460'),('460','462'))):
 row={}
 for v in order:
  dest=out.parent/f'wallet-fixed-pair-{i+1}-v{v}-20261110-v1.json.gz'
  subprocess.run(['node',str(tool),str(fixture),str(dest)],cwd=root/f'candidate-v{v}',check=True,stdout=subprocess.DEVNULL)
  with gzip.open(dest,'rt') as f: row[v]=json.load(f)
 for k in row['460']:
  for field in ('chosen','value','roots','nodes','plan'):
   assert row['460'][k][field]==row['462'][k][field],(k,field)
 pairs.append({v:{k:{x:r[x] for x in ('chosen','value','n','nodes','ms')} for k,r in vals.items()} for v,vals in row.items()})
out.write_text(json.dumps(pairs,indent=2)+'\n')
print(json.dumps(pairs))
