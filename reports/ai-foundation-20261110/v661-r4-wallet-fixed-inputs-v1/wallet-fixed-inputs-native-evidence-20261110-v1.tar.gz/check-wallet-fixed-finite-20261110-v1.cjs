'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {readZ,open}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {searchDecision}=require(path.resolve('randomizer/game/ai/decision-search'));
const {createStateValueEvaluator}=require(path.resolve('randomizer/game/ai/state-value'));
const {BUDGET,OPTIONS}=require(path.resolve('randomizer/game/ai/search-agent'));
const root=readZ(process.argv[2]).rows['keep-amiba9'].stages.round4.state,m=open(root),seat='player-white';
const port=createAnalysisPort({composition:m.c,seatId:seat});
try{
 const evaluate=createStateValueEvaluator(seat);
 const q=searchDecision({port,root:port.openRoot(),evaluate,modelKey:evaluate.modelKey,budget:{...BUDGET,transitions:256},...OPTIONS});
 assert(!q.complete);assert.equal(q.stopReason,'transition-budget');assert.deepEqual(m.save(),root);
 console.log(JSON.stringify({complete:q.complete,stop:q.stopReason,actionId:q.actionId,n:q.diagnostics.nativeExecutions,
  transitions:q.diagnostics.transitions,remaining:q.unresolved.length,nodes:q.diagnostics.graphNodes}));
}finally{port.close();m.dispose();}
