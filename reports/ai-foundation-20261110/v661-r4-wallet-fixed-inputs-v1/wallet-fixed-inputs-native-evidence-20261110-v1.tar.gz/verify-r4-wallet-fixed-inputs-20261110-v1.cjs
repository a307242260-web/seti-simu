'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,open}=require('./controlled-r3');
const [file,out]=process.argv.slice(2),x=readZ(file),m=open(x.results['keep-amiba9'].root),diffs=[],counts={};
function normalize(e){
 const q=structuredClone(e);q.committedState=JSON.parse(q.committedState);
 const s=q.session?.session;
 if(s){s.undoFrames=[];const id=s.sessionId;
  if(id){
   const walk=v=>typeof v==='string'?v.replaceAll(id,'@session'):Array.isArray(v)?v.map(walk):
    v&&typeof v==='object'?Object.fromEntries(Object.entries(v).map(([k,t])=>[k,walk(t)])):v;
   q.session=walk(q.session);
  }
 }
 return q;
}
try{
 for(const [i,r] of x.rows.entries()){
  const source=x.snapshots[r.source],target=x.snapshots[r.target],key=r.key+':'+r.kind;
  assert(m.c.lifecycle.restore(source).ok);
  assert.deepEqual(normalize(m.save()),normalize(source));
  const d=m.c.inspect().session?.decision;
  const a=m.menu().find(v=>v.actionId===r.action.actionId);
  assert(a,r.action.actionId);assert.deepEqual(a.target,r.action.target);
  const submitted=d?m.c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
    :m.c.inputPort.submitQuickAction(a);
  assert(submitted.ok);
  try{assert.deepEqual(normalize(m.save()),normalize(target));}
  catch(error){diffs.push({i,key,error:String(error).slice(0,2100)});}
  const native=new Set(m.menu().map(v=>JSON.stringify([v.actionId,v.family,v.target,v.payload])));
  for(const menu of r.legal)assert(native.has(JSON.stringify(menu)),JSON.stringify({i,key,menu}));
  if(r.beforeBarrier)assert.deepEqual(r.beforeBarrier,r.barrier);
  if(r.exposed.length){
   assert(r.barrier?.code==='hidden_card_reveal');
   for(const id of r.exposed){
    assert(!JSON.stringify(r.view).includes(JSON.stringify(id)));
    assert(!JSON.stringify(r.legal).includes(JSON.stringify(id)));
   }
  }
  counts[key]=(counts[key]||0)+1;
 }
 writeZ(out,{counts,diffs});
 console.log(JSON.stringify({counts,diffs:diffs.length,examples:diffs.slice(0,3)}));
 assert.equal(diffs.length,0);
}finally{m.dispose();}
