'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const [teacherOpening,teacherTrace,ai265,aiTeacher,out]=process.argv.slice(2);
const read=x=>JSON.parse(z.gunzipSync(fs.readFileSync(x)));
const log=x=>fs.readFileSync(x,'utf8').trim().split('\n').map(JSON.parse);
const tRoot=read(teacherOpening).rows.find(r=>r.decision.input===249).before;
const recorded=read(teacherTrace).full.slice(4);
function replay(m,root,steps,end){
 m.restore(root);for(const a of steps)m.apply(a);assert.deepEqual(m.save(),end);
}
function result(m,root,accepted,before){
 const end=m.save(),s=m.state();
 assert(s.turn.gameEnded&&s.match.finalScoringSettled);
 const p=s.match.finalScores.find(x=>x.playerId===seat);
 replay(m,root,accepted,end);
 return {root,end,accepted,before,exact:true,score:{board:p.baseScore,tile:p.tileScore,card:p.cardScore,total:p.totalScore}};
}
const outcomes={};
for(const [name,file] of [['aiFromTeacher265',ai265],['aiFromTeacherOpeningAfterTwo',aiTeacher]]){
 const entries=log(file),e=entries.at(-1);
 assert(e.pass&&e.exactReplay&&!e.failed);assert.deepEqual(e.pass.before,e.end);
 const m=open(e.end);
 try{
  const before=m.facts(),a=m.apply(e.pass.action);
  outcomes[name]=result(m,entries[0].root,[...e.accepted,a],before);
 }finally{m.dispose();}
}
const m=open(tRoot),accepted=[],round=[];
try{
 const white=recorded.filter(a=>a.actorId===seat);
 for(const a of white){
  m.advanceOpponents(accepted);
  if(a.family==='pass')round.push(m.facts());
  accepted.push(m.apply(a));
 }
 assert.equal(round.length,1);
 outcomes.teacherWithSamePassers=result(m,tRoot,accepted,round[0]);
 assert.equal(outcomes.teacherWithSamePassers.score.total,388);
}finally{m.dispose();}
fs.writeFileSync(out,z.gzipSync(JSON.stringify(outcomes)+'\n'),{flag:'wx'});
for(const [k,v] of Object.entries(outcomes))console.log(JSON.stringify({k,score:v.score,accepted:v.accepted.length,wallet:v.before.wallet,
 tech:Object.keys(v.before.tech.ownedTiles).length,hand:v.before.hand.length,probes:v.before.probes.map(p=>p.kind||'probe')}));

