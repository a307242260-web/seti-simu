'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const solar=require(path.resolve('randomizer/solar-system/core')), rockets=require(path.resolve('randomizer/game/rockets'));
const {aiFromTeacher265:d}=JSON.parse(z.gunzipSync(fs.readFileSync(process.argv[2])));
const variants=[
 {free:[0,-1],later:[[-1,0],[0,-1]]},
 {free:[-1,0],later:[[0,-1],[0,-1]]},
];
const results=[];
for(const v of variants){
 const m=open(d.root),accepted=[];const take=a=>{accepted.push(a);return a;};
 const cargoId=6;
 function step(dx,dy){return take(m.act('choose_target',x=>x.target.rocketId===cargoId&&x.target.deltaX===dx&&x.target.deltaY===dy));}
 try{
  let freeRoot;
  for(const [i,a] of d.accepted.entries()){
   if(i===48)break;
   if(i===29){freeRoot=m.save();step(...v.free);}
   else take(m.apply(a));
  }
  const paidRoot=m.save(),before=m.facts(),s=m.state(),ship=s.pieces.rockets.find(r=>r.id===cargoId),earth=solar.collectPlanetLocations(s.solarSystem).find(p=>p.planetId==='earth');
  assert.equal(before.wallet.energy,2);assert.deepEqual([earth.x,earth.y],[1,1]);
  for(const [dx,dy] of v.later){take(m.act('quick_trade',x=>x.target.tradeId==='energy-for-move'));step(dx,dy);}
  assert(m.state().aliens.chong.transportTasksByRocketId['5'].delivered);
  const delivery=take(m.act('complete_task',a=>a.target.ruleId==='transport'));
  const after=m.facts();
  take(m.act('pass'));
  const end=m.save(),final=m.state().match.finalScores.find(p=>p.playerId===seat);
  assert(m.state().turn.gameEnded&&m.state().match.finalScoringSettled);
  m.restore(d.root);for(const a of accepted)m.apply(a);assert.deepEqual(m.save(),end);
  results.push({direction:v,freeRoot,paidRoot,from:rockets.getRocketSectorCoordinate(ship),before,after,delivery,accepted,end,
   score:{board:final.baseScore,tile:final.tileScore,card:final.cardScore,total:final.totalScore},rootAndRngExact:true});
 }finally{m.dispose();}
}
fs.writeFileSync(process.argv[3],z.gzipSync(JSON.stringify({original:d.score,results})+'\n'),{flag:'wx'});
console.log(JSON.stringify(results.map(x=>({direction:x.direction,score:x.score,cargo:x.delivery.summary,wallet:x.after.wallet}))));

