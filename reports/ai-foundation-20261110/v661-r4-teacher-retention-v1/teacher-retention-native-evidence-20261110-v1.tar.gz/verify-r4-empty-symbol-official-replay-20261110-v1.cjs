'use strict';
const assert=require('node:assert/strict'),{open,read}=require('./native-late-r3');
const [pre,save]=process.argv.slice(2),s=read(save),m=open(read(pre).checkpoint);
try {
  const steps=s.replaySteps.slice(261);
  for(const x of steps)m.apply(x.action);
  const a=m.save();
  assert.deepEqual(a.session,s.session);assert.equal(a.committedState,s.committedState);
  assert.equal(m.state().match.finalScores.find(p=>p.playerId==='player-white').totalScore,216);
  console.log(JSON.stringify({replayedInputs:steps.length,terminalPhase:m.state().turn.phase,score:m.facts().final,exactStateSessionAndRng:true}));
}finally{m.dispose();}
