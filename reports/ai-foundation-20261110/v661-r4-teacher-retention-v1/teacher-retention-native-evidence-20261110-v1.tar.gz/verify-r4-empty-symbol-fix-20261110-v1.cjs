'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const evidence=JSON.parse(fs.readFileSync(process.argv[2])),root=evidence.root,m=open(root);
try{
 const before=m.facts(),s=m.state(),actions=m.menu(),results={};
 assert.equal(actions.length,2);
 assert(!Object.keys(s.aliens.amiba.symbolSlots).some(k=>k.startsWith('blue_')));
 for(const selected of actions){
  m.restore(root);m.apply(selected);const f=m.facts(),e=m.save();
  assert.equal(e.session,null);
  assert.equal(f.wallet.score,before.wallet.score);
  assert.deepEqual(f.rng,before.rng);
  assert(m.menu().length>0);
  assert.deepEqual(m.state().aliens.amiba.symbolSlots,s.aliens.amiba.symbolSlots);
  const confirmed=selected.target.choiceId.startsWith('confirm:');
  assert.equal(f.taskCount-before.taskCount,Number(confirmed));
  assert.equal(f.reserved.includes('amiba_1.webp'),!confirmed);
  results[confirmed?'confirm':'skip']={action:selected,endpoint:e,taskDelta:f.taskCount-before.taskCount,nextMenu:m.menu().map(a=>a.actionId)};
 }
 m.restore(root);
 assert.deepEqual(m.save(),root);
 fs.writeFileSync(process.argv[3],JSON.stringify({root,results,rootAndRngExact:true},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({choices:Object.keys(results),nativeMenus:Object.values(results).map(r=>r.nextMenu.length),rngExact:true}));
}finally{m.dispose();}

