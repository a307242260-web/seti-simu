'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {open,seat}=require('./native-late-r3');
const [mode,out,replayPath]=process.argv.slice(2);
assert(['ai','keep-scan','same-teacher-opening','teacher-reference','resume'].includes(mode));
const load=n=>JSON.parse(z.gunzipSync(fs.readFileSync(path.join(__dirname,n))));
const root265=load('teacher-r4-first-four-cold-20261110-reuse.json.gz').rows.find(r=>r.decision.input===265).before;
const native=load('teacher-r4-full-native-actions-20261110-reuse.json.gz').full;
const prior=()=>fs.readFileSync(path.join(__dirname,'r4-amiba1-control-teacher-first-two-turns-20261110-v1.jsonl'),'utf8').trim().split('\n').map(JSON.parse);
const already=replayPath?fs.readFileSync(replayPath,'utf8').trim().split('\n').map(JSON.parse):null;
const root=mode==='resume'?already[0].root:mode==='same-teacher-opening'?prior().filter(r=>r.kind==='turn').at(-1).end:root265;
const m=open(root),fd=fs.openSync(out,'wx'),all=[],turns=[],queries=[];
const write=obj=>{fs.writeSync(fd,JSON.stringify(obj)+'\n');fs.fsyncSync(fd);};
const patchFacts=()=>{
 const f=m.facts(),s=m.state(),v=m.owner(seat);
 return {...f,scan:Object.entries(s.data.nebulae).map(([id,b])=>[id,b.tokens.filter(t=>t.replacedByPlayerId===seat).map(t=>t.slotIndex)]).filter(x=>x[1].length),
  cargo:s.aliens.chong?.transportTasksByRocketId,marks:s.finalScoring,aliens:v.publicState.board.aliens.slots};
};
function accept(action,origin){
 const a=m.apply(action);all.push(a);
 if(a.actorId===seat&&a.family==='end_turn'){
  const entry={kind:'turn',count:turns.length+1,actions:all.length,origin,checkpoint:m.save(),facts:patchFacts()};
  turns.push(entry);write(entry);
 }
}
function replay(){
 const end=m.save();m.restore(root);for(const a of all)m.apply(a);assert.deepEqual(m.save(),end);
 return end;
}
const limit=5;
let failed,pass,checkpoint;
try{
 write({kind:'root',mode,root,facts:patchFacts(),maxOwnTurns:limit,gates:{native:256,ms:600}});
 if(mode==='resume'){
  for(const e of already){
   if(e.kind==='decision'){assert(e.complete&&e.native<=256&&e.ms<=600);accept(e.action,'replayed-prior-prefix');}
   if(e.kind==='passive')for(const a of e.actions)accept(a,'replayed-passive');
  }
  write({kind:'resume',inputs:all.length,root:m.save(),facts:patchFacts()});
 }else if(mode==='keep-scan'){
   for(const a of native.slice(20,27))accept(a,'fixed-teacher-first-scan');
   assert.equal(turns.length,1);
 }else if(mode==='teacher-reference'){
   for(const a of native.slice(20)){
    if(a.actorId===seat&&a.family==='pass'||turns.length===limit)break;
    accept(a,'teacher-native');
   }
 }
 if(mode!=='teacher-reference')for(let i=0;i<140&&turns.length<limit;i++){
   const passive=[];m.advanceOpponents(passive);all.push(...passive);
   if(passive.length)write({kind:'passive',actions:passive});
   const before=m.save();
   let q;
   try{q=m.automatic(checkpoint);}catch(error){
    assert.deepEqual(m.save(),before);
    failed={kind:'rule-or-search-failure',i,turn:turns.length+1,before,message:error.message,code:error.code};write(failed);break;
   }
   const selected=q.roots?.filter(x=>x.actionId===q.a?.actionId);
   const row={kind:'decision',i,turn:turns.length+1,action:q.a,value:q.value,native:q.n,ms:q.ms,complete:q.complete,selected};
   queries.push(row);write(row);
   if(!q.complete||q.n>256||q.ms>600){failed={...row,before,roots:q.roots};break;}
   if(q.a.family==='pass'){pass={...row,before};break;}
   accept(q.a,'autonomous');checkpoint=q.checkpoint;
 }
 const end=replay();assert(failed||pass||turns.length===limit);
 write({kind:'end',mode,accepted:all,failed,pass,end,exactReplay:true});
 console.log(JSON.stringify({mode,steps:all.length,queries:queries.length,peakNative:Math.max(0,...queries.map(x=>x.native)),peakMs:Math.max(0,...queries.map(x=>x.ms)),
  failed:failed&&[failed.i,failed.action?.summary,failed.native,failed.ms,failed.message],pass:!!pass,
  turns:turns.map(t=>{const f=t.facts;return[t.count,f.wallet.score,f.final,Object.keys(f.tech.ownedTiles).length,
   f.wallet.credits,f.wallet.energy,f.wallet.availableData,f.wallet.publicity,f.hand.length,f.probes.map(p=>[p.id,p.kind||'probe',p.sectorX,p.sectorY])];})}));
}finally{fs.closeSync(fd);m.dispose();}

