'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const [inPath,out]=process.argv.slice(2);
const api=path.resolve('randomizer/game/ai/analysis-port.js'),native=Module._extensions['.js'];
let diagnostic;
globalThis.captureEmptyNativeAnalysis=(inspection,sourceAction,source,envelope)=>{diagnostic={inspection,sourceAction,source:source.envelope,end:envelope};};
Module._extensions['.js']=(mod,p)=>{
 if(p!==api)return native(mod,p);
 const source=fs.readFileSync(p,'utf8'),anchor='        throw new Error("ANALYSIS_EMPTY_NONTERMINAL");';
 assert.equal(source.split(anchor).length,2);
 mod._compile(source.replace(anchor,'        globalThis.captureEmptyNativeAnalysis(inspection,sourceAction,source,envelope);\n'+anchor),p);
};
const {open}=require('./native-late-r3');
const entries=fs.readFileSync(inPath,'utf8').trim().split('\n').map(JSON.parse);
const m=open(entries[0].root),steps=[];
try{
 for(const e of entries){
  if(e.kind==='decision'){assert(e.complete&&e.native<=256&&e.ms<=600);m.apply(e.action);steps.push(e.action);}
  else if(e.kind==='passive')for(const a of e.actions){m.apply(a);steps.push(a);}
 }
 const root=m.save(),menu=m.menu();
 let error;
 try{m.automatic();}catch(e){error=e;}
 assert.equal(error?.message,'ANALYSIS_EMPTY_NONTERMINAL');
 assert(diagnostic);assert.deepEqual(m.save(),root);
 const state=diagnostic.end.session?.session?.workingState??JSON.parse(diagnostic.end.committedState);
 fs.writeFileSync(out,JSON.stringify({root,menu,steps,diagnostic,exact:true},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({rootMenu:menu.map(a=>[a.family,a.summary]),a:diagnostic.sourceAction,
  endPhase:diagnostic.inspection.phase,endMenu:diagnostic.inspection.session?.decision?.choices,
  endQueue:diagnostic.end.session?.session?.queue.map(x=>[x.type,x.payload]),
  symbols:state.aliens.amiba.symbolSlots},null,2));
}finally{m.dispose();}

