'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{open,z,seat}=require('./native-late-r3');
const {evaluateStateValue}=require(path.resolve('randomizer/game/ai/state-value'));
const {sanitizeHiddenInformationObservation}=require(path.resolve('randomizer/game/rule-composition'));
const [fixture,twoFile,teacherFile,out]=process.argv.slice(2),read=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const {root,end:scanEnd}=read(fixture),two=read(twoFile),teacher=read(teacherFile).teacherTurns[2].actions;
const m=open(root),origin=m.owner(seat),initial=new Set([...origin.selfState.hand,...origin.selfState.reservedCards,...origin.publicState.board.publicCards].filter(Boolean).map(c=>c.id));
const displays={amiba:origin.publicState.board.aliens.amibaTraces.displayedCardIndex,chong:origin.publicState.board.aliens.chongOffer.displayedCardIndex};
const rows=[];
function plan(kind){
 const from=kind==='triton-scan'?two.source:scanEnd;
 m.restore(from);
 assert.equal(m.facts().turn,8);assert.equal(m.facts().round,4);assert(m.state().turn.activePlayerIds.every(id=>id===seat||m.state().turn.passedPlayerIds.includes(id)));
 const known=new Set(initial),actions=[];
 const inspect=()=>{
  const x=sanitizeHiddenInformationObservation(origin,m.owner(seat),{code:'hidden_card_reveal'},known),v=evaluateStateValue(x,seat);
  return {value:v.total,components:v.components,facts:m.facts(),envelope:m.save(),unknownHand:x.selfState.hand.filter(c=>c.hidden).length};
 };
 const before=inspect();
 const apply=(a)=>{
  assert(a,kind+' missing choice: '+m.menu().map(x=>x.summary).join(', '));
  for(const id of [a.target?.cardInstanceId,...(a.target?.cardIds||[])])if(id)assert(known.has(id),kind+' used newly unknown card');
  assert(!a.target?.fossilId,kind+' selected a fossil');
  const originalHand=new Set(m.player().hand.map(c=>c.id));
  const cardDisplay=String(a.target?.choiceId||'').match(/^(amiba|chong):display:(\d+)$/);
  if(cardDisplay)assert.equal(Number(cardDisplay[2]),displays[cardDisplay[1]]);
  actions.push(m.apply(a));
  if(cardDisplay){
   const gained=m.player().hand.filter(c=>!originalHand.has(c.id));assert.equal(gained.length,1);
   known.add(gained[0].id);
  }
 };
 const step=(f,p=()=>true)=>apply(m.menu().find(x=>x.family===f&&p(x)));
 const choose=p=>step('choose_target',p);
 const exact=a=>apply(m.menu().find(x=>x.actionId===a.actionId&&x.actorId===seat));
 const phases=[];
 if(kind==='triton-scan'){
  for(const a of two.replayed.actions)exact(a);
 }else{
  if(kind==='enceladus-card')step('play_card',a=>a.target.cardInstanceId===teacher[0].target.cardInstanceId);
  else{step('quick_trade',a=>a.target.tradeId==='credits-for-energy');step('land');}
  choose(a=>a.target?.landTarget?.satelliteId==='enceladus');phases.push({phase:'land',...inspect()});
  exact(teacher[2]);exact(teacher[3]);
  if(kind==='enceladus-card-blind')exact(teacher[4]);
  else step('choose_card',a=>a.target.choiceId===`chong:display:${displays.chong}`);
  exact(teacher[5]);exact(teacher[6]);exact(teacher[7]);exact(teacher[8]);
  phases.push({phase:'sector-rewards',...inspect()});
  if(kind==='enceladus-card'){
   assert(m.menu().every(a=>a.target?.fossilId));
  }else{
   for(const a of teacher.slice(10))exact(a);
  }
 }
 const after=inspect(),closed=after.facts.turn===9&&!m.save().session;
 if(kind==='enceladus-card')assert(!closed);else assert(closed);
 rows.push({kind,closed,before,after,phases,actions,known:[...known]});
}
try{
 for(const kind of ['triton-scan','enceladus-standard','enceladus-card'])plan(kind);
 m.restore(root);assert.deepEqual(m.save(),root);
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({rows,rootExact:true})+'\n'),{flag:'wx'});
 for(const r of rows)console.log(JSON.stringify([r.kind,r.closed,r.before.value,r.after.value,r.after.facts.wallet,r.after.facts.final,r.after.components,r.actions.map(a=>a.summary)]));
}finally{m.dispose();}
