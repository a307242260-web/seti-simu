'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{open,z,seat}=require('./native-late-r3');
const value=require(path.resolve('randomizer/game/ai/state-value')),probe=require(path.resolve('randomizer/game/ai/probe-capital'));
const [fixture,out]=process.argv.slice(2),source=JSON.parse(z.gunzipSync(fs.readFileSync(fixture))).end,m=open(source);
try{
 const facts=probe.factsFromObservation(m.owner(seat),seat),weights=value.DEFAULT_WEIGHTS,investment=()=>0;
 const row=probe.quote({...facts,investment},weights),control=probe.quote({...facts,uncontestedRound:false,investment},weights);
 assert.equal(row.selected.id,control.selected.id);
 assert.equal(row.value-control.value,7);
 const before={wallet:m.facts().wallet,components:value.evaluateStateValue(m.owner(seat),seat).components};
 const actions=[m.act('quick_trade',a=>a.target.tradeId==='credits-for-energy'),m.act('land'),
  m.act('choose_target',a=>a.target.landTarget?.satelliteId==='enceladus')];
 for(const entry of row.selected.ledger.filter(x=>x.selected)){
  actions.push(m.act('choose_target',a=>a.target.nebulaId===entry.selected.id));
  if(entry.selected.sectorClosure)actions.push(m.act('choose_target',a=>a.target.stateExtra&&a.target.alienSlotId===1));
 }
 assert.equal(m.save().session,null);
 const after={wallet:m.facts().wallet,components:value.evaluateStateValue(m.owner(seat),seat).components};
 assert.equal(after.wallet.score-before.wallet.score,19);assert.equal(after.wallet.publicity-before.wallet.publicity,2);
 assert.equal(after.wallet.availableData-before.wallet.availableData,3);
 assert.equal(after.components.probePotential,0);
 const endpoint=m.save();m.restore(source);assert.deepEqual(m.save(),source);
 for(const action of actions)m.apply(action);
 assert.deepEqual(m.save(),endpoint);
 m.restore(source);assert.deepEqual(m.save(),source);
 const output={quote:row.selected,control:control.selected,increment:row.value-control.value,before,after,actions,endpoint,replayedExact:true,rootAndRngUnchanged:true};
 fs.writeFileSync(out,z.gzipSync(JSON.stringify(output)+'\n'));console.log(JSON.stringify([output.increment,before.components,after.components,actions.length]));
}finally{m.dispose();}
