'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),root=d.roots[259].e,m=open(root),rows={};
const choices=m.menu(),opening=m.automatic(),seat='player-white';
try{
 for(const x of choices){
  m.restore(root);
  const inputs=[m.apply(x)];m.advanceOpponents(inputs);
  const s=m.save(),facts=short(m);
  m.restore(root);inputs.forEach(m.apply);assert.deepEqual(m.save(),s);
  const menus=m.menu(),q=m.automatic();
  const base={s,facts,inputs,q:{n:q.n,ms:q.ms,value:q.value,a:q.a,complete:q.complete,
   roots:q.roots.filter(r=>r.value!=null).map(r=>[menus.find(a=>a.actionId===r.actionId)?.summary,r.value])}};
  console.log(x.summary,JSON.stringify(base.q));
  rows[x.summary]=base;
 }
 writeZ(out,{root,opening:{action:opening.a,roots:opening.roots,n:opening.n,ms:opening.ms},rows});
}finally{m.dispose();}
