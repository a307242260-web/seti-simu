'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,open,runCases,short}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),root=d.roots[238].e;
const m=open(root),u=m.automatic();assert(u.complete&&u.n<=256&&u.ms<=600);m.dispose();
const sw=(into,out='b_16.webp')=>({m,take,cut})=>{take(...m.swap(out,into));cut('after-swap');};
const knownPrepare=h=>{
 sw('dlc_14.png')(h);
 const {m,act,take,cut}=h;
 const step=(f,id)=>act(f,a=>id==null||a.target?.choiceId===id);
 step('end_turn');step('analyze');step('choose_target','trace:1:blue:amiba:3');
 step('choose_card','amiba:display:2');
 take(m.corner('dlc_17.png'));take(m.corner('amiba_2.webp'));
 for(let i=0;i<3;i++){step('place_data');step('choose_target','data:computer');}
 step('end_turn');cut('hold-dlc14-dlc25');
};
const cases=[
 ['swap-dlc14',sw('dlc_14.png')],
 ['swap-dlc14-over-income',sw('dlc_14.png','dlc_25.png')],
 ['known-hold',knownPrepare],
 ['known-free-launch',h=>{knownPrepare(h);h.take(h.m.play('dlc_14.png'));h.cut('launch-menu');}],
 ['known-free-launch-after-blue-energy',h=>{knownPrepare(h);h.take(h.m.play('dlc_14.png'));h.cut('launch-menu');}]
];
// The last variant waits for the real launch; slot-four funding is tested independently.
cases.pop();
const all=runCases(root,cases);
writeZ(out,{root,all,source:238});
