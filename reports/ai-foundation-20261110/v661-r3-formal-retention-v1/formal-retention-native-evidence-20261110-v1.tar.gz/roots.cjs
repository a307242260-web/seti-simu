'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),{open,short,writeZ}=require('./controlled-r3');
const ledger=JSON.parse(fs.readFileSync(__dirname+'/formal-native.json')),ref=JSON.parse(fs.readFileSync(__dirname+'/formal-save.json')),initial=ledger.roundStarts['3'];
const m=open(initial.envelope),roots={},actions=ref.replaySteps;
try{
 for(let step=initial.beforeInput;step<=actions.length;step++){
  const a=actions[step-1].action;
  if(step>=214){
   const e=m.save(),s=short(m);roots[step]={e,s,action:a,menu:m.menu()};
   console.log(step,s.turn,JSON.stringify(s.wallet),s.hand.join(','),s.computer.join(''),s.blue.join(''),a.family,a.summary);
  }
  m.apply(a);
 }
 assert.deepEqual(m.save(),ledger.envelope);
 writeZ(process.argv[2],{roots,close:m.save(),sameNativeEndpoint:true});
}finally{m.dispose();}
