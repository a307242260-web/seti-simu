'use strict';
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [source,out]=process.argv.slice(2),d=readZ(source),root=d.roots[235].e;
const play=id=>({m,take,cut})=>{take(m.play(id));cut('after-main-open');};
const all=runCases(root,[
 ['b16-blue-scan',play('b_16.webp')],
 ['analyze-first',({act,cut})=>{act('analyze');cut('after-main-open');}],
 ['known-dlc17-payment',({m,take,cut})=>{take(...m.swap('amiba_5.webp','dlc_17.png'));take(m.play('dlc_17.png'));cut('after-main-open');}],
]);
writeZ(out,{root,all});
