'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [startPath,jupiterPath,output]=process.argv.slice(2);
const starts=readZ(startPath).rows,jupiter=readZ(jupiterPath),rows=[];
for(const [id,row] of Object.entries(starts))for(const [at,e] of [['round-open',row.s],['after-jupiter',jupiter[id].stages[1].e]])for(const mode of id==='b_32.webp'?['extra','display']:['data','draw','score']){
 const m=open(e),actions=[],stages={},confirmations=[];
 const take=a=>{actions.push(a);return a;},act=(f,p)=>take(m.act(f,p));
 function settle(prefix){
  for(let k=0;k<12;k++){
   if(m.menu().some(a=>a.family==='end_turn'))return;
   const options=m.menu().map(a=>a.target.ruleId).filter(Boolean);
   const a=act('accept_optional_effect',a=>a.target.choiceId?.startsWith('confirm:trigger:')
     &&(!options.includes('b111-scan-'+mode)||a.target.ruleId==='b111-scan-'+mode));
   confirmations.push({prefix,id:a.target.ruleId,options,after:short(m)});
  }
  assert.fail('unclosed trigger sequence');
 }
 try{
  stages.start=short(m);
  take(m.play(id));
  if(mode==='extra')act('choose_target',a=>a.target.choiceId==='trace:1:yellow:state-extra');
  if(mode==='display'){
   act('choose_target',a=>a.target.choiceId==='trace:1:yellow:amiba:4');
   act('choose_card',a=>a.target.choiceId==='amiba:display:8');
  }
  settle('play');act('end_turn');m.advanceOpponents(actions);
  stages.afterPlay=short(m);
  while(m.player().resources.energy<2)act('quick_trade',a=>a.target.tradeId==='credits-for-energy');
  const targetId=m.state().cards.publicCards.find(a=>a?.cardId==='b_16.webp').id;
  act('scan');act('choose_target',a=>a.target.nebulaId==='sector-4-a');
  act('choose_card',a=>a.target.cardInstanceId===targetId&&a.target.nebulaId==='sector-3-a');
  if(m.menu().some(a=>a.target.choiceId==='public:done'))act('choose_card',a=>a.target.choiceId==='public:done');
  if(m.menu().some(a=>a.target.choiceId==='scan4:skip'))act('choose_target',a=>a.target.choiceId==='scan4:skip');
  settle('scan');stages.beforeEnd=short(m);act('end_turn');m.advanceOpponents(actions);
  stages.afterScan=short(m);
  const end=m.save();m.restore(e);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  rows.push({id,at,mode,root:e,actions,stages,confirmations,end,exact:true});
  console.log(JSON.stringify({id,at,mode,n:actions.length,trigger:confirmations.map(x=>[x.prefix,x.id]),start:stages.start.wallet,play:stages.afterPlay.wallet,scan:stages.afterScan.wallet,est:stages.afterScan.established,hand:stages.afterScan.hand,display:stages.afterScan.amibaOffer,tech:stages.afterScan.tech}));
 }finally{m.dispose();}
}
assert.equal(rows.length,10);
writeZ(output,{rows});
