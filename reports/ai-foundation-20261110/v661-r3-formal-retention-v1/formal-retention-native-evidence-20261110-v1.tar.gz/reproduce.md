# Reproduction

Use a clean SETI snapshot of 8e726ec32 (the published strategy sources are identical to 8bd4208b2). Run from the SETI root. Nothing requires a browser, new game registration, or an autoplayed whole game.

Extract this archive, set E to the extraction directory, and run `node "$E/check-native.cjs"`. It submits recorded legal input through Production, checks the complete stored endpoint after each segment, and checks the recorded decision limits. This does not recompute policy or overwrite the artifacts.

To rebuild the evidence, use an empty copy of the extraction directory or fresh output names. For roots.cjs provide the following existing Git files under the stated names in the script directory:

* formal-native.json: reports/ai-foundation-20261109/v661-early-transport-boundary-v1/v661-first3-independent-replay-20261109-v1.checkpoint.json
* formal-save.json: seti-saves/seti-save-research-ai-search-v661-white-first3-20261109-de3eb34e-quick-400-v115.json

Run `node "$E/roots.cjs" <roots.gz>`. Each of moves.cjs, bank.cjs, public-supply.cjs, late-main.cjs and pass-card.cjs takes <roots.gz> and a fresh output. r4-two.cjs takes <pass-card-output.gz> and a fresh output. For the second pair of turns, use the archived formal-r4-after-two-starts input, preserving the cold-resume boundary. scan-retention.cjs takes <pass-card-output.gz>, <r4-two-output.gz>, <fresh-output.gz>; second-scan.cjs and third-scan.cjs take the immediately preceding matched-scan output and a fresh output path. Timing may vary; a decision above the original limit is recorded as unaccepted.
