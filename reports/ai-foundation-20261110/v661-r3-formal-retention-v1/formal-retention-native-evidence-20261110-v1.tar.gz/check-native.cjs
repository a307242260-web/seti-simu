'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ}=require('./controlled-r3');
const dir=process.argv[2]||__dirname;
const file=n=>readZ(path.join(dir,n+'-20261110-v1.json.gz'));
let segments=0,inputs=0,decisions=0,maxNative=0,maxMs=0;
const replay=(root,actions,expected)=>{
 const m=open(root);
 try{
  for(const x of actions){
   if(x.n!==undefined){
    assert(x.n<=256&&x.ms<=600);
    decisions++;maxNative=Math.max(maxNative,x.n);maxMs=Math.max(maxMs,x.ms);
   }
   m.apply(x.action?.actionId?x.action:x);
  }
  assert.deepEqual(m.save(),expected);
  inputs+=actions.length;segments++;
 }finally{m.dispose();}
};
const d=file('formal-r3-roots');
const roots=Object.values(d.roots);
replay(roots[0].e,roots.map(x=>x.action),d.close);
const move=file('formal-r3-move-pairs').rows;
for(const [k,x] of Object.entries(move))replay(k.startsWith('r4:')?move.none.stage.r4.e:d.roots[258].e,x.seq,x.stage.r4.e);
for(const x of Object.values(file('formal-r3-bank-r4')))replay(x.source,x.actions,x.e);
for(const n of ['formal-public-supply','formal-r3-late-main-counterfactual']){
 const v=file(n);
 for(const x of v.all.rows)replay(v.root,[...x.prefix,...x.actions],x.end);
}
const pass=file('formal-pass-card');
assert.equal(pass.opening.roots.length,2);
assert(pass.opening.roots.every(r=>r.value===188.5));
for(const x of Object.values(pass.rows))replay(pass.root,x.inputs,x.s);
for(const n of ['formal-r4-pass-card-first-two','formal-r4-pass-card-next-two']){
 for(const x of Object.values(file(n))){
  assert.equal(x.stop,'two-own-turns');
  replay(x.root,x.inputs,x.end);
 }
}
for(const n of ['formal-r4-pass-card-matched-scan-all','formal-r4-pass-card-second-matched-scan','formal-r4-pass-card-third-matched-scan']){
 for(const x of file(n).rows)replay(x.root,x.actions,x.end);
}
console.log(JSON.stringify({segments,inputs,decisions,maxNative,maxMs}));
