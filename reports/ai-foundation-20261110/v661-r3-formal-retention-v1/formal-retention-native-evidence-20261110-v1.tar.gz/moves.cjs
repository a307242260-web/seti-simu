'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,short,readZ,writeZ}=require('./controlled-r3');
const n=require(path.resolve('randomizer/game/production-kernel')),solar=require(path.resolve('randomizer/solar-system/core'));
const [infile,out]=process.argv.slice(2),fixture=readZ(infile),root=fixture.roots[258].e,m=open(root),rows={};
const seat='player-white',actions=[null,...m.menu().filter(a=>a.family==='move')];
function directory(){const s=m.state(),r=n.getProbeRouteRequirements(s,seat);
 return {pos:short(m).probes,rotation:s.solarSystem.rotation,
  loc:solar.collectPlanetLocations(s.solarSystem).filter(p=>['earth','jupiter','saturn'].includes(p.planetId)),
  list:r.candidates.map(x=>({id:x.requirementId,planet:x.planetId,from:x.start,required:x.required,positions:x.targets?.length,cost:x.targetBenefit?.score,raw:x}))};
}
const tryMove=(take,a)=>{
 take(m.apply(a));
 const pay=m.menu().find(x=>x.family==='choose_payment'&&x.target.kind==='move-payment'&&!x.target.cardIds.length);
 if(!pay)return false;
 take(m.apply(pay));
 return true;
};
const reserve=take=>{
 take(m.act('pass'));
 take(m.act('choose_card',a=>a.target.choiceId==='card-30-pass-3-1'));
 const opp=[];m.advanceOpponents(opp);opp.forEach(take);
};
try{
 for(const move of actions){
  m.restore(root);const seq=[],take=a=>seq.push(a),stage={};
  if(move&&!tryMove(take,move)){
   console.log(move.summary,'not paid by 1 energy');continue;
  }
  stage.r3={e:m.save(),s:short(m),dir:directory()};
  reserve(take);
  stage.r4={e:m.save(),s:short(m),dir:directory()};
  const end=m.save();m.restore(root);seq.forEach(m.apply);assert.deepEqual(m.save(),end);
  rows[move?.summary??'none']={seq,stage};console.log(move?.summary??'none',JSON.stringify({s:stage.r3.s,s4:stage.r4.s,dir:stage.r4.dir.list.map(r=>[r.id,r.planet,r.required])}));
 }
 const orig=rows.none.stage.r4.e;m.restore(orig);
 const late=m.menu().filter(a=>a.family==='move');
 for(const a of late){
  m.restore(orig);const seq=[];
  if(!tryMove(x=>seq.push(x),a))continue;
  rows['r4:'+a.summary]={seq,stage:{r4:{e:m.save(),s:short(m),dir:directory()}}};
 }
 writeZ(out,{rows});
}finally{m.dispose();}
