'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,short,readZ,writeZ}=require('./controlled-r3');
const native=require(path.resolve('randomizer/game/production-kernel'));
const [file,out]=process.argv.slice(2),fixture=readZ(file),rows={},seat='player-white';
const choices=[
 ['formal',258,0,null],['keep-six',242,0,null],['keep-analysis-reward',245,0,null],['computer3',247,3,null],
 ['computer2-pool1',247,2,null],['computer2-blue2',247,2,1],
];
function build(label,step,computer,blue,planet){
 const source=fixture.roots[step].e,m=open(source),actions=[],stages={};
 const act=(f,p)=>{const a=m.act(f,p);actions.push(a);return a;};
 const cut=k=>stages[k]={e:m.save(),s:short(m),at:actions.length};
 const data=(slot)=>{act('place_data');act('choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');};
 const corner=id=>actions.push(m.corner(id));
 const advance=()=>{if(m.menu()[0]?.actorId!==seat)m.advanceOpponents(actions);};
 const finish=()=>{
  act('end_turn');
  for(let i=0;i<12&&m.c.inspect().phase==='awaiting_input';i++){
   const q=m.menu();
   if(q[0]?.actorId!==seat)break;
   const a=q.find(a=>a.target?.choiceId?.startsWith('confirm:task:'))||q.find(a=>a.target?.choiceId?.startsWith('skip:'))
      ||q.find(a=>a.target?.choiceId==='final:b');
   assert(a,q.map(x=>x.summary).join('/'));actions.push(m.apply(a));
  }
  advance();
 };
 const fill=()=>{
  while(m.facts().computer.length<6&&m.player().resources.availableData){
   data();
   if(m.c.inspect().phase==='awaiting_input'){
    const a=m.menu().find(a=>a.target?.choiceId==='income:card-60-0')||m.menu().find(a=>a.target?.choiceId==='income:card-30-pass-3-1');
    assert(a,m.menu().map(x=>x.summary).join('/'));actions.push(m.apply(a));
   }
  }
 };
 const close=(status)=>{
  const e=m.save();m.restore(source);actions.forEach(m.apply);assert.deepEqual(m.save(),e);
  return {status,source,actions,stages,e,replayExact:true};
 };
 try{
  for(let i=0;i<computer;i++)data();
  if(blue)data(blue);
  if(m.player().mainActionCompleted)finish();
  cut('r3-settled');
  act('pass');act('choose_card',a=>a.target.choiceId==='card-30-pass-3-1');advance();cut('r4-start');
  const req=native.getProbeRouteRequirements(m.state(),seat).candidates.find(r=>r.planetId===planet&&r.endpointFamily==='land'&&r.endpointTarget.type==='planet');
  assert(req);
  while(m.player().resources.energy<req.required.energy)act('quick_trade',a=>a.target.tradeId==='credits-for-energy');
  for(const q of req.path){
   act('move',a=>a.target.rocketId===req.rocketId&&a.target.deltaX===q.deltaX&&a.target.deltaY===q.deltaY);
   if(m.c.inspect().phase==='awaiting_input')act('choose_payment',a=>a.target.kind==='move-payment'&&!a.target.cardIds.length);
  }
  act('land');
  if(m.menu().some(a=>a.target?.planetId===planet&&a.target?.actionType==='land'))act('choose_target',a=>a.target?.planetId===planet&&a.target.landTarget.type==='planet');
  act('choose_target',a=>a.target?.choiceId==='trace:1:yellow:state-extra');
  if(m.menu().some(a=>a.target?.choiceId?.includes('amiba0-yellow-data')))act('accept_optional_effect',a=>a.target?.choiceId?.startsWith('confirm:trigger:'));
  cut('landed');
  fill();
  if(m.facts().computer.length<6&&m.facts().hand.some(x=>x[1]==='dlc_15.png')){corner('dlc_15.png');fill();}
  finish();cut('before-analysis');
  if(m.facts().computer.length<6)return close('cannot-analyze');
  act('analyze');act('choose_target',a=>a.target?.choiceId==='trace:1:blue:state-extra');
  cut('after-analysis');
  if(m.facts().income.energy===3&&m.facts().hand.some(x=>x[1]==='dlc_25.png'))fill();
  finish();cut('after-two');
  return close('matched-two-mains');
 }catch(e){return {status:'infeasible',message:String(e).slice(0,600),source,actions,stages,menu:m.menu()};}
 finally{m.dispose();}
}
for(const p of ['saturn','jupiter'])for(const spec of choices){
 const r=build(...spec,p);
 rows[p+':'+spec[0]]=r;
 console.log(p,spec[0],r.status,r.message||JSON.stringify(Object.entries(r.stages).map(([k,x])=>[k,x.s.wallet,x.s.established,x.s.hand,x.s.computer,x.s.blue,x.s.income])));
}
writeZ(out,rows);
