'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [src,output]=process.argv.slice(2),d=readZ(src),rows={},seat='player-white';
for(const [id,row] of Object.entries(d.rows)){
 const first=row.q;assert(first.complete&&first.n<=256&&first.ms<=600);
 const root=row.s,m=open(root),inputs=[],stages={},cold={};
 let saved,started=m.facts().turn,turns=0,stop;
 try{
  for(let i=0;i<85;i++){
   const q=m.menu()[0];assert(q);
   if(q.actorId!==seat){const a=[];m.advanceOpponents(a);inputs.push(...a.map(action=>({action,passive:true})));continue;}
   const now=m.facts().turn;
   if(now!==started){started=now;turns++;stages[turns]={e:m.save(),s:short(m)};if(turns===2){stop='two-own-turns';break;}}
   const t=m.automatic(saved);
   if(!t.complete||t.n>256||t.ms>600){stop={gate:[t.n,t.ms],action:t.a?.summary};break;}
   if(!i||t.a.phase==='main')cold[inputs.length]={value:t.value,n:t.n,ms:t.ms,action:t.a.summary};
   saved=t.checkpoint;
   inputs.push({action:m.apply(t.a),n:t.n,ms:t.ms,value:t.value});
  }
  assert(stop);const end=m.save();m.restore(root);inputs.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),end);
  rows[id]={root,inputs,stages,cold,stop,end,exact:true};console.log(id,JSON.stringify({stop,cold,stages:Object.fromEntries(Object.entries(stages).map(([k,x])=>[k,x.s]))}));
 }finally{m.dispose();}
}
writeZ(output,rows);
