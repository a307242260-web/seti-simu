'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [source,output]=process.argv.slice(2),rows=[];
for(const previous of readZ(source).rows){
 const {id,mode,end:root}=previous,m=open(root),actions=[],legal=[];
 const act=(f,p)=>{const a=m.act(f,p);actions.push(a);return a;};
 try{
  act('quick_trade',a=>a.target.tradeId==='credits-for-energy');
  act('scan');act('choose_target',a=>a.target.nebulaId==='sector-4-a');
  const card=m.state().cards.publicCards.find(a=>a?.cardId==='dlc_16.png');
  assert(card);
  act('choose_card',a=>a.target.cardInstanceId===card.id&&a.target.nebulaId==='sector-2-a');
  if(m.menu().some(a=>a.target.choiceId==='public:done'))act('choose_card',a=>a.target.choiceId==='public:done');
  if(m.menu().some(a=>a.target.choiceId==='scan4:skip'))act('choose_target',a=>a.target.choiceId==='scan4:skip');
  legal.push(...m.menu().map(a=>a.target.ruleId).filter(Boolean));
  if(id==='b_111.webp'){
   assert.equal(legal.length,1);assert(!legal.includes('b111-scan-'+mode));
   act('accept_optional_effect',a=>a.target.ruleId===legal[0]);
  }else assert.equal(legal.length,0);
  act('end_turn');m.advanceOpponents(actions);
  const end=m.save(),s=short(m);m.restore(root);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  rows.push({id,mode,root,actions,legal,s,end,exact:true});
  console.log(JSON.stringify({mode,legal,n:actions.length,w:s.wallet,est:s.established,hand:s.hand}));
 }finally{m.dispose();}
}
assert.equal(rows.length,5);writeZ(output,{rows});
