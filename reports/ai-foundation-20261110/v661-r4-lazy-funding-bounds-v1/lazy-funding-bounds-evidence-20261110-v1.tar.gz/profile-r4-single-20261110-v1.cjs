'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const [mode,file,out]=process.argv.slice(2),data=JSON.parse(file.endsWith('.gz')?z.gunzipSync(fs.readFileSync(file)):fs.readFileSync(file));
const root=mode==='teacher272'?data.rows[0].root:data.checkpoint,m=open(root);
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 const d=p.getDiagnostics(),summary={action:q.actionId,value:q.value,ms:q.rootAndSearchMilliseconds,diagnostics:q.diagnostics,port:d,
  roots:q.roots.map(r=>[r.actionId,r.value,r.realization,r.preparationDebt])};
 fs.writeFileSync(out,JSON.stringify(summary,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({mode,action:summary.action,value:summary.value,ms:summary.ms,native:q.diagnostics.nativeExecutions,graph:q.diagnostics.graphNodes,
   valueEvaluations:q.diagnostics.valueEvaluations,port:d.milliseconds}));
}finally{p.close();m.dispose();}
