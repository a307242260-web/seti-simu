Run from the SETI source root, using the two repository states of this report.
The audit independently loads the baseline implementations from 2c55c7128 without installing them as the active policy:
node <archive-dir>/audit-funding-and-capital-20261110-v1.cjs <baseline-source-dir> official <archive-dir>/v661-r4-full-preflight-20261109-v1.json /private/tmp/seti-funding-audit.json
For the other modes, choose teacher272 with the teacher archive, satellite with satellite-local-root, or r3 with the two root fixtures.
Run the included compare-full-graphs script with <mode> <root> <fresh output> once from each repository to verify complete graph digests. The profile script accepts the three fourth-round single-root modes. All output paths must be new.
