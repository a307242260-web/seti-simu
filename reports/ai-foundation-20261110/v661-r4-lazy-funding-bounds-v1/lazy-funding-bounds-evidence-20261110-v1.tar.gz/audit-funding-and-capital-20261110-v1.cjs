'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),assert=require('node:assert/strict'),Module=require('node:module');
const [before,mode,file,out]=process.argv.slice(2),counts={},profiles={};
const names={value:'state-value',demand:'resource-demand'};
function install(name,text,cache){
 const filename=path.resolve('randomizer/game/ai/'+name+'.js'),m=new Module(filename,module);
 m.filename=filename;m.paths=Module._nodeModulePaths(path.dirname(filename));
 if(cache)Module._cache[filename]=m;
 m._compile(text,filename);m.loaded=true;return m.exports;
}
const source=(name,root=process.cwd())=>fs.readFileSync(path.join(root,'randomizer/game/ai/'+name+'.js'),'utf8');
const oldValue=install(names.value,source(names.value,before),false),oldDemand=install(names.demand,source(names.demand,before),false);
globalThis.auditCapital=(fn,facts,weights,compute)=>{
 const a=compute(),b=oldValue[fn](facts,weights);
 assert.deepEqual(a,b,fn);
 const key=fn+'/r'+facts.round;counts[key]=(counts[key]||0)+1;
 return a;
};
globalThis.auditFunding=(state,seat,goal,allow,compute)=>{
 const a=compute(),b=oldDemand.capacity(state,seat,goal,allow);
 assert.equal(a,b,JSON.stringify({goal,allow,round:state.turn.roundNumber}));
 const key='capacity/r'+state.turn.roundNumber+'/'+goal.kind;counts[key]=(counts[key]||0)+1;
 return a;
};
let sv=source(names.value);
for(const fn of ['purposeCapital','incomePreparationCapital']){
 const from=`  function ${fn}(facts,${fn==='purposeCapital'?' ':''}weights${fn==='purposeCapital'?' = ':'='}DEFAULT_WEIGHTS) {`;
 assert.equal(sv.split(from).length,2,from);
 sv=sv.replace(from,from+`\n    return globalThis.auditCapital('${fn}',facts,weights,()=>${fn}Implementation(facts,weights));\n  }\n  function ${fn}Implementation(facts,weights) {`);
}
install(names.value,sv,true);
let rd=source(names.demand),from='  function capacity(state,seatId,goal,allowBlue=true){';
assert.equal(rd.split(from).length,2);
rd=rd.replace(from,from+'\n    return globalThis.auditFunding(state,seatId,goal,allowBlue,()=>capacityImplementation(state,seatId,goal,allowBlue));\n  }\n  function capacityImplementation(state,seatId,goal,allowBlue){');
install(names.demand,rd,true);
const {open}=require('./native-late-r3'),data=JSON.parse(file.endsWith('.gz')?z.gunzipSync(fs.readFileSync(file)):fs.readFileSync(file));
const roots=mode==='r3'?data.rows.map(x=>[String(x.summary.i),x.root]):[[mode,mode==='teacher272'?data.rows[0].root:data.checkpoint]];
for(const [label,root] of roots){
 const m=open(root);
 try{
  const q=m.automatic();
  assert(q.complete);assert.deepEqual(m.save(),root);
  profiles[label]={action:q.a.actionId,value:q.value,native:q.n};
 }finally{m.dispose();}
}
fs.writeFileSync(out,JSON.stringify({counts,profiles,sourceExact:true},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({profiles,checked:Object.values(counts).reduce((a,b)=>a+b,0),kinds:Object.keys(counts).length}));
