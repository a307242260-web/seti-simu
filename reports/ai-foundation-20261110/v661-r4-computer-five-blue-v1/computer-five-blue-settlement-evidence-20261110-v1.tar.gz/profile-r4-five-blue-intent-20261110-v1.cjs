'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),assert=require('node:assert/strict'),Module=require('node:module');
const [official,out]=process.argv.slice(2),{checkpoint:root}=JSON.parse(fs.readFileSync(official));
const original=Module._extensions['.js'],counts={};
globalThis.fiveCount=(k)=>{counts[k]=(counts[k]||0)+1;return null;};
Module._extensions['.js']=(m,p)=>{
 if(!p.endsWith('/randomizer/game/ai/analysis-port.js'))return original(m,p);
 let code=fs.readFileSync(p,'utf8');
 for(const [f,e,arg] of [['quietR4ComputerFiveBlue','quietR4Blue3Pick','true'],['quietBluePublicPick','quietR4ComputerFiveBlue','foreignFive']]){
  const a=code.indexOf('    function '+f+'('),b=code.indexOf('    function '+e+'(',a);let i=0;
  const body=code.slice(a,b).replace('}) {','}) {\n      if('+arg+')globalThis.fiveCount("'+f+':enter");')
   .replace('}){','}){\n      if('+arg+')globalThis.fiveCount("'+f+':enter");')
   .replaceAll('return null;',()=>`return ${arg}?globalThis.fiveCount("${f}:${++i}"):null;`);
  code=code.slice(0,a)+body+code.slice(b);
 }
 code=code.replace('      if(state.turn.roundNumber!==4||!stored.informationBarrier||stored.intent||stored.resourceControl\n        ||transition.nextPlayerId===seatId||plan.goal.id!=="data:blue:2"',
  `      if(placements.length===5&&plan.goal.id==="data:blue:2")globalThis.fiveCount(JSON.stringify({round:state.turn.roundNumber,bar:stored.informationBarrier?.code,
    intent:stored.intent&&{path:stored.intent.path.length,timing:stored.intent.goal.timing,kind:stored.intent.goal.kind,
      at:rockets.getRocketSectorCoordinate(state.pieces.rockets.find(r=>r.id===stored.intent.rocketId)),
      goal:stored.intent.goal.coordinate,policy:goalMovementSpec(node)?.reason},control:Boolean(stored.resourceControl),same:transition.nextPlayerId===seatId,
    reward:data.getBlueBonusPlacementReward(owner,2)?.type,cargo:Object.values(state.aliens.chong?.transportTasksByRocketId||{}).some(job=>!job.delivered),
    inert:hasPostMainInertReservations(state,false,true,true),place:cardEffects.hasMatchingTrigger(owner,{type:"placeData",playerId:seatId,placementKind:"blueBonus",blueSlot:2})}));
  if(state.turn.roundNumber!==4||!stored.informationBarrier||stored.intent||stored.resourceControl
        ||transition.nextPlayerId===seatId||plan.goal.id!=="data:blue:2"`);
 code=code.replace('return result&&{...result,computerFiveForeignBlue:true};','if(result)globalThis.fiveCount("accepted");return result&&{...result,computerFiveForeignBlue:true};');
 return m._compile(code,p);
};
const {open,seat}=require('./native-late-r3'),m=open(root),load=p=>require(path.resolve(p));
const p=load('randomizer/game/ai/analysis-port').createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=load('randomizer/game/ai/search-agent').createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete);assert.deepEqual(m.save(),root);
 const record={counts,native:q.diagnostics.nativeExecutions,edges:q.lines.flatMap(l=>l.edges.filter(e=>e.turnTailPlanValue?.computerFiveForeignBlue)).length};
 fs.writeFileSync(out,JSON.stringify(record,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(record));
}finally{p.close();m.dispose();}
