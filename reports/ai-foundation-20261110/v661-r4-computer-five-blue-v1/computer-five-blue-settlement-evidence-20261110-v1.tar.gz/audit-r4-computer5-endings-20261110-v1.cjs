'use strict';
const fs=require('node:fs'),z=require('node:zlib'),assert=require('node:assert/strict'),path=require('node:path'),crypto=require('node:crypto');
const {open,seat}=require('./native-late-r3');
const [input,out]=process.argv.slice(2),d=JSON.parse(z.gunzipSync(fs.readFileSync(input))),by=new Map(d.rows.map(r=>[r.i,r]));
const V=require(path.resolve('randomizer/game/ai/state-value')).createStateValueEvaluator(seat);
const stable=x=>Array.isArray(x)?'['+x.map(stable).join(',')+']':x&&typeof x==='object'
 ?'{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+stable(x[k])).join(',')+'}':JSON.stringify(x);
const sha=x=>crypto.createHash('sha256').update(stable(x)).digest('hex');
const rows=[];
for(const src of d.rows)for(const edge of src.edges){
 if(edge.g!=='data:computer-prefix:5')continue;
 const mid=by.get(edge.to),es=mid.edges;
 const end=es.find(a=>a.a.startsWith('end_turn:')&&a.t==='end-turn');
 const blue=es.find(a=>a.a.startsWith('place_data:')&&a.g==='data:blue:2');
 if(es.length!==2||!end||!blue)continue;
 const endExpected=by.get(end.to),afterBlue=by.get(blue.to);
 const picked=afterBlue.edges[0];assert.equal(afterBlue.edges.length,1);
 const blueExpected=by.get(picked.to);
 const source=stable(JSON.parse(mid.envelope.committedState));
 const m=open({...mid.envelope,committedState:source});
 try{
  const afterComputer=m.save(),p=m.player(),nativeSteps=[];
  const act=(family,predicate)=>{const a=m.act(family,predicate);nativeSteps.push([a.actionId,a.family,a.target]);return a;};
  const finish=(edgeId)=>{
   act('end_turn',edgeId?a=>a.actionId===edgeId:undefined);
   assert.equal(m.save().session,null,'quiet end may not add a pending decision');
   return {facts:{...m.facts(),actor:m.state().turn.currentPlayerId},value:V.details(m.owner(seat)),save:m.save(),steps:nativeSteps.splice(0)};
  };
  const direct=finish(end.a);
  m.restore(afterComputer);
  const next=JSON.parse(afterBlue.envelope.committedState),q=next.players.players.find(q=>q.id===seat);
  const newCards=q.hand.filter(c=>!p.hand.some(h=>h.id===c.id));
  assert.equal(newCards.length,1);const card=newCards[0];
  assert(m.state().cards.publicCards.some(c=>c?.id===card.id),'known graph choice must currently be in the actual market');
  act('place_data',a=>a.actionId===blue.a);
  act('choose_target',a=>a.target.target==='blueBonus'&&a.target.blueSlot===2);
  act('choose_card',a=>a.target.cardInstanceId===card.id&&a.target.choiceId==='pick:'+card.id);
  const exactBlue=sha(m.state())===sha(next);
  if(picked.t==='blue-end-turn'){
   assert(picked.a.startsWith('place_data:'));
   act('place_data',a=>a.actionId===picked.a);
   const blues=m.menu().filter(a=>a.target.target==='blueBonus');
   assert.equal(blues.length,1,'native must confirm only one remaining blue slot');
   const selected=act('choose_target',a=>a.actionId===blues[0].actionId);
   assert.equal(selected.target.blueSlot,3);
  }else assert.equal(picked.t,'end-turn');
  const continued=finish(picked.t==='end-turn'?picked.a:null);
  const actualGain=continued.value.value-direct.value.value, expectedGain=blueExpected.value-endExpected.value;
  const f=(r)=>({score:r.facts.wallet.score,established:r.facts.final,wallet:r.facts.wallet,hand:r.facts.hand,actor:r.facts.actor,turn:r.facts.turn,
    rng:r.facts.rng,details:r.value,saveSha:sha(r.save),steps:r.steps});
  assert.equal(actualGain,expectedGain);
  assert.equal(direct.value.value,endExpected.value);
  assert.equal(continued.value.value,blueExpected.value);
  assert.equal(continued.value.purposePreparationDebt,direct.value.purposePreparationDebt);
  assert.equal(-direct.value.unrealizedPurposeValue,endExpected.realization);
  assert.equal(-continued.value.unrealizedPurposeValue,blueExpected.realization);
  assert.notEqual(continued.facts.actor,seat);
  assert.deepEqual(continued.facts.rng,direct.facts.rng);
  assert.equal(continued.facts.turn,direct.facts.turn);
  assert.equal(continued.facts.actor,direct.facts.actor);
  m.restore(afterComputer);
  rows.push({source:src.i,afterComputer:mid.i,exactBlue,expectedGain,actualGain,thirdBlue:picked.t==='blue-end-turn',direct:f(direct),continued:f(continued)});
 }finally{m.dispose();}
}
assert.equal(rows.length,44);
const groups={};
for(const r of rows)groups[r.actualGain]=(groups[r.actualGain]||0)+1;
const result={count:rows.length,exactBlue:rows.filter(r=>r.exactBlue).length,groups,actorIds:[...new Set(rows.map(r=>r.continued.actor))],additionalBlue3:rows.filter(r=>r.thirdBlue).length,rows};
fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({...result,rows:undefined}));
