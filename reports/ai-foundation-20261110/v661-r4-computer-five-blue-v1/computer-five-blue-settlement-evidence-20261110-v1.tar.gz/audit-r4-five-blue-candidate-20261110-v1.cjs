'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),z=require('node:zlib');
const [teacher,official,which,out]=process.argv.slice(2);
const load=n=>require(path.resolve(n)),orig=Module._extensions['.js'];
const snapshots=new WeakMap(),proofs=new Map();
globalThis.captureFive=(node, stored, spec, known)=>{
 assert(known.has(spec.bluePublicPick.cardId));
 snapshots.set(spec,{base:V.details(port.valueObservation(node)),source:stored.envelope,spec,known:known.size,barrier:stored.informationBarrier?.code});
};
globalThis.validateFiveEdge=(spec)=>{
 if(!spec?.computerFiveForeignBlue)return;
 assert(snapshots.has(spec));proofs.set(spec,snapshots.get(spec));
};
Module._extensions['.js']=(m,p)=>{
 let code;
 if(p.endsWith('/randomizer/game/ai/analysis-port.js')){
  code=fs.readFileSync(p,'utf8');
  const key='      nodes.set(leaf,{identity:Object.freeze({}),turnTailBase:node});nodeCount++;';
  assert.equal(code.split(key).length,2);
  code=code.replace(key,key+'\n      if(spec.computerFiveForeignBlue){const stored=nodes.get(node);globalThis.captureFive(node,stored,spec,knownCards(stored.envelope));}');
 }else if(p.endsWith('/randomizer/game/ai/decision-search.js')){
  code=fs.readFileSync(p,'utf8');
  const key='    const lines = nodes.map((entry, index) => ({';
  assert.equal(code.split(key).length,2);
  code=code.replace(key,'    for(const n of nodes)for(const e of n.edges)globalThis.validateFiveEdge(e.turnTailPlanValue);\n'+key);
 }else return orig(m,p);
 return m._compile(code,p);
};
const {open,seat}=require('./native-late-r3'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),
 {createSearchAgent}=load('randomizer/game/ai/search-agent'),V=load('randomizer/game/ai/state-value').createStateValueEvaluator(seat);
const stable=x=>Array.isArray(x)?'['+x.map(stable).join(',')+']':x&&typeof x==='object'
 ?'{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+stable(x[k])).join(',')+'}':JSON.stringify(x);
const root=which==='official'?JSON.parse(fs.readFileSync(official)).checkpoint:JSON.parse(z.gunzipSync(fs.readFileSync(teacher))).rows.find(r=>r.summary.i===Number(which)).root;
const actual=open(root),port=createAnalysisPort({composition:actual.c,seatId:seat,maxCacheEntries:0});
const rows=[];
let summary;
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:actual.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(actual.save(),root);
 summary={which,action:q.actionId,value:q.value,realization:q.realization,preparationDebt:q.preparationDebt,
  retained:q.roots.map(r=>[r.actionId,r.completion,r.value,r.realization,r.preparationDebt]),
  originalExact:true,logical:q.diagnostics.transitions,native:q.diagnostics.nativeExecutions,nodes:q.lines.length};
 for(const {base,source,spec,known,barrier} of proofs.values()){
  const m=open({...source,committedState:stable(JSON.parse(source.committedState))});
  try{
   const before=m.save(),steps=[],act=(family,predicate)=>{const a=m.act(family,predicate);steps.push(a.actionId);return a;};
   act('place_data',a=>a.actionId===spec.firstActionId);
   act('choose_target',a=>a.target.target==='blueBonus'&&a.target.blueSlot===2);
   const sel=spec.bluePublicPick;
   act('choose_card',a=>a.target.publicSlotIndex===sel.publicSlotIndex&&a.target.cardInstanceId===sel.cardId);
   for(const step of sel.continuingDataPlans||[]){
    assert.equal(step.goal.id,'data:blue:3');
    act('place_data');act('choose_target',a=>a.target.target==='blueBonus'&&a.target.blueSlot===3);
   }
   act('end_turn');
   assert.equal(m.save().session,null);
   const endpoint=m.state();
   assert.notEqual(endpoint.turn.currentPlayerId,seat);
   assert.equal(steps.length,spec.requiredNativeInputs);
   const final=V.details(m.owner(seat));
   assert.equal(final.value,base.value+spec.netGain);
   assert.equal(final.unrealizedPurposeValue,base.unrealizedPurposeValue+spec.unrealizedPurposeDelta);
   assert.equal(final.purposePreparationDebt,base.purposePreparationDebt);
   assert.deepEqual(endpoint.meta.rngState,JSON.parse(before.committedState).meta.rngState);
   const end=m.save();
   m.restore(before);
   for(const id of steps){const a=m.menu().find(x=>x.actionId===id);assert(a,id);m.apply(a);}
   assert.deepEqual(m.save(),end);
   rows.push({spec,known,barrier,steps,base,final,source:before,end});
  }finally{m.dispose();}
 }
}finally{port.close();actual.dispose();}
const result={...summary,proofs:rows.length,rows};
fs.writeFileSync(out,z.gzipSync(JSON.stringify(result)+'\n'),{flag:'wx'});
console.log(JSON.stringify({...result,rows:undefined,retained:undefined}));
