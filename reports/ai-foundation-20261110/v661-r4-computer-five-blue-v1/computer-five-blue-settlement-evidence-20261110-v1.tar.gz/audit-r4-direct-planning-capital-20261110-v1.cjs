'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),crypto=require('node:crypto');
const [source,official,which,mode,out]=process.argv.slice(2),load=n=>require(path.resolve(n));
const original=Module._extensions['.js'];
const counters={capital:0,r4:0,mission:0,nonzero:0};
const audit=mode==='audit',legacy=process.argv[7];
globalThis.verifyCapital=(state,p,current,previous)=>{
 assert.equal(current,previous);
 counters.capital++;
 if(state.turn.roundNumber===4){
  counters.r4++;
  if(state.pieces.rockets.some(r=>r.playerId===p.id&&r.surface==='solar-board'&&(r.kind||'standard')==='standard'&&r.fossilId==null))counters.mission++;
  if(current!==0)counters.nonzero++;
 }
 return current;
};
if(audit)Module._extensions['.js']=(m,p)=>{
 if(!p.endsWith('/randomizer/game/ai/resource-demand.js'))return original(m,p);
 let code=fs.readFileSync(p,'utf8');
 const old=fs.readFileSync(path.join(legacy,'randomizer/game/ai/resource-demand.js'),'utf8');
 const a='  function planningCapital(state,p){',b='  function planningAnalysisCapital(';
 const prior=old.split(a)[1].split(b)[0];
 code=code.replace(a,'  function currentPlanningCapital(state,p){').replace(b,`  function previousPlanningCapital(state,p){${prior}
   function planningCapital(state,p){return globalThis.verifyCapital(state,p,currentPlanningCapital(state,p),previousPlanningCapital(state,p));}\n`+b);
 return m._compile(code,p);
};
const {open,seat}=require('./native-late-r3'),agent=load('randomizer/game/ai/search-agent'),
 {createAnalysisPort}=load('randomizer/game/ai/analysis-port');
const fixture=JSON.parse(z.gunzipSync(fs.readFileSync(source))),root=which==='official'?JSON.parse(fs.readFileSync(official)).checkpoint:
 fixture.rows.find(r=>r.summary.i===Number(which)).root;
const m=open(root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=agent.createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 const semantic={actionId:q.actionId,value:q.value,realization:q.realization,preparationDebt:q.preparationDebt,roots:q.roots,lines:q.lines,
  transitions:q.diagnostics.transitions,nativeExecutions:q.diagnostics.nativeExecutions};
 const canonical=x=>Array.isArray(x)?x.map(canonical):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,canonical(x[k])])):x;
 const graph=crypto.createHash('sha256').update(JSON.stringify(canonical(semantic))).digest('hex');
 
 const r={which,mode,graph,counters,ms:q.rootAndSearchMilliseconds,native:q.diagnostics.nativeExecutions,logical:q.diagnostics.transitions,
  eval:q.diagnostics.valueEvaluations,nodes:q.lines.length,rootAndRngExact:true};
 fs.writeFileSync(out,JSON.stringify(r,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(r));
}finally{p.close();m.dispose();}
