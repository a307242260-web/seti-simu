'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3'),load=p=>require(path.resolve(p));
const [reference,out]=process.argv.slice(2),e=JSON.parse(fs.readFileSync(reference)),f=JSON.parse(fs.readFileSync(e.fixture)),root=f.compositionEnvelope;
const m=open(root),p=load('randomizer/game/ai/analysis-port').createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
const agent=load('randomizer/game/ai/search-agent'),proofs=new Map();
const port={...p,turnTailBoundary(n,spec){if(spec.dataPlans?.length)proofs.set(spec,n);return p.turnTailBoundary(n,spec);}};
try{
 const evaluate=load('randomizer/game/ai/state-value').createStateValueEvaluator(seat);
 const r=load('randomizer/game/ai/decision-search').searchDecision({port,root:p.openRoot(),evaluate,...agent.OPTIONS,modelKey:evaluate.modelKey,budget:agent.BUDGET});
 assert.deepEqual(m.save(),root);
 const v={actionId:r.actionId,expectedAction:e.actionId,value:r.value,native:r.diagnostics.nativeExecutions,proofCount:proofs.size,
  proofGoals:[...proofs.keys()].map(s=>s.dataPlans.map(d=>d.goal.id)),complete:r.complete};
 fs.writeFileSync(out,JSON.stringify(v,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(v));
}finally{p.close();m.dispose();}
