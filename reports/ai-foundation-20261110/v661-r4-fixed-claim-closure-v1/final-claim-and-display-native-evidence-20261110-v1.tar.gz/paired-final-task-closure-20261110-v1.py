import gzip
import hashlib
import json
from pathlib import Path
from statistics import median
import subprocess
import sys

base, new, witness, dest = (Path(x).resolve() for x in sys.argv[1:])
dest.mkdir(exist_ok=True)
agent = witness / "trace-satellite-graph-20261110-v1.cjs"
native = witness / "native-compact-20261110-v1.cjs"


def row(mode, variant, iteration, source, fixture):
    stem = f"{mode}-{variant}-20261110-s{iteration}"
    file = dest / (stem + ".json.gz")
    command = ["node", str(agent), str(native), str(fixture), str(file)]
    if not file.exists():
        with (dest / (stem + ".log")).open("x") as out:
            subprocess.run(command, cwd=source, stdout=out, check=True)
    q = json.load(gzip.open(file))
    q.pop("schemaVersion")
    elapsed = q.pop("rootAndSearchMilliseconds")
    diagnostics = q.pop("analysis")
    q["diagnostics"].pop("milliseconds", None)
    q["diagnostics"].pop("resourceModelKey", None)
    digest = hashlib.sha256(json.dumps(q, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
    ranks={key:[{k:x.get(k) for k in fields} for x in q[key]] for key,fields in
           (("roots",("actionId","value","realization","preparationDebt")),("lines",("node","status","boundary","value","realization","preparationDebt","distance")))}
    ranked=hashlib.sha256(json.dumps(ranks,sort_keys=True).encode()).hexdigest()
    return {"ranked":ranked,"variant": variant, "sample": iteration, "ms": elapsed, "graph": digest, "action": q["actionId"],
            "value": q["value"], "nodes": q["diagnostics"]["graphNodes"], "native": q["diagnostics"]["nativeExecutions"],
            "complete": q["complete"], "diagnostics": diagnostics}


fixtures = {
    "board08": dest.parent / "root-replay-fixture-20261110-v1.json",
    "teacher272": witness / "teacher272-checkpoint-20261110-v1.json",
    "satellite": witness / "satellite-checkpoint-20261110-v1.json",
    "official": witness / "official-checkpoint-20261110-v1.json",
    "late": witness / "late-checkpoint-20261110-v1.json",
    "r3-172": witness / "r3-172-checkpoint-20261110-v1.json",
    "r3-136": witness / "r3-136-checkpoint-20261110-v1.json",
    "held0": witness / "reverse-funded-root-0-20261110-v1.json",
    "held1": witness / "reverse-funded-root-1-20261110-v1.json",
}
out = {}
for mode, fixture in fixtures.items():
    results = []
    count = 5 if mode in ("teacher272", "satellite", "official") else 1
    for i in range(1, count + 1):
        pair = [("baseline", base), ("candidate", new)]
        if i % 2 == 0:
            pair.reverse()
        for variant, source in pair:
            results.append(row(mode, variant, i, source, fixture))
    same = len(set(r["graph"] for r in results)) == 1
    assert len(set(r["ranked"] for r in results))==1, (mode,[(r["variant"],r["ranked"]) for r in results])
    assert all(r["complete"] for r in results)
    out[mode] = {
        "samples": results,
        "sameGraph": same,
        "medians": {variant: median(r["ms"] for r in results if r["variant"] == variant)
                    for variant in ("baseline", "candidate")},
    }
    print(mode, out[mode]["medians"], [(r["variant"],r["native"],r["nodes"]) for r in results[:2]], same, flush=True)

with (dest / "paired-final-task-closure-20261110-v1.json").open("x") as file:
    json.dump(out, file, ensure_ascii=False, indent=2)
    file.write("\n")
