'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),assert=require('node:assert/strict'),Module=require('node:module');
const compile=Module._extensions['.js'];
Module._extensions['.js']=(mod,file)=>{
 if(!file.endsWith('/game/ai/analysis-port.js'))return compile(mod,file);
 const src=fs.readFileSync(file,'utf8'),mark='redundantQuietFinalClaim,quietFinalEndTaskClosure,matchesQuietFinalEndTask';
 assert.equal(src.split(mark).length,2);
 mod._compile(src.replace(mark,mark+',auditEnvelope:node=>nodes.get(node).envelope'),file);
};
const {open,seat}=require(process.argv[2]),load=f=>require(path.resolve('randomizer/game/ai',f));
const root=JSON.parse(fs.readFileSync(process.argv[3])).checkpoint,m=open(root),replay=open(root);
const p=load('analysis-port').createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0}),proofs=[];
const proxy={...p,close(){},quietFinalEndTaskClosure(node,end){
 const proof=p.quietFinalEndTaskClosure(node,end);
 if(proof)proofs.push({source:node,end,proof});
 return proof;
}};
try{
 const agent=load('search-agent').createSearchAgent({seatId:seat,analysisPort:proxy});
 const q=agent.decide({seatId:seat,legalActions:m.menu()}).search,ai=agent.createCheckpoint();
 assert(q.complete&&!q.unresolved.length);
 assert.deepEqual(m.save(),root);
 const evaluate=load('state-value').createStateValueEvaluator(seat),cases=[];
 for(const {source,end,proof} of proofs){
   const execution=p.expandWithCardPick(source,end,()=>null);
   assert(execution.complete);assert.equal(execution.submissions,2);
   assert.deepEqual(execution.prefixes.map(a=>a.action.actionId),[end,proof.confirmId]);
   assert.deepEqual(execution.fixedChoices,[{prefix:1,...proof.policy}]);
   assert(p.matchesQuietFinalEndTask(proof.node,execution.node));
   const v=evaluate.details(p.valueObservation(proof.node));
   assert.deepEqual(v,evaluate.details(p.valueObservation(execution.node)));
   const checkpoint=JSON.parse(JSON.stringify(p.auditEnvelope(source)));
   const r=replay.c.lifecycle.restore(checkpoint);assert(r.ok,JSON.stringify(r).slice(0,800));
   assert.deepEqual(JSON.parse(replay.save().committedState),JSON.parse(checkpoint.committedState));
   for(const step of execution.prefixes)replay.apply(step.action);
   const actual=replay.save(),expected=p.auditEnvelope(proof.node);
   assert.equal(actual.session,null);
   assert.deepEqual(JSON.parse(actual.committedState),JSON.parse(expected.committedState));
   cases.push({steps:[end,proof.confirmId],boundary:proof.node.boundary,value:v.value,card:proof.task.cardInstanceId});
 }
 assert.deepEqual(m.save(),root);
 const result={cases,rootExact:true,action:q.actionId,value:q.value,n:q.diagnostics.nativeExecutions,ai};
 fs.writeFileSync(process.argv[4],z.gzipSync(JSON.stringify(result)),{flag:'wx'});
 console.log(JSON.stringify({cases:cases.length,inputs:cases.length*2,action:q.actionId,value:q.value,n:result.n,plan:ai?.plan?.rows.length||0}));
}finally{p.close();m.dispose();replay.dispose();}
