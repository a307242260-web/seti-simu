'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),assert=require('node:assert/strict'),Module=require('node:module'),{isDeepStrictEqual:same}=require('node:util');
const compile=Module._extensions['.js'],proofs=[],seen=new Set();
globalThis.savePinkProof=(node,stored,result)=>{
 if(result?.policy!=='seti-late-pink-position-dominance-v1'||seen.has(stored.envelope))return;
 seen.add(stored.envelope);
 for(const proof of result.proof)if(proof.forecastScope==='pending-then-masked-amiba-display')proofs.push({node,envelope:stored.envelope,proof});
};
Module._extensions['.js']=(mod,file)=>{
 if(!file.endsWith('/game/ai/analysis-port.js'))return compile(mod,file);
 const src=fs.readFileSync(file,'utf8'),mark='      const spec=result&&freeze(result);localSpecs.set(node,spec);return spec;';
 assert.equal(src.split(mark).length,2);
 mod._compile(src.replace(mark,'      globalThis.savePinkProof(node,stored,result);\n'+mark),file);
};
const {open,seat}=require(process.argv[2]),load=f=>require(path.resolve('randomizer/game/ai',f));
const root=JSON.parse(fs.readFileSync(process.argv[3])).checkpoint,m=open(root),replay=open(root);
const p=load('analysis-port').createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
const scores=load('state-value');
function diff(x,y,k='',out=[]){
 if(same(x,y))return out;
 if(!x||!y||typeof x!=='object'||typeof y!=='object'){out.push(k);return out;}
 for(const key of new Set([...Object.keys(x),...Object.keys(y)]))diff(x[key],y[key],k+'.'+key,out);
 return out;
}
const score=s=>s.players.players.find(p=>p.id===seat).resources.score;
try{
 const agent=load('search-agent').createSearchAgent({seatId:seat,analysisPort:{...p,close(){}}});
 const q=agent.decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 const result=[];
 for(const {node,envelope,proof} of proofs){
   const session=envelope.session.session,display=session.workingState.aliens.amiba.displayedCardIndex;
   assert(Number.isInteger(display));
   const ownedProbe=session.workingState.pieces.rockets.some(r=>r.playerId===seat&&r.surface==='solar-board'
     &&(r.kind||'standard')==='standard'&&r.fossilId==null);
   const audit=[];
   for(const actionId of [proof.lower,proof.higher]){
     const first=p.expand(node,actionId),firstObs=p.valueObservation(first);
     assert.equal(firstObs.selfState.pendingNativeEffects,true);
     const policy=p.cardPickSpec(first);
     let bound=first,forecast='pending';
     if(first.status==='decision'){
       const selected=first.legalActions.find(x=>x.actionId===policy?.selectedActionId);
       assert(selected&&selected.target.choiceId==='amiba:display:'+display);
       bound=p.expand(first,selected.actionId);
       const after=p.valueObservation(bound);
       assert.equal(after.publicState.board.aliens.amibaTraces?.displayedCardIndex??null,null);
       forecast='masked';
     }else assert.equal(first.status,'information-barrier');
     const value=scores.evaluateStateValue(p.valueObservation(bound),seat);
     const cp=JSON.parse(JSON.stringify(envelope)),r=replay.c.lifecycle.restore(cp);
     assert(r.ok,JSON.stringify(r).slice(0,800));
     const a=replay.menu().find(x=>x.actionId===actionId);assert(a);replay.apply(a);
     const c=replay.menu().find(x=>x.target?.choiceId==='amiba:display:'+display);assert(c);replay.apply(c);
     const result=replay.state();
     assert.notEqual(result.aliens.amiba.displayedCardIndex,display);
     audit.push({forecast,value,result,nativeMenu:replay.menu().map(x=>x.actionId),boundary:bound.boundary});
   }
   const [low,high]=audit;
   const changed=diff(low.result,high.result);
   assert.equal(score(high.result)-score(low.result),1);
   assert.deepEqual(low.nativeMenu,high.nativeMenu);
   assert(changed.length===4&&changed.filter(x=>x.includes('.aliens.amiba.traceSlotsByAlienSlotId.')&&/\.pink\.[34]$/.test(x)).length===2);
   assert.equal(high.forecast,low.forecast);assert.equal(high.boundary,low.boundary);
   assert.equal(high.value.components.probePotential,low.value.components.probePotential);
   assert.equal(high.value.total-low.value.total,1);
   result.push({pair:[proof.lower,proof.higher],ownedProbe,stage:high.forecast,originalDisplay:display,
     scoreDelta:1,probeValue:high.value.components.probePotential,boundary:high.boundary,changed});
 }
 assert(result.some(r=>r.ownedProbe));assert.deepEqual(m.save(),root);
 fs.writeFileSync(process.argv[4],z.gzipSync(JSON.stringify({action:q.actionId,value:q.value,cases:result,rootExact:true})),{flag:'wx'});
 console.log(JSON.stringify({cases:result.length,withProbe:result.filter(r=>r.ownedProbe).length,inputs:result.length*4}));
}finally{p.close();m.dispose();replay.dispose();}
