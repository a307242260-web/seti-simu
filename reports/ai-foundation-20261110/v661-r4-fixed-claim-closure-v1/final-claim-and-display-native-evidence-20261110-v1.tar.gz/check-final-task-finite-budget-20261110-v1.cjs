'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),load=f=>require(path.resolve('randomizer/game/ai',f));
const checkpoint=JSON.parse(fs.readFileSync(process.argv[3])).checkpoint,m=open(checkpoint),rows=[];
try{
 for(const transitions of [20,8000]){
   const p=load('analysis-port').createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
   try{
     const evaluate=load('state-value').createStateValueEvaluator(seat),root=p.openRoot();
     const proxy={...p,quietFinalEndTaskClosure(){throw Error('FINITE_USED_TASK_ENDPOINT');}};
     const r=load('decision-search').searchDecision({port:proxy,root,evaluate,...load('search-agent').OPTIONS,
       modelKey:evaluate.modelKey,budget:{transitions,nodes:8000,frontier:8000,milliseconds:5000}});
     if(transitions===20)assert(!r.complete&&!r.actionId&&r.stopReason==='transition-budget');
     else assert(r.complete&&r.value===222.5&&r.actionId==='place_data:8fd12fd3');
     assert.deepEqual(m.save(),checkpoint);
     rows.push({transitions,complete:r.complete,value:r.value,action:r.actionId,stop:r.stopReason,executed:r.diagnostics.transitions});
   }finally{p.close();}
 }
 fs.writeFileSync(process.argv[4],JSON.stringify(rows,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(rows));
}finally{m.dispose();}
