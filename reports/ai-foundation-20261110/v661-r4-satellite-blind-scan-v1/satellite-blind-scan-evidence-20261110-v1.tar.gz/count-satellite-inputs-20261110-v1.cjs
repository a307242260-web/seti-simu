'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const [root,out]=process.argv.slice(2),file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));Module._cache[file]=mod;
const at='      submissionCount += 1;',source=fs.readFileSync(file,'utf8');
assert.equal(source.split(at).length,2);
mod._compile(source.replace(at,'      globalThis.countInput(current,session);\n'+at),file);mod.loaded=true;
const family={},kind={},top={};
function inc(o,k){o[k]=(o[k]||0)+1;}
globalThis.countInput=(a,s)=>{
 inc(family,a.family);
 inc(kind,[a.family,s?.queue?.[0]?.type||'stable'].join('/'));
 inc(top,[s?.journal?.actions?.[0]?.action?.family||a.family,a.family].join('/'));
};
const {open}=require('./native-late-r3'),checkpoint=JSON.parse(fs.readFileSync(root)).checkpoint,m=open(checkpoint);
try{
 const q=m.automatic();assert.equal(q.n,3423);assert(q.complete);
 assert.equal(Object.values(family).reduce((a,b)=>a+b,0),q.n);assert.deepEqual(m.save(),checkpoint);
 const result={native:q.n,value:q.value,family,kind,top};
 fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 for(const group of [family,kind,top])console.log(Object.entries(group).sort((a,b)=>b[1]-a[1]).slice(0,12));
}finally{m.dispose();}
