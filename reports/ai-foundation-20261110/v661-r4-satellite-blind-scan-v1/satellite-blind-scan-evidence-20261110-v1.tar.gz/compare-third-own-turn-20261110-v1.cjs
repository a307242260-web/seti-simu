'use strict';
const fs=require('node:fs'),z=require('node:zlib'),assert=require('node:assert/strict'),path=require('node:path');
const {open,seat}=require('./native-late-r3');
const evaluate=require(path.resolve('randomizer/game/ai/state-value')).createStateValueEvaluator(seat);
const [sourceFile,teacherFile,out]=process.argv.slice(2),read=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const s=read(sourceFile),t=read(teacherFile),rows=[];
for(const [label,source] of [['triton',s.replayed.end],['enceladus',s.stop.envelope]]){
 const m=open(source);
 try{
  const start=m.facts(),q=m.automatic(),ok=q.complete&&q.n<=256&&q.ms<=600;
  assert.equal(start.turn,9);assert.deepEqual(m.save(),source);
  const record={label,start,source,gate:ok,quoted:{value:q.value,native:q.n,ms:q.ms,action:q.a}};
  if(ok){
   const actions=[];
   for(const row of q.checkpoint.plan.rows){
    if(m.facts().turn!==start.turn)break;
    const a=m.menu().find(a=>a.actionId===row.actionId&&a.actorId===seat);
    if(!a)break;actions.push(m.apply(a));
   }
   record.replayed={actions,end:m.save(),facts:m.facts(),value:evaluate.details(m.owner(seat)),closed:m.facts().turn>start.turn&&!m.save().session};
  }
  rows.push(record);
 }finally{m.dispose();}
}
const teacher=t.teacherTurns[2];
const result={rows,teacher:{facts:teacher.facts,value:teacher.value,envelope:teacher.envelope}};
fs.writeFileSync(out,z.gzipSync(JSON.stringify(result)+'\n'),{flag:'wx'});
for(const x of rows)console.log(JSON.stringify([x.label,x.gate,x.quoted,x.replayed?.closed,x.replayed?.actions.map(a=>a.summary),x.replayed?.facts.wallet,x.replayed?.value]));
