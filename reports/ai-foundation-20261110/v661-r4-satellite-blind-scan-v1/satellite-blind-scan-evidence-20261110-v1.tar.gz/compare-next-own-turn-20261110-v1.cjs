'use strict';
const fs=require('node:fs'),z=require('node:zlib'),assert=require('node:assert/strict'),path=require('node:path');
const {open,seat}=require('./native-late-r3');
const evaluator=require(path.resolve('randomizer/game/ai/state-value')).createStateValueEvaluator(seat);
const [aiFile,teacherFile,out]=process.argv.slice(2),read=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const c=read(aiFile).chosen,t=read(teacherFile).variants.find(r=>r.label==='teacher-scan-with-free-move-then-card'),m=open(c.end);
try{
 const source=m.save(),sourceFacts=m.facts(),q=m.automatic();
 assert.deepEqual(m.save(),source);assert(q.complete);
 const threshold={native:256,ms:600},passes=q.n<=threshold.native&&q.ms<=threshold.ms;
 const evidence={source,sourceFacts,sourceValue:evaluator.details(m.owner(seat)),threshold,passes,
  singleDecision:{action:q.a,value:q.value,native:q.n,ms:q.ms,roots:q.roots.map(a=>[a.actionId,a.value,a.realization,a.preparationDebt]),
   certificate:q.checkpoint?.plan?.rows?.map(r=>({actionId:r.actionId,distance:r.distance,sourceNode:r.sourceNode}))}};
 if(passes){
  const actions=[],ownerTurn=sourceFacts.turn;
  for(const row of q.checkpoint.plan.rows){
   if(m.facts().turn!==ownerTurn)break;
   const a=m.menu().find(a=>a.actionId===row.actionId&&a.actorId===seat);
   if(!a)break;actions.push(m.apply(a));
  }
  evidence.replayed={actions,end:m.save(),facts:m.facts(),value:evaluator.details(m.owner(seat)),closed:m.facts().turn>ownerTurn&&!m.save().session};
 }
 const refs=t.snapshots.filter(s=>s.facts);
 for(const key of ['before-card','stop']){
  const row=refs.find(s=>s.stage===key);m.restore(row.envelope);
  evidence[key]={envelope:row.envelope,facts:m.facts(),value:evaluator.details(m.owner(seat))};
 }
 m.restore(source);assert.deepEqual(m.save(),source);
 fs.writeFileSync(out,z.gzipSync(JSON.stringify(evidence)+'\n'),{flag:'wx'});
 console.log(JSON.stringify({gate:passes,selected:q.a.summary,value:q.value,native:q.n,ms:q.ms,
  actions:evidence.replayed?.actions.map(a=>a.summary),end:evidence.replayed?.facts.wallet,closed:evidence.replayed?.closed,
  ai:evidence.replayed?.value.components,teacherNext:evidence['before-card'].value.components,teacherEnd:evidence.stop.value.components}));
}finally{m.dispose();}
