'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const [fixture,teacher,out]=process.argv.slice(2),read=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const root=read(fixture).rows[0].root,m=open(root),[first,charge,landing]=read(teacher).teacherTurns,steps=first.actions;
const rows=[];
function native(i){
 const t=steps[i],choices=m.menu(),a=choices.find(x=>x.actionId===t.actionId&&x.actorId===t.actorId);
 assert(a,`step ${i}: ${t.summary} unavailable, legal: ${choices.map(a=>a.summary).join(', ')}`);return m.apply(a);
}
function normalized(s){
 const copy=structuredClone(s),p=copy.players.players.find(p=>p.id===seat);
 for(const token of [...p.dataState.poolTokens,...p.dataState.placedTokens]){
  delete token.id;delete token.index;
 }
 for(const token of p.dataState.poolTokens)delete token.slotIndex;
 p.dataState.placedTokens.sort((a,b)=>a.placementKind.localeCompare(b.placementKind)||(a.placementSlot??a.blueSlot)-(b.placementSlot??b.blueSlot));
 delete copy.meta.stateVersion;delete copy.meta.sequences.dataToken;
 return copy;
}
function replay(label,head,tail){
 m.restore(root);const moves=[];
 let error=null;
 for(const i of [...head,8,9,10,11,12,...tail,13]){
  try{moves.push(native(i));}catch(e){error=e.message;break;}
 }
 const end=m.save(),facts=m.facts(),a=normalized(m.state()),b=normalized(JSON.parse(first.envelope.committedState));
 const changed=Object.keys(a).filter(key=>!require('node:util').isDeepStrictEqual(a[key],b[key]));
 const suffix=[];
 for(const t of [...charge.actions,...landing.actions]){
  const next=m.menu().find(x=>x.actionId===t.actionId&&x.actorId===t.actorId);
  if(!next)break;
  suffix.push(m.apply(next));
 }
 const suffixFacts=m.facts(),suffixEnd=m.save(),u=normalized(m.state()),v=normalized(JSON.parse(landing.envelope.committedState));
 const suffixChanged=Object.keys(u).filter(key=>!require('node:util').isDeepStrictEqual(u[key],v[key]));
 rows.push({label,head,tail,moves,error,end,facts,changed,sessionClosed:!end.session,suffix,suffixFacts,suffixEnd,suffixChanged});
}
try{
 replay('original',[0,1,2,3,4,5,6,7],[]);
 replay('computer-two-only-before-scan',[0,1],[2,3,4,5,6,7]);
 replay('defer-all',[],[0,1,2,3,4,5,6,7]);
 assert.deepEqual(rows[0].end,first.envelope);assert.deepEqual(rows[0].suffixEnd,landing.envelope);
 m.restore(root);assert.deepEqual(m.save(),root);
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({rows,authoritativeRootExact:true})+'\n'),{flag:'wx'});
 for(const r of rows)console.log(JSON.stringify([r.label,r.moves.length,r.error,r.sessionClosed,r.changed,r.facts.wallet,r.facts.computer,r.facts.blue,r.suffix.length,r.suffixFacts.wallet,r.suffixChanged]));
}finally{m.dispose();}
