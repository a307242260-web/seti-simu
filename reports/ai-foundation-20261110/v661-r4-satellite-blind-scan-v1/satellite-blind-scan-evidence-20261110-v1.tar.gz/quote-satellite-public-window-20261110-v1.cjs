'use strict';
const fs=require('node:fs'),z=require('node:zlib'),assert=require('node:assert/strict'),path=require('node:path');
const {open,seat}=require('./native-late-r3');
const values=require(path.resolve('randomizer/game/ai/state-value'));
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const [two,teacher,out]=process.argv.slice(2),load=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const source=load(two)['before-card'].envelope,script=load(teacher).teacherTurns[2].actions,model=open(source),rows=[];
function run(kind){
 const p=createAnalysisPort({composition:model.c,seatId:seat,maxCacheEntries:0});
 try{
  let n=p.openRoot();p.setMovementPlanning(true);p.setCardPickPlanning(true);p.setResourcePlanning(true);p.setDecisionPlanning({finalMarkPlanning:true,scanPlanning:true});
  const quote=()=>{
   const obs=p.valueObservation(n),v=values.evaluateStateValue(obs,seat),a=obs.publicState.players.find(p=>p.playerId===seat);
   return {status:n.status,boundary:n.boundary,v:v.total,components:v.components,score:a.score,wallet:[a.credits,a.energy,a.availableData,a.handCount,a.publicity],
    hand:obs.selfState.hand.map(x=>x.hidden?'hidden':x.cardId),choices:n.legalActions.map(a=>[a.family,a.summary,a.target])};
  };
  const steps=[{state:quote()}];
  const find=(pred)=>n.legalActions.find(pred);
  const apply=(a)=>{
   if(!a)return false;
   n=p.expand(n,a.actionId);steps.push({action:a,state:quote()});return true;
  };
  if(kind==='card'){
   assert(apply(find(a=>a.family==='play_card'&&a.target.cardInstanceId===script[0].target.cardInstanceId)));
  }else{
   assert(apply(find(a=>a.family==='quick_trade'&&a.target.tradeId==='credits-for-energy')));
   assert(apply(find(a=>a.family==='land')));
  }
  assert(apply(find(a=>a.target?.landTarget?.satelliteId==='enceladus')));
  let reason='fixed-listed-actions-exhausted';
  for(const a of script.slice(2)){
   if(['information-barrier','turn-boundary','other-owner','terminal'].includes(n.status)){reason=n.status;break;}
   if(!apply(find(b=>b.actionId===a.actionId&&b.family===a.family))){
    reason='native-menu-differs:'+a.summary;break;
   }
  }
  assert.deepEqual(model.save(),source);
  rows.push({kind,steps,reason,native:p.getDiagnostics().submissionCount});
 }finally{p.close();}
}
try{
 run('card');run('standard');
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({rows,source,rootExact:true})+'\n'),{flag:'wx'});
 for(const r of rows)console.log(JSON.stringify([r.kind,r.reason,r.native,r.steps.map(x=>[x.action?.summary,x.state.status,x.state.boundary,x.state.v,x.state.score,x.state.wallet,x.state.hand])]));
}finally{model.dispose();}
