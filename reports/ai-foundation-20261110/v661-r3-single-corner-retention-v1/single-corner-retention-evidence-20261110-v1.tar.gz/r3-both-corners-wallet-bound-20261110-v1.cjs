'use strict';
const assert=require('node:assert/strict');
const {readZ,writeZ,open,short}=require('./controlled-r3');
const {control}=require('./r3-r4-handoff-known-payments-20261110-v1.cjs');
const [witness,menuAudit,out]=process.argv.slice(2);
const prior=readZ(witness).rows[0].row;
const source=readZ(menuAudit).results.find(r=>r.key==='no-salary-energy');
const m=open(source.root),actions=[],stages={};
const apply=a=>actions.push(m.apply(a));
const act=(f,p)=>actions.push(m.act(f,p));
const cut=label=>stages[label]={state:m.save(),summary:short(m)};
try{
 const corners=['chong_8.webp','amiba_9.webp'];
 for(const c of corners)actions.push(m.corner(c));
 cut('r3-before-pass');
 const handoff=control(m.save(),{dataCard:'b_35.webp',incomeCard:'b_111.webp'});
 assert(!handoff.failure&&handoff.replayExact,handoff.failure);
 handoff.accepted.forEach(apply);cut('after-blue8');
 prior.actions.slice(0,5).forEach(apply);
 // One salary card paid for data. The remaining one cannot purchase energy
 // by count without discarding a named movement tool.
 assert.equal(m.player().hand.filter(c=>['card-68-0','card-69-0'].includes(c.id)).length,1);
 const trade=()=>act('quick_trade',a=>a.target.tradeId==='credits-for-energy');
 trade();prior.actions.slice(9,18).forEach(apply);cut('before-dlc16');
 const offer=m.facts().market.find(c=>c?.[1]==='dlc_16.png');assert(offer);
 act('quick_trade',a=>a.target.tradeId==='publicity-for-card');
 act('choose_card',a=>a.target.cardInstanceId===offer[0]);
 prior.actions.slice(21,23).forEach(apply);cut('before-merc-payments');
 assert.equal(m.player().resources.credits,5);
 trade();trade();
 const hasThird=m.menu().some(a=>a.target.tradeId==='credits-for-energy');
 assert.equal(hasThird,false);
 cut('third-cash-conversion-unavailable');
 const end=m.save();m.restore(source.root);actions.forEach(m.apply);assert.deepEqual(m.save(),end);m.restore(source.root);
 const summary={sameFixedMercuryPaymentsLegal:false,creditsForThree:6,availableBeforeConversions:5,missingCredits:1,
  stages:Object.fromEntries(Object.entries(stages).map(([k,v])=>[k,v.summary]))};
 writeZ(out,{summary,stages,actions,root:source.root,end});console.log(JSON.stringify(summary));
}finally{m.dispose();}
