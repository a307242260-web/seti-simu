'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {readZ,writeZ,open,short}=require('./controlled-r3');
const load=n=>require(path.resolve(n)),rocket=load('randomizer/game/rockets'),ability=load('randomizer/game/abilities/rocket'),solar=load('randomizer/solar-system/core');
const seat="player-white";
function pathToEarth(m,fossilId){
 const s=m.state(),ship=s.pieces.rockets.find(r=>r.fossilId===fossilId&&r.playerId===seat),earth=solar.collectPlanetLocations(s.solarSystem).find(p=>p.planetId==='earth');
 assert(ship&&earth);
 const queue=[{at:rocket.getRocketSectorCoordinate(ship),cost:0,path:[]}],seen=new Set();
 while(queue.length){
  queue.sort((a,b)=>a.cost-b.cost||a.path.length-b.path.length);
  const n=queue.shift(),id=n.at.x+','+n.at.y;if(seen.has(id))continue;seen.add(id);
  if(n.at.x===earth.x&&n.at.y===earth.y)return {rocketId:ship.id,earth:{x:earth.x,y:earth.y},...n};
  const cost=ability.getRequiredMovePointsFromCoordinate(s,m.player(),n.at);
  for(const d of ability.MOVE_DIRECTIONS){
   const a=rocket.canMoveFromCoordinate(s.pieces,n.at,d.deltaX,d.deltaY,ship.id);
   if(a.ok&&!seen.has(a.to.x+','+a.to.y))queue.push({at:a.to,cost:n.cost+cost,path:[...n.path,{...d,cost,from:n.at,to:a.to}]});
  }
 }
 throw new Error('No legal Earth route');
}
function control(root, payments={}){
 const m=open(root),accepted=[],stages={};
 const act=(f,p)=>{const a=m.act(f,p);accepted.push(a);return a;};
 const checkpoint=label=>stages[label]={state:m.save(),assets:short(m),fossils:m.state().aliens.chong.transportTasksByRocketId};
 const settle=()=>{
  for(let i=0;m.c.inspect().phase==='awaiting_input';i++){
   assert(i<15);
   const menu=m.menu();
   if(payments.inspectIncome&&menu.every(a=>a.target?.choiceId?.startsWith('income:'))){
    checkpoint('income-menu');
    payments.inspectIncome(m,menu);
    return;
   }
   const target=m.menu().find(a=>a.target.choiceId?.startsWith('confirm:'))||m.menu().find(a=>a.target.choiceId?.startsWith('skip:'))||m.menu().find(a=>a.target.choiceId===(payments.incomeCard?
      'income:'+m.player().hand.find(h=>h.cardId===payments.incomeCard)?.id:'income:card-30-pass-3-1'));
   assert(target,JSON.stringify(m.menu().map(x=>[x.family,x.summary])).slice(0,300));
   accepted.push(m.apply(target));
  }
 };
 try{
  checkpoint('r3-before-pass');
  const id=m.state().pieces.rockets.find(p=>p.fossilId&&p.playerId===seat).fossilId;
  const task=Object.values(m.state().aliens.chong.transportTasksByRocketId).find(t=>t.fossilId===id);
  act('pass');const reserve=act('choose_card',a=>a.target.kind==='pass-reserve-card'&&a.target.choiceId==='card-30-pass-3-1');
  if(m.menu()[0].actorId!==seat)m.advanceOpponents(accepted);
  settle();
  assert.equal(m.facts().round,4);assert.equal(m.player().mainActionCompleted,false);
  checkpoint('r4-before-first-main');
  const route=pathToEarth(m,id);
  for(const d of route.path){
   while(m.player().resources.energy<d.cost)act('quick_trade',a=>a.target.tradeId==='credits-for-energy');
   act('move',a=>a.target.rocketId===route.rocketId&&a.target.deltaX===d.deltaX&&a.target.deltaY===d.deltaY);
   act('choose_payment',a=>a.target.kind==='move-payment'&&!a.target.cardIds.length);settle();
  }
  checkpoint('delivered');assert.equal(m.state().aliens.chong.fossilsById[id].status,'delivered');
  act('complete_task',a=>a.target.cardInstanceId===task.cardId);settle();
  checkpoint('claimed');assert(m.state().aliens.chong.fossilsById[id].taskCompleted);
  const data=load('randomizer/game/data'),cards=load('randomizer/game/cards/deck'),dataPayments=[];
  const slot=()=>Object.keys(data.COMPUTER_DATA_SLOTS).map(Number).find(n=>!data.listComputerPlacedTokens(m.player()).some(t=>t.placementSlot===n));
  for(let i=0;i<6&&slot();i++){
   const target=slot();
   if(!m.player().resources.availableData){
    const menu=m.menu();
    const a=menu.find(a=>a.family==='card_corner'&&a.payload.kind==='resource'&&
      m.player().hand.some(c=>c.id===a.target.cardInstanceId&&(!payments.dataCard||c.cardId===payments.dataCard)
       &&cards.getDiscardActionRewardForCard(c)?.dataCount===1));
    assert(a,'No known data corner for computer '+target);
    dataPayments.push(a.summary);accepted.push(m.apply(a));settle();
   }
   act('place_data');act('choose_target',a=>a.target.target==='computer');settle();
   if(stages['income-menu'])return {root,accepted,stages,reachedIncome:true};
  }
  checkpoint('ready-analysis');
  act('analyze');
  checkpoint('common-analysis-menu');
  const traceChoices=m.menu().filter(a=>a.target.traceType==='blue'||a.target.traceColor==='blue'||a.summary.includes('蓝')).map(a=>[a.target.speciesId,a.target.position,a.target.choiceId,a.summary]);
  if(traceChoices.some(x=>x[2]==='trace:2:blue:chong:8')){
   act('choose_target',a=>a.target.choiceId==='trace:2:blue:chong:8');
   if(m.menu().some(a=>a.family==='choose_card'&&a.target.source==='display'))act('choose_card',a=>a.target.source==='display');
   settle();checkpoint('after-common-blue8');
  }
  const end=m.save();m.restore(root);accepted.forEach(m.apply);assert.deepEqual(m.save(),end);
  return {root,reserve:reserve.summary,route,accepted,stages,end,dataPayments,traceChoices,replayExact:true};
 }catch(error){return {root,accepted,stages,failure:String(error),menu:m.menu().slice(0,14)};}
 finally{m.dispose();}
}

module.exports={control};
