'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {readZ,writeZ,open}=require('./controlled-r3');
const {control}=require('./r3-r4-handoff-income-audit-20261110-v1.cjs');
const {getIncomeGainForCard,getDiscardActionRewardForCard}=require(path.resolve('randomizer/game/cards/deck'));
const [source,out]=process.argv.slice(2),j=readZ(source),results=[];
const original=j.rows[0].root,negative=JSON.parse(original.committedState);
for(const [i,id] of ['b_35.webp','b_9.webp'].entries()){
 const pile=negative.cards.drawPileCardIds,index=pile.indexOf(id);assert(index>=0);
 [pile[i],pile[index]]=[pile[index],pile[i]];
}
const altered={...original,committedState:JSON.stringify(negative)};
const visible=e=>{const m=open(e);try{return [m.owner('player-white'),m.menu()];}finally{m.dispose();}};
assert.deepEqual(visible(altered),visible(original));
assert.deepEqual(negative.meta.rngState,JSON.parse(original.committedState).meta.rngState);
j.rows['no-salary-energy']={root:altered};
function independentSession(e){
 const id=e.session?.session?.sessionId;assert(id);
 return JSON.parse(JSON.stringify(e).replaceAll(id,'@session'));
}
for(const [key,r] of Object.entries(j.rows)){
 const m=open(r.root);
 try{
  const corners=['chong_8.webp','amiba_9.webp'].map(id=>m.corner(id));
  let choices;
  const audit=control(m.save(),{dataCard:'b_111.webp',inspectIncome:(o,menu)=>{
   choices=menu.map(a=>{
    const card=o.player().hand.find(c=>c.id===a.target.cardInstanceId);
    return {id:card.id,card:card.cardId,gain:getIncomeGainForCard(card),corner:getDiscardActionRewardForCard(card)?.dataCount??0,
     salary:['card-68-0','card-69-0'].includes(card.id)};
   });
  }});
  assert(audit.reachedIncome&&choices);
  const actions=[...corners,...audit.accepted],endpoint=audit.stages['income-menu'].state;
  m.restore(r.root);actions.forEach(m.apply);
  assert.deepEqual(independentSession(m.save()),independentSession(endpoint));m.restore(r.root);
  const row={key,choices,actions,root:r.root,endpoint,income:audit.stages['income-menu'].assets};
  results.push(row);console.log(JSON.stringify({key,choices,n:actions.length}));
 }finally{m.dispose();}
}
writeZ(out,{results});
