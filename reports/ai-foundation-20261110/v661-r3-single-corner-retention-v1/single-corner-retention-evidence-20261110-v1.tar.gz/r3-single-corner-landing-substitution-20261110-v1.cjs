'use strict';
const assert=require('node:assert/strict');
const {readZ,writeZ,open,short}=require('./controlled-r3');
const {control}=require('./r3-r4-handoff-known-payments-20261110-v1.cjs');
const [source,out]=process.argv.slice(2),reference=readZ(source);
const results=[];
function selectCard(m,cardId){
 const a=m.menu().find(a=>a.family==='choose_card'&&a.summary===cardId);
 assert(a,JSON.stringify(m.menu().map(a=>[a.family,a.summary,a.target.choiceId])));
 return m.apply(a);
}
function run(label,input,discard){
 const origin=input.root,prior=input.row,stages={},m=open(origin),actions=[];
 const checkpoint=(label)=>stages[label]={state:m.save(),summary:short(m)};
 const apply=a=>{const hit=m.apply(a);actions.push(hit);return hit;};
 const act=(family,match)=>{const hit=m.act(family,match);actions.push(hit);return hit;};
 try{
  checkpoint('r3-original');
  if(discard){
   const id=m.player().hand.find(c=>c.cardId===discard)?.id;
   assert(id);
   act('card_corner',a=>a.target.cardInstanceId===id);
  }
  checkpoint('r3-before-pass');
  const incomeCard=discard==='chong_8.webp'?'amiba_9.webp':'chong_8.webp';
  const handoff=control(m.save(),{dataCard:'b_111.webp',incomeCard});
  if(!handoff.replayExact||handoff.failure)throw new Error(handoff.failure);
  handoff.accepted.forEach(apply);
  assert.deepEqual(m.save(),handoff.stages['after-common-blue8'].state);
  checkpoint('first-blue8');
  prior.actions.slice(0,18).forEach(apply);
  checkpoint('before-landing');
  if(discard){
   const offer=m.facts().market.find(c=>c?.[1]==='dlc_16.png');
   assert(offer);
   act('quick_trade',a=>a.target.tradeId==='publicity-for-card');
   act('choose_card',a=>a.target.cardInstanceId===offer[0]);
  }else prior.actions.slice(18,21).forEach(apply);
  checkpoint('paid-for-dlc16');
  prior.actions.slice(21,36).forEach(apply);
  checkpoint('mercury-claimed');
  prior.actions.slice(36,42).forEach(apply);
  if(discard)actions.push(selectCard(m,'b_16.webp'));
  else apply(prior.actions[42]);
  apply(prior.actions[43]);
  checkpoint('turn-end');
  const end=m.save();m.restore(origin);actions.forEach(m.apply);assert.deepEqual(m.save(),end);m.restore(origin);
  return {label,discard,incomeCard,origin,end,actions,stages,complete:true};
 }catch(error){
  const endpoint=m.save();m.restore(origin);actions.forEach(m.apply);assert.deepEqual(m.save(),endpoint);m.restore(origin);
  return {label,discard,origin,actions,stages,endpoint,complete:false,failure:String(error)};
 }finally{m.dispose();}
}
for(const [group,input] of Object.entries(reference.rows)){
 for(const discard of [null,'chong_8.webp','amiba_9.webp']){
  const r=run(group,input,discard);
  results.push(r);
  console.log(JSON.stringify({group,discard,complete:r.complete,failure:r.failure,n:r.actions.length,
   afterDiscard:r.stages['r3-before-pass']?.summary.wallet,offer:r.stages['before-landing']?.summary.wallet,
   afterLanding:r.stages['mercury-claimed']?.summary,end:r.stages['turn-end']?.summary}));
 }
}
assert.equal(results.filter(r=>!r.discard&&r.complete).length,3);
writeZ(out,{results});
