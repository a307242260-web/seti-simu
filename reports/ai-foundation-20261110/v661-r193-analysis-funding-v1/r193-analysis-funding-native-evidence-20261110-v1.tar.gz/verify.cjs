'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ}=require('./controlled-r3');
const dir=process.argv[2]||__dirname;
const data=n=>readZ(path.join(dir,n+'-20261110-v1.json.gz'));
let segments=0,actions=0,decisions=0,maxNative=0,maxMs=0;
function replay(root,inputs,end){
 const m=open(root);
 try{
  for(const x of inputs){
   if(Number.isFinite(x.n)){
    assert(x.n<=256&&x.ms<=600);
    maxNative=Math.max(maxNative,x.n);maxMs=Math.max(maxMs,x.ms);decisions++;
   }
   m.apply(x.action||x);
  }
  assert.deepEqual(m.save(),end);segments++;actions+=inputs.length;
 }finally{m.dispose();}
}
for(const x of Object.values(data('r193-historical-roots')))replay(x.roots[0].root,x.roots.map(r=>r.a),x.end);
function verifyCases(x){
 for(const r of x.rows){
  assert.equal(r.stop,'r4-first-white-main');
  replay(x.source||x.root,[...r.prefix,...r.actions],r.end);
 }
}
for(const x of Object.values(data('r193-known-electric-income')))verifyCases(x);
for(const n of ['r193-pink-public-supply','r193-early-blue-cash','r193-second-r3-scan','r193-second-r3-scan-electric','r193-keep-amiba5'])verifyCases(data(n));
for(const x of data('r193-matched-r4').rows){
 assert(x.stages['before-analysis'].s.computer.length===6);
 replay(x.root,x.actions,x.end);
}
const actual=data('r193-current-roots');
assert.equal(actual['actual:205'].q.a.target.blueSlot,1);
assert(actual['actual:205'].q.roots.some(r=>r.choice==='data:computer'&&r.value===null));
assert.equal(actual['computer6:before-early-analysis'].q.roots.find(r=>r.family==='analyze').value,160);
assert.equal(actual['computer6:before-early-analysis'].q.value,168);
for(const {q} of Object.values(actual))assert(q.complete&&q.n<=256&&q.ms<=600);
console.log(JSON.stringify({segments,actions,decisions,maxNative,maxMs,coldRoots:Object.keys(actual).length}));
