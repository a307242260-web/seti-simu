'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),hist=readZ(src)['earlier-analysis-blue3'].roots,root=hist[0].root;
const act=(h,f,p)=>h.act(f,p);
const put=(h,slot)=>{act(h,'place_data');act(h,'choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');};
const hand=(h,id)=>h.m.player().hand.find(a=>a.cardId===id)?.id;
function prepare(h){
 put(h);act(h,'quick_trade',a=>a.target.tradeId==='cards-for-energy');
 for(const id of ['amiba_9.webp','b_16.webp'])act(h,'choose_payment',a=>a.target.cardInstanceId===hand(h,id));
 if(h.m.c.inspect().session?.decision)act(h,'choose_payment',a=>a.target.kind!=='discard-hand-card');
 act(h,'end_turn');
 for(const i of [6,7,8])h.take(h.m.apply(hist[i].a));
 act(h,'choose_target',a=>a.target.choiceId==='trace:1:pink:amiba:3');
 act(h,'choose_card',a=>a.target.choiceId==='amiba:display:2');
 if(h.m.menu().some(a=>a.target.ruleId==='amiba0-pink-data'))act(h,'accept_optional_effect',a=>a.target.ruleId==='amiba0-pink-data');
 if(h.m.menu().some(a=>a.family==='complete_task'&&a.summary.includes('dlc_9')))act(h,'complete_task',a=>a.summary.includes('dlc_9'));
 h.cut('held');
}
function fund(h,mode){
 prepare(h);
 if(mode==='electric'){
  h.take(...h.m.swap('amiba_2.webp','dlc_25.png'));
 }
 for(let i=0;i<3;i++)put(h);
 act(h,'choose_card',a=>a.target.cardInstanceId===hand(h,mode==='electric'?'dlc_25.png':'amiba_2.webp'));
 h.cut('income');
}
function play(h){
 fund(h,'cash');act(h,'end_turn');h.take(h.m.play('amiba_5.webp'));
 h.take(h.m.pick('dlc_25.png'));act(h,'choose_target',a=>a.target.choiceId==='symbol:red_2');h.cut('played');
}
writeZ(out,{root,...runCases(root,[
 ['keep-amiba5:after-scan',prepare],
 ['keep-amiba5:cash',h=>fund(h,'cash')],
 ['keep-amiba5:electric',h=>fund(h,'electric')],
 ['keep-amiba5:play',play],
])});
