'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),cases={};
function activate(h,f,p){h.act(f,p);}
const end=h=>activate(h,'end_turn');
const task=h=>activate(h,'complete_task',a=>a.summary.includes('dlc_9'));
const put=(h,slot)=>{activate(h,'place_data');activate(h,'choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');};
const swap=(h,drop,into)=>h.take(...h.m.swap(drop,into));
const inputIncome=(h,id)=>{
 const c=h.m.player().hand.find(a=>a.cardId===id);assert(c,id);
 activate(h,'choose_card',a=>a.target.cardInstanceId===c.id);
};
function fund(h,mode){
 task(h);
 if(mode==='dlc25-from-b16')swap(h,'b_16.webp','dlc_25.png');
 if(mode==='dlc25-from-amiba9')swap(h,'amiba_9.webp','dlc_25.png');
 const income=mode.startsWith('dlc25')?'dlc_25.png':mode==='amiba9'?'amiba_9.webp':'b_16.webp';
 for(let i=0;i<3;i++)put(h);
 inputIncome(h,income);h.cut('after-income');
}
function tech(h,id){
 activate(h,'research_tech');
 activate(h,'choose_target',a=>a.target.tileId===id);
}
function launch(h,pick){
 end(h);tech(h,'orange1');
 if(pick)h.take(h.m.pick(pick));
 h.cut('after-launch');
}
for(const [k,at] of [['earlier-analysis-blue3',11],['early-scan-second-species',1]]){
 const source=d[k].roots[at].root,m=open(source);
 try{
  const q=m.automatic();console.log('cold-root',k,short(m).wallet,q.n,q.ms,q.complete,q.a?.summary);
  assert(q.complete&&q.n<=256&&q.ms<=600);
 }finally{m.dispose();}
 const candidates=[
  ['amiba9:income',h=>fund(h,'amiba9')],
  ['dlc25-from-b16:income',h=>fund(h,'dlc25-from-b16')],
  ['dlc25-from-amiba9:income',h=>fund(h,'dlc25-from-amiba9')],
  ['amiba9:launch-dlc25',h=>{fund(h,'amiba9');launch(h,'dlc_25.png');}],
  ['dlc25-from-b16:launch-dlc20',h=>{fund(h,'dlc25-from-b16');launch(h,'dlc_20.png');}],
  ['dlc25-from-amiba9:launch-dlc20',h=>{fund(h,'dlc25-from-amiba9');launch(h,'dlc_20.png');}],
 ];
 cases[k]={source,...runCases(source,candidates)};
}
writeZ(out,cases);
