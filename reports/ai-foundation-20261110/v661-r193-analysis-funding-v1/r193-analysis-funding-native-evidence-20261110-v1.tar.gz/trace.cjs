'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [out]=process.argv.slice(2),data={};
for(const src of ['earlier-analysis','earlier-reveal']){
 const d=readZ(__dirname+'/v655-r193-'+src+'-20261109-v1.json.gz');
 for(const row of d.rows.filter(r=>['earlier-analysis-blue2','earlier-analysis-blue3','early-scan-second-species'].includes(r.label))){
  const m=open(row.start),roots=[];
  try{
   for(const {action:a} of row.accepted){
    const s=short(m),root=m.save(),menu=m.menu();
    roots.push({s,root,menu,a});
    if(['main','turn_control','quick','decision'].includes(a.phase))console.log(row.label,roots.length-1,s.turn,a.phase,a.family,a.summary,s.wallet.join('/'),s.hand.join(','),s.computer.join(''),s.blue.join(''),s.market.join(','));
    m.apply(a);
   }
   assert.deepEqual(m.save(),row.end);
   data[row.label]={roots,end:row.end,settled:row.settled.envelope};
  }finally{m.dispose();}
 }
}
writeZ(out,data);
