'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,short,readZ,writeZ}=require('./controlled-r3');
const native=require(path.resolve('randomizer/game/production-kernel'));
const [src,formal,out]=process.argv.slice(2),d=readZ(src),reference=readZ(formal).roots[258].e,rows=[];
const starts=[['formal',reference],...d.rows.filter(r=>r.label.endsWith(':orange1:blue1:0')||r.label==='swap-b16:orange1:blue1:3')
 .map(r=>[r.label,r.settled.state])];
for(const [label,root] of starts)for(const planet of ['jupiter','saturn']){
 const m=open(root),actions=[],stages={};
 const act=(f,p)=>{const a=m.act(f,p);actions.push(a);return a;};
 const cut=k=>stages[k]={e:m.save(),s:short(m),at:actions.length};
 function finish(){
  act('end_turn');
  if(m.c.inspect().session?.decision){
   const s=m.menu().find(a=>a.target?.choiceId?.startsWith('skip:'));
   assert(s,m.menu().map(a=>a.summary).join(','));
   actions.push(m.apply(s));
  }
  m.advanceOpponents(actions);
 }
 try{
  cut('round3');
  act('pass');act('choose_card',a=>a.target.choiceId==='card-30-pass-3-1');m.advanceOpponents(actions);cut('round4');
  const req=native.getProbeRouteRequirements(m.state(),'player-white').candidates
   .find(r=>r.planetId===planet&&r.endpointFamily==='land'&&r.endpointTarget.type==='planet');
  assert(req);
  const funding=req.required.energy,route=req.path;
  while(m.player().resources.energy<funding)act('quick_trade',a=>a.target.tradeId==='credits-for-energy');
  for(const q of route){
   act('move',a=>a.target.rocketId===req.rocketId&&a.target.deltaX===q.deltaX&&a.target.deltaY===q.deltaY);
   if(m.c.inspect().session?.decision)act('choose_payment',a=>a.target.kind==='move-payment'&&!a.target.cardIds.length);
  }
  act('land');
  if(m.menu().some(a=>a.target?.planetId===planet&&a.target?.actionType==='land'))act('choose_target',a=>a.target?.planetId===planet&&a.target.landTarget.type==='planet');
  act('choose_target',a=>a.target?.choiceId==='trace:1:yellow:state-extra');
  if(m.menu().some(a=>a.target.ruleId==='amiba0-yellow-data'))act('accept_optional_effect',a=>a.target.ruleId==='amiba0-yellow-data');
  cut('landing');
  while(m.facts().computer.length<6&&m.player().resources.availableData){
   act('place_data');act('choose_target',a=>a.target.target==='computer');
  }
  finish();cut('before-analysis');
  if(m.facts().computer.length===6){
   act('analyze');act('choose_target',a=>a.target.choiceId==='trace:1:blue:state-extra');
   finish();
  }
  cut('after-two');
  const end=m.save();m.restore(root);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  rows.push({label,planet,funding,root,actions,stages,end,exact:true});
  console.log(label,planet,funding,Object.fromEntries(Object.entries(stages).map(([k,x])=>[k,[x.s.wallet,x.s.established,x.s.hand,x.s.computer,x.s.blue]])));
 }finally{m.dispose();}
}
writeZ(out,{rows});
