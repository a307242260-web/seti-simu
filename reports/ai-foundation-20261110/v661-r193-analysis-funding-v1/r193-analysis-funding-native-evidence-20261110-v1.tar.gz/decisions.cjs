'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [raw,savePath,early,trace,out]=process.argv.slice(2);
const orig=readZ(raw).snapshots['193'].envelope,official=JSON.parse(fs.readFileSync(savePath)).replaySteps;
const fixed=readZ(early).rows.find(x=>x.label==='earlier-analysis-ready'),d=readZ(trace),m=open(orig),rows={};
function query(name){
 const e=m.save(),q=m.automatic(),options=m.menu(),roots=q.roots.map(r=>{
  const a=options.find(a=>a.actionId===r.actionId);
  return {family:a?.family,summary:a?.summary,choice:a?.target?.choiceId,value:r.value,status:r.status,reason:r.reason};
 });
 rows[name]={e,s:short(m),q:{a:q.a,n:q.n,ms:q.ms,value:q.value,complete:q.complete,roots}};
 console.log(name,JSON.stringify(rows[name].q));assert.deepEqual(m.save(),e);
 assert(q.complete&&q.n<=256&&q.ms<=600);
}
try{
 for(let i=193;i<=211;i++){
  if([193,204,205,210,211].includes(i))query('actual:'+i);
  m.apply(official[i-1].action);
 }
 m.restore(orig);
 fixed.prefix.forEach(m.apply);
 assert.deepEqual(m.save(),fixed.start);query('computer6:before-early-analysis');
 m.restore(d['earlier-analysis-blue3'].roots[9].root);query('early-scan:pink');
 writeZ(out,rows);
}finally{m.dispose();}
