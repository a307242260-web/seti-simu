'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ,runCases}=require('./controlled-r3');
const [src,out,...modes]=process.argv.slice(2),saved=readZ(src),root=saved.rows.find(r=>r.label==='pink3').checkpoints['after-scan'].state;
const act=(h,f,p)=>h.act(f,p);
const put=h=>{act(h,'place_data');act(h,'choose_target',a=>a.target.target==='computer');};
const idFor=(h,id)=>h.m.player().hand.find(a=>a.cardId===id)?.id;
function income(h,id){for(let i=0;i<3;i++)put(h);act(h,'choose_card',a=>a.target.cardInstanceId===idFor(h,id));}
function launch(h,pick){act(h,'end_turn');act(h,'research_tech');act(h,'choose_target',a=>a.target.tileId==='orange1');h.take(h.m.pick(pick));act(h,'end_turn');}
function pay(h,discard){
 act(h,'quick_trade',a=>a.target.tradeId==='cards-for-credit');
 for(const id of discard)act(h,'choose_payment',a=>a.target.cardInstanceId===idFor(h,id));
 if(h.m.c.inspect().session?.decision)act(h,'choose_payment',a=>a.target.kind!=='discard-hand-card');
}
function prepare(h,mode){
 if(mode==='electric'){
  income(h,'amiba_9.webp');launch(h,'dlc_20.png');
  pay(h,['amiba_2.webp','dlc_20.png']);
 }else{income(h,'amiba_2.webp');launch(h,mode==='cash-dlc17'?'dlc_17.png':'dlc_20.png');}
 h.cut('funded-scan');
 h.take(h.m.play('b_16.webp'));
 act(h,'choose_target',a=>a.target.deltaX===0&&a.target.deltaY===1);
 h.cut('scan-menu');
}
const m=open(root),rows=[];
try{
 for(const mode of (modes.length?modes:['cash-dlc17','cash-dlc20','electric'])){
  m.restore(root);
  const h={m,take:()=>{},cut:()=>{},act:m.act};
  try{
   prepare(h,mode);
   const targetList=m.menu().filter(a=>a.target.nebulaId);
   assert(targetList.length);
   for(const a of targetList)rows.push([mode+':'+a.target.nebulaId,b=>{
    prepare(b,mode);act(b,'choose_target',q=>q.target.nebulaId===a.target.nebulaId);b.cut('second-scan');
   }]);
  }catch(e){console.log('prefix fail',mode,String(e),m.menu().map(a=>[a.family,a.target]));}
 }
}finally{m.dispose();}
assert(rows.length);
writeZ(out,{root,...runCases(root,rows)});
