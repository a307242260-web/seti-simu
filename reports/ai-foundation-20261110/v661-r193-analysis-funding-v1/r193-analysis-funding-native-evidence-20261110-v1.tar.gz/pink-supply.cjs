'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),history=readZ(src)['earlier-analysis-blue3'].roots,root=history[9].root;
const act=(h,f,p)=>h.act(f,p);
const put=(h,slot)=>{act(h,'place_data');act(h,'choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');};
const end=h=>act(h,'end_turn');
const corner=(h,id)=>h.take(h.m.corner(id));
function income(h,id){const c=h.m.player().hand.find(a=>a.cardId===id);assert(c,id);act(h,'choose_card',a=>a.target.cardInstanceId===c.id);}
function tech(h,id){act(h,'research_tech');act(h,'choose_target',a=>a.target.tileId===id&&(!a.target.blueSlot||a.target.blueSlot===3));}
function start(h,pink){
 act(h,'choose_target',a=>a.target.choiceId==='trace:1:pink:'+(pink===3?'amiba:3':'state-extra'));
 if(pink===3)act(h,'choose_card',a=>a.target.choiceId==='amiba:display:2');
 if(h.m.menu().some(a=>a.target.ruleId==='amiba0-pink-data'))act(h,'accept_optional_effect',a=>a.target.ruleId==='amiba0-pink-data');
 if(h.m.menu().some(a=>a.family==='complete_task'&&a.summary.includes('dlc_9')))act(h,'complete_task',a=>a.summary.includes('dlc_9'));
 h.cut('after-scan');
}
function funding(h,currency){
 start(h,3);
 put(h);put(h);put(h,2);
 h.take(h.m.pick('dlc_25.png'));
 corner(h,'amiba_2.webp');put(h);
 income(h,currency==='e'?'dlc_25.png':'b_16.webp');
 h.cut('after-income');
}
function prepareLaunch(h,currency,id){
 funding(h,currency);end(h);tech(h,'orange1');
 h.take(h.m.pick(id));h.cut('after-launch');
}
const candidates=[
 ['pink3',h=>start(h,3)],['pink-extra',h=>start(h,0)],
 ['pink3-extra-data-electric',h=>funding(h,'e')],
 ['pink3-extra-data-cash',h=>funding(h,'c')],
 ...['e','c'].flatMap(c=>['dlc_20.png','dlc_17.png'].map(id=>[c+':orange1:'+id,h=>prepareLaunch(h,c,id)])),
];
const m=open(root);
try{const q=m.automatic();console.log('base',q.complete,q.n,q.ms,q.a?.summary,q.roots.map(r=>[r.actionId,r.value]));assert(q.complete&&q.n<=256&&q.ms<=600);}finally{m.dispose();}
writeZ(out,{root,...runCases(root,candidates)});
