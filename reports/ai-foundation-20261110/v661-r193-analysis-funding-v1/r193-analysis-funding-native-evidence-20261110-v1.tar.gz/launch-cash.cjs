'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),saved=readZ(src),root=saved.rows.find(r=>r.label==='pink3').checkpoints['after-scan'].state;
const act=(h,f,p)=>h.act(f,p);
const corner=(h,id)=>h.take(h.m.corner(id));
const put=(h,slot)=>{act(h,'place_data');act(h,'choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');};
const swap=(h,drop,into)=>h.take(...h.m.swap(drop,into));
function income(h,id){
 const c=h.m.player().hand.find(a=>a.cardId===id);assert(c,id);
 act(h,'choose_card',a=>a.target.cardInstanceId===c.id);
}
function tech(h,id){
 act(h,'research_tech');act(h,'choose_target',a=>a.target.tileId===id&&(!a.target.blueSlot||a.target.blueSlot===3));
}
function move(h,mode){
 act(h,'move',a=>a.target.deltaY===1&&a.target.deltaX===0);
 act(h,'choose_payment',a=>mode==='card'?a.target.cardIds?.length===1:a.target.cardIds?.length===0);
}
function funding(h,drop){
 const incomeId=drop?'dlc_25.png':'amiba_9.webp';
 if(drop)swap(h,drop,incomeId);
 for(let i=0;i<3;i++)put(h);
 income(h,incomeId);h.cut('funded');
}
const rows=[];
for(const [k,drop,pubCard] of [['amiba9',null,'b_16.webp'],['swap-b16','b_16.webp','amiba_9.webp'],['swap-amiba9','amiba_9.webp','b_16.webp']]){
 for(const slot of [0,3]){
  rows.push([k+':orange1:blue1:'+slot,h=>{
   funding(h,drop);act(h,'end_turn');tech(h,'orange1');h.take(h.m.pick('dlc_17.png'));h.cut('launch');
   act(h,'end_turn');
   move(h,'energy');
   corner(h,pubCard);
   tech(h,'blue1');
   corner(h,'amiba_2.webp');put(h);
   if(slot){corner(h,'dlc_17.png');put(h,slot);}
   h.cut('blue');
  }]);
 }
}
for(const tile of ['purple2','purple3','orange3'])for(const mode of ['amiba9','swap-b16'])rows.push([mode+':'+tile,h=>{
 funding(h,mode==='amiba9'?null:'b_16.webp');act(h,'end_turn');tech(h,tile);
 if(h.m.menu()[0]?.family==='choose_card')h.take(h.m.pick('dlc_17.png'));
 h.cut('new-tech');
}]);
const m=open(root);
try{const q=m.automatic();console.log('base',q.complete,q.n,q.ms,q.a?.summary);assert(q.complete&&q.n<=256&&q.ms<=600);}finally{m.dispose();}
writeZ(out,{root,...runCases(root,rows)});
