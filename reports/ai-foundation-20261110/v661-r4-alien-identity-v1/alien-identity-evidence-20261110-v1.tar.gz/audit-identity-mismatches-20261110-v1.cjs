'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const [root,out]=process.argv.slice(2),file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));Module._cache[file]=mod;
const at='          if(prior.stored.physicalKey===exact)return prior.id;',source=fs.readFileSync(file,'utf8');
assert.equal(source.split(at).length,2);
mod._compile(source.replace(at,'          globalThis.compareIdentity(prior.stored,stored);\n'+at),file);mod.loaded=true;
const {open}=require('./native-late-r3'),cp=JSON.parse(fs.readFileSync(root)).checkpoint,m=open(cp);
const memo=new WeakMap(),counts={},fields={},paths={},combined={};let equal=0,total=0;
function parts(stored){
 let p=memo.get(stored);if(!p){p=JSON.parse(stored.physicalKey);memo.set(stored,p);}return p;
}
const j=JSON.stringify;
function diff(a,b,at,list){
 if(Object.is(a,b))return;
 if(!a||!b||typeof a!=='object'||typeof b!=='object'){list.add(at);return;}
 for(const k of new Set([...Object.keys(a),...Object.keys(b)]))diff(a[k],b[k],at+'.'+k,list);
}
globalThis.compareIdentity=(left,right)=>{
 total++;
 if(left.physicalKey===right.physicalKey){equal++;return;}
 const a=parts(left),b=parts(right),names=['pending','state','status','boundary'].filter(k=>j(a[k])!==j(b[k]));
 const changed=[];
 for(const name of names){
  if(name==='state'){for(const k of Object.keys(a.state))if(j(a.state[k])!==j(b.state[k]))changed.push(k);}
  else changed.push(name);
 }
 for(const name of changed)fields[name]=(fields[name]||0)+1;
 const key=changed.join(',');combined[key]=(combined[key]||0)+1;
 const diffs=new Set();diff(a,b,'',diffs);
 for(const p of new Set(Array.from(diffs, s=>s.replace(/\.[0-9]+(?=\.|$)/g,'.*'))))paths[p]=(paths[p]||0)+1;
};
try{
 const q=m.automatic();assert(q.complete);assert.deepEqual(m.save(),cp);
 const sort=x=>Object.fromEntries(Object.entries(x).sort((a,b)=>b[1]-a[1]));
 const data={native:q.n,total,equal,unequal:total-equal,fields:sort(fields),combinations:sort(combined),paths:sort(paths)};
 fs.writeFileSync(out,JSON.stringify(data,null,2)+'\n');
 console.log(JSON.stringify({...data,combinations:Object.entries(data.combinations).slice(0,12),paths:Object.entries(data.paths).slice(0,25)}));
}finally{m.dispose();}
