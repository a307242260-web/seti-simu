from pathlib import Path
import gzip,json,subprocess,sys,statistics
root=Path(sys.argv[1]).resolve()
fixture=Path(sys.argv[2]).resolve()
dest=Path(sys.argv[3]).resolve()
tool=root/'probe-r4-wallet-shipment-20261110-v1.cjs'
pairs=[]
for i,order in enumerate((('464','466'),('466','464'),('464','466'))):
 row={}
 for v in order:
  output=dest.parent/f'wallet-marker-pair-{i+1}-v{v}-20261110-v2.json.gz'
  subprocess.run(['node',str(tool),str(fixture),str(output)],cwd=root/f'candidate-v{v}',check=True,stdout=subprocess.DEVNULL)
  with gzip.open(output,'rt') as f: row[v]=json.load(f)
 for k,x in row['464'].items():
  y=row['466'][k]
  for field in ('chosen','value','plan','nodes','roots'):assert x[field]==y[field],(k,field)
  assert len(x['roots'])==len(y['roots'])
  for a,b in zip(x['roots'],y['roots']):
   assert a['actionId']==b['actionId']
   if a['value'] is None:assert b['value'] is None;continue
   assert b['value']<=a['value'],(k,a,b)
   if a['value']!=b['value']:assert b.get('valueType')=='attained-lower-bound'
 pairs.append({v:{k:{x:r[x] for x in ('chosen','value','n','nodes','ms')} for k,r in vals.items()} for v,vals in row.items()})
dest.write_text(json.dumps(pairs,indent=2)+'\n')
for k in pairs[0]['464']:
 print(k,[(v,pairs[0][v][k]['n'],pairs[0][v][k]['nodes'],round(statistics.median(p[v][k]['ms'] for p in pairs))) for v in ('464','466')])
