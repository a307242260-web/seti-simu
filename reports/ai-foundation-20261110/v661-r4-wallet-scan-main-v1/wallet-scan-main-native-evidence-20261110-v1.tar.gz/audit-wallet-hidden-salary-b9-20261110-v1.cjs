'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,short}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [file,out]=process.argv.slice(2),{root,rows}=readZ(file),seat='player-white',res={};
function substitute(cardId){
 if(cardId==='b_9.webp')return root;
 const s=JSON.parse(root.committedState),deck=s.cards.drawPileCardIds;
 const from=deck.indexOf('b_9.webp'),to=deck.indexOf(cardId);
 assert.equal(from,0);assert(to>=4);
 [deck[from],deck[to]]=[deck[to],deck[from]];
 return {...root,committedState:JSON.stringify(s)};
}
function inspect(e){
 const m=open(e),p=createAnalysisPort({composition:m.c,seatId:seat});
 try{
  const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),e);
  const menu=m.menu(),action=menu.find(x=>x.actionId===q.actionId);
  const ship=q.roots.find(r=>r.goal?.kind==='wallet-earth-shipment');
  return {action,value:q.value,n:q.diagnostics.nativeExecutions,nodes:q.diagnostics.graphNodes,ms:q.rootAndSearchMilliseconds,roots:q.roots,ship};
 }finally{p.close();m.dispose();}
}
function view(e){const m=open(e);try{return [m.owner(seat),m.menu(),m.state().meta.rngState];}finally{m.dispose();}}
const originalView=view(root),previous=inspect(root);
for(const cardId of ['b_9.webp','b_137.webp','b_104.webp']){
 const initial=substitute(cardId),initialResult=cardId==='b_9.webp'?previous:inspect(initial);
 assert.deepEqual(view(initial),originalView);
 for(const k of ['action','value','roots','n'])assert.deepEqual(initialResult[k],previous[k],k);
 const arms={};
 for(const name of ['keep-amiba9','research-orange3']){
  const m=open(initial),prefix=[];
  try{
   for(const a of rows[name].steps){
    if(m.facts().round===4&&m.menu()[0]?.actorId===seat&&!m.save().session)break;
    prefix.push(m.apply(a));
   }
   assert.equal(m.facts().round,4);assert(m.player().hand.some(c=>c.cardId===cardId));
   const state=m.save(),facts=short(m);if(cardId==='b_9.webp')assert.deepEqual(state,rows[name].stages.round4.state);
   m.restore(initial);prefix.forEach(a=>m.apply(a));assert.deepEqual(m.save(),state);
   const decision=inspect(state);
   arms[name]={state,facts,prefix,decision};
   console.log(JSON.stringify([cardId,name,decision.action.summary,decision.value,decision.ship?.value,decision.n,Math.round(decision.ms)]));
  }finally{m.dispose();}
 }
 res[cardId]={initial,initialResult,arms};
}
writeZ(out,res);
