'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),Module=require('node:module');
const ai=path.resolve('randomizer/game/ai'),portFile=path.join(ai,'analysis-port.js'),searchFile=path.join(ai,'decision-search.js');
const original=Module._extensions['.js'],snapshots=new WeakMap(),byIndex=new Map(),names=new Map();
globalThis.fanoutNode=(node,envelope,state)=>snapshots.set(node,{envelope,state});
globalThis.fanoutIndex=(i,node)=>byIndex.set(i,node);
globalThis.fanoutName=a=>names.set(a.actionId,{family:a.family,target:a.target,summary:a.summary});
Module._extensions['.js']=(m,f)=>{
 if(f!==portFile&&f!==searchFile)return original(m,f);
 let s=fs.readFileSync(f,'utf8');
 if(f===portFile){
  const a='      nodeCount += 1;\n      return node;',b='      const key = expansionKey(stored,actionId);';
  assert.equal(s.split(a).length,2);assert.equal(s.split(b).length,2);
  s=s.replace(a,'      globalThis.fanoutNode(node,envelope,()=>readIdentityState(envelope));\n'+a)
     .replace(b,b+'\n      globalThis.fanoutName(requested);');
 }else{
  const a='      if(initializeDeferred){configured.queued=nodes[index].queued;nodes[index]=configured;}else nodes.push(configured);';
  assert.equal(s.split(a).length,2);s=s.replace(a,a+'\n      globalThis.fanoutIndex(index,node);');
 }
 m._compile(s,f);
};
const {readZ,writeZ,open}=require('./controlled-r3'),{createAnalysisPort}=require(portFile),{createSearchAgent}=require(path.join(ai,'search-agent'));
const [fixture,out]=process.argv.slice(2),{rows}=readZ(fixture),result={},seat='player-white';
for(const name of ['keep-amiba9','research-orange3']){
 const root=rows[name].stages.round4.state,m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat});
 byIndex.clear();names.clear();
 try{
  const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete);assert.deepEqual(m.save(),root);
  const claim=q.lines[0].edges.find(e=>e.resourcePlan?.goal.kind==='wallet-earth-shipment');
  assert(claim);
  const indexSet=(starts)=>{
   const seen=new Set(),pending=[...starts];
   while(pending.length){const i=pending.pop();if(seen.has(i))continue;seen.add(i);pending.push(...q.lines[i].edges.map(e=>e.target));}
   return seen;
  };
  const source=claim.target,seen=new Set(),queue=[source],groups=new Map(),mainFamilies=new Set(['launch','scan','play_card','orbit','land','research_tech','analyze','pass']);
  const starters=[];
  while(queue.length){
   const i=queue.shift();if(seen.has(i))continue;seen.add(i);
   const line=q.lines[i];
   for(const e of line.edges){
    const ids=e.steps?.length?e.steps:[e.actionId],act=ids.map(id=>names.get(id)).find(a=>a&&mainFamilies.has(a.family));
    const goal=e.resourcePlan?.goal;
    if(act){
     const card=act.target?.cardInstanceId,main=act.family==='scan'&&goal?.nebulaId?act.summary+' / '+goal.nebulaId:act.summary;
     const key=[act.family,main,card].filter(Boolean).join('|'),g=groups.get(key)||{act,starts:[],edges:[]};
     g.starts.push(e.target);g.edges.push({from:i,to:e.target,value:q.lines[e.target].value,ids,goal});
     groups.set(key,g);starters.push({i,e,key});
    }else queue.push(e.target);
   }
  }
  const memberships=new Map();
  for(const g of groups.values()){
   g.reachable=[...indexSet(g.starts)];
   for(const id of g.reachable)memberships.set(id,(memberships.get(id)||0)+1);
   g.maximum=Math.max(...g.edges.map(e=>e.value??-Infinity));
  }
  for(const g of groups.values()){
   g.exclusive=g.reachable.filter(id=>memberships.get(id)===1).length;
   g.incoming=g.edges.length;
  }
  const side=[...groups].map(([k,g])=>[k,g.incoming,g.reachable.length,g.exclusive,Number.isFinite(g.maximum)?g.maximum:null]);
  const menu=q.lines[source].edges.map(e=>[names.get(e.actionId)?.summary||e.actionId,e.resourcePlan?.goal.id||null,q.lines[e.target].value,indexSet([e.target]).size]);
  const touched=[...indexSet([source])].map(i=>{const line=q.lines[i],raw=snapshots.get(byIndex.get(i)),s=raw?.state(),p=s?.players.players.find(v=>v.id===seat);
   return {i,line:{value:line.value,status:line.status,boundary:line.boundary,distance:line.distance,
    edges:line.edges,actionBounds:line.actionBounds,resourcePolicy:line.resourcePolicy},turn:s?.turn.turnNumber,
    main:p?.mainActionCompleted,assets:p&&{wallet:p.resources,hand:p.hand.map(c=>c.cardId),tech:p.techState,scoreSources:p.scoreSources,
     computer:p.dataState.placedTokens.map(t=>[t.placementKind,t.placementSlot??t.blueSlot]),
     probes:s.pieces.rockets.filter(r=>r.playerId===seat).map(r=>[r.id,r.kind,r.sectorX,r.sectorY]),
     market:s.cards.publicCards.map(c=>c?.cardId)}};});
  const replays=[];
  if(name==='keep-amiba9'){
   const targets=[source,31,32,1274];
   const prefix=new Map([[source,[]]]),frontier=[source];
   for(let k=0;k<frontier.length;k++){
    const i=frontier[k];
    for(const e of q.lines[i].edges){
     if(prefix.has(e.target)||!seen.has(e.target))continue;
     const ids=e.steps?.length?e.steps:[e.actionId];
     prefix.set(e.target,[...prefix.get(i),...ids]);frontier.push(e.target);
    }
   }
   const path=e=>{
    const value=q.lines[e.to].value,steps=[...e.ids];let i=e.to;
    while(q.lines[i].edges.length){
     const line=q.lines[i],next=line.edges.filter(y=>q.lines[y.target].value===value&&q.lines[y.target].distance<line.distance)
      .sort((a,b)=>a.cost+q.lines[a.target].distance-b.cost-q.lines[b.target].distance)[0];
     if(!next)return {steps,status:'unresolved-value-path'};
     if(next.turnTailPlanValue){
      const proof=next.turnTailPlanValue;
      return {steps,synthetic:proof,status:'proved-tail'};
     }
     steps.push(...(next.steps?.length?next.steps:[next.actionId]));i=next.target;
    }
    return {steps,status:q.lines[i].status};
   };
   for(const [label,g] of groups){
    if(!label.includes('|b_9.webp|')&&!label.includes('|dlc_13.png|'))continue;
    for(const e of g.edges.filter(e=>targets.includes(e.from))){
     const selected=path(e),ids=[...claim.steps,...prefix.get(e.from),...selected.steps];
     m.restore(root);
     const accepted=ids.map(id=>{const action=m.menu().find(a=>a.actionId===id);assert(action,JSON.stringify({id,menu:m.menu().map(a=>a.actionId)}));return m.apply(action);});
     if(selected.synthetic){
      const t=selected.synthetic;
      if(t.requiredNativeInputs===1&&t.kind==='end-turn')accepted.push(m.act('end_turn'));
      else if(t.bluePublicPick&&t.kind==='blue-end-turn'&&t.requiredNativeInputs===6){
       accepted.push(m.act('place_data'),m.act('choose_target',a=>a.target.blueSlot===2),
        m.act('choose_card',a=>a.target.cardInstanceId===t.bluePublicPick.cardId),
        m.act('place_data'),m.act('choose_target',a=>a.target.blueSlot===3),m.act('end_turn'));
      }
     }
     const end=m.save(),f=m.facts(),closed=m.menu()[0]?.actorId!==seat&&!end.session;
     m.restore(root);accepted.forEach(a=>m.apply(a));assert.deepEqual(m.save(),end);m.restore(root);
     replays.push({label,from:e.from,value:e.value,status:selected.status,proof:selected.synthetic?.proof,closed,accepted,end,
      wallet:f.wallet,income:f.income,hand:f.hand,market:f.market,blue:f.blue,computer:f.computer});
    }
   }
   assert.equal(replays.length,8);
  }
  result[name]={root,source,side,menu,groups:Object.fromEntries(groups),total:q.diagnostics.nativeExecutions,nodeCount:q.diagnostics.graphNodes,touched,replays};
  console.log(JSON.stringify({name,source,preMainNodes:seen.size,covered:memberships.size,side:side.sort((a,b)=>b[3]-a[3]).slice(0,18),menu}));
  for(const r of replays)console.log(JSON.stringify([r.label,r.from,r.value,r.closed,r.status,r.proof,r.wallet.score,r.wallet.credits,r.wallet.energy,r.wallet.publicity,r.income,r.accepted.slice(claim.steps.length,claim.steps.length+7).map(a=>a.summary)]));
 }finally{port.close();m.dispose();}
}
writeZ(out,result);
