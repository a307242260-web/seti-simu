'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),Module=require('node:module');
const ai=path.resolve('randomizer/game/ai'),file=path.join(ai,'analysis-port.js'),load=Module._extensions['.js'],native=[];
globalThis.captureNative=(a,e,head,s,readState)=>{
 const st=s?.workingState||readState(e),p=st.players.players.find(p=>p.id===a.actorId);
 const claim=!!st.aliens.chong?.fossilsById?.fossil_07?.taskCompleted;
 const parent=s?.journal.actions[0]?.action;
 native.push({f:a.family,target:a.target||{},summary:a.summary,head:head?.type,parent:parent&&[parent.family,parent.summary],
  queue:s?.queue.map(x=>[x.type,x.ownerId,x.allowQuickActions]),headOpts:head?.payload?.options,marker:s?.queue.find(x=>x.type==="card_play_domain_direct")?.payload,prelude:[s?.undoFrames.length,s?.irreversibleBarrier?.code],
  claim,main:p.mainActionCompleted,data:p.resources.availableData,slots:p.dataState.placedTokens.filter(t=>t.placementKind==='computer').map(t=>t.placementSlot),
  st:st.meta.stateVersion,known:[st.cards.publicCards.filter(Boolean).length,p.reservedCards.length],fossilOpen:!!Object.keys(st.aliens.chong?.transportTasksByRocketId||{}).length});
};
Module._extensions['.js']=(m,f)=>{
 if(f!==file)return load(m,f);const s=fs.readFileSync(f,'utf8');
 const anchor='      loadedEnvelope = null;\n      const executeAt = now();';
 assert.equal(s.split(anchor).length,2);
 m._compile(s.replace(anchor,'      globalThis.captureNative(current,loadedEnvelope,head,session,readIdentityState);\n'+anchor),f);
};
const {readZ,writeZ,open}=require('./controlled-r3'),{createAnalysisPort}=require(file),{createSearchAgent}=require(path.join(ai,'search-agent'));
const [fixture,key,out]=process.argv.slice(2),e=readZ(fixture).rows[key].stages.round4.state,m=open(e),seat='player-white';
const port=createAnalysisPort({composition:m.c,seatId:seat});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete);assert.deepEqual(m.save(),e);assert.equal(q.diagnostics.nativeExecutions,native.length);
 const cost={};
 for(const r of native){
  const k=(r.claim?'claim':'before')+' / '+[r.f,r.head,r.target.tradeId||r.target.choiceId?.split(':')[0]||r.target.kind,r.main?'post':'pre'].filter(Boolean).join('/');
  cost[k]=(cost[k]||0)+1;
 }
 const summary=Object.entries(cost).sort((a,b)=>b[1]-a[1]);writeZ(out,{root:e,key,summary,native,analysis:q.analysis});
 console.log(JSON.stringify([key,q.value,native.length,summary.slice(0,30),q.analysis]));
}finally{port.close();m.dispose();}
