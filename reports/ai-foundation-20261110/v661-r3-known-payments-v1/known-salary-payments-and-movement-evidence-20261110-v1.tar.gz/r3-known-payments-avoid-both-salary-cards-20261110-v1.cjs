'use strict';
const assert=require('node:assert/strict');
const {readZ,writeZ,open,short}=require('./controlled-r3');
const {control}=require('./r3-r4-handoff-known-payments-20261110-v1.cjs');
const [source,proof,output]=process.argv.slice(2);
const reference=readZ(source)['analyze-fill-3'].checkpoint;
const witness=readZ(proof).rows.preserve.auto;
const seat='player-white';
const visible = e => {
 const m=open(e);
 try {return {state:m.owner(seat),actions:m.menu()};} finally {m.dispose();}
};
const view=visible(reference);
const expected=JSON.parse(reference.committedState);
assert.equal(expected.cards.drawPileCardIds[1],'b_9.webp');

function exact(m, origin, actions) {
 const end=m.save();m.restore(origin);actions.forEach(m.apply);assert.deepEqual(m.save(),end);m.restore(origin);return end;
}
function run(origin) {
 const m=open(origin),prior=open(witness.origin),actions=[],stages={};
 const take=(f,id)=>actions.push(m.act(f,typeof id==='function'?id:v=>!id||v.target?.choiceId===id||v.target?.tradeId===id));
 const cut=k=>stages[k]={state:m.save(),summary:short(m)};
 const fill=()=>{take('place_data');take('choose_target',v=>v.target.target==='computer');};
 const use=a=>{
  if(a.family==='choose_payment'){
   const before=new Map(prior.facts().hand),now=new Map(m.facts().hand);
   const label=ids=>JSON.stringify(ids.sort());
   const names=label(a.target.cardIds.map(id=>before.get(id)));
   take('choose_payment',v=>label(v.target.cardIds.map(id=>now.get(id)))===names);
  }else actions.push(m.apply(a));
  prior.apply(a);
 };
 try {
  const incomeDraws=m.facts().hand.filter(h=>['card-68-0','card-69-0'].includes(h[0]));
  assert.equal(incomeDraws.length,2);
  take('end_turn');m.advanceOpponents(actions);
  take('quick_trade','cards-for-energy');
  for(const [id] of incomeDraws)take('choose_payment',v=>v.target.cardInstanceId===id);
  take('choose_payment',v=>v.target.kind==='confirm');
  take('quick_trade','credits-for-energy');
  take('scan');
  take('choose_target','nebula:sector-2-b');
  take('choose_card','public:card-67-0:sector-1-a');
  take('choose_card','public:done');
  take('choose_target','scan4:launch');
  cut('scan-and-launch');
  assert.equal(short(m).wallet[4],2);
  fill();
  take('end_turn');m.advanceOpponents(actions);
  cut('before-landing');
  for(const a of m.swap('amiba_9.webp','dlc_16.png'))actions.push(a);
  witness.actions.slice(0,3).forEach(prior.apply);
  for(const a of witness.actions.slice(3,18))use(a);
  cut('after-landing');
  fill();fill();
  for(const a of witness.actions.slice(18,20))use(a);
  take('choose_card',v=>v.summary==='amiba_9.webp');
  take('end_turn');
  cut('turn-end');
  return {origin,actions,stages,end:exact(m,origin,actions),incomeDraws:incomeDraws.map(h=>h[1])};
 } finally{m.dispose();prior.dispose();}
}

const rows={};
for(const [i,j] of [[0,1],[2,3],[113,114]]){
 const state=JSON.parse(reference.committedState),pile=state.cards.drawPileCardIds;
 [pile[i],pile[0]]=[pile[0],pile[i]];
 [pile[j],pile[1]]=[pile[1],pile[j]];
 const root={...reference,committedState:JSON.stringify(state)};
 assert.deepEqual(visible(root),view);
 assert.deepEqual(state.meta.rngState,expected.meta.rngState);
 const handoff=control(root,{dataCard:'b_111.webp',incomeCard:'chong_8.webp'});
 assert(handoff.replayExact&&!handoff.failure);
 const post=handoff.stages['after-common-blue8'];
 const row=run(post.state);rows[i]={root,handoff,row};
 console.log(i,row.incomeDraws,JSON.stringify(row.stages['turn-end'].summary),row.actions.length);
}
writeZ(output,{rows,visibilityExact:true,scope:'Both hidden salary identities are interchangeable. Reserve B111 pays the data deficit and already-held Chong 8 is invested as electricity income. Two unidentified salary instances buy one energy by count; only visible cards or actions fund the rest. No autonomous rollout.'});
