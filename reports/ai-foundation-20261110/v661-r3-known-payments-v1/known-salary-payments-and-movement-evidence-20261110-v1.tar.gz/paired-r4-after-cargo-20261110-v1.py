from pathlib import Path
from statistics import median
import json, subprocess, sys
base,new,fixture,out=sys.argv[1:]
here=Path(__file__).resolve().parent
rows={}
for index in ('9','11','14'):
    batch=[]
    for i in range(3 if index=='9' else 1):
        order=[('base',base),('new',new)]
        if i%2: order.reverse()
        for tag,src in order:
            p=subprocess.run(['node',str(here/'cold-r4-after-cargo-20261110-v1.cjs'),fixture,index],cwd=src,capture_output=True,text=True,check=True)
            batch.append({'tag':tag,**json.loads(p.stdout)})
    assert all((r['actionId'],r['value'],r['roots'],r['nodes'],r['rankGraph'])==(batch[0]['actionId'],batch[0]['value'],batch[0]['roots'],batch[0]['nodes'],batch[0]['rankGraph']) for r in batch)
    rows[index]=batch
    print(index,[(tag,median(r['ms'] for r in batch if r['tag']==tag),next(r['n'] for r in batch if r['tag']==tag)) for tag in ('base','new')],flush=True)
with open(out,'x') as f: json.dump(rows,f,ensure_ascii=False)
