'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),{open,z,seat}=require('./native-late-r3');
const readZ=p=>JSON.parse(z.gunzipSync(fs.readFileSync(p)));
const writeZ=(p,data)=>fs.writeFileSync(p,z.gzipSync(JSON.stringify(data)),{flag:'wx'});
function short(m){
 const f=m.facts(),w=f.wallet,alien=m.owner(seat).publicState.board.aliens;
 return {turn:f.turn,wallet:[w.score,w.credits,w.energy,w.publicity,w.availableData],
  income:[f.income.credits,f.income.energy,f.income.handSize,f.income.additionalPublicScan],
  established:f.final,computer:f.computer,blue:f.blue,tech:Object.keys(f.tech.ownedTiles),probes:f.probes.map(q=>[q.sectorX,q.sectorY,q.fossilId]),
  hand:f.hand.map(x=>x[1]),market:f.market.map(x=>x?.[1]),amibaOffer:alien.amibaTraces?.displayedCardIndex,chongOffer:alien.chongOffer?.displayedCardIndex};
}
function autonomous(m){
 const start=m.save(),actions=[],roots=[];let stop,settled,checkpoint;
 for(let i=0;i<120;i++){
  const q=m.menu()[0];assert(q);
  if(q.actorId!==seat){
   const a=[];m.advanceOpponents(a);actions.push(...a.map(action=>({action,passive:true})));continue;
  }
  if(m.facts().round===4&&!m.c.inspect().session){stop='r4-first-white-main';break;}
  const u=m.automatic(checkpoint),a=u.a;
  if(!u.complete||u.n>256||u.ms>600){stop={kind:'gate',n:u.n,ms:u.ms,action:a?.summary};break;}
  if(i===0||a.phase==='main'||a.family==='pass')roots.push({action:a,n:u.n,ms:u.ms,value:u.value,roots:u.roots});
  if(a.family==='pass'&&m.facts().round===3)settled={state:m.save(),assets:m.facts(),summary:short(m)};
  checkpoint=u.checkpoint;actions.push({action:m.apply(a),n:u.n,ms:u.ms,value:u.value});
 }
 assert(stop);
 const end=m.save(),opening=short(m);
 m.restore(start);actions.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),end);m.restore(start);
 return {actions,roots,settled,end,opening,stop};
}
function runCases(origin,cases){
 const m=open(origin),rows=[],failures=[];
 try{
  for(const [label,sequence] of cases){
   m.restore(origin);const prefix=[];
   const take=(...a)=>{prefix.push(...a);return a[0];},act=(f,p)=>take(m.act(f,p));
   let checkpoints={};
   try{sequence({m,take,act,cut:k=>checkpoints[k]={state:m.save(),summary:short(m)}});}
   catch(err){
    failures.push({label,reason:String(err),prefix,menu:m.menu(),checkpoint:m.save(),summary:short(m)});
    console.log(JSON.stringify([label,'infeasible',String(err).slice(0,190),short(m)]));continue;
   }
   const start=m.save(),summary=short(m),r=autonomous(m);
   m.restore(origin);prefix.forEach(m.apply);assert.deepEqual(m.save(),start);m.restore(origin);
   rows.push({label,prefix,checkpoints,start,summary,...r,replayExact:true});
   console.log(JSON.stringify([label,r.stop,r.settled?.summary,r.roots.map(x=>x.action.summary),
    Math.max(0,...r.actions.map(x=>x.n||0)),Math.max(0,...r.actions.map(x=>x.ms||0))]));
  }
  return {rows,failures};
 }finally{m.dispose();}
}
module.exports={readZ,writeZ,short,runCases,open};
