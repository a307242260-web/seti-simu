'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,open}=require('./controlled-r3');
const [file,out,coverage]=process.argv.slice(2),x=readZ(file),m=open(x.root);
const groups=new Map(),rows=[];
function canonical(e){
 const clone=structuredClone(e);
 clone.committedState=JSON.parse(clone.committedState);
 const ss=clone.session?.session;
 if(ss){ss.undoFrames=[];const prefix=ss.sessionId;
  if(prefix){
   const visit=o=>typeof o==='string'?o.replaceAll(prefix,'@session'):Array.isArray(o)?o.map(visit):o&&typeof o==='object'?Object.fromEntries(Object.entries(o).map(([k,v])=>[k,visit(v)])):o;
   clone.session=visit(clone.session);
  }
 }
 return clone;
}
const shape=e=>({actor:JSON.parse(e.committedState).turn.currentPlayerId,pending:e.session?.session?.queue[0]?.type||null});
for(const r of x.chains){
 const start=r.details[0],end=r.details.at(-1);
 const key=JSON.stringify([end.value-r.directValue,r.steps.length,start.intent?.goal?.id||null,shape(end.e),shape(r.directState.e)]);
 if(!groups.has(key))groups.set(key,[]);
 groups.get(key).push(r);
}
function forwardDataTokens(e){
 const out=canonical(e);
 for(const state of [out.committedState,out.session?.session?.workingState,out.session?.session?.baseState]){
  if(!state)continue;
  delete state.meta.sequences.dataToken;
  for(const p of state.players.players){
   const d=p.dataState;
   const token=(t,pool)=>{const x={...t};delete x.id;delete x.index;if(pool)delete x.slotIndex;return x;};
   d.poolTokens=d.poolTokens.map(t=>token(t,true));
   d.placedTokens=d.placedTokens.map(t=>token(t,false)).sort((a,b)=>a.placementKind.localeCompare(b.placementKind)
    ||(a.placementSlot??a.blueSlot)-(b.placementSlot??b.blueSlot));
  }
 }
 return out;
}
function execute(root,steps,expected){
 assert(m.c.lifecycle.restore(root).ok);
 const summaries=[];
 for(const id of steps){
  const a=m.menu().find(a=>a.actionId===id);
  assert(a,JSON.stringify({id,menu:m.menu().map(v=>[v.actionId,v.summary])}).slice(0,1300));
  m.apply(a);summaries.push(a.summary);
 }
 const native=m.save();
 let stateMatch="exact";
 try{assert.deepEqual(canonical(native),canonical(expected));}
 catch{
  try{assert.deepEqual(forwardDataTokens(native),forwardDataTokens(expected));}
  catch(error){throw new Error("NATIVE_TAIL_ENDPOINT_DIFFERENT: "+String(error).slice(0,1600));}
  stateMatch="forward-data-token-equivalent";
 }
 return {summaries,shape:shape(native),assets:m.facts(),stateMatch};
}
try{
 for(const [key,items] of groups){
  for(const r of coverage==='all'?items:[items[0]]){
  const start=r.details[0],end=r.details.at(-1);
  const a=execute(start.e,r.steps,end.e),b=execute(start.e,[r.direct],r.directState.e);
  rows.push({key,occurrences:items.length,source:start.node,blue:a,direct:b});
  }
 }
 assert(m.c.lifecycle.restore(x.root).ok);assert.deepEqual(m.save(),x.root);
 writeZ(out,{groups:groups.size,rows});
 console.log(JSON.stringify({groups:groups.size,inputs:rows.reduce((n,r)=>n+r.blue.summaries.length+r.direct.summaries.length,0),matches:rows.flatMap(r=>[r.blue.stateMatch,r.direct.stateMatch]).reduce((t,x)=>(t[x]=(t[x]||0)+1,t),{}),shapes:[...new Set(rows.map(r=>JSON.stringify([r.blue.shape,r.direct.shape])))]}));
}finally{m.dispose();}
