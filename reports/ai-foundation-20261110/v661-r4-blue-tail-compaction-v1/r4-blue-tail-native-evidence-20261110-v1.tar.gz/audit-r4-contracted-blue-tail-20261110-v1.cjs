'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),Module=require('node:module'),crypto=require('node:crypto');
const {readZ,writeZ,open}=require('./controlled-r3');
const [fixture,output]=process.argv.slice(2),root=readZ(fixture)[9].root;
function load(file,transform){
 const f=path.resolve('randomizer/game/ai',file+'.js'),m=new Module(f,module);
 m.filename=f;m.paths=Module._nodeModulePaths(path.dirname(f));
 m._compile(transform(fs.readFileSync(f,'utf8')),f);return m.exports;
}
function inject(s,needle,add){assert.equal(s.split(needle).length,2,needle);return s.replace(needle,add+'\n'+needle);}
const {createAnalysisPort}=load('analysis-port',s=>inject(inject(s,'      nodeCount += 1;\n      return node;','      globalThis.recordState(node,envelope,barrier,intent,resourceControl);'),'      return child;\n    }\n\n    function knownPostdrawDataView',`      globalThis.recordScan(child, envelope, sourceAction, barrier, intent, resourceControl, source?.envelope, source?.resourceControl);`));
const {searchDecision}=load('decision-search',s=>inject(s,'    const roots = root.legalActions.map(action => {',`    globalThis.recordGraph(nodes, lines);`));
const {createStateValueEvaluator}=require(path.resolve('randomizer/game/ai/state-value'));
const seat='player-white',m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
const recorded=new WeakMap(),states=new WeakMap(),publicEdges=[];
globalThis.recordState=(node,e,barrier,intent,control)=>states.set(node,{e,barrier,intent,control});
const digest=e=>crypto.createHash("sha256").update(JSON.stringify(e)).digest("hex");
globalThis.recordScan=(node,e,source,barrier,intent,control,before,beforeControl)=>{
 states.set(node,{e,source,barrier,intent,control});
 if(source?.family==='choose_card'&&source.target?.choiceId?.startsWith('public:')){
  const h=before?.session?.session?.queue[0];
  if(h?.payload?.options?.mode==='public'){
   publicEdges.push({origin:digest(before),next:digest(e),action:source.target.choiceId,
    step:h.payload.options.selected,status:node.status,goal:beforeControl?.goal?.id||null});
  }
 }
 const ss=e.session?.session,h=ss?.queue[0],mode=h?.payload?.options?.mode,step=h?.payload?.options?.selected;
 if(h?.type==='science_domain_scan_step'||h?.type==='science_domain_scan_action_4'){
  const parent=ss.journal.actions[0]?.action;
  recorded.set(node,{shape:h.type,mode,step,queue:ss.queue.map(x=>x.type),source:parent?.summary,last:source?.target,
   barrier:barrier?.code||null,intent:intent?.goal?.id,control:control?.goal?.id,
   menu:node.legalActions.map(a=>[a.actionId,a.family,a.target]),envelope:e});
 }
};
let evidence,chains=[];
globalThis.recordGraph=(nodes,lines)=>{
 evidence=lines.map((l,i)=>{
  const e=nodes[i],r=recorded.get(e.node);
  return {node:l.node,status:l.status,value:l.value,realization:l.realization,preparationDebt:l.preparationDebt,distance:l.distance,
   scan:r,edges:l.edges.map(x=>({action:x.actionId,to:x.target,equivalent:x.equivalent,cost:x.cost,goal:x.resourcePlan?.goal.id,steps:x.steps,continued:x.continuedBlueTail})),
   alternatives:e.alternatives.map(a=>[a.firstActionId,a.resourcePlan?.goal.id||null]),best:e.best?.actionId,
   nativeMenu:r?null:e.node.legalActions.map(a=>[a.actionId,a.family])};
 });
 for(const line of evidence){
  for(const edge of line.edges){
   if(!edge.continued?.closed)continue;
   const terminal=evidence[edge.to];
   const details=[line,terminal].map(item=>{
    const node=nodes[item.node].node,s=states.get(node);
    return {...item,...s,menu:node.legalActions.map(a=>[a.family,a.target])};
   });
   const direct=line.edges.find(e=>e.action.startsWith('end_turn:'));
   assert(direct);
   chains.push({details,steps:edge.steps,direct:direct.action,directValue:evidence[direct.to].value,directState:states.get(nodes[direct.to].node)});
  }
 }
};
try{
 const n=port.openRoot(),v=createStateValueEvaluator(seat);
 const limit=process.argv[4]==='finite'?256:null;
 const q=searchDecision({port,root:n,evaluate:v,modelKey:v.modelKey,budget:{transitions:limit,nodes:null,frontier:null,milliseconds:null},
 movementPlanning:true,cardPickPlanning:true,resourcePlanning:true,finalMarkPlanning:true,scanPlanning:true,resourceDominance:true,
 moneyCapacityDominance:true,cardTradePruning:true,postMainPruning:true,openingPruning:true,cardChoiceEquivalence:true,planReuse:true});
 if(limit===null)assert(q.complete&&!q.unresolved.length);
 else assert(!q.complete&&q.stopReason==="transition-budget"&&chains.length===0);
 assert.deepEqual(m.save(),root);
 writeZ(output,{root,chains,q:{action:q.actionId,roots:q.roots,complete:q.complete,stop:q.stopReason,diagnostics:q.diagnostics}});
 console.log(q.actionId,q.diagnostics.graphNodes,q.diagnostics.nativeExecutions,'chains',chains.length);
}finally{port.close();m.dispose();}
