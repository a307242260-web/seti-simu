import sys,gzip,json,subprocess
from pathlib import Path
base,new,source,output=sys.argv[1:];here=Path(__file__).resolve().parent;rows={}
for key in json.load(gzip.open(source)):
 pair=[]
 for root in [base,new]:
  raw=subprocess.check_output(['node',str(here/'cold-r4-after-cargo-20261110-v1.cjs'),source,key],cwd=root,text=True)
  pair.append(json.loads(raw))
 a,b=pair
 assert all(a.get(k)==b.get(k) for k in ('actionId','value','roots','edges','nodes','rankGraph')),key
 rows[key]=pair
 print(key,[(x['n'],round(x['ms'])) for x in pair],flush=True)
with open(output,'x') as f:json.dump(rows,f)
