'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),z=require('node:zlib'),crypto=require('node:crypto');
const {open,seat}=require('./native-late-r3');
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
let code=fs.readFileSync(file,'utf8');
function inject(anchor,replacement){assert.equal(code.split(anchor).length,2,anchor);code=code.replace(anchor,replacement);}
inject('      const { before, result } = executeCurrent(requested);',
`      const beforeProfile=globalThis.profileBefore(node,stored,requested,readIdentityState(stored.envelope));
      const startProfile=performance.now();
      const { before, result } = executeCurrent(requested);
      beforeProfile.executeMs=performance.now()-startProfile;
      beforeProfile.beforePhase=before.phase;`);
inject('      if(queuedPreview&&!chongQueuedTemplates.has(chongQueuedKey(stored,queuedPreview)))',
`      globalThis.profileAfter(beforeProfile,child,nodes.get(child));
      if(queuedPreview&&!chongQueuedTemplates.has(chongQueuedKey(stored,queuedPreview)))`);
for(const name of ['provedScan4QuietMoves']){
 const anchor='        '+name+'++;';
 inject(anchor,`        if(['launch','skip'].includes(requested.target?.mode)){
          const evidence=globalThis.profileBefore(node,stored,requested,readIdentityState(stored.envelope));
          evidence.proved=true;
          globalThis.profileAfter(evidence,child,nodes.get(child));
        }
${anchor}`);
}
mod._compile(code,file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const fixture=JSON.parse(z.gunzipSync(fs.readFileSync(process.argv[3])));
const root=fixture[process.argv[4]||'9'].root;
const rows=[],snapshots={};
globalThis.profileBefore=(n,s,a,state)=>{
 const session=s.envelope.session?.session, owner=state.players.players.find(p=>p.id===seat);
 return {family:a.family,target:a.target,payload:a.payload,summary:a.summary,source:n.status,action:a,menu:n.legalActions.map(x=>[x.family,x.target]),
 barrier:s.informationBarrier??null,effect:session?.queue?.[0]?.type??'stable',origin:session?.journal?.actions?.[0]?.action?.family??null,
 control:s.resourceControl, intent:s.intent, flags:[owner.mainActionCompleted,state.turn.roundNumber,s.informationBarrier?.kind],
 wallet:owner.resources,hand:owner.hand.map(c=>c.id),
 envelopes:s.envelope};
};
function save(e){const key=crypto.createHash('sha256').update(JSON.stringify(e)).digest('hex');snapshots[key]??=e;return key;}
globalThis.profileAfter=(p,n,s)=>{
 rows.push({...p,envelopes:save(p.envelopes),nextEnvelope:save(s.envelope),result:n.status,nextBarrier:s.informationBarrier??null,nextMenu:n.legalActions.map(x=>[x.family,x.target]),nextEffect:s.envelope.session?.session?.queue?.[0]?.type??null});
};
const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);assert.equal(rows.filter(r=>!r.proved).length,q.diagnostics.nativeExecutions);
 const group=new Map();
 for(const r of rows){const k=[r.family,r.effect,r.origin,r.nextEffect??r.result].join('|'),g=group.get(k)??{count:0,ms:0,goals:{},targets:{}};g.count++;g.ms+=r.executeMs;const goal=r.control?.goal?.kind??'none';g.goals[goal]=(g.goals[goal]??0)+1;const target=r.summary??JSON.stringify(r.target);g.targets[target]=(g.targets[target]??0)+1;group.set(k,g);}
 const categories=[...group].sort((a,b)=>b[1].ms-a[1].ms);
 fs.writeFileSync(process.argv[2],z.gzipSync(JSON.stringify({rows,snapshots,categories,roots:q.roots.map(r=>[r.actionId,r.value,r.realization,r.preparationDebt]),diagnostics:q.diagnostics})+'\n'),{flag:'wx'});
 console.log(JSON.stringify({count:rows.length,snapshots:Object.keys(snapshots).length,categories:categories.map(([k,{count,ms,goals}])=>[k,count,Math.round(ms*10)/10,goals])}));
}finally{port.close();m.dispose();}

