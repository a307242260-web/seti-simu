'use strict';
const assert=require('node:assert/strict'),{readZ,open,writeZ}=require('./controlled-r3');
const [input,output,reference]=process.argv.slice(2),proof=readZ(input),rows=proof.rows.filter(r=>r.proved);
const m=open(readZ(reference)[9].root),counts={},diff=[];
function normalize(e){
 const s=structuredClone(e),ss=s.session?.session;
 s.committedState=JSON.parse(s.committedState);
 if(ss){
  // Interactive host records undo; the trusted search fork never exposes it.
  ss.undoFrames=[];
  const id=ss.id??ss.sessionId;
  if(id){
   const visit=x=>{
    if(typeof x==='string')return x.replaceAll(String(id),'@session');
    if(Array.isArray(x))return x.map(visit);
    if(x&&typeof x==='object')return Object.fromEntries(Object.entries(x).map(([k,v])=>[k,visit(v)]));
    return x;
   };
   s.session=visit(s.session);
  }
 }
 return s;
}
try{
 for(const [i,r] of rows.entries()){
  const src=proof.snapshots[r.envelopes],target=proof.snapshots[r.nextEnvelope];
  assert(m.c.lifecycle.restore(src).ok);
  assert.deepEqual(normalize(m.save()),normalize(src));
  const d=m.c.inspect().session?.decision;
  const a=m.menu().find(a=>a.actionId===r.action.actionId&&a.actorId===r.action.actorId);
  assert(d&&a);assert.deepEqual(a.target,r.action.target);
  const result=m.c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a});
  assert(result.ok);
  const actual=m.save();
  assert.equal(r.barrier,null);
  assert.equal(r.nextBarrier,null);
  assert.equal(result.irreversibleBarrier??null,null);
  try{assert.deepEqual(normalize(actual),normalize(target));}
  catch(err){diff.push({i,family:r.family,reason:err.message.slice(0,1600)});}
  const native=new Set(m.menu().map(a=>JSON.stringify([a.family,a.target])));
  assert.deepEqual(new Set(r.nextMenu.map(a=>JSON.stringify(a))),native);
  const group=r.target.done?'done':'select';
  counts[group]=(counts[group]??0)+1;
 }
 writeZ(output,{counts,diff,n:rows.length});
 console.log(JSON.stringify({counts,diff:diff.length,examples:diff.slice(0,2)}));
}finally{m.dispose();}
