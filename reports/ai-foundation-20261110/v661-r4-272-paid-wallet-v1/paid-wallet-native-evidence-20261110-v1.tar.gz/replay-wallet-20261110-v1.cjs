'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { open, z, seat } = require('./native-late-r3');
const { evaluateStateValue } = require(path.resolve('randomizer/game/ai/state-value'));
const { collectPlanetLocations } = require(path.resolve('randomizer/solar-system/core'));
const { getLandEnergyCost } = require(path.resolve('randomizer/game/abilities/planet'));
const { sanitizeHiddenInformationObservation } = require(path.resolve('randomizer/game/rule-composition'));
const [fixture, out] = process.argv.slice(2);
const input = JSON.parse(z.gunzipSync(fs.readFileSync(fixture)));
const { root, recipes } = input;
const m = open(root);
const original = m.owner(seat);
const baselineKnown = new Set([...original.selfState.hand, ...original.selfState.reservedCards,
    ...original.publicState.board.publicCards].filter(Boolean).map(c => c.id));
const displays = {
    amiba: original.publicState.board.aliens.amibaTraces.displayedCardIndex,
    chong: original.publicState.board.aliens.chongOffer.displayedCardIndex
};
const analy = [
    { family: 'analyze', target: { kind: 'computer', requiredSlot: 6 } },
    { family: 'choose_target', target: { choiceId: 'trace:1:blue:state-extra' } },
    { family: 'end_turn', target: { kind: 'end-turn' } }
];
// Card landing's fossil probe changes the later ordinary probe sequence number.
const paidLand = [
    ...recipes.land.slice(0, 4),
    ...['alien-chong-9-18', 'card-66-0', 'alien-chong-2-8'].flatMap(card => [
        { family: 'move', target: { rocketId: '@new-probe', deltaX: 0, deltaY: 1 } },
        { family: 'choose_payment', target: { choiceId: card } }
    ]),
    recipes.land[10],
    { family: 'choose_target', target: { rocketId: '@new-probe', planetId: 'neptune',
        landTarget: { type: 'satellite', satelliteId: 'triton' } } },
    ...recipes.land.slice(12)
];
const paidLandWithExtraTrade = [
    ...paidLand.slice(0, 10),
    paidLand[0],
    ...['card-67-0', 'alien-chong-6-16'].map(id =>
        ({ family: 'choose_payment', target: { kind: 'discard-hand-card', cardInstanceId: id, select: true } })),
    paidLand[3],
    ...paidLand.slice(10)
];
const paidLandAligned = [
    ...paidLandWithExtraTrade.slice(0, 14),
    { family: 'move', target: { rocketId: '@new-probe', deltaX: -1, deltaY: 0 } },
    { family: 'choose_payment', target: { choiceId: 'energy' } },
    ...paidLandWithExtraTrade.slice(14)
];
function sameFields(fields, actual, probe) {
    return Object.entries(fields).every(([k, value]) =>
        value && typeof value === 'object' ? sameFields(value, actual?.[k], probe)
            : (value === '@new-probe' ? probe : value) === actual?.[k]);
}
const routes = [
    ['triton', recipes.triton1, recipes.triton2, recipes.triton3, recipes.triton4, recipes.triton5],
    ['paid-blue4-orange1', recipes.scan1, recipes.paid2, recipes.paid3, recipes.orange, paidLand],
    ['paid-analyze-orange1', recipes.scan1, recipes.paid2, analy, recipes.orange, paidLand],
    ['paid-blue4-no-deposit', recipes.scan1, recipes.paid2, [...recipes.paid3.slice(0, 4), recipes.paid3.at(-1)], recipes.orange, paidLand],
    ['paid-analyze-then-extra-trade', recipes.scan1, recipes.paid2, analy, recipes.orange, paidLandWithExtraTrade],
    ['paid-orange1-land', recipes.scan1, recipes.paid2, recipes.orange, paidLand, analy],
    ['paid-orange1-early-extra-trade', recipes.scan1, recipes.paid2, recipes.orange, paidLandWithExtraTrade, analy],
    ['paid-orange1-early-aligned', recipes.scan1, recipes.paid2, recipes.orange, paidLandAligned, analy]
];

function run([label, ...turns]) {
    m.restore(root);
    const known = new Set(baselineKnown), rows = [];
    function snapshot() {
        const obs = sanitizeHiddenInformationObservation(original, m.owner(seat), {code: 'hidden_card_reveal'}, known);
        const value = evaluateStateValue(obs, seat);
        return {
            facts: m.facts(), value: value.total, components: value.components, end: m.save(),
            opaque: obs.selfState.hand.filter(c => c.hidden).length
        };
    }
    const rootTurn = m.facts().turn;
    for (const [i, choices] of turns.entries()) {
        assert.equal(m.facts().turn, rootTurn + i);
        assert(m.state().turn.activePlayerIds.every(id => id === seat || m.state().turn.passedPlayerIds.includes(id)));
        const before = m.save(), actions = [];
        const ship = m.facts().probes.filter(p => !p.kind);
        if ([paidLand, paidLandWithExtraTrade, paidLandAligned].includes(choices)) assert.equal(ship.length, 1);
        for (const [j, wanted] of choices.entries()) {
            const legal = m.menu();
            const action = legal.find(a => a.actorId === seat && a.family === wanted.family &&
                (wanted.actionId ? a.actionId === wanted.actionId :
                    sameFields(wanted.target, a.target, ship[0]?.id)));
            if (!action) {
                // An exact recorded selection may have been replaced by a different legal benefit.
                // No substitution is made after the fact.
                const state = m.state(), loc = collectPlanetLocations(state.solarSystem).find(p => p.planetId === 'neptune');
                return { label, turns: rows, blocked: { turn: i + 1, index: j, wanted, legal, actions,
                    target: { x: loc.x, y: loc.y, energy: getLandEnergyCost(state, 'neptune', m.player()) },
                    ...snapshot() } };
            }
            assert(!action.target?.fossilId);
            for (const obj of [action.target, action.payload]) {
                if (obj?.cardInstanceId) assert(known.has(obj.cardInstanceId), action.summary);
                for (const id of [...obj?.cardIds || [], ...obj?.cardInstanceIds || []]) assert(known.has(id), action.summary);
            }
            const hand = new Set(m.player().hand.map(c => c.id));
            const display = String(action.target?.choiceId).match(/^(amiba|chong):display:(\d+)$/);
            if (display) assert.equal(Number(display[2]), displays[display[1]]);
            actions.push(m.apply(action));
            if (display) {
                const gained = m.player().hand.filter(c => !hand.has(c.id));
                assert.equal(gained.length, 1);
                known.add(gained[0].id);
            }
        }
        const after = snapshot();
        assert.equal(after.facts.turn, rootTurn + i + 1);
        assert.equal(after.end.session, null);
        if (i === 1) {
            const ref = input[label === 'triton' ? 'triton2Reference' : 'paid2Reference'];
            assert.deepEqual(before, ref.before, label + ' before turn 2');
            assert.deepEqual(after.end, ref.after, label + ' after turn 2');
        }
        rows.push({ turn: i + 1, actions, ...after });
    }
    return { label, turns: rows };
}

try {
    const rows = routes.map(run);
    assert.deepEqual(routes.map(run), rows);
    m.restore(root);
    assert.deepEqual(m.save(), root);
    fs.writeFileSync(out, z.gzipSync(JSON.stringify({ rows, rootExact: true, repeatedStateAndRngExact: true }) + '\n'), { flag: 'wx' });
    for (const row of rows) {
        console.log(row.label, row.turns.map(r => [r.value, r.facts.wallet.score, r.facts.final,
            ['credits','energy','availableData','handSize','publicity'].map(k=>r.facts.wallet[k]), r.facts.computer.length, r.opaque]));
        if (row.blocked) console.log('Blocked:', row.blocked.turn, row.blocked.index, row.blocked.wanted,
            row.blocked.legal.map(a => [a.family, a.summary]));
    }
} finally {
    m.dispose();
}
