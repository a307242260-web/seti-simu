'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const [rootFile,controlFile,variantsFile,out]=process.argv.slice(2),load=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const root=load(rootFile).rows[0].root,control=load(controlFile),[scan,charge]=control.teacherTurns.map(t=>t.actions);
const model=open(root),rows=[];
function moves(label,actions,recorded){
 model.restore(root);
 const inputs=[];
 for(const a of actions){inputs.push(model.apply(a));}
 const before=model.save(),p=createAnalysisPort({composition:model.c,seatId:seat,maxCacheEntries:0});
 try{
  const n=p.openRoot();p.setMovementPlanning(true);const s=p.goalMovementSpec(n);
  const selected=n.legalActions.find(a=>a.actionId===s?.selectedActionId),teacher=n.legalActions.find(a=>a.target.choiceId===recorded.target.choiceId);
  assert(teacher);assert.deepEqual(model.save(),before);
  rows.push({label,inputs,before,facts:model.facts(),selected,teacher,policy:s,legal:n.legalActions});
 }finally{p.close();}
}
try{
 const free=scan.findIndex(a=>a.target.choiceId==='scan4:move:7:out');
 moves('teacher-free-move',scan.slice(0,free),scan[free]);
 const v=load(variantsFile).variants.find(r=>r.label==='teacher-scan-with-free-move-then-card');
 model.restore(v.snapshots.at(-1).envelope);
 const before=model.save(),facts=model.facts();
 const steps=[model.play('chong_2.webp')],choices=model.menu();
 const same=choices.find(a=>a.target.choiceId===charge[1].target.choiceId);
 if(same){steps.push(model.apply(same));steps.push(model.act('end_turn'));}
 rows.push({label:'reverse-charge',before,facts,steps,sameFossil:Boolean(same),choices,end:model.save(),after:model.facts()});
 model.restore(root);assert.deepEqual(model.save(),root);
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({rows})+'\n'),{flag:'wx'});
 for(const x of rows)console.log(JSON.stringify({label:x.label,policy:x.policy?.chosenGoal,selected:x.selected?.summary,teacher:x.teacher?.summary,
  sameFossil:x.sameFossil,choices:x.choices?.map(a=>a.summary),wallet:x.after?.wallet,ship:x.facts.probes.find(p=>p.id===7)?.sectorY}));
}finally{model.dispose();}
