'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const [fixture,teacher,out]=process.argv.slice(2),read=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const root=read(fixture).rows[0].root,m=open(root),steps=read(teacher).teacherTurns[0].actions,results=[];
try{
 for(const a of steps){
  const before=m.save(),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
  try{
   const n=p.openRoot();
   p.setMovementPlanning(true);p.setCardPickPlanning(true);p.setResourcePlanning(true);p.setDecisionPlanning({scanPlanning:true,finalMarkPlanning:true});
   const resource=p.resourceSpec(n),pick=p.cardPickSpec(n),local=p.localDecisionSpec(n),movement=p.goalMovementSpec(n);
   const plans=resource?.plans?.map(x=>({goal:x.goal.id,kind:x.goal.kind,first:x.firstActionId}));
   const matching=plans?.filter(q=>q.first===a.actionId)||[];
   const kept=[resource,pick,local,movement].every(x=>!x?.retainedActionIds||x.retainedActionIds.includes(a.actionId));
   const raw=n.legalActions.find(x=>x.actionId===a.actionId);assert(raw);
   results.push({step:results.length,action:a.summary,actionId:a.actionId,planStarts:matching,keptInDirectIntersection:kept,
    policies:[resource,pick,local,movement].map(x=>x&&({rule:x.policy,selected:x.selectedActionId,goal:x.goal?.id||x.chosenGoal?.id,
      retained:x.retainedActionIds?.map(id=>n.legalActions.find(x=>x.actionId===id)?.summary||id)})),
    goals:plans,rotation:m.state().solarSystem.rotation.rotationCount});
   assert.deepEqual(m.save(),before);
  }finally{p.close();}
  m.apply(a);
 }
 assert.deepEqual(m.save(),read(teacher).teacherTurns[0].envelope);
 fs.writeFileSync(out,JSON.stringify({results},null,2)+'\n',{flag:'wx'});
 for(const r of results)console.log(JSON.stringify([r.step,r.action,r.keptInDirectIntersection,r.planStarts.map(x=>x.goal),r.policies.map(x=>x&&[x.selected,x.goal])]));
}finally{m.dispose();}
