'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const [rootFile,controlFile,out]=process.argv.slice(2),load=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const {createStateValueEvaluator}=require(path.resolve('randomizer/game/ai/state-value')),evaluate=createStateValueEvaluator(seat);
const solar=require(path.resolve('randomizer/solar-system/core'));
const root=load(rootFile).rows[0].root,control=load(controlFile),[scan,charge,land]=control.teacherTurns.map(t=>t.actions);
assert.equal(scan.length,14);assert.equal(charge.length,3);assert.equal(land.length,19);
const model=open(root),variants=[];
function run(label,{data=true,scanned=false,skip=false,paidMove=false,charged=false}={}){
 model.restore(root);
 const actions=[],snapshots=[];
 const record=(stage)=>snapshots.push({stage,facts:model.facts(),envelope:model.save(),
   v:evaluate(model.owner(seat)),legal:model.menu().map(a=>[a.family,a.actionId,a.summary,a.target])});
 const apply=a=>{actions.push(model.apply(a));return actions.at(-1);};
 const available=a=>model.menu().find(b=>b.actionId===a.actionId&&b.actorId===a.actorId&&b.family===a.family);
 if(data)for(const a of scan.slice(0,8))apply(a);
 if(scanned)for(const a of scan.slice(8)){
  if(skip&&a.target.choiceId==='scan4:move:7:out'){
   const alt=model.menu().find(x=>x.target.choiceId==='scan4:skip');
   assert(alt);apply(alt);
  }else{
   const same=available(a);
   if(!same){
    snapshots.push({stage:'teacher-scan-action-changed',needed:a,legal:model.menu()});
    break;
   }
   apply(a);
  }
 }
 if(paidMove){
  const a=model.menu().find(a=>a.family==='move'&&a.target.rocketId===7&&a.target.deltaX===0&&a.target.deltaY===1);
  assert(a);apply(a);
  const pay=model.menu().find(a=>a.target?.kind==='move-payment'&&a.target?.payment==='energy')
   ||model.menu().find(a=>a.summary==='消耗 1 能量');
  assert(pay);apply(pay);
 }
 if(charged)for(const a of charge)apply(a);
 assert.equal(model.state().turn.currentPlayerId,seat);
 record('before-card');
 const saturn=solar.collectPlanetLocations(model.state().solarSystem).find(p=>p.planetId==='saturn');
 const card=model.menu().find(a=>a.family==='play_card'&&a.target.cardInstanceId===land[0].target.cardInstanceId);assert(card,label);apply(card);
 record('after-card');
 const target=available(land[1]);
 if(target){
  apply(target);record('landed');
  for(const [i,a] of land.slice(2).entries()){
   const exact=available(a);
   if(!exact){snapshots.push({stage:'teacher-landing-action-changed',index:i+2,needed:a,legal:model.menu()});break;}
   apply(exact);
  }
 }
 record('stop');
 const before=snapshots[0].facts,after=snapshots.at(-1).facts;
 variants.push({label,saturn,enceladusLegal:Boolean(target),actions,snapshots,points:[before.wallet.score,after.wallet.score],turn:after.turn});
}
try{
 run('root-immediate-no-move',{data:false});
 run('teacher-data-immediate-no-move');
 run('root-paid-move-then-card',{data:false,paidMove:true});
 run('teacher-data-paid-move-then-card',{paidMove:true});
 run('teacher-scan-with-free-move-then-card',{scanned:true});
 run('teacher-scan-without-free-move-then-card',{scanned:true,skip:true});
 run('teacher-scan-with-free-move-and-charge-then-card',{scanned:true,charged:true});
 assert.deepEqual(variants.at(-1).snapshots.at(-1).envelope,control.teacherTurns[2].envelope);
 model.restore(root);assert.deepEqual(model.save(),root);
 const result={variants,authoritativeRootExact:true,otherSeatsAlreadyPassed:true,newSearches:0};
 fs.writeFileSync(out,z.gzipSync(JSON.stringify(result)+'\n'),{flag:'wx'});
 for(const v of variants){
  console.log(JSON.stringify({label:v.label,inputs:v.actions.length,saturn:[v.saturn.x,v.saturn.y],enceladusLegal:v.enceladusLegal,
   snapshots:v.snapshots.map(s=>s.facts?[s.stage,s.facts.turn,s.facts.wallet,s.v,s.facts.probes.find(p=>p.id===7)?.sectorY]:[s.stage,s.index,s.needed.summary,s.legal.map(a=>a.summary)])}));
 }
}finally{model.dispose();}
