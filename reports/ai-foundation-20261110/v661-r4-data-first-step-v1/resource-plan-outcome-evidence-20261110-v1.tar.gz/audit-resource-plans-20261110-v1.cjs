'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),Module=require('node:module'),path=require('node:path');
const hook=Module._extensions['.js'], rows=[], specTimes=[];
const group=(o,keys)=>Object.fromEntries(keys.filter(k=>Object.hasOwn(o,k)).map(k=>[k,o[k]]));
globalThis.capturePlan=(node,stored,state,plan,out,ms)=>{
 const owner=state.players.players.find(p=>p.id==='player-white');
 const input=out.prefixes.map(({node,action})=>({id:action.actionId,family:action.family,target:action.target,phase:action.phase}));
 rows.push({root:stored.serial,status:node.status,bound:!!stored.resourceControl,boundary:node.boundary,ownerMain:owner.mainActionCompleted,
  wallet:owner.resources,goal:plan.goal,operation:plan.operation,planId:plan.id,mode:plan.mode,
  endStatus:out.node.status,endBoundary:out.node.boundary,endGoalStatus:out.goalStatus,reason:out.reason,
  fallback:out.fallbackReason,stop:out.stopReason,complete:out.complete,submissions:out.submissions,newSubmissions:out.newSubmissions,
  sharedPath:out.sharedPath,inputs:input,ms});
};
globalThis.captureSpec=(node,stored,out,ms)=>{specTimes.push({root:stored.serial,status:node.status,alreadyBound:!!stored.resourceControl,
 plans:out?.plans.map(p=>({id:p.id,kind:p.goal.kind,firstActionId:p.firstActionId}))||[],ms})};
Module._extensions['.js']=(mod,file)=>{
 if(!file.endsWith('/randomizer/game/ai/analysis-port.js'))return hook(mod,file);
 let s=fs.readFileSync(file,'utf8');
 for(const [mark,alt] of [
  ['    function expandResourcePlan(node,plan,hasCapacity) {',`    function expandResourcePlan(node,plan,hasCapacity) {
      const at=performance.now(),out=expandResourcePlanUnobserved(node,plan,hasCapacity),ms=performance.now()-at,stored=nodes.get(node);
      globalThis.capturePlan(node,stored,readPlanningState(stored),plan,out,ms);return out;
    }
    function expandResourcePlanUnobserved(node,plan,hasCapacity) {`],
  ['    function resourceSpec(node) {',`    function resourceSpec(node) {
      const at=performance.now(),out=resourceSpecUnobserved(node),ms=performance.now()-at;
      globalThis.captureSpec(node,nodes.get(node),out,ms);return out;
    }
    function resourceSpecUnobserved(node) {`]
 ]){
  assert.equal(s.split(mark).length,2);s=s.replace(mark,alt);
 }
 mod._compile(s,file);
};
const {open,seat}=require(process.argv[2]),{createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const {checkpoint:root}=JSON.parse(fs.readFileSync(process.argv[3])),m=open(root);
const port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 fs.writeFileSync(process.argv[4],require('node:zlib').gzipSync(JSON.stringify({rows,specTimes,q})),{flag:'wx'});
 console.log(JSON.stringify({rows:rows.length,specs:specTimes.length,choice:q.actionId,value:q.value}));
}finally{port.close();m.dispose();}
