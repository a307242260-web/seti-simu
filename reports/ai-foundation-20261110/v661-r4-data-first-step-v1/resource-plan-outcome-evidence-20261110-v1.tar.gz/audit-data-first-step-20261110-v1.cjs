'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),Module=require('node:module');
const hook=Module._extensions['.js'], counts={}, audit={hits:0,rootMismatch:0,otherPlans:0};
globalThis.auditFirst=(kind,cached,old)=>{
 assert.deepEqual(cached,old);
 audit.hits++;counts[kind]=(counts[kind]||0)+1;
 return cached;
};
globalThis.auditFirstMiss=hasPlan=>{
 if(hasPlan)audit.rootMismatch++;else audit.otherPlans++;
};
Module._extensions['.js']=(mod,file)=>{
 if(!file.endsWith('/randomizer/game/ai/analysis-port.js'))return hook(mod,file);
 const s=fs.readFileSync(file,'utf8'),mark=':forced&&firstStep||resourceStep(current,plan.goal,operation);';
 assert.equal(s.split(mark).length,2);
 mod._compile(s.replace(mark,`:forced&&firstStep
           ?globalThis.auditFirst(plan.goal.kind,firstStep,resourceStep(current,plan.goal,operation))
           :(forced&&globalThis.auditFirstMiss(Boolean(first)),resourceStep(current,plan.goal,operation));`),file);
};
const [trace,...args]=process.argv.slice(2);
process.argv=[process.argv[0],trace,...args];
require(trace);
assert.equal(audit.rootMismatch,0);
console.log(JSON.stringify({...audit,counts}));
