from collections import Counter, defaultdict
from pathlib import Path
import gzip
import json
import sys

root = Path(sys.argv[1])
output = Path(sys.argv[2])
results = {}
for file in sorted(root.glob("outcome-*-20261110-v1.json.gz")):
    name = file.name.removeprefix("outcome-").removesuffix("-20261110-v1.json.gz")
    data = json.load(gzip.open(file))
    rows, q = data["rows"], data["q"]
    lines = {line["node"]: line for line in q["lines"]}
    assert q["complete"] and q["unresolved"] == []
    counts, local, global_gap = defaultdict(Counter), defaultdict(Counter), defaultdict(Counter)
    cuts = set()
    for row in rows:
        key = row.get("endGoalStatus") or row.get("fallback")
        for c in (counts[key], counts["total"]):
            c["plans"] += 1
            c["logicalInputs"] += row["submissions"]
    for idx, line in lines.items():
        for edge_idx, edge in enumerate(line["edges"]):
            plan = edge.get("resourcePlan")
            if not plan or plan["goal"]["kind"] not in {"blue-data", "income", "computer-prefix"}:
                continue
            child = lines[edge["target"]]
            best = line["value"]
            assert best is None or child["value"] is None or best >= child["value"]
            label = ("root" if idx == 0 else "strictly-lower" if child["value"] is not None and best > child["value"]
                     else "sole-alternative" if len(line["edges"]) == 1 else "shares-best-value")
            if label == "strictly-lower":
                cuts.add((idx, edge_idx))
            if idx != 0:
                assert best <= q["value"]
                scope = "below-root-best" if best < q["value"] else "can-match-root-best"
                for c in (global_gap["all/"+scope], global_gap[plan["goal"]["kind"]+"/"+scope]):
                    c["plans"] += 1
                    c["logicalInputs"] += edge["cost"]
                    if len(line["edges"]) == 1:
                        c["solePlans"] += 1
                        c["soleLogicalInputs"] += edge["cost"]
            for c in (local["all/"+label], local[plan["goal"]["kind"]+"/"+label]):
                c["plans"] += 1
                c["logicalInputs"] += edge["cost"]
    def reach(cuts):
        seen, prefix, stack = set(), set(), [0]
        while stack:
            idx = stack.pop()
            if idx in seen:
                continue
            seen.add(idx)
            for edge_idx, edge in enumerate(lines[idx]["edges"]):
                if (idx, edge_idx) in cuts:
                    continue
                prefix.update(edge.get("sharedPath", []))
                stack.append(edge["target"])
        return seen, prefix
    a, p = reach(set())
    b, t = reach(cuts)
    assert b <= a and t <= p
    results[name] = {
        "outcomes": counts, "perKind": dict(Counter(row["goal"]["kind"] for row in rows)),
        "dataEdgeLocalValueComparison": local,
        "dataEdgeSourceVsRootBest": global_gap,
        "optimisticOfflineOnly": {"strictCuts": len(cuts), "reachableLinesBefore": len(a),
                                  "reachableLinesAfter": len(b), "uniqueResourcePrefixEdgesBefore": len(p),
                                  "uniqueResourcePrefixEdgesAfter": len(t)},
    }
    print(name, dict(local), results[name]["optimisticOfflineOnly"])
with output.open("x") as fh:
    json.dump(results, fh, ensure_ascii=False, indent=2, sort_keys=True)
    fh.write("\n")
