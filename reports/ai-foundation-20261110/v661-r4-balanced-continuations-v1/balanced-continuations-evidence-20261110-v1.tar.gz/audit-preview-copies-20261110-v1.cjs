'use strict';
const fs=require('node:fs'),Module=require('node:module'),assert=require('node:assert/strict');
const js=Module._extensions['.js'];
Module._extensions['.js']=function(mod,file){
 if(!file.endsWith('/randomizer/game/effects/residual-domain-session.js'))return js(mod,file);
 let src=fs.readFileSync(file,'utf8');
 const fields={
  previewPlainPinkTrace:['owner.reservedCards','source.aliens'],
  previewQuietEndHandoffs:['owner.reservedCards','root.aliens','root.finalScoring'],
 };
 for(const [name,list] of Object.entries(fields)){
  const start=src.indexOf('  function '+name+'('),end=src.indexOf('\n  function ',start+12);assert(start>=0&&end>start);
  let body=src.slice(start,end);
  for(const term of list){
   const needle='copyForkData('+term+')';assert(body.includes(needle));
   body=body.replace(needle,'auditCopy('+term+','+JSON.stringify(name+':'+term)+')');
  }
  src=src.slice(0,start)+body+src.slice(end);
 }
 src=src.replace('  const DOMAIN_ID',`
 const copyAudit={};
 process.on('exit',()=>console.error('COPY_AUDIT '+JSON.stringify(copyAudit)));
 function auditCopy(value,label){
  const assert=require('node:assert/strict'),actual=copyForkData(value),expected=structuredClone(value);
  assert.deepEqual(actual,expected);assert.equal(JSON.stringify(actual),JSON.stringify(expected));
  const visited=new WeakSet();
  function detached(a,b){
   if(!a||typeof a!=='object'||visited.has(a))return;
   visited.add(a);assert.notEqual(a,b);for(const key of Object.keys(a))detached(a[key],b[key]);
  }
  detached(value,actual);
  copyAudit[label]=(copyAudit[label]||0)+1;return actual;
 }
  const DOMAIN_ID`);
 mod._compile(src,file);
};
