'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{open,z,seat}=require('./native-compact-20261110-v1.cjs');
const [file,out]=process.argv.slice(2),{root,paths}=JSON.parse(z.gunzipSync(fs.readFileSync(file))),m=open(root);
const rows={},values=require(path.resolve('randomizer/game/ai/state-value'));
try{
 for(const [label,stages] of Object.entries(paths)){
  let inputs=0, current=[];
  for(let repeat=0;repeat<2;repeat++){
   m.restore(root);inputs=0;const observed=[];
   let source=root;
   for(const row of stages){
    m.restore(source);
    for(const input of row.inputs){assert.equal(input.actorId,seat);assert.notEqual(input.family,'pass');m.apply(input);inputs++;}
    const end=m.save();
    try{assert.deepEqual(end,row.end);}catch{
      const a=end.session?.session,b=row.end.session?.session;
      console.error(JSON.stringify({label,inputs,expectedSession:[b?.sessionId,b?.revision,row.end.session?.replayCursor],actualSession:[a?.sessionId,a?.revision,end.session?.replayCursor],committedExact:end.committedState===row.end.committedState,workingExact:JSON.stringify(a?.workingState)===JSON.stringify(b?.workingState)}));
      throw Error('BALANCED_REPLAY_CHECKPOINT_MISMATCH');
    }
    source=row.end;
    observed.push(values.evaluateStateValue(m.owner(seat),seat));
    assert(m.state().turn.activePlayerIds.every(id=>id===seat||m.state().turn.passedPlayerIds.includes(id)));
    if(row.blocked)assert(m.menu().some(a=>a.summary===row.blocked.action&&a.actorId===seat));
   }
   if(repeat===0)current=observed;else assert.deepEqual(observed,current);
  }
  rows[label]={inputs,ends:stages.length,lastTurn:m.state().turn.turnNumber,checkpointMatches:true,current};
 }
 m.restore(root);assert.deepEqual(m.save(),root);
 fs.writeFileSync(out,JSON.stringify({rows,rootAndRngExact:true},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(rows));
}finally{m.dispose();}
