'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {open,z,seat}=require('./native-compact-20261110-v1.cjs');
const [file,out]=process.argv.slice(2);
const {root,base,candidate}=JSON.parse(z.gunzipSync(fs.readFileSync(file))),m=open(root);
const rows={};
try{
 for(const [mode,stages] of Object.entries({base,candidate})){
  const audits=[];
  for(let repeat=0;repeat<2;repeat++){
   m.restore(root);
   let n=0,ms=0,inputs=0;
   const originalCards=new Set([...m.player().hand,...m.player().reservedCards,...m.state().cards.publicCards].filter(Boolean).map(c=>c.id));
   for(const stage of stages){
    for(const {a,n:usage,ms:elapsed} of stage.entries){
     assert(a.actorId===seat&&usage<=256&&elapsed<=600);
     assert(a.family!=='pass'&&a.target?.source!=='blind'&&!a.target?.fossilId);
     if(mode==='candidate')for(const id of [a.target?.cardInstanceId,...(a.target?.cardIds||[])].filter(Boolean))assert(originalCards.has(id));
     m.apply(a);n=Math.max(n,usage);ms=Math.max(ms,elapsed);inputs++;
    }
    assert.equal(m.state().turn.turnNumber,stage.endTurn);assert.deepEqual(m.save(),stage.end);
   }
   audits.push({inputs,maxNative:n,maxMs:ms,endpoint:m.facts()});
  }
  assert.deepEqual(audits[0],audits[1]);rows[mode]=audits[0];
 }
 m.restore(root);assert.deepEqual(m.save(),root);
 fs.writeFileSync(out,JSON.stringify({rows,rootAndRngExact:true},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(Object.fromEntries(Object.entries(rows).map(([k,r])=>[k,[r.inputs,r.maxNative,r.maxMs,r.endpoint.wallet.score,r.endpoint.final]]))));
}finally{m.dispose();}
