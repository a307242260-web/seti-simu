'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require('./native-compact-20261110-v1.cjs');
const [file,out]=process.argv.slice(2),{checkpoint:root}=JSON.parse(fs.readFileSync(file)),m=open(root);
const {evaluateStateValue}=require(path.resolve('randomizer/game/ai/state-value'));
const start=m.state().turn.turnNumber,known=new Set([...m.player().hand,...m.player().reservedCards,...m.state().cards.publicCards].filter(Boolean).map(c=>c.id)),entries=[];
let continuation=null,blocked=null;
const alien=m.owner(seat).publicState.board.aliens;
const knownDisplays={amiba:alien.amibaTraces?.displayedCardIndex,chong:alien.chongOffer?.displayedCardIndex};
try{
 for(let i=0;i<24&&m.state().turn.turnNumber===start;i++){
  const r=m.automatic(continuation);
  const {a,n,ms,value,complete,checkpoint}=r;
  assert(complete&&a.actorId===seat);
  const ids=[a.target?.cardInstanceId,...(a.target?.cardIds||[])].filter(Boolean);
  const display=/^(amiba|chong):display:(\d+)$/.exec(a.target?.choiceId||'');
  if(a.family==='pass'||n>256||ms>600||display&&Number(display[2])!==knownDisplays[display[1]]||a.target?.fossilId||a.target?.source==='blind'||ids.some(id=>!known.has(id))){
   blocked={action:a.summary,n,ms,ids,target:a.target};break;
  }
  const held=new Set(m.player().hand.map(c=>c.id));
  m.apply(a);continuation=checkpoint;
  if(display){
    const gained=m.player().hand.filter(c=>!held.has(c.id));assert.equal(gained.length,1);
    known.add(gained[0].id);knownDisplays[display[1]]=null;
  }
  entries.push({a,n,ms,value});
 }
 const end=m.save(),endTurn=m.state().turn.turnNumber;
 if(!blocked){assert.equal(endTurn,start+1);assert.equal(end.session,null);}
 const result={entries,end,endTurn,blocked,facts:m.facts(),value:evaluateStateValue(m.owner(seat),seat).total};
 m.restore(root);assert.deepEqual(m.save(),root);
 fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({entries:entries.map(x=>[x.a.summary,x.n,x.ms,x.value]),endTurn,blocked,total:result.value,facts:result.facts.wallet}));
}finally{m.dispose();}
