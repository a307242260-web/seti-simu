'use strict';
const path=require('node:path'),fs=require('node:fs'),assert=require('node:assert/strict');
const {open,z,seat}=require('./native-compact-20261110-v1.cjs');
const [startFile,priorFile,out]=process.argv.slice(2);
const read=p=>JSON.parse(z.gunzipSync(fs.readFileSync(p)));
const {root:original}=read(startFile),prior=read(priorFile);
const previous=prior.rows.find(r=>r.label==='paid-blue4-orange1'),root=previous.turns[1].end,m=open(original),obs=m.owner(seat);
const known=new Set([...obs.selfState.hand,...obs.selfState.reservedCards,...obs.publicState.board.publicCards].filter(Boolean).map(c=>c.id));
const seen=new Map(previous.turns[1].facts.hand);
for(const [id,card] of seen)if(!known.has(id)){
 assert(['chong_9.webp','amiba_9.webp'].includes(card));
 assert.equal(+card.match(/_(\d+)\.webp/)[1],card.startsWith('chong')
  ?obs.publicState.board.aliens.chongOffer.displayedCardIndex:obs.publicState.board.aliens.amibaTraces.displayedCardIndex);
 known.add(id);
}
const {getProbeRouteRequirements}=require(path.resolve('randomizer/game/production-kernel'));
const values=require(path.resolve('randomizer/game/ai/state-value'));
const {sanitizeHiddenInformationObservation}=require(path.resolve('randomizer/game/rule-composition'));
const copy=o=>JSON.parse(JSON.stringify(o));
const labels=['blue-first','orange-four-steps-then-analyze','analyze-then-orange-four-steps','orange-blue-four-steps','blue-first-then-analyze','analyze-blue-first','orange-quoted-pay'];
function run(label){
 m.restore(root);const turns=[],steps=[];let route=null,blocked=null;
 function take(a){
  assert.equal(a.actorId,seat);
  assert(!a.target?.fossilId);
  for(const id of [a.target?.cardInstanceId,a.payload?.cardInstanceId,...(a.target?.cardIds||[]),...(a.payload?.cardIds||[])].filter(Boolean))
   assert(known.has(id),id);
  steps.push(m.apply(a));
 }
 function act(f,fn=()=>true){
  const a=m.menu().find(a=>a.family===f&&fn(a));
  assert(a,JSON.stringify([label,f,m.facts().wallet,m.menu().map(x=>[x.family,x.summary,x.target])]).slice(0,3000));take(a);
 }
 function end(label){
  assert(!m.save().session,JSON.stringify([label,m.menu().map(a=>[a.family,a.summary,a.target])]).slice(0,2300));
  assert(m.state().turn.activePlayerIds.every(id=>id===seat||m.state().turn.passedPlayerIds.includes(id)));
  const v=values.evaluateStateValue(sanitizeHiddenInformationObservation(obs,m.owner(seat),{code:'hidden_card_reveal'},known),seat);
  turns.push({label,actions:steps.splice(0),facts:m.facts(),value:v,checkpoint:m.save()});
 }
 function directOrange(){
  act('research_tech');act('choose_target',a=>a.target.tileId==='orange1');act('choose_card',a=>a.target.cardInstanceId==='card-66-0');act('end_turn');
  end('正常科研橙1');
 }
 function blue4(){
  act('research_tech');act('choose_target',a=>a.target.tileId==='blue4'&&a.target.blueSlot===3);
  act('accept_optional_effect',a=>a.target.ruleId==='amiba1-blue-tech'&&a.target.choiceId.startsWith('confirm:'));
  if(m.save().session)act('choose_target',a=>a.target.slotId==='blue_1');
 }
 function analyze(){
  act('analyze');act('choose_target',a=>a.target.choiceId==='trace:1:blue:state-extra');act('end_turn');
  if(m.save().session)act('accept_optional_effect',a=>a.target.choiceId.startsWith('skip:chong_task:'));
  end('免电分析');
 }
 function powerTrade(){
  act('quick_trade',a=>a.target.tradeId==='credits-for-energy');
 }
 function handTrade(){
  act('quick_trade',a=>a.target.tradeId==='cards-for-energy');
  const ids=label==='orange-quoted-pay'?['alien-amiba-9-20','alien-chong-6-16']:['alien-chong-8-12','alien-amiba-9-20'];
  for(const id of ids)act('choose_payment',a=>a.target.cardInstanceId===id);
  act('choose_payment',a=>a.target.confirm);
 }
 function paidTriton({tradeHand}){
  const s=m.state();
  route=getProbeRouteRequirements(s,seat)?.candidates.find(c=>c.endpointTarget?.satelliteId==='triton'&&c.rocketId);
  assert(route&&route.endpointFacts.cost.energy===3);
  powerTrade();if(tradeHand)handTrade();
  const pay=['alien-chong-2-8','alien-chong-9-18','card-66-0','alien-chong-4-14'];
  assert(route.path.length<=pay.length);
  for(const [i,dir] of route.path.entries()){
    act('move',a=>a.target.rocketId===route.rocketId&&a.target.deltaX===dir.deltaX&&a.target.deltaY===dir.deltaY);
    act('choose_payment',a=>a.target.choiceId===pay[i]);
  }
  act('land');act('choose_target',a=>a.target.landTarget?.satelliteId==='triton');act('end_turn');
  end('正常登陆海卫一');
 }
 if(label==='blue-first'||label==='blue-first-then-analyze'){
  for(const t of previous.turns.slice(2)){
    for(const a of t.actions)take(a);end('原路线 '+t.turn);
    assert.deepEqual(m.save(),t.end);
  }
  if(label.endsWith('-analyze'))analyze();
 }else if(label==='orange-four-steps-then-analyze'||label==='analyze-then-orange-four-steps'){
  if(label.startsWith('analyze'))analyze();
  directOrange();paidTriton({tradeHand:true});
  if(label.endsWith('-analyze'))analyze();
 }else if(label==='orange-blue-four-steps'){
  directOrange();
  for(const id of ['alien-chong-8-12','alien-amiba-9-20'])act('card_corner',a=>a.target.cardInstanceId===id&&a.payload.kind==='resource');
  blue4();
  act('place_data');act('choose_target',a=>a.target.blueSlot===3);
  act('end_turn');end('两张已知宣传角标再科研蓝4');
  paidTriton({tradeHand:false});
 }else if(label==='orange-quoted-pay'){
  directOrange();paidTriton({tradeHand:true});
 }else if(label==='analyze-blue-first'){
  analyze();blue4();act('end_turn');end('先分析再科研蓝4');
  for(const a of previous.turns[3].actions)take(a);end('虫族4研究橙1');
  for(const a of previous.turns[4].actions)take(a);end('正常登陆海卫一');
 }
 return {label,turns,route:route&&copy(route),blocked};
}
try{
 const results=labels.map(run);
 assert.deepEqual(labels.map(run),results);
 m.restore(original);assert.deepEqual(m.save(),original);
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({source:root,results,rootExact:true,replayAndRngExact:true})),{flag:'wx'});
 for(const r of results)console.log(r.label,JSON.stringify(r.turns.map(t=>[t.label,t.facts.turn,t.value.total,t.facts.wallet.score,t.facts.final,
  ['credits','energy','availableData','handSize','publicity'].map(k=>t.facts.wallet[k]),t.facts.computer.length])),r.route?.path.length);
}finally{m.dispose();}
