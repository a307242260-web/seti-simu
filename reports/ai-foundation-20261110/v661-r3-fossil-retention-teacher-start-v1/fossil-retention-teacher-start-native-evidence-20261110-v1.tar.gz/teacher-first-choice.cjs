'use strict';
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [f,out]=process.argv.slice(2),d=readZ(f);
const x=runCases(d.root,[
 ['teacher-dlc31-first',h=>h.take(h.m.play('dlc_31.png'))],
 ['research-b101-first',h=>h.take(h.m.play('b_101.webp'))],
]);
writeZ(out,{root:d.root,...x});
