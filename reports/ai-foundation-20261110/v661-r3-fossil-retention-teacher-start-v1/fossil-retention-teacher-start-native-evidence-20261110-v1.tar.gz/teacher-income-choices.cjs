'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const [f,out]=process.argv.slice(2),x=readZ(f),r=x.rows[0],m=open(r.start),anchors={},cases={};
try{
 for(const [i,u] of r.actions.entries()){
  if([31,54].includes(i)){
   const e=m.save(),s=short(m),menu=m.menu(),{checkpoint,...q}=m.automatic();
   assert(q.complete&&q.n<=256&&q.ms<=600);
   anchors[i]={e,s,menu,q};
   console.log('income',i,s.wallet,q.a.summary,q.value,q.n,q.roots.map(r=>[menu.find(a=>a.actionId===r.actionId)?.summary,r.value,r.completion]));
  }
  m.apply(u.action);
 }
}finally{m.dispose();}
const insert=id=>h=>{const c=h.m.player().hand.find(x=>x.cardId===id);assert(c);h.act('choose_card',a=>a.target.cardInstanceId===c.id);};
cases[31]=runCases(anchors[31].e,[['amiba9-energy-first-income',insert('amiba_9.webp')]]);
cases[54]=runCases(anchors[54].e,[
 ['amiba9-energy-second-income',insert('amiba_9.webp')],['b14-energy-second-income',insert('b_14.webp')]
]);
writeZ(out,{anchors,cases});
