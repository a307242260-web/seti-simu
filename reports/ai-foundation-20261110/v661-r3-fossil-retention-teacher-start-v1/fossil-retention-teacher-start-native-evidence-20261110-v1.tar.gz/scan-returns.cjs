'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),r=readZ(src)['before-orange1'].rows[0],m=open(r.start),rows=[];
try{
 r.actions.slice(0,53).forEach(u=>m.apply(u.action));
 const root=m.save(),f=short(m),oldWins=m.state().data.sectorSettlements.winsByPlayerId['player-white'],scan=m.act('scan'),scanOpen=m.save();
 assert.deepEqual(f.wallet,[116,1,3,3,0]);assert.deepEqual(f.probes,[]);
 for(const first of m.menu()){
  m.restore(scanOpen);m.apply(first);
  const menu=m.menu().filter(a=>a.target.nebulaId),one=m.save();
  for(const second of menu){
   m.restore(one);m.apply(second);
   const actions=[first,second],middle=m.save();
   if(m.menu().some(a=>a.target.choiceId==='scan4:launch'))actions.push(m.act('choose_target',a=>a.target.choiceId==='scan4:launch'));
   const end=m.save(),summary=short(m),legal=m.menu();
   const winDelta=m.state().data.sectorSettlements.winsByPlayerId['player-white'].length-oldWins.length;
   m.restore(scanOpen);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
   rows.push({actions,middle,end,summary,legal,winDelta});
  }
 }
 assert.equal(rows.length,18);
 console.log(rows.map(r=>[r.actions.map(a=>a.summary).join(' / '),r.summary.wallet,r.winDelta,r.legal[0]?.summary]));
 writeZ(out,{root,f,oldWins,scan,scanOpen,rows});
}finally{m.dispose();}
