'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),{open,writeZ,short,runCases}=require('./controlled-r3');
const [f,out]=process.argv.slice(2),d=JSON.parse(fs.readFileSync(f,'utf8')),root=d.coreState.compositionEnvelope,m=open(root);
let q,s,menu;
try{
 assert.equal(m.facts().round,3);assert(!m.save().session);assert.equal(m.menu()[0].actorId,'player-white');
 s=short(m);const {checkpoint,...cold}=m.automatic();q=cold;menu=m.menu();
 console.log('teacher checkpoint',s,q.a.summary,q.n,q.ms,q.value);
 assert(q.complete&&q.n<=256&&q.ms<=600);assert.deepEqual(m.save(),root);
}finally{m.dispose();}
writeZ(out,{root,s,menu,q,...runCases(root,[['teacher-r3-start-autonomous-current',()=>{}]])});
