'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src).rows[0],m=open(d.start);
let e,q,menu,s;
try{
 d.actions.slice(0,56).forEach(u=>m.apply(u.action));e=m.save();menu=m.menu();s=short(m);
 const {checkpoint,...cold}=m.automatic();q=cold;assert(q.complete&&q.n<=256&&q.ms<=600);
 console.log('funding root',q.a.summary,q.value,q.n,s,q.roots.map(x=>[menu.find(a=>a.actionId===x.actionId)?.summary,x.value]));
}finally{m.dispose();}
const x=runCases(e,[
 ['play-amiba0-not-corner',h=>h.take(h.m.play('amiba_0.webp'))],
 ['play-b14-before-research',h=>h.take(h.m.play('b_14.webp'))],
 ['play-amiba9-before-research',h=>h.take(h.m.play('amiba_9.webp'))],
]);
writeZ(out,{e,q,menu,s,...x});
