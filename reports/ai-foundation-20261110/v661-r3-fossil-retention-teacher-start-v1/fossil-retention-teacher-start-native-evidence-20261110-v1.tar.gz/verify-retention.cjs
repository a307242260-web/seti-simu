'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ}=require('./controlled-r3');
const dir=process.argv[2]||__dirname,load=n=>readZ(path.join(dir,n+'-20261110-v1.json.gz'));
const prior=load('fossil06-prior-witness'),keep=load('fossil06-late-retain'),scan=load('fossil06-scan-returns'),branches=load('fossil06-scan-continuations'),r4=load('fossil06-scan-r4');
const teacher=load('teacher-r3-current'),first=load('teacher-first-choice'),income=load('teacher-income-choices'),t4=load('teacher-r4-controls'),third=load('teacher-third-income');
const metrics={replays:0,inputs:0,autonomous:0,maxNative:0,maxMs:0,scanPairs:0,overGate:0};
const sameSession=e=>JSON.parse(JSON.stringify(e).split(e.session?.session?.sessionId||'__no_session_id__').join('effect-session-X'));
function replay(e,actions,end,settled=null,independentSession=false){
 const m=open(e);try{
  let pass=false;
  for(const u of actions){
   if(u.n!==undefined){assert(u.n<=256&&u.ms<=600);metrics.autonomous++;metrics.maxNative=Math.max(metrics.maxNative,u.n);metrics.maxMs=Math.max(metrics.maxMs,u.ms);}
   const a=u.action||u;
   if(settled&&a.actorId==='player-white'&&a.family==='pass'&&m.facts().round===3){assert.deepEqual(m.save(),settled.state);pass=true;}
   m.apply(a);metrics.inputs++;
  }
  if(settled)assert(pass);
  if(independentSession)assert.deepEqual(sameSession(m.save()),sameSession(end));else assert.deepEqual(m.save(),end);
  metrics.replays++;
 }finally{m.dispose();}
}
function group(e,g){
 assert.deepEqual(g.failures,[]);
 for(const r of g.rows)replay(e,[...r.prefix,...r.actions],r.end,r.settled);
}
function round4(e,r){
 replay(e,r.actions,r.end);
 if(typeof r.stop==='object'){assert(r.stop.n>256||r.stop.ms>600);metrics.overGate++;}
}
replay(prior.r.start,prior.r.actions.slice(0,53),scan.root);
replay(prior.r.start,prior.r.actions.slice(0,58),keep.e);
replay(scan.root,[scan.scan],scan.scanOpen,null,true);
assert.equal(scan.rows.length,18);
for(const r of scan.rows){replay(scan.scanOpen,r.actions,r.end);assert.equal(r.winDelta,0);assert.equal(r.summary.wallet[4],2);metrics.scanPairs++;}
assert.equal(scan.rows.filter(r=>r.summary.wallet[0]===118).length,6);
for(const r of Object.values(keep.rows)){replay(keep.e,r.prefix,r.p);round4(r.p,r);assert.equal(r.checkpoints[1].s.established,203);}
group(branches.root,branches.variants);group(branches.extraRoot,branches.extra);group(branches.root,branches.twice);
for(const r of Object.values(r4))round4(r.e,r);
assert.equal(r4['扫描 绘架座β/dlc_17.png → 开普勒22'].checkpoints[1].s.established,224);
assert.equal(r4['skip-launch-for-second-standard-scan'].checkpoints[1].s.established,204);
assert.equal(Object.keys(prior.r4).length,2);
for(const r of Object.values(prior.r4))round4(r.e,r);
group(teacher.root,teacher);group(first.root,first);
assert.deepEqual(teacher.root,first.root);
assert.deepEqual(teacher.rows[0].settled.summary.income,[8,2,1,1]);
assert.deepEqual(first.rows[0].settled.summary.income,[6,4,2,1]);
for(const [k,g] of Object.entries(income.cases))group(income.anchors[k].e,g);
group(third.e,third);
for(const r of Object.values(t4))round4(r.e,r);
assert.deepEqual(t4['teacher-r3-start-autonomous-current'].checkpoints[0].s.wallet,[110,1,0,5,0]);
assert.equal(t4['b14-energy-second-income'].checkpoints[1].s.established,140);
console.log(JSON.stringify(metrics));
