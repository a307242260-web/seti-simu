# 原生复放：第三轮化石交付收尾与教师同起点

源码 `67d3118d8586d99014b6963dcf05dd2c6eb11d9b`。从源码根运行，`P` 为本档案解包目录：

```sh
(cd "$P" && shasum -a 256 -c SHA256SUMS)
node "$P/verify-retention.cjs"
```

复放器不重查策略。它核对完整规则信封、会话与 RNG（重新创建扫描会话时仅标准化会话命名空间）、每个已接受自主决定的预算记录、原生扫描目标和关键账本。超过门槛的输入没有提交。

`late-retain.cjs`、`scan-returns.cjs` 的起点来自蓝槽数据保留档案内的 `reserve-upstream-20261110-v1.json.gz`。本档案的 `fossil06-prior-witness-20261110-v1.json.gz` 单独保存了其中实际使用的原后缀及既有第四轮基准见证。先运行 `scan-returns.cjs` 与 `late-retain.cjs`，再运行 `scan-continuations.cjs` 与 `roll-scan-choices.cjs`。除前两个脚本外，各脚本输入均为本档案对应的上游 JSON.GZ。

教师同状态接手使用 `reports/ai-foundation-20261105/third-round-teacher-v1/teacher-before-input-113-20261105-v1.checkpoint.json`。运行 `teacher-entry.cjs` 后，可继续运行 `teacher-first-choice.cjs`、`teacher-income-choices.cjs`、`teacher-third-income.cjs`，最后以同一 B111 运行 `roll-teacher.cjs`。脚本拒绝覆盖已存在的结果文件。教师 105 分为已核验的现行规则参考；本档案只生成从该原生入口交回 AI 的分叉。
