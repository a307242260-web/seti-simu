'use strict';
const {open,readZ,writeZ,runCases}=require('./controlled-r3');
const [src,retained,out]=process.argv.slice(2),a=readZ(src),b=readZ(retained),d=a.rows.filter(r=>r.summary.wallet[0]===118);
const candidates=d.filter(r=>!r.actions[0].summary.includes('绘架座β')||!r.actions[1].summary.includes('b_16.webp'));
const variants=runCases(a.scanOpen,candidates.map(r=>[r.actions.map(x=>x.summary).slice(0,2).join('/'),h=>r.actions.forEach(x=>h.take(h.m.apply(x)))]));
const extra=runCases(b.rows['cash-buy-data-fill-six'].p,[['cash-after-analysis',()=>{}]]);
const twice=runCases(a.scanOpen,[['skip-launch-for-second-standard-scan',h=>{
 const r=d.find(r=>r.actions[0].summary.includes('绘架座β')&&r.actions[1].summary.includes('b_16.webp'));
 r.actions.slice(0,2).forEach(x=>h.take(h.m.apply(x)));
 h.act('choose_target',x=>x.target.choiceId==='scan4:skip');
 const put=id=>{h.act('place_data');h.act('choose_target',x=>x.target.choiceId===id);};
 put('data:computer');put('data:blueBonus:3');
 h.act('quick_trade',x=>x.target.tradeId==='publicity-for-card');h.take(h.m.pick('dlc_17.png'));
 h.act('quick_trade',x=>x.target.tradeId==='cards-for-energy');
 for(const id of ['chong_8.webp','dlc_17.png'])h.act('choose_payment',x=>x.summary===id);
 h.act('choose_payment',x=>x.summary.includes('确认弃牌'));h.act('end_turn');h.cut('second-scan-ready');
}]]);
writeZ(out,{root:a.scanOpen,extraRoot:b.rows['cash-buy-data-fill-six'].p,variants,extra,twice});
