'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),old=readZ(src)['before-orange1'].rows[0],seat='player-white',m=open(old.start);
let e;
try{old.actions.slice(0,58).forEach(u=>m.apply(u.action));e=m.save();}
finally{m.dispose();}
function prepare(m,key){
 const prefix=[],act=(f,p)=>prefix.push(m.act(f,p));
 const put=id=>{act('place_data');act('choose_target',a=>a.target.choiceId===id);};
 const acquire=id=>{act('quick_trade',a=>a.target.tradeId==='publicity-for-card');prefix.push(m.pick(id));};
 switch(key){
  case 'pool-two':break;
  case 'computer-six':put('data:computer');put('data:computer');break;
  case 'computer-five-cash':put('data:computer');put('data:blueBonus:3');break;
  case 'cash-buy-data':put('data:computer');put('data:blueBonus:3');acquire('dlc_17.png');break;
  case 'cash-buy-data-fill-six':put('data:computer');put('data:blueBonus:3');acquire('dlc_17.png');
   prefix.push(m.corner('dlc_17.png'));put('data:computer');break;
  case 'computer-five-pool':put('data:computer');break;
 }
 return prefix;
}
function next(m,e){
 const actions=[],checkpoints=[];const push=(a,method)=>actions.push({action:a,method});
 const other=()=>{const s=[];m.advanceOpponents(s);s.forEach(a=>push(a,'passive'));};
 const summarize=()=>short(m);
 push(m.act('pass'),'fixed');push(m.act('choose_card',a=>a.target.cardId==='b_111.webp'),'fixed');other();
 assert.equal(m.facts().round,4);assert(!m.save().session);
 const opening=m.save(),openingSummary=summarize();let last=openingSummary.turn,stop=null,cache=null;
 for(let i=0;i<150;i++){
  if(m.menu()[0]?.actorId!==seat){other();continue;}
  const s=summarize();
  if(!m.save().session&&s.turn>last){last=s.turn;checkpoints.push({e:m.save(),s});if(checkpoints.length===2){stop='two-turns';break;}}
  const q=m.automatic(cache);
  if(!q.complete||q.n>256||q.ms>600){stop={kind:'gate',n:q.n,ms:q.ms,action:q.a};break;}
  cache=q.checkpoint;actions.push({action:m.apply(q.a),method:'autonomous',n:q.n,ms:q.ms,value:q.value});
  if(q.a.family==='pass'){stop='autonomous-pass';break;}
 }
 assert(stop);const end=m.save();m.restore(e);actions.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),end);
 return {opening,openingSummary,actions,checkpoints,end,stop};
}
const h=open(e),rows={};
try{
 const common=short(h);
 assert.deepEqual(common.wallet,[118,0,0,3,2]);assert.equal(common.probes.length,1);
 for(const k of ['pool-two','computer-six','computer-five-cash','cash-buy-data','cash-buy-data-fill-six','computer-five-pool']){
  h.restore(e);
  const prefix=prepare(h,k),p=h.save(),f=short(h);
  h.restore(e);prefix.forEach(h.apply);assert.deepEqual(h.save(),p);
  rows[k]={prefix,p,f,...next(h,p)};
  console.log(k,JSON.stringify([f,rows[k].stop,rows[k].checkpoints.map(x=>x.s)]));
 }
 writeZ(out,{e,common,rows});
}finally{h.dispose();}
