'use strict';
const fs=require('node:fs'),Module=require('node:module'),assert=require('node:assert/strict');
const original=Module._extensions['.js'];
let installed=false;
Module._extensions['.js']=function(mod,file){
 if(!file.endsWith('/randomizer/game/ai/resource-demand.js'))return original(mod,file);
 assert(!installed);installed=true;
 const source=fs.readFileSync(file,'utf8'),marker='  function computeIncomeTailPreview({state,seatId,goal},scalarOnly){';
 assert(source.includes(marker));
 const checked=`
 const audit={compared:0,readOnly:0,public:0,available:0,misses:0,knownDataIncome:0,cachedPrefixes:0};
 process.on('exit',()=>console.error('INCOME_PREFIX_AUDIT '+JSON.stringify(audit)));
 function computeIncomeTailPreview(input,scalarOnly){
  const {state,seatId,goal}=input,player=owner(state,seatId),card=player.hand.find(c=>c.id===goal.incomeCardId);
  const actual=computeIncomeTailPreviewInner(input,scalarOnly),expected=referenceIncomeTail(input);
  require('node:assert/strict').deepEqual(actual,expected);
  audit.compared++;audit[scalarOnly?'readOnly':'public']++;audit[actual.available?'available':'misses']++;
  if(cards.getIncomeGainForCard(card)?.availableData)audit.knownDataIncome++;
  if(scalarOnly&&actual.available&&incomeTailPrefixes.get(player)?.dataState===actual.player.dataState)audit.cachedPrefixes++;
  return actual;
 }
  function referenceIncomeTail({state,seatId,goal}){
    const original=owner(state,seatId),p={...original,resources:{...original.resources},income:{...original.income},hand:[...original.hand],dataState:structuredClone(original.dataState)},card=p.hand.find(c=>c.id===goal.incomeCardId);
    const remaining=Math.max(0,4-placed(p));
    if(!card||p.resources.availableData<remaining)return{available:false,reason:'income-tail-needs-additional-funding'};
    for(let i=0;i<remaining;i++){
      const result=data.placeDataToComputer(p);if(!result.ok)return{available:false,reason:'income-tail-slot-unavailable'};
      for(const bonus of result.slotBonuses||[]){if(bonus.type==='publicity')players.gainResources(p,{publicity:bonus.publicity});else if(bonus.type==='score')players.gainResources(p,{score:bonus.score});}
    }
    p.hand=p.hand.filter(c=>c.id!==card.id);const gain=cards.getIncomeGainForCard(card);let blindHandValue=0,previewRoot=null;
    players.gainIncome(p,gain,{blindDraw:()=>{blindHandValue++;},
      gainData:target=>data.gainData(target,{root:previewRoot||(previewRoot={meta:structuredClone(state.meta)})})});
    p.resources.handSize=p.hand.length+blindHandValue;
    const future=Object.entries(gain).reduce((n,[k,v])=>n+v*({credits:1,energy:1,publicity:.5,availableData:.5,additionalPublicScan:.5,handSize:1}[k]||0),0)*(4-state.turn.roundNumber);
    return{available:true,player:p,netGain:resourceValue(p)-resourceValue(original)+blindHandValue+future,
      immediateScoreGain:p.resources.score-original.resources.score,placements:remaining,assumption:'known income reward and remaining official income rounds; unknown drawn identities excluded'};
  }
`;
 mod._compile(source.replace(marker,checked+marker.replace('computeIncomeTailPreview','computeIncomeTailPreviewInner')),file);
};
