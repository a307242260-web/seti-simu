'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {open,z,seat}=require('./native-compact-20261110-v1.cjs');
const read=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const {getProbeRouteRequirements}=require(path.resolve('randomizer/game/production-kernel'));
const {evaluateStateValue}=require(path.resolve('randomizer/game/ai/state-value'));
const {sanitizeHiddenInformationObservation}=require(path.resolve('randomizer/game/rule-composition'));
const deck=require(path.resolve('randomizer/game/cards/deck'));
const data=require(path.resolve('randomizer/game/data'));
const effects=require(path.resolve('randomizer/game/cards/effects'));
const demand=require(path.resolve('randomizer/game/ai/resource-demand'));
const [file,out]=process.argv.slice(2),{root,recipes,paid2Reference}=read(file),m=open(root),rootObs=m.owner(seat);
const rootKnown=new Set([...rootObs.selfState.hand,...rootObs.selfState.reservedCards,...rootObs.publicState.board.publicCards].filter(Boolean).map(c=>c.id));
const triton0=recipes.triton1;
const otherIncome='card-30-pass-3-1',supplier='alien-chong-6-16',dlc16='card-66-0';
const labels=['same-income','preserve-landing','reverse-fossil-energy','reverse-fossil-publicity','reverse-fossil-energy-display','reverse-fossil-publicity-display'];
function run(label){
 m.restore(root);
 const known=new Set(rootKnown),turns=[]; let actions=[],incomeChoice=null;
 function act(f,p=()=>true){return execute(m.menu().find(a=>a.family===f&&p(a)),f);}
 function execute(a,expect='action'){
  assert(a,JSON.stringify([expect,m.facts().wallet,m.menu().map(x=>[x.family,x.summary,x.target])]).slice(0,3000));
  assert.equal(a.actorId,seat);
  for(const id of [a.target?.cardInstanceId,a.payload?.cardInstanceId,...(a.target?.cardIds||[]),...(a.payload?.cardIds||[])].filter(Boolean))assert(known.has(id),id);
  assert(!a.target?.fossilId||label.startsWith('reverse-fossil-'));
  const hand=new Set(m.player().hand.map(c=>c.id));
  actions.push(m.apply(a));
  const display=/^(chong|amiba):display:(\d+)$/.exec(a.target?.choiceId||'');
  if(display){
    const board=rootObs.publicState.board.aliens,id=display[1]==='chong'?board.chongOffer.displayedCardIndex:board.amibaTraces.displayedCardIndex;
    assert.equal(+display[2],id);
    const added=m.player().hand.filter(c=>!hand.has(c.id));assert.equal(added.length,1);known.add(added[0].id);
  }
 }
 function snapshot(label){
  const obs=sanitizeHiddenInformationObservation(rootObs,m.owner(seat),{code:'hidden_card_reveal'},known),value=evaluateStateValue(obs,seat);
  const facts=m.facts();
  const target=getProbeRouteRequirements(m.state(),seat,m.save().session?.session?.queue?.[0])?.candidates.find(c=>c.endpointTarget?.satelliteId==='enceladus');
  const detail={label,actions,value:value.total,components:value.components,facts,checkpoint:m.save(),target,
    turn:m.state().turn.turnNumber,menu:m.menu().map(a=>[a.family,a.target,a.summary]),
    sectorAudit:m.menu().filter(a=>a.target?.nebulaId).map(a=>{
      const id=a.target.nebulaId,tokens=data.listNebulaTokens(m.state().data,id),count=data.getNebulaCapacity(id);
      const replaced=tokens.filter(t=>t.replacedByPlayerColor||t.playerColor).length;
      return {id,remaining:count-replaced,ranking:data.getSectorRanking(m.state().data,id)};
    })};
  turns.push(detail);actions=[];
  return detail;
 }
 for(const a of triton0){
   if(a.family==='choose_card'&&a.target.cardInstanceId===supplier){
     const state=m.state(),menu=m.menu(),p=state.players.players.find(p=>p.id===seat);
     const quote=demand.incomeChoice({state,seatId:seat,goal:{required:{}},actions:menu});
     incomeChoice={chosen:menu.find(a=>a.actionId===quote.actionId).target.cardInstanceId,options:[supplier,otherIncome].map(id=>{
       const card=p.hand.find(c=>c.id===id);
       return {id,gain:deck.getIncomeGainForCard(card),price:effects.getCardPrice(card),value:demand.incomeCardValue(state,seat,card)};
     })};
     if(label!=='same-income'){act('choose_card',q=>q.target.cardInstanceId===otherIncome);continue;}
   }
   execute(a);
 }
 snapshot('立即海卫一');
 act('research_tech');act('choose_target',a=>a.target.tileId==='orange1');
 act('choose_card',a=>a.target.cardInstanceId===dlc16);
 act('end_turn');
 const orange=snapshot('正常科研橙1并发射');
 if(label==='same-income')return{label,turns,incomeChoice};
 assert.equal(orange.target.path.length,3);
 assert.equal(orange.target.endpointFacts.cost.energy,2);
 act('quick_trade',a=>a.target.tradeId==='credits-for-energy');
 act('quick_trade',a=>a.target.tradeId==='cards-for-energy');
 for(const id of ['alien-chong-8-12','card-67-0'])act('choose_payment',a=>a.target.cardInstanceId===id);
 act('choose_payment',a=>a.target.confirm);
 const ship=orange.target.rocketId;
 for(const [i,dir] of orange.target.path.entries()){
   act('move',a=>a.target.rocketId===ship&&a.target.deltaX===dir.deltaX&&a.target.deltaY===dir.deltaY);
   act('choose_payment',a=>a.target.choiceId===(i===0?dlc16:'energy'));
 }
 const at=snapshot('到达土卫二，只剩1钱和虫族6');
 const card=m.player().hand.find(c=>c.id===supplier);
 assert.deepEqual(effects.getCardPlayCost(card),{credits:1});
 act('play_card',a=>a.target.cardInstanceId===supplier);
 snapshot('虫族6登陆菜单');
 if(m.menu().some(a=>a.target.landTarget?.satelliteId==='enceladus'))act('choose_target',a=>a.target.landTarget?.satelliteId==='enceladus');
 snapshot('确认土卫二后');
 act('choose_target',a=>a.target.nebulaId==='sector-3-b');
 snapshot('土卫二红扫后');
 act('choose_target',a=>a.target.nebulaId==='sector-2-a');
 snapshot('土卫二蓝扫后');
 act('choose_target',a=>a.target.nebulaId==='sector-4-a');
 snapshot('土卫二黄扫后');
 if(label==='preserve-landing')return{label,turns,incomeChoice};
 const [fossil]=m.menu().filter(a=>a.summary.includes(label.includes('-energy')?'2能量':'3宣传'));
 execute(fossil,'mandatory fossil');
 snapshot('强制领化石后');
 function deposit(target,blueSlot=null){
   act('place_data');
   act('choose_target',a=>a.target.target===target&&(blueSlot===null||a.target.blueSlot===blueSlot));
 }
 deposit('computer');deposit('computer');
 act('end_turn'); snapshot('第3回合结束');
 act('research_tech');act('choose_target',a=>a.target.tileId==='blue4'&&a.target.blueSlot===3);
 act('accept_optional_effect',a=>a.target.ruleId==='amiba1-blue-tech'&&a.target.choiceId.startsWith('confirm:'));
 if(m.save().session)act('choose_target',a=>a.target.slotId==='blue_1');
 deposit('blueBonus',3);
 act('end_turn');snapshot('第4回合结束');
 act('analyze');
 const choice=label.endsWith('-display')?'trace:2:blue:chong:8':'trace:1:blue:state-extra';
 act('choose_target',a=>a.target.choiceId===choice);
 if(label.endsWith('-display'))act('choose_card',a=>a.target.choiceId===`chong:display:${rootObs.publicState.board.aliens.chongOffer.displayedCardIndex}`);
 act('end_turn');
 const fifth=snapshot('第5回合结束');
 assert.equal(fifth.turn,12);assert.equal(fifth.checkpoint.session,null);
 return {label,turns,incomeChoice};
}

function forwardAttribution(){
 m.restore(root);
 for(const a of recipes.scan1)m.apply(a);
 assert.deepEqual(m.save(),paid2Reference.before);
 const rows=[];
 function stats(){
   const s=m.state(),p=m.player();
   return {resources:p.resources, hand:p.hand.map(c=>[c.id,c.cardId]),sectorWins:m.facts().wins,traceCounts:m.facts().traces,
     offers:m.menu().filter(a=>a.target?.nebulaId).map(a=>{
       const id=a.target.nebulaId,tokens=data.listNebulaTokens(s.data,id);
       return {id,remaining:data.getNebulaCapacity(id)-tokens.filter(t=>t.replacedByPlayerColor||t.playerColor).length,
         ranking:data.getSectorRanking(s.data,id)};
     })};
 }
 for(const a of recipes.paid2){
   const before=stats();m.apply(a);
   rows.push({action:a,before,after:stats()});
 }
 assert.deepEqual(m.save(),paid2Reference.after);
 return rows;
}

try{
 assert.deepEqual(deck.getIncomeGainForCard(m.player().hand.find(c=>c.id===otherIncome)),deck.getIncomeGainForCard(m.player().hand.find(c=>c.id===supplier)));
 const results=labels.map(run),forward=forwardAttribution();
 assert.deepEqual(labels.map(run),results);assert.deepEqual(forwardAttribution(),forward);
 m.restore(root);assert.deepEqual(m.save(),root);
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({results,forward,rootExact:true,repeatedStateAndRngExact:true})),{flag:'wx'});
 for(const r of results)for(const t of r.turns)console.log(JSON.stringify([r.label,t.label,t.turn,t.value,t.facts.final,t.facts.wallet,t.facts.hand,t.menu.filter(x=>x[0]==='choose_target'||x[0]==='choose_card')]));
}finally{m.dispose();}
