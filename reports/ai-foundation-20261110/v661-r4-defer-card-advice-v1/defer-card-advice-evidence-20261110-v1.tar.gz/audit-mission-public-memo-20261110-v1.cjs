'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),Module=require('node:module'),z=require('node:zlib');
const counts={menus:0,menuHits:0,tokens:0,tokenHits:0,usedFirstTokens:0,tasks:0,pinks:0};
globalThis.missionAudit=counts;
const normal=Module._extensions['.js'];
Module._extensions['.js']=(mod,file)=>{
 if(!file.endsWith('/randomizer/game/ai/probe-capital.js'))return normal(mod,file);
 let src=fs.readFileSync(file,'utf8');
 const menu='  function missionScanIds(root,actor,options,memo) {',
  token='  function missionScanToken(root,id,used,memo) {',
  task='missionMemo.task===undefined?(missionMemo.task=finalLandingTaskGain(facts)):missionMemo.task',
  pink='missionMemo.pink===undefined?(missionMemo.pink=knownAmibaPinkPayout(facts)):missionMemo.pink';
 for(const key of [menu,token,task,pink])assert.equal(src.split(key).length,2);
 src=src.replace(menu,`  function missionScanIds(root,actor,options,memo) {
    const before=memo?.menus.size,actual=uncheckedMissionScanIds(root,actor,options,memo);
    globalThis.missionAudit.menus++;
    if(memo&&memo.menus.size===before)globalThis.missionAudit.menuHits++;
    const fresh=science.listScanStepChoices(root,actor,{...options,gainData:true}).map(a=>a.target.nebulaId);
    require('node:assert/strict').deepEqual(actual,fresh);
    return actual;
  }
  function uncheckedMissionScanIds(root,actor,options,memo) {`)
 .replace(token,`  function missionScanToken(root,id,used,memo) {
    globalThis.missionAudit.tokens++;
    if(memo?.tokens.has(id))globalThis.missionAudit.tokenHits++;
    if(used.has(memo?.tokens.get(id)?.id))globalThis.missionAudit.usedFirstTokens++;
    const actual=uncheckedMissionScanToken(root,id,used,memo);
    const bucket=root.data.nebulae[id],available={...root.data,nebulae:{...root.data.nebulae,
      [id]:{...bucket,tokens:bucket.tokens.filter(t=>!used.has(t.id))}}};
    require('node:assert/strict').deepEqual(actual,data.getNextReplaceableNebulaToken(available,id));
    return actual;
  }
  function uncheckedMissionScanToken(root,id,used,memo) {`)
 .replace(task,`(missionMemo.task===undefined?(missionMemo.task=finalLandingTaskGain(facts)):(globalThis.missionAudit.tasks++,require('node:assert/strict').deepEqual(missionMemo.task,finalLandingTaskGain(facts)),missionMemo.task))`)
 .replace(pink,`(missionMemo.pink===undefined?(missionMemo.pink=knownAmibaPinkPayout(facts)):(globalThis.missionAudit.pinks++,require('node:assert/strict').deepEqual(missionMemo.pink,knownAmibaPinkPayout(facts)),missionMemo.pink))`);
 mod._compile(src,file);
};
process.on('exit',()=>{
 const out=process.env.SETI_MISSION_AUDIT_OUT;
 if(!out)return;
 fs.writeFileSync(out,JSON.stringify(counts,null,2)+'\n',{flag:'wx'});
});
