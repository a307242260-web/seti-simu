'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),read=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const load=f=>require(path.resolve('randomizer/game/ai',f));
const {createAnalysisPort}=load('analysis-port'),{createSearchAgent}=load('search-agent'),V=load('state-value');
const {replays}=read(process.argv[3]),proofs=[];
for(const [i,w] of replays.filter(r=>r.from==='orange3-ranked').entries()){
 const q=read(process.argv[4+i]),edge=q.lines[0].edges.find(e=>e.actionId===q.actionId&&e.resourcePlan?.goal?.kind==='held-satellite-travel');
 assert(edge&&q.value===240&&q.complete);
 const m=open(w.third.checkpoint),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 const agent=createSearchAgent({seatId:seat,analysisPort:port}),steps=[];
 try{
  for(let j=0;j<20;j++){
   const menu=m.menu();
   if(menu.every(a=>a.target?.fossilId))break;
   const s=agent.decide({seatId:seat,legalActions:menu}).search;
   assert(s.complete&&!s.unresolved.length);
   assert(s.diagnostics.nativeExecutions<=256&&s.rootAndSearchMilliseconds<=600,JSON.stringify(s.diagnostics).slice(0,300));
   if(j<edge.steps.length)assert.equal(s.actionId,edge.steps[j],j);
   const a=m.apply(menu.find(x=>x.actionId===s.actionId));
   assert(!a.target?.fossilId);
   steps.push({a,checkpoint:m.save(),reuse:s.diagnostics.planContinuation,native:s.diagnostics.nativeExecutions,ms:s.rootAndSearchMilliseconds});
  }
  const offer=m.save(),choices=m.menu();
  assert.equal(choices.length,2);assert(choices.every(a=>a.target?.fossilId));
  const scores=[];
  for(const a of choices){
   m.restore(offer);m.apply(a);m.act('end_turn');assert(!m.save().session);
   const val=V.evaluateStateValue(m.owner(seat),seat),f=m.facts();
   assert.equal(val.total,240);assert.equal(f.wallet.score,168);assert.equal(f.final,236);
   scores.push({fossilId:a.target?.fossilId,value:val.total,final:f.final});
  }
  m.restore(w.third.checkpoint);
  for(const {a,checkpoint} of steps){m.apply(a);assert.deepEqual(m.save(),checkpoint);}
  m.restore(w.third.checkpoint);
  proofs.push({mode:w.mode,steps,scores});
 }finally{port.close();m.dispose();}
}
fs.writeFileSync(process.argv[6],z.gzipSync(JSON.stringify({proofs,rootRestored:true})),{flag:'wx'});
console.log(JSON.stringify(proofs.map(r=>({mode:r.mode,steps:r.steps.length,reused:r.steps.filter(s=>s.reuse==='hit').length,
 maxMs:Math.max(...r.steps.map(s=>s.ms)),maxNative:Math.max(...r.steps.map(s=>s.native)),scores:r.scores}))));
