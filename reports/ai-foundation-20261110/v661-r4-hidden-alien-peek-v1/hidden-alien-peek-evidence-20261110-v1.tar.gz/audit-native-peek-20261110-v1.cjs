'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const {evaluateStateValue}=require(path.resolve('randomizer/game/ai/state-value'));
const [file,out]=process.argv.slice(2),src=path.resolve('randomizer/game/ai/analysis-port.js');
const m=new Module(src,module),base=fs.readFileSync(src,'utf8');
m.filename=src;m.paths=Module._nodeModulePaths(path.dirname(src));Module._cache[src]=m;
const needle='        chongTaskPeekBoundaries.set(node, boundary);';
assert.equal(base.split(needle).length,2);
const end=needle+'\n      }';
assert(base.includes(end));
m._compile(base.replace(end,end+`
      if(stored.informationBarrier?.code==="hidden_alien_card") {
        const native=expand(node,actionId);
        globalThis.auditPeek({action, before:readIdentityState(stored.envelope),
          after:readIdentityState(nodes.get(native).envelope), native, boundary,
          predicted:valueObservation(boundary), actual:valueObservation(native)});
      }
`),src);m.loaded=true;
const {open,seat}=require('./native-late-r3');
const rows=[];
globalThis.auditPeek=({action,before,after,native,boundary,predicted,actual})=>{
 assert.equal(native.status,'information-barrier');assert.equal(boundary.status,native.status);
 assert.equal(native.boundary,'hidden_chong_task_fossils');assert.equal(native.boundary,boundary.boundary);
 assert.equal(native.legalActions.length,0);assert.equal(boundary.legalActions.length,0);
 const a=structuredClone(after),revealed=[];
 for(const [id,f] of Object.entries(a.aliens.chong.fossilsById)){
  const prior=before.aliens.chong.fossilsById[id];
  if(JSON.stringify(f.visibleToPlayerIds)===JSON.stringify(prior.visibleToPlayerIds))continue;
  assert.equal(f.planetId,action.target.planetId);
  assert(!prior.visibleToPlayerIds.includes(seat));
  assert(f.visibleToPlayerIds.includes(seat));
  f.visibleToPlayerIds=prior.visibleToPlayerIds;
  revealed.push(id);
 }
 assert(revealed.length>0);
 assert.deepEqual(a,before,'only fossil visibility changes; wallet, turn and RNG exact');
 const value=evaluateStateValue(actual,seat);
 assert.deepEqual(value,evaluateStateValue(predicted,seat));
 assert.deepEqual(actual.selfState.hand,predicted.selfState.hand);
 rows.push({planet:action.target.planetId,revealed:revealed.length,value:value.total});
};
const {checkpoint:root}=JSON.parse(fs.readFileSync(file)),kernel=open(root);
try{
 const r=kernel.automatic();
 assert(r.complete);assert.deepEqual(kernel.save(),root);
 assert(rows.length>=20);
 const result={rows,score:r.value,action:r.a.actionId,rootAndRngExact:true};
 fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({validated:rows.length,planets:[...new Set(rows.map(x=>x.planet))],score:r.value,rootAndRngExact:true}));
}finally{kernel.dispose();}
