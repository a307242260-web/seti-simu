'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,open}=require('./controlled-r3');
const [file,out,coverage]=process.argv.slice(2),x=readZ(file),m=open(x.root);
const rows=[];
function canonical(e){
 const clone=structuredClone(e);
 clone.committedState=JSON.parse(clone.committedState);
 const ss=clone.session?.session;
 if(ss){ss.undoFrames=[];const prefix=ss.sessionId;
  if(prefix){
   const visit=o=>typeof o==='string'?o.replaceAll(prefix,'@session'):Array.isArray(o)?o.map(visit):o&&typeof o==='object'?Object.fromEntries(Object.entries(o).map(([k,v])=>[k,visit(v)])):o;
   clone.session=visit(clone.session);
  }
 }
 return clone;
}
const shape=e=>({actor:JSON.parse(e.committedState).turn.currentPlayerId,pending:e.session?.session?.queue[0]?.type||null});
function forwardDataTokens(e){
 const out=canonical(e);
 for(const state of [out.committedState,out.session?.session?.workingState,out.session?.session?.baseState]){
  if(!state)continue;
  delete state.meta.sequences.dataToken;
  for(const p of state.players.players){
   const d=p.dataState;
   const token=(t,pool)=>{const x={...t};delete x.id;delete x.index;if(pool)delete x.slotIndex;return x;};
   d.poolTokens=d.poolTokens.map(t=>token(t,true));
   d.placedTokens=d.placedTokens.map(t=>token(t,false)).sort((a,b)=>a.placementKind.localeCompare(b.placementKind)
    ||(a.placementSlot??a.blueSlot)-(b.placementSlot??b.blueSlot));
  }
 }
 return out;
}
function execute(root,steps,expected){
 assert(m.c.lifecycle.restore(root).ok);
 const summaries=[];
 for(const id of steps){
  const a=m.menu().find(a=>a.actionId===id);
  assert(a,JSON.stringify({id,menu:m.menu().map(v=>[v.actionId,v.summary])}).slice(0,1300));
  m.apply(a);summaries.push(a.summary);
 }
 const native=m.save();
 let stateMatch="exact";
 try{assert.deepEqual(canonical(native),canonical(expected));}
 catch{
  try{assert.deepEqual(forwardDataTokens(native),forwardDataTokens(expected));}
  catch(error){throw new Error("NATIVE_TAIL_ENDPOINT_DIFFERENT: "+String(error).slice(0,1600));}
  stateMatch="forward-data-token-equivalent";
 }
 return {summaries,shape:shape(native),assets:m.facts(),stateMatch};
}
try{
 for(const r of x.chains){
  assert.equal(r.upperBound,r.value);assert(r.incumbent.value>r.value);
  const blue=execute(r.start,r.steps,r.end);
  assert.notEqual(blue.shape.actor,'player-white');assert.equal(blue.shape.pending,null);
  rows.push({blue,upperBound:r.upperBound,incumbent:r.incumbent});
 }
 assert(m.c.lifecycle.restore(x.root).ok);assert.deepEqual(m.save(),x.root);
 const summary={paths:rows.length,inputs:rows.reduce((n,r)=>n+r.blue.summaries.length,0),states:Object.fromEntries([...new Set(rows.map(r=>r.blue.stateMatch))].map(k=>[k,rows.filter(r=>r.blue.stateMatch===k).length]))};
 writeZ(out,{summary,rows});
 console.log(JSON.stringify(summary));
}finally{m.dispose();}
