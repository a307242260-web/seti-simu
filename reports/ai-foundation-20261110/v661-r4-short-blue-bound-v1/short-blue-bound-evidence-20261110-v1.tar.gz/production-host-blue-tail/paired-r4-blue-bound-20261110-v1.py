from pathlib import Path
from statistics import median
import gzip,json,subprocess,sys
base,new,first,control,out=sys.argv[1:];here=Path(__file__).resolve().parent;rows={}
def values(r):
 return {x['actionId']:(x['value'],x.get('realization'),x.get('preparationDebt'),x.get('valueType'),x['completion']) for x in r['roots']}
for fixture,indices in [(first,('9','11','14')),(control,tuple(json.load(gzip.open(control))))]:
 for key in indices:
  batch=[]
  for i in range(5 if key=='9' else 2 if key in ('11','14') else 1):
   order=[('base',base),('new',new)]
   if i%2:order.reverse()
   for tag,src in order:
    raw=subprocess.check_output(['node',str(here/'cold-r4-after-cargo-20261110-v1.cjs'),fixture,key],cwd=src,text=True)
    batch.append({'tag':tag,**json.loads(raw)})
  old=next(r for r in batch if r['tag']=='base');test=next(r for r in batch if r['tag']=='new')
  assert all((r['actionId'],r['value'],r['completed'])==(old['actionId'],old['value'],True) for r in batch),key
  diffs=[]
  for k,(v,*_) in values(test).items():
   before=values(old)[k]
   if before[0]!=v:
    assert (v is None or before[0]>=v) and v!=test['value'],(key,k,before,values(test)[k])
    diffs.append([k,before,values(test)[k]])
  rows[key]={'batch':batch,'diffs':diffs}
  print(key,[(tag,round(median(r['ms'] for r in batch if r['tag']==tag),2),next((r['n'],r['nodes']) for r in batch if r['tag']==tag)) for tag in ('base','new')],diffs,flush=True)
with open(out,'x') as f:json.dump(rows,f,ensure_ascii=False)
