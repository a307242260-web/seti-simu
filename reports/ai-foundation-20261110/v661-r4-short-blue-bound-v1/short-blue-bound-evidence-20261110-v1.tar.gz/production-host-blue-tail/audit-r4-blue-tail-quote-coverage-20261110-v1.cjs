'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
const instrumented=path.resolve('randomizer/game/ai/decision-search.js');
const changes=[],blueRejection=new WeakMap();
globalThis.auditForeignReject=(node,i)=>{blueRejection.set(node,i);return null;};
function inject(text,needle,code){
 assert.equal(text.split(needle).length,2,needle);
 return text.replace(needle,code+'\n'+needle);
}
const extensions=Module._extensions['.js'];
Module._extensions['.js']=(m,file)=>{
 if(file===path.resolve('randomizer/game/ai/analysis-port.js')){
  let body=fs.readFileSync(file,'utf8');
  const start=body.indexOf('    function quietBluePublicPick('),finish=body.indexOf('    function quietR4ComputerFiveBlue(',start);
  const sliced=body.slice(start,finish).split('\n').map((line,i)=>line.replaceAll('return null;',
   'return globalThis.auditForeignReject(node,'+(i+1)+');')).join('\n');
  body=body.slice(0,start)+sliced+body.slice(finish);
  body=inject(body,'    function quietR4ComputerFiveBlue(',[
   '    function auditForeignBlueQuote(node,plan){',
   '      if(node.status!=="stable")return {reject:"status"};',
   '      const stored=nodes.get(node),state=readPlanningState(stored),owner=state.players.players.find(p=>p.id===seatId);',
   '      if(state.turn.roundNumber!==4||stored.informationBarrier?.code!=="hidden_card_reveal")return {reject:"scope"};',
   '      const slots=data.listComputerPlacedTokens(owner);',
   '      if(slots.length!==5||owner.resources.availableData!==2)return {reject:"stock"};',
   '      const transition=previewTurn(state),scope=Boolean(!stored.intent||stored.intent.path.length===0);',
   '      if(!scope||!transition.turnAdvanced||transition.roundAdvanced||transition.gameEnded||transition.nextPlayerId===seatId)return {reject:"turn"};',
   '      const quiet=localPlans.quietEndCompletion({state,seatId});',
   '      const checked=hasPostMainInertReservations(state,false,true,true);',
   '      const quote=quietBluePublicPick({state,owner,node,stored,plan,transition,finalRoundQuiet:true,foreignFive:true});',
   '      return {quote,quiet,checked,intent:Boolean(stored.intent)};',
   '    }'
  ].join('\n'));
  body=body.replace('expandResourcePlan, extendKnownBlueTail,','expandResourcePlan, extendKnownBlueTail, auditForeignBlueQuote,');
  m._compile(body,file);return;
 }
 if(file!==instrumented)return extensions(m,file);
 let content=fs.readFileSync(file,'utf8');
 content=inject(content,'        const regionNeedsTail=tailKind!==',
  '        globalThis.auditBlueTailAttempt(currentIndex,alternative.resourcePlan,incumbent,transitions,entry.node,port,valueForNode);');
 content=inject(content,'          let fixed=port.expandResourcePlan',
  '          const auditBlueBefore=alternative.resourcePlan.goal.id==="data:blue:2"?port.getDiagnostics().submissionCount:null;');
 content=inject(content,'          const newInputs=fixed.newSubmissions??fixed.submissions;',
  '          if(auditBlueBefore!==null)globalThis.auditBlueTailCost(currentIndex,alternative.firstActionId,auditBlueBefore,port.getDiagnostics().submissionCount);');
 content=inject(content,'    const roots = root.legalActions.map(action => {','    globalThis.auditBlueTailGraph(nodes, lines);');
 const original='      if (BOUNDARIES.has(node.status) && (!incumbent || value > incumbent.value)) incumbent = { node: index, value };';
 assert(content.includes(original));
 content=content.replace(original,[
  '      if (BOUNDARIES.has(node.status) && (!incumbent || value > incumbent.value)) {',
  '        incumbent = { node: index, value };',
  '        globalThis.auditBlueTailIncumbent(index,value,node.status,transitions);',
  '      }'].join('\n'));
 m._compile(content,file);
};
const {readZ,writeZ,open}=require('./controlled-r3');
const [fixture,output]=process.argv.slice(2);
const seat='player-white',root=readZ(fixture)[9].root,m=open(root);
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const port=createAnalysisPort({composition:m.c,seatId:seat});
const attempts=new Map(),results=[],allQuoted=[];
globalThis.auditBlueTailAttempt=(index,plan,incumbent,transitions,node,port,valueForNode)=>{
 if(plan?.goal?.id!=='data:blue:2')return;
 const key=JSON.stringify([index,plan.firstActionId]);
 assert(!attempts.has(key),key);
 const proof=port.auditForeignBlueQuote(node,plan);
 attempts.set(key,{incumbent:incumbent&&{...incumbent},transitions,barrier:node.informationBoundary?.code,proof,
  rejected:blueRejection.get(node),valueBefore:proof.quote?valueForNode(node):null});
};
globalThis.auditBlueTailCost=(index,actionId,before,after)=>{
 const item=attempts.get(JSON.stringify([index,actionId]));
 assert(item);
 item.nativeBefore=before;
 item.nativeInputs=after-before;
};
globalThis.auditBlueTailGraph=(nodes,lines)=>{
 for(const line of lines){
  for(const edge of line.edges){
   if(edge.resourcePlan?.goal.id==='data:blue:2'){
    const tried=attempts.get(JSON.stringify([line.node,edge.actionId]));
    if(tried?.proof.quote){
     const q=tried.proof.quote, leaf=lines[edge.target],upper=tried.valueBefore+q.netGain;
     allQuoted.push({index:line.node,value:leaf.value,upper,closed:Boolean(edge.continuedBlueTail?.closed),
       status:leaf.status, length:q.requiredNativeInputs, suffix:q.bluePublicPick.continuingDataPlans?.map(p=>p.goal.id)||[],
       inert:tried.proof.checked,markGain:tried.proof.quiet.netGain,score:tried.incumbent?.value??null});
    }
   }
   if(!edge.continuedBlueTail?.closed)continue;
   const key=JSON.stringify([line.node,edge.actionId]);
   const before=attempts.get(key);
   assert(before,key);
   const leaf=lines[edge.target],direct=line.edges.find(e=>e.actionId.startsWith('end_turn:'));
   assert(direct,key);
   results.push({source:line.node,terminal:edge.target,direct:direct.target,value:leaf.value,directValue:lines[direct.target].value,steps:edge.steps,
    newInputs:edge.newInputs,...before, incumbentStatus:before.incumbent&&nodes[before.incumbent.node].node.status});
  }
 }
};
globalThis.auditBlueTailIncumbent=(index,value,status,n)=>{
 changes.push({index,value,status,n});
};
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);
 assert.deepEqual(m.save(),root);
 assert.equal(results.length,127);
 const isShort=row=>row.steps.length===6&&row.value-row.directValue===1;
 const short=results.filter(isShort);
 assert.equal(short.length,84);
 const summary=group=>({count:group.length,missing:group.filter(x=>!x.incumbent).length,
  strictlyBeaten:group.filter(x=>x.incumbent?.value>x.value).length,equal:group.filter(x=>x.incumbent?.value===x.value).length,
  slackHalf:group.filter(x=>x.incumbent?.value>x.value+.5).length,slackOne:group.filter(x=>x.incumbent?.value>x.value+1).length,
  slackTwo:group.filter(x=>x.incumbent?.value>x.value+2).length,slackFour:group.filter(x=>x.incumbent?.value>x.value+4).length,
  slackEight:group.filter(x=>x.incumbent?.value>x.value+8).length,withNative:group.filter(x=>x.incumbent?.value>x.value&&!x.incumbentStatus?.endsWith('-value')).length,
  atRootWinner:group.filter(x=>x.incumbent?.value===q.value).length,
  nativeCost:group.reduce((sum,x)=>sum+x.nativeInputs,0),
  strictNativeCost:group.filter(x=>x.incumbent?.value>x.value).reduce((sum,x)=>sum+x.nativeInputs,0),
  strictNewSteps:group.filter(x=>x.incumbent?.value>x.value).reduce((sum,x)=>sum+x.newInputs,0)});
 const rejection=Object.groupBy(short,r=>r.proof.quote?'accepted':r.proof.reject||r.rejected||'unclassified');
 const audit={all:summary(results),short:summary(short),other:summary(results.filter(x=>!isShort(x))),
  categories:Object.fromEntries(Object.entries(rejection).map(([k,v])=>[k,v.length])),
  quoted:short.filter(r=>r.proof.quote).map(r=>[r.source,r.value,r.valueBefore+r.proof.quote.netGain,r.proof.intent])};
 writeZ(output,{results,changes,audit,allQuoted,decision:{actionId:q.actionId,value:q.value,native:q.diagnostics.nativeExecutions,nodes:q.diagnostics.graphNodes,complete:q.complete,ms:q.rootAndSearchMilliseconds}});
 const six=allQuoted.filter(q=>q.length===6&&q.suffix.join()==='data:blue:3');
 console.log(JSON.stringify({counts:audit.categories,totalQuoted:allQuoted.length,six:six.length,
  sixStrict:six.filter(q=>q.score>q.upper).length,sixMismatches:six.filter(q=>q.value!==q.upper),
  allMismatches:allQuoted.filter(q=>q.value!==q.upper).length,sixNotClosed:six.filter(q=>!q.closed).length}));
}finally{port.close();m.dispose();}
