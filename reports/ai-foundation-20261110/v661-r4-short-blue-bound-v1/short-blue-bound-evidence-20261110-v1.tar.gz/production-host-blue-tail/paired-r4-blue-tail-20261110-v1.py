from pathlib import Path
from statistics import median
import json,subprocess,sys
base,new,fixture,out=sys.argv[1:];here=Path(__file__).resolve().parent;rows={}
rankkeys=('actionId','value','realization','preparationDebt','completion','valueType')
def rank(r):return [[x.get(k) for k in rankkeys] for x in r['roots']]
for index in ('9','11','14'):
 batch=[]
 for i in range(5 if index=='9' else 2):
  order=[('base',base),('new',new)]
  if i%2: order.reverse()
  for tag,src in order:
   raw=subprocess.check_output(['node',str(here/'cold-r4-after-cargo-20261110-v1.cjs'),fixture,index],cwd=src,text=True)
   batch.append({'tag':tag,**json.loads(raw)})
 assert all((r['actionId'],r['value'],rank(r))==(batch[0]['actionId'],batch[0]['value'],rank(batch[0])) for r in batch)
 rows[index]=batch
 print(index,[(tag,round(median(r['ms'] for r in batch if r['tag']==tag),2),next((r['n'],r['nodes']) for r in batch if r['tag']==tag)) for tag in ('base','new')],flush=True)
with open(out,'x') as f:json.dump(rows,f,ensure_ascii=False)
