'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
const calls=[],envelopes=new WeakMap(),extensions=Module._extensions['.js'];
const ai=path.resolve('randomizer/game/ai');
globalThis.auditBlueUpper=(node,plan,currentValue,upperBound,incumbent)=>calls.push({node,plan,currentValue,upperBound,incumbent:{...incumbent}});
globalThis.auditBlueEnvelope=(node,envelope)=>envelopes.set(node,envelope);
Module._extensions['.js']=(m,file)=>{
 if(![path.join(ai,'analysis-port.js'),path.join(ai,'decision-search.js')].includes(file))return extensions(m,file);
 let code=fs.readFileSync(file,'utf8');
 if(file.endsWith('decision-search.js')){
  const from=code.indexOf('const proof=port.foreignBlueTwoUpperBound'),k='            if(upperBound!==null&&incumbent.value>upperBound){';
  const at=code.indexOf(k,from);
  assert(from>=0&&at>from);
  code=code.slice(0,at+k.length)+'\n              globalThis.auditBlueUpper(entry.node,alternative.resourcePlan,currentValue,upperBound,incumbent);'+code.slice(at+k.length);
 }else{
  for(const [anchor,record] of [
   ['      nodeCount += 1;\n      return node;', '      globalThis.auditBlueEnvelope(node,envelope);'],
   ['      return child;\n    }\n\n    function knownPostdrawDataView', '      globalThis.auditBlueEnvelope(child,envelope);']
  ]){
   assert.equal(code.split(anchor).length,2);
   code=code.replace(anchor,record+'\n'+anchor);
  }
 }
 m._compile(code,file);
};
const {readZ,writeZ,open}=require('./controlled-r3');
const {createAnalysisPort}=require(path.join(ai,'analysis-port'));
const {BUDGET,OPTIONS}=require(path.join(ai,'search-agent'));
const {searchDecision}=require(path.join(ai,'decision-search'));
const {createStateValueEvaluator}=require(path.join(ai,'state-value'));
const [fixture,output,index='9']=process.argv.slice(2),root=readZ(fixture)[index].root,seat='player-white',m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat});
const chains=[];
try{
 const evaluate=createStateValueEvaluator(seat);
 const q=searchDecision({port,root:port.openRoot(),evaluate,modelKey:evaluate.modelKey,budget:BUDGET,...OPTIONS});
 assert(q.complete&&!q.unresolved.length);
 assert.deepEqual(m.save(),root);
 for(const {node,plan,currentValue,upperBound,incumbent} of calls){
  let fixed=port.extendKnownBlueTail(port.expandResourcePlan(node,plan,()=>null));
  if(fixed.complete&&fixed.continuedBlueTail&&!fixed.continuedBlueTail.closed){
   const n=fixed.node,pick=port.cardPickSpec(n),res=port.resourceSpec(n),move=port.goalMovementSpec(n);
   const a=n.legalActions.filter(a=>(!res||res.retainedActionIds.includes(a.actionId))
     &&(!move||move.retainedActionIds.includes(a.actionId))&&(!pick||pick.retainedActionIds.includes(a.actionId)));
   assert(a.length===1&&a[0].family==='end_turn'&&!res?.plans.length&&!move?.selectedActionId,
    JSON.stringify({actions:a.map(x=>x.family),res:res?.plans,move:move?.selectedActionId,status:n.status}));
   const next=port.expand(n,a[0].actionId);
   fixed={...fixed,node:next,prefixes:[...fixed.prefixes,{action:a[0]}],continuedBlueTail:{closed:true}};
  }
  const current=envelopes.get(node),end=envelopes.get(fixed.node);
  assert(current&&end&&fixed.complete&&fixed.continuedBlueTail?.closed&&fixed.prefixes.length===6,
   JSON.stringify({current:!!current,end:!!end,complete:fixed.complete,continued:fixed.continuedBlueTail,
    steps:fixed.prefixes.map(p=>p.action.summary),value:upperBound,menu:fixed.node.legalActions.map(a=>[a.family,a.target])}));
  const value=evaluate(port.valueObservation(fixed.node));
  assert(value===upperBound&&incumbent.value>value);
  chains.push({start:current,end,steps:fixed.prefixes.map(p=>p.action.actionId),currentValue,upperBound,incumbent,value});
 }
 assert.deepEqual(m.save(),root);
 writeZ(output,{root,chains,decision:{actionId:q.actionId,value:q.value,roots:q.roots,n:q.diagnostics.nativeExecutions,nodes:q.diagnostics.graphNodes,complete:q.complete}});
 console.log(chains.length);
}finally{port.close();m.dispose();}
