'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),z=require('node:zlib'),Module=require('node:module');
const [teacher,official,which,out]=process.argv.slice(2),load=n=>require(path.resolve(n));
const source=Module._extensions['.js'],counters={};
globalThis.snapProfile=(kind,stats,fn)=>{
 const before=performance.now(),v=fn(),ms=performance.now()-before;
 const key=kind+':'+stats;
 const row=counters[key]||={calls:0,ms:0};row.calls++;row.ms+=ms;
 return v;
};
const edits={
 '/randomizer/game/ai/analysis-port.js':[
  ['const observation = project(fork.composition || fork,valueOnly);','const observation = globalThis.snapProfile("projection",Boolean(envelope.session)+"/"+valueOnly,()=>project(fork.composition || fork,valueOnly));'],
  ['const saved = comp.lifecycle.save({ trustedFork: true, deferSerialization:true });','const saved = globalThis.snapProfile("capture","trusted",()=>comp.lifecycle.save({ trustedFork: true, deferSerialization:true }));'],
  ['const restored = comp.lifecycle.restore(envelope, {','const restored = globalThis.snapProfile("restore",Boolean(envelope.session)+"/"+forWrite,()=>comp.lifecycle.restore(envelope, {'],
  ['trustedState: readCommittedState(envelope),\n      });','trustedState: readCommittedState(envelope),\n      }));'],
 ],
 '/randomizer/game/effects/session-runtime.js':[
  ['journal: clone(session.journal),','journal: globalThis.snapProfile("journal","commit",()=>clone(session.journal)),'],
 ],
 '/randomizer/game/state/state-store.js':[
  ['const nextValidation = validate(isolatedCandidate, { skipSerializableGraph: true });','const nextValidation = globalThis.snapProfile("invariants","commit",()=>validate(isolatedCandidate, { skipSerializableGraph: true }));'],
  ['state: trustedIsolatedOwnership ? copyForkData(committedState) : clone(committedState),','state: trustedIsolatedOwnership ? globalThis.snapProfile("copy","committed",()=>copyForkData(committedState)) : clone(committedState),'],
 ],
};
Module._extensions['.js']=(m,p)=>{
 const edit=Object.entries(edits).find(([f])=>p.endsWith(f));
 if(!edit)return source(m,p);
 let code=fs.readFileSync(p,'utf8');
 for(const [a,b] of edit[1]){assert.equal(code.split(a).length,2,a);code=code.replace(a,b);}
 return m._compile(code,p);
};
const {open,seat}=require('./native-late-r3'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),
 {createSearchAgent}=load('randomizer/game/ai/search-agent');
const fixture=JSON.parse(z.gunzipSync(fs.readFileSync(teacher)));
const root=which==='official'?JSON.parse(fs.readFileSync(official)).checkpoint:fixture.rows.find(r=>r.summary.i===Number(which)).root;
const m=open(root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 const data={which,counters,native:q.diagnostics.nativeExecutions,complete:q.complete,rootAndRngExact:true};
 fs.writeFileSync(out,JSON.stringify(data,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(data));
}finally{p.close();m.dispose();}
