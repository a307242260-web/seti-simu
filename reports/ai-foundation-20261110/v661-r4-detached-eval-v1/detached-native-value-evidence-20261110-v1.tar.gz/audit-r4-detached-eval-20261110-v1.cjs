'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),crypto=require('node:crypto');
const [source,official,which,mode,out]=process.argv.slice(2),load=n=>require(path.resolve(n));
const original=Module._extensions['.js'];
const counters={copies:0,detached:0,scoreComparisons:0,r4NoProbe:0,pendingMark:0,probe:0};
const audit=mode==='audit';
const legacy=process.argv[7];
globalThis.verifyValueCopy=(value,copy)=>{
 assert.deepEqual(copy,structuredClone(value));
 counters.copies++;
 if(value&&typeof value==='object'){assert.notEqual(value,copy);counters.detached++;}
 return copy;
};
globalThis.verifyFinalValue=(current,previous,obs)=>{
 assert.deepEqual(current,previous);
 counters.scoreComparisons++;
 if(obs.publicState.roundNumber===4&&!obs.terminal){
   if(current.components.probePotential>0)counters.probe++;
   else if(!obs.publicState.board.rockets.some(r=>r.playerId===obs.selfState.playerId&&r.surface==='solar-board'&&(r.kind||'standard')==='standard'&&r.fossilId==null)){
    counters.r4NoProbe++;if(current.components.finalMarkPotential>0)counters.pendingMark++;
   }
 }
 return current;
};
if(audit)Module._extensions['.js']=(m,p)=>{
 if(p.endsWith('/randomizer/app/rule-observation.js')){
  let code=fs.readFileSync(p,'utf8');
  const a='const copyValueSlice=valueOnly?stateStore.copyForkData:clone;';
  assert.equal(code.split(a).length,2);
  code=code.replace(a,'const copyValueSlice=valueOnly?value=>globalThis.verifyValueCopy(value,stateStore.copyForkData(value)):clone;');
  return m._compile(code,p);
 }
 if(p.endsWith('/randomizer/game/ai/state-value.js')){
  let code=fs.readFileSync(p,'utf8');
  const old=fs.readFileSync(path.join(legacy,'randomizer/game/ai/state-value.js'),'utf8');
  const a='  function evaluateStateValue(',b='  function createStateValueEvaluator(';
  const oldEval=old.split(a)[1].split(b)[0];
  code=code.replace(a,'  function currentEvaluateStateValue(').replace(b,`  function previousEvaluateStateValue(${oldEval}
    function evaluateStateValue(obs,seat,opts){
     return globalThis.verifyFinalValue(currentEvaluateStateValue(obs,seat,opts),previousEvaluateStateValue(obs,seat,opts),obs);
    }\n`+b);
  return m._compile(code,p);
 }
 return original(m,p);
};
const {open,seat}=require('./native-late-r3'),agent=load('randomizer/game/ai/search-agent'),
 {createAnalysisPort}=load('randomizer/game/ai/analysis-port');
const fixture=JSON.parse(z.gunzipSync(fs.readFileSync(source))),root=which==='official'?JSON.parse(fs.readFileSync(official)).checkpoint:
 fixture.rows.find(r=>r.summary.i===Number(which)).root;
const m=open(root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=agent.createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 const semantic={actionId:q.actionId,value:q.value,realization:q.realization,preparationDebt:q.preparationDebt,roots:q.roots,lines:q.lines,
  transitions:q.diagnostics.transitions,nativeExecutions:q.diagnostics.nativeExecutions};
 const canonical=x=>Array.isArray(x)?x.map(canonical):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,canonical(x[k])])):x;
 const graph=crypto.createHash('sha256').update(JSON.stringify(canonical(semantic))).digest('hex');
 
 const r={which,mode,graph,counters,ms:q.rootAndSearchMilliseconds,native:q.diagnostics.nativeExecutions,logical:q.diagnostics.transitions,
  eval:q.diagnostics.valueEvaluations,nodes:q.lines.length,rootAndRngExact:true};
 fs.writeFileSync(out,JSON.stringify(r,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(r));
}finally{p.close();m.dispose();}
