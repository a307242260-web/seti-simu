'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),z=require('node:zlib'),crypto=require('node:crypto'),path=require('node:path');
const {open,seat}=require('./native-late-r3');
const [input,out]=process.argv.slice(2),d=JSON.parse(z.gunzipSync(fs.readFileSync(input))),lookup=new Map(d.rows.map(r=>[r.i,r]));
const record=[];
const canonical=x=>Array.isArray(x)?x.map(canonical):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,canonical(x[k])])):x;
const hash=x=>crypto.createHash('sha256').update(JSON.stringify(canonical(x))).digest('hex');
const data=require(path.resolve('randomizer/game/data'));
const stableSerialize=x=>Array.isArray(x)?'['+x.map(stableSerialize).join(',')+']':x&&typeof x==='object'
 ?'{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+stableSerialize(x[k])).join(',')+'}':JSON.stringify(x);
for(const src of d.rows)for(const edge of src.edges){
 if(edge.g!=='data:computer-prefix:5')continue;
 const dest=lookup.get(edge.to);
 const n=open({...src.envelope,committedState:stableSerialize(JSON.parse(src.envelope.committedState))});
 try{
  const before=n.state(),p=before.players.players.find(q=>q.id===seat);
  assert.deepEqual(data.listComputerPlacedTokens(p).map(t=>t.placementSlot).sort((a,b)=>a-b),[1,2,3,4]);
  const first=n.act('place_data',a=>a.actionId===edge.a);
  const chosen=n.act('choose_target',a=>a.target.target==='computer');
  const actual=n.save();assert.equal(actual.session,null);
  const after=JSON.parse(actual.committedState),p1=after.players.players.find(q=>q.id===seat);
  assert.equal(p1.resources.score-p.resources.score,2);
  assert.equal(p1.resources.availableData-p.resources.availableData,-1);
  assert.deepEqual(p1.hand,p.hand);
  assert.deepEqual(after.cards.publicCards,before.cards.publicCards);
  const expected=JSON.parse(dest.envelope.committedState);
  // A normalized transposition can point to the same forward state after a
  // different number of inputs. Report which literal authority fields differ.
  const versionExact=after.meta.stateVersion===expected.meta.stateVersion&&after.match.decisionVersion===expected.match.decisionVersion;
  for(const s of [after,expected]){delete s.meta.stateVersion;delete s.match.decisionVersion;}
  const actualHash=hash(after),expectedHash=hash(expected),exact=actualHash===expectedHash;
  if(!exact){
    // Preserve each difference as evidence; do not silently normalize it.
    const different=Object.keys(after).filter(k=>hash(after[k])!==hash(expected[k]));
    record.push({from:src.i,to:dest.i,exact,versionExact,different,first:first.actionId,second:chosen.actionId});
  }else{
    record.push({from:src.i,to:dest.i,exact,versionExact,first:first.actionId,second:chosen.actionId,rngExact:true,
      downstream:dest.edges.map(a=>({family:a.a.split(':')[0],goal:a.g||null,proof:a.t||null})),
      sourceAuthority:before.meta.stateVersion,endpointHash:actualHash});
  }
 }finally{n.dispose();}
}
assert.equal(record.length,66);
const summary={total:record.length,exactAfterAuthority:record.filter(x=>x.exact).length,exactAuthority:record.filter(x=>x.exact&&x.versionExact).length,
 differences:record.filter(x=>!x.exact).map(x=>x.different),record};
fs.writeFileSync(out,JSON.stringify(summary,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({...summary,record:undefined}));
