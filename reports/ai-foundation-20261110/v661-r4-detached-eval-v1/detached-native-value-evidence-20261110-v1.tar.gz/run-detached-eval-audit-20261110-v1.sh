#!/bin/sh
set -eu
test "$#" = 5
prev=$1
candidate=$2
teacher=$3
r3=$4
output=$5
h=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
mkdir -p "$output"
for mode in official 317 318 359 136 172; do
 fixture=$teacher
 case "$mode" in 136|172) fixture=$r3;; esac
 (cd "$prev" && node "$h/audit-r4-detached-eval-20261110-v1.cjs" "$fixture" "$h/v661-r4-full-preflight-20261109-v1.json" "$mode" baseline "$output/$mode-before.json")
 (cd "$candidate" && node "$h/audit-r4-detached-eval-20261110-v1.cjs" "$fixture" "$h/v661-r4-full-preflight-20261109-v1.json" "$mode" audit "$output/$mode-after.json" "$prev")
done
python3 - "$output" <<'PY'
from pathlib import Path
import json
import sys
p=Path(sys.argv[1])
for b in sorted(p.glob('*-before.json')):
    x=json.loads(b.read_text())
    y=json.loads(p.joinpath(f'{x["which"]}-after.json').read_text())
    assert all(x[k]==y[k] for k in ['graph','native','logical','eval','nodes','rootAndRngExact']),x['which']
PY
