'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{open,z,seat}=require('./native-late-r3');
const load=n=>require(path.resolve('randomizer/game/'+n));
const {evaluateStateValue,DEFAULT_WEIGHTS}=load('ai/state-value'),probe=load('ai/probe-capital');
const {sanitizeHiddenInformationObservation}=load('rule-composition');
const [rootFile,fourthFile,fifthFile,out,verify]=process.argv.slice(2);
const read=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f))).rows;
const fourth=read(fourthFile).find(r=>r.line==='enceladus'&&r.third==='blue4'&&r.goal==='chong4-then-research');
const fifth=read(fifthFile).find(r=>r.line==='enceladus'&&r.variant==='original');
const m=open(read(rootFile)[0].root);
try {
 const raw=m.owner(seat), known=new Set([...raw.selfState.hand,...raw.selfState.reservedCards,...raw.publicState.board.publicCards].filter(Boolean).map(c=>c.id));
 m.restore(fourth.end);
 for(const card of m.player().hand)if(card.cardId===`amiba_${raw.publicState.board.aliens.amibaTraces.displayedCardIndex}.webp`)known.add(card.id);
 const masked=sanitizeHiddenInformationObservation(raw,m.owner(seat),{code:'hidden_card_reveal'},known);
 assert.equal(masked.selfState.hand.filter(c=>c.hidden).length,1);
 const full=evaluateStateValue(masked,seat);
 const facts={...probe.factsFromObservation(masked,seat),investment:()=>0,initialInvestmentCapital:0};
 const quotation=probe.quote(facts,DEFAULT_WEIGHTS),choice=quotation.selected;
 assert.deepEqual(m.save(),fourth.end);
 const close=()=>{m.act('end_turn'); if(m.save().session)m.act('accept_optional_effect',a=>a.target.choiceId.startsWith('skip:chong_task:'));};
 const afterReference=()=>{m.restore(fifth.end);return m.facts();};
 const reference=afterReference();
 m.restore(fourth.end);
 const result={before:full,choice,reference};
 console.log(JSON.stringify({total:full.total,probe:full.components.probePotential,choice,knownHand:facts.hand.map(c=>[c.id,c.cardId]),candidates:quotation.candidates.length}));
 if(verify){
  const c=choice;
  assert.equal(c.id,'9:land:neptune:triton');
  assert.equal(c.value,19);
  assert.equal(full.total,254.5);
  assert.equal(full.components.probePotential,19);
  const mask=o=>sanitizeHiddenInformationObservation(raw,o,{code:'hidden_card_reveal'},known);
  const compact=m.c.projection({role:'player',playerId:seat,valueOnly:true}).state;
  assert.deepEqual(evaluateStateValue(mask(compact),seat),full);
  const scalar=probe.quoteValue(facts,DEFAULT_WEIGHTS);
  assert.equal(scalar,c.value);
  const nativeState=m.state(),p=m.player(),maskedOwner={...p,hand:facts.hand};
  const formal=probe.factsFromState(nativeState,maskedOwner);
  assert.equal(probe.quoteValue({...formal,investment:()=>0,initialInvestmentCapital:0},DEFAULT_WEIGHTS),c.value);
  const swap=probe.prepareFinalRoundSwapMission(nativeState,maskedOwner);
  assert.equal(swap.sensitive,true);
  assert.equal(swap.quote(facts.hand,nativeState.cards.publicCards),c.value);
  for(const id of c.payment.cornerCardIds){
   const noCorner=facts.hand.map(card=>card.id===id?{id:card.id,hidden:true}:card);
   const losesTriton=probe.quote({...facts,hand:noCorner},DEFAULT_WEIGHTS);
   assert(!losesTriton.candidates.find(x=>x.id===c.id).funded);
   assert.equal(swap.quote(noCorner,nativeState.cards.publicCards),losesTriton.value);
  }
  assert(!probe.quote({...facts,uncontestedRound:false},DEFAULT_WEIGHTS).candidates.find(x=>x.id===c.id).funded);
  const payCards=[...c.payment.cornerCardIds,...c.payment.exchangeCardIds];
  assert.equal(new Set(payCards).size,4);
  assert(payCards.every(id=>known.has(id)));
  const actions=[],act=(...args)=>{const a=m.act(...args);actions.push(a);return a;};
  act('quick_trade',a=>a.target.tradeId==='cards-for-energy');
  for(const id of c.payment.exchangeCardIds)act('choose_payment',a=>a.target.cardInstanceId===id&&a.target.select);
  act('choose_payment',a=>a.target.confirm===true);
  const paid=[...c.payment.cornerCardIds];
  for(const step of c.route.path){
   act('move',a=>a.target.rocketId===9&&a.target.deltaX===step.deltaX&&a.target.deltaY===step.deltaY);
   const id=paid.shift();
   act('choose_payment',a=>a.target.kind==='move-payment'&&(id?a.target.cardIds.length===1&&a.target.cardIds[0]===id:!a.target.cardIds.length));
  }
  act('land');
  act('choose_target',a=>a.target.landTarget?.satelliteId==='triton');
  close();
  const endpoint=m.facts();
  assert.equal(endpoint.turn,12);
  assert.equal(endpoint.final,248);
  assert.deepEqual(endpoint.wallet,reference.wallet);
  assert.deepEqual(endpoint.rng,reference.rng);
  assert.equal(endpoint.wallet.score-fourth.facts.wallet.score,26);
  assert.equal(endpoint.wallet.publicity-fourth.facts.wallet.publicity,3);
  const after=evaluateStateValue(sanitizeHiddenInformationObservation(raw,m.owner(seat),{code:'hidden_card_reveal'},known),seat);
  assert.equal(after.total,256);
  m.restore(fourth.end);assert.deepEqual(m.save(),fourth.end);
  const analyzeActions=[m.act('analyze'),m.act('choose_target',a=>a.target.alienSlotId===1&&a.target.stateExtra)];
  assert(!m.save().session);
  analyzeActions.push(m.act('end_turn'));
  if(m.save().session)analyzeActions.push(m.act('accept_optional_effect',a=>a.target.choiceId.startsWith('skip:chong_task:')));
  assert.equal(m.facts().turn,12);
  assert(!m.save().session);
  const postAnalysis=evaluateStateValue(mask(m.owner(seat)),seat);
  assert.equal(postAnalysis.components.probePotential,19);
  const continuation=[];
  for(const expected of actions.slice(0,12)){
   const a=m.menu().find(a=>a.family===expected.family&&JSON.stringify(a.target)===JSON.stringify(expected.target));
   assert(a,expected.summary);continuation.push(m.apply(a));
  }
  close();
  const afterBoth=evaluateStateValue(mask(m.owner(seat)),seat),bothFacts=m.facts();
  assert.equal(bothFacts.turn,13);
  assert.equal(bothFacts.wallet.score,179);
  assert.equal(bothFacts.wallet.energy,0);
  assert.deepEqual(bothFacts.rng,endpoint.rng);
  m.restore(fourth.end);assert.deepEqual(m.save(),fourth.end);
  Object.assign(result,{endpoint,after,actions,analyzeFirst:{analyzeActions,postAnalysis,continuation,afterBoth,bothFacts},
    rootExact:true,fullScalarFormalCompactSwapExact:true,maskedUnknownCannotPay:true});
 }
 if(out)fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
}finally{m.dispose();}
