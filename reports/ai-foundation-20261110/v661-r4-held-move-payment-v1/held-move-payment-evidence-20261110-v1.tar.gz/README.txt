Run from the SETI repository root using the source of this report:
node <archive-dir>/verify-held-move-payment-20261110-v1.cjs <archive-dir>/knowledge-root-20261110-v1.json.gz <archive-dir>/launch-end-20261110-v1.json.gz <archive-dir>/reference-landing-20261110-v1.json.gz /private/tmp/seti-held-move-replayed.json yes
The output path must not exist. The direct and analysis-first lines use the same legal production inputs as recorded in the resulting evidence. The estimate retains only cards known at the original #272 or a card from its public Amiba display.
