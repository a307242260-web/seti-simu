# 第三轮宣传买牌后扫描：原生复放

在包含 `quietR3BluePickSource` 阿米巴单物种证明的源码根运行，`P` 为本档案解包目录：

```sh
(cd "$P" && shasum -a 256 -c SHA256SUMS)
node "$P/verify-324.cjs"
```

复放器从原生存档逐输入核对完整信封，不重新搜索。79 次固定结算的原生交叉核验可独立重建（此审计故意双执行，不能用其耗时衡量搜索性能）：

```sh
node "$P/audit-blue.cjs" randomizer/game/ai/analysis-port.js \
  "$P/formal-scan-pay-without-data-20261110-v1.json.gz" <新输出.gz>
```

`profile.cjs` 参数为分析端源码、上次宣传付款对照、输出；只用于记下每次真正提交的原生输入。用父提交 8dc26fe36 得到 324，使用本次源码得到 245。两个归档保留完整搜索图、原生提交的家族和动作、并在复放器核对首选与图一致。原生明细只保留序列、家族与会话类型，动作可由复盘见证重建；冷耗时以独立的 `resume.cjs` 验证。后者使用同一上次宣传付款对照。

`formal-parity.cjs` 参数为正式独立复盘检查点、正式保存、第三轮末端根、早期根、输出。前两份分别见 `v661-first3-independent-replay-20261109-v1.checkpoint.json` 与 V661 正式前三轮保存；末端根见正式第三轮留存报告的证据包，早期根见第 189 步提前分析报告的证据包。旧比较摘要已归档。所有实跑输出文件拒绝覆盖已存在结果。
