'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src).rows[0],m=open(d.start);
let e,q,menu,summary;
try{
 for(const u of d.actions.slice(0,11))m.apply(u.action);
 e=m.save();menu=m.menu();summary=short(m);
 const {checkpoint,...cold}=m.automatic();q=cold;
 assert(q.complete&&q.n<=256&&q.ms<=600);
}finally{m.dispose();}
const options=menu.filter(a=>['orange1','orange3','blue1'].includes(a.target.tileId));
assert(options.some(x=>x.target.tileId==='orange1'));
console.log('ranking',q.roots.map(x=>[menu.find(a=>a.actionId===x.actionId)?.summary,x.value]));
const branch=runCases(e,options.map(a=>[a.summary,h=>h.take(h.m.apply(a))]));
writeZ(out,{e,q,menu,summary,...branch});
