'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,writeZ}=require('./controlled-r3');
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [input,out]=process.argv.slice(2),profile=readZ(input),root=profile.root,rows={};
assert(!root.session);
const original=open(root),obs=original.owner('player-white'),menu=original.menu();original.dispose();
for(const name of ['ordinary','amiba','both']){
 const e=structuredClone(root),s=JSON.parse(e.committedState);
 function swap(list){assert(list.length>=3);[list[0],list[2]]=[list[2],list[0]];}
 if(name!=='amiba')swap(s.cards.drawPileCardIds);
 if(name!=='ordinary')swap(s.aliens.amiba.cardDeck);
 e.committedState=createStateStore(s).serialize().serialized;
 const m=open(e),port=createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});
 try{
  assert.deepEqual(m.owner('player-white'),obs);assert.deepEqual(m.menu(),menu);
  const search=createSearchAgent({seatId:'player-white',analysisPort:port}).decide({seatId:'player-white',legalActions:menu}).search;
  assert(search.complete&&!search.unresolved.length);assert.deepEqual(m.save(),e);
  for(const k of ['actionId','value','realization','preparationDebt','roots','lines','unresolved','candidates','sharedPrefixGraph'])assert.deepEqual(JSON.parse(JSON.stringify(search[k])),profile.search[k],name+'/'+k);
  const ms=search.rootAndSearchMilliseconds,n=search.diagnostics.nativeExecutions;
  assert.equal(n,245);assert(ms<=600);
  rows[name]={e,obs,menu,n,ms,value:search.value,actionId:search.actionId};
  console.log(name,n,ms,search.value);
 }finally{port.close();m.dispose();}
}
writeZ(out,rows);
