'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),Module=require('node:module');
const [src,file,out]=process.argv.slice(2),key=path.resolve('randomizer/game/ai/analysis-port.js');
const m=new Module(key,module);m.filename=key;m.paths=Module._nodeModulePaths(path.dirname(key));Module._cache[key]=m;
const s=fs.readFileSync(src,'utf8'),before='      loadedEnvelope = null;\n      const executeAt = now();';
assert.equal(s.split(before).length,2);
m._compile(s.replace(before,'      globalThis.recordNative(loadCapture(loadedEnvelope, comp), current);\n'+before)
.replace('    function executeCurrent(current) {','    function loadCapture(e,c){return e||c.lifecycle.save().envelope;}\n    function executeCurrent(current) {'),key);
m.loaded=true;
const {open,short,readZ,writeZ}=require('./controlled-r3');
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const root=readZ(file).rows[0].start,host=open(root),raw=[];
const port=m.exports.createAnalysisPort({composition:host.c,seatId:'player-white',maxCacheEntries:0});
globalThis.recordNative=(e,a)=>raw.push({e,a});
try{
 const search=createSearchAgent({seatId:'player-white',analysisPort:port}).decide({seatId:'player-white',legalActions:host.menu()}).search;
 assert(search.complete&&!search.unresolved.length);
 assert.deepEqual(host.save(),root);assert.equal(search.diagnostics.nativeExecutions,raw.length);
 const all={};for(const {a,e} of raw){
  const ss=e.session?.session,p=ss?.queue[0],k=p?.type? a.family+':'+p.type+':'+(p.payload?.options?.mode||''):a.family;
  all[k]=(all[k]||0)+1;
 }
 const top=Object.entries(all).sort((a,b)=>b[1]-a[1]);
 const summary=short(host),chosen=host.menu().find(a=>a.actionId===search.actionId);
 console.log(JSON.stringify({summary,chosen:chosen.summary,n:raw.length,ms:search.rootAndSearchMilliseconds,value:search.value,
  top,d:{...port.getDiagnostics(),search:search.diagnostics}},null,1));
 writeZ(out,{root,summary,chosen,top,search,port:port.getDiagnostics(),raw});
}finally{port.close();host.dispose();}
