'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ}=require('./controlled-r3');
const file=process.argv[2]||__dirname,load=n=>readZ(path.join(file,n+'-20261110-v1.json.gz'));
const a=load('324-profile'),b=load('324-blue-preview'),formal=load('324-formal-parity'),prior=load('second-scan-budget-formal-parity-admitted');
assert.deepEqual(a.root,b.root);
assert.equal(a.search.diagnostics.nativeExecutions,324);assert.equal(b.search.diagnostics.nativeExecutions,245);
assert.equal(a.search.diagnostics.transitions,324);assert.equal(b.search.diagnostics.transitions,324);
for(const k of ['actionId','value','realization','preparationDebt','roots','lines','unresolved','candidates','sharedPrefixGraph'])assert.deepEqual(a.search[k],b.search[k],k);
const proof=load('324-blue-native-proof'),hidden=load('324-hidden-blue');
assert.deepEqual(proof.count,{'blue-pick':23,'data-menu':28,'blue-pick-menu':28});
assert.equal(proof.rows.length,79);
assert.equal(Object.keys(formal).length,89);assert.deepEqual(Object.keys(formal),Object.keys(prior));
const changes=[];
for(const k of Object.keys(formal)){
 for(const p of ['a','roots','value','complete'])assert.deepEqual(formal[k][p],prior[k][p],k+'/'+p);
 if(prior[k].n!==formal[k].n)changes.push([k,prior[k].n,formal[k].n]);
 assert(formal[k].complete&&formal[k].n<=256&&formal[k].ms<=600,k);
}
assert.deepEqual(changes,[['early:193',226,224]]);
const original=open(a.root);
try{
 for(const d of Object.values(hidden)){
  assert.deepEqual(d.obs,original.owner('player-white'));assert.deepEqual(d.menu,original.menu());
  assert.equal(d.value,167);assert.equal(d.actionId,a.search.actionId);assert.equal(d.n,245);assert(d.ms<=600);
 }
}finally{original.dispose();}
const start=load('formal-scan-pay-without-data'),r3=load('324-blue-preview-resume'),
 prep=load('324-close-income'),research=load('324-after-scan-research'),r4=load('324-r4-roll-after-research');
let replays=0,inputs=0,autonomous=0,maxNative=0,maxMs=0;
function replay(e,steps,end,settled){
 const m=open(e);
 try{
  let passed=false;
  for(const u of steps){
   const a=u.action||u;
   if(u.n!==undefined){
    assert(u.n<=256&&u.ms<=600);autonomous++;maxNative=Math.max(maxNative,u.n);maxMs=Math.max(maxMs,u.ms);
   }
   if(settled&&a.family==='pass'&&a.actorId==='player-white'&&m.facts().round===3){
    assert.deepEqual(m.save(),settled.state);passed=true;
   }
   m.apply(a);inputs++;
  }
  if(settled)assert(passed);
  assert.deepEqual(m.save(),end);replays++;
 }finally{m.dispose();}
}
function group(e,g){
 for(const r of g.rows){replay(e,r.prefix,r.start);replay(r.start,r.actions,r.end,r.settled);}
 assert.deepEqual(g.failures,[]);
}
assert.equal(start.rows[0].stop.n,324);assert.deepEqual(start.rows[0].actions,[]);
replay(start.root,start.rows[0].prefix,a.root);
group(a.root,r3);
for(const [k,g] of Object.entries(prep.cases))group(prep.anchors[k],g);
group(research.e,research);
assert.deepEqual([r3.rows[0].settled.summary.wallet[0],r3.rows[0].settled.summary.established],[109,149]);
assert.deepEqual(Object.values(r4).map(r=>[r.checkpoints[1].s.wallet[0],r.checkpoints[1].s.established]),[[133,181],[136,190],[138,192]]);
for(const r of Object.values(r4))replay(r.e,r.actions,r.end);
console.log(JSON.stringify({replays,inputs,autonomous,maxNative,maxMs,nativeProofs:proof.rows.length,formalColdRoots:Object.keys(formal).length}));
