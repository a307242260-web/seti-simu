'use strict';
const {open,readZ,writeZ,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src).rows[0],m=open(d.start),anchors={};
try{for(const [i,u] of d.actions.entries()){if([6,14,29].includes(i))anchors[i]=m.save();m.apply(u.action);}}
finally{m.dispose();}
const put=h=>{h.act('place_data');h.act('choose_target',a=>a.target.target==='computer');};
const cases={};
cases[6]=runCases(anchors[6],[['scan-keep-data',h=>{put(h);put(h);h.act('end_turn');}]]);
cases[14]=runCases(anchors[14],[['blue4-fill-sixth',h=>{put(h);h.act('end_turn');}]]);
writeZ(out,{anchors,cases});
