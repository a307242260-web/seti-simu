'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const [sourceFile,stop,out]=process.argv.slice(2),src=path.resolve('randomizer/game/ai/analysis-port.js');
const m=new Module(src,module);
m.filename=src;m.paths=Module._nodeModulePaths(path.dirname(src));Module._cache[src]=m;
const use=(kind)=>`
        if(readIdentityState(stored.envelope).turn.roundNumber===3){
          restoreEnvelope(stored.envelope,true);
          const real=executeCurrent(requested);
          const raw=finishChild(real.before,real.result,movementPlanning?nextMovementIntent(node,requested):null,
            stored.resourceControl&&resourceStep(node,stored.resourceControl.goal,stored.resourceControl.operation).kind!=="complete"?stored.resourceControl:null,
            stored.informationBarrier,requested,stored);
          globalThis.auditR3(${JSON.stringify(kind)},stored.envelope,requested,nodes.get(child),nodes.get(raw),child,raw,
            ()=>valueObservation(child),()=>valueObservation(raw));
        }
`;
let source=fs.readFileSync(sourceFile,'utf8');
function after(a,kind){assert.equal(source.split(a).length,2,kind);source=source.replace(a,a+use(kind));}
after('provedBluePickSettlements++;','blue-pick');
after('null, stored.informationBarrier, requested, stored, {envelope:menuPreview, inspection});','data-menu');
after('null,stored.informationBarrier,requested,stored,{envelope:rewardMenu,inspection});','blue-pick-menu');
m._compile(source,src);m.loaded=true;
const {open,readZ,writeZ}=require('./controlled-r3');
const {evaluateStateValue}=require(path.resolve('randomizer/game/ai/state-value'));
const rows=[],fixtures=new Map();let label;
globalThis.auditR3=(kind,root,action,pred,native,a,b,viewA,viewB)=>{
 const norm=(o,e)=>JSON.parse(JSON.stringify(o??null).split(e?.session?.sessionId||'__no_session__').join('effect-session-X'));
 assert.deepEqual(norm(pred.envelope.session,pred.envelope.session),norm(native.envelope.session,native.envelope.session),kind+' '+action.summary+' session');
 assert.deepEqual(JSON.parse(pred.envelope.committedState),JSON.parse(native.envelope.committedState),kind+' '+action.summary+' committed');
 assert.deepEqual(norm(pred.informationBarrier,pred.envelope.session),norm(native.informationBarrier,native.envelope.session));
 assert.deepEqual([a.status,a.boundary,a.legalActions],[b.status,b.boundary,b.legalActions]);
 const av=viewA(),bv=viewB();assert.deepEqual(av,bv);
 assert.deepEqual(evaluateStateValue(av,action.actorId),evaluateStateValue(bv,action.actorId));
 if(!fixtures.has(kind))fixtures.set(kind,{root,action,end:native.envelope,barrier:b.boundary,menu:b.legalActions});
 rows.push({label,kind,action:action.actionId,status:a.status});
};
for(const [name,e] of [['formal-206-paid',readZ(stop).rows[0].start]]){
 label=name;const k=open(e);
 try{const r=k.automatic();assert(r.complete);assert.deepEqual(k.save(),e);}
 finally{k.dispose();}
}
const count={};for(const r of rows)count[r.kind]=(count[r.kind]||0)+1;
console.log(count);writeZ(out,{rows,fixtures:Object.fromEntries(fixtures),count});
