'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),original=readZ(src).rows[0],e=original.start,m=open(e);
try{
 const q=m.automatic();assert(q.complete&&q.n<=256&&q.ms<=600);
 assert.equal(q.value,167);assert.equal(q.a.family,'scan');
 console.log('cold gate',q.n,q.ms,q.value,q.a.summary,short(m));
}finally{m.dispose();}
writeZ(out,{root:e,...runCases(e,[['publicity-paid-autonomous',()=>{}]])});
