'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),{open,readZ,writeZ}=require('./controlled-r3');
const [ledger,save,prior,out]=process.argv.slice(2),p=readZ(prior),v=JSON.parse(fs.readFileSync(ledger)),s=JSON.parse(fs.readFileSync(save)),m=open(v.roundStarts[1].envelope),rows={};
try{
 const keys=new Map(Object.keys(p).map(k=>[Number(k.split(':')[1]),k]));assert.equal(keys.size,Object.keys(p).length);
 for(let i=v.roundStarts[1].beforeInput;i<=s.replaySteps.length;i++){
  const k=keys.get(i);
  if(k){const {a,roots,n,ms,value,complete}=m.automatic();rows[k]={a,roots,n,ms,value,complete};}
  m.apply(s.replaySteps[i-1].action);
 }
 assert.deepEqual(m.save(),v.envelope);assert.deepEqual(Object.keys(rows).sort(),Object.keys(p).sort());
 for(const [k,a] of Object.entries(rows)){
  for(const f of ['a','roots','value','complete'])assert.deepEqual(JSON.parse(JSON.stringify(a[f])),p[k][f],k+'/'+f);
  assert(a.complete&&a.n<=256&&a.ms<=600,k);
 }
 console.log(Object.keys(rows).length,Math.max(...Object.values(rows).map(q=>q.n)),Math.max(...Object.values(rows).map(q=>q.ms)),Object.entries(rows).filter(([k,q])=>q.n!==p[k].n).map(([k,q])=>[k,p[k].n,q.n]));
 writeZ(out,rows);
}finally{m.dispose();}
