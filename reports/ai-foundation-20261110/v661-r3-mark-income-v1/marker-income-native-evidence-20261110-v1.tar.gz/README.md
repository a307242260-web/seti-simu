# 第三轮标记和收入对照复现

在具备当前 `assets` 的 Production 源码根目录运行 `node <解包路径>/verify-markers.cjs`。它只重放归档动作并验证终点、已提交决定的门槛和搜索图差分，不重跑标准实验。所有脚本输出均用新路径。

基线代码为 `359643269`（运行时与 `67d3118d8` 相同）。在基线上按各脚本首行的参数读取归档中的原始输入，依次运行 `paired-marks.cjs`、`roll-paired-marks.cjs`、`natural-marks.cjs`、`trace-marks.cjs`、`scan-handoff.cjs`。`profile-formal-c.cjs` 以 analysis-port 源码路径、`marker-formal-and-trace`、新输出为输入，可以重新生成带全部实际提交的 profile；归档的两份 `summary` 省略了体积较大的逐次原始提交信封。用新版源码运行 `resume-formal-c.cjs`、`audit-data.cjs`、`hidden-formal-c.cjs` 和 `parity.cjs`，分别复查实际续跑、原生菜单／放置证明、暗牌不变性和原标准冷根。`audit-data.cjs` 会额外执行原生输入，只做差分验证，其提交数和耗时不用于验收。
