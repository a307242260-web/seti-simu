'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),g=readZ(src),rows={};
for(const f of g.formal){
 const before=f.rows.find(x=>x.label==='final:c');
 assert.equal(before.stop.n,288);assert(!before.settled);
 rows[f.step]={e:before.end,...runCases(before.end,[['continue-c',()=>{}]])};
}
writeZ(out,rows);
