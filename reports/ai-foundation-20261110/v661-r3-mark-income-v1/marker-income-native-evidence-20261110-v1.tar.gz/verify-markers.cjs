'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ}=require('./controlled-r3');
const dir=process.argv[2]||__dirname,load=n=>readZ(path.join(dir,n+'-20261110-v1.json.gz'));
const w=load('marker-worlds-r3'),r4=load('marker-worlds-r4'),n=load('marker-natural'),t=load('marker-formal-and-trace'),handoff=load('marker-scan-handoff');
const before=load('marker-formal-c-profile-summary'),after=load('marker-formal-c-candidate-summary'),p=load('marker-formal-c-native-proof');
const resumes=load('marker-formal-c-resume'),parity=load('marker-formal-parity'),hidden=load('marker-formal-c-hidden');
let checks=0,inputs=0,decisions=0,maxNative=0,maxMs=0;
const pair=s=>[s.wallet[0],s.established];
function replay(e,acts,end,settled){
 const m=open(e);
 try{
  let sawPass=false;
  for(const u of acts){const a=u.action||u;
   if(u.n!==undefined){assert(u.n<=256&&u.ms<=600);decisions++;maxNative=Math.max(maxNative,u.n);maxMs=Math.max(maxMs,u.ms);}
   if(settled&&a.actorId==='player-white'&&a.family==='pass'&&m.facts().round===3){assert.deepEqual(m.save(),settled.state);sawPass=true;}
   m.apply(a);inputs++;
  }
  if(settled)assert(sawPass);
  assert.deepEqual(m.save(),end);checks++;
 }finally{m.dispose();}
}
function group(e,g){
 assert.deepEqual(g.failures,[]);
 for(const a of g.rows){replay(e,a.prefix,a.start);replay(a.start,a.actions,a.end,a.settled);}
}
for(const [key,g] of Object.entries(w.rows)){
 replay(g.e,g.prep,g.mark);group(g.mark,g);
 for(const [i,a] of g.rows.entries()){
  assert.deepEqual(pair(a.settled.summary),i?[79,116]:[83,123]);
  const z=r4[key+'-'+a.label];assert.equal(z.stop,'two-turns');replay(z.e,z.actions,z.end);
  assert.deepEqual(pair(z.checkpoints[1].s),i?[114,163]:[108,156]);
 }
}
group(n.teacherRoot,n.teacher);assert.deepEqual(n.teacher.rows.map(r=>pair(r.settled.summary)),[[89,118],[89,126]]);
group(handoff.e,handoff);
assert.deepEqual(handoff.rows.map(r=>r.settled.summary.income[1]),[3,3,3,3,3,3,4,3]);
for(const g of t.formal){
 const start=n.formal.find(f=>f.step===g.step).e;group(start,g);
 const r=g.rows.find(r=>r.label==='final:c'),finished=resumes[g.step];
 assert.equal(r.stop.n,288);assert.deepEqual(finished.e,r.end);group(finished.e,finished);
 assert.deepEqual(pair(finished.rows[0].settled.summary),[105,134]);
}
assert.deepEqual(before.root,after.root);assert.equal(before.search.diagnostics.nativeExecutions,288);assert.equal(after.search.diagnostics.nativeExecutions,247);
for(const k of ['actionId','value','realization','preparationDebt','roots','lines','unresolved','candidates','sharedPrefixGraph'])assert.deepEqual(before.search[k],after.search[k],k);
assert.deepEqual(p.count,{settle:23,open:27});assert.equal(Object.keys(parity).length,89);assert.equal(Object.keys(hidden).length,3);
console.log({checks,inputs,decisions,maxNative,maxMs,nativeProofs:p.rows.length,formalParity:Object.keys(parity).length});
