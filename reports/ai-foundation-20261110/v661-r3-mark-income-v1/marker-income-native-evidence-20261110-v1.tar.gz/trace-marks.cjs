'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,writeZ,runCases}=require('./controlled-r3');
const end=require(path.resolve('randomizer/game/end-game-scoring')),effects=require(path.resolve('randomizer/game/cards/effects'));
const local=require(path.resolve('randomizer/game/ai/local-decision-plans'));
const [natural,worlds,out]=process.argv.slice(2),d=readZ(natural),w=readZ(worlds),seat='player-white';
function fields(m){
 const s=structuredClone(m.state()),p=s.players.players.find(q=>q.id===seat),current=s.turn.currentPlayerId;
 const scores=end.computePlayerFinalScore({...s,players:s.players.players,currentPlayer:p,cardEffects:effects,getCardTypeCode:c=>effects.getRuntimeCardTypeCode(c,effects.getCardModel(c)?.cardType)},p);
 return {turn:s.turn.turnNumber,round:s.turn.roundNumber,owner:current,score:p.resources.score,income:p.income,
  tasks:p.completedTaskCount,earned:scores.tileScoresById,
  reserve:p.reservedCards.map(c=>({card:c.cardId,id:c.id,triggers:c.triggers,cardState:c.cardState,taskProgress:c.taskProgress}))};
}
function trace(e,steps,limit){
 const m=open(e),start=fields(m),record=[];
 try{
  let prev=start;
  for(const a of steps){
   m.apply(a);const next=fields(m);
   if(next.round>limit)break;
   if(prev.tasks!==next.tasks||JSON.stringify(prev.earned)!==JSON.stringify(next.earned)||JSON.stringify(prev.income)!==JSON.stringify(next.income))record.push({a,prev,next});
   prev=next;
  }
  return {start,record};
 }finally{m.dispose();}
}
const traces={},formal=[];
for(const r of d.teacher.rows)traces['teacher-'+r.label]=trace(d.teacherRoot,[...r.prefix,...r.actions.map(x=>x.action)],3);
for(const [world,g] of Object.entries(w.rows))for(const r of g.rows)traces[world+'-'+r.label]=trace(g.mark,[...r.prefix,...r.actions.map(x=>x.action)],3);
for(const f of d.formal){
 const m=open(f.e);let greedy;
 try{greedy=local.finalMark({state:m.state(),seatId:seat,actions:m.menu()});}finally{m.dispose();}
 // Use the archived autonomous reference for the chosen mark; only run the alternative at this exact root.
 const candidates=f.scores.filter(k=>k!==f.taken.target.choiceId).map(k=>[k,h=>h.act('choose_target',a=>a.target.choiceId===k)]);
 const r=runCases(f.e,candidates);assert.deepEqual(r.failures,[]);formal.push({step:f.step,greedy,...r});
 for(const x of r.rows)traces['formal-'+f.step+'-'+x.label]=trace(f.e,[...x.prefix,...x.actions.map(a=>a.action)],3);
}
for(const [k,t] of Object.entries(traces))console.log(k,JSON.stringify(t.record.map(x=>[x.a.summary,x.prev.tasks,x.next.tasks,x.next.earned])));
writeZ(out,{traces,formal});
