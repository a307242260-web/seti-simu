'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,short,readZ,writeZ,runCases}=require('./controlled-r3');
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const local=require(path.resolve('randomizer/game/ai/local-decision-plans'));
const [hiddenFile,markerFile,incomeFile,out]=process.argv.slice(2);
const h=readZ(hiddenFile).original,d=readZ(markerFile),branch=readZ(incomeFile).rows[20].rows[1];
const markerAt=h.executed.findIndex(a=>a.target.choiceId==='final:a');
assert(markerAt>0);
const pendingEnd=branch.prefix.findIndex(a=>a.target.choiceId==='final:a');assert(pendingEnd>0);
const remaining=branch.prefix.slice(pendingEnd+1,-1),rows={};
function native(m,a){
 const available=m.menu().filter(b=>b.actorId===a.actorId&&b.family===a.family&&JSON.stringify(b.target)===JSON.stringify(a.target));
 assert.equal(available.length,1,a.summary);return m.apply(available[0]);
}
const keys=['draw-b16','salary-dlc17','next-alien-8','draw-and-next-alien'];
const norm=e=>JSON.parse(JSON.stringify(e).split(e.session?.session?.sessionId||'__no_session__').join('effect-session-X'));
function diff(a,b,path='$'){
 if(Object.is(a,b))return;
 if(!a||!b||typeof a!=='object'||typeof b!=='object')return [path,String(a).slice(0,160),String(b).slice(0,160)];
 for(const k of new Set([...Object.keys(a),...Object.keys(b)])){const d=diff(a[k],b[k],path+'.'+k);if(d)return d;}
}
let original;
for(const key of ['original-root',...keys]){
 const e=structuredClone(h.e),s=JSON.parse(e.committedState);
 const swap=(a,i,j)=>{assert(a[i]!==a[j]);[a[i],a[j]]=[a[j],a[i]];};
 assert.deepEqual(s.cards.drawPileCardIds.slice(0,6),['dlc_24.png','dlc_20.png','dlc_19.png','b_16.webp','dlc_17.png','dlc_16.png']);
 assert.deepEqual(s.aliens.amiba.cardDeck.slice(0,4),[5,2,8,4]);
 if(key==='draw-b16'||key==='draw-and-next-alien')swap(s.cards.drawPileCardIds,2,3);
 if(key==='salary-dlc17')swap(s.cards.drawPileCardIds,3,4);
 if(key==='next-alien-8'||key==='draw-and-next-alien')swap(s.aliens.amiba.cardDeck,1,2);
 e.committedState=createStateStore(s).serialize().serialized;
 const m=open(e);
 let mark,obs,menu,summary,q,greedy,prep=[];
 try{
  prep=h.executed.slice(0,markerAt).map(a=>native(m,a));
  mark=m.save();obs=m.owner('player-white');menu=m.menu();summary=short(m);
  greedy=local.finalMark({state:m.state(),seatId:'player-white',actions:menu});
  if(key==='original-root'){
   assert.equal(diff(norm(mark),norm(d.root)),undefined);original={mark,obs,menu,summary,greedy};continue;
  }
  const {checkpoint,...cold}=m.automatic();q=cold;
  assert(q.complete&&q.n<=256&&q.ms<=600);
  assert.deepEqual(obs,original.obs);assert.deepEqual(menu,original.menu);
  assert.deepEqual(greedy,original.greedy);
  for(const f of ['a','value','n','roots','complete'])assert.deepEqual(q[f],d.q[f],key+'/'+f);
  assert.deepEqual(m.save(),mark);
 }finally{m.dispose();}
 const cases=runCases(mark,['a','c'].map(mark=>[mark,h=>{
  h.act('choose_target',a=>a.target.choiceId==='final:'+mark);
  remaining.forEach(a=>h.take(native(h.m,a)));h.cut('same-income-menu');
 }]));
 assert.deepEqual(cases.failures,[]);
 rows[key]={e,prep,mark,obs,menu,summary,q,greedy,...cases};
}
writeZ(out,{original,rows});
