'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const {open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const [worlds,formalLedger,formalSave,out]=process.argv.slice(2);
const d=readZ(worlds),e=d.original.mark;
const candidates=['a','c'].map(mark=>[mark,h=>h.act('choose_target',a=>a.target.choiceId==='final:'+mark)]);
const teacher=runCases(e,candidates);assert.deepEqual(teacher.failures,[]);
const {roundStarts,envelope}=JSON.parse(fs.readFileSync(formalLedger)),{replaySteps}=JSON.parse(fs.readFileSync(formalSave));
const start=roundStarts['3'],m=open(start.envelope),formal=[];
try{
 for(let i=start.beforeInput-1;i<replaySteps.length;i++){
  const a=replaySteps[i].action;
  if(a.target?.choiceId?.startsWith('final:')&&a.actorId==='player-white'){
   const scores=m.menu().map(a=>a.target.choiceId);
   formal.push({step:i+1,e:m.save(),s:short(m),taken:a,scores});
   console.log('formal mark',i+1,a.target.choiceId,JSON.stringify([short(m),scores]));
  }
  m.apply(a);
 }
 assert.deepEqual(m.save(),envelope);
}finally{m.dispose();}
writeZ(out,{teacherRoot:e,teacher,formal});
