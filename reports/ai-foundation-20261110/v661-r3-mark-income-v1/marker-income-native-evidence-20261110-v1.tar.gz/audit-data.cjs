'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),Module=require('node:module');
const [infile,out]=process.argv.slice(2),src=path.resolve('randomizer/game/ai/analysis-port.js'),m=new Module(src,module);
m.filename=src;m.paths=Module._nodeModulePaths(path.dirname(src));Module._cache[src]=m;
let source=fs.readFileSync(src,'utf8');
const inject=kind=>`
        const proofState=readIdentityState(stored.envelope),proofOwner=proofState.players.players.find(p=>p.id===seatId);
        if(quietR3AmibaData(proofState,proofOwner)){
          restoreEnvelope(stored.envelope,true);
          const real=executeCurrent(requested);
          const raw=finishChild(real.before,real.result,movementPlanning?nextMovementIntent(node,requested):null,
            null,stored.informationBarrier,requested,stored);
          globalThis.auditData(${JSON.stringify(kind)},stored.envelope,requested,nodes.get(child),nodes.get(raw),child,raw,
            ()=>valueObservation(child),()=>valueObservation(raw));
        }
`;
for(const [marker,kind] of [
 ['null, stored.informationBarrier, requested, stored, {envelope:menuPreview, inspection});','open'],
 ['const child = finishProvedCommittedState(node, stored, requested, state);\n        return rememberPrefix','settle']]){
 assert.equal(source.split(marker).length,2,kind);
 source=source.replace(marker,kind==='open'?marker+inject(kind):marker.replace('\n        return rememberPrefix',inject(kind)+'\n        return rememberPrefix'));
}
m._compile(source,src);m.loaded=true;
const {open,readZ,writeZ}=require('./controlled-r3'),{evaluateStateValue}=require(path.resolve('randomizer/game/ai/state-value'));
const srcProfile=readZ(infile),rows=[],examples={};
globalThis.auditData=(kind,root,action,pred,native,a,b,viewA,viewB)=>{
 const norm=(o,e)=>JSON.parse(JSON.stringify(o??null).split(e?.session?.sessionId||'__no_session__').join('effect-session-X'));
 assert.deepEqual(pred.envelope.committedState,native.envelope.committedState,kind+' committed');
 assert.deepEqual(norm(pred.envelope.session,pred.envelope.session),norm(native.envelope.session,native.envelope.session),kind+' session');
 assert.deepEqual(norm(pred.informationBarrier,pred.envelope.session),norm(native.informationBarrier,native.envelope.session),kind+' knowledge');
 assert.deepEqual([a.status,a.boundary,a.legalActions],[b.status,b.boundary,b.legalActions],kind+' native menu');
 const av=viewA(),bv=viewB();assert.deepEqual(av,bv);assert.deepEqual(evaluateStateValue(av,action.actorId),evaluateStateValue(bv,action.actorId));
 if(!examples[kind])examples[kind]={root,action,end:native.envelope};
 rows.push({kind,action:action.actionId,target:action.target,status:a.status});
};
const host=open(srcProfile.root);
try{const q=host.automatic();assert(q.complete);assert.deepEqual(JSON.parse(JSON.stringify(q.roots)),srcProfile.search.roots);assert.equal(q.value,srcProfile.search.value);}
finally{host.dispose();}
const count=rows.reduce((a,x)=>(a[x.kind]=(a[x.kind]||0)+1,a),{});console.log(count);writeZ(out,{rows,examples,count});
