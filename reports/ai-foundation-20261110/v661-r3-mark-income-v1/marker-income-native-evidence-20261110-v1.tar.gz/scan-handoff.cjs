'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,runCases}=require('./controlled-r3');
const [worlds,out]=process.argv.slice(2),g=readZ(worlds),e=g.original.mark;
const controlled=g.rows['draw-b16'].rows.find(x=>x.label==='c').prefix;
const samples=[[2,'only-start-scan'],[4,'same-two-scan-targets'],[5,'resolve-scan'],[9,'scan-and-fill-computer'],[10,'scan-then-end-turn'],[11,'start-analysis-after-scan'],[14,'scan-and-get-visible-a5'],[15,'plus-spend-a7-corner']];
const cases=samples.map(([length,label])=>[label,h=>{
 for(const a of controlled.slice(0,length)){
  const b=h.m.menu().find(b=>b.actorId===a.actorId&&b.family===a.family&&JSON.stringify(a.target)===JSON.stringify(b.target));
  assert(b,a.summary);h.take(h.m.apply(b));
 }
}]);
const r=runCases(e,cases);assert.deepEqual(r.failures,[]);writeZ(out,{e,...r});
