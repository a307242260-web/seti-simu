'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),Module=require('node:module'),old=Module._extensions['.js'];
Module._extensions['.js']=(mod,file)=>{
 if(!file.endsWith('/game/ai/analysis-port.js'))return old(mod,file);
 const src=fs.readFileSync(file,'utf8');
 const marker='redundantCargoClaim,redundantQuietFinalClaim,proveDeferredFinalDataClaim';
 assert.equal(src.split(marker).length,2);mod._compile(src.replace(marker,'redundantCargoClaim,redundantQuietFinalClaim:()=>null,proveDeferredFinalDataClaim'),file);
};
