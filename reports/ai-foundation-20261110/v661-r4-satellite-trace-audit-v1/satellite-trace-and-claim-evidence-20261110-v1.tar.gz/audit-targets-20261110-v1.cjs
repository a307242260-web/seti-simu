'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const old=Module._extensions['.js'],hits=new Map();
globalThis.auditTarget=(n, id, stored)=>{
 const a=n.legalActions.find(x=>x.actionId===id);
 if(!a||!['choose_target','end_turn','choose_card'].includes(a.family))return;
 const s=stored.envelope.session?.session;
 const head=s?.queue?.[0],source=s?.journal?.actions?.[0]?.action;
 const key=JSON.stringify([a.actionId,a.family,a.target,head?.type??null,head?.payload?.cardEffect?.type??null,source?.family??null,stored.informationBarrier?.code??null]);
 let row=hits.get(key);
 if(!row){
   row={id:a.actionId,family:a.family,target:a.target,summary:a.summary,head:head?.type??null,
    effect:head?.payload?.cardEffect?.type??null,source:source?.family??null,barrier:stored.informationBarrier?.code??null,total:0};hits.set(key,row);
 }
 row.total++;
};
Module._extensions['.js']=(mod,file)=>{
 if(!file.endsWith('/game/ai/analysis-port.js'))return old(mod,file);
 const src=fs.readFileSync(file,'utf8'),mark='    function expand(node, actionId, previewOnly = false) {\n      const stored = nodes.get(node);';
 assert.equal(src.split(mark).length,2);mod._compile(src.replace(mark,mark+'\n      globalThis.auditTarget(node,actionId,stored);'),file);
};
const {open,seat}=require(process.argv[2]),root=JSON.parse(fs.readFileSync(process.argv[3])).checkpoint,m=open(root);
try{
 const decision=m.automatic();
 assert(decision.complete);assert.deepEqual(m.save(),root);
 const rows=[...hits.values()].sort((a,b)=>b.total-a.total);
 const evidence={action:decision.a.actionId,value:decision.value,rootExact:true,rows};
 fs.writeFileSync(process.argv[4],JSON.stringify(evidence,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({action:evidence.action,value:evidence.value,entries:rows.length,top:rows.slice(0,30)}));
}finally{m.dispose();}
