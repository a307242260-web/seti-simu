'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const old=Module._extensions['.js'],rows=[];
globalThis.earlyClaim=(state,node,early,policy)=>{
 const p=state.players.players.find(p=>p.id==='player-white');
 rows.push({before:node.legalActions.map(a=>[a.family,a.target?.tradeId??a.payload?.kind??null]),
  after:early.legalActions.map(a=>[a.family,a.target?.tradeId??a.payload?.kind??null]),
  retained:policy?.actions.map(a=>a.family),plans:policy?.plans.map(a=>a.goal.kind),boundary:early.boundary,
  resources:p.resources,computer:p.dataState.placedTokens.map(x=>[x.placementKind,x.placementSlot,x.blueSlot])});
};
Module._extensions['.js']=(mod,file)=>{
 if(!file.endsWith('/game/ai/analysis-port.js'))return old(mod,file);
 const src=fs.readFileSync(file,'utf8'),marker='      const policy=stableFinalClaimPolicy(early);';
 assert.equal(src.split(marker).length,2);mod._compile(src.replace(marker,marker+'\n      globalThis.earlyClaim(readIdentityState(nodes.get(early).envelope),node,early,policy);'),file);
};
const {open}=require(process.argv[2]),root=JSON.parse(fs.readFileSync(process.argv[3])).checkpoint,m=open(root);
try{
 const q=m.automatic();assert(q.complete);assert.deepEqual(m.save(),root);
 fs.writeFileSync(process.argv[4],JSON.stringify({action:q.a.actionId,value:q.value,rows},null,2)+'\n',{flag:'wx'});
}finally{m.dispose();}
