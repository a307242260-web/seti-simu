import gzip,json,os,statistics,subprocess,sys
from pathlib import Path
src,w,t=map(Path,sys.argv[1:])
dest=t/'trace-ab-20261110-v1';dest.mkdir()
rows=[]
for n in range(1,6):
 for mode,on in ([('control','0'),('pruned','1')] if n%2 else [('pruned','1'),('control','0')]):
  stem=dest/f'{mode}-s{n}-20261110-v1';out=Path(str(stem)+'.json.gz')
  with Path(str(stem)+'.log').open('x') as log:
   subprocess.run(['node','--require',str(t/'diagnose-satellite-trace-savings-20261110-v1.cjs'),
     str(w/'trace-satellite-graph-20261110-v1.cjs'),str(w/'native-compact-20261110-v1.cjs'),str(w/'satellite-checkpoint-20261110-v1.json'),str(out)],
    cwd=src,stdout=log,check=True,env=dict(os.environ,SETI_TRACE_AUDIT=str(t/'satellite-trace-dominance-20261110-v1.json'),
     SETI_TRACE_DIAGNOSTIC=on,SETI_TRACE_META=str(stem)+'.meta.json'))
  q=json.load(gzip.open(out));assert q['complete'] and not q['unresolved']
  ranking=[{k:r.get(k) for k in ('actionId','value','realization','preparationDebt')} for r in q['roots']]
  rows.append(dict(mode=mode,sample=n,ms=q['rootAndSearchMilliseconds'],rank=ranking,selected=q['actionId'],value=q['value'],
                    graph=q['diagnostics']['graphNodes'],inputs=q['diagnostics']['nativeExecutions']))
assert all(q['rank']==rows[0]['rank'] for q in rows)
assert all((q['selected'],q['value'])==(rows[0]['selected'],rows[0]['value']) for q in rows)
summary={m:{k:statistics.median(q[k] for q in rows if q['mode']==m) for k in ('ms','inputs','graph')} for m in ('control','pruned')}
print(summary)
(t/'trace-diagnostic-ab-summary-20261110-v1.json').write_text(json.dumps({'diagnosticOnly':True,'summary':summary,'rows':rows},ensure_ascii=False,indent=2)+'\n')
