'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),Module=require('node:module'),{isDeepStrictEqual:same}=require('node:util');
const old=Module._extensions['.js'],seen=new Set(),saved=[];
const audit=JSON.parse(fs.readFileSync(process.argv[4]));
globalThis.captureTracePair=(node,stored)=>{
 const e=stored.envelope, actions=node.legalActions;
 if(e.session?.session?.queue?.[0]?.type!=='science_domain_alien_trace'||seen.has(e))return;
 const pairs=Object.entries(audit.pairs).flatMap(([kind,{actions:ids}])=>{
   const both=ids.map(id=>actions.find(a=>a.actionId===id));return both.every(Boolean)?[{kind,both}]:[];
 });
 if(!pairs.length)return;
 seen.add(e);saved.push({e,pairs});
};
Module._extensions['.js']=(mod,file)=>{
 if(!file.endsWith('/game/ai/analysis-port.js'))return old(mod,file);
 const src=fs.readFileSync(file,'utf8'),marker='      const spec=result&&freeze(result);localSpecs.set(node,spec);return spec;';
 assert.equal(src.split(marker).length,2);mod._compile(src.replace(marker,'      if(!result)globalThis.captureTracePair(node,stored);\n'+marker),file);
};
const {open}=require(process.argv[2]),root=JSON.parse(fs.readFileSync(process.argv[3])).checkpoint,m=open(root),replay=open(root);
function diff(x,y,k='',out=[]){
 if(same(x,y))return out;
 if(!x||!y||typeof x!=='object'||typeof y!=='object'){out.push(k);return out;}
 for(const key of new Set([...Object.keys(x),...Object.keys(y)]))diff(x[key],y[key],k+'.'+key,out);
 return out;
}
function take(source,a){
 const e=JSON.parse(JSON.stringify(source)),r=replay.c.lifecycle.restore(e);
 if(!r.ok)throw Error('TRACE_SOURCE_RESTORE '+JSON.stringify(r).slice(0,700));
 replay.apply(a);
 const end=replay.save(),s=end.session?.session;
 const actions=replay.menu();
 return {state:replay.state(),end,actions,session:s?.queue?.map(e=>[e.type,e.payload]),menu:actions.map(a=>a.actionId),barrier:s?.irreversibleBarrier?.code??null};
}
try{
 const q=m.automatic();assert(q.complete);assert.deepEqual(m.save(),root);
 const report=[];
 for(const {e,pairs} of saved){
   const s=e.session.session;
   for(const {kind,both} of pairs){
     const [low,high]=both.map(a=>take(e,a));
     const score=side=>side.state.players.players.find(p=>p.id==='player-white').resources.score;
     const onlyHigh=high.menu.filter(k=>!low.menu.includes(k)),onlyLow=low.menu.filter(k=>!high.menu.includes(k));
     let follow=null;
     if(onlyHigh.length===1&&onlyLow.length===1&&onlyHigh[0]===both[0].actionId&&onlyLow[0]===both[1].actionId){
       const x=take(low.end,low.actions.find(a=>a.actionId===onlyLow[0])),y=take(high.end,high.actions.find(a=>a.actionId===onlyHigh[0]));
       follow={scoreDelta:score(y)-score(x),sameMenu:same(x.menu,y.menu),sameEffectQueue:same(x.session,y.session),
         sameBarrier:x.barrier===y.barrier,changed:diff(y.state,x.state)};
     }
     report.push({kind,follow,origin:s.journal.actions[0].action.family,sourceTail:s.queue.slice(1).map(x=>x.type),
       delta:score(high)-score(low),sameMenu:same(high.menu,low.menu),sameEffectQueue:same(high.session,low.session),
       sameBarrier:high.barrier===low.barrier,changed:diff(high.state,low.state),queueChanged:diff(high.session,low.session),menuOnlyHigh:high.menu.filter(k=>!low.menu.includes(k)),menuOnlyLow:low.menu.filter(k=>!high.menu.includes(k))});
   }
 }
 assert.deepEqual(m.save(),root);
 assert(report.length>0);
 fs.writeFileSync(process.argv[5],JSON.stringify({rootExact:true,report},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({cases:report.length,checkedNativeInputs:report.length*2}));
}finally{m.dispose();replay.dispose();}
