from pathlib import Path
from collections import Counter, defaultdict
import json,gzip,sys
source,action_source,dest=map(Path,sys.argv[1:])
q=json.load(gzip.open(source))
actions=json.loads(action_source.read_text())['rows']
positions={}
for row in actions:
    target=row['target']
    if row['head']!='science_domain_alien_trace' or not target or target.get('traceType')!='pink' or not target.get('position'):
        continue
    k=(target['speciesId'],target['position'])
    prior=positions.setdefault(k,row['id'])
    assert prior==row['id']
nodes={n['node']:n for n in q['lines']}
cases={}
removed=set()
for species,low,high in (('amiba',1,2),('amiba',3,4),('chong',1,2)):
    ids=[positions[(species,i)] for i in (low,high)]
    rows=[]
    for index,node in nodes.items():
        edges={edge['actionId']:edge for edge in node['edges']}
        if not all(i in edges for i in ids): continue
        first,second=(nodes[edges[i]['target']] for i in ids)
        if first['value'] is None or second['value'] is None:
            cmp='not-evaluated'
        else:
            cmp='positive' if second['value']>first['value'] else 'zero' if second['value']==first['value'] else 'negative'
        if cmp=='positive':removed.add((index,ids[0]))
        rows.append(dict(source=index,sourceBoundary=node['boundary'],first=first['node'],second=second['node'],lowerValue=first['value'],
                         higherValue=second['value'],difference=second['value']-first['value'] if cmp!='not-evaluated' else None,sign=cmp))
    cases[f'{species}:{low}/{high}']={'actions':ids,'cases':rows,'counts':dict(Counter(r['sign'] for r in rows)),
                                     'differences':dict(Counter(str(r['difference']) for r in rows))}
def walk(drop):
    todo=[0]
    seen=set()
    while todo:
        i=todo.pop()
        if i in seen:continue
        seen.add(i)
        todo.extend(e['target'] for e in nodes[i]['edges'] if (i,e['actionId']) not in drop)
    return seen
baseline=walk(set()); revised=walk(removed)
d={'source':str(source.name),'decision':q['actionId'],'value':q['value'],'graphNodes':len(nodes),'reachableGraphNodes':len(baseline),
   'strictlyLowerObservedEdges':len(removed),'wouldLoseReachability':len(baseline-revised),
   'unreachableLeafStates':dict(Counter((nodes[k]['status'] for k in baseline-revised))),'pairs':cases}
with dest.open('x') as out:json.dump(d,out,ensure_ascii=False,indent=2)
for k,v in cases.items():print(k,v['counts'],v['differences'])
print('would lose reachability',d['wouldLoseReachability'],'from',d['reachableGraphNodes'])
