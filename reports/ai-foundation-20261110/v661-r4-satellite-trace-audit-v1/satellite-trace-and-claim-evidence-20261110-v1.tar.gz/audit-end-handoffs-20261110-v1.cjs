'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),{isDeepStrictEqual:same}=require('node:util');
const old=Module._extensions['.js'],seen=new WeakMap(),groups=new Map();
globalThis.auditEnd=(root,out,seat,stationary)=>{
 let count=seen.get(root)||0;seen.set(root,count+1);
 const p=root.players.players.find(a=>a.id===seat);
 const q=out?.state.players.players.find(a=>a.id===seat);
 const changed=(a,b)=>[...new Set([...Object.keys(a),...Object.keys(b)])].filter(k=>!same(a[k],b[k]));
 const key=JSON.stringify({stationary,success:Boolean(out),repeated:count>0,settlements:out?.settlements.map(x=>x.kind+':'+x.ruleId)??[],
   reserved:p.reservedCards.map(c=>c.cardId),markChanges:out?changed(root.finalScoring,out.state.finalScoring):null,
   alienChanges:out?changed(root.aliens,out.state.aliens):null,playerChanges:out?changed(p,q):null});
 groups.set(key,1+(groups.get(key)||0));
};
Module._extensions['.js']=(mod,file)=>{
 if(!file.endsWith('/game/effects/residual-domain-session.js'))return old(mod,file);
 const src=fs.readFileSync(file,'utf8'),mark='  function previewQuietEndHandoffs(root, ownerId, {stationaryCargo=false} = {}) {';
 assert.equal(src.split(mark).length,2);mod._compile(src.replace(mark,mark+'\n    const p=previewQuietEndHandoffsAudit(root,ownerId,{stationaryCargo});globalThis.auditEnd(root,p,ownerId,stationaryCargo);return p;\n  }\n'+mark.replace('previewQuietEndHandoffs','previewQuietEndHandoffsAudit')),file);
};
const {open}=require(process.argv[2]),root=JSON.parse(fs.readFileSync(process.argv[3])).checkpoint,m=open(root);
try{
 const q=m.automatic();assert(q.complete);assert.deepEqual(m.save(),root);
 const rows=[...groups].map(([k,n])=>({...JSON.parse(k),n})).sort((a,b)=>b.n-a.n);
 fs.writeFileSync(process.argv[4],JSON.stringify({action:q.a.actionId,value:q.value,rows},null,2)+'\n',{flag:'wx'});
}finally{m.dispose();}
