'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),{performance}=require('node:perf_hooks');
const old=Module._extensions['.js'],seen={};
globalThis.claimStep=(k,start,previous)=>{
 const now=performance.now();
 const q=seen[k]??={count:0,fullMs:0,stageMs:0};q.count++;q.fullMs+=now-start;q.stageMs+=now-previous;
 return now;
};
Module._extensions['.js']=(mod,file)=>{
 if(!file.endsWith('/game/ai/analysis-port.js'))return old(mod,file);
 const src=fs.readFileSync(file,'utf8');
 const mark='    function redundantQuietFinalClaim(node, actionId, endId, hasTime) {';
 const a=src.indexOf(mark),b=src.indexOf('    function redundantCargoClaim',a);
 let i=0,part=src.slice(a,b).replace(mark,mark+'\n      const start=performance.now();let prev=start;')
   .replace(/return null;/g,()=>'{globalThis.claimStep("rejected-'+(++i)+'",start,prev);return null;}')
   .replace('      const policy=','      prev=globalThis.claimStep("early-preview",start,prev);\n      const policy=')
   .replace('      const late=','      prev=globalThis.claimStep("early-policy",start,prev);\n      const late=')
   .replace('      const a=nodes.get(early)','      prev=globalThis.claimStep("late-preview",start,prev);\n      const a=nodes.get(early)')
   .replace('      return {proof:', '      globalThis.claimStep("success",start,prev);\n      return {proof:');
 assert.equal(i,8);mod._compile(src.slice(0,a)+part+src.slice(b),file);
};
const {open}=require(process.argv[2]),root=JSON.parse(fs.readFileSync(process.argv[3])).checkpoint,m=open(root);
try{
 const q=m.automatic();assert(q.complete);assert.deepEqual(m.save(),root);
 const evidence={action:q.a.actionId,value:q.value,seen};
 fs.writeFileSync(process.argv[4],JSON.stringify(evidence,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(evidence));
}finally{m.dispose();}
