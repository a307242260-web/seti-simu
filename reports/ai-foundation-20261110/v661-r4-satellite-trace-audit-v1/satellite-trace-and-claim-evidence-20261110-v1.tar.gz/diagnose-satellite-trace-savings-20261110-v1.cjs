'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),Module=require('node:module');
const old=Module._extensions['.js'],pairs=JSON.parse(fs.readFileSync(process.env.SETI_TRACE_AUDIT)).pairs,rows=[];
globalThis.forSatDiagnostic=(node,stored,state)=>{
 const ids=new Set(node.legalActions.map(a=>a.actionId)),s=stored.envelope.session?.session;
 const p=state.players.players.find(p=>p.id==='player-white');
 const group=Object.entries(pairs).filter(([,v])=>v.actions.every(id=>ids.has(id)));
 if(!group.length||s?.queue[0]?.type!=='science_domain_alien_trace')return [];
 const meta={turn:state.turn.turnNumber,version:state.meta.stateVersion,credits:p.resources.credits,energy:p.resources.energy,
   data:p.resources.availableData,hand:p.hand.length,score:p.resources.score,origin:s.journal.actions[0]?.action.family,
   tail:s.queue.slice(1).map(e=>[e.type,e.payload?.cardEffect?.type??null,e.payload?.traceType??null]),bound:node.boundary,options:node.legalActions.length,
   pairs:group.map(([k])=>k)};
 rows.push(meta);
 return group.map(([,v])=>v.actions[0]);
};
Module._extensions['.js']=(mod,file)=>{
 if(!file.endsWith('/game/ai/analysis-port.js'))return old(mod,file);
 const src=fs.readFileSync(file,'utf8'),marker='      const spec=result&&freeze(result);localSpecs.set(node,spec);return spec;';
 assert.equal(src.split(marker).length,2);mod._compile(src.replace(marker,`      if(!result){
        const excludedActionIds=globalThis.forSatDiagnostic(node,stored,state);
        if(excludedActionIds.length&&process.env.SETI_TRACE_DIAGNOSTIC==="1")result={
          policy:"diagnostic-only-observed-satellite-trace-order",kind:"rank-automatic-scan-traces",isEquivalence:false,
          retainedActionIds:node.legalActions.filter(a=>!excludedActionIds.includes(a.actionId)).map(a=>a.actionId),excludedActionIds
        };
      }
`+marker),file);
};
process.on('exit',()=>{if(process.exitCode==null||process.exitCode===0)fs.writeFileSync(process.env.SETI_TRACE_META,JSON.stringify(rows,null,2)+'\n',{flag:'wx'});});
