'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3'),plans=require(path.resolve('randomizer/game/ai/local-decision-plans'));
const [input,pairPath,output]=process.argv.slice(2),d=JSON.parse(z.gunzipSync(fs.readFileSync(input))),pairs=JSON.parse(fs.readFileSync(pairPath));
const score=x=>x.publicState.players.find(p=>p.playerId===seat).finalScore;
const result=[];
for(const p of pairs){
 const original=d.snapshots[p.root],m=open(original),s=original.session.session,ids=[p.first,p.skip,p.symbol];
 const action=(id,env)=>d.rows.find(r=>r.envelopes===env&&r.action.actionId===id).action;
 const confirm=action(p.first,p.root),skip=action(p.skip,p.root);
 const symbol=action(p.symbol,d.rows.find(r=>r.envelopes===p.root&&r.action.actionId===p.first).nextEnvelope);
 const player=st=>st.players.players.find(p=>p.id===seat),known=new Set(player(s.workingState).reservedCards.map(c=>c.id));
 const choose=(state,session=s,knownCards=known)=>plans.pureOptional({state,session,actions:[confirm,skip],seatId:seat,knownCards});
 const reason='greedy-final-single-public-blue-symbol';
 try{
  assert.equal(choose(s.workingState)?.selectedActionId,confirm.actionId);
  m.apply(skip); const sk=m.save(),sv=score(m.owner(seat));
  assert.deepEqual(JSON.parse(sk.committedState),JSON.parse(d.snapshots[p.afterSkip].committedState));
  m.restore(original); m.apply(confirm);
  assert.deepEqual(m.menu().map(x=>[x.family,x.target.choiceId]),[['choose_target','symbol:blue_1']]);
  m.apply(symbol);const yes=m.save(),yv=score(m.owner(seat));
  assert.deepEqual(JSON.parse(yes.committedState),JSON.parse(d.snapshots[p.afterAccept].committedState));
  const a=JSON.parse(yes.committedState),b=JSON.parse(sk.committedState),x=player(a),y=player(b);
  assert.equal(x.resources.score-y.resources.score,4);
  assert.equal(x.completedTaskCount-y.completedTaskCount,1);
  assert.equal(x.reservedCards.length,y.reservedCards.length-1);
  assert.equal(yv-sv,8);assert.deepEqual(a.meta.rngState,b.meta.rngState);
  const extra=structuredClone(s.workingState);extra.aliens.amiba.symbolSlots.blue_3='symbol_5';
  const unseen=structuredClone(s.workingState);unseen.aliens.amiba.revealInitialized=false;
  const live=structuredClone(s.workingState);live.turn.passedPlayerIds.pop();
  const reuse=structuredClone(s.workingState);
  player(reuse).reservedCards.find(x=>x.cardId==='amiba_1.webp').cardEffectState.consumedTriggerIds=[];
  const pending={...s,queue:[...s.queue,...s.queue]};
  for(const pol of [choose(extra),choose(unseen),choose(live),choose(reuse),choose(s.workingState,pending),choose(s.workingState,s,new Set())]){
   assert.notEqual(pol?.reason,reason);
  }
  result.push({...p,finalValueGain:yv-sv,taskDelta:1,nativeReplayInputs:3,negativeControls:6});
 }finally{m.dispose();}
}
assert.equal(result.length,12);
fs.writeFileSync(output,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log('12 pairs: 36 native inputs, +4 board / +8 established, 72 fallbacks');

