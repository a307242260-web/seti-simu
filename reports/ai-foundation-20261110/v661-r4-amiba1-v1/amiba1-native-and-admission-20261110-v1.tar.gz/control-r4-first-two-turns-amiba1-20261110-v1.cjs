'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const [which,filename]=process.argv.slice(2);
assert(['teacher','official'].includes(which));
const dir=__dirname,read=name=>JSON.parse(z.gunzipSync(fs.readFileSync(path.join(dir,name))));
const teacherFixture=read('teacher-r4-first-four-cold-20261110-reuse.json.gz');
const teacher=teacherFixture.rows.find(r=>r.decision.input===249).before;
const root=which==='teacher'?teacher:require('./v661-r4-full-preflight-20261109-v1.json').checkpoint;
const m=open(root),trace=[],accepted=[],turns=[],fd=fs.openSync(filename,'wx');
const record=x=>{fs.writeSync(fd,JSON.stringify(x)+'\n');fs.fsyncSync(fd);};
function replay(end,from=root,steps=accepted){
 const r=open(from);try{for(const a of steps)r.apply(a);assert.deepEqual(r.save(),end);}finally{r.dispose();}
}
function facts(model){
 const f=model.facts(),obs=model.owner(seat),s=model.state();
 return {...f,scanProgress:obs.publicState.board.data, pendingAlien:s.aliens.chong?.transportTasksByRocketId};
}
let checkpoint,failed;
try{
 record({kind:'start',which,root,facts:facts(m),gate:{native:256,ms:600},turnLimit:2});
 for(let i=0;i<96&&turns.length<2;i++){
  const before=m.save();
  const q=m.automatic(checkpoint);
  const entry={kind:'decision',i,action:q.a,native:q.n,ms:q.ms,value:q.value,complete:q.complete,
   reused:q.n===0,legalRootExact:true};
  record(entry);trace.push(entry);
  if(!q.complete||q.n>256||q.ms>600){failed={...entry,before,checkpoint};break;}
  if(q.a.family==='pass')throw Error('FIXTURE_REACHED_ROUND_PASS_BEFORE_TWO_TURNS');
  m.apply(q.a);accepted.push(q.a);
  checkpoint=q.checkpoint;
  if(q.a.family==='end_turn'){
   turns.push({count:turns.length+1,end:m.save(),facts:facts(m),accepted:accepted.length});
   record({kind:'turn',...turns.at(-1)});
   if(turns.length===2)break;
  }
  const opponents=[];
  m.advanceOpponents(opponents);
  if(opponents.length){record({kind:'passive',after:i,inputs:opponents});accepted.push(...opponents);}
  const round=m.state().turn.roundNumber;assert.equal(round,4);
 }
 assert(failed||turns.length===2);
 const end=m.save();replay(end);
 let reference;
 if(which==='teacher'&&!failed){
   const r=open(root),native=read('teacher-r4-full-native-actions-20261110-reuse.json.gz').full.slice(4,20);
   const refTurns=[];
   try{
    for(const a of native){r.apply(a);if(a.actorId===seat&&a.family==='end_turn')refTurns.push({facts:facts(r),end:r.save()});}
    assert.equal(refTurns.length,2);replay(r.save(),root,native);reference={steps:native,turns:refTurns};
   }finally{r.dispose();}
 }
 record({kind:'end',which,completedTurns:turns.length,accepted,exactReplay:true,failed,end,facts:facts(m),reference});
 console.log(JSON.stringify({which,turns:turns.map(t=>[t.count,t.facts.wallet.score,t.facts.final,t.facts.wallet.credits,t.facts.wallet.energy,t.facts.wallet.availableData,t.facts.wallet.publicity,t.facts.hand.length]),
  decisions:trace.length,maxMs:Math.max(...trace.map(r=>r.ms)),maxNative:Math.max(...trace.map(r=>r.native)),
  failed:failed&&{native:failed.native,ms:failed.ms,action:failed.action?.summary},references:reference?.turns.map(t=>[t.facts.wallet.score,t.facts.final,t.facts.wallet.credits,t.facts.wallet.energy,t.facts.wallet.availableData,t.facts.wallet.publicity,t.facts.hand.length])}));
}finally{fs.closeSync(fd);m.dispose();}

