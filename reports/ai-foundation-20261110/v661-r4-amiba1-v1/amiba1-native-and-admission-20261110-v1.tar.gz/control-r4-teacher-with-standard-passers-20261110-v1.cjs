'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const read=name=>JSON.parse(z.gunzipSync(fs.readFileSync(path.join(__dirname,name))));
const root=read('teacher-r4-first-four-cold-20261110-reuse.json.gz').rows.find(r=>r.decision.input===249).before;
const historical=read('teacher-r4-full-native-actions-20261110-reuse.json.gz').full.slice(4,20);
const expected=historical.filter(a=>a.actorId===seat),m=open(root),rows=[],opponents=[],accepted=[];
let failure;
try{
 for(const action of expected){
  const other=[];m.advanceOpponents(other);opponents.push(...other);accepted.push(...other);
  const a=m.menu().find(x=>x.actionId===action.actionId&&x.actorId===seat);
  if(!a){failure={action,choices:m.menu()};break;}
  m.apply(a);accepted.push(a);
  if(a.family==='end_turn')rows.push({facts:m.facts(),checkpoint:m.save()});
 }
 const end=m.save();m.restore(root);for(const a of accepted)m.apply(a);assert.deepEqual(m.save(),end);
 const old=historical.filter(a=>a.actorId!==seat);
 const matches=opponents.map(a=>old.some(x=>x.actionId===a.actionId&&x.actorId===a.actorId));
 const result={failure,end,rows,opponents,accepted,root,rootAndRngExact:true,matches};
 fs.writeFileSync(process.argv[2],JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({passive:opponents.map(x=>x.summary),matches,failure:failure?.action?.summary,
  rows:rows.map(r=>[r.facts.wallet.score,r.facts.final,r.facts.wallet.credits,r.facts.wallet.energy,r.facts.wallet.availableData,r.facts.wallet.publicity,r.facts.hand.length])}));
}finally{m.dispose();}

