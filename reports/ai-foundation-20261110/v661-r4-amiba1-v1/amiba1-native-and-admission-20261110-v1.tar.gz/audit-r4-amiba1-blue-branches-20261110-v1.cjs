'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const data=JSON.parse(z.gunzipSync(fs.readFileSync(process.argv[2])));
const pair=JSON.parse(fs.readFileSync(process.argv[3]));
const {root}=JSON.parse(z.gunzipSync(fs.readFileSync(path.join(__dirname,'candidate-r4-active-task-preview-native-20261109-v1.json.gz')))).rows.find(r=>r.input===355);
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent')),{createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 const first=new Set(pair.map(p=>p.first)),skip=new Set(pair.map(p=>p.skip)),symbol=new Set(pair.map(p=>p.symbol));
 const measure=(root)=>{
  const visit=new Set([root]);const list=[root];
  for(const i of list)for(const e of q.lines[i].edges)if(!visit.has(e.target)){visit.add(e.target);list.push(e.target);}
  const {value,realization,preparationDebt,status,bestActionId}=q.lines[root];
  return{root,value,realization,preparationDebt,status,bestActionId,nodes:visit.size,leaves:list.filter(i=>!q.lines[i].edges.length).length};
 };
 const result=[];
 for(const l of q.lines){
  const yes=l.edges.find(e=>first.has(e.actionId)),no=l.edges.find(e=>skip.has(e.actionId));
  if(!yes||!no)continue;
  const next=q.lines[yes.target],end=next.edges.find(e=>symbol.has(e.actionId));assert(end);
  result.push({index:l.node,confirmation:measure(yes.target),reward:measure(end.target),skip:measure(no.target)});
 }
 assert.equal(result.length,pair.length);
 const out={rootExact:true,rootValue:q.value,native:q.diagnostics.nativeExecutions,transitions:q.diagnostics.transitions,graphNodes:q.diagnostics.graphNodes,result};
 fs.writeFileSync(process.argv[4],JSON.stringify(out,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(result.map(p=>[p.reward.value,p.skip.value,p.reward.realization,p.skip.realization,p.reward.nodes,p.skip.nodes,p.reward.status,p.skip.status])));
}finally{port.close();m.dispose();}

