'use strict';
const assert=require('node:assert/strict');
const {readZ,writeZ,open,short}=require('./controlled-r3');
const {control}=require('./r3-r4-handoff-helper-20261110-v1.cjs');
const [source,proof,output]=process.argv.slice(2);
const reference=readZ(source)['analyze-fill-3'].checkpoint;
const witness=readZ(proof).rows.preserve.auto;
const seat='player-white';
const visible = e => {
 const m=open(e);
 try {return {state:m.owner(seat),actions:m.menu()};} finally {m.dispose();}
};
const view=visible(reference);
const expected=JSON.parse(reference.committedState);
assert.equal(expected.cards.drawPileCardIds[1],'b_9.webp');

function exact(m, origin, actions) {
 const end=m.save();m.restore(origin);actions.forEach(m.apply);assert.deepEqual(m.save(),end);m.restore(origin);return end;
}
function run(origin) {
 const m=open(origin),prior=open(witness.origin),actions=[],stages={};
 const take=(f,id)=>actions.push(m.act(f,typeof id==='function'?id:v=>!id||v.target?.choiceId===id||v.target?.tradeId===id));
 const cut=k=>stages[k]={state:m.save(),summary:short(m)};
 const fill=()=>{take('place_data');take('choose_target',v=>v.target.target==='computer');};
 const use=a=>{
  if(a.family==='choose_payment'){
   const before=new Map(prior.facts().hand),now=new Map(m.facts().hand);
   const label=ids=>JSON.stringify(ids.sort());
   const names=label(a.target.cardIds.map(id=>before.get(id)));
   take('choose_payment',v=>label(v.target.cardIds.map(id=>now.get(id)))===names);
  }else actions.push(m.apply(a));
  prior.apply(a);
 };
 try {
  const incomeDraw=m.facts().hand.find(h=>h[0]==='card-69-0');
  assert(incomeDraw);
  take('end_turn');m.advanceOpponents(actions);
  take('quick_trade','cards-for-energy');
  take('choose_payment',v=>v.target.cardInstanceId===incomeDraw[0]);
  take('choose_payment',v=>v.target.cardInstanceId===m.player().hand.find(h=>h.cardId==='amiba_9.webp')?.id);
  take('choose_payment',v=>v.target.kind==='confirm');
  take('quick_trade','credits-for-energy');
  take('scan');
  take('choose_target','nebula:sector-2-b');
  take('choose_card','public:card-67-0:sector-1-a');
  take('choose_card','public:done');
  take('choose_target','scan4:launch');
  cut('scan-and-launch');
  assert.equal(short(m).wallet[4],2);
  fill();
  take('end_turn');m.advanceOpponents(actions);
  cut('before-landing');
  for(const a of witness.actions.slice(0,18))use(a);
  cut('after-landing');
  fill();fill();
  for(const a of witness.actions.slice(18,21))use(a);
  take('end_turn');
  cut('turn-end');
  return {origin,actions,stages,end:exact(m,origin,actions),incomeDraw:incomeDraw[1]};
 } finally{m.dispose();prior.dispose();}
}

const rows={};
for(const index of [1,2,114]){
 const state=JSON.parse(reference.committedState),pile=state.cards.drawPileCardIds;
 [pile[index],pile[1]]=[pile[1],pile[index]];
 const root={...reference,committedState:JSON.stringify(state)};
 assert.deepEqual(visible(root),view);
 assert.deepEqual(state.meta.rngState,expected.meta.rngState);
 const handoff=control(root);
 assert(handoff.replayExact&&!handoff.failure);
 const post=handoff.stages['after-common-blue8'];
 const row=run(post.state);rows[index]={root,handoff,row};
 console.log(index,row.incomeDraw,JSON.stringify(row.stages['turn-end'].summary),row.actions.length);
}
writeZ(output,{rows,visibilityExact:true,scope:'Counterfactual permutations replace only the identity of the second salary draw. Its hand instance and an existing Amiba 9 are used only as count-based trade payment. Standard scan and explicit known inputs, no autonomous rollout.'});
