const assert=require('node:assert/strict');
const {readZ,writeZ,open,short}=require('./controlled-r3');
const {control}=require('./r3-r4-handoff-helper-20261110-v1.cjs');
const [source,output]=process.argv.slice(2), x=readZ(source),row=x.cases['fully-fixed-before-pass'].rows[0],origin=x.origins['fully-fixed-before-pass'];
const m=open(origin),out={};
try{
 for(const [name,n] of [['analyze-keep-pool',5],['analyze-fill-3',11]]){
  m.restore(origin);const actions=row.actions.slice(0,n).map(v=>m.apply(v.action));
  actions.push(m.act('end_turn'));m.advanceOpponents(actions);
  const checkpoint=m.save(),before=short(m);
  m.restore(origin);actions.forEach(m.apply);assert.deepEqual(m.save(),checkpoint);m.restore(origin);
  const handoff=control(checkpoint);
  out[name]={origin,actions,checkpoint,before,handoff};
  console.log(JSON.stringify({name,before,failure:handoff.failure,after:handoff.stages['after-common-blue8']?.assets,dataPayments:handoff.dataPayments}));
 }
 writeZ(output,out);
}finally{m.dispose();}
