'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,open,short}=require('./controlled-r3');
const [source,output]=process.argv.slice(2),origin=readZ(source).origin,m=open(origin),inputs=[],decisions=[];
try{
 let cache,stop='diagnostic input cap';
 const turn=m.facts().turn;
 for(let i=0;i<40&&m.facts().turn===turn;i++){
  if(m.menu()[0].actorId!=='player-white'){m.advanceOpponents(inputs);if(m.facts().turn!==turn)break;}
  const q=m.automatic(cache);decisions.push({a:q.a,n:q.n,ms:q.ms,complete:q.complete,value:q.value});
  if(!q.complete||q.n>256||q.ms>600){stop='single-decision gate';break;}
  inputs.push(m.apply(q.a));cache=q.checkpoint;
 }
 if(m.facts().turn!==turn)stop='turn closed';
 const end=m.save(),assets=short(m);
 m.restore(origin);inputs.forEach(m.apply);assert.deepEqual(m.save(),end);m.restore(origin);
 writeZ(output,{origin,inputs,decisions,end,assets,stop,exact:true});
 console.log(JSON.stringify({assets,n:inputs.length,native:Math.max(...decisions.map(q=>q.n)),ms:Math.max(...decisions.map(q=>q.ms)),stop,moves:inputs.map(a=>a.summary)}));
}finally{m.dispose();}
