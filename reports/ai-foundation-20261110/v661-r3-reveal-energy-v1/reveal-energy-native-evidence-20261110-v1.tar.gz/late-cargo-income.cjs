'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const [matrix,output]=process.argv.slice(2),r=readZ(matrix).out.late.world.虫.rows.reveal.rows[0];
const m=open(r.start),roots={},routes={},cards=require(path.resolve('randomizer/game/cards/deck'));
const apply=(a,b)=>r.actions.slice(a,b).forEach(x=>m.apply(x.action));
try{
 apply(0,7);const fromLaunch=m.save();
 for(const a of m.menu().filter(a=>a.family==='move')){
  m.restore(fromLaunch);m.apply(a);m.act('choose_payment',a=>a.target.cardIds?.join(',')==='card-62-0');
  const afterMove=short(m),payment=afterMove.wallet[3]===5?'b_16.webp':'amiba_9.webp';
  m.corner(payment);apply(10,23);
  routes[a.summary]={afterMove,payment,beforeLanding:short(m),envelope:m.save()};
 }
 m.restore(r.start);apply(0,33);roots.yellow=m.save();
 const u=m.automatic();roots.yellowGate={n:u.n,ms:u.ms,complete:u.complete};assert(u.complete&&u.n<=256&&u.ms<=600);
 const alternatives=m.menu().map(a=>[a.target.choiceId,a.summary]);
 const cases=alternatives.filter(([id])=>id!=='trace:2:yellow:chong:4')
  .map(([id])=>[id,({act})=>act('choose_target',a=>a.target.choiceId===id)]);
 const results=runCases(roots.yellow,cases);
 for(const row of results.rows)assert(row.replayExact);
 writeZ(output,{roots,routes,results,reference:r.settled?.summary});
}finally{m.dispose();}
