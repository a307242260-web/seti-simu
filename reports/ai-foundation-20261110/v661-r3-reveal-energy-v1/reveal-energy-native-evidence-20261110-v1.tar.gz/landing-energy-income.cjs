'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const [fixture,output]=process.argv.slice(2),root=readZ(fixture).roots.yellow;
const m=open(root),witness=[];
function prepare(m,record,fossil){
 const take=(f,id)=>record(m.act(f,a=>id==null||a.target?.choiceId===id));
 take('choose_target','trace:1:yellow:amiba:4');take('choose_card','amiba:display:5');
 const afterPick=short(m);
 take('accept_optional_effect','confirm:trigger:alien-amiba-0-1:amiba0-yellow-data');
 take('choose_target','chong-fossil:'+fossil);
 const afterFossil=short(m);
 for(let i=0;i<3;i++){take('place_data');take('choose_target','data:computer');}
 const afterFill=short(m);
 take('complete_task');const afterTask=short(m);
 take('end_turn');
 return {afterPick,afterFossil,afterFill,afterTask,stable:short(m)};
}
try{
 const stages=prepare(m,a=>witness.push(a),'fossil_01'),beforeIncome=m.save(),known=m.automatic();
 assert(known.complete&&known.n<=256&&known.ms<=600);
 console.log('phases',JSON.stringify(stages),'live',known.a.summary,known.n,known.ms);
 m.restore(root);witness.forEach(m.apply);assert.deepEqual(m.save(),beforeIncome);
 const rows=runCases(beforeIncome,[
  ['retain-for-income-autonomous',()=>{}],
  ['corner-amiba5-keep-dlc14',({m,take,act})=>{
   take(m.corner('amiba_5.webp'));act('place_data');act('choose_target',a=>a.target.choiceId==='data:computer');
   act('choose_card',a=>a.target.choiceId?.startsWith('income:')&&a.summary.includes('dlc_14'));
  }],
  ['corner-dlc14-keep-amiba5',({m,take,act})=>{
   take(m.corner('dlc_14.png'));act('place_data');act('choose_target',a=>a.target.choiceId==='data:computer');
   act('choose_card',a=>a.target.choiceId?.startsWith('income:')&&a.summary.includes('amiba_5'));
  }]
 ]);
 writeZ(output,{root,witness,stages,beforeIncome,afterEndGate:{n:known.n,ms:known.ms,action:known.a.summary},rows});
}finally{m.dispose();}
