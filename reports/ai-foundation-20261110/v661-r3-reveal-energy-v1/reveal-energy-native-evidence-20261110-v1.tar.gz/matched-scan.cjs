'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),rows={};
for(const [id,r] of Object.entries(d)){
 const root=r.stages['common-scan-open'].e,m=open(root),actions=[];
 const take=(f,x)=>actions.push(m.act(f,a=>x==null||a.target?.choiceId===x));
 try{
  take('choose_target','nebula:sector-2-b');
  take('choose_card','public:card-67-0:sector-1-a');take('choose_card','public:card-66-0:sector-2-a');
  const afterScan=short(m);
  while(m.player().resources.availableData&&m.facts().computer.length<6){
   take('place_data');take('choose_target','data:computer');
   if(m.menu().some(a=>a.target?.choiceId==='income:card-30-pass-3-1'))take('choose_card','income:card-30-pass-3-1');
  }
  const afterFill=short(m);
  const n=m.save();m.restore(root);actions.forEach(m.apply);assert.deepEqual(m.save(),n);
  rows[id]={root,actions,end:n,afterScan,afterFill};
  console.log(id,JSON.stringify({afterScan,afterFill}));
 }finally{m.dispose();}
}
writeZ(out,rows);
