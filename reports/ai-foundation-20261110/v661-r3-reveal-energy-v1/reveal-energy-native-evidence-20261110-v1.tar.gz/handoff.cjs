'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,short}=require('./controlled-r3'),{pathToEarth}=require('./path.cjs');
const [input,output]=process.argv.slice(2),d=readZ(input),rows={};
const scanCosts=require(path.resolve('randomizer/game/actions/scan-effects'));
for(const r of d.rows.rows){
 const m=open(r.end),accepted=[],stages={};
 const act=(f,p)=>{const a=m.act(f,p);accepted.push(a);return a;};
 const cut=k=>stages[k]={e:m.save(),f:short(m)};
 try{
  cut('start');
  const route=pathToEarth(m,'fossil_01');
  for(const x of route.path){
   while(m.player().resources.energy<x.cost)act('quick_trade',a=>a.target.tradeId==='credits-for-energy');
   act('move',a=>a.target.rocketId===route.rocketId&&a.target.deltaX===x.deltaX&&a.target.deltaY===x.deltaY);
   act('choose_payment',a=>a.target.kind==='move-payment'&&!a.target.cardIds.length);
  }
  cut('delivered');
  act('complete_task',a=>a.target.ruleId==='transport');cut('claimed');
  const cost=scanCosts.getStandardScanCost(m.player());
  while(m.player().resources.energy<cost.energy)act('quick_trade',a=>a.target.tradeId==='credits-for-energy');
  act('scan');cut('common-scan-open');
  const sectors=m.menu().map(a=>a.target.choiceId);
  const e=m.save();m.restore(r.end);accepted.forEach(m.apply);assert.deepEqual(m.save(),e);
  rows[r.label]={route,accepted,stages,sectors,cost};
  console.log(r.label,route.cost,JSON.stringify(Object.entries(stages).map(([k,v])=>[k,v.f.wallet,v.f.established,v.f.hand,v.f.income])),sectors);
 }finally{m.dispose();}
}
writeZ(output,rows);
