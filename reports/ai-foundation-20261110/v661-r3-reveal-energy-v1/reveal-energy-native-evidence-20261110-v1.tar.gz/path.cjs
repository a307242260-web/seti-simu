'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const load=n=>require(path.resolve(n)),rocket=load('randomizer/game/rockets'),ability=load('randomizer/game/abilities/rocket'),solar=load('randomizer/solar-system/core');
const seat="player-white";
function pathToEarth(m,fossilId){
 const s=m.state(),ship=s.pieces.rockets.find(r=>r.fossilId===fossilId&&r.playerId===seat),earth=solar.collectPlanetLocations(s.solarSystem).find(p=>p.planetId==='earth');
 assert(ship&&earth);
 const queue=[{at:rocket.getRocketSectorCoordinate(ship),cost:0,path:[]}],seen=new Set();
 while(queue.length){
  queue.sort((a,b)=>a.cost-b.cost||a.path.length-b.path.length);
  const n=queue.shift(),id=n.at.x+','+n.at.y;if(seen.has(id))continue;seen.add(id);
  if(n.at.x===earth.x&&n.at.y===earth.y)return {rocketId:ship.id,earth:{x:earth.x,y:earth.y},...n};
  const cost=ability.getRequiredMovePointsFromCoordinate(s,m.player(),n.at);
  for(const d of ability.MOVE_DIRECTIONS){
   const a=rocket.canMoveFromCoordinate(s.pieces,n.at,d.deltaX,d.deltaY,ship.id);
   if(a.ok&&!seen.has(a.to.x+','+a.to.y))queue.push({at:a.to,cost:n.cost+cost,path:[...n.path,{...d,cost,from:n.at,to:a.to}]});
  }
 }
 throw new Error('No legal Earth route');
}

module.exports={pathToEarth};
