'use strict';
const assert=require('node:assert/strict');
const {open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const [output,...requested]=process.argv.slice(2);
const earlier=readZ(__dirname+'/r172-handoffs.json.gz'),later=readZ(__dirname+'/v660-r3-public-mark-comparison-20261109-v1.json.gz');
const sources={early:{root:earlier.origins['pink-menu-10'],keep:'trace:1:pink:amiba:4'},late:{root:later.roots.later,keep:'trace:1:pink:amiba:3'}};
const seat='player-white';
const path=require('node:path'),aliens=require(path.resolve('randomizer/game/aliens')),
 {createSeededRandom}=require(path.resolve('randomizer/game/random')),
 {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const keys=['amiba','chong','aomomo','banrenma','runezu','yichangdian','jiuzhe','fangzhou'];
function alter(source,species){
 const root=structuredClone(source),committed=JSON.parse(root.committedState);
 let edits=0;
 const key=keys.find(k=>aliens[k].ALIEN_ID===species);
 assert(key);
 const config=species==='虫'?null:aliens[key].createInitialConfiguration(
  createSeededRandom(`${committed.meta.seed}:alien-configuration-v1:2:${key}`),committed.players.players);
 assert(species==='虫'||config);
 function walk(x){
  if(!x||typeof x!=='object')return;
  const slot=x.aliens?.aliens?.['2'];
  if(slot&&!slot.revealed&&slot.assignedAlienId){
   assert.equal(slot.assignedAlienId,'虫');
   if(species!=='虫'){slot.assignedAlienId=species;x.aliens.chong.initialConfiguration=null;x.aliens[key].initialConfiguration=structuredClone(config);edits++;}
  }
  for(const v of Object.values(x))if(v&&typeof v==='object')walk(v);
 }
 walk(committed);walk(root.session);
 assert(species==='虫'||edits>=3);
 const encoded=createStateStore(committed).serialize(committed);assert(encoded.ok);root.committedState=encoded.serialized;
 return root;
}
const out={};
for(const [id,{root,keep}] of Object.entries(sources)){
 if(requested.length&&!requested.includes(id))continue;
 const m=open(root);let pool,baseline,baselineRoot;
 try{
  pool=m.state().aliens.revealPoolAlienIds.filter(s=>s!=='阿米巴');
  const q=m.automatic();
  baselineRoot={complete:q.complete,n:q.n,ms:q.ms};
  baseline={owner:m.owner(seat),menu:m.menu(),rng:m.facts().rng,rank:q.roots,value:q.value};
  assert(q.complete&&q.n<=256&&q.ms<=600);
 }finally{m.dispose();}
 const world={};
 for(const species of pool){
  const e=alter(root,species),f=open(e);
  try{
   const q=f.automatic();
   assert(q.complete&&q.n<=256&&q.ms<=600);
   assert.deepEqual({owner:f.owner(seat),menu:f.menu(),rng:f.facts().rng,rank:q.roots,value:q.value},baseline);
  }finally{f.dispose();}
  const rows={};
  for(const [label,choice] of [['keep',keep],['reveal','trace:2:pink']]){
   try {
    rows[label]=runCases(e,[[label,({act,cut})=>{act('choose_target',a=>a.target.choiceId===choice);cut('mark-paid');}]]);
   }catch(error){rows[label]={failed:String(error).slice(0,800)};}
   const row=rows[label].rows?.[0],s=row?.settled?.summary;
   console.log('case',id,species,label,JSON.stringify({wallet:s?.wallet,established:s?.established,tech:s?.tech?.length,
     income:s?.income,hand:s?.hand?.length,blue:s?.blue?.length,probes:s?.probes,stop:row?.stop??rows[label].failed}));
  }
  world[species]={source:e,rows};
 }
 out[id]={root,baselineRoot,baseline,world};
}
writeZ(output,{scope:'Only the unrevealed species and its required seeded setup change. Other state and RNG are fixed. Each world has two paired fixed trace choices, then current v436 autonomy. No new standard game.',out});
