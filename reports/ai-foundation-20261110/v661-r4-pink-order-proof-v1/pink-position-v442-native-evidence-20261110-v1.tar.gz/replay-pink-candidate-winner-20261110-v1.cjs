'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs');
const {open,seat}=require(process.argv[2]),root=JSON.parse(fs.readFileSync(process.argv[3])).checkpoint,m=open(root);
try{
 const q=m.automatic(),plan=q.checkpoint?.plan?.rows;
 assert(q.complete&&plan?.length>0&&plan[0].actionId===q.a.actionId);
 assert.deepEqual(m.save(),root);
 for(const row of plan){
   const a=m.menu().find(a=>a.actionId===row.actionId&&a.actorId===seat);
   assert(a,row.actionId);m.apply(a);
 }
 const report={action:q.a.actionId,value:q.value,inputs:plan.map(a=>a.actionId),end:m.save(),facts:m.facts()};
 fs.writeFileSync(process.argv[4],JSON.stringify(report,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({action:q.a.actionId,value:q.value,inputs:plan.length,score:report.facts.wallet.score}));
}finally{m.dispose();}
