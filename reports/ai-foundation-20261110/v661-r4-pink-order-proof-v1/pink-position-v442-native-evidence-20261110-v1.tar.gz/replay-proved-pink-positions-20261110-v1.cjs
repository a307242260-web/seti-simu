'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),Module=require('node:module'),path=require('node:path'),{isDeepStrictEqual:same}=require('node:util');
const old=Module._extensions['.js'],seen=new Set(),saved=[];

globalThis.captureTracePair=(node,stored,result)=>{
 const e=stored.envelope, actions=node.legalActions;
 if(result?.policy!=='seti-late-pink-position-dominance-v1'||seen.has(e))return;
 const pairs=result.proof.map(proof=>({proof,kind:proof.sameSpecies,both:[proof.lower,proof.higher].map(id=>actions.find(a=>a.actionId===id))}));
 assert(pairs.every(p=>p.both.every(Boolean)));
 seen.add(e);saved.push({e,pairs});
};
Module._extensions['.js']=(mod,file)=>{
 if(!file.endsWith('/game/ai/analysis-port.js'))return old(mod,file);
 const src=fs.readFileSync(file,'utf8'),marker='      const spec=result&&freeze(result);localSpecs.set(node,spec);return spec;';
 assert.equal(src.split(marker).length,2);mod._compile(src.replace(marker,'      globalThis.captureTracePair(node,stored,result);\n'+marker),file);
};
const {open}=require(process.argv[2]),root=JSON.parse(fs.readFileSync(process.argv[3])).checkpoint,m=open(root),replay=open(root);
function diff(x,y,k='',out=[]){
 if(same(x,y))return out;
 if(!x||!y||typeof x!=='object'||typeof y!=='object'){out.push(k);return out;}
 for(const key of new Set([...Object.keys(x),...Object.keys(y)]))diff(x[key],y[key],k+'.'+key,out);
 return out;
}
function take(source,a){
 const e=JSON.parse(JSON.stringify(source)),r=replay.c.lifecycle.restore(e);
 if(!r.ok)throw Error('TRACE_SOURCE_RESTORE '+JSON.stringify(r).slice(0,700));
 replay.apply(a);
 const end=replay.save(),s=end.session?.session;
 const actions=replay.menu();
 return {state:replay.state(),end,actions,session:s?.queue?.map(e=>[e.type,e.payload]),menu:actions.map(a=>a.actionId),barrier:s?.irreversibleBarrier?.code??null};
}
function auditGuards(samples){
 const source=samples.find(x=>x.pairs.some(p=>p.proof.sameCardChoice));
 if(!source)return [];
 const local=require(path.resolve('randomizer/game/ai/local-decision-plans'));
 const seatId='player-white',tags=[];
 const check=(name,edit,expect)=>{
   const session=structuredClone(source.e.session.session),state=session.workingState,owner=state.players.players.find(p=>p.id===seatId);
   const params={state,session,seatId,actions:source.pairs.flatMap(p=>p.both),knownCards:new Set(owner.reservedCards.map(c=>c.id)),
     knownAmibaDisplay:state.aliens.amiba.displayedCardIndex};
   edit(params,owner);const result=local.pinkPositionDominance(params);
   assert(expect(result),name);tags.push(name);
 };
 const none=x=>x===null;
 check('verified-shape',()=>{},x=>x?.proof.some(p=>p.sameCardChoice));
 check('earlier-round',({state})=>{state.turn.roundNumber=3;},none);
 check('other-player-active',({state})=>{state.turn.passedPlayerIds.pop();},none);
 check('mark-still-pending',({state})=>{for(const tile of Object.values(state.finalScoring.tiles))tile.marks=tile.marks.filter(m=>m.playerId!==seatId);},none);
 check('unrecognized-queue',({session})=>{session.queue.push({...session.queue[0],type:'science_domain_income'});},none);
 check('unknown-reservation',({knownCards},p)=>{knownCards.delete(p.reservedCards[0].id);},none);
 check('main-action-still-available',(_ctx,p)=>{p.mainActionCompleted=false;},none);
 check('another-company',(_ctx,p)=>{p.initialSelection.industry=null;},none);
 check('lower-alone',p=>{const pair=source.pairs.find(p=>p.proof.sameCardChoice);p.actions=p.actions.filter(a=>a.actionId!==pair.proof.higher);},x=>!x?.proof.some(p=>p.sameCardChoice));
 check('satellite-forecast-reads-card-slot',({state})=>{state.pieces.rockets.push({playerId:seatId,surface:'solar-board',kind:'standard'});},
   x=>x?.proof.length>0&&!x.proof.some(p=>p.sameCardChoice));
 check('missing-known-display',p=>{p.knownAmibaDisplay=null;},x=>x?.proof.length>0&&!x.proof.some(p=>p.sameCardChoice));
 return tags;
}
try{
 const q=m.automatic();assert(q.complete);assert.deepEqual(m.save(),root);
 const report=[],guardControls=auditGuards(saved);
 for(const {e,pairs} of saved){
   const s=e.session.session;
   for(const {kind,both,proof} of pairs){
     const [low,high]=both.map(a=>take(e,a));
     const score=side=>side.state.players.players.find(p=>p.id==='player-white').resources.score;
     const onlyHigh=high.menu.filter(k=>!low.menu.includes(k)),onlyLow=low.menu.filter(k=>!high.menu.includes(k));
     let follow=null;
     if(onlyHigh.length===1&&onlyLow.length===1&&onlyHigh[0]===both[0].actionId&&onlyLow[0]===both[1].actionId){
       const x=take(low.end,low.actions.find(a=>a.actionId===onlyLow[0])),y=take(high.end,high.actions.find(a=>a.actionId===onlyHigh[0]));
       follow={scoreDelta:score(y)-score(x),sameMenu:same(x.menu,y.menu),sameEffectQueue:same(x.session,y.session),
         sameBarrier:x.barrier===y.barrier,changed:diff(y.state,x.state)};
     }
     const changed=diff(high.state,low.state);
     const suffix=kind==='amiba'?'.aliens.amiba.traceSlotsByAlienSlotId.':'.aliens.chong.traceSlotsByAlienSlotId.';
     const expected=[suffix+both[0].target.alienSlotId+'.pink.'+both[0].target.position,suffix+both[1].target.alienSlotId+'.pink.'+both[1].target.position];
     assert(changed.length===4&&expected.every(k=>changed.includes(k))&&changed.filter(k=>k.endsWith('.resources.score')||k.endsWith('.scoreSources.alienTracePinkScore')).length===2,JSON.stringify(changed));
     assert.equal(score(high)-score(low),1);
     assert(same(high.session,low.session)&&high.barrier===low.barrier);
     if(!same(high.menu,low.menu)){
       assert(follow&&follow.scoreDelta===0&&follow.sameMenu&&follow.sameEffectQueue&&follow.sameBarrier,JSON.stringify(follow));
       assert.deepEqual(follow.changed.sort(),expected.map(k=>k+'.sequence').sort());
     }
     report.push({kind,proof,follow,origin:s.journal.actions[0].action.family,sourceTail:s.queue.slice(1).map(x=>x.type),
       delta:score(high)-score(low),sameMenu:same(high.menu,low.menu),sameEffectQueue:same(high.session,low.session),
       sameBarrier:high.barrier===low.barrier,changed:diff(high.state,low.state),queueChanged:diff(high.session,low.session),menuOnlyHigh:high.menu.filter(k=>!low.menu.includes(k)),menuOnlyLow:low.menu.filter(k=>!high.menu.includes(k))});
   }
 }
 assert.deepEqual(m.save(),root);
 assert(report.length>0);
 fs.writeFileSync(process.argv[4],JSON.stringify({rootExact:true,guardControls,report},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({cases:report.length,guardControls,checkedNativeInputs:report.length*2+report.filter(x=>x.follow).length*2}));
}finally{m.dispose();replay.dispose();}
