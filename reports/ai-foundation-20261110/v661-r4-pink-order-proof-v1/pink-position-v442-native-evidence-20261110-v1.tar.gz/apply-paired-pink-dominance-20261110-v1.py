from pathlib import Path
import sys
d=Path(sys.argv[1])/'randomizer/game/ai'
p=d/'local-decision-plans.js';s=p.read_text()
mark=' // Price only automatic trace rewards. Any real card/fossil selection'
assert s.count(mark)==1
new=''' const quietPinkTaskConditions=new Set(['orbitOrLandCount','probeDistanceFromEarth','completedSectors','completedSectorsByColor','traceCount']);
 function pinkPositionDominance({state,seatId,actions,session,knownCards,knownAmibaDisplay}){
  const [head,...tail]=session?.queue||[],t=state.turn;
  const pink=e=>e?.type===science.EFFECT_TYPES.ALIEN_TRACE&&e.kind==='decision'&&e.ownerId===seatId&&!e.allowQuickActions
    &&e.payload?.traceType==='pink'&&Object.keys(e.payload).length===1;
  const refill=e=>e.type===science.EFFECT_TYPES.PUBLIC_REFILL&&e.kind==='effect'&&e.ownerId===seatId
    &&!e.allowQuickActions&&!Object.keys(e.payload).length;
  if(t.roundNumber!==4||t.currentPlayerId!==seatId||t.gameEnded||t.passedPlayerIds.includes(seatId)
    ||t.cardTurnEventBonuses?.length||!t.activePlayerIds.every(id=>id===seatId||t.passedPlayerIds.includes(id))
    ||session?.phase!=='awaiting_input'||session.interruptContext||session.failure||session.undoFrames.length
    ||!pink(head)||!['scan','land','play_card'].includes(session.journal.actions[0]?.action?.family))return null;
  // A second plain pink choice may use the other position. The same two
  // rewards in reversed order consume the same resources and expose the
  // same knowledge; two distinct marker sequences are not an identity.
  const secondPink=pink(tail[0]);
  const after=secondPink?tail.slice(1):tail;
  if(after.length>1||after.length===1&&!refill(after[0]))return null;
  const p=owner(state,seatId),slotOf=a=>aliens.getAlienSlot(state.aliens,a.target.alienSlotId);
  if(!p.mainActionCompleted||p.passCompletionPending||industry.getPlayerIndustryDefinition(p)?.activeAbilityId!=='deepspace_swap_cards'
    ||Object.values(state.aliens.aliens).some(s=>!s.revealed||!['阿米巴','虫'].includes(s.alienId))
    ||state.finalScoring.thresholds.some(n=>!Object.values(state.finalScoring.tiles).some(tile=>
      tile.marks?.some(m=>m.playerId===seatId&&m.threshold===n))))return null;
  // With the main action used, retained effects must only observe counts,
  // resources other than score, or probe geometry; no active effect may
  // remove or inspect a particular trace. Already queued triggers are
  // still live even if they were emitted by the earlier main action.
  if((t.type1TriggerEvents||[]).some(event=>effects.hasMatchingTrigger(p,event)))return null;
  for(const card of p.reservedCards){
    const model=effects.getCardModel(card),runtime=card.cardEffectState;
    if(!knownCards.has(card.id)||!model||model.temporaryTasks?.length
      ||model.endGameScoring?.kind==='remainingResource'&&model.endGameScoring.resource==='score')return null;
    const consumed=runtime?.modelCardId===card.cardId?runtime.consumedTriggerIds||[]:[];
    if(model.triggers?.some(trigger=>!consumed.includes(trigger.id)
      &&!(trigger.event?.types||[trigger.event?.type]).every(type=>type==='researchTech')))return null;
    if(model.tasks?.some(task=>!quietPinkTaskConditions.has(task.condition?.type)
      ||task.rewards?.some(e=>e.type!=='gain_resources')))return null;
    if(aliens.chong.isChongCard(card)){
      const task=card.chongTask||aliens.chong.getCardTask(card);
      if(task&&(task.kind!=='transport'||task.effects?.some(e=>!['gain_resources','gain_data','pick_card','draw_cards'].includes(e.type))))return null;
    }
    if(aliens.amiba.isAmibaCard(card)&&(card.amibaTask||aliens.amiba.getCardTask(card)))return null;
  }
  const proof=[],excludedActionIds=[];
  for(const [species,lo,hi] of [['amiba',1,2],['amiba',3,4],['chong',1,2]]){
    const position=n=>actions.find(a=>a.actorId===seatId&&a.family==='choose_target'&&a.target?.kind==='planet-reward-alien-trace'
      &&a.target.traceType==='pink'&&a.target.speciesId===species&&a.target.position===n);
    const low=position(lo),high=position(hi),takesCard=lo===3;
    if(!low||!high||low.target.alienSlotId!==high.target.alienSlotId||!slotOf(low)?.revealed
      ||!science.isPlainPinkTrace(state,low,true,takesCard)||!science.isPlainPinkTrace(state,high,true,takesCard))continue;
    const speciesApi=aliens[species],a=speciesApi.getTraceReward(state.aliens,'pink',lo),b=speciesApi.getTraceReward(state.aliens,'pink',hi);
    if((b.gain.score||0)-(a.gain.score||0)!==1||a.region!==b.region
      ||a.pickAlienCard!==b.pickAlienCard||Boolean(a.pickAlienCard)!==takesCard)continue;
    if(species==='amiba'&&aliens.amiba.listSymbolsInRegion(state.aliens,'red',{readOnlyRewards:true})
      .some(({reward})=>!reward||Object.keys(reward.gain||{}).some(k=>k!=='score')
        ||Object.keys(reward).some(k=>k!=='gain'&&reward[k])))continue;
    // The probe portfolio can quote the best remaining 3/4 card position.
    // Do not discard either while that extra valuation input is reachable.
    if(takesCard&&(secondPink||state.aliens.amiba.displayedCardIndex!==knownAmibaDisplay
      ||!Number.isInteger(knownAmibaDisplay)||probeCapital.ownedProbes(state.pieces.rockets,p).length))continue;
    excludedActionIds.push(low.actionId);
    proof.push({lower:low.actionId,higher:high.actionId,scoreDelta:1,sameSpecies:species,sameRegion:a.region??null,sameCardChoice:takesCard,
      continuation:secondPink?'same-two-rewards-in-opposite-order':'same-post-placement-effects'});
  }
  return excludedActionIds.length?{policy:'seti-late-pink-position-dominance-v1',kind:'rank-automatic-scan-traces',fixed:false,
    isEquivalence:false,retainedActionIds:actions.filter(a=>!excludedActionIds.includes(a.actionId)).map(a=>a.actionId),
    excludedActionIds,proof}:null;
 }
'''
s=s.replace(mark,new+mark)
mark='scoredEndCorner,pinkScoreBeforeUnknownFossil,previewQuietPinkTrace'
assert s.count(mark)==1
p.write_text(s.replace(mark,'scoredEndCorner,pinkScoreBeforeUnknownFossil,pinkPositionDominance,previewQuietPinkTrace'))
p=d/'analysis-port.js';s=p.read_text()
assert s.count('rankKnownFossilTraces = false;')==1
s=s.replace('rankKnownFossilTraces = false;','rankKnownFossilTraces = false, rankLatePinkPositions = false;')
assert s.count('rankKnownFossilTraces=options.rankKnownFossilTraces===true;')==1
s=s.replace('rankKnownFossilTraces=options.rankKnownFossilTraces===true;','rankKnownFossilTraces=options.rankKnownFossilTraces===true;rankLatePinkPositions=options.rankLatePinkPositions===true;')
mark='      if(!result&&resourcePlanning)result=quietScanTracePlan(node,stored,state);'
assert s.count(mark)==1
p.write_text(s.replace(mark,mark+'''
      if(!result&&rankLatePinkPositions&&resourcePlanning&&cardPickPlanning&&!stored.resourceControl&&!stored.intent?.path.length)result=localPlans.pinkPositionDominance({
        state,seatId,actions:node.legalActions,session:stored.envelope.session?.session,knownCards:knownCards(stored.envelope),
        knownAmibaDisplay:rootObservation.publicState.board.aliens.amibaTraces?.displayedCardIndex,
      });'''))
p=d/'decision-search.js';s=p.read_text()
s=s.replace('seti-complete-decision-search-v435','seti-complete-decision-search-v442')
mark='rankKnownFossilTraces:realizationTies===true'
assert s.count(mark)==1
p.write_text(s.replace(mark,mark+',rankLatePinkPositions:unlimited&&realizationTies===true'))
