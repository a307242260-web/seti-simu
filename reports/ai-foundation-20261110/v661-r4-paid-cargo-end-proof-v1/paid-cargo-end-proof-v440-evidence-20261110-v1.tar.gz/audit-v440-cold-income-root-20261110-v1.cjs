'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),load=f=>require(path.resolve('randomizer/game/ai',f));
const root=JSON.parse(fs.readFileSync(process.argv[3])).checkpoint,m=open(root);
const {ai}=JSON.parse(z.gunzipSync(fs.readFileSync(process.argv[4])));
try{
 const rows=ai.plan.rows,firstMove=rows.findIndex(r=>r.actionId.startsWith('move:'));
 assert(firstMove>0);
 for(const row of rows.slice(0,firstMove)){
  const action=m.menu().find(a=>a.actionId===row.actionId);
  assert(action);m.apply(action);
 }
 const saved=m.save(),p=load('analysis-port').createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  const agent=load('search-agent').createSearchAgent({seatId:seat,analysisPort:p});
  const q=agent.decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length);
  const offered=q.roots.find(r=>r.goal?.kind==="paid-income-earth-cargo");
  assert(offered&&offered.proof==="seti-native-paid-cargo-quiet-turn-boundary-v1"&&Number.isFinite(offered.value));
  assert.equal(offered.actionId,rows[firstMove].actionId);
  assert.deepEqual(m.save(),saved);
  m.restore(root);assert.deepEqual(m.save(),root);
  const result={stepsToCold:firstMove,offered,chosen:q.actionId,value:q.value,native:q.diagnostics.nativeExecutions,
   ms:q.rootAndSearchMilliseconds,rootExact:true};
  fs.writeFileSync(process.argv[5],JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result));
 }finally{p.close();}
}finally{m.dispose();}
