'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),assert=require('node:assert/strict'),Module=require('node:module');
const orig=Module._extensions['.js'],quotes=new Map(),records=[];
globalThis.provePaidEnd=(plan,finish)=>{if(finish)quotes.set(plan,finish);};
globalThis.recordPaidEnd=(plan,execution,actual)=>records.push({goal:plan.goal.id,status:execution.goalStatus,steps:execution.submissions,
  expected:quotes.get(plan),actual});
Module._extensions['.js']=(mod,file)=>{
 if(!file.endsWith('/randomizer/game/ai/analysis-port.js'))return orig(mod,file);
 let s=fs.readFileSync(file,'utf8');
 const a=s.indexOf('    function paidIncomeEarthCargoPlan('),b=s.indexOf('    function paidIncomeEarthCargoStep(',a);
 assert(a>=0&&b>a);
 let part=s.slice(a,b);
 const step='      const next=copyForkData(state),q=next.players.players.find(x=>x.id===seatId);';
 assert.equal(part.split(step).length,2);
 part=part.replace(step,step.replace('copyForkData(state)','copyForkData(readIdentityState(stored.envelope))'));
 const x='      const capital=stateValue.sumValueParts([resourceDemand.planningCapital(claim.state,claim.player),-resourceDemand.planningCapital(state,p)]);';
 assert.equal(part.split(x).length,2);
 part=part.replace(x,`      const claimView=planningState(claim.state,stored.informationBarrier,known);
      const viewOwner=claimView.players.players.find(p=>p.id===seatId);
      const capital=stateValue.sumValueParts([resourceDemand.planningCapital(claimView,viewOwner),-resourceDemand.planningCapital(state,p)]);`);
 const end='      return {id,goal,operation:{},firstActionId:first.actionId,mode:"greedy",reason:"paid-public-transport-with-positive-net-value"};';
 assert.equal(part.split(end).length,2);
 part=part.replace(end,`      const plan={id,goal,operation:{},firstActionId:first.actionId,mode:"greedy",reason:"paid-public-transport-with-positive-net-value"};
      const after={...claim.state,meta:quietSavedMeta(claim.state.meta,claim.state.meta.stateVersion+steps.length+1)};
      const end=node.legalActions.find(a=>a.family==="end_turn");
      const final=localPlans.previewFinalEndPrelude({state:after,seatId,action:end,knownCards:known,allowSameSeat:true});
      globalThis.provePaidEnd(plan,final?.finished);
      return plan;`);
 s=s.slice(0,a)+part+s.slice(b);
 const expand='    function expandResourcePlan(node,plan,hasCapacity) {';
 assert.equal(s.split(expand).length,2);
 s=s.replace(expand,`    function expandResourcePlan(node,plan,hasCapacity){
      const result=expandPaidEndAudit(node,plan,hasCapacity);
      if(plan.goal.kind==="paid-income-earth-cargo")globalThis.recordPaidEnd(plan,result,nodes.get(result.node).envelope);
      return result;
    }
    function expandPaidEndAudit(node,plan,hasCapacity) {`);
 mod._compile(s,file);
};
const {open,seat}=require(process.argv[2]),load=f=>require(path.resolve('randomizer/game/ai',f));
const root=JSON.parse(fs.readFileSync(process.argv[3])).checkpoint,m=open(root),p=load('analysis-port').createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
const eq=require('node:util').isDeepStrictEqual;
function fields(x,y,at='',result=[]){
 if(eq(x,y))return result;
 if(!x||!y||typeof x!=='object'||typeof y!=='object'){result.push(at);return result;}
 for(const k of new Set([...Object.keys(x),...Object.keys(y)]))fields(x[k],y[k],at+'.'+k,result);
 return result;
}
try{
 const q=load('search-agent').createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert.deepEqual(m.save(),root);assert(q.complete&&!q.unresolved.length);
 const cases=records.map(v=>{
  const actual=JSON.parse(v.actual.committedState);
  const expected=v.expected?JSON.parse(JSON.stringify(v.expected)):null;
  return {goal:v.goal,status:v.status,steps:v.steps,proved:!!expected,sessionOpen:!!v.actual.session,
   differences:expected?fields(expected,actual):[]};
 });
 fs.writeFileSync(process.argv[4],JSON.stringify({action:q.actionId,value:q.value,cases},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({action:q.actionId,value:q.value,proofs:cases.filter(x=>x.proved).length,exact:cases.filter(x=>x.proved&&!x.differences.length&&!x.sessionOpen).length,
  differences:[...new Set(cases.flatMap(x=>x.differences))]}));
}finally{p.close();m.dispose();}
