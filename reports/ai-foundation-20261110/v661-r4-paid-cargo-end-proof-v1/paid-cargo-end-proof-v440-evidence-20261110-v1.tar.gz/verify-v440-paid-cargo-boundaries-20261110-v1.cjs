'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),load=f=>require(path.resolve('randomizer/game/ai',f));
const root=JSON.parse(fs.readFileSync(process.argv[3])).checkpoint,m=open(root);
const p=load('analysis-port').createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
const evaluate=load('state-value').createStateValueEvaluator(seat);
const proofs=[];
const proxy={...p,close(){},paidCargoProvedBoundary(node,plan){
 const proved=p.paidCargoProvedBoundary(node,plan);
 if(proved)proofs.push({node,plan,proved});
 return proved;
}};
try{
 const agent=load('search-agent').createSearchAgent({seatId:seat,analysisPort:proxy});
 const q=agent.decide({seatId:seat,legalActions:m.menu()}).search,ai=agent.createCheckpoint();
 assert(q.complete&&!q.unresolved.length);
 assert(ai?.plan?.rows.length===21);
 assert.deepEqual(m.save(),root);
 const before=p.getDiagnostics().submissionCount;
 const cases=[];
 for(const {node,plan,proved} of proofs){
  const macro=p.expandResourcePlan(node,plan,()=>null);
  assert(macro.complete);
  assert.equal(macro.submissions,plan.goal.path.length*2+2);
  assert(p.matchesPaidCargoBoundary(proved,macro.node));
  const actual=evaluate.details(p.valueObservation(macro.node)),predicted=evaluate.details(p.valueObservation(proved));
  assert.deepEqual(actual,predicted);
  cases.push({steps:macro.submissions,paidSteps:plan.goal.path.length,netGain:plan.goal.netGain,
   inputs:macro.prefixes.map(x=>x.action.actionId),boundary:proved.boundary,value:actual.value,
   realization:-actual.unrealizedPurposeValue,preparationDebt:actual.purposePreparationDebt});
 }
 assert.deepEqual(m.save(),root);
 const report={rootExact:true,closureCases:cases,searchNative:before,auditNative:p.getDiagnostics().submissionCount-before};
 fs.writeFileSync(process.argv[4],JSON.stringify(report,null,2)+'\n',{flag:'wx'});
 fs.writeFileSync(process.argv[5],z.gzipSync(JSON.stringify({q,ai})),{flag:'wx'});
 console.log(JSON.stringify({cases:cases.length,steps:cases.reduce((n,r)=>n+r.steps,0),searchNative:before,auditNative:report.auditNative,value:q.value}));
}finally{p.close();m.dispose();}
