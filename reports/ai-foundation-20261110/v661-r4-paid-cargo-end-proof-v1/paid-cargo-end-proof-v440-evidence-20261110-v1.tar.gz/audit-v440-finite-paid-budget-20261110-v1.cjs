'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),load=f=>require(path.resolve('randomizer/game/ai',f));
const root=JSON.parse(fs.readFileSync(process.argv[3])).checkpoint,m=open(root);
const evaluate=load('state-value').createStateValueEvaluator(seat),search=load('decision-search').searchDecision;
const rows=[];
try{
 for(const budget of [
   {transitions:5000,nodes:5000,frontier:4000,milliseconds:10000},
   {transitions:20,nodes:5000,frontier:4000,milliseconds:10000},
   {transitions:5000,nodes:20,frontier:4000,milliseconds:10000},
  ]){
  const p=load('analysis-port').createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
  try{
   const options=JSON.parse(load('search-agent').createSearchAgent({seatId:seat,analysisPort:p}).getProvenance().modelChecksum).options;
   const node=p.openRoot(),q=search({port:p,root:node,evaluate,modelKey:evaluate.modelKey,budget,...options});
   const cargo=q.lines.flatMap(l=>l.edges).filter(e=>e.resourcePlan?.goal.kind==="paid-income-earth-cargo");
   assert(cargo.every(e=>e.proof!=="seti-native-paid-cargo-quiet-turn-boundary-v1"));
   assert.deepEqual(m.save(),root);
   rows.push({budget,complete:q.complete,action:q.actionId,value:q.value,reason:q.stopReason,
    cargoNative:cargo.length,transitions:q.diagnostics.transitions,native:q.diagnostics.nativeExecutions});
  }finally{p.close();}
 }
 assert.equal(rows[0].complete,true);
 assert.equal(rows[0].value,224);
 assert.equal(rows[0].cargoNative,11);
 assert.equal(rows[1].complete,false);assert.equal(rows[1].action,null);assert.equal(rows[1].reason,'transition-budget');
 assert.equal(rows[2].complete,false);assert.equal(rows[2].action,null);assert.equal(rows[2].reason,'node-budget');
 fs.writeFileSync(process.argv[4],JSON.stringify({rootExact:true,rows},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(rows));
}finally{m.dispose();}
