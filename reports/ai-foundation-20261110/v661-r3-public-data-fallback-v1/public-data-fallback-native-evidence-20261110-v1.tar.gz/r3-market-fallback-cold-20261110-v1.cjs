'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {readZ,writeZ,open,short}=require('./controlled-r3');
const {control}=require('./r3-r4-handoff-reserve-data-control-20261110-v1.cjs');
const cards=require(path.resolve('randomizer/game/cards/deck')),seat='player-white';
const [ref,output]=process.argv.slice(2),original=readZ(ref)['114-market-data-instead'].root,rows={};
const s=JSON.parse(original.committedState),beforeRng=s.meta.rngState;
for(const [i,id] of ['b_9.webp','dlc_13.png'].entries()){
 const pile=s.cards.drawPileCardIds,j=pile.indexOf(id);assert(j>=0);[pile[i],pile[j]]=[pile[j],pile[i]];
}
const altered={...original,committedState:JSON.stringify(s)};
function visible(root){
 const m=open(root);try{return [m.owner(seat),m.menu(),m.state().meta.rngState];}finally{m.dispose();}
}
assert.deepEqual(visible(altered),visible(original));
assert.deepEqual(s.meta.rngState,beforeRng);
function autonomous(root,steps){
 const m=open(root),actions=[],queries=[];let plan,stop=null;
 try{
  const turn=m.facts().turn;
  for(let i=0;i<steps;i++){
   if(m.facts().turn!==turn){stop='turn-closed';break;}
   const q=m.automatic(plan);
   queries.push({action:q.a,value:q.value,n:q.n,ms:q.ms,complete:q.complete,roots:q.roots});
   if(!q.complete||!q.a||q.n>256||q.ms>600){stop='single-point-gate';break;}
   plan=q.checkpoint;actions.push(m.apply(q.a));
  }
  const end=m.save(),assets=short(m);
  m.restore(root);actions.forEach(m.apply);assert.deepEqual(m.save(),end);m.restore(root);
  return {root,actions,queries,stop,end,assets};
 }finally{m.dispose();}
}
for(const [name,e] of [['salary-has-data',original],['neither-salary-has-data',altered]]){
 const m=open(e);
 try{
  const corner=m.corner('chong_8.webp'),r3=m.save();
  const cornerAudit=autonomous(r3,0);
  assert.deepEqual(cornerAudit.root,r3);
  const beforePass=m.automatic();
  const q=control(r3,{dataCard:'dlc_15.png',incomeCard:'amiba_9.webp',buyDataCard:'dlc_15.png'});
  assert(q.replayExact&&!q.failure,q.failure);
  const claimed=q.stages.claimed.state;
  const n=open(claimed);
  let sources;
  try{
   sources=n.player().hand.map(c=>[c.id,c.cardId,cards.getDiscardActionRewardForCard(c)?.dataCount??0]);
   if(name==='neither-salary-has-data')assert(sources.every(x=>!x[2]));
  }finally{n.dispose();}
  const after=autonomous(claimed,24);
  const pre={n:beforePass.n,ms:beforePass.ms,complete:beforePass.complete,action:beforePass.a,value:beforePass.value,roots:beforePass.roots};
  rows[name]={e,corner,r3,pre,claimed,sources,after,witness:q};
  console.log(JSON.stringify({name,pre:[pre.action?.summary,pre.value,pre.n,Math.round(pre.ms)],sources,
   after:after.queries.map(q=>[q.action?.summary,q.value,q.n,Math.round(q.ms)]),stop:after.stop,assets:after.assets}));
 }finally{m.dispose();}
}
writeZ(output,rows);
