'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {readZ,writeZ,open,short}=require('./controlled-r3');
const {control}=require('./r3-r4-handoff-reserve-data-control-20261110-v1.cjs');
const cards=require(path.resolve('randomizer/game/cards/deck')),seat='player-white';
const [source,witness,output]=process.argv.slice(2);
const asset=readZ(source)['analyze-fill-3'],origin=asset.checkpoint,kept=asset.origin;
const prior=readZ(witness).rows[0].row,outputs={};
const noDataIds=['dlc_10.png','dlc_1.png'];
function onlyHiddenSwap(root){
 const s=JSON.parse(root.committedState),pile=s.cards.drawPileCardIds;
 s.cards.passReservePiles[3]=s.cards.passReservePiles[3].map((old,i)=>{
  const id=noDataIds[i],index=pile.indexOf(id);assert(index>=4);
  const e=cards.CARD_CATALOG.find(e=>e.card_id===id);
  const {cardName,src,...fresh}=cards.createCardInstance(e,old.id.slice(5));
  assert.equal(fresh.id,old.id);
  assert(!cards.getDiscardActionRewardForCard(fresh)?.dataCount);
  pile[index]=old.cardId;
  return Object.fromEntries(Object.keys(fresh).sort().map(k=>[k,fresh[k]]));
 });
 return {...root,committedState:JSON.stringify(s)};
}
const read=e=>{const m=open(e);try{
 const before={observation:m.owner(seat),menu:m.menu(),rng:m.state().meta.rngState};
 const cold=m.automatic();
 const pass=m.act('pass');
 const options=m.menu().map(a=>{const c=m.state().cards.passReservePiles[3].find(c=>c.id===a.payload.cardInstanceId);
  assert(c);return {id:c.id,card:c.cardId,data:cards.getDiscardActionRewardForCard(c)?.dataCount??0};
 });
 m.restore(e);return {before,cold:{action:cold.a?.actionId,n:cold.n,ms:cold.ms,complete:cold.complete,value:cold.value,roots:cold.roots},pass,options};
}finally{m.dispose();}};
const baseline=read(origin),modifiedRoot=onlyHiddenSwap(origin),modified=read(modifiedRoot);
assert.deepEqual(baseline.before,modified.before);
assert.deepEqual({...baseline.cold,ms:0},{...modified.cold,ms:0});
assert.deepEqual(baseline.options.map(c=>c.data),[1,1]);
assert.deepEqual(modified.options.map(c=>c.data),[0,0]);
outputs.visibility={baseline,modified};
const controls=[
 {label:'114-no-data-reserve',root:modifiedRoot,params:{dataCard:'b_111.webp',incomeCard:'amiba_9.webp'}},
 {label:'114-market-data-instead',root:modifiedRoot,params:{dataCard:'dlc_15.png',incomeCard:'amiba_9.webp',buyDataCard:'dlc_15.png'},corner:'chong_8.webp'},
 {label:'109-kept-data',root:onlyHiddenSwap(kept),params:{dataCard:'b_111.webp',incomeCard:'amiba_9.webp'}},
];
function canon(e){
 const id=e.session?.session?.sessionId;
 return id?JSON.parse(JSON.stringify(e).replaceAll(id,'@session')):e;
}
for(const row of controls){
 const m=open(row.root);
 try{
  const prefix=row.corner?[m.corner(row.corner)]:[];
  const result=control(m.save(),row.params);
  const actions=[...prefix,...result.accepted];
  m.restore(row.root);actions.forEach(m.apply);
  const endpoint=m.save();
  const endpointKey=Object.keys(result.stages).at(-1);
  const frozen=result.end||(result.failure&&result.stages[endpointKey]?.state);
  // The failing path may have placed data after its last named checkpoint.
  m.restore(row.root);actions.forEach(m.apply);assert.deepEqual(canon(m.save()),canon(endpoint));
  if(result.end)assert.deepEqual(canon(endpoint),canon(result.end));
  let afterAnalysis;
  if(row.label==='114-market-data-instead'&&!result.failure){
   const newer=[];
   prior.actions.slice(0,12).forEach(a=>newer.push(m.apply(a)));
   const scanMenu=m.menu().map(a=>[a.summary,a.target]);
   const originalPublic=['card-64-0','card-66-0','card-67-0'];
   const allowed=scanMenu.filter(([,a])=>originalPublic.includes(a.cardInstanceId));
   afterAnalysis={scanMenu,allowed,checkpoint:m.save(),actions:newer};
  }
  m.restore(row.root);
  outputs[row.label]={...row,result,endpoint,actions,afterAnalysis};
  console.log(JSON.stringify({label:row.label,failure:result.failure,actions:actions.length,stage:endpointKey,
   end:result.stages['after-common-blue8']?.assets,afterAnalysis:afterAnalysis?.allowed}));
 }finally{m.dispose();}
}
assert.equal(outputs['114-no-data-reserve'].result.failure,'AssertionError [ERR_ASSERTION]: No known data corner for computer 6');
assert(outputs['114-market-data-instead'].result.replayExact);
assert(outputs['109-kept-data'].result.replayExact);
writeZ(output,outputs);
console.log(JSON.stringify({beforeIdentical:true,beforeAction:baseline.cold.action,beforeValue:baseline.cold.value,
 old:baseline.options,altered:modified.options}));
