'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {readZ,writeZ,open}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [fixture,key,output,expected]=process.argv.slice(2),root=readZ(fixture)[key].root,seat='player-white',m=open(root);
const port=createAnalysisPort({composition:m.c,seatId:seat});
try{
 const menu=m.menu(),trade=menu.find(a=>a.target?.tradeId==='publicity-for-card');
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:menu}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 const candidate=q.roots.find(r=>r.actionId===trade.actionId),target=q.lines[candidate.target],edge=q.lines[0].edges.find(e=>e.actionId===trade.actionId);
 const policy=q.lines[0].cardPickPolicy;
 if(expected==='fixed'){
  assert.equal(candidate.value,181);
  assert.equal(policy.goal.id,'data:analyze:6');
  assert.equal(policy.selection.cardId,'card-67-0');
  assert.equal(target.status,'information-barrier');
  assert.equal(target.boundary,'hidden_card_reveal');
 }else assert.notEqual(policy.goal.id,'data:analyze:6');
 const d={selected:q.actionId,value:q.value,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,policy,candidate,target,edge,root};
 writeZ(output,d);
 console.log(JSON.stringify({selected:d.selected,value:d.value,n:d.n,ms:Math.round(d.ms),offer:policy.selection?.cardId,
  goal:policy.goal?.id,target:target?.status,boundary:target?.boundary,tradeValue:candidate.value,trade:trade.actionId}));
}finally{port.close();m.dispose();}
