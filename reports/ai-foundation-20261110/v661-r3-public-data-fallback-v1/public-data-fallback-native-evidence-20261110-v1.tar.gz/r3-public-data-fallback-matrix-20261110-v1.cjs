'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {readZ,writeZ,open,short}=require('./controlled-r3');
const {control}=require('./r3-r4-handoff-reserve-data-control-20261110-v1.cjs');
const cards=require(path.resolve('randomizer/game/cards/deck')),seat='player-white';
const [input,output]=process.argv.slice(2),reference=readZ(input),out=[];
const slots=['dlc_10.png','dlc_1.png'];
function altered(root){
 const s=JSON.parse(root.committedState),pile=s.cards.drawPileCardIds;
 s.cards.passReservePiles[3]=s.cards.passReservePiles[3].map((old,i)=>{
  const id=slots[i],index=pile.indexOf(id);assert(index>=4);
  const e=cards.CARD_CATALOG.find(e=>e.card_id===id);
  const {cardName,src,...fresh}=cards.createCardInstance(e,old.id.slice(5));
  assert.equal(fresh.id,old.id);assert(!cards.getDiscardActionRewardForCard(fresh)?.dataCount);
  pile[index]=old.cardId;
  return Object.fromEntries(Object.keys(fresh).sort().map(k=>[k,fresh[k]]));
 });
 return {...root,committedState:JSON.stringify(s)};
}
const view=e=>{const m=open(e);try{return {observation:m.owner(seat),menu:m.menu(),rng:m.state().meta.rngState};}finally{m.dispose();}};
for(const [key,input] of Object.entries(reference.rows)){
 const root=altered(input.root);assert.deepEqual(view(root),view(input.root));
 const prior=input.row;
 for(const [slot,reserveChoice] of ['card-30-pass-3-1','card-32-pass-3-3'].entries()){
  for(const sector of ['sector-4-a','sector-3-a']){
   const m=open(root),actions=[],stages={};
   const act=(f,p)=>actions.push(m.act(f,p));
   const apply=a=>actions.push(m.apply(a));
   const cut=label=>stages[label]={state:m.save(),assets:short(m)};
   try{
    actions.push(m.corner('chong_8.webp'));cut('r3-before-pass');
    const q=control(m.save(),{reserveChoice,dataCard:'dlc_15.png',incomeCard:'amiba_9.webp',buyDataCard:'dlc_15.png'});
    assert(q.replayExact&&!q.failure,q.failure);
    q.accepted.forEach(apply);cut('after-analysis');
    assert.equal(m.player().hand.filter(c=>['card-68-0','card-69-0'].includes(c.id)).length,2);
    prior.actions.slice(0,12).forEach(apply);
    act('choose_card',a=>a.target.cardInstanceId==='card-64-0'&&a.target.nebulaId===sector);
    prior.actions.slice(13,18).forEach(apply);cut('before-landing');
    for(const a of m.swap(slots[slot],'dlc_16.png'))actions.push(a);
    prior.actions.slice(21,42).forEach(apply);
    act('choose_card',a=>a.target.cardInstanceId===reserveChoice);
    apply(prior.actions[43]);cut('end');
    const end=m.save();m.restore(root);actions.forEach(m.apply);assert.deepEqual(m.save(),end);m.restore(root);
    const facts=stages.end.assets;
    assert.deepEqual([facts.wallet[0],facts.established],sector==='sector-3-a'?[142,198]:[140,196]);
    out.push({key,sector,reserve:slots[slot],root,end,stages,actions});
    console.log(JSON.stringify([key,slot,sector,actions.length,facts.wallet,facts.established]));
   }finally{m.dispose();}
  }
 }
}
assert.equal(out.length,12);
writeZ(output,{results:out});
