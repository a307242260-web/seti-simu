'use strict';
const fs=require('node:fs'),Module=require('node:module'),path=require('node:path'),assert=require('node:assert/strict');
const js=Module._extensions['.js'];
Module._extensions['.js']=function(mod,file){
 if(!file.endsWith('/randomizer/game/ai/analysis-port.js'))return js(mod,file);
 let src=fs.readFileSync(file,'utf8');
 for(const [func,code] of Object.entries({
  physicalBucket:`note('bucket-state',state);note('bucket-rockets',state.pieces.rockets);note('bucket-public',state.cards.publicCards);for(const p of state.players.players)note('bucket-player-'+p.color,p);`,
  physicalCollisionKey:`note('collision-state',state);note('collision-data',state.data);note('collision-aliens',state.aliens);`,
 })){
  const start=src.indexOf('    function '+func+'('),p=src.indexOf('\n',src.indexOf('const state=readIdentityState(envelope)',start));
  assert(start>=0&&p>start);src=src.slice(0,p)+'\n'+code+src.slice(p);
 }
 src=src.replace('  const STATIC_IDENTITY_SLICES',`
 const buckets={};
 function note(key,obj){const row=buckets[key]||={seen:new WeakSet(),count:0,repeated:0,frozen:0};row.count++;
  if(row.seen.has(obj))row.repeated++;else row.seen.add(obj);if(Object.isFrozen(obj))row.frozen++;
 }
 process.on('exit',()=>console.error('BUCKET_AUDIT '+JSON.stringify(buckets)));
  const STATIC_IDENTITY_SLICES`);
 mod._compile(src,file);
};
const {open,seat}=require('./native-compact-20261110-v1.cjs');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [file,out]=process.argv.slice(2),{checkpoint:root}=JSON.parse(fs.readFileSync(file)),m=open(root);
const p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 fs.writeFileSync(out,JSON.stringify(q),{flag:'wx'});
}finally{p.close();m.dispose();}
