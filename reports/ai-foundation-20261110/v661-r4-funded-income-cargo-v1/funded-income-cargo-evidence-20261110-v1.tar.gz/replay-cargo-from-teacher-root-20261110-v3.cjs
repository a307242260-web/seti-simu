'use strict';
const fs=require('node:fs'),z=require('node:zlib'),assert=require('node:assert/strict'),path=require('node:path');
const {open,seat}=require(process.argv[2]);
const read=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const root=JSON.parse(fs.readFileSync(process.argv[3])).checkpoint;
const capture=read(process.argv[4]),ends=read(process.argv[5]),m=open(root);
const {createStateValueEvaluator}=require(path.resolve('randomizer/game/ai/state-value'));
const {sanitizeHiddenInformationObservation}=require(path.resolve('randomizer/game/rule-composition'));
const evalValue=createStateValueEvaluator(seat),rootObservation=m.owner(seat);
const prefix=new Map();
for(const e of capture.q.sharedPrefixGraph.edges){
 if(!prefix.has(e.from))prefix.set(e.from,[]);
 prefix.get(e.from).push(e);
}
function shortest(target){
 const queue=[[0,[],[]]],seen=new Set();
 while(queue.length){
  queue.sort((a,b)=>b[1].length-a[1].length);
  const [i,steps,edges]=queue.pop();
  if(seen.has(i))continue;
  if(i===target)return{steps,edges};
  seen.add(i);
  for(const e of prefix.get(i)||[])
   if(!seen.has(e.to))queue.push([e.to,[...steps,e.actionId],[...edges,e.id]]);
 }
 throw Error('no real input path to node '+target);
}
try{
 const rank=ends.rows.filter(r=>r.candidate.closed).sort((a,b)=>b.candidate.end.value-a.candidate.end.value);
 const best=rank[0].candidate.end.value;
 const results=[];
 for(const outcome of rank.filter((r,i)=>i===rank.findIndex(t=>t.original.index===r.original.index)).slice(0,3)){
  const input=capture.rows.find(r=>r.root===outcome.root&&r.replay);
  assert(input&&Number.isSafeInteger(input.prefixTarget));
  const plan=shortest(input.prefixTarget);
  function replay(){
   m.restore(root);
   const actions=[];
   for(const id of plan.steps){
    const a=m.menu().find(x=>x.actorId===seat&&x.actionId===id);assert(a,id);actions.push(m.apply(a));
   }
   const arrival=m.save(),actual=JSON.parse(arrival.committedState),target=JSON.parse(input.replay.checkpoint.committedState);
   const view=s=>({turn:s.turn,players:s.players,pieces:s.pieces,solarSystem:s.solarSystem,data:s.data,
    finalScoring:s.finalScoring,planets:s.planets,chong:s.aliens.chong});
   if(!require('node:util').isDeepStrictEqual(view(actual),view(target))){
    const delta=Object.keys(view(actual)).filter(k=>!require('node:util').isDeepStrictEqual(view(actual)[k],view(target)[k]));
    throw Error('DIFFERENT_REPLAY_SLICES '+delta.join(','));
   }
   assert.equal(arrival.session,input.replay.checkpoint.session);
   for(const a of outcome.candidate.a)actions.push(m.apply(a));
   const end=m.save(),expected=JSON.parse(outcome.candidate.checkpoint.committedState);
   if(!require('node:util').isDeepStrictEqual(view(JSON.parse(end.committedState)),view(expected)))
    throw Error('DIFFERENT_CARGO_ENDPOINT');
   const projected=m.c.projection({role:'player',playerId:seat,valueOnly:true}).state;
   const visible=outcome.barrier?sanitizeHiddenInformationObservation(rootObservation,projected,
    {code:outcome.barrier},input.replay.known):projected;
   const nativeV=evalValue(visible);
   assert.equal(nativeV,outcome.candidate.end.value);
   return {actions,checkpoint:m.save(),facts:m.facts(),nativeV};
  }
  const first=replay(),second=replay();assert.deepEqual(first,second);
  results.push({root:outcome.root,graphNode:outcome.original.index,plan,fromOriginalPolicy:outcome.original.value,
   nativeV:outcome.candidate.end.value,oldRootV:capture.q.value,prefixInputs:plan.steps.length,
   cargoInputs:outcome.candidate.a.length,first});
 }
 assert.equal(results[0].nativeV,best);
 m.restore(root);assert.deepEqual(m.save(),root);
 fs.writeFileSync(process.argv[6],z.gzipSync(JSON.stringify({rootExact:true,results})),{flag:'wx'});
 for(const v of results)console.log(JSON.stringify({root:v.root,index:v.graphNode,policy:v.fromOriginalPolicy,nativeV:v.nativeV,fromRoot:v.prefixInputs,cargo:v.cargoInputs,families:v.first.actions.map(a=>a.family)}));
}finally{m.dispose();}
