'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),Module=require('node:module'),path=require('node:path');
const cards=require(path.resolve('randomizer/game/cards/deck')),data=require(path.resolve('randomizer/game/data'));
const hook=Module._extensions['.js'], rows=[], specTimes=[], actions={};
const loadGame=f=>require(path.resolve('randomizer/game',f));
const rockets=loadGame('rockets'),solar=require(path.resolve('randomizer/solar-system/core'));
const ability=loadGame('abilities/rocket');
globalThis.captureTrackedAction=(a)=>{
 if(!['complete_task','move','quick_trade'].includes(a.family))return;
 const fact=[a.family,a.target,a.payload],ref=actions[a.actionId];
 if(ref)assert.deepEqual(ref,fact);else actions[a.actionId]=fact;
};
function cargoFacts(state){
 const seatId='player-white',p=state.players.players.find(p=>p.id===seatId);
 const earth=solar.collectPlanetLocations(state.solarSystem).find(p=>p.planetId==='earth');
 const jobs=Object.entries(state.aliens.chong?.transportTasksByRocketId||{}).map(([rocketId,j])=>{
  const matches=state.pieces.rockets.filter(r=>r.kind==='chong-fossil'&&r.fossilId===j.fossilId);
  assert(matches.length<=1,j.fossilId);
  const ship=state.pieces.rockets.find(r=>String(r.id)===rocketId)||matches[0];
  const fossil=state.aliens.chong.fossilsById[j.fossilId];
  assert(fossil,j.fossilId);
  const at=ship&&rockets.getRocketSectorCoordinate(ship);
  // Optimistic geometry only: no acquisition, triggers, forecasts or future rotation.
  // Query the same legal ring edges and payment costs as production.
  let routeCost=null,route=null;
  if(at&&earth&&!j.delivered&&!ship.movementLocked){
   const key=p=>p.x+':'+p.y,best=new Map([[key(at),0]]),queue=[[at,0,[]]],move=rockets.createStaticCoordinateMoveQuery(state.pieces,ship.id);
   while(queue.length){
    queue.sort((a,b)=>b[1]-a[1]);
    const [point,cost,steps]=queue.pop();
    if(cost!==best.get(key(point)))continue;
    if(point.x===earth.x&&point.y===earth.y){routeCost=cost;route=steps;break;}
    const costNext=cost+ability.getRequiredMovePointsFromCoordinate(state,p,point);
    for(const d of ability.MOVE_DIRECTIONS){
     const r=move(point,d.deltaX,d.deltaY);
     if(r.ok&&costNext<(best.get(key(r.to))??Infinity)){best.set(key(r.to),costNext);queue.push([r.to,costNext,[...steps,{deltaX:d.deltaX,deltaY:d.deltaY}]]);}
    }
   }
  }
  return {rocketId:Number(rocketId),fossilStatus:fossil.status,carrierRocketId:ship?.id??null,shipPresent:!!ship,lock:ship?.movementLocked??null,fossilId:j.fossilId,cardId:j.cardId,delivered:!!j.delivered,destination:j.destinationPlanetId,at,earth,routeCost,route};
 });
 return {credits:p.resources.credits,energy:p.resources.energy,pool:p.resources.availableData,
  knownMoveCorners:p.hand.reduce((n,c)=>n+(cards.getDiscardActionMoveRewardForCard(c)?.movementPoints||0),0),
  jobs};
}
const group=(o,keys)=>Object.fromEntries(keys.filter(k=>Object.hasOwn(o,k)).map(k=>[k,o[k]]));
globalThis.capturePlan=(node,stored,state,plan,out,ms,after,afterEnvelope,known,prefixSource,prefixTarget)=>{
 const owner=state.players.players.find(p=>p.id==='player-white');
 const replay=plan.goal.kind==='income'&&owner.mainActionCompleted&&out.node.status==='stable'?cargoFacts(after):null;
 const input=out.prefixes.map(({node,action})=>({id:action.actionId,family:action.family,target:action.target,phase:action.phase}));
 rows.push({root:stored.serial,status:node.status,bound:!!stored.resourceControl,boundary:node.boundary,ownerMain:owner.mainActionCompleted,
  prefixSource,prefixTarget,wallet:owner.resources,goal:plan.goal,operation:plan.operation,planId:plan.id,mode:plan.mode,
  ...(plan.goal.kind==='income'?{cargoBefore:cargoFacts(state),cargoAfter:cargoFacts(after)}:{}),
  ...(replay?.jobs[0]?.routeCost>0&&replay.energy>=replay.jobs[0].routeCost?{replay:{route:replay.jobs[0].route,carrier:replay.jobs[0].carrierRocketId,
   fossilId:replay.jobs[0].fossilId,cardId:replay.jobs[0].cardId,checkpoint:afterEnvelope,known:[...known]}}:{}),
  incomeGain:plan.goal.incomeCardId?cards.getIncomeGainForCard(owner.hand.find(c=>c.id===plan.goal.incomeCardId)):null,
  computerSlots:data.listComputerPlacedTokens(owner).map(t=>t.placementSlot),blueSlots:data.listBlueBonusPlacedTokens(owner).map(t=>t.blueSlot),
  knownTransportCount:Object.keys(state.aliens.chong?.transportTasksByRocketId||{}).length,
  turnBonuses:(state.turn.cardTurnEventBonuses||[]).length, priorTriggerEvents:(state.turn.type1TriggerEvents||[]).map(e=>e.type),
  activeSlots:state.turn.activePlayerIds.filter(id=>!state.turn.passedPlayerIds.includes(id)),
  endStatus:out.node.status,endBoundary:out.node.boundary,endGoalStatus:out.goalStatus,reason:out.reason,
  fallback:out.fallbackReason,stop:out.stopReason,complete:out.complete,submissions:out.submissions,newSubmissions:out.newSubmissions,
  sharedPath:out.sharedPath,inputs:input,ms});
};
globalThis.captureSpec=(node,stored,out,ms)=>{specTimes.push({root:stored.serial,status:node.status,alreadyBound:!!stored.resourceControl,
 plans:out?.plans.map(p=>({id:p.id,kind:p.goal.kind,firstActionId:p.firstActionId}))||[],ms})};
Module._extensions['.js']=(mod,file)=>{
 if(!file.endsWith('/randomizer/game/ai/analysis-port.js'))return hook(mod,file);
 let s=fs.readFileSync(file,'utf8');
 const prefix='    function rememberPrefix(key,node,actionId,child){';
 assert.equal(s.split(prefix).length,2);
 s=s.replace(prefix,prefix+'\n      globalThis.captureTrackedAction(node.legalActions.find(a=>a.actionId===actionId));');
 for(const [mark,alt] of [
  ['    function expandResourcePlan(node,plan,hasCapacity) {',`    function expandResourcePlan(node,plan,hasCapacity) {
      const at=performance.now(),out=expandResourcePlanUnobserved(node,plan,hasCapacity),ms=performance.now()-at,stored=nodes.get(node);
      globalThis.capturePlan(node,stored,readPlanningState(stored),plan,out,ms,readPlanningState(nodes.get(out.node)),nodes.get(out.node).envelope,knownCards(nodes.get(out.node).envelope),prefixNodes.get(node),prefixNodes.get(out.node));return out;
    }
    function expandResourcePlanUnobserved(node,plan,hasCapacity) {`],
  ['    function resourceSpec(node) {',`    function resourceSpec(node) {
      const at=performance.now(),out=resourceSpecUnobserved(node),ms=performance.now()-at;
      globalThis.captureSpec(node,nodes.get(node),out,ms);return out;
    }
    function resourceSpecUnobserved(node) {`]
 ]){
  assert.equal(s.split(mark).length,2);s=s.replace(mark,alt);
 }
 mod._compile(s,file);
};
const {open,seat}=require(process.argv[2]),{createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const {checkpoint:root}=JSON.parse(fs.readFileSync(process.argv[3])),m=open(root);
const port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 fs.writeFileSync(process.argv[4],require('node:zlib').gzipSync(JSON.stringify({rows,specTimes,q,actions})),{flag:'wx'});
 console.log(JSON.stringify({rows:rows.length,specs:specTimes.length,choice:q.actionId,value:q.value}));
}finally{port.close();m.dispose();}
