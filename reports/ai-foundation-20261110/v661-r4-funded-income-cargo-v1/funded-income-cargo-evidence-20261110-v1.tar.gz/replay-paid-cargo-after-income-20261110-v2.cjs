'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),{createStateValueEvaluator}=require(path.resolve('randomizer/game/ai/state-value'));
const value=createStateValueEvaluator(seat);
const {sanitizeHiddenInformationObservation}=require(path.resolve('randomizer/game/rule-composition'));
const root=JSON.parse(fs.readFileSync(process.argv[3])).checkpoint,d=JSON.parse(z.gunzipSync(fs.readFileSync(process.argv[4]))),m=open(root);
const rows=[],rootObservation=m.owner(seat);
const byPath=new Map(),lines=new Map(d.q.lines.map(l=>[l.node,l]));
for(const line of d.q.lines)for(const e of line.edges)
 if(e.resourcePlan?.goal.kind==='income')byPath.set(JSON.stringify(e.sharedPath),{index:e.target,value:lines.get(e.target).value});
let active;
function phase(){
 const s=m.state(),p=s.players.players.find(v=>v.id===seat);
 const projected=m.c.projection({role:'player',playerId:seat,valueOnly:true}).state;
 const visible=active?.endBoundary?sanitizeHiddenInformationObservation(rootObservation,projected,
  {code:active.endBoundary},active.replay.known):projected;
 return {round:s.turn.roundNumber,turn:s.turn.turnNumber,score:p.resources.score,
  final:projected.publicState.players.find(p=>p.playerId===seat).finalScore,
  wallet:p.resources,income:p.income,rng:s.meta.rngState,ship:s.pieces.rockets.find(r=>r.fossilId==='fossil_07'),
  taskCount:p.completedTaskCount,fossil:s.aliens.chong.fossilsById.fossil_07.status,value:value(visible),capital:value.details(visible).unrealizedPurposeValue};
}
function witness(test,withCargo){
 const a=[];
 const pick=(family,rule)=>{const x=m.menu().find(c=>c.family===family&&c.actorId===seat&&rule(c));if(!x)throw Error('MISSING '+family+' '+JSON.stringify(m.menu().map(c=>[c.family,c.target,c.payload])).slice(0,1300));a.push(m.apply(x));return x;};
 function settleOptional(){
  for(let i=0;i<8&&m.c.inspect().phase==='awaiting_input';i++){
   pick('accept_optional_effect',c=>String(c.target?.choiceId||'').startsWith('skip:'));
  }
  assert.notEqual(m.c.inspect().phase,'awaiting_input');
 }
 try{
  if(withCargo){
   for(const move of test.route){
    pick('move',c=>c.target?.rocketId===test.carrier&&c.target.deltaX===move.deltaX&&c.target.deltaY===move.deltaY);
    pick('choose_payment',c=>c.target?.kind==='move-payment'&&c.target.cardIds?.length===0&&c.payload.energyCost>0);
    settleOptional();
   }
   assert.equal(m.state().aliens.chong.fossilsById[test.fossilId].status,'delivered');
   pick('complete_task',c=>c.target?.cardInstanceId===test.cardId&&c.target.ruleId==='transport');
   settleOptional();
   assert.equal(m.state().aliens.chong.fossilsById[test.fossilId].status,'panel');
  }
  const afterActions=phase();
  pick('end_turn',()=>true);
  settleOptional();
  return {a,afterActions,end:phase(),checkpoint:m.save(),closed:true};
 }catch(error){return{a,error:error.message,at:phase(),closed:false};}
}
try{
 for(const row of d.rows.filter(r=>r.replay)){
  const r=row.replay;active=row;
  assert(m.c.lifecycle.restore(r.checkpoint,{silent:true}).ok);
  const anchor=m.save(),before=phase();
  const baseline=witness(r,false);
  m.restore(anchor);const candidate=witness(r,true);
  m.restore(anchor);const again=witness(r,true);
  assert.deepEqual(again,candidate);
  if(candidate.closed&&baseline.closed){
   assert.deepEqual(candidate.end.rng,baseline.end.rng);
   assert.equal(candidate.end.turn,baseline.end.turn);
  }
  const original=byPath.get(JSON.stringify(row.sharedPath));assert(original);
  rows.push({root:row.root,original,barrier:row.endBoundary,before,route:r.route,baseline,candidate,againExact:true});
 }
 m.restore(root);assert.deepEqual(m.save(),root);
 const report={cases:rows.length,closed:rows.filter(r=>r.baseline.closed&&r.candidate.closed).length,rows};
 fs.writeFileSync(process.argv[5],z.gzipSync(JSON.stringify(report)),{flag:'wx'});
 for(const r of rows.slice(0,4))console.log(JSON.stringify({root:r.root,route:r.route,error:r.candidate.error,baseline:r.baseline.end&&{value:r.baseline.end.value,final:r.baseline.end.final},cargo:r.candidate.end&&{value:r.candidate.end.value,final:r.candidate.end.final}}));
 console.log(JSON.stringify({cases:report.cases,closed:report.closed}));
}finally{m.dispose();}
