'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),z=require('node:zlib');
const {open,seat}=require(process.argv[2]);
const load=n=>require(path.resolve('randomizer/game/ai',n));
const {createSearchAgent}=load('search-agent'),{createAnalysisPort}=load('analysis-port');
const root=JSON.parse(fs.readFileSync(process.argv[3])).checkpoint;
const evidence=JSON.parse(z.gunzipSync(fs.readFileSync(process.argv[4])));
const m=open(root),results=[];
try{
 const rows=evidence.ai.plan.rows;
 let checkpoint=evidence.ai;
 for(let i=0;i<rows.length;i++){
  const row=rows[i],before=m.save();
  const legal=m.menu(),a=legal.find(x=>x.actionId===row.actionId&&x.actorId===seat);
  assert(a,row.actionId);
  let diagnostics=null;
  if(i){
   const port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
   try{
    const agent=createSearchAgent({seatId:seat,analysisPort:port});
    agent.loadCheckpoint(checkpoint);
    const {search:q}=agent.decide({seatId:seat,legalActions:legal});
    assert.deepEqual(m.save(),before);
    diagnostics={actionId:q.actionId,value:q.value,ms:q.rootAndSearchMilliseconds,native:q.diagnostics.nativeExecutions,
      reused:q.diagnostics.planContinuation==='hit'||q.reusedCoverage?.proof==='seti-complete-window-best-prefix-reuse-v1',
      reuseReason:q.diagnostics.planContinuation,complete:q.complete};
    checkpoint=agent.createCheckpoint()??checkpoint;
   }catch(error){
    diagnostics={error:error.message,code:error.code};
   }finally{port.close();}
  }
  m.apply(a);
  results.push({i,expected:row.actionId,family:a.family,summary:a.summary,sourceNode:row.sourceNode,
   match:diagnostics?diagnostics.actionId===row.actionId:true,diagnostics});
 }
 const end=m.save(),facts=m.facts();
 m.restore(root);
 for(const row of rows){const a=m.menu().find(a=>a.actionId===row.actionId);assert(a);m.apply(a);}
 assert.deepEqual(m.save(),end);
 m.restore(root);assert.deepEqual(m.save(),root);
 const result={results,end,facts,rootExact:true,endExact:true};
 fs.writeFileSync(process.argv[5],z.gzipSync(JSON.stringify(result)),{flag:'wx'});
 console.log(JSON.stringify({steps:results.length,matched:results.filter(r=>r.match).length,
  reused:results.filter(r=>r.diagnostics?.reused).length,changes:results.filter(r=>!r.match),
  maxMs:Math.max(0,...results.map(r=>r.diagnostics?.ms||0)),final:facts.final,wallet:facts.wallet}));
}finally{m.dispose();}
