'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),z=require('node:zlib');
const {open,seat}=require(process.argv[2]);
const root=JSON.parse(fs.readFileSync(process.argv[3])).checkpoint;
const gz=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const {q,ai}=gz(process.argv[4]),{end}=gz(process.argv[5]);
const {sanitizeHiddenInformationObservation}=require(path.resolve('randomizer/game/rule-composition'));
const {createStateValueEvaluator}=require(path.resolve('randomizer/game/ai/state-value'));
const value=createStateValueEvaluator(seat),m=open(root);
const project=()=>m.c.projection({role:'player',playerId:seat,valueOnly:true}).state;
try{
 const r=m.owner(seat);
 m.restore(end);
 const leaf=q.lines.find(l=>l.node===ai.plan.source.boundaryWitness.node);
 const p=project(),masked=sanitizeHiddenInformationObservation(r,p,{code:leaf.boundary});
 const parts=value.details(masked);
 assert.equal(parts.value,q.value);
 assert.equal(parts.unrealizedPurposeValue,-q.realization);
 m.restore(root);
 assert.deepEqual(m.save(),root);
 fs.writeFileSync(process.argv[6],JSON.stringify({leaf:leaf.node,barrier:leaf.boundary,masked:true,rootExact:true,value:parts},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({leaf:leaf.node,barrier:leaf.boundary,value:parts.value,realization:-parts.unrealizedPurposeValue}));
}finally{m.dispose();}
