'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const js=Module._extensions['.js'],records=[],plans=[];
let paidDepth=0;
globalThis.isPaidAudit=()=>paidDepth>0;
globalThis.paidEnter=()=>{paidDepth++;};
globalThis.paidExit=()=>{paidDepth--;};
globalThis.paidDone=(plan,out,root)=>plans.push({plan,out,root});
globalThis.captureBlindScopedEdge=(before,after,a,node)=>records.push({before,after,a,node});
Module._extensions['.js']=(mod,file)=>{
 if(!file.endsWith('/randomizer/game/ai/analysis-port.js'))return js(mod,file);
 let s=fs.readFileSync(file,'utf8'),marker='    function expand(node, actionId, previewOnly = false) {';
 assert.equal(s.split(marker).length,2);
 s=s.replace(marker,`    function expand(node,actionId,previewOnly=false){
      const a=nodes.get(node),next=expandScopedAudit(node,actionId,previewOnly);
      const b=next&&nodes.get(next);
      if(a&&b&&globalThis.isPaidAudit())
        globalThis.captureBlindScopedEdge(a.envelope,b.envelope,node.legalActions.find(a=>a.actionId===actionId),next);
      return next;
    }
    function expandScopedAudit(node, actionId, previewOnly = false) {`);
 const plan='    function expandResourcePlan(node,plan,hasCapacity) {';
 assert.equal(s.split(plan).length,2);
 s=s.replace(plan,`    function expandResourcePlan(node,plan,hasCapacity){
      if(plan.goal.kind!=="paid-income-earth-cargo")return expandPaidAudit(node,plan,hasCapacity);
      globalThis.paidEnter();
      try{const out=expandPaidAudit(node,plan,hasCapacity);
        globalThis.paidDone(plan,{complete:out.complete,goalStatus:out.goalStatus,reason:out.reason,
         inputs:out.prefixes.map(p=>p.action),boundary:out.node.boundary,after:nodes.get(out.node).envelope},nodes.get(node).envelope);
        return out;
      }finally{globalThis.paidExit();}
    }
    function expandPaidAudit(node,plan,hasCapacity) {`);
 mod._compile(s,file);
};
const {open,seat}=require(process.argv[2]),{createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const {checkpoint:root}=JSON.parse(fs.readFileSync(process.argv[3])),m=open(root);
const p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
const native=m.c.counterfactualPort.createFork(root,{branchKey:'audit-scope-graph',restoreRandomState:true}).composition;
const eq=(a,b)=>require('node:util').isDeepStrictEqual(a,b);
function sameSession(a,b,fresh){
 if(eq(a,b))return {ok:true,renamed:false};
 const x=a?.session.sessionId,y=b?.session.sessionId;
 if(!fresh||!/^effect-session-\d+$/.test(x)||!/^effect-session-\d+$/.test(y)||x===y)return {ok:false,renamed:false};
 const canonical=(value,id)=>{
  if(typeof value==='string')return value===id||value.startsWith(id+':')?'fresh-session'+value.slice(id.length):value;
  if(!value||typeof value!=='object')return value;
  return Array.isArray(value)?value.map(x=>canonical(x,id)):Object.fromEntries(Object.entries(value).map(([key,v])=>[key,canonical(v,id)]));
 };
 return {ok:eq(canonical(a,x),canonical(b,y)),renamed:true};
}
try{
 const agent=createSearchAgent({seatId:seat,analysisPort:p});
 const q=agent.decide({seatId:seat,legalActions:m.menu()}).search;
 const ai=agent.createCheckpoint();
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 const seen=new WeakMap(),checks={},mismatch=[];
 let compared=0,hiddenStops=0,freshSessionIdAliases=0;
 for(const {before,after,a,node} of records){
  const k=a.actionId,paths=seen.get(before)||new Set();
  if(paths.has(k))continue;paths.add(k);seen.set(before,paths);
  const restore=native.lifecycle.restore(before,{trustedFork:true,silent:true,inPlace:true,skipProjection:true,
    trustedState:JSON.parse(before.committedState)});
  assert(restore.ok,restore.message);
  const decision=native.inspect().session?.decision;
  const full=decision?.choices||native.inputPort.enumerateActions({}),ref=full.find(x=>x.actionId===k);
  assert(ref,k);assert.deepEqual(ref,a);
  const options={skipProjection:true,omitTrustedResult:true};
  const applied=decision?native.inputPort.submitDecision({decisionId:decision.decisionId,decisionVersion:decision.decisionVersion,ownerId:decision.ownerId,choice:ref},options)
    :ref.phase==='quick'?native.inputPort.submitQuickAction(ref,options):native.inputPort.submitAction(ref,options);
  assert(applied.ok,applied.message);
  const real=native.lifecycle.save().envelope,x=JSON.parse(after.committedState),y=JSON.parse(real.committedState);
  const type=before.session?.session.queue?.[0]?.type||a.family;
  const session=sameSession(after.session,real.session,!before.session);
  if(session.ok&&session.renamed)freshSessionIdAliases++;
  if(!eq(x,y)||!session.ok){
   const u=after.session?.session,v=real.session?.session;
   mismatch.push({type,a:a.summary,state:Object.keys(x).filter(k=>!eq(x[k],y[k])),
    session:u&&v&&Object.keys(u).filter(k=>!eq(u[k],v[k])),
    base:u&&v&&Object.keys(u.baseState).filter(k=>!eq(u.baseState[k],v.baseState[k])),
    journal:u&&v&&Object.keys(u.journal).filter(k=>!eq(u.journal[k],v.journal[k])),
    working:u&&v&&Object.keys(u.workingState).filter(k=>!eq(u.workingState[k],v.workingState[k]))});
  }
  if(node.legalActions.length){
   const d=native.inspect().session?.decision,options=d?.choices||native.inputPort.enumerateActions({});
   for(const a of node.legalActions)assert.deepEqual(a,options.find(x=>x.actionId===a.actionId));
  }
  if(node.boundary==='hidden_chong_fossil_offer'){assert(!node.legalActions.length);hiddenStops++;}
  checks[type]=(checks[type]||0)+1;compared++;
 }
 assert.deepEqual(m.save(),root);
 fs.writeFileSync(process.argv[4],JSON.stringify({compared,hiddenStops,freshSessionIdAliases,checks,mismatch,rootExact:true,plans:plans.map(p=>({status:p.out.goalStatus,inputs:p.out.inputs.length,first:p.plan.firstActionId,net:p.plan.goal.netGain})),rank:{value:q.value,action:q.actionId},planCertificateRows:ai?.plan?.rows.length??0},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({compared,hiddenStops,freshSessionIdAliases,mismatches:mismatch.length,examples:mismatch.slice(0,5),checks}));
 if(process.argv[5])fs.writeFileSync(process.argv[5],require('node:zlib').gzipSync(JSON.stringify({plans,ai,q})),{flag:'wx'});
 assert.equal(mismatch.length,0);
 assert(plans.every(p=>p.out.complete&&['completed','boundary'].includes(p.out.goalStatus)),JSON.stringify(plans.map(p=>[p.out.goalStatus,p.out.reason])));
}finally{native.dispose();p.close();m.dispose();}
