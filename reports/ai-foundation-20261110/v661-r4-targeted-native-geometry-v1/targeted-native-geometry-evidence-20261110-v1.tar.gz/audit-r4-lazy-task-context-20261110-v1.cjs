'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),crypto=require('node:crypto');
const [source,official,which,mode,out]=process.argv.slice(2),load=n=>require(path.resolve(n));
const original=Module._extensions['.js'];
const counters={contexts:0,probeContexts:0,dataContexts:0,menus:0,settlements:0};
const audit=mode==='audit';
const legacyPath=process.argv[7];
globalThis.countTaskContext=()=>counters.contexts++;
globalThis.countTaskProbes=()=>counters.probeContexts++;
globalThis.countTaskData=()=>counters.dataContexts++;
globalThis.verifySettlements=(before,after,expected,actual)=>{
 assert.deepEqual(actual,expected);
 assert.deepEqual(after,before);
 counters.menus++;
 counters.settlements+=actual.length;
};
if(audit)Module._extensions['.js']=(m,p)=>{
 if(!p.endsWith('/randomizer/game/effects/residual-domain-session.js'))return original(m,p);
 let code=fs.readFileSync(p,'utf8');
 const prior=fs.readFileSync(legacyPath,'utf8');
 const oldContext=prior.split('  function buildCardTaskContext(')[1].split('  function rewardEffects(')[0];
 const oldList=prior.split('  function listCardSettlements(')[1].split('  function findCardSettlement(')[0].replace('buildCardTaskContext(root)','priorTaskContext(root)');
 const anchor='  function findCardSettlement(';
 assert.equal(code.split(anchor).length,2);
 code=code.replace('  function listCardSettlements(','  function currentCardSettlements(')
  .replace('    let probeData, dataTotals;', '    globalThis.countTaskContext();\n    let probeData, dataTotals;')
  .replace('() => probeData ??= rockets.buildProbeLocationData(root)','() => probeData ??= (globalThis.countTaskProbes(),rockets.buildProbeLocationData(root))')
  .replace('        return dataTotals ??= Object.fromEntries','        if(!dataTotals)globalThis.countTaskData();\n        return dataTotals ??= Object.fromEntries');
 code=code.replace(anchor,`  function priorTaskContext(${oldContext}  function priorCardSettlements(${oldList}  function listCardSettlements(root,ownerId){
   const copy=structuredClone(root);
   const expected=priorCardSettlements(copy,ownerId);
   const actual=currentCardSettlements(root,ownerId);
   globalThis.verifySettlements(copy.players,root.players,expected,actual);
   return actual;
 }\n`+anchor);
 return m._compile(code,p);
};
const {open,seat}=require('./native-late-r3'),agent=load('randomizer/game/ai/search-agent'),
 {createAnalysisPort}=load('randomizer/game/ai/analysis-port');
const fixture=JSON.parse(z.gunzipSync(fs.readFileSync(source))),root=which==='official'?JSON.parse(fs.readFileSync(official)).checkpoint:
 fixture.rows.find(r=>r.summary.i===Number(which)).root;
const m=open(root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=agent.createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 const semantic={actionId:q.actionId,value:q.value,realization:q.realization,preparationDebt:q.preparationDebt,roots:q.roots,lines:q.lines,
  transitions:q.diagnostics.transitions,nativeExecutions:q.diagnostics.nativeExecutions};
 const canonical=x=>Array.isArray(x)?x.map(canonical):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,canonical(x[k])])):x;
 const graph=crypto.createHash('sha256').update(JSON.stringify(canonical(semantic))).digest('hex');
 
 const r={which,mode,graph,counters,ms:q.rootAndSearchMilliseconds,native:q.diagnostics.nativeExecutions,logical:q.diagnostics.transitions,
  eval:q.diagnostics.valueEvaluations,nodes:q.lines.length,rootAndRngExact:true};
 fs.writeFileSync(out,JSON.stringify(r,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(r));
}finally{p.close();m.dispose();}
