from pathlib import Path
import gzip,json,statistics,subprocess,sys,tempfile
w=Path(__file__).resolve().parent
previous,new,out=map(Path,sys.argv[1:])
items=(('previous',previous),('candidate',new))
rows=[]
with tempfile.TemporaryDirectory() as d:
 for mode in ('root-317','root-318','root-359','root-official'):
  for rep in range(3):
   pair=[]
   for label,cwd in (items if rep%2==0 else items[::-1]):
    target=Path(d)/f'{mode}-{label}-{rep}.json.gz'
    cmd=['node',str(w/'verify-cargo-research-corner-20261109-v1.cjs'),str(w/'teacher-r4-ready-transport-cold-20261109-v1.json.gz'),str(w/'v661-r4-full-preflight-20261109-v1.json'),mode,str(target)]
    subprocess.run(cmd,cwd=cwd,check=True,text=True,capture_output=True)
    raw=json.load(gzip.open(target,'rt'))
    pair.append(raw)
    rows.append({'version':label,'rep':rep,**{k:raw[k] for k in ('mode','native','ms','value','action','rootExact','complete','unresolved')}})
   assert all(pair[0].get(k)==pair[1].get(k) for k in ('action','value','retained','complete','unresolved','plan')),mode
  per=[x for x in rows if x['mode']==mode]
  summary={k:{'native':sorted({x['native'] for x in per if x['version']==k}),'msMedian':round(statistics.median(x['ms'] for x in per if x['version']==k),1),
   'msRange':[round(y,1) for y in (min(x['ms'] for x in per if x['version']==k),max(x['ms'] for x in per if x['version']==k))]} for k,_ in items}
  print(mode,summary,flush=True)
with out.open('x') as f:json.dump(rows,f,ensure_ascii=False,indent=2)
