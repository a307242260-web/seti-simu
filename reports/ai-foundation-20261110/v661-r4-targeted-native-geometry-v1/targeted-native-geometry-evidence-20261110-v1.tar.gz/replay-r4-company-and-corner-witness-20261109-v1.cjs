'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {open,seat}=require('./native-late-r3');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const witnesses=require(path.resolve(__dirname,process.argv[3]||'r4-company-and-corner-witness-20261109-v1.json'));
const result=[];
for(const witness of witnesses){
 const m=open(root),rows=[];
 const lite=()=>{
  const f=m.facts(),s=m.state(),p=m.player();
  return {score:p.resources.score,established:f.final,wallet:p.resources,hand:f.hand,computer:f.computer,blue:f.blue,
   reserved:f.reserved,tech:Object.keys(p.techState.ownedTiles).filter(x=>p.techState.ownedTiles[x]),income:p.income,
   traces:f.traces,finalMarks:Object.fromEntries(Object.entries(s.finalScoring.tiles).map(([id,t])=>[id,t.marks.filter(m=>m.playerId===seat)])),
   probes:f.probes,market:f.market,turn:s.turn.turnNumber,actor:s.turn.currentPlayerId};
 };
 const apply=(id)=>{
  const a=m.menu().find(x=>x.actionId===id);assert(a,id);
  const before=lite(),cardId=a.target?.cardInstanceId;
  const player=m.player(),card=cardId&&[...player.hand,...player.reservedCards,...m.state().cards.publicCards.filter(Boolean)].find(c=>c.id===cardId);
  m.apply(a);rows.push({input:rows.length+1,id,family:a.family,summary:a.summary,target:a.target,card:card?.cardId||null,before,after:lite()});
 };
 try{
  const start=lite();
  for(const edge of witness.path){
   for(const id of edge.steps)apply(id);
   if(edge.tail){
    assert.equal(edge.tail.kind,'blue-end-turn');assert.equal(edge.tail.dataPlans.length,1);
    assert.equal(edge.tail.dataPlans[0].goal.id,'data:blue:3');assert.equal(edge.tail.requiredNativeInputs,3);
    const slot=m.menu().find(a=>a.family==='choose_target'&&a.target?.blueSlot===3);
    assert(slot);apply(slot.actionId);
    const end=m.menu().find(a=>a.family==='end_turn');assert(end);apply(end.actionId);
   }
  }
  const end=lite(),save=m.save();
  assert.equal(end.turn,start.turn+1);assert.notEqual(end.actor,seat);assert.equal(save.session,null);
  m.restore(root);
  for(const r of rows){const a=m.menu().find(x=>x.actionId===r.id);assert(a);m.apply(a);}
  assert.deepEqual(m.save(),save);
  result.push({id:witness.id,searchValue:witness.rootValue,inputs:rows.length,start,end,rows,terminalCheckpoint:save,
   endpointSha:crypto.createHash('sha256').update(save.committedState).digest('hex'),nativeReplayExact:true});
 }finally{m.dispose();}
}
fs.writeFileSync(process.argv[2],JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(result.map(({id,searchValue,inputs,end,rows})=>({id,searchValue,inputs,score:end.score,established:end.established,wallet:end.wallet,
 hand:end.hand,blue:end.blue,computer:end.computer,probe:end.probes.map(p=>[p.id,p.planetId,p.surface]),traces:end.traces,paid:rows.filter(r=>['industry','card_corner','choose_payment','quick_trade','choose_card','land'].includes(r.family)).map(r=>[r.input,r.family,r.summary,r.card])}))));
