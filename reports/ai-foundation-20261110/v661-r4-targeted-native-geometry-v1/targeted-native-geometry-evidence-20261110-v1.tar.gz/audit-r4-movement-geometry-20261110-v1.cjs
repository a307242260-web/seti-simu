'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),crypto=require('node:crypto');
const [source,official,which,mode,out]=process.argv.slice(2),load=n=>require(path.resolve(n));
const original=Module._extensions['.js'];
const counters={calls:0,previousMisses:0,currentMisses:0,coordinates:0};
const audit=mode==='audit';
const legacyPath=process.argv[7];
const legacyCaches=new WeakMap();
globalThis.previousRouteCache=cache=>{
 if(!cache)return null;
 if(!legacyCaches.has(cache))legacyCaches.set(cache,new Map());
 return legacyCaches.get(cache);
};
globalThis.verifyRoute=(before,after)=>{
 assert.deepEqual(after.best,before.best);
 counters.calls++;counters.previousMisses+=Boolean(before.settled);counters.currentMisses+=Boolean(after.settled);
 counters.coordinates+=after.best.size;
};
if(audit)Module._extensions['.js']=(m,p)=>{
 if(!p.endsWith('/randomizer/game/ai/goal-movement.js'))return original(m,p);
 let code=fs.readFileSync(p,'utf8');
 const anchor='  function plan(';
 const prior=fs.readFileSync(legacyPath,'utf8').split('  function routes(')[1].split(anchor)[0];
 assert.equal(code.split(anchor).length,2);
 code=code.replace('  function routes(','  function currentRoutes(').replace(anchor,`  function previousRoutes(${prior}  function routes(state,owner,ship,cache){
   const before=previousRoutes(state,owner,ship,globalThis.previousRouteCache(cache));
   const after=currentRoutes(state,owner,ship,cache);
   globalThis.verifyRoute(before,after);
   return after;
 }
`+anchor);
 return m._compile(code,p);
};
const {open,seat}=require('./native-late-r3'),agent=load('randomizer/game/ai/search-agent'),
 {createAnalysisPort}=load('randomizer/game/ai/analysis-port');
const fixture=JSON.parse(z.gunzipSync(fs.readFileSync(source))),root=which==='official'?JSON.parse(fs.readFileSync(official)).checkpoint:
 fixture.rows.find(r=>r.summary.i===Number(which)).root;
const m=open(root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=agent.createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 const semantic={actionId:q.actionId,value:q.value,realization:q.realization,preparationDebt:q.preparationDebt,roots:q.roots,lines:q.lines,
  transitions:q.diagnostics.transitions,nativeExecutions:q.diagnostics.nativeExecutions};
 const canonical=x=>Array.isArray(x)?x.map(canonical):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).filter(k=>k!=='routingNodes').sort().map(k=>[k,canonical(x[k])])):x;
 const graph=crypto.createHash('sha256').update(JSON.stringify(canonical(semantic))).digest('hex');
 
 const r={which,mode,graph,counters,ms:q.rootAndSearchMilliseconds,native:q.diagnostics.nativeExecutions,logical:q.diagnostics.transitions,
  eval:q.diagnostics.valueEvaluations,nodes:q.lines.length,rootAndRngExact:true};
 fs.writeFileSync(out,JSON.stringify(r,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(r));
}finally{p.close();m.dispose();}
