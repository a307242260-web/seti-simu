'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict'),z=require('node:zlib'),crypto=require('node:crypto');
const [fixture,out]=process.argv.slice(2),{checkpoint:root}=JSON.parse(fs.readFileSync(fixture));
const original=Module._extensions['.js'];
const prof={},audits=new Map();
function timer(k,ms){const a=prof[k]||={calls:0,ms:0};a.calls++;a.ms+=ms;}
globalThis.profileJoin=timer;
Module._extensions['.js']=(m,p)=>{
 let code;
 if(p.endsWith('/randomizer/game/ai/analysis-port.js')){
  code=fs.readFileSync(p,'utf8');
  const names=['resourceSpec','proveDeferredFinalDataClaim','stableFinalClaimPolicy','sameFinalClaimEnd','turnTailSummary','finishChild','expand','quietTailHasNoAcquisition','goalMovementSpec','cardPickSpec'];
  for(const name of names){
   const marker='    function '+name+'(';
   const line=code.split('\n').find(l=>l.startsWith(marker));
   assert(line?.endsWith('{'),name);
   code=code.replace(line,line.replace(marker,'    function original'+name+'('));
   code=code.replace(line.replace(marker,'    function original'+name+'('),`    function ${name}(...args){const at=performance.now();try{return original${name}(...args);}finally{globalThis.profileJoin("${name}",performance.now()-at);}}\n`+line.replace(marker,'    function original'+name+'('));
  }
  const anchor='    return Object.freeze({ openRoot, expand, identity,';
  assert.equal(code.split(anchor).length,2);
  code=code.replace(anchor,anchor+' auditNode:node=>nodes.get(node),');
 }else if(p.endsWith('/randomizer/game/ai/decision-search.js')){
  code=fs.readFileSync(p,'utf8');
  const anchor='    const lines = nodes.map((entry, index) => ({';
  assert.equal(code.split(anchor).length,2);
  code=code.replace(anchor,'    globalThis.captureJoinedPaths(nodes,port,resourceExecutions);\n'+anchor);
 }else return original(m,p);
 return m._compile(code,p);
};
const load=n=>require(path.resolve(n)),{open,seat}=require('./native-late-r3'),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),
 {createSearchAgent}=load('randomizer/game/ai/search-agent');
const canonical=x=>Array.isArray(x)?x.map(canonical):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,canonical(x[k])])):x;
const key=x=>crypto.createHash('sha256').update(JSON.stringify(canonical(x))).digest('hex');
const pick=(s,k)=>Object.fromEntries(k.map(v=>[v,s[v]]));
const score=p=>pick(p.resources,['score','credits','energy','availableData','publicity','handSize']);
const counts=(xs,make)=>Object.fromEntries([...xs.reduce((m,x)=>{const k=make(x);m.set(k,(m.get(k)||0)+1);return m;},new Map())].sort((a,b)=>b[1]-a[1]));
globalThis.captureJoinedPaths=(nodes,port,resourceExecutions)=>{
 const roots=['industry:e887dc52','card_corner:bf0cc13d'];
 const reach=roots.map(id=>{
  const a=nodes[0].edges.filter(e=>e.actionId===id),walk=new Set();
  const add=i=>{if(walk.has(i))return;walk.add(i);for(const e of nodes[i].edges)add(e.target);};
  a.forEach(e=>add(e.target));return walk;
 });
 const relevant=new Set([...reach[0],...reach[1]]);
 for(const i of relevant){
  const n=nodes[i],stored=port.auditNode(n.node);
  const envelope=stored.envelope||port.auditNode(stored.turnTailBase||stored.incomeProofBase)?.envelope;
  if(!envelope)continue;
  const session=envelope.session?.session, s=session?.workingState||JSON.parse(envelope.committedState);
  const p=s.players.players.find(p=>p.id===seat),profile=pick(s,['solarSystem','pieces','data','planets','tech','aliens','finalScoring']);
  const e=session?.queue[0];
  const pureBoard=key(profile);
  const task=(e?.payload?.cardInstanceId||null);
  const blue=(p.dataState.placedTokens||[]).filter(t=>t.placementKind==='blueBonus').map(t=>t.blueSlot);
  const placed=(p.dataState.placedTokens||[]).filter(t=>t.placementKind!=='blueBonus').map(t=>t.placementSlot);
  const stage=key({board:pureBoard,blue,placed,score:p.resources.score,main:p.mainActionCompleted,status:n.node.status,
   menu:n.node.legalActions.map(a=>a.actionId),effect:e?.type??null,task});
  audits.set(i,{i,reach:reach.map(a=>a.has(i)),n:n.node.status,phase:e?.type??null,value:n.value,realization:n.realization,
   pureBoard,stage,blue,placed,score:score(p),hand:p.hand.map(c=>c.cardId),market:s.cards.publicCards.map(c=>c?.cardId),
   ready:n.node.legalActions.filter(a=>a.family==='complete_task').map(a=>a.target.ruleId),control:stored.resourceControl?.goal?.kind,
   boundary:n.node.boundary,tech:p.techState.ownedTiles,
   edges:n.edges.map(a=>({to:a.target,a:a.actionId,g:a.resourcePlan?.goal.id,t:a.turnTailPlanValue?.kind,proof:a.proof})),
   envelope});
 }
 const joined=[...relevant].filter(i=>reach[0].has(i)&&reach[1].has(i));
 const rows=[...audits.values()],common=(prop)=>{
  const a=new Set(rows.filter(r=>r.reach[0]).map(r=>r[prop]));
  const b=new Set(rows.filter(r=>r.reach[1]).map(r=>r[prop]));
  return {first:a.size,second:b.size,intersection:[...a].filter(k=>b.has(k)).length};
 };
 globalThis.joinSummary={routes:roots.map((id,k)=>({id,nodes:reach[k].size,exclusive:[...reach[k]].filter(i=>!joined.includes(i)).length,
   byKind:counts(rows.filter(r=>r.reach[k]),r=>[r.n,r.phase||'-',r.ready.join('/')||'-'].join('|'))})),
   shared:joined.length,exactShared:joined.map(i=>{const a=audits.get(i);return [i,a?.n,a?.score?.score,a?.ready];}),
   sameBoard:common('pureBoard'),sameBoardSameMenu:common('stage')};
};
const m=open(root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 const result={...globalThis.joinSummary,profile:prof,native:q.diagnostics.nativeExecutions,logical:q.diagnostics.transitions,rows:[...audits.values()]};
 fs.writeFileSync(out,z.gzipSync(JSON.stringify(result)+'\n'),{flag:'wx'});
 console.log(JSON.stringify({...result,rows:undefined,exactShared:result.exactShared.slice(0,8)}));
}finally{p.close();m.dispose();}
