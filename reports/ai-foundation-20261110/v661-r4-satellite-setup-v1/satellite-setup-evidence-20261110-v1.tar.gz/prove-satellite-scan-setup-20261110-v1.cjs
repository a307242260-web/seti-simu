'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),Module=require('node:module'),assert=require('node:assert/strict');
const [fixture,out]=process.argv.slice(2),file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
const needle='if(["other-owner","information-barrier","terminal","turn-boundary"].includes(current.status))return finish({goalStatus:"boundary"});';
const source=fs.readFileSync(file,'utf8').replace('      loadedEnvelope = rootEnvelope;',
 '      globalThis.capturePreparedRoot(rootEnvelope,publicSeed);\n      loadedEnvelope = rootEnvelope;');
assert.equal(source.split(needle).length,2);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));Module._cache[file]=mod;
mod._compile(source.replace(needle,`if(["other-owner","information-barrier","terminal","turn-boundary"].includes(current.status)){
 if(plan.goal.kind==="satellite-scan-setup")globalThis.captureSatellite(nodes.get(current).envelope);
 return finish({goalStatus:"boundary"});
}`),file);mod.loaded=true;
const {open,seat}=require('./native-late-r3');
const {createStateValueEvaluator,evaluateStateValue}=require(path.resolve('randomizer/game/ai/state-value'));
const {root,actions,end}=JSON.parse(z.gunzipSync(fs.readFileSync(fixture))),m=open(root),p=mod.exports.createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 let captured,prepared,branchKey;
 globalThis.capturePreparedRoot=(envelope,key)=>{prepared=envelope;branchKey=key;};
 globalThis.captureSatellite=envelope=>captured=envelope;
 const n=p.openRoot();p.setMovementPlanning(true);p.setCardPickPlanning(true);p.setResourcePlanning(true);p.setDecisionPlanning({finalMarkPlanning:true,scanPlanning:true});
 const plan=p.resourceSpec(n).plans.find(x=>x.goal.kind==='satellite-scan-setup');
 const macro=p.expandResourcePlan(n,plan,()=>null);
 assert.equal(macro.goalStatus,'boundary');
 assert.deepEqual(macro.prefixes.map(x=>x.action.actionId),actions.map(x=>x.actionId));
 assert.deepEqual(m.save(),root);
 assert(captured);assert.equal(captured.session,null);assert.equal(end.session,null);
 const branch=m.c.counterfactualPort.createFork(prepared,{branchKey,restoreRandomState:true});
 const c=branch.composition||branch;
 try{
  for(const x of actions){
   const d=c.inspect().session?.decision;
   const a=(d?.choices||c.inputPort.enumerateActions({})).find(q=>q.actionId===x.actionId);
   assert(a);
   const r=d?c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
    :a.phase==='quick'?c.inputPort.submitQuickAction(a):c.inputPort.submitAction(a);
   assert(r.ok,JSON.stringify(r).slice(0,500));
  }
  const expected=c.lifecycle.save({trustedFork:true}).envelope;
  assert.equal(expected.session,null);
  const actualState=JSON.parse(captured.committedState),nativeState=JSON.parse(expected.committedState);
  assert(require('node:util').isDeepStrictEqual(actualState,nativeState),Object.keys(nativeState).filter(k=>!require('node:util').isDeepStrictEqual(actualState[k],nativeState[k])).join(','));
 }finally{c.dispose();}
 const value=evaluateStateValue(p.valueObservation(macro.node),seat),base=createStateValueEvaluator(seat);
 for(const x of actions)m.apply(x);
 assert.deepEqual(m.save(),end);
 const facts=m.facts();
 assert.equal(facts.turn,8);assert.equal(facts.wallet.availableData,3);assert(facts.hand.some(([id])=>id===plan.goal.cardId));
 m.restore(root);assert.deepEqual(m.save(),root);
 const data={goal:plan.goal,inputs:macro.prefixes.map(x=>x.action.summary),count:macro.prefixes.length,
  nativeExecutions:p.getDiagnostics().submissionCount,knownValue:value.total,probePotential:value.components.probePotential,
  rootValue:base(n.observation),status:macro.node.status,boundary:macro.node.boundary,endpoint:facts,exactHypothesisStateRngAndRoot:true};
 fs.writeFileSync(out,JSON.stringify(data,null,2)+'\n');console.log(JSON.stringify([data.count,data.nativeExecutions,data.knownValue,data.probePotential,data.exactHypothesisStateRngAndRoot]));
}finally{p.close();m.dispose();}
