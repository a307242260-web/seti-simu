'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,short,readZ,writeZ}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const [src,out]=process.argv.slice(2),r=readZ(src),rows={};
for(const k of ['110','114']){
 const root=r[k].root,m=open(root);
 try{
  const port=createAnalysisPort({composition:m.c,seatId:'player-white'}),node=port.openRoot();
  port.setResourcePlanning(true);
  const spec=port.resourceSpec(node),plan=spec?.plans.find(x=>x.goal.kind==='data-funded-cargo');
  port.close();
  const q=m.automatic();
  rows[k]={root,plan,q:{...q,checkpoint:undefined}};
  console.log(k,q.complete,q.n,q.ms,q.a?.summary,q.value,'plan',plan?.goal.kind,q.roots.filter(x=>x.value!=null).map(x=>[m.menu().find(a=>a.actionId===x.actionId)?.summary,x.value]));
 }finally{m.dispose();}
}
writeZ(out,rows);
