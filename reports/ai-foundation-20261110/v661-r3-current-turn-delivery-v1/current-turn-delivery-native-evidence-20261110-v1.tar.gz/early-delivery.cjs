'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ,runCases}=require('./controlled-r3');
const {pathToEarth}=require('./shortest-return-20261110-v1.cjs');
const [src,out]=process.argv.slice(2),data=readZ(src),rows={};
const a=(h,f,p)=>h.act(f,p),ch=(h,f,id)=>a(h,f,q=>q.target.choiceId===id);
const put=(h,slot)=>{a(h,'place_data');ch(h,'choose_target',slot?'data:blueBonus:'+slot:'data:computer');};
const find=(h,id)=>h.m.player().hand.find(c=>c.cardId===id)?.id;
const income=(h,id)=>a(h,'choose_card',q=>q.target.cardInstanceId===find(h,id));
const corner=(h,id)=>h.take(h.m.corner(id));
function energyTrade(h){
 a(h,'quick_trade',q=>q.target.tradeId==='cards-for-energy');
 for(const id of ['chong_8.webp','amiba_9.webp'])a(h,'choose_payment',q=>q.target.cardInstanceId===find(h,id));
 if(h.m.c.inspect().session?.decision)a(h,'choose_payment',q=>q.target.kind!=='discard-hand-card');
}
function deliver(h){
 const d=pathToEarth(h.m,'fossil_07');
 assert.equal(d.cost,3);assert.equal(d.path.length,3);
 const job=Object.values(h.m.state().aliens.chong.transportTasksByRocketId).find(x=>x.fossilId==='fossil_07');
 for(let i=0;i<3;i++){
  const step=d.path[i],supplier=['chong_7.webp','chong_9.webp',null][i],pay=supplier&&find(h,supplier);
  assert(!supplier||pay);
  a(h,'move',q=>q.target.rocketId===d.rocketId&&q.target.deltaX===step.deltaX&&q.target.deltaY===step.deltaY);
  a(h,'choose_payment',q=>q.target.kind==='move-payment'&&(supplier?q.target.cardIds?.length===1&&q.target.cardIds[0]===pay:!q.target.cardIds.length));
 }
 h.cut('at-earth');
 a(h,'complete_task',q=>q.target.cardInstanceId===job.cardId);
 assert(h.m.state().aliens.chong.fossilsById.fossil_07.taskCompleted);
 h.cut('claimed');
}
function bluePrep(h){put(h);put(h,1);h.cut('funded');deliver(h);}
function fillIncome(h,card){bluePrep(h);for(let i=0;i<3;i++)put(h);income(h,card);h.cut('income');}
const list=[
 ['110',data['analyze-keep-pool'].checkpoint,[
  ['data-funded-delivery',bluePrep],
  ['delivery-and-insert-chong8',h=>fillIncome(h,'chong_8.webp')],
  ['delivery-and-insert-amiba9',h=>fillIncome(h,'amiba_9.webp')],
  ['delivery-keep-data',h=>{bluePrep(h);put(h);put(h);h.cut('keep-data');}],
  ['delivery-keep-blue-and-income',h=>{
   bluePrep(h);put(h);put(h);put(h,2);
   h.take(h.m.pick('dlc_15.png'));corner(h,'dlc_15.png');put(h);income(h,'chong_8.webp');h.cut('income');
  }],
  ['delay-delivery-use-same-energy-blue',h=>{put(h);put(h,1);h.cut('funded');}]
 ]],
 ['114',data['analyze-fill-3'].checkpoint,[
  ['four-card-delivery',h=>{energyTrade(h);deliver(h);}]
 ]]
];
for(const [id,root,cases] of list){
 const m=open(root);
 try{
  const q=m.automatic();console.log('cold',id,q.complete,q.n,q.ms,q.a?.summary,q.value);
  assert(q.complete&&q.n<=256&&q.ms<=600);
 }finally{m.dispose();}
 rows[id]={root,...runCases(root,cases)};
}
writeZ(out,rows);
