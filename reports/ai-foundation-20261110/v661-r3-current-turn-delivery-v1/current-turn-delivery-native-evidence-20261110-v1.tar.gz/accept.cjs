'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,runCases,short}=require('./controlled-r3');
const [infile,out]=process.argv.slice(2),d=readZ(infile),root=d[110].root;
const r=runCases(root,[['autonomous',()=>{}]]);
for(const a of r.rows)console.log('main-ledger',a.actions.filter(x=>x.action.phase==='main'||x.action.family==='complete_task'
  ||x.action.family==='card_corner').map(x=>[x.action.summary,x.n,x.value]),'prefix',a.actions.slice(0,20).map(x=>x.action.summary));
writeZ(out,{root,...r});
