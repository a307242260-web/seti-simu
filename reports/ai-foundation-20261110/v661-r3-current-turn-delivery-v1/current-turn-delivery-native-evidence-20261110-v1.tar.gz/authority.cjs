'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,short}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const hash=x=>require('node:crypto').createHash('sha256').update(JSON.stringify(x)).digest('hex');
const [file,out]=process.argv.slice(2),root=readZ(file)[110].root,rows=[];
const copy=JSON.parse(root.committedState),first=copy.cards.drawPileCardIds[0];
const captures=[];
for(const k of [0,1,3,5]){
 const s=JSON.parse(root.committedState),d=s.cards.drawPileCardIds,changed=d[k];
 [d[0],d[k]]=[d[k],d[0]];
 const e={...root,committedState:createStateStore(s).serialize().serialized};
 const m=open(e),actions=[],continuations=[];
 try{
  const observation=m.owner('player-white'),menu=m.menu(),q=m.automatic(),main=q.a;
  assert(q.complete&&q.n<=256&&q.ms<=600);
  const key={observation,menu,value:q.value,a:q.a,roots:q.roots,n:q.n};
  if(captures.length)assert.deepEqual(key,captures[0]);else captures.push(key);
  const p=createAnalysisPort({composition:m.c,seatId:'player-white'});
  p.setResourcePlanning(true);const node=p.openRoot(),plan=p.resourceSpec(node)?.plans.find(x=>x.goal.kind==='data-funded-cargo');
  assert(plan);
  const fixed=p.expandResourcePlan(node,plan,(used,context,input)=>input&&used>=18?'test-limit':false);
  assert(fixed.complete&&fixed.goalStatus==='completed');assert.equal(fixed.prefixes.length,18);
  const expected=fixed.prefixes.map(x=>x.action);p.close();
  assert.equal(main.actionId,expected[0].actionId);
  let cp=q.checkpoint;
  for(const [i,a] of expected.entries()){
   const checkpoint=m.save();
   if(i){
    const saved=JSON.parse(JSON.stringify(cp));m.restore(checkpoint);
    const restored=m.automatic(saved);assert.equal(restored.a.actionId,a.actionId);
    assert(restored.complete&&restored.n===0);cp=restored.checkpoint;
    continuations.push({n:restored.n,action:restored.a,checkpointSha256:hash(checkpoint),planSha256:hash(saved),...(k===0&&[1,3,10,17].includes(i)?{checkpoint,saved}:{})});
   }
   actions.push(m.apply(a));
  }
  const end=m.save(),state=short(m);
  m.restore(e);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  assert.equal(state.wallet[0],116);assert.equal(state.income[1],4);assert.equal(state.computer.length,4);
  rows.push({k,changed,first,e,key,plan,actions,continuations,end,state});
  console.log(JSON.stringify([changed,q.n,q.ms,state.wallet,state.income,continuations.length]));
 }finally{m.dispose();}
}
writeZ(out,{rows});
