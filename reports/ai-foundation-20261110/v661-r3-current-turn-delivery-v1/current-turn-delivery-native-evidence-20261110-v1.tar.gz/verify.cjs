'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ}=require('./controlled-r3');
const d=process.argv[2]||__dirname,file=n=>readZ(path.join(d,n+'-20261110-v1.json.gz'));
let inputs=0;
function replay(root,actions,end){
 const m=open(root);
 try{actions.forEach(x=>m.apply(x.action||x));assert.deepEqual(m.save(),end);inputs+=actions.length;}
 finally{m.dispose();}
}
for(const x of Object.values(file('r3-early-delivery')))for(const r of x.rows)replay(x.root,[...r.prefix,...r.actions],r.end);
for(const n of ['r3-delivery-base-autonomous','r3-delivery-final-autonomous']){
 const v=file(n),r=v.rows[0];replay(v.root,r.actions,r.end);
 assert(r.actions.every(x=>x.n===undefined||x.n<=256&&x.ms<=600));
 assert.equal(r.stop,'r4-first-white-main');
 assert.equal(r.settled.summary.wallet[0],n.includes('base')?119:125);
}
const a=file('r3-cargo-authority').rows;
for(const x of a){
 assert.deepEqual(x.key,a[0].key);
 replay(x.e,x.actions,x.end);assert.equal(x.continuations.length,17);
 assert(x.continuations.every(c=>c.n===0));assert.equal(x.state.wallet[0],116);
}
const clean=x=>Object.fromEntries(Object.entries(x).map(([k,{ms,...q}])=>[k,q]));
const base=file('r3-cargo-parity-base'),next=file('r3-cargo-parity-candidate');
assert.deepEqual(clean(base),clean(next));
assert(Object.values(next).every(q=>q.complete&&q.n<=256&&q.ms<=600));
console.log(JSON.stringify({inputs,standardRoots:Object.keys(next).length,recoveredPrefixes:a.length*17}));
