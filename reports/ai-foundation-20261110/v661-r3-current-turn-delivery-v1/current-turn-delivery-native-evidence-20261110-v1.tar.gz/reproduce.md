# Reproduction

From the SETI source root, use `node "<unpacked>/verify.cjs"` to replay the stored inputs through Production. This is an independent rule replay, not a whole-game experiment. See the base commit ff4b62411 for policy comparisons.

For new output files, early-delivery.cjs takes the archived r3-keep-cards-with-analysis from v661-r3-split-orange3-v1 and a fresh output. The resulting r3-early-delivery gzip supplies gate.cjs, accept.cjs and authority.cjs, each with a fresh output path. Run gate and accept first on the base and then on the new policy. authority uses the new policy. parity.cjs takes the formal first3 independent replay JSON, its replay save JSON, formal-r3-roots from the formal retention archive, r189-formal-roots from the reordered income archive, and a fresh output. Timing may vary. The verification script consumes the published files and compares exact rules envelopes independently.
