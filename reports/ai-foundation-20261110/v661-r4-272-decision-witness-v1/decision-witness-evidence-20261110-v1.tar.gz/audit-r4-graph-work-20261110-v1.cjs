'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const [fixture,out]=process.argv.slice(2),file=path.resolve('randomizer/game/ai/decision-search.js');
const mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));Module._cache[file]=mod;
let src=fs.readFileSync(file,'utf8');
const a='    return {\n      schemaVersion: VERSION,',b='      valueEvaluations++;';
assert.equal(src.split(a).length,2);assert.equal(src.split(b).length,2);
src=src.replace(a,'    globalThis.recordGraph(nodes,resourceExecutions,resourceStateAdditions);\n'+a)
 .replace(b,b+'\n      globalThis.recordValue(observation,evaluate.seatId);');
mod._compile(src,file);mod.loaded=true;
const {open,seat}=require('./native-late-r3'),{factsFromObservation}=require(path.resolve('randomizer/game/ai/probe-capital'));
const root=JSON.parse(z.gunzipSync(fs.readFileSync(fixture))).rows[0].root,m=open(root),values=[];
let graph;
globalThis.recordValue=(o,id)=>{
 const f=factsFromObservation(o,id),p=f.player,board=f.board;
 values.push({round:f.round,passing:f.passing,terminal:f.terminal,base:p.score,score:p.finalScore,
  wallet:[p.credits,p.energy,p.availableData,p.publicity],hand:f.hand,tech:p.techState,income:p.income,
  player:p,board,nextFinalMark:f.nextFinalMark,facts:f});
};
globalThis.recordGraph=(nodes,executions)=>{
 graph=nodes.map((e,i)=>({i,status:e.node.status,value:e.value,legal:e.node.legalActions.map(a=>[a.actionId,a.summary]),
  edges:e.edges.map(x=>{
   const m=executions.get(x),g=x.resourcePlan?.goal;
   return {a:x.actionId,t:x.target,k:g?.kind,id:g?.id,n:x.cost,equivalent:!!x.equivalent,
    prefix:m?.prefixes.map(({node,action})=>[node.status,action.actionId,action.family,action.summary])};
  })}));
};
try{
 const q=m.automatic();
 assert(q.complete&&q.value===216.5);assert.deepEqual(m.save(),root);
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({graph,values,q:{value:q.value,roots:q.roots.map(x=>[x.actionId,x.value,x.realization,x.preparationDebt])}})+'\n'),{flag:'wx'});
 console.log(JSON.stringify({graph:graph.length,values:values.length}));
}finally{m.dispose();}
