'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const [fixture,out]=process.argv.slice(2),file=path.resolve('randomizer/game/ai/decision-search.js');
const mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));Module._cache[file]=mod;
let src=fs.readFileSync(file,'utf8');
const a='    return {\n      schemaVersion: VERSION,',b='      valueEvaluations++;';
assert.equal(src.split(a).length,2);assert.equal(src.split(b).length,2);
src=src.replace(a,'    globalThis.recordGraph(nodes,resourceExecutions,port.proofEnvelope);\n'+a)
 .replace(b,b+'\n      globalThis.recordValue(observation,evaluate.seatId);');
mod._compile(src,file);mod.loaded=true;
const af=path.resolve('randomizer/game/ai/analysis-port.js'),am=new Module(af,module);
am.filename=af;am.paths=Module._nodeModulePaths(path.dirname(af));Module._cache[af]=am;
const at='    return Object.freeze({ openRoot, expand, identity, hasMovementIntent',as=fs.readFileSync(af,'utf8');
assert.equal(as.split(at).length,2);
am._compile(as.replace(at,'    return Object.freeze({ proofEnvelope:node=>nodes.get(node)?.envelope, openRoot, expand, identity, hasMovementIntent'),af);
am.loaded=true;
const {open,seat}=require('./native-late-r3'),{factsFromObservation}=require(path.resolve('randomizer/game/ai/probe-capital'));
const root=JSON.parse(z.gunzipSync(fs.readFileSync(fixture))).rows[0].root,m=open(root),values=[];
let graph;
globalThis.recordValue=(o,id)=>{
 const f=factsFromObservation(o,id),p=f.player,board=f.board;
 values.push({round:f.round,passing:f.passing,terminal:f.terminal,base:p.score,score:p.finalScore,
  wallet:[p.credits,p.energy,p.availableData,p.publicity],hand:f.hand,tech:p.techState,income:p.income,
  player:p,board,nextFinalMark:f.nextFinalMark,facts:f});
};
globalThis.recordGraph=(nodes,executions,env)=>{
 graph=[];
 for(const [i,e] of nodes.entries())for(const x of e.edges){
  if(x.resourcePlan?.goal.id!=='data:blue:2')continue;
  const m=executions.get(x),b=nodes[x.target],g=x.resourcePlan.goal;
  if(!m||b.node.status!=='stable'||b.edges.length!==1||b.node.legalActions.find(a=>a.actionId===b.edges[0].actionId)?.family!=='end_turn')continue;
  const y=b.edges[0],z=nodes[y.target];
  graph.push({i,after:x.target,end:y.target,score:z.value,goal:g,root:env(e.node),middle:env(b.node),endState:env(z.node),
    prefix:m.prefixes.map(p=>p.action),endAction:b.node.legalActions.find(a=>a.actionId===y.actionId),
    endProof:y.turnTailPlanValue||null,endCost:y.cost,afterLegal:b.node.legalActions,endStatus:z.node.status});
 }
};
try{
 const q=m.automatic();
 assert(q.complete&&q.value===216.5);assert.deepEqual(m.save(),root);
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({graph,q:{value:q.value,roots:q.roots.map(x=>[x.actionId,x.value,x.realization,x.preparationDebt])}})+'\n'),{flag:'wx'});
 console.log(JSON.stringify({graph:graph.length,values:values.length}));
}finally{m.dispose();}
