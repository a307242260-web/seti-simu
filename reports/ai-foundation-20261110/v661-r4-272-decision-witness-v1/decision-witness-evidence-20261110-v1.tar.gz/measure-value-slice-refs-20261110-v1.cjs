'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const [, , mode,fixture,out]=process.argv;
const file=path.resolve('randomizer/app/rule-observation.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));Module._cache[file]=mod;
const source=fs.readFileSync(file,'utf8'),at='  const copyValueSlice=valueOnly?stateStore.copyForkData:clone;';
assert.equal(source.split(at).length,2);
mod._compile(source.replace(at,at+'\n  if(valueOnly)globalThis.measureSlices(state);'),file);mod.loaded=true;
const maps=new Map();
globalThis.measureSlices=s=>{
 for(const [key,slice] of Object.entries({rockets:s.pieces.rockets,planets:s.planets,data:s.data,solarSystem:s.solarSystem,finalScoring:s.finalScoring})){
  if(!maps.has(key))maps.set(key,{refs:new Set(),frozenRefs:new Set(),calls:0,frozenCalls:0});
  const d=maps.get(key);d.calls++;d.refs.add(slice);
  if(Object.isFrozen(slice)){d.frozenCalls++;d.frozenRefs.add(slice);}
 }
};
process.argv=[process.argv[0],'benchmark',mode,fixture,out];
require('./profile-r4-single-20261110-v1.cjs');
console.log(JSON.stringify(Object.fromEntries([...maps].map(([k,v])=>[k,{calls:v.calls,frozenCalls:v.frozenCalls,refs:v.refs.size,frozenRefs:v.frozenRefs.size}]))));
