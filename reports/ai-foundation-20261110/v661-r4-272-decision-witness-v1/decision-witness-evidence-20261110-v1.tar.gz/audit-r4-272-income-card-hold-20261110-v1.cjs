'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const {createStateValueEvaluator}=require(path.resolve('randomizer/game/ai/state-value'));
const [fixture,audit,out]=process.argv.slice(2),read=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const root=read(fixture).rows[0].root,{witnesses}=read(audit),source=witnesses.find(w=>w.label==='ai-selected');
const gain=c=>require(path.resolve('randomizer/game/cards/deck')).getIncomeGainForCard(c);
const a=open(root),evaluate=createStateValueEvaluator(seat);
const run=swap=>{
 a.restore(root);
 const actions=[];
 let income;
 for(const action of source.steps){
  if(action.family==='choose_card'&&action.summary==='收入 chong_6.webp'){
   const offered=a.menu().filter(c=>c.family==='choose_card'),old=offered.find(c=>c.summary==='收入 chong_6.webp'),other=offered.find(c=>c.summary==='收入 b_111.webp');
   assert(old&&other);const card=id=>a.player().hand.find(c=>c.cardId===id);
   const oldGain=gain(card('chong_6.webp')),otherGain=gain(card('b_111.webp'));
   assert.deepEqual(oldGain,otherGain);assert.deepEqual(oldGain,{energy:1});
   const actual=swap?other:old;
   actions.push(a.apply(actual));
   income={before:old.stateVersion,menu:offered.map(a=>a.summary),gain:oldGain,used:actual.summary,after:a.facts(),checkpoint:a.save()};
  }else{
   actions.push(a.apply(action));
  }
 }
 assert(income&&a.facts().turn===8);
 const facts=a.facts(),legal=a.menu();
 return {actions,income,facts,value:evaluate(a.owner(seat)),landingCardAction:legal.find(a=>a.family==='play_card'&&a.summary==='chong_6.webp')||null,
  end:a.save()};
};
try{
 const chosen=run(false),preserve=run(true),f=x=>x.facts;
 for(const key of ['wallet','income','tech','computer','blue','probes','traces','rng','wins'])assert.deepEqual(f(chosen)[key],f(preserve)[key],key);
 assert(f(preserve).hand.some(c=>c[1]==='chong_6.webp'));assert(!f(chosen).hand.some(c=>c[1]==='chong_6.webp'));
 a.restore(preserve.end);
 const extra=[];
 if(preserve.landingCardAction){
  extra.push(a.apply(preserve.landingCardAction));let menu=a.menu();
  for(let i=0;i<8&&menu.every(x=>x.phase==='conditional');i++){
   assert(!menu.some(x=>x.target?.target==='land'||x.target?.target==='orbit'||/^(登陆|环绕)/.test(x.summary)));
   if(menu.length!==1)break;
   extra.push(a.apply(menu[0]));menu=a.menu();
  }
 }
 preserve.cardOnlyReplay={actions:extra,end:a.save(),next:a.menu().map(x=>[x.family,x.summary,x.target]),facts:a.facts()};
 const result={chosen,preserve,sameResultExceptIncomeCardIdentity:true,seededNativeReplays:2};
 fs.writeFileSync(out,z.gzipSync(JSON.stringify(result)+'\n'),{flag:'wx'});
 console.log(JSON.stringify({score:f(chosen).wallet.score,value:[chosen.value,preserve.value],income:chosen.income.gain,
  kept:[f(chosen).hand,f(preserve).hand],landingCardPlayableNext:Boolean(preserve.landingCardAction),cardOnlyResult:[extra.map(x=>x.summary),a.facts().wallet.score]}));
}finally{a.dispose();}
