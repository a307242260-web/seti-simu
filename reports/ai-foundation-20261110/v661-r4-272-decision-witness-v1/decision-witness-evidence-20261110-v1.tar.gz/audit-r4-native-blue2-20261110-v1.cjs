'use strict';
const fs=require('node:fs'),z=require('node:zlib'),assert=require('node:assert/strict'),path=require('node:path');
const {open,seat}=require('./native-late-r3');
const {previewFinalOwnQuietEnd}=require(path.resolve('randomizer/game/ai/local-decision-plans'));
const [fixture,out]=process.argv.slice(2);
const {graph}=JSON.parse(z.gunzipSync(fs.readFileSync(fixture)));
const model=open(graph[0].root),verified=[];
try{
 for(const item of graph){
  assert(model.c.lifecycle.restore(item.root).ok);
  const initial=JSON.parse(item.root.committedState);
  assert.deepEqual(model.state(),initial);
  assert.equal(model.save().session,null);
  for(const a of item.prefix)model.apply(a);
  const middle=model.state();
  assert.deepEqual(middle,JSON.parse(item.middle.committedState),`placement ${item.i}`);
  assert.equal(model.save().session,null);
  const p=middle.players.players.find(p=>p.id===seat);
  const knownCards=new Set(p.reservedCards.map(c=>c.id));
  const preview=previewFinalOwnQuietEnd({state:middle,seatId:seat,action:item.endAction,knownCards});
  model.apply(item.endAction);
  const expected=JSON.parse(item.endState.committedState),actual=model.state();
  assert.equal(model.save().session,null);
  const withoutVersion=s=>({...s,meta:{...s.meta,stateVersion:null}});
  assert.deepEqual(withoutVersion(actual),withoutVersion(expected),`end ${item.i}`);
  const versions=[middle.meta.stateVersion,actual.meta.stateVersion,expected.meta.stateVersion,preview?.meta.stateVersion];
  assert.deepEqual(actual.meta.rngState,initial.meta.rngState,`rng ${item.i}`);
  if(preview)assert.deepEqual(withoutVersion(preview),withoutVersion(expected),`preview ${item.i}`);
  const midPlayer=middle.players.players.find(p=>p.id===seat),afterPlayer=actual.players.players.find(p=>p.id===seat);
  verified.push({i:item.i,prefix:item.prefix.map(a=>a.family),status:item.endStatus,versions,proof:Boolean(preview),
   changes:Object.keys(actual).filter(k=>JSON.stringify(actual[k])!==JSON.stringify(middle[k])),
   playerChanges:Object.keys(afterPlayer).filter(k=>JSON.stringify(afterPlayer[k])!==JSON.stringify(midPlayer[k]))});
 }
}finally{model.dispose();}
const result={verified:verified.length,inputs:verified.reduce((n,r)=>n+r.prefix.length+1,0),
 provedQuietEnd:verified.filter(r=>r.proof).length,verifiedRows:verified};
fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log({...result,verifiedRows:undefined});
