'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
function instrument(name,anchor,replacement,extra){
 const file=path.resolve('randomizer/game/ai',name),mod=new Module(file,module);
 mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));Module._cache[file]=mod;
 const source=fs.readFileSync(file,'utf8');assert.equal(source.split(anchor).length,2);
 mod._compile((extra?source.replace(...extra):source).replace(anchor,replacement),file);mod.loaded=true;
}
const hook='    return {\n      schemaVersion: VERSION,';
instrument('decision-search.js',hook,'    globalThis.captureGraph(nodes,resourceExecutions,roots,port.proofEnvelope);\n'+hook);
instrument('analysis-port.js','  return Object.freeze({ createAnalysisPort });','  return Object.freeze({ createAnalysisPort, forwardIdentity });',
 ['    return Object.freeze({ openRoot, expand, identity, hasMovementIntent',
  '    return Object.freeze({ proofEnvelope:node=>nodes.get(node)?.envelope, openRoot, expand, identity, hasMovementIntent']);
const {forwardIdentity}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {open,seat}=require('./native-late-r3');
const values=require(path.resolve('randomizer/game/ai/state-value')),evaluate=values.createStateValueEvaluator(seat);
const read=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f))),[fixture,teacher,out]=process.argv.slice(2);
const root=read(fixture).rows[0].root,m=open(root);
const source=read(teacher).full;
const start=source.findIndex(a=>a.stateVersion===m.state().meta.stateVersion&&a.actorId===seat&&a.family==='place_data');
assert(start>=0);
let witnesses,forkRoot;
globalThis.captureGraph=(nodes,executions,roots,env)=>{
 forkRoot=env(nodes[0].node);
 const choose=(entry,edge)=>{
  const actions=(executions.get(edge)||entry.fixedCardExecutions?.get(edge.actionId)||entry.goalExecutions?.get(edge.actionId))?.prefixes.map(p=>p.action);
  return actions||entry.node.legalActions.filter(a=>a.actionId===edge.actionId);
 };
 const trace=(rootEdge,label)=>{
  const parts=[];let i=0,e=rootEdge;
  while(e&&parts.length<nodes.length){
   const n=nodes[i];parts.push({from:i,to:e.target,goal:e.resourcePlan?.goal.id,steps:choose(n,e),cost:e.cost,
    proof:e.proof||e.turnTailPlanValue?.proof,after:env(nodes[e.target].node)});
   i=e.target;e=nodes[i].best;
  }
  const n=nodes[i],status=n.node.status;
  return {label,parts,status,boundary:n.node.boundary,score:n.value,realization:n.realization,base:n.baseValue,preparedTransport:n.preparedTransport,
   displayTransportQuote:n.displayTransportQuote,preparedDebt:n.preparationDebt,envelope:env(n.node)};
 };
 const select=action=>nodes[0].edges.find(e=>e.actionId===action.actionId&&e.target===action.target);
 const scan=roots.find(a=>a.actionId.startsWith('scan:'));
 witnesses=[trace(nodes[0].best,'ai-selected'),trace(select(scan),'best-root-scan')];
};
try{
 const q=m.automatic();assert.equal(q.value,216.5);assert(q.complete&&witnesses.every(x=>x.parts.length));assert.deepEqual(m.save(),root);
 const before=m.facts(),teacherTurns=[];let previousTurn=before.turn,actions=[];
 for(const [i,a] of source.entries()){
  if(i<start)continue;
  assert(a.actorId===seat,'other seats already passed');
  const valid=m.menu().find(x=>x.actionId===a.actionId&&x.actorId===a.actorId);
  assert(valid,`unavailable teacher input ${i} ${a.summary}`);
  m.apply(a);actions.push(a);
  const now=m.facts();
  if(now.turn!==previousTurn){
   teacherTurns.push({from:previousTurn,actions,facts:now,value:evaluate(m.owner(seat)),envelope:m.save()});
   previousTurn=now.turn;actions=[];
   if(teacherTurns.length===3)break;
  }
 }
 assert.equal(teacherTurns.length,3);assert.equal(teacherTurns[0].actions[0].family,'place_data');
 const witnessResults=[];
 for(const w of witnesses){
  assert(w.envelope);const model=open(root);assert(model.c.lifecycle.restore(forkRoot).ok);assert.deepEqual(model.state(),JSON.parse(forkRoot.committedState));let replayMatches=true;
  const steps=w.parts.flatMap(p=>p.steps);
  try{
   for(const part of w.parts){
    if(part.cost!==part.steps.length){replayMatches=false;break;}
    for(const a of part.steps)model.apply(a);
   }
   if(replayMatches){
    const key=e=>forwardIdentity(e,w.status,w.boundary);
    assert(key(model.save())===key(w.envelope),w.label+' native replay must match forward identity');
    replayMatches=JSON.stringify(model.save())===JSON.stringify(w.envelope)?'exact-envelope':'exact-forward-identity';
   }
   witnessResults.push({...w,replayMatches,facts:model.facts(),unmaskedValue:evaluate(model.owner(seat)),steps});
  }finally{model.dispose();}
 }
 const result={before,teacherStart:start,teacherTurns,witnesses:witnessResults,roots:q.roots};
 fs.writeFileSync(out,z.gzipSync(JSON.stringify(result)+'\n'),{flag:'wx'});
 console.log(JSON.stringify({teacherStart:start,turns:teacherTurns.map(t=>[t.from,t.facts.wallet.score,t.value,t.actions.map(a=>a.summary)]),
 witnesses:witnessResults.map(x=>[x.label,x.status,x.score,x.realization,x.replayMatches,x.facts.wallet,x.steps.map(a=>a.summary)])}));
}finally{m.dispose();}
