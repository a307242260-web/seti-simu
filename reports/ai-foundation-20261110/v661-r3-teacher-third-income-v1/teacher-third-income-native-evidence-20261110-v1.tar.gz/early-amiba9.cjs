'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),r=readZ(src).rows[0],m=open(r.start);
let e,menu,base;
try{
 r.actions.slice(0,39).forEach(x=>m.apply(x.action));e=m.save();base=short(m);
 m.play('amiba_9.webp');menu=m.menu();
 console.log('before first analysis',base,menu.map(x=>[x.summary,x.target.choiceId]));
}finally{m.dispose();}
const acts=[
 ['amiba9-before-first-analysis',h=>h.take(h.m.play('amiba_9.webp'))],
 ...menu.map(x=>[x.summary,h=>{
  h.take(h.m.play('amiba_9.webp'));h.act('choose_target',a=>a.target.choiceId===x.target.choiceId);
  h.cut('symbol');
 }])
];
const result=runCases(e,acts);
writeZ(out,{e,menu,base,...result});
