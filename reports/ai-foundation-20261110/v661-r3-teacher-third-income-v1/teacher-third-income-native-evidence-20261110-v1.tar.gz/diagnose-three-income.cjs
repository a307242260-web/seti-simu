'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [src,hidden,out]=process.argv.slice(2),r=readZ(src),a=readZ(hidden),rows={};
function measure(label,e){
 const m=open(e);
 try{
  const s=short(m),menu=m.menu(),{checkpoint,...q}=m.automatic();assert(q.complete&&q.n<=256&&q.ms<=600);
  rows[label]={e,s,menu,q};
  console.log(label,q.n,q.ms,q.a.summary,q.roots.map(r=>[menu.find(a=>a.actionId===r.actionId)?.summary,r.value,r.completion]));
 }finally{m.dispose();}
}
measure('second-income-early-a9',r.roots[20]);
measure('third-analysis-trace',r.roots[33]);
const m=open(a.original.e);
try{
 a.original.executed.slice(0,-1).forEach(m.apply);
 measure('third-income-b14-route',m.save());
}finally{m.dispose();}
const e=r.rows[20].rows[1].checkpoints['scan-ready'].state,scan=open(e),returns=[];
try{
 const winCount=scan.state().data.sectorSettlements.winsByPlayerId['player-white'].length;
 const start=scan.act('scan'),scanOpen=scan.save();
 for(const a of scan.menu()){
  scan.restore(scanOpen);scan.apply(a);const after=scan.save();
  for(const b of scan.menu().filter(a=>a.target.nebulaId)){
   scan.restore(after);scan.apply(b);
   const c=scan.act('choose_target',a=>a.target.choiceId==='scan4:skip');
   const summary=short(scan),end=scan.save(),menu=scan.menu(),won=scan.state().data.sectorSettlements.winsByPlayerId['player-white'].length-winCount;
   assert.equal(summary.wallet[4],4);assert.equal(won,0);
   assert(!menu.some(a=>a.target.choiceId?.startsWith('trace:')));
   scan.restore(scanOpen);[a,b,c].forEach(scan.apply);assert.deepEqual(scan.save(),end);
   returns.push({steps:[a,b,c],summary,end,won});
  }
 }
 assert.equal(returns.length,18);
 console.log('three-income scan scores',returns.reduce((a,r)=>(a[r.summary.wallet[0]]=(a[r.summary.wallet[0]]||0)+1,a),{}));
 writeZ(out,{rows,scan:{e,start,scanOpen,returns}});
}finally{scan.dispose();}
