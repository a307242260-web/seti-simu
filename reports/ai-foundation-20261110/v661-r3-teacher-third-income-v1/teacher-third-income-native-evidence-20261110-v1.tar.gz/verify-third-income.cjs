'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ}=require('./controlled-r3');
const dir=process.argv[2]||__dirname,load=name=>readZ(path.join(dir,name+'-20261110-v1.json.gz'));
const preserve=load('teacher-conserve-data'),tech=load('teacher-earlier-income-levers'),pair=load('teacher-scan-pairs');
const early=load('teacher-early-amiba9'),income=load('teacher-three-income'),hidden=load('teacher-three-income-hidden');
const diagnostics=load('teacher-three-income-diagnostics'),matched=load('teacher-matched-income'),marker=load('teacher-marker-and-scan');
const r4=load('teacher-three-income-r4'),matchedR4=load('teacher-matched-income-r4'),cR4=load('teacher-c-marker-r4');
const result={replays:0,inputs:0,autonomous:0,maxNative:0,maxMs:0,pairs:0};
const normalize=e=>JSON.parse(JSON.stringify(e).split(e.session?.session?.sessionId||'__no_session__').join('effect-session-X'));
function replay(e,actions,end,settled=null,independentSession=false){
 const m=open(e);try{
  let pass=false;
  for(const u of actions){
   if(u.n!==undefined){assert(u.n<=256&&u.ms<=600);result.autonomous++;result.maxNative=Math.max(result.maxNative,u.n);result.maxMs=Math.max(result.maxMs,u.ms);}
   const a=u.action||u;
   if(settled&&a.actorId==='player-white'&&a.family==='pass'&&m.facts().round===3){assert.deepEqual(m.save(),settled.state);pass=true;}
   m.apply(a);result.inputs++;
  }
  if(settled)assert(pass);
  if(independentSession)assert.deepEqual(normalize(m.save()),normalize(end));else assert.deepEqual(m.save(),end);
  result.replays++;
 }finally{m.dispose();}
}
function group(e,g){
 for(const r of g.rows)replay(e,[...r.prefix,...r.actions],r.end,r.settled);
 for(const r of g.failures)replay(e,r.prefix,r.checkpoint);
}
group(preserve.root,preserve);assert.equal(preserve.failures[0].summary.wallet[4],3);
for(const [k,g] of Object.entries(tech.rows))group(tech.roots[k],g);
group(early.e,early);
for(const [k,g] of Object.entries(income.rows))group(income.roots[k],g);
group(matched.root,matched);group(marker.root,marker);
for(const [key,r] of Object.entries(hidden)){
 replay(r.e,r.executed,r.end);
 for(const field of ['obs','menu'])assert.deepEqual(r[field],hidden.original[field]);
 for(const field of ['a','n','value','roots'])assert.deepEqual(r.q[field],hidden.original.q[field]);
 if(key.startsWith('amiba'))assert(!r.incomeMenu.some(x=>x.gain?.energy===1));
 else assert.deepEqual(r.f.income,[7,4,1,1]);
}
for(const [k,r] of Object.entries(pair)){
 replay(r.start,r.pre,r.root);replay(r.root,[r.scan],r.opened,null,true);assert.equal(r.cases.length,18);
 for(const x of r.cases){replay(r.opened,x.steps,x.end);assert.equal(x.f.wallet[4],k==='first'?2:3);assert.equal(x.wins,0);result.pairs++;}
}
const d=diagnostics.scan;
replay(d.e,[d.start],d.scanOpen,null,true);assert.equal(d.returns.length,18);
for(const r of d.returns){replay(d.scanOpen,r.steps,r.end);assert.equal(r.won,0);assert.equal(r.summary.wallet[4],4);result.pairs++;}
assert.equal(d.returns.filter(x=>x.summary.wallet[0]===74).length,1);
for(const r of Object.values({...r4,...matchedR4,...cR4})){assert.equal(r.stop,'two-turns');replay(r.e,r.actions,r.end);}
assert.deepEqual(income.rows[20].rows[1].settled.summary.income,[7,4,1,1]);
assert.equal(marker.scoring['same-third-income-autonomous'].tileScoresById.a,11);
assert.equal(marker.scoring['b14-keep-aim-for-third-income'].tileScoresById.a,0);
assert.equal(marker.rows[2].actions[0].action.summary,'收入 amiba_5.webp');
assert.equal(marker.scoring['c-marker-same-scan-autonomous-income'].tileScoresById.c,8);
assert.deepEqual(Object.values(cR4)[0].checkpoints[1].s.wallet,[114,1,0,6,3]);
assert.equal(Object.values(cR4)[0].checkpoints[1].s.established,163);
console.log(JSON.stringify(result));
