'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,runCases}=require('./controlled-r3');
const [f,out]=process.argv.slice(2),d=readZ(f).rows['third-income-b14-route'],x=runCases(d.e,[['same-third-income-autonomous',()=>{}]]);
assert.equal(x.rows[0].actions[0].action.actionId,d.q.a.actionId);
writeZ(out,{root:d.e,...x});
