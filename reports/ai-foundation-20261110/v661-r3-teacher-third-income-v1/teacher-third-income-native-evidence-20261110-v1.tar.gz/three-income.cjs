'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const [f,out]=process.argv.slice(2),d=readZ(f),r=d.rows[0],roots={};
const m=open(d.e);
try{
 r.prefix.forEach(m.apply);
 for(const [i,u] of r.actions.entries()){if([20,33].includes(i))roots[i]=m.save();m.apply(u.action);}
 assert.deepEqual(m.save(),r.end);
}finally{m.dispose();}
const ch=(h,id)=>h.act('choose_target',a=>a.target.choiceId===id);
const comp=h=>{h.act('place_data');ch(h,'data:computer');};
const insert=(h,id)=>{const c=h.m.player().hand.find(c=>c.cardId===id);assert(c,id);h.act('choose_card',a=>a.target.cardInstanceId===c.id);};
const end=h=>{
 h.act('end_turn');
 while(h.m.menu().some(a=>a.target.choiceId?.startsWith('final:')))
  h.act('choose_target',a=>a.target.choiceId==='final:a'||a.target.choiceId==='final:c');
};
function trace(h){ch(h,'trace:1:blue:amiba:3');h.act('choose_card',a=>a.target.choiceId==='amiba:display:5');
 h.act('accept_optional_effect',a=>a.target.ruleId==='amiba9-blue-data-2'||a.target.ruleId==='amiba9-blue-data-1');h.cut('blue-data');}
function prepare(h){
 insert(h,'b_14.webp');end(h);
 h.take(h.m.play('amiba_0.webp'));ch(h,'symbol:blue_2');
 assert.deepEqual(short(h.m).wallet.slice(1,3),[1,1]);
 h.act('place_data');ch(h,'data:blueBonus:1');end(h);
 assert.deepEqual(short(h.m).wallet.slice(1,3),[1,2]);h.cut('scan-ready');
}
function scan(h){
 h.act('scan');
 const initial=h.m.menu().find(a=>a.target.nebulaId==='sector-3-a')||h.m.menu().find(a=>a.target.nebulaId);
 h.take(h.m.apply(initial));
 const next=h.m.menu().find(a=>a.target.nebulaId==='sector-3-a')||h.m.menu().find(a=>a.target.nebulaId);
 h.take(h.m.apply(next));
 if(h.m.menu().some(a=>a.target.choiceId==='scan4:skip'))ch(h,'scan4:skip');
 assert.equal(short(h.m).wallet[4],4);
 assert(!h.m.save().session);h.cut('scan-paid');
}
const rows={};
rows[33]=runCases(roots[33],[
 ['third-electric-choose-blue',trace],
 ['third-electric-native-income',h=>{trace(h);assert.equal(short(h.m).wallet[4],4);for(let i=0;i<4;i++)comp(h);insert(h,'amiba_5.webp');}],
]);
rows[20]=runCases(roots[20],[
 ['b14-retain-amiba7-pay-scan',prepare],
 ['b14-keep-aim-for-third-income',h=>{prepare(h);scan(h);comp(h);comp(h);end(h);h.act('analyze');trace(h);h.take(h.m.corner('amiba_7.webp'));assert.equal(short(h.m).wallet[4],4);for(let i=0;i<4;i++)comp(h);insert(h,'amiba_5.webp');h.cut('third-income');}],
]);
writeZ(out,{roots,rows});
