'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,runCases}=require('./controlled-r3');
const endScoring=require(path.resolve('randomizer/game/end-game-scoring')),effects=require(path.resolve('randomizer/game/cards/effects'));
const [src,diag,matched,out]=process.argv.slice(2),d=readZ(src),x=readZ(diag),r=d.rows[20].rows[1],m=open(d.roots[20]);
const index=r.prefix.findIndex(a=>a.target.choiceId==='final:a');let root,q,menu;
try{
 r.prefix.slice(0,index).forEach(m.apply);root=m.save();menu=m.menu();const {checkpoint,...p}=m.automatic();q=p;
 assert(q.complete&&q.n<=256&&q.ms<=600);
}finally{m.dispose();}
const best=x.scan.returns.find(v=>v.summary.wallet[0]===74);assert(best);
function execute(h,a){
 const b=h.m.menu().find(b=>b.family===a.family&&JSON.stringify(b.target)===JSON.stringify(a.target));
 assert(b,a.summary);h.take(h.m.apply(b));
}
function route(mark,better,insert){
 return h=>{
  h.act('choose_target',a=>a.target.choiceId===mark);
  const start=index+1;
  execute(h,r.prefix[start]);
  for(const a of better?best.steps:r.prefix.slice(start+1,start+4))execute(h,a);
  for(const a of r.prefix.slice(start+4,insert?undefined:-1))execute(h,a);
 };
}
const test=runCases(root,[
 ['a-marker-best-known-scan',route('final:a',true,true)],
 ['c-marker-same-scan-and-electric-income',route('final:c',false,true)],
 ['c-marker-same-scan-autonomous-income',route('final:c',false,false)],
]);
const scoring={};
for(const row of [...test.rows,r,...readZ(matched).rows]){
 const m=open(row.settled.state);
 try{
  const s=structuredClone(m.state()),p=s.players.players.find(x=>x.id==='player-white');
  scoring[row.label]=endScoring.computePlayerFinalScore({...s,players:s.players.players,currentPlayer:p,cardEffects:effects,
   getCardTypeCode:c=>effects.getRuntimeCardTypeCode(c,effects.getCardModel(c)?.cardType)},p);
 }finally{m.dispose();}
}
console.log('tile scoring',Object.fromEntries(Object.entries(scoring).map(([k,v])=>[k,[v.baseScore,v.totalScore,v.tileScoresById]])));
writeZ(out,{root,index,q,menu,scoring,...test});
