'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,short}=require('./controlled-r3');
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const {getIncomeGainForCard}=require(path.resolve('randomizer/game/cards/deck'));
const [early,route,out]=process.argv.slice(2),a=readZ(early),b=readZ(route),r=a.rows[0],final=b.rows[20].rows[1];
const steps=[...r.prefix,...r.actions.slice(0,20).map(x=>x.action),...final.prefix],rows={};
for(const key of ['original','ordinary-blind-b16','ordinary-blind-dlc17','amiba-display-amiba2']){
 const e=structuredClone(a.e),s=JSON.parse(e.committedState);
 const swap=(items,a,b)=>{assert(items[a]!==items[b]);[items[a],items[b]]=[items[b],items[a]];};
 if(key.startsWith('ordinary')){
  const id=key.endsWith('b16')?'b_16.webp':'dlc_17.png';
  assert.equal(s.cards.drawPileCardIds[0],'dlc_24.png');const index=s.cards.drawPileCardIds.indexOf(id);assert(index>=3);
  swap(s.cards.drawPileCardIds,0,index);
 }
 if(key.startsWith('amiba')){assert.deepEqual(s.aliens.amiba.cardDeck.slice(0,2),[5,2]);swap(s.aliens.amiba.cardDeck,0,1);}
 e.committedState=createStateStore(s).serialize().serialized;
 const m=open(e);
 try{
  const obs=m.owner('player-white'),menu=m.menu(),{checkpoint,...q}=m.automatic();assert(q.complete&&q.n<=256&&q.ms<=600);
  if(rows.original){
   assert.deepEqual(obs,rows.original.obs);assert.deepEqual(menu,rows.original.menu);
   for(const f of ['a','value','n','roots','complete'])assert.deepEqual(q[f],rows.original.q[f],key+'/'+f);
  }
  const executed=[];let incomeMenu=null,blind=null;
  for(let i=0;i<steps.length;i++){
   const a=steps[i];
   if(i===steps.length-1){
    incomeMenu=m.menu().map(choice=>{
     const c=m.player().hand.find(card=>card.id===choice.target.cardInstanceId);assert(c);
     return {card:c.cardId,gain:getIncomeGainForCard(c)};
    });
    if(key.startsWith('amiba'))break;
   }
   const current=key.startsWith('amiba')&&a.target.choiceId==='amiba:display:5'
    ?m.menu().find(b=>b.target.choiceId==='amiba:display:2')
    :m.menu().find(b=>b.family===a.family&&JSON.stringify(b.target)===JSON.stringify(a.target));
   assert(current,key+' '+a.summary);
   executed.push(m.apply(current));
   if(i===1)blind=short(m).hand.find(id=>id!=='amiba_0.webp'&&id!=='b_14.webp');
  }
  const end=m.save(),f=short(m);
  if(key.startsWith('amiba')){
   assert.equal(f.income[1],3);assert(!incomeMenu.some(x=>x.gain?.energy===1));
  }else{
   assert.deepEqual(f.income,[7,4,1,1]);assert.deepEqual(f.wallet,[77,0,1,5,0]);
   assert.deepEqual(f.computer,[1,2,3,4]);assert.equal(f.probes.length,2);
   if(rows.original)assert.deepEqual(f.probes,rows.original.f.probes);
  }
  m.restore(e);executed.forEach(m.apply);assert.deepEqual(m.save(),end);
  rows[key]={e,obs,menu,q,executed,end,f,blind,incomeMenu};
  console.log(key,JSON.stringify([blind,q.a.summary,q.value,q.n,f.wallet,f.income,incomeMenu]));
 }finally{m.dispose();}
}
writeZ(out,rows);
