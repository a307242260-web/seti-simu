'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),e=d.anchors[54].e,m=open(e),roots={},rows={};
function root(label,idx){
 const r=d.cases[54].rows.find(x=>x.label===label);m.restore(e);[...r.prefix,...r.actions.slice(0,idx).map(u=>u.action)].forEach(m.apply);return m.save();
}
try{
 roots.tech=root('b14-energy-second-income',4);
 roots.research=root('amiba9-energy-second-income',2);
}finally{m.dispose();}
const ch=(h,id)=>h.act('choose_target',a=>a.target.choiceId===id);
rows.tech=runCases(roots.tech,[
 ['teacher-purple2-late',h=>ch(h,'tech:purple2')],
 ['orange4-on-b14-income',h=>ch(h,'tech:orange4')],
 ['blue3-market-on-b14-income',h=>ch(h,'tech:blue3:slot:3')],
]);
rows.research=runCases(roots.research,[
 ['preserve-b14-research-blue4',h=>{
   h.take(h.m.corner('amiba_0.webp'));h.act('research_tech');ch(h,'tech:blue4:slot:3');
 }],
 ['play-b14-before-blue4',h=>h.take(h.m.play('b_14.webp'))],
 ['play-amiba0-before-blue4',h=>h.take(h.m.play('amiba_0.webp'))],
]);
writeZ(out,{roots,rows});
