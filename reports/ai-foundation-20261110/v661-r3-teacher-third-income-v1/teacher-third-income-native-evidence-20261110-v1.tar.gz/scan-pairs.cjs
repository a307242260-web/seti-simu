'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [prior,retain,out]=process.argv.slice(2),d=readZ(prior),x=readZ(retain),r=d.cases[54].rows.find(q=>q.label==='b14-energy-second-income');
let first;
const init=open(d.anchors[54].e);
try{[...r.prefix,...r.actions.slice(0,11).map(u=>u.action)].forEach(init.apply);first=init.save();}
finally{init.dispose();}
const inputs={first,second:x.rows[0].start},rows={};
for(const [name,start] of Object.entries(inputs)){
 const m=open(start);
 try{
  const pre=[];if(name==='second')pre.push(m.act('quick_trade',a=>a.target.tradeId==='credits-for-energy'));
  const root=m.save(),oldWins=m.state().data.sectorSettlements.winsByPlayerId['player-white'].length;
  const scan=m.act('scan'),opened=m.save(),cases=[];
  for(const a of m.menu()){
   m.restore(opened);m.apply(a);const s=m.save();
   for(const b of m.menu().filter(a=>a.target.nebulaId)){
    m.restore(s);m.apply(b);
    const move=m.menu().find(a=>a.target.choiceId==='scan4:move:5:ccw');
    const finish=move||m.menu().find(a=>a.target.choiceId==='scan4:skip');
    if(finish)m.apply(finish);
    const end=m.save(),legal=m.menu(),f=short(m),wins=m.state().data.sectorSettlements.winsByPlayerId['player-white'].length-oldWins;
    const steps=[a,b,...(finish?[finish]:[])];
    m.restore(opened);steps.forEach(m.apply);assert.deepEqual(m.save(),end);
    cases.push({steps,end,legal,f,wins});
   }
  }
  rows[name]={start,pre,root,scan,opened,cases};
  console.log(name,cases.length,JSON.stringify(cases.map(r=>[r.steps.slice(0,2).map(a=>a.summary),r.f.wallet[4],r.wins,r.legal.filter(a=>a.target.choiceId?.startsWith('trace')).length])));
 }finally{m.dispose();}
}
writeZ(out,rows);
