# 教师同起点：第三次插收入、标记与原生复放

游戏源码与 `67d3118d8586d99014b6963dcf05dd2c6eb11d9b` 相同。运行时使用原生存档 `teacher-before-input-113-20261105-v1.checkpoint.json` 的第三轮出发点，其他三席只 PASS 或做必选。从源码根运行：

```sh
(cd "$P" && shasum -a 256 -c SHA256SUMS)
node "$P/verify-third-income.cjs"
```

`P` 是本档案解包目录。验证器不重新搜索；从包内真实检查点重放动作，核对完整信封、会话及 RNG、预算、54 个扫描组合和阶段账本。仅独立新建扫描会话时标准化其 ID 命名空间。

`conserve-data.cjs`、`scan-pairs.cjs`、`earlier-income-levers.cjs` 和 `early-amiba9.cjs` 读取上一份[教师同起点证据](../v661-r3-fossil-retention-teacher-start-v1/fossil-retention-teacher-start-native-evidence-20261110-v1.tar.gz)中的 `teacher-r3-current-20261110-v1.json.gz` 或 `teacher-income-choices-20261110-v1.json.gz`，参数见每个脚本开头。其后各脚本只使用包内的上游 JSON.GZ。所有生成脚本拒绝覆盖已有结果；复放器可直接使用现成证据。
