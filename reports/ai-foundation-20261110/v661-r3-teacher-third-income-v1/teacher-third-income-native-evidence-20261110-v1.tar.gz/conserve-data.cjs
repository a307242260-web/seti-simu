'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const [f,out]=process.argv.slice(2),d=readZ(f),r=d.cases[54].rows.find(v=>v.label==='b14-energy-second-income');
const m=open(d.anchors[54].e);let root,base;
try{
 r.prefix.forEach(m.apply);r.actions.slice(0,17).forEach(x=>m.apply(x.action));
 root=m.save();base=short(m);assert.deepEqual(base.wallet,[79,3,1,0,1]);
 assert.deepEqual(base.computer,[1,2,3,4,5]);
 const {checkpoint,...q}=m.automatic();assert(q.complete&&q.n<=256&&q.ms<=600);
 console.log('cash vs preserve',q.a.summary,q.value,q.n,q.roots);
}finally{m.dispose();}
function action(h,a){
 const next=h.m.menu().find(b=>b.family===a.family&&b.actorId===a.actorId
   &&JSON.stringify(b.target)===JSON.stringify(a.target));
 assert(next,a.summary);h.take(h.m.apply(next));
}
const end=h=>h.act('end_turn'),comp=h=>{h.act('place_data');h.act('choose_target',a=>a.target.choiceId==='data:computer');};
function sameScan(h){
 for(const u of r.actions.slice(20,25))action(h,u.action);
 assert.equal(short(h.m).wallet[4],3);h.cut('after-scan');
}
function analysis(h){
 comp(h);end(h);h.act('analyze');h.act('choose_target',a=>a.target.choiceId==='trace:1:blue:amiba:3');
 h.act('choose_card',a=>a.target.choiceId==='amiba:display:5');h.cut('known-display');
}
function electricIncome(h){
 h.take(h.m.corner('amiba_5.webp'));
 assert.equal(short(h.m).wallet[4],4);
 for(let i=0;i<4;i++)comp(h);
 const c=h.m.player().hand.find(x=>x.cardId==='amiba_9.webp');
 assert(c);h.act('choose_card',a=>a.target.cardInstanceId===c.id);h.cut('income');
}
const test=runCases(root,[
 ['keep-token-only',h=>{end(h);h.cut('ready');}],
 ['keep-token-same-scan',h=>{end(h);sameScan(h);}],
 ['keep-token-analysis-known-display',h=>{end(h);sameScan(h);analysis(h);}],
 ['keep-token-prove-third-income',h=>{end(h);sameScan(h);analysis(h);electricIncome(h);}],
]);
writeZ(out,{root,base,...test});
