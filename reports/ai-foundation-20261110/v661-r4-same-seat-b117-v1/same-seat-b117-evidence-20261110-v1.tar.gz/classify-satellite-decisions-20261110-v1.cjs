'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const [root,out]=process.argv.slice(2),file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));Module._cache[file]=mod;
const at='      loadedEnvelope = null;\n      const executeAt = now();',source=fs.readFileSync(file,'utf8');
assert.equal(source.split(at).length,2);
mod._compile(source.replace(at,'      globalThis.countInput(current,session,loadedEnvelope);\n'+at),file);mod.loaded=true;
const counts={},groups={},witness={},targets={},sourceKeys={};
function inc(o,k){o[k]=(o[k]||0)+1;}
globalThis.countInput=(a,s,envelope)=>{
 const head=s?.queue[0],origin=s?.journal?.actions?.[0]?.action?.family,kind=a.target?.kind;
 if(head?.type==='science_domain_alien_trace'){
  const key=[a.target.traceType,a.target.speciesId||'extra',a.target.position||a.target.alienSlotId].join('/');
  inc(counts,'trace/'+key);inc(groups,'trace/queue/'+s.queue.map(e=>e.type).join('/'));
  inc(sourceKeys,'trace/'+[a.target.traceType,origin,Boolean(s.irreversibleBarrier)].join('/'));
  if(!witness['trace/'+key])witness['trace/'+key]={envelope,action:a};
 }else if(head?.type==='residual_card_decision'&&a.family==='accept_optional_effect'){
  const tag=(a.target.choiceId||'').split(':')[0],p=head.payload;
  const key=[p.kind,p.ruleId||p.eventType,tag].join('/');
  inc(counts,'optional/'+key);inc(groups,'optional/queue/'+s.queue.map(e=>e.payload?.ruleId||e.type).join('/'));
  inc(sourceKeys,'optional/'+[p.kind,p.ruleId,origin,Boolean(s.irreversibleBarrier)].join('/'));
  if(!witness['optional/'+key])witness['optional/'+key]={envelope,action:a};
 }else if(head?.type==='residual_alien_card_decision'&&a.family==='choose_card'){
  const key=[head.payload.speciesId,a.target.source||a.target.choiceId?.split(':')[1]].join('/');
  inc(counts,'alien/'+key);inc(groups,'alien/queue/'+s.queue.map(e=>e.type).join('/'));
  inc(sourceKeys,'alien/'+[key,origin,Boolean(s.irreversibleBarrier)].join('/'));
  if(!witness['alien/'+key])witness['alien/'+key]={envelope,action:a};
 }
};
const {open}=require('./native-late-r3'),checkpoint=JSON.parse(fs.readFileSync(root)).checkpoint,m=open(checkpoint);
try{
 const q=m.automatic();assert.equal(q.n,3423);assert(q.complete);assert.deepEqual(m.save(),checkpoint);
 const result={native:q.n,value:q.value,counts,groups,sourceKeys,witness};
 fs.writeFileSync(out,z.gzipSync(JSON.stringify(result)+'\n'),{flag:'wx'});
 for(const obj of [counts,sourceKeys,groups])console.log(JSON.stringify(Object.entries(obj).sort((a,b)=>b[1]-a[1]).slice(0,26)));
}finally{m.dispose();}
