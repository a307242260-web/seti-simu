'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3'),plans=require(path.resolve('randomizer/game/ai/local-decision-plans.js'));
const v=require(path.resolve('randomizer/game/ai/state-value.js'));
const [fixture,root,out]=process.argv.slice(2),rows=JSON.parse(z.gunzipSync(fs.readFileSync(fixture))).confirmations;
const origin=JSON.parse(fs.readFileSync(root)).checkpoint,model=open(origin),evidence=[];
const restore=e=>{
 assert(model.c.lifecycle.restore(e).ok);
 assert.deepEqual(model.state(),e.session?.session?.workingState||JSON.parse(e.committedState));
};
const wallet=s=>s.players.players.find(p=>p.id===seat).resources;
try{
 for(const {envelope,action} of rows){
  restore(envelope);
  const session=model.save().session.session,state=session.workingState,menu=model.menu();
  const p=state.players.players.find(p=>p.id===seat),knownCards=new Set(p.reservedCards.map(c=>c.id));
  const fixed=plans.pureOptional({state,seatId:seat,actions:menu,session,knownCards});
  assert.equal(fixed?.selectedActionId,action.actionId);
  const preview=plans.previewFinalPositiveEndTask({state,seatId:seat,actions:menu,session,action,knownCards});
  assert(preview);model.apply(action);
  const confirmed=model.state(),after=model.facts(),result=model.save();
  assert.equal(result.session,null);
  assert.deepEqual(confirmed,preview);
  assert.deepEqual(confirmed.meta.rngState,state.meta.rngState);
  restore(envelope);const skip=model.menu().find(a=>a.target.choiceId.startsWith('skip:task:'));model.apply(skip);
  const skipped=model.state(),passed=model.facts();
  assert.equal(after.wallet.score-passed.wallet.score,3);
  assert.equal(after.wallet.credits-passed.wallet.credits,1);
  assert(after.final>passed.final);
  assert.equal(confirmed.turn.currentPlayerId,seat);
  const owner=s=>s.players.players.find(p=>p.id===seat);
  assert.equal(owner(confirmed).completedTaskCount,owner(skipped).completedTaskCount+1);
  for(const k of Object.keys(confirmed).filter(k=>!['players','cards'].includes(k)))assert.deepEqual(confirmed[k],skipped[k],k);
  const stable={...envelope,session:null};restore(stable);
  const end=model.menu().find(a=>a.family==='end_turn');assert(end);
  const prelude=plans.previewFinalEndPrelude({state:model.state(),seatId:seat,action:end,knownCards,allowSameSeat:true});
  assert(prelude?.task);assert.deepEqual(prelude.working,state);assert.deepEqual(prelude.task,session.queue[0].payload);
  model.apply(end);
  const formal=model.save().session.session;
  assert.deepEqual(formal.workingState,prelude.working);assert.deepEqual(formal.queue[0].payload,prelude.task);
  assert.deepEqual(model.menu().map(a=>a.target),menu.map(a=>a.target));
  restore(stable);
  const quick=model.menu().find(a=>a.family==='complete_task'&&a.target.ruleId==='b117-orbit-land-count-task');
  let quickExact=false;
  if(quick){
   const quickPreview=plans.previewFinalPositiveTaskClaim({state:model.state(),seatId:seat,action:quick,knownCards});
   assert(quickPreview);model.apply(quick);assert.equal(model.save().session,null);
   assert.deepEqual(model.state(),quickPreview);quickExact=true;
  }
  evidence.push({fixed:fixed.reason,quickExact,scoreGain:after.wallet.score-passed.wallet.score,creditsGain:after.wallet.credits-passed.wallet.credits,
   countedScoreGain:after.final-passed.final,nativeVersion:confirmed.meta.stateVersion});
 }
 model.restore(origin);assert.deepEqual(model.save(),origin);
 const result={prelude:rows.length,confirm:rows.length,quick:evidence.filter(r=>r.quickExact).length,
  countedScoreGains:[...new Set(evidence.map(r=>r.countedScoreGain))],evidence};
 fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 console.log({...result,evidence:undefined});
}finally{model.dispose();}
