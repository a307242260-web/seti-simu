'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,writeZ,short}=require('./controlled-r3');
const {pathToEarth}=require('./shortest-return-20261110-v1.cjs');
const {evaluateStateValue}=require(path.resolve('randomizer/game/ai/state-value'));
const [source,out]=process.argv.slice(2),root=readZ(source)['neither-salary-has-data'].e;
const m=open(root),seat='player-white',rows={};
const cardA='chong_8.webp',cardB='amiba_9.webp';
try{
 for(const [name,corners,tech] of [['keep-both',[],null],['keep-amiba9',[cardA],null],['keep-chong8',[cardB],null],
  ['spend-both-no-research',[cardA,cardB],null],['research-orange3',[cardA,cardB],'orange3']]){
  m.restore(root);const steps=[],stages={};
  const act=(f,p)=>steps.push(m.act(f,p));
  const cut=k=>{
   const s=m.state(),ship=s.pieces.rockets.find(r=>r.fossilId==='fossil_07'),shipTask=Object.values(s.aliens.chong.transportTasksByRocketId).find(t=>t.fossilId===ship.fossilId);
   const observed=m.owner(seat);
   stages[k]={state:m.save(),summary:short(m),rotation:s.solarSystem.rotation,ship,shipTask,
    value:evaluateStateValue(observed,seat)};
  };
  for(const c of corners)steps.push(m.corner(c));
  cut('after-corners');
  if(tech){
   act('research_tech');act('choose_target',a=>a.target.tileId===tech);cut('after-research');
   act('end_turn');if(m.menu()[0].actorId!==seat)m.advanceOpponents(steps);
  }
  cut('before-pass');
  const routeBeforePass=pathToEarth(m,'fossil_07');
  act('pass');act('choose_card',a=>a.target.choiceId==='card-30-pass-3-1');
  if(m.menu()[0].actorId!==seat)m.advanceOpponents(steps);
  assert.equal(m.facts().round,4);cut('round4');
  const route=pathToEarth(m,'fossil_07');
  let cashTrades=0;
  for(const d of route.path){
   while(m.player().resources.energy<d.cost){act('quick_trade',a=>a.target.tradeId==='credits-for-energy');cashTrades++;}
   act('move',a=>a.target.rocketId===route.rocketId&&a.target.deltaX===d.deltaX&&a.target.deltaY===d.deltaY);
   act('choose_payment',a=>a.target.kind==='move-payment'&&!a.target.cardIds.length);
   assert.notEqual(m.c.inspect().phase,'awaiting_input');
  }
  cut('delivered');
  act('complete_task',a=>a.target.cardInstanceId===stages.round4.shipTask.cardId);
  assert(m.state().aliens.chong.fossilsById.fossil_07.taskCompleted);
  cut('claimed');
  const end=m.save();m.restore(root);steps.forEach(a=>m.apply(a));assert.deepEqual(m.save(),end);m.restore(root);
  rows[name]={steps,stages,routeBeforePass,route,cashTrades,end};
  console.log(JSON.stringify({name,steps:steps.length,
   stages:Object.fromEntries(Object.entries(stages).map(([k,v])=>[k,{wallet:v.summary.wallet,hand:v.summary.hand,rotation:v.rotation,
    value:v.value.total,components:v.value.components,ship:[v.ship?.sectorX,v.ship?.sectorY],established:v.summary.established}])),
    path:route.path.map(d=>[d.from,d.to,d.cost]),cashTrades}));
 }
 assert.deepEqual(Object.values(rows).map(r=>r.route.cost),[3,3,3,3,4]);
 assert.deepEqual(Object.values(rows).map(r=>r.cashTrades),[0,0,0,0,1]);
 writeZ(out,{root,rows});
}finally{m.dispose();}
