'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,writeZ,short}=require('./controlled-r3');
const cards=require(path.resolve('randomizer/game/cards/deck')),data=require(path.resolve('randomizer/game/data'));
const [source,out]=process.argv.slice(2),{root,rows}=readZ(source),seat='player-white',matrix=[];
function noElectric(root){
 const s=JSON.parse(root.committedState),deck=s.cards.drawPileCardIds,options=s.cards.passReservePiles[3],old=options[0];
 assert.equal(old.cardId,'dlc_10.png');
 const idx=deck.indexOf('b_137.webp');
 assert(idx>=4);
 const model=cards.CARD_CATALOG.find(c=>c.card_id==='b_137.webp'),{cardName,src,...replacement}=cards.createCardInstance(model,old.id.slice(5));
 assert.equal(old.id,replacement.id);assert(!cards.getIncomeGainForCard(replacement).energy);
 options[0]=Object.fromEntries(Object.keys(replacement).sort().map(k=>[k,replacement[k]]));deck[idx]=old.cardId;
 return {...root,committedState:JSON.stringify(s)};
}
const hidden=noElectric(root);
const view=e=>{const m=open(e);try{return [m.owner(seat),m.menu(),m.state().meta.rngState];}finally{m.dispose();}};
assert.deepEqual(view(root),view(hidden));
for(const [label,start] of [['electric-reserve',root],['no-electric-reserve',hidden]]){
 for(const [name,prior] of Object.entries(rows)){
  const m=open(start),steps=[],stages={};
  const act=(f,p)=>steps.push(m.act(f,p));
  const cut=k=>stages[k]={state:m.save(),summary:short(m)};
  try{
   prior.steps.forEach(a=>{if(a.target.kind==='pass-reserve-card')act(a.family,b=>b.target.choiceId===a.target.choiceId);else steps.push(m.apply(a));});
   cut('claimed');assert.equal(m.player().resources.availableData,2);assert.equal(m.facts().computer.length,3);
   steps.push(...m.swap('chong_9.webp','dlc_15.png'));
   steps.push(m.corner('dlc_15.png'));
   act('place_data');act('choose_target',a=>a.target.target==='computer');
   const incomeMenu=m.menu().filter(a=>a.target.choiceId?.startsWith('income:')).map(a=>{
    const c=m.player().hand.find(x=>x.id===a.target.cardInstanceId);assert(c);
    return {action:a,id:c.cardId,gain:cards.getIncomeGainForCard(c),alreadyHeldInRound3:['chong_7.webp','chong_9.webp','chong_8.webp','amiba_9.webp'].includes(c.cardId)};
   });
   const known=incomeMenu.filter(x=>x.gain.energy&&x.alreadyHeldInRound3);
   const choice=known[0]||incomeMenu.find(x=>x.gain.energy)||incomeMenu.find(x=>x.gain.credits&&x.alreadyHeldInRound3);
   assert(choice);
   steps.push(m.apply(choice.action));cut('income');
   for(let i=0;i<2;i++){act('place_data');act('choose_target',a=>a.target.target==='computer');}
   assert.equal(data.listComputerPlacedTokens(m.player()).length,6);
   act('analyze',a=>a.payload.skipCost===true);
   act('choose_target',a=>a.target.choiceId==='trace:2:blue:chong:8');
   act('choose_card',a=>a.target.source==='display');cut('resolved-blue8');
   const end=m.save();m.restore(start);steps.forEach(a=>m.apply(a));assert.deepEqual(m.save(),end);m.restore(start);
   const c=stages['resolved-blue8'].summary;
   matrix.push({label,name,choice,known,incomeMenu,stages,steps,end});
   console.log(JSON.stringify([label,name,steps.length,c.wallet,c.established,c.income,choice.id,known.map(x=>x.id)]));
  }finally{m.dispose();}
 }
}
assert.equal(matrix.length,10);
const find=(l,n)=>matrix.find(x=>x.label===l&&x.name===n);
for(const label of ['electric-reserve','no-electric-reserve']){
 assert.equal(find(label,'keep-amiba9').choice.id,'amiba_9.webp');
 assert.equal(find(label,'keep-chong8').choice.id,'chong_8.webp');
}
for(const name of ['spend-both-no-research','research-orange3']){
 assert.equal(find('electric-reserve',name).choice.id,'dlc_10.png');
 assert(!find('no-electric-reserve',name).incomeMenu.some(x=>x.gain.energy));
}
writeZ(out,{root,hidden,matrix});
