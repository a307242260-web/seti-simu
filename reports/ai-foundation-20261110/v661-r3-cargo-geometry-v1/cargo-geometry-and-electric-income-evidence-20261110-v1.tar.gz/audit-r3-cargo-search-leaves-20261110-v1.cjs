'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),Module=require('node:module');
const ai=path.resolve('randomizer/game/ai'),source=path.join(ai,'decision-search.js'),portSource=path.join(ai,'analysis-port.js');
const extension=Module._extensions['.js'],nodeEntries=new Map(),envelopes=new WeakMap();
globalThis.recordCargoNode=(i,n,v,b,f)=>nodeEntries.set(i,{n,v,b,f});
globalThis.recordCargoEnvelope=(n,e)=>envelopes.set(n,e);
Module._extensions['.js']=(m,f)=>{
 if(f!==source&&f!==portSource)return extension(m,f);
 const s=fs.readFileSync(f,'utf8');
 if(f===source){
  const anchor='      if(initializeDeferred){configured.queued=nodes[index].queued;nodes[index]=configured;}else nodes.push(configured);';
  assert.equal(s.split(anchor).length,2);
  m._compile(s.replace(anchor,anchor+'\n      globalThis.recordCargoNode(index,node,value,baseValue,forecast);'),f);
 }else{
  const anchor='      nodeCount += 1;\n      return node;';
  assert.equal(s.split(anchor).length,2);
  m._compile(s.replace(anchor,'      globalThis.recordCargoEnvelope(node,envelope);\n'+anchor),f);
 }
};
const {open,readZ,writeZ}=require('./controlled-r3');
const {createAnalysisPort}=require(portSource);
const {OPTIONS,BUDGET}=require(path.join(ai,'search-agent'));
const {evaluateStateValue,createStateValueEvaluator}=require(path.join(ai,'state-value'));
const {searchDecision}=require(source);
const [file,out]=process.argv.slice(2),{root,hidden,matrix}=readZ(file),seat='player-white',rows=[];
function follow(lines,index,value,seen=new Set()){
 assert(!seen.has(index));seen.add(index);
 const line=lines[index];assert(line);
 if(!line.edges?.length)return [{path:[],leaf:line}];
 return line.edges.filter(edge=>lines[edge.target]?.value===value)
  .flatMap(edge=>follow(lines,edge.target,value,new Set(seen)).map(r=>({path:[edge,...r.path],leaf:r.leaf})));
}
for(const [name,start] of [['original',root],['hidden-no-electric',hidden],['after-chong8',matrix.find(r=>r.label==='electric-reserve'&&r.name==='keep-amiba9').stages.claimed.state]]){
 let e=start;
 if(name==='after-chong8'){
  const control=open(root);control.corner('chong_8.webp');e=control.save();control.dispose();
 }
 const m=open(e),port=createAnalysisPort({composition:m.c,seatId:seat});
 try{
  nodeEntries.clear();const evaluate=createStateValueEvaluator(seat);
  const q=searchDecision({port,root:port.openRoot(),evaluate,modelKey:evaluate.modelKey,budget:BUDGET,...OPTIONS});
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),e);
  const menu=m.menu(),passId=menu.find(a=>a.family==='pass').actionId;
  const captures={};
  for(const id of [passId,q.actionId]){
   const target=q.roots.find(r=>r.actionId===id);
   const first=q.lines[0].edges.find(edge=>edge.actionId===id&&edge.target===target.target);
   assert(first);
   const a=follow(q.lines,first.target,target.value).slice(0,6);
   assert(a.length);
   captures[id]=a.map(({path,leaf})=>{
    const i=nodeEntries.get(leaf.node);assert(i);
    const obs=port.valueObservation(i.n),envelope=envelopes.get(i.n),p=obs.publicState.players.find(p=>p.playerId===seat);
    const state=envelope&&(envelope.session?.session?.workingState||JSON.parse(envelope.committedState));
    return {value:target.value,path:[first,...path].map(x=>({actionId:x.actionId,steps:x.steps,goal:x.resourceGoal})),
     leaf,base:i.b,forecast:i.f,details:evaluateStateValue(obs,seat),view:{round:obs.publicState.roundNumber,turn:obs.publicState.turnNumber,
      passing:obs.publicState.passingPlayerIds,p:{score:p.score,credits:p.credits,energy:p.energy,publicity:p.publicity},
      hand:obs.selfState.hand.map(c=>c.cardId),cargo:obs.publicState.board.rockets.filter(q=>q.fossilId),rotation:state?.solarSystem.rotation,
      pending:envelope?.session?.session?.queue.map(q=>q.type)}};
   });
  }
  rows.push({name,root:e,menu,actionId:q.actionId,value:q.value,n:q.diagnostics.nativeExecutions,ms:q.diagnostics.milliseconds,roots:q.roots,captures});
  console.log(JSON.stringify({name,actionId:q.actionId,n:q.diagnostics.nativeExecutions,ms:Math.round(q.diagnostics.milliseconds),
   captures:Object.fromEntries(Object.entries(captures).map(([k,v])=>[k,v.map(d=>[d.value,d.leaf.status,d.leaf.boundary,d.base,d.forecast,d.details.components,d.view.round,d.view.turn,d.view.p,d.view.hand,d.view.rotation])]))}));
 }finally{port.close();m.dispose();}
}
for(const k of ['actionId','value','n','menu','roots','captures'])assert.deepEqual(rows[0][k],rows[1][k],k);
writeZ(out,{rows});
