'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ}=require('./controlled-r3');
const [file,out]=process.argv.slice(2),{rows}=readZ(file),result={};
for(const name of ['keep-amiba9','research-orange3']){
 const e=rows[name].stages.round4.state,m=open(e);
 try{
  const menu=m.menu(),q=m.automatic(),moves=menu.filter(a=>a.family==='move'&&a.target.rocketId===rows[name].route.rocketId);
  assert(moves.length>0&&q.complete);assert.deepEqual(m.save(),e);
  for(const a of moves)assert.equal(q.roots.find(r=>r.actionId===a.actionId)?.completion,'excluded-by-movement-policy');
  assert(!q.roots.some(r=>r.goal?.kind==='funded-earth-shipment'));
  result[name]={q,e,menu};
  console.log(JSON.stringify([name,q.a.summary,q.value,q.n,q.ms,moves.length]));
 }finally{m.dispose();}
}
writeZ(out,result);
