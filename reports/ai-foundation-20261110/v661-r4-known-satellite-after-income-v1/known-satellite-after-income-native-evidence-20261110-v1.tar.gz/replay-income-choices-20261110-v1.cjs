'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),V=require(path.resolve('randomizer/game/ai/state-value'));
const {checkpoint:root}=JSON.parse(fs.readFileSync(process.argv[3])),q=JSON.parse(z.gunzipSync(fs.readFileSync(process.argv[4])));
const m=open(root),income=q.lines[0].edges.find(e=>e.resourcePlan?.id==='data:income:4');
assert(income&&income.steps.length===3);
function best(i,first){
 const edges=[];
 if(first){edges.push(first);i=first.target;}
 while(q.lines[i].edges.length){
  const l=q.lines[i];
  const e=l.edges.find(e=>q.lines[e.target].value===l.value&&q.lines[e.target].distance+e.cost===l.distance);
  assert(e,'No matching fully scored edge at '+i);edges.push(e);i=e.target;
 }
 return {leaf:q.lines[i],steps:edges.flatMap(e=>e.steps||[e.actionId])};
}
try{
 for(const id of income.steps){const a=m.menu().find(x=>x.actionId===id);assert(a);m.apply(a);}
 const start=m.save(),entries=[];
 for(const branch of q.lines[income.target].edges){
  m.restore(start);
  const r=best(income.target,branch),steps=[];
  for(const id of r.steps){
   const a=m.menu().find(x=>x.actionId===id);assert(a,id);
   m.apply(a);steps.push({a,checkpoint:m.save()});
  }
  const facts=m.facts(),v=V.evaluateStateValue(m.owner(seat),seat);
  m.restore(start);for(const {a,checkpoint} of steps){m.apply(a);assert.deepEqual(m.save(),checkpoint);}
  entries.push({r,steps,facts,unmaskedV:v});
 }
 m.restore(root);assert.deepEqual(m.save(),root);
 fs.writeFileSync(process.argv[5],z.gzipSync(JSON.stringify({root,start,entries,rootRestored:true})),{flag:'wx'});
 console.log(JSON.stringify(entries.map(x=>({first:x.steps[0].a.summary,v:x.r.leaf.value,boundary:x.r.leaf.boundary,wallet:x.facts.wallet,
  n:x.steps.length,steps:x.steps.map(s=>s.a.summary)}))));
}finally{m.dispose();}
