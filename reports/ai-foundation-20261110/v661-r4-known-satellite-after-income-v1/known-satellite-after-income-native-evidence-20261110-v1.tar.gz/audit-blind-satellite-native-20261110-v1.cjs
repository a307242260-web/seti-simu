'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const captured=new WeakMap(),js=Module._extensions['.js'];
globalThis.captureScopedNode=(n,e)=>captured.set(n,e);
Module._extensions['.js']=(mod,file)=>{
 if(!file.endsWith('/randomizer/game/ai/analysis-port.js'))return js(mod,file);
 const s=fs.readFileSync(file,'utf8'),marker='      nodeCount += 1;\n      return node;';
 assert.equal(s.split(marker).length,2);
 mod._compile(s.replace(marker,'      globalThis.captureScopedNode(node,envelope);\n'+marker),file);
};
const {open,seat}=require(process.argv[2]);
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {evaluateStateValue}=require(path.resolve('randomizer/game/ai/state-value'));
const data=JSON.parse(z.gunzipSync(fs.readFileSync(process.argv[3]))),witness=[];
const eq=(a,b)=>require('node:util').isDeepStrictEqual(a,b);
function parity(actual,expected,i){
 const a=JSON.parse(actual.committedState),b=JSON.parse(expected.committedState);
 assert.deepEqual(a,b,'committed at '+i);
 if(!eq(actual.session,expected.session)){
  const x=actual.session?.session,y=expected.session?.session;
  throw Error('SESSION_DIFF '+i+' '+JSON.stringify({
    keys:x&&y&&Object.keys(x).filter(k=>!eq(x[k],y[k])),
    journal:x&&y&&Object.keys(x.journal).filter(k=>!eq(x.journal[k],y.journal[k])),
    state:x&&y&&Object.keys(x.workingState).filter(k=>!eq(x.workingState[k],y.workingState[k])),
  }));
 }
}
for(const r of data.results){
 const m=open(r.before),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0}),path=[];
 const native=m.c.counterfactualPort.createFork(r.before,{branchKey:'audit-scoped-blind',restoreRandomState:true}).composition;
 try{
  p.setMovementPlanning(true);p.setResourcePlanning(true);p.setCardPickPlanning(true);
  p.setDecisionPlanning({finalMarkPlanning:true,scanPlanning:true});
  let node=p.openRoot();
  assert(native.lifecycle.restore(captured.get(node),{trustedFork:true,silent:true,inPlace:true,skipProjection:true}).ok);
  for(const [i,step] of r.actions.entries()){
   const action=node.legalActions.find(a=>a.actionId===step.a.actionId);
   assert(action,'missing action '+i+' '+step.a.summary+' '+JSON.stringify(node.legalActions.map(a=>a.summary)));
   assert.deepEqual(action.target,step.a.target);
   const previous=captured.get(node);
   assert(native.lifecycle.restore(previous,{trustedFork:true,silent:true,inPlace:true,skipProjection:true,
     trustedState:JSON.parse(previous.committedState)}).ok);
   const decision=native.inspect().session?.decision;
   const reference=(decision?.choices||native.inputPort.enumerateActions({})).find(a=>a.actionId===action.actionId);
   assert(reference);assert.deepEqual(action,reference);
   const opts={skipProjection:true,omitTrustedResult:true};
   const accepted=decision?native.inputPort.submitDecision({decisionId:decision.decisionId,decisionVersion:decision.decisionVersion,ownerId:decision.ownerId,choice:reference},opts)
     :reference.phase==='quick'?native.inputPort.submitQuickAction(reference,opts):native.inputPort.submitAction(reference,opts);
   assert(accepted.ok,accepted.message);
   node=p.expand(node,action.actionId);
   const e=captured.get(node);assert(e);
   if(i>=2){
    parity(e,native.lifecycle.save().envelope,i);
    const obs=p.valueObservation(node),hand=obs.selfState.hand;
    assert(hand.some(c=>c.hidden===true&&!c.id&&!c.cardId),i);
    assert(!hand.some(c=>c.id===r.fresh.id||c.cardId===r.fresh.cardId),i);
    assert(!JSON.stringify(node.legalActions).includes(r.fresh.id),i);
    path.push({value:evaluateStateValue(obs,seat).total,status:node.status,boundary:node.boundary,actions:node.legalActions.map(a=>a.actionId)});
   }
  }
  assert.equal(node.status,'information-barrier');
  assert.equal(node.boundary,'hidden_chong_fossil_offer');
  assert.equal(node.legalActions.length,0);
  assert.deepEqual(m.save(),r.before);
  witness.push({fresh:r.fresh.cardId,path,stats:p.getDiagnostics()});
 }finally{native.dispose();p.close();m.dispose();}
}
assert.deepEqual(witness[0].path,witness[1].path);
fs.writeFileSync(process.argv[4],JSON.stringify({witness,exactCommittedStateSessionRng:true,actionAndValueParityAcrossDraws:true},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(witness.map(w=>[w.fresh,w.path.length,w.path[0],w.path.at(-1),w.stats.submissionCount,w.stats.provedQuietSpecifiedScans,w.stats.provedAlienDisplays])));
