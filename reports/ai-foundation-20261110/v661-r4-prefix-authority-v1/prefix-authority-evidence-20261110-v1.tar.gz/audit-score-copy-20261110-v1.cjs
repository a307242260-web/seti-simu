'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),Module=require('node:module');
const original=Module._extensions['.js'],counts={};
globalThis.auditScoringCopy=(label,source,copy)=>{
 const canonical=structuredClone(source);
 assert.deepStrictEqual(copy,canonical,label);
 const seen=new Map(),reverse=new Map();
 function visit(a,b,input){
  if(!a||typeof a!=='object')return;
  assert.notEqual(b,input,label);
  if(seen.has(a)){assert.equal(seen.get(a),b,label);return;}
  assert(!reverse.has(b),label);
  seen.set(a,b);reverse.set(b,a);
  assert.deepEqual(Object.keys(a),Object.keys(b),label);
  for(const k of Object.keys(a))visit(a[k],b[k],input[k]);
 }
 visit(canonical,copy,source);
 counts[label]=(counts[label]||0)+1;
 return copy;
};
const edits={
 '/ai/analysis-port.js':[['    function previewFixedResearchSelection','    function prepareDecisionContinuation',['state']]],
 '/ai/local-decision-plans.js':[
  [' function knownFossilTraceQuotes',' function pinkScoreBeforeUnknownFossil',['state.finalScoring','state.aliens']],
  [' function previewIncomeCompletion',' function incomeCompletion',['state.finalScoring','state.aliens']],
 ],
};
Module._extensions['.js']=(mod,file)=>{
 const entry=Object.entries(edits).find(([path])=>file.endsWith(path));
 if(!entry)return original(mod,file);
 let src=fs.readFileSync(file,'utf8');
 for(const [start,end,args] of entry[1]){
  const i=src.indexOf(start),j=src.indexOf(end,i+start.length);
  assert(i>=0&&j>i);
  let range=src.slice(i,j);
  for(const arg of args){
   const before='copyForkData('+arg+')';
   assert.equal(range.split(before).length,2);
   range=range.replace(before,`globalThis.auditScoringCopy(${JSON.stringify(start.trim()+':'+arg)},${arg},${before})`);
  }
  src=src.slice(0,i)+range+src.slice(j);
 }
 mod._compile(src,file);
};
const [trace,...args]=process.argv.slice(2);
process.argv=[process.argv[0],trace,...args];
require(trace);
console.log(JSON.stringify({copyAudit:counts}));
