'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const load=f=>require(path.resolve('randomizer/game/ai',f));
const original=Module._extensions['.js'],snapshots=new Map(),edges=[],identities=new WeakMap(), facts=new Map();
let nextIdentity=0;
const hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
function stable(x){
 if(!x||typeof x!=='object')return x;
 if(Array.isArray(x))return x.map(stable);
 return Object.fromEntries(Object.keys(x).sort().map(k=>[k,stable(x[k])]));
}
globalThis.recordPrefixNode=(n,stored,identity,known,actionId,child,c)=> {
 function save(n,s,id,knowledge){
  if(snapshots.has(n))return snapshots.get(n);
  const e=s.envelope,scope=[n.status,n.boundary,s.intent,s.resourceControl,s.cardControl,knowledge,s.informationBarrier,
   n.legalActions.map(a=>[a.actionId,a.family,a.target,a.payload])];
  const native=JSON.parse(e.committedState);
  const fact=stable([native,e.session,scope]),idExact=hash(fact);
  if(!identities.has(id))identities.set(id,nextIdentity++);
  const classification={i:s.serial,id:identities.get(id),exact:idExact,status:n.status,boundary:n.boundary,
    version:native.meta.stateVersion,sessionId:e.session?.session.sessionId,decisionVersion:e.session?.session.revision};
  facts.set(s.serial,fact);snapshots.set(n,classification);return classification;
 }
 edges.push({parent:save(n,stored,identity,known),actionId,child:c&&save(child,c,null,null)});
};
Module._extensions['.js']=(mod,file)=>{
 if(!file.endsWith('/randomizer/game/ai/analysis-port.js'))return original(mod,file);
 const s=fs.readFileSync(file,'utf8'),mark='    function rememberPrefix(key,node,actionId,child){';
 assert.equal(s.split(mark).length,2);
 mod._compile(s.replace(mark,mark+`
      if(resourcePlanning){
        const s=nodes.get(node);
        globalThis.recordPrefixNode(node,s,s.identity,cardKnowledgeKey(s.envelope),actionId,child,null);
      }`),file);
};
const {open,seat}=require(process.argv[2]),{createAnalysisPort}=load('analysis-port'),{createSearchAgent}=load('search-agent');
const {checkpoint:root}=JSON.parse(fs.readFileSync(process.argv[3])),m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 const group=(by)=>{
  const d=new Map();
  for(const e of edges){
   const key=JSON.stringify([e.parent[by],e.actionId]);
   if(!d.has(key))d.set(key,new Map());
   d.get(key).set(e.parent.i,e);
  }
  const a=[...d.values()].filter(g=>g.size>1).map(g=>[...g.values()]);
  return {groups:a.length,excess:a.reduce((n,g)=>n+g.length-1,0),examples:a.slice(0,25),
   sizes:Object.fromEntries([...new Set(a.map(g=>g.length))].map(k=>[k,a.filter(g=>g.length===k).length]))};
 };
 function compare(left,right,at='',out=[]){
  if(Object.is(left,right)||out.length>=32)return out;
  if(left&&right&&typeof left==='object'&&typeof right==='object'){
   for(const key of new Set([...Object.keys(left),...Object.keys(right)])){
    if(out.length>=32)break;
    compare(left[key],right[key],at+'.'+key,out);
   }
  }else out.push(at);
  return out;
 }
 const report={parents:snapshots.size,edges:edges.length,exact:group('exact'),forward:group('id')};
 report.forward.differingFields=report.forward.examples.map(([a,b])=>({
  left:a.parent.i,right:b.parent.i,fields:compare(facts.get(a.parent.i),facts.get(b.parent.i)),
 }));
 fs.writeFileSync(process.argv[4],JSON.stringify(report,null,2)+'\n',{flag:'wx'});
 for(const [k,r] of Object.entries(report))console.log(k,typeof r==='object'?{groups:r.groups,excess:r.excess,sizes:r.sizes}:r);
}finally{port.close();m.dispose();}
