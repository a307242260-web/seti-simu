'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]);
const load=f=>require(path.resolve('randomizer/game/ai',f));
const {createAnalysisPort}=load('analysis-port'),V=load('state-value'),local=load('local-decision-plans');
const {draws}=JSON.parse(z.gunzipSync(fs.readFileSync(process.argv[3])));
const audit=[];
for(const row of draws){
 const m=open(row.before),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  port.setMovementPlanning(true);port.setResourcePlanning(true);port.setCardPickPlanning(true);
  port.setDecisionPlanning({finalMarkPlanning:true,scanPlanning:true});
  const replay=(n,entries)=>{
   for(const a of entries){assert(n.legalActions.some(x=>x.actionId===a.actionId));n=port.expand(n,a.actionId);}
   return n;
  };
  const income=replay(port.openRoot(),row.startInputs);
  const hidden=replay(income,row.checkpointsHeld.map(x=>x.a));
  assert.equal(hidden.status,'information-barrier');assert.equal(hidden.boundary,'hidden_chong_fossil_offer');
  assert.deepEqual(hidden.legalActions,[]);
  const obs=port.valueObservation(hidden),base=V.evaluateStateValue(obs,seat).total;
  assert(obs.selfState.hand.some(c=>c.hidden&&!c.id&&!c.cardId));
  assert(!obs.selfState.hand.some(c=>c.id===row.fresh.id||c.cardId===row.fresh.cardId));
  assert(row.outcomes.every(x=>!JSON.stringify(obs).includes(x.choice.target.fossilId)));
  const delta=port.quoteFossilIndependentTask(hidden).value;
  assert.equal(delta,8);assert.equal(base,214.5);
  assert.deepEqual(m.save(),row.before);
  const quick=[];
  for(const x of row.outcomes){
   m.restore(x.steps[0].checkpoint);
   const s=m.state(),known=new Set(m.player().reservedCards.map(c=>c.id)),ready=local.quoteReadyLandingTask({state:s,seatId:seat,knownCards:known});
   assert.equal(ready.value,8);
   const c=m.player().reservedCards.find(x=>x.cardId==='b_117.webp');
   assert.equal(local.quoteReadyLandingTask({state:s,seatId:seat,knownCards:new Set([...known].filter(id=>id!==c.id))}),null);
   const withoutMark={...s,finalScoring:{...s.finalScoring,tileVariants:{...s.finalScoring.tileVariants,c:2}}};
   assert.equal(local.quoteReadyLandingTask({state:withoutMark,seatId:seat,knownCards:known}),null);
   // Existing quote must disappear as soon as the task is consumed.
   const a=m.act('complete_task',a=>a.target.ruleId==='b117-orbit-land-count-task');
   assert.equal(local.quoteReadyLandingTask({state:m.state(),seatId:seat,knownCards:known}),null);
   const actual=V.evaluateStateValue(m.owner(seat),seat).total;
   assert.equal(actual,base+delta);
   assert.deepEqual(m.facts().wallet,x.end.facts.wallet);
   assert.equal(m.facts().final,x.end.facts.final);
   quick.push({id:x.choice.target.fossilId,action:a.actionId,actual,checkpoint:m.save()});
  }
  m.restore(row.before);assert.deepEqual(m.save(),row.before);
  const ordinary=replay(income,row.checkpointsPaid.map(x=>x.a));
  assert.equal(port.quoteFossilIndependentTask(ordinary),null);
  const paid=V.evaluateStateValue(port.valueObservation(ordinary),seat).total;
  assert.equal(paid,221.5);
  assert.deepEqual(m.save(),row.before);
  audit.push({fresh:row.fresh.cardId,base,delta,paid,masked:true,legalActions:0,quick});
 }finally{port.close();m.dispose();}
}
assert.equal(audit.length,2);
fs.writeFileSync(process.argv[4],z.gzipSync(JSON.stringify(audit)),{flag:'wx'});
console.log(JSON.stringify(audit.map(({quick,...r})=>({...r,quick:quick.map(({checkpoint,...x})=>x)}))));
