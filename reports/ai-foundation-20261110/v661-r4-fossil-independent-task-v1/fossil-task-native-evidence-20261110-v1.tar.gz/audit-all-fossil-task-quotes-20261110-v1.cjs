'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const js=Module._extensions['.js'],records=new Map();
globalThis.recordFossilTask=(node,envelope,quote,obs)=>records.set(node,{envelope,quote,obs});
Module._extensions['.js']=(mod,file)=>{
 if(!file.endsWith('/randomizer/game/ai/analysis-port.js'))return js(mod,file);
 const s=fs.readFileSync(file,'utf8'),marker='    function quoteFossilIndependentTask(node){';
 assert.equal(s.split(marker).length,2);
 mod._compile(s.replace(marker,`    function quoteFossilIndependentTask(node){
      const quote=quoteFossilIndependentTaskAudit(node);
      if(quote)globalThis.recordFossilTask(node,nodes.get(node).envelope,quote,valueObservation(node));
      return quote;
    }
    function quoteFossilIndependentTaskAudit(node){`),file);
};
const {open,seat}=require(process.argv[2]),load=f=>require(path.resolve('randomizer/game/ai',f));
const {createAnalysisPort}=load('analysis-port'),{createSearchAgent}=load('search-agent'),V=load('state-value');
const {checkpoint:root}=JSON.parse(fs.readFileSync(process.argv[3])),m=open(root);
const port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
const native=m.c.counterfactualPort.createFork(root,{branchKey:'audit-all-fossil-task-quotes',restoreRandomState:true}).composition;
const opts={skipProjection:true,omitTrustedResult:true};
const view=()=>native.projection({role:'player',playerId:seat}).state;
const verify=({envelope,node,quote,obs})=>{
 const base=V.evaluateStateValue(obs,seat),outcomes=[];
 assert.equal(node.legalActions.length,0);
 const restore=()=>assert(native.lifecycle.restore(envelope,{trustedFork:true,silent:true,inPlace:true,skipProjection:true,
   trustedState:JSON.parse(envelope.committedState)}).ok);
 restore();
 const choices=native.inspect().session.decision.choices;
 assert(choices.length);assert(choices.every(a=>a.target.fossilId&&a.actorId===seat));
 const snapshot=JSON.stringify(obs);
 for(const choice of choices){
  assert(!snapshot.includes(choice.target.fossilId));
  restore();
  const d=native.inspect().session.decision,a=d.choices.find(a=>a.actionId===choice.actionId);
  assert.deepEqual(a,choice);
  const accepted=native.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a},opts);
  assert(accepted.ok,accepted.message);assert.equal(native.inspect().phase,'idle');
  const pickup=V.evaluateStateValue(view(),seat);
  assert.deepEqual(pickup.components,base.components);
  const claim=native.inputPort.enumerateActions({}).find(a=>a.family==='complete_task'&&a.target.ruleId==='b117-orbit-land-count-task');
  assert(claim);
  const done=native.inputPort.submitQuickAction(claim,opts);
  assert(done.ok,done.message);assert.equal(native.inspect().phase,'idle');
  const after=V.evaluateStateValue(view(),seat);
  assert.equal(after.total-base.total,quote.value);
  assert.equal(after.components.realizedScore-base.components.realizedScore,3);
  assert.equal(after.components.currentEndGameBonus-base.components.currentEndGameBonus,4);
  assert.equal(after.components.resources-base.components.resources,1);
  outcomes.push({choice:a.actionId,delta:after.total-base.total});
 }
 return {base:base.total,quote:quote.value,outcomes};
};
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);
 const results=[...records].map(([node,r])=>verify({node,...r}));
 assert(results.length>0);
 assert.deepEqual(m.save(),root);
 const count=results.reduce((n,x)=>n+x.outcomes.length,0);
 fs.writeFileSync(process.argv[4],JSON.stringify({quotedLeaves:results.length,nativeContinuations:count,rootRestored:true,results},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({quotedLeaves:results.length,nativeContinuations:count}));
}finally{native.dispose();port.close();m.dispose();}
