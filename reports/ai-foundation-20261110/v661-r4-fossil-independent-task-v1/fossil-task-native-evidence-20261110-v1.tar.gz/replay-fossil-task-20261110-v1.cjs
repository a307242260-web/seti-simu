'use strict';
const fs=require('node:fs'),z=require('node:zlib'),assert=require('node:assert/strict'),path=require('node:path');
const {open,seat}=require(process.argv[2]),read=n=>JSON.parse(z.gunzipSync(fs.readFileSync(n)));
const V=require(path.resolve('randomizer/game/ai/state-value'));
const effects=require(path.resolve('randomizer/game/cards/effects'));
const witness=read(process.argv[3]),draws=read(process.argv[4]);
const held=witness.entries[0].steps,paid=witness.entries[2].steps,taskTail=paid.slice(-2);
const snapshot=(m)=>{const f=m.facts(),v=V.evaluateStateValue(m.owner(seat),seat);return {facts:f,value:v.total,parts:v.parts};};
const report=[];
for(const {before,fresh,actions} of draws.results){
 const m=open(before);
 try{
  const startInputs=actions.slice(0,3).map(x=>x.a);
  for(const a of startInputs)m.apply(a);
  const start=m.save();
  assert(m.player().hand.some(x=>x.id===fresh.id&&x.cardId===fresh.cardId));
  const run=(inputs)=>inputs.map(a=>({a:m.apply(a),checkpoint:m.save()}));
  const checkpointsPaid=run(paid.map(x=>x.a)),ordinary=snapshot(m);
  assert.equal(ordinary.facts.round,4);assert.equal(ordinary.facts.turn,9);
  m.restore(start);
  const checkpointsHeld=run(held.map(x=>x.a)),offer=m.save(),pending=snapshot(m),queue=offer.session.session.queue;
  assert.equal(queue.length,1);
  assert.equal(queue[0].payload.cardEffect.id,'chong-6-pickup');
  const player=m.player(),card=player.reservedCards.find(c=>c.cardId==='b_117.webp'),task=effects.getCardModel(card).tasks[0];
  assert(effects.taskConditionMet(task,player,{planets:m.state().planets,aliens:m.state().aliens}));
  assert(!card.cardEffectState.completedTaskIds.includes(task.id));
  const choices=m.menu();assert(choices.length>=2);assert(choices.every(a=>a.target.fossilId&&a.target.planetId==='saturn'));
  const outcomes=[];
  for(const choice of choices){
   m.restore(offer);
   const inputs=[choice,...taskTail.map(x=>x.a)],steps=run(inputs),end=snapshot(m);
   assert.equal(end.facts.turn,ordinary.facts.turn);
   assert.equal(end.facts.wallet.score,pending.facts.wallet.score+3);
   assert.equal(end.facts.wallet.credits,pending.facts.wallet.credits+1);
   assert.equal(end.facts.final,pending.facts.final+7);
   assert.equal(end.facts.taskCount,pending.facts.taskCount+1);
   m.restore(offer);
   for(const {a,checkpoint} of steps){m.apply(a);assert.deepEqual(m.save(),checkpoint);}
   m.restore(steps[0].checkpoint);
   const pickup=snapshot(m),s=m.state();
   assert.deepEqual(pickup.facts.wallet,pending.facts.wallet);
   assert.equal(pickup.facts.taskCount,pending.facts.taskCount);
   assert.equal(pickup.facts.final,pending.facts.final);
   assert.deepEqual(pickup.facts.hand,pending.facts.hand);
   assert.deepEqual(pickup.facts.rng,pending.facts.rng);
   assert(Object.values(s.aliens.chong.transportTasksByRocketId).some(t=>t.fossilId===choice.target.fossilId));
   outcomes.push({choice,steps,pickup,end});
  }
  m.restore(before);assert.deepEqual(m.save(),before);
  report.push({before,startInputs,start,fresh,checkpointsPaid,ordinary,checkpointsHeld,pending,outcomes});
 }finally{m.dispose();}
}
const scalar=(x)=>({wallet:x.facts.wallet,final:x.facts.final,value:x.value,task:x.facts.taskCount,rng:x.facts.rng});
assert.equal(report.length,2);
assert.deepEqual(scalar(report[0].ordinary),scalar(report[1].ordinary));
assert.deepEqual(scalar(report[0].pending),scalar(report[1].pending));
for(const r of report)for(const x of r.outcomes)assert.deepEqual(scalar(x.end),scalar(report[0].outcomes[0].end));
fs.writeFileSync(process.argv[5],z.gzipSync(JSON.stringify({draws:report,exactNativeReplay:true,rootRestored:true})),{flag:'wx'});
for(const r of report)console.log(JSON.stringify({draw:r.fresh.cardId,pending:scalar(r.pending),paid:scalar(r.ordinary),
 fossils:r.outcomes.map(x=>({id:x.choice.target.fossilId,pickup:scalar(x.pickup),end:scalar(x.end),probe:x.end.facts.probes.find(p=>p.fossilId===x.choice.target.fossilId)}))}));
