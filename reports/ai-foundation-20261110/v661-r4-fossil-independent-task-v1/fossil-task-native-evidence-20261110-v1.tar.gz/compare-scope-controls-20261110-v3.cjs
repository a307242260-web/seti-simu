'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),z=require('node:zlib'),{createHash}=require('node:crypto');
const {open,seat}=require('./native-compact-20261110-v1.cjs');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [mode,file,out]=process.argv.slice(2);
const data=JSON.parse(file.endsWith('.gz')?z.gunzipSync(fs.readFileSync(file)):fs.readFileSync(file));
const controls=mode==='r3'?data.rows.map(x=>({label:"r3-"+x.summary.i,root:x.root}))
 :[{label:mode,root:mode==='teacher272'?(data.rows?.[0]?.root||data.checkpoint):data.checkpoint}];
assert(controls.length);
const values=[];
for(const {label,root} of controls){
 const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
  const {analysis,rootAndSearchMilliseconds,...graph}=q;
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
  delete graph.diagnostics.milliseconds;
  const bytes=JSON.stringify(graph).replace(/seti-complete-decision-search-v43[567]/g,"seti-complete-decision-search-audited").replace(/seti-local-mark-and-scan-purpose-v13/g,"seti-local-mark-and-scan-purpose-v12");
  const {identityMaterializations,identityBucketCollisions,identitySliceHits,identitySliceStores}=analysis;
  values.push({label,action:q.actionId,value:q.value,native:q.diagnostics.nativeExecutions,graphNodes:q.diagnostics.graphNodes,ms:rootAndSearchMilliseconds,
   mainMenu:m.menu().map(a=>[a.actionId,a.family,a.summary]),roots:q.roots.map(r=>[r.actionId,r.value,r.realization,r.preparationDebt]),quietClaims:q.lines.flatMap(l=>l.quietClaimEquivalences||[]).length,digest:createHash('sha256').update(bytes).digest('hex'),bytes:Buffer.byteLength(bytes),
   identityMaterializations,identityBucketCollisions,identitySliceHits,identitySliceStores});
 }finally{port.close();m.dispose();}
}
fs.writeFileSync(out,JSON.stringify(values,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(values));
