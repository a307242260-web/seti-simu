'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{open,z,seat}=require('./native-late-r3');
const [src,out]=process.argv.slice(2),records=JSON.parse(z.gunzipSync(fs.readFileSync(src)));
const {evaluateStateValue}=require(path.resolve('randomizer/game/ai/state-value'));
const {sanitizeHiddenInformationObservation}=require(path.resolve('randomizer/game/rule-composition'));
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const verify=process.env.SETI_VERIFY_TRACE_PAIR==='1',m=open(records.root);
const knownSource=m.owner(seat),display=knownSource.publicState.board.aliens.amibaTraces.displayedCardIndex;
const rootKnown=new Set([...knownSource.selfState.hand,...knownSource.selfState.reservedCards,...knownSource.publicState.board.publicCards].filter(Boolean).map(c=>c.id));
const rows=[];let native=0;
function choice(n){return m.menu().find(a=>a.family==='choose_target'&&a.target.traceType==='pink'&&a.target.speciesId==='amiba'&&a.target.position===n);}
function take(c){native++;return m.apply(c);}
try{
 for(const [i,record] of records.records.entries()){
  if(record.follow!=='card_play_domain_effect:effect:chong_pickup_fossil')continue;
  m.restore(record.before);
  const p0=m.player(),s0=m.state(),stateDisplay=s0.aliens.amiba.displayedCardIndex;
  const isRootKnown=stateDisplay===display,legal=m.menu();
  const p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
  p.setCardPickPlanning(true);p.setMovementPlanning(true);p.setResourcePlanning(true);p.setDecisionPlanning({finalMarkPlanning:true,scanPlanning:true});
  const root=p.openRoot(),spec=p.localDecisionSpec(root);
  try{
   for(const n of [1,3]){
    if(!choice(n)||!choice(n+1))continue;
    const delta=[];const lowId=choice(n).actionId,highId=choice(n+1).actionId;
    for(const pos of [n,n+1]){
     m.restore(record.before);
     const before=m.player(),known=new Set(rootKnown),actions=[];
     for(const c of before.hand)if(c.cardId===`amiba_${display}.webp`)known.add(c.id);
     actions.push(take(choice(pos)));
     if(pos>=3){
      const pick=m.menu().find(a=>a.target.choiceId===`amiba:display:${stateDisplay}`);
      assert(pick);
      actions.push(take(pick));
      if(isRootKnown){const gained=m.player().hand.find(c=>!before.hand.some(o=>o.id===c.id));assert(gained);known.add(gained.id);}
     }
     const h=m.save().session.session.queue[0],f=m.facts(),observation=m.owner(seat);
     assert.equal(h.type,'card_play_domain_effect:decision:chong_pickup_fossil');
     assert(m.menu().every(a=>a.target?.fossilId));
     const masked=sanitizeHiddenInformationObservation(knownSource,observation,{code:'hidden_chong_fossil_offer'},known);
     const value=evaluateStateValue(masked,seat);
     delta.push({position:pos,value:value.total,parts:value.components,final:f.final,wallet:f.wallet,hand:f.hand,
      rng:f.rng,actions,menu:m.menu().map(a=>a.actionId),symbols:m.state().aliens.amiba.symbolSlots});
    }
    const [lo,hi]=delta;
    assert.equal(hi.value-lo.value,1);
    assert.equal(hi.final-lo.final,1);
    assert.deepEqual({...lo.wallet,score:hi.wallet.score},hi.wallet);
    assert.deepEqual({...lo.parts,realizedScore:hi.parts.realizedScore},hi.parts);
    for(const k of ['rng','hand','menu','symbols'])assert.deepEqual(hi[k],lo[k],k);
    if(verify){
     assert(spec?.excludedActionIds.includes(lowId));
     assert(spec.retainedActionIds.includes(highId));
    }
    rows.push({i,pair:[n,n+1],isRootKnown,sourceScore:p0.resources.score,old:lo,new:hi});
    m.restore(record.before);assert.deepEqual(m.save(),record.before);
   }
  }finally{p.close();}
 }
 m.restore(records.root);assert.deepEqual(m.save(),records.root);
 fs.writeFileSync(out,JSON.stringify({rows,native,rootAndRngExact:true},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({pairs:rows.length,native,knownDisplayPairs:rows.filter(r=>r.isRootKnown).length,counts:rows.reduce((o,r)=>(o[r.pair]=(o[r.pair]||0)+1,o),{})}));
}finally{m.dispose();}
