'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{open,z,seat}=require('./native-late-r3');
const [src,out]=process.argv.slice(2),d=JSON.parse(z.gunzipSync(fs.readFileSync(src)));
const {pinkScoreBeforeUnknownFossil:policy}=require(path.resolve('randomizer/game/ai/local-decision-plans'));
const {getAvailablePlanetFossils}=require(path.resolve('randomizer/game/aliens/chong'));
const m=open(d.root);
const trace=(a,n)=>a.target?.speciesId==='amiba'&&a.target.traceType==='pink'&&a.target.position===n;
try {
 const record=d.records.find(r=>{
  if(r.follow!=='card_play_domain_effect:effect:chong_pickup_fossil')return false;
  m.restore(r.before);return [1,2,3,4].every(n=>m.menu().some(a=>trace(a,n)));
 });
 assert(record);
 m.restore(record.before);const actions=m.menu(),state=m.state(),knownCards=new Set(m.player().reservedCards.map(c=>c.id));
 const base={state,seatId:seat,actions,knownCards,session:record.before.session.session,
  knownFossilIds:new Set(),knownAmibaDisplay:state.aliens.amiba.displayedCardIndex};
 const actual=policy(base),action=n=>actions.find(a=>trace(a,n)).actionId;
 assert.deepEqual(actual.excludedActionIds,[action(1),action(3)]);
 assert.deepEqual(policy({...base,knownAmibaDisplay:null}).excludedActionIds,[action(1)]);
 const planet=state.match.cardPlayContext.lastLanding.planetId;
 const fossil=getAvailablePlanetFossils(state.aliens,planet)[0];
 assert(fossil);
 assert.equal(policy({...base,knownFossilIds:new Set([fossil.fossilId])}),null);
 const edit=fn=>{const s=structuredClone(state);fn(s);return s;};
 assert.equal(policy({...base,state:edit(s=>{s.turn.passedPlayerIds=[];})}),null);
 assert.equal(policy({...base,state:edit(s=>{s.aliens.amiba.symbolSlots.red_1='symbol_4';})}),null);
 assert.equal(policy({...base,state:edit(s=>{for(const t of Object.values(s.finalScoring.tiles))t.marks=t.marks.filter(m=>m.playerId!==seat);})}),null);
 assert.equal(policy({...base,actions:actions.filter(a=>!trace(a,2)&&!trace(a,4))}),null);
 const session=structuredClone(base.session);session.queue.push({...session.queue[1]});
 assert.equal(policy({...base,session}),null);
 assert.deepEqual(m.save(),record.before);
 const proof={pruned:actual.proof,keptUnknownDisplayPair:true,rejectedKnownFossil:true,rejectedActiveOpponent:true,
  rejectedRedDraw:true,rejectedPendingMark:true,rejectedMissingHigher:true,rejectedAdditionalQueue:true,rootExact:true};
 fs.writeFileSync(out,JSON.stringify(proof,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(proof));
}finally{m.dispose();}
