'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {gzipSync}=require('node:zlib');
const [file,out]=process.argv.slice(2),src=path.resolve('randomizer/game/ai/analysis-port.js'),source=fs.readFileSync(src,'utf8'),mod=new Module(src,module);
mod.filename=src;mod.paths=Module._nodeModulePaths(path.dirname(src));Module._cache[src]=mod;
const at='      loadedEnvelope = null;\n      const executeAt = now();';
assert.equal(source.split(at).length,2);
mod._compile(source.replace(at,'      globalThis.capturePinkPair(current,session,loadedEnvelope);\n'+at),src);mod.loaded=true;
const {open}=require('./native-late-r3'),root=JSON.parse(fs.readFileSync(file)).checkpoint,m=open(root),records=new Map();
globalThis.capturePinkPair=(a,s,envelope)=>{
 if(!envelope||s?.queue?.[0]?.type!=='science_domain_alien_trace'||a.target.traceType!=='pink'||a.target.speciesId!=='amiba'
  ||![1,3].includes(a.target.position))return;
 const h=s.queue[0],follow=s.queue[1]?.type??null,actions=s.journal.actions,origin=actions[0]?.action;
 const stateKey=crypto.createHash('sha256').update(JSON.stringify([s.workingState,s.queue.map(x=>[x.type,x.payload]),s.irreversibleBarrier,origin?.target])).digest('hex');
 if(!records.has(stateKey))records.set(stateKey,{before:envelope,follow,origin:origin?.family,low:[a.target.position]});
 else records.get(stateKey).low.push(a.target.position);
};
try{
 const r=m.automatic();assert.equal(r.n,1317);assert(r.complete);assert.deepEqual(m.save(),root);
 fs.writeFileSync(out,gzipSync(JSON.stringify({root,records:[...records.values()],native:r.n})+'\n'),{flag:'wx'});
 const groups={};for(const e of records.values())groups[e.follow]=(groups[e.follow]||0)+1;
 console.log(JSON.stringify({native:r.n,menus:records.size,groups}));
}finally{m.dispose();}
