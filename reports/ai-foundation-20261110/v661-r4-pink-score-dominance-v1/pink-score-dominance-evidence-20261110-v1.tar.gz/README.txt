From the repository root, using the source of this report:
SETI_VERIFY_TRACE_PAIR=1 node <archive-dir>/replay-pink-pairs-20261110-v1.cjs <archive-dir>/native-pink-fossil-roots-20261110-v1.json.gz /private/tmp/seti-pink-pair-results.json
node <archive-dir>/verify-pink-guards-20261110-v1.cjs <archive-dir>/native-pink-fossil-roots-20261110-v1.json.gz /private/tmp/seti-pink-pair-guards.json
Output paths must not exist. Omitting SETI_VERIFY_TRACE_PAIR permits the same independent Native replay with the v431 source. Capture instrumentation was run on v431 and retained 128 distinct menu states, of which 57 belong to this specific hidden-fossil continuation.
