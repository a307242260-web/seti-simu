Apply the report's candidate patch in an isolated checkout of `1dea78e45`.
Run with Node 22 from the candidate source root. Set `evidence_dir` to the
absolute path containing the unarchived files and `replay_dir` to a new output
directory.

```sh
cd "$evidence_dir"
# Find these three starting checkpoints and two continuation witnesses in the archive.
ls common-orange1-native-20261110-v1.json.gz ranked-landing-native-20261110-v1.json.gz orange-first-held-enceladus-20261110-v1.json.gz
cd "$OLDPWD"
native="$evidence_dir/native-compact-20261110-v1.cjs"
node "$evidence_dir/audit-held-travel-20261110-v1.cjs" "$native" "$evidence_dir/ranked-landing-native-20261110-v1.json.gz" "$evidence_dir/common-orange1-native-20261110-v1.json.gz" "$evidence_dir/orange-first-held-enceladus-20261110-v1.json.gz" "$replay_dir/value.json" candidate
node "$evidence_dir/audit-held-travel-execution-20261110-v1.cjs" "$native" "$evidence_dir/common-orange1-native-20261110-v1.json.gz" "$evidence_dir/search-reverse-funded-root-0-20261110-v1.json.gz" "$evidence_dir/search-reverse-funded-root-1-20261110-v1.json.gz" "$replay_dir/execution.json.gz"
node "$evidence_dir/audit-paired-pass-20261110-v1.cjs" "$native" "$evidence_dir/common-free-analysis-native-20261110-v1.json.gz" "$evidence_dir/scan-surplus-native-20261110-v1.json.gz" "$replay_dir/pass.json.gz"
```

To regenerate the two decision graphs, use the bundled
`trace-satellite-graph-20261110-v1.cjs` with the Native helper, either
`reverse-funded-root-[0-1]-20261110-v1.json`, and a new `.json.gz` path.
