'use strict';
const fs=require('node:fs'),z=require('node:zlib'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),read=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const {rows}=read(process.argv[3]),{result}=read(process.argv[4]),m=open(rows[0].after.checkpoint);
const records=[];
const apply=(steps,...args)=>{const a=m.act(...args);steps.push({a,checkpoint:m.save()});};
function run(label,from,ids,score){
 m.restore(from);const steps=[];
 if(label.startsWith('orange')){
  assert(m.menu().every(a=>a.family==='pass'||a.target?.tradeId==='publicity-for-card'));
  for(const id of ids){
   apply(steps,'quick_trade',a=>a.target.tradeId==='publicity-for-card');
   const pick=m.menu().find(a=>a.family==='choose_card'&&a.target.cardInstanceId===id);assert(pick);
   steps.push({a:m.apply(pick),checkpoint:m.save()});
   apply(steps,'card_corner',a=>a.target.cardInstanceId===id&&a.payload.kind==='resource');
   assert(m.menu().every(a=>a.family==='pass'||a.target?.tradeId==='publicity-for-card'));
  }
 }
 apply(steps,'pass');
 assert(m.state().turn.gameEnded);assert(!m.save().session);
 const white=m.owner(seat).publicState.players.find(p=>p.playerId===seat);
 assert.equal(white.finalScore,score);
 m.restore(from);for(const {a,checkpoint} of steps){m.apply(a);assert.deepEqual(m.save(),checkpoint);}
 records.push({label,ids,score,steps});
}
try{
 const paths=[[],['card-74-0','card-75-0'],['card-75-0','card-74-0']];
 for(const r of rows.filter(x=>x.first==='orange3'))for(const ids of paths)run('orange:'+r.mode+':'+r.fossil,r.after.checkpoint,ids,241);
 for(const r of result)run('scan:'+r.mode+':'+r.fossil,r.end.checkpoint,[],r.mode==='card'?251:248);
 fs.writeFileSync(process.argv[5],z.gzipSync(JSON.stringify(records)),{flag:'wx'});
 console.log(JSON.stringify(records.map(r=>[r.label,r.ids.length,r.score])));
}finally{m.dispose();}
