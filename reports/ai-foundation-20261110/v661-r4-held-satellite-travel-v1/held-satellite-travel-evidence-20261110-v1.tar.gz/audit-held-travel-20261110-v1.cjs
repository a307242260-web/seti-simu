'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),read=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const load=f=>require(path.resolve('randomizer/game',f));
const probe=load('ai/probe-capital'),V=load('ai/state-value'),{sanitizeHiddenInformationObservation}=load('rule-composition');
const {root}=read(process.argv[3]),{replays}=read(process.argv[4]),{results}=read(process.argv[5]),m=open(root),original=m.owner(seat);
const known=new Set([...original.selfState.hand,...original.selfState.reservedCards,...original.publicState.board.publicCards].filter(Boolean).map(c=>c.id));
const proofs=[],needsQuote=process.argv[7]==='candidate';
function inspect(){
 const obs=sanitizeHiddenInformationObservation(original,m.owner(seat),{code:'hidden_card_reveal'},known);
 const val=V.evaluateStateValue(obs,seat),facts=probe.factsFromObservation(obs,seat),input={...facts,initialInvestmentCapital:0,investment:()=>0};
 const quote=probe.quote(input,V.DEFAULT_WEIGHTS);
 assert.equal(probe.quoteFinalRoundValue(input,V.DEFAULT_WEIGHTS),quote.value);
 const formal=probe.factsFromState(m.state(),m.player()),f={...formal,initialInvestmentCapital:0,investment:()=>0};
 assert.equal(probe.quoteFinalRoundValue(f,V.DEFAULT_WEIGHTS),quote.value);
 return {val,quote,input};
}
try{
 for(const row of replays.filter(r=>r.from==='orange3-ranked')){
  const source=row.third.checkpoint;m.restore(source);
  const before=inspect(),q=before.quote.selected;
  const forkProof=probe.prepareFinalRoundSwapMission(m.state(),m.player());
  assert.equal(forkProof.quote(before.input.hand,before.input.board.publicCards),before.quote.value);
  if(needsQuote){
   assert.equal(q?.id,'8:land:saturn:enceladus:card:alien-chong-6-16');
   assert.equal(q.payment.exchangeCardIds.length,2);assert.equal(q.payment.spend.credits,row.third.facts.wallet.credits);
   const used=[...q.payment.exchangeCardIds,...q.payment.cornerCardIds,q.knownLandingCardId];
   assert.equal(new Set(used).size,used.length);
   const noCredit={...before.input,player:{...before.input.player,credits:0}};
   const hidden={...before.input,hand:before.input.hand.map(c=>c.id===q.knownLandingCardId?{hidden:true}:c)};
   const obscuredPair={...before.input,hand:before.input.hand.map(c=>c.id===q.payment.exchangeCardIds[0]?{hidden:true}:c)};
   for(const c of [noCredit,hidden,obscuredPair])assert(!probe.quote(c,V.DEFAULT_WEIGHTS).selected?.knownLandingCardId);
   const capped=probe.quote({...before.input,player:{...before.input.player,publicity:9}},V.DEFAULT_WEIGHTS).selected;
   assert.equal(capped.ledger.find(x=>x.type==='known-travel-arrival').gain.publicity,1);
  }else assert.equal(q,null);
  const ends=[];
  for(const w of results.filter(r=>r.mode===row.mode)){
   m.restore(source);
   for(const {a,checkpoint} of w.steps){m.apply(a);assert.deepEqual(m.save(),checkpoint);}
   const actual=inspect().val;
   assert.equal(actual.total,240);assert.equal(actual.components.probePotential,0);
   if(needsQuote){
    assert.equal(before.val.total,actual.total);
    assert.equal(q.value,actual.total-(before.val.total-before.val.components.probePotential));
   }
   ends.push({fossil:w.fossil,nativeActions:w.steps.length,value:actual.total,facts:m.facts()});
  }
  m.restore(source);assert.deepEqual(m.save(),source);
  proofs.push({mode:row.mode,sourceValue:before.val.total,mission:before.quote.value,selected:q,ends});
 }
 m.restore(root);assert.deepEqual(m.save(),root);
 fs.writeFileSync(process.argv[6],JSON.stringify({proofs,rootRestored:true},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(proofs.map(x=>({mode:x.mode,V:x.sourceValue,mission:x.mission,payment:x.selected?.payment,ledger:x.selected?.ledger}))));
}finally{m.dispose();}
