'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const [root,out]=process.argv.slice(2),file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));Module._cache[file]=mod;
const at='      if(pinkRefill){',source=fs.readFileSync(file,'utf8');
assert.equal(source.split(at).length,2);
mod._compile(source.replace(at,at+'\n        globalThis.captureFossil(stored.envelope,requested,pinkRefill);'),file);mod.loaded=true;
const {open}=require('./native-late-r3'),checkpoint=JSON.parse(fs.readFileSync(root)).checkpoint,m=open(checkpoint),rows=[];
globalThis.captureFossil=(before,action,prepared)=>rows.push({before,action,prepared});
try{
 const q=m.automatic();assert(q.complete);assert.deepEqual(m.save(),checkpoint);
 const data={native:q.n,roots:q.roots,rows};fs.writeFileSync(out,z.gzipSync(JSON.stringify(data)+'\n'));
 console.log(JSON.stringify({native:q.n,rows:rows.length}));
}finally{m.dispose();}
