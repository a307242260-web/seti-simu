'use strict';
const {open,read,z}=require('./native-late-r3');
const fs=require('node:fs'),assert=require('node:assert/strict');
const [root,source,out]=process.argv.slice(2),data=JSON.parse(z.gunzipSync(fs.readFileSync(source)));
const cp=read(root).checkpoint,model=open(cp);
const trusted=model.c.counterfactualPort.createFork(cp,{branchKey:'pink-fossil-audit',restoreRandomState:true});
const c=trusted.composition||trusted;
const count={};
function firstDiff(a,b,key='snapshot'){
 if(Object.is(a,b))return;
 if(!a||!b||typeof a!=='object'||typeof b!=='object')return {key,a,b};
 for(const k of new Set([...Object.keys(a),...Object.keys(b)])){
  if(Object.hasOwn(a,k)!==Object.hasOwn(b,k))return {key:key+'.'+k,a:a[k],b:b[k]};
  const p=firstDiff(a[k],b[k],key+'.'+k);if(p)return p;
 }
}
try{
 for(const [i,{before,action,prepared}] of data.rows.entries()){
  assert(c.lifecycle.restore(before,{trustedFork:true,inPlace:true,skipProjection:true}).ok);
  const decision=c.inspect().session?.decision,choice=decision.choices.find(x=>x.actionId===action.actionId);
  assert(choice);assert.deepEqual(choice,action);
  const result=c.inputPort.submitDecision({decisionId:decision.decisionId,decisionVersion:decision.decisionVersion,ownerId:decision.ownerId,choice},{skipProjection:true});
  assert(result.ok);
  const expected=c.lifecycle.save({trustedFork:true}).envelope;
  const a={...expected,committedState:JSON.parse(expected.committedState)},b={...prepared.envelope,committedState:JSON.parse(prepared.envelope.committedState)};
  const diff=firstDiff(a,b);
  assert(!diff,JSON.stringify({i,action:action.target,diff}).slice(0,1400));
  assert.equal(expected.session,null);
  assert.deepEqual(result.irreversibleBarrier,prepared.barrier);
  const key=action.target.stateExtra?'extra':'chong:'+action.target.position;
  count[key]=(count[key]||0)+1;
 }
 assert.deepEqual(model.save(),cp);
}finally{c.dispose();model.dispose();}
const result={native:data.native,exact:data.rows.length,count};fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
