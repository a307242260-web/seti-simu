'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),a=readZ(src),r=a.rows[0],m=open(a.root),anchors={};
try{
 for(const [i,{action}] of r.actions.entries()){
  if([37,39,43,44,54,58,61,62,65].includes(i))anchors[i]={e:m.save(),before:short(m),menu:m.menu(),original:action};
  m.apply(action);
 }
 assert.deepEqual(m.save(),r.end);
}finally{m.dispose();}
const ch=(h,id)=>h.act('choose_target',a=>a.target.choiceId===id);
const end=h=>h.act('end_turn');
const put=(h,slot=null)=>{h.act('place_data');h.act('choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');};
function selectBlue(h,pos=4){
 h.act('analyze');ch(h,pos===0?'trace:1:blue:state-extra':'trace:1:blue:amiba:'+pos);
 if(h.m.menu().some(a=>a.target.source==='display'))h.act('choose_card',a=>a.target.source==='display');
 h.cut('analyzed');
}
function buyCredit(h,ids){
 h.act('quick_trade',a=>a.target.tradeId==='cards-for-credit');
 for(const id of ids){
  const c=h.m.player().hand.find(x=>x.cardId===id);assert(c,id);
  h.act('choose_payment',a=>a.target.cardInstanceId===c.id||a.summary===id);
 }
 h.act('choose_payment',a=>a.summary.includes('确认弃牌'));
}
function originalScan(h){
 h.act('scan');
 h.act('choose_target',a=>a.target.nebulaId===r.actions[59].action.target.nebulaId);
 h.act('choose_card',a=>a.target.choiceId===r.actions[60].action.target.choiceId);
 h.cut('matched-scan');
}
function earlyFill(h,pos){
 while(h.m.facts().computer.length<6)put(h);
 if(h.m.player().mainActionCompleted)end(h);
 selectBlue(h,pos);
}
const variants={
 54:[['analysis-blue4',h=>selectBlue(h,4)],
     ['analysis-blue4-then-funded',h=>{selectBlue(h,4);end(h);buyCredit(h,['dlc_32.png','dlc_24.png']);h.cut('funded');}],
     ['analysis-blue4-same-payment-and-scan',h=>{selectBlue(h,4);end(h);buyCredit(h,['dlc_32.png','dlc_24.png']);originalScan(h);}],
     ['analysis-blue4-keep-dlc32',h=>{selectBlue(h,4);end(h);buyCredit(h,['amiba_9.webp','dlc_24.png']);originalScan(h);}],
     ['analysis-blue3-same-payment-and-scan',h=>{selectBlue(h,3);end(h);buyCredit(h,['dlc_32.png','dlc_24.png']);originalScan(h);}],
     ['analysis-blue2-same-payment-and-scan',h=>{selectBlue(h,2);end(h);buyCredit(h,['dlc_32.png','dlc_24.png']);originalScan(h);}]],
 37:[['fill-before-blue4',h=>earlyFill(h,4)],['fill-before-blue4-via-blue2',h=>earlyFill(h,2)]],
 39:[['fill-after-blue4',h=>earlyFill(h,4)],['fill-after-blue4-via-blue2',h=>earlyFill(h,2)]],
 44:[['skip-blue3-retain-amiba0',h=>earlyFill(h,4)],['skip-blue3-analysis-blue2',h=>earlyFill(h,2)]],
};
const cases={};
for(const [k,list] of Object.entries(variants))cases[k]=runCases(anchors[k].e,list);
writeZ(out,{anchors,cases});
