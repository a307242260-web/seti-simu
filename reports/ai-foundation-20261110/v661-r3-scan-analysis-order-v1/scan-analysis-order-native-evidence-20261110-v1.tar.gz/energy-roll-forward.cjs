'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [original,reversed,out]=process.argv.slice(2),x=readZ(original),y=readZ(reversed);
const id='player-white',rows={};
const get=label=>y.cases[54].rows.find(r=>r.label===label).settled.state;
for(const [key,e] of [
 ['original-amiba9',x.rows[0].settled.state],
 ['reverse-ai-dlc24',get('analysis-blue4')],
 ['reverse-fixed-amiba9',get('analysis-blue4-same-payment-and-scan')],
 ['reverse-fixed-dlc32',get('analysis-blue4-keep-dlc32')],
 ['early-keep-amiba0',y.cases[44].rows.find(r=>r.label==='skip-blue3-retain-amiba0').settled.state],
]){
 const m=open(e),actions=[],checkpoints=[];
 try{
  const take=action=>actions.push({action,method:'fixed'});
  const other=()=>{const list=[];m.advanceOpponents(list);list.forEach(action=>actions.push({action,method:'passive'}));};
  take(m.act('pass'));take(m.act('choose_card',q=>q.target.cardId==='b_111.webp'));other();
  assert.equal(m.facts().round,4);assert(!m.save().session);
  const opening=m.save(),openingSummary=short(m),startTurn=openingSummary.turn;
  let cache=null,stop=null,observedTurn=startTurn;
  for(let i=0;i<120;i++){
   if(m.menu()[0]?.actorId!==id){other();continue;}
   const summary=short(m);
   if(!m.save().session&&summary.turn>observedTurn){
    checkpoints.push({state:m.save(),summary});
    observedTurn=summary.turn;
    if(checkpoints.length===2){stop='two-turns';break;}
   }
   const q=m.automatic(cache);
   if(!q.complete||q.n>256||q.ms>600){stop={kind:'gate',action:q.a,n:q.n,ms:q.ms};break;}
   cache=q.checkpoint;
   const action=m.apply(q.a);actions.push({action,method:'autonomous',n:q.n,ms:q.ms,value:q.value});
   if(action.family==='pass'){stop='autonomous-pass';break;}
  }
  assert(stop);
  const end=m.save();m.restore(e);actions.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),end);
  rows[key]={e,actions,opening,openingSummary,checkpoints,end,stop};
  console.log(key,JSON.stringify(stop),JSON.stringify(checkpoints.map(x=>x.summary)));
 }finally{m.dispose();}
}
writeZ(out,rows);
