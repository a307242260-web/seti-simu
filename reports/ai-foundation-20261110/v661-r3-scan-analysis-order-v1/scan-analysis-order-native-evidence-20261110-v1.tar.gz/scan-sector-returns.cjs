'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),rows={};
function make(k,label){
 const r=d.cases[k].rows.find(x=>x.label===label),m=open(r.start),a=[];
 const act=(f,p)=>{const x=m.act(f,p);a.push(x);return x;};
 try{
  if(k!==54){
   act('quick_trade',q=>q.target.tradeId==='publicity-for-card');
   a.push(m.pick('dlc_32.png'));
   if(k===37){
    for(const s of [null,1]){act('place_data');act('choose_target',q=>s?q.target.blueSlot===s:q.target.target==='computer');}
   }
   act('end_turn');
   act('quick_trade',q=>q.target.tradeId==='cards-for-credit');
   for(const id of ['amiba_0.webp','amiba_9.webp'])act('choose_payment',q=>q.summary===id);
   act('choose_payment',q=>q.summary.includes('确认弃牌'));
  }
  const ready=m.save(),opening=short(m);
  assert.deepEqual(opening.wallet.slice(1,3),[1,2]);
  const scan=act('scan'),post=m.save(),main=m.menu(),results=[];
  for(const first of main){
   m.restore(post);m.apply(first);const after=m.save();
   for(const second of m.menu().filter(q=>q.target.nebulaId)){
    m.restore(after);m.apply(second);const f=short(m),menu=m.menu();
    results.push({first,second,f,menu,end:m.save()});
   }
  }
  for(const r of results){
   m.restore(ready);[scan,r.first,r.second].forEach(m.apply);assert.deepEqual(m.save(),r.end);
  }
  console.log(k,opening.wallet,results.length,results.map(r=>[r.first.summary,r.second.summary,r.f.wallet.slice(0,5),r.menu.filter(a=>a.target.choiceId?.startsWith('trace:')).map(a=>a.summary)]));
  rows[k]={origin:r.start,pre:a.slice(0,-1),ready,scan,opening,results};
 }finally{m.dispose();}
}
for(const [k,l] of [[54,'analysis-blue4-then-funded'],[39,'fill-after-blue4'],[37,'fill-before-blue4']])make(k,l);
writeZ(out,rows);
