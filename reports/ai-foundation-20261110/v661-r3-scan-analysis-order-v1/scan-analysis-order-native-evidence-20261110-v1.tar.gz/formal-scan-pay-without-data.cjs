'use strict';
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),root=readZ(src).root;
const choices=[
 ['3-publicity-buy-dlc25',h=>{
  h.act('quick_trade',a=>a.target.tradeId==='publicity-for-card');
  h.take(h.m.pick('dlc_25.png'));h.act('end_turn');
 }],
 ['swap-b16-for-dlc25',h=>{h.take(...h.m.swap('b_16.webp','dlc_25.png'));h.act('end_turn');}],
 ['swap-amiba9-for-dlc25',h=>{h.take(...h.m.swap('amiba_9.webp','dlc_25.png'));h.act('end_turn');}],
];
writeZ(out,{root,...runCases(root,choices)});
