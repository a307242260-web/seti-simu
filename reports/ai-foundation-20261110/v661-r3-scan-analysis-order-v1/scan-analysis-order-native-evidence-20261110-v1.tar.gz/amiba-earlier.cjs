'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),r=d.rows[0],m=open(d.root),rows={};
let e,menu;
try{
 for(const {action:a} of r.actions.slice(0,27))m.apply(a);
 e=m.save();
 m.play('amiba_3.webp');menu=m.menu().filter(a=>a.target.choiceId?.startsWith('trace:'));
}finally{m.dispose();}
const cases=[
 ['play-amiba0',h=>{h.take(h.m.play('amiba_0.webp'));h.cut('amiba0');}],
 ...menu.map(a=>[a.summary,h=>{h.take(h.m.play('amiba_3.webp'));h.take(h.m.apply(a));h.cut('removed');}]),
];
writeZ(out,{root:e,...runCases(e,cases)});
