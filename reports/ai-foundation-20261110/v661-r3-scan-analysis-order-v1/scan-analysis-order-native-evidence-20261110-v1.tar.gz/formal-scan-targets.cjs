'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),root=d.rows?.[211]?.e||d.root,m=open(root),rows=[];
try{
 const scan=m.act('scan'),post=m.save(),firsts=m.menu();
 for(const first of firsts){
  m.restore(post);m.apply(first);const s=m.save();
  const all=m.menu();
  for(const second of all){
   m.restore(s);m.apply(second);rows.push({scan,first,second,state:m.save(),summary:short(m),menu:m.menu()});
  }
 }
 for(const r of rows){
  m.restore(root);[r.scan,r.first,r.second].forEach(m.apply);assert.deepEqual(m.save(),r.state);
 }
 console.log('pair summaries',rows.map(r=>[r.first.summary,r.second.summary,r.summary.wallet,r.menu.map(x=>x.summary).slice(0,3)]));
}finally{m.dispose();}
const useful=rows.filter(r=>r.menu.some(a=>a.target.choiceId?.startsWith('trace:')));
const all=runCases(root,useful.map((r,i)=>['pair-'+i,h=>{for(const a of [r.scan,r.first,r.second])h.take(h.m.apply(a));h.cut('scan-trace');}]));
writeZ(out,{root,rows,all});
