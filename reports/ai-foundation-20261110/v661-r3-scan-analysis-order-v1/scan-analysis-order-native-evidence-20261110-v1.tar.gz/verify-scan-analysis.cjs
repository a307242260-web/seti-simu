'use strict';
const path=require('node:path'),assert=require('node:assert/strict'),{open,readZ,short}=require('./controlled-r3');
const src=process.argv[2]||__dirname;
const load=name=>readZ(path.join(src,name+'-20261110-v1.json.gz'));
const metrics={replays:0,inputs:0,autonomous:0,maxNative:0,maxMs:0,pairs:0};
const valid=u=>{
 assert(Number.isFinite(u.n)&&u.n>=0&&u.n<=256);
 assert(Number.isFinite(u.ms)&&u.ms>=0&&u.ms<=600);
 metrics.autonomous++;
 metrics.maxNative=Math.max(metrics.maxNative,u.n);
 metrics.maxMs=Math.max(metrics.maxMs,u.ms);
};
function replay(start,actions,end,settled){
 const m=open(start);
 try{
  let matched=false;
  for(const u of actions){
   const a=u.action||u;
   if(u.n!==undefined)valid(u);
   if(settled&&a.family==='pass'&&a.actorId==='player-white'&&m.facts().round===3){
    assert.deepEqual(m.save(),settled.state||settled.e);matched=true;
   }
   m.apply(a);metrics.inputs++;
  }
  assert.deepEqual(m.save(),end);
  if(settled)assert(matched);
  metrics.replays++;
 }finally{m.dispose();}
}
function stage(root,group){
 for(const r of group.rows){
  replay(root,r.prefix,r.start);replay(r.start,r.actions,r.end,r.settled);
 }
 for(const r of group.failures)replay(root,r.prefix,r.checkpoint);
}
const flip=load('energy-reverse-scan'),sector=load('energy-scan-sector-returns'),formal=load('formal-scan-targets');
const earlier=load('energy-earlier-amiba'),funded=load('energy-amiba0-funded-scan'),hidden=load('energy-amiba0-hidden');
const retain=load('energy-amiba0-retain-data'),matched=load('energy-amiba0-matched-analysis'),roots=load('energy-amiba0-roots');
const formalSkip=load('formal-keep-scan-supplier'),formalPay=load('formal-scan-pay-without-data');
const forward=load('energy-amiba-roll-forward'),reverse=load('energy-reverse-roll-forward'),tech=load('energy-amiba0-tech-alternatives');
const score=s=>[s.wallet[0],s.established];
for(const [i,group] of Object.entries(flip.cases))stage(flip.anchors[i].e,group);
for(const d of Object.values(sector)){
 replay(d.origin,d.pre,d.ready);assert.equal(d.results.length,18);
 for(const r of d.results){
  replay(d.ready,[d.scan,r.first,r.second],r.end);metrics.pairs++;
  assert.equal(r.f.wallet[4]-d.opening.wallet[4],2);
  assert(!r.menu.some(a=>a.target.choiceId?.startsWith('trace:')));
 }
}
assert.equal(formal.rows.length,18);
for(const r of formal.rows){replay(formal.root,[r.scan,r.first,r.second],r.state);metrics.pairs++;}
assert.equal(formal.rows.filter(r=>r.menu.some(a=>a.target.choiceId?.startsWith('trace:'))).length,2);
stage(formal.root,formal.all);stage(formalSkip.root,formalSkip);stage(formalPay.root,formalPay);
const [paid,swapB16,swapA9]=formalPay.rows;
assert.equal(paid.stop.kind,'gate');assert.equal(paid.stop.n,324);
assert.equal(paid.actions.length,0);assert.deepEqual(paid.start,paid.end);
for(const r of [swapB16,swapA9])assert.deepEqual(score(r.settled.summary),[110,156]);
assert.deepEqual(score(formalSkip.rows[0].settled.summary),[110,156]);
assert.deepEqual(formalSkip.rows[0].settled.summary,formalSkip.rows[1].settled.summary);stage(earlier.root,earlier);stage(funded.root,funded);stage(tech.root,tech);
for(const r of Object.values(hidden)){
 replay(r.e,r.steps,r.end,r.settled);
 const o=hidden.original;
 assert.deepEqual(r.obs,o.obs);assert.deepEqual(r.menu,o.menu);assert.deepEqual(r.q.roots,o.q.roots);
 assert.deepEqual([r.q.n,r.q.a,r.q.value],[o.q.n,o.q.a,o.q.value]);
 valid(r.q);assert.deepEqual(score(r.settled.s),[106,135]);
}
for(const r of Object.values(roots)){
 const m=open(r.e);
 try{assert.deepEqual(m.menu(),r.menu);assert.deepEqual(m.owner('player-white'),r.obs);}finally{m.dispose();}
 valid(r.q);
}
for(const [k,r] of Object.entries({...reverse,...forward})){
 replay(r.e,r.actions,r.end);
 if(k==='income108-scan-twice'){
  assert.equal(r.stop.n,440);assert.equal(r.stop.kind,'gate');assert.deepEqual(r.end,r.opening);
 }else assert.equal(r.stop,'two-turns');
}
replay(retain.start,retain.atScan,retain.common);
for(const r of Object.values(retain.cases)){
 replay(retain.common,r.prepare,r.e);replay(r.e,r.actions,r.end);valid(r.r3q);
}
replay(matched.e,matched.actions,matched.end);valid(matched.qR4);
assert.deepEqual(score(matched.checkpoints[0].summary),[110,139]);
assert.deepEqual(score(forward['income106-keep-three'].checkpoints[1].summary),[128,176]);
assert.deepEqual(score(flip.cases[54].rows.find(r=>r.label==='analysis-blue4-same-payment-and-scan').settled.summary),[103,132]);
assert.deepEqual(score(reverse['original-amiba9'].checkpoints[1].summary),[125,162]);
assert.deepEqual(score(tech.rows.find(r=>r.label==='tech:orange3').settled.summary),[100,129]);
assert.deepEqual(Object.values(retain.cases).map(r=>score(r.checkpoints[1].summary)),[[119,156],[110,150],[119,156],[119,156]]);
console.log(JSON.stringify(metrics));
