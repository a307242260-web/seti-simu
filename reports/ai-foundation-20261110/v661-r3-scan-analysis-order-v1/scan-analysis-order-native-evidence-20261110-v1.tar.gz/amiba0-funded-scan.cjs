'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),base=d.rows.find(r=>r.label==='play-amiba0'),m=open(base.start);
let e,legal,orig;
try{
 for(const {action:a} of base.actions.slice(0,22))m.apply(a);
 e=m.save();orig=short(m);legal=m.menu();
}finally{m.dispose();}
const pay=(h,ids)=>{h.act('quick_trade',a=>a.target.tradeId==='cards-for-credit');for(const id of ids)h.act('choose_payment',a=>a.summary===id);h.act('choose_payment',a=>a.summary.includes('确认弃牌'));};
const ch=(h,id)=>h.act('choose_target',a=>a.target.choiceId===id);
const place=(h,slot=null)=>{h.act('place_data');h.act('choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');};
function insert(h,id){
 while(h.m.facts().computer.length<4)place(h);
 const c=h.m.player().hand.find(x=>x.cardId===id);assert(c);h.act('choose_card',a=>a.target.cardInstanceId===c.id);h.cut('income');
}
const cases=[
 ['scan-keep-chong7-amiba1',h=>{pay(h,['chong_2.webp','amiba_9.webp']);h.act('scan');h.cut('scan');}],
 ['scan-keep-chong2-amiba1',h=>{pay(h,['chong_7.webp','amiba_9.webp']);h.act('scan');h.cut('scan');}],
 ['scan-keep-chong7-chong2',h=>{pay(h,['amiba_1.webp','amiba_9.webp']);h.act('scan');h.cut('scan');}],
 ['amiba1-preserve-energy',h=>{pay(h,['chong_2.webp','amiba_9.webp']);h.take(h.m.play('amiba_1.webp'));h.cut('amiba1');}],
 ['researched-data-pay-scan',h=>{
   h.take(h.m.corner('amiba_9.webp'));h.act('research_tech');ch(h,'tech:purple1');
   insert(h,'amiba_1.webp');h.act('end_turn');h.act('scan');h.cut('scan');
 }],
 ['researched-data-only',h=>{
   h.take(h.m.corner('amiba_9.webp'));h.act('research_tech');ch(h,'tech:purple1');
   insert(h,'amiba_1.webp');
 }],
];
writeZ(out,{root:e,orig,legal,...runCases(e,cases)});
