'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,short}=require('./controlled-r3');
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const [earlier,funded,out]=process.argv.slice(2),a=readZ(earlier),b=readZ(funded);
const r=a.rows.find(r=>r.label==='play-amiba0'),f=b.rows.find(r=>r.label==='researched-data-only');
const list=[...r.prefix,...r.actions.slice(0,22).map(x=>x.action),...f.prefix,...f.actions.map(x=>x.action)];
const root=a.root,rows={};
assert(!root.session);
for(const label of ['original','ordinary','amiba','chong','all']){
 const e=structuredClone(root),s=JSON.parse(e.committedState);
 function swap(a){assert(a.length>2&&a[0]!==a[2]);[a[0],a[2]]=[a[2],a[0]];}
 if(label==='ordinary'||label==='all')swap(s.cards.drawPileCardIds);
 if(label==='amiba'||label==='all')swap(s.aliens.amiba.cardDeck);
 if(label==='chong'||label==='all')swap(s.aliens.chong.cardDeck);
 e.committedState=createStateStore(s).serialize().serialized;
 const m=open(e);
 try{
  const obs=m.owner('player-white'),menu=m.menu(),q=m.automatic(),k={a:q.a,roots:q.roots,n:q.n,complete:q.complete,value:q.value,ms:q.ms};
  assert(q.complete&&q.n<=256&&q.ms<=600);
  if(rows.original)for(const [key,value] of Object.entries({obs,menu}))assert.deepEqual(value,rows.original[key],label+':'+key);
  if(rows.original)for(const key of ['a','roots','complete','value'])assert.deepEqual(k[key],rows.original.q[key],label+':'+key);
  const steps=[];let settled;
  for(const a of list){
   if(a.actorId==='player-white'&&a.family==='pass')settled={e:m.save(),s:short(m)};
   const next=m.apply(a);steps.push(next);
  }
  assert(settled);
  const end=m.save();if(label==='original')assert.deepEqual(end,f.end);
  if(rows.original)for(const key of ['wallet','income','established','computer','blue','tech','hand','probes'])
   assert.deepEqual(settled.s[key],rows.original.settled.s[key],label+':'+key);
  m.restore(e);steps.forEach(m.apply);assert.deepEqual(m.save(),end);
  rows[label]={e,obs,menu,q:k,steps,settled,end};
  console.log(label,q.a.summary,q.value,q.n,settled.s.wallet,settled.s.income,settled.s.hand,settled.s.established);
 }finally{m.dispose();}
}
writeZ(out,rows);
