'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [src,old,newer,out]=process.argv.slice(2),branch=readZ(src).cases['retain-computer'];
const early=readZ(old)['income106-keep-three'],funded=readZ(newer).rows.find(x=>x.label==='researched-data-only');
const e=branch.opening,m=open(e),actions=[],checkpoints=[],id='player-white';
try{
 const fixed=(f,p)=>actions.push({action:m.act(f,p),method:'fixed'});
 const q=m.automatic();assert(q.complete&&q.n<=256&&q.ms<=600);
 fixed('analyze');fixed('choose_target',a=>a.target.choiceId==='trace:2:blue:chong:9');
 fixed('choose_card',a=>a.target.source==='display');fixed('end_turn');
 const other=()=>{const list=[];m.advanceOpponents(list);list.forEach(action=>actions.push({action,method:'passive'}));};
 other();
 const sameTrace=m.save(),sameTraceSummary=short(m),startTurn=short(m).turn;
 assert.deepEqual(sameTraceSummary.wallet.slice(0,4),early.openingSummary.wallet.slice(0,4));
 assert(sameTraceSummary.hand.includes('chong_9.webp'));assert.equal(sameTraceSummary.chongOffer,early.openingSummary.chongOffer);
 assert.deepEqual(sameTraceSummary.hand.toSorted(),early.openingSummary.hand.toSorted());
 assert.deepEqual(sameTraceSummary.income,early.openingSummary.income);
 assert.deepEqual(sameTraceSummary.tech,early.openingSummary.tech);
 assert.deepEqual(sameTraceSummary.computer,early.openingSummary.computer);
 assert.deepEqual(sameTraceSummary.blue,early.openingSummary.blue);
 assert.deepEqual(sameTraceSummary.market,early.openingSummary.market);
 let cache=null,stop=null;
 for(let i=0;i<100;i++){
  if(m.menu()[0].actorId!==id){other();continue;}
  const s=short(m);
  if(!m.save().session&&s.turn>startTurn){checkpoints.push({state:m.save(),summary:s});stop='two-turns';break;}
  assert(m.menu()[0].actorId===id);
  const u=m.automatic(cache);if(!u.complete||u.n>256||u.ms>600){stop={kind:'gate',action:u.a,n:u.n,ms:u.ms};break;}
  cache=u.checkpoint;actions.push({action:m.apply(u.a),method:'autonomous',n:u.n,ms:u.ms,value:u.value});
 }
 assert(stop);
 const end=m.save();m.restore(e);actions.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),end);
 const openingDifference={retained:branch.openingSummary,settledThen:funded.settled.summary,analyzedEarlier:early.openingSummary,analyzedNow:sameTraceSummary};
 const {checkpoint,...qR4}=q;
 writeZ(out,{e,openingDifference,qR4,actions,checkpoints,end,stop,sameTrace,earlySecondTurn:early.checkpoints.at(-1)});
 console.log(JSON.stringify({openingDifference,stop,end:short(m),early:early.checkpoints.at(-1).summary,moves:actions.map(x=>[x.action.family,x.action.summary])}));
}finally{m.dispose();}
