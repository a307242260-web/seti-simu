'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [early,funded,out]=process.argv.slice(2),a=readZ(early),b=readZ(funded),rows={};
const chain=b.rows.find(x=>x.label==='researched-data-only');
function measure(key,e){
 const m=open(e);
 try{
  const obs=m.owner('player-white'),menu=m.menu(),{checkpoint,...q}=m.automatic();
  assert(q.complete&&q.n<=256&&q.ms<=600);assert.deepEqual(m.save(),e);
  rows[key]={e,obs,menu,q,summary:short(m)};
  console.log(key,JSON.stringify([q.a.family,q.a.summary,q.value,q.n,q.ms,q.roots.map(r=>[r.actionId,r.value,r.actions?.length])]));
 }finally{m.dispose();}
}
measure('78-choose-amiba-card',a.root);
measure('95-choose-funding',b.root);
const m=open(b.root);
try{
 for(const [i,action] of chain.prefix.entries()){
  m.apply(action);
  if(i===1)measure('95-choose-tech',m.save());
  if(i===chain.prefix.length-2)measure('97-choose-income',m.save());
 }
 assert.deepEqual(m.save(),chain.start);
 for(const [i,{action}] of chain.actions.entries()){
  if(i===1||i===5||i===9)measure('after-income-native-'+i,m.save());
  m.apply(action);
 }
 assert.deepEqual(m.save(),chain.end);
}finally{m.dispose();}
writeZ(out,rows);
