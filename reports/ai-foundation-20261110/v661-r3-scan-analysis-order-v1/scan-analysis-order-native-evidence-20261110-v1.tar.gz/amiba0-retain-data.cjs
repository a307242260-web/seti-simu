'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),r=d.rows.find(x=>x.label==='researched-data-only');
const id='player-white',cases={},m=open(r.start);
const atScan=r.actions.slice(0,5).map(x=>x.action);
const fill=r.actions.slice(5,9).map(x=>x.action);
const {start}=r;
try{
 for(const a of atScan)m.apply(a);
 const common=m.save(),initial=short(m),blueMenu=[];
 assert.deepEqual(initial.wallet,[99,0,0,1,2]);
 const choices=m.act('place_data');
 blueMenu.push(...m.menu().filter(a=>a.target.blueSlot!=null));
 m.restore(common);
 const place=(slot)=>{const a=m.act('place_data'),b=m.act('choose_target',q=>q.target.blueSlot===slot);return [a,b];};
 for(const key of ['retain-pool','retain-computer','retain-blue','retain-mixed']){
  m.restore(common);
  const prepare=[];
  if(key==='retain-computer'){for(const a of fill)prepare.push(m.apply(a));}
  if(key==='retain-blue')prepare.push(...place(1),...place(2));
  if(key==='retain-mixed'){for(const a of fill.slice(0,2))prepare.push(m.apply(a));prepare.push(...place(2));}
  const e=m.save(),third=short(m),q3=m.automatic();
  assert(q3.complete&&q3.n<=256&&q3.ms<=600);
  const actions=[],checkpoints=[],firstRoots=[];
  const take=action=>actions.push({action,method:'fixed'});
  const other=()=>{const list=[];m.advanceOpponents(list);list.forEach(action=>actions.push({action,method:'passive'}));};
  take(m.act('pass'));take(m.act('choose_card',q=>q.target.cardId==='b_111.webp'));other();
  assert.equal(m.facts().round,4);assert(!m.save().session);
  const opening=m.save(),openingSummary=short(m);
  let cache=null,stop=null,observedTurn=openingSummary.turn;
  for(let i=0;i<120;i++){
   if(m.menu()[0]?.actorId!==id){other();continue;}
   const summary=short(m);
   if(!m.save().session&&summary.turn>observedTurn){
    checkpoints.push({state:m.save(),summary});
    observedTurn=summary.turn;
    if(checkpoints.length===2){stop='two-turns';break;}
   }
   const q=m.automatic(cache);
   if(i===0||q.a.phase==='main')firstRoots.push({action:q.a,n:q.n,ms:q.ms,value:q.value,roots:q.roots});
   if(!q.complete||q.n>256||q.ms>600){stop={kind:'gate',action:q.a,n:q.n,ms:q.ms};break;}
   cache=q.checkpoint;
   const action=m.apply(q.a);actions.push({action,method:'autonomous',n:q.n,ms:q.ms,value:q.value});
   if(action.family==='pass'){stop='autonomous-pass';break;}
  }
  assert(stop);
  const end=m.save();m.restore(common);prepare.forEach(a=>m.apply(a));assert.deepEqual(m.save(),e);
  actions.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),end);
  const {checkpoint, ...r3q}=q3;
  cases[key]={prepare,e,third,r3q,actions,opening,openingSummary,firstRoots,checkpoints,end,stop};
  console.log(key,JSON.stringify({third,q3:[q3.a.summary,q3.n,q3.ms,q3.value],stop,
   turns:checkpoints.map(x=>x.summary),moves:actions.filter(a=>a.method==='autonomous').map(a=>[a.action.family,a.action.summary])}));
 }
 writeZ(out,{start,atScan,common,initial,choices,blueMenu,cases});
}finally{m.dispose();}
