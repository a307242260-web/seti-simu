'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),root=d.rows?.[206]?.e||d.root;
const m=open(root);
try{
 const s=short(m);
 assert.deepEqual(s.wallet,[89,1,2,5,0]);assert.deepEqual(s.computer,[1,2,3,4]);assert(s.hand.includes('amiba_7.webp'));
}finally{m.dispose();}
const r=runCases(root,[
 ['end-without-amiba7-corner',h=>{h.act('end_turn');h.cut('ready');}],
 ['end-without-amiba7-corner-then-scan',h=>{h.act('end_turn');h.act('scan');h.cut('scan');}],
]);
writeZ(out,{root,...r});
