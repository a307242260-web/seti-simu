'use strict';
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),root=d['95-choose-tech'].e;
const a=d['95-choose-tech'].menu.filter(q=>q.target.choiceId?.startsWith('tech:'));
const candidates=a.filter(q=>q.target.tileId!=='purple1');
if(candidates.length!==6)throw new Error(JSON.stringify(a));
const rows=runCases(root,candidates.map(q=>[q.target.choiceId,h=>h.take(h.m.apply(q))]));
writeZ(out,{root,...rows});
