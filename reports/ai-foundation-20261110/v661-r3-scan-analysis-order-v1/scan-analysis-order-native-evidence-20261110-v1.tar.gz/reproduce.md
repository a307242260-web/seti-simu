# 原生复放：第三轮扫描与分析顺序（2026-11-10）

运行时源码为 `40d96a137f494e7cfe581b705e70a96a5c9ecee2`，搜索版本 v439；基准和所有对照使用同一 Production 状态机。以下命令从该源码根执行；`W` 是本档案解包目录。

```sh
(cd "$W" && shasum -a 256 -c SHA256SUMS)
node "$W/verify-scan-analysis.cjs"
```

验证脚本以压缩数据中保存的真实根为起点，不重新搜索。独立逐输入复放并核对完整信封（规则、会话及随机数），核对提交前的预算记录、暗牌对照和 72 组扫描选择；预算失败的 440 次根只验证未提交。

再生成扫描换序试验需要上一次 [第二次扫描筹资归档](../v661-r3-second-scan-funding-v1/second-scan-funding-native-evidence-20261110-v1.tar.gz) 内的 `second-scan-blue1-energy-admitted-20261110-v1.json.gz`（作为 `reverse-scan.cjs`、`amiba-earlier.cjs` 的输入）。正式扫描两个脚本取逐输入冻结表的第 211 和 206 步；对应完整原生根已经在本档案的 `formal-scan-targets-20261110-v1.json.gz` 和 `formal-keep-scan-supplier-20261110-v1.json.gz` 内，复放不依赖额外数据。每个生成脚本的参数依次为源 JSON.GZ 和输出 JSON.GZ（多个输入的脚本按各文件开头声明）；输出拒绝覆盖已存在的文件。
