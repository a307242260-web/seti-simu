'use strict';
const assert = require('node:assert/strict');
const path = require('node:path');
const { readZ, writeZ, short, open } = require('./controlled-r3');
const [source, output] = process.argv.slice(2);
const version = require(path.resolve('randomizer/game/ai/decision-search')).VERSION;
const { canAnalyzeData } = require(path.resolve('randomizer/game/data'));
const roots = readZ(source).rows;
const seat = 'player-white';

function replay(origin, execute) {
  const m = open(origin), actions = [], stages = {};
  const act = (f, id) => {
    const filter = typeof id === 'function' ? id : a => !id || a.target?.choiceId === id;
    const a = m.act(f, filter); actions.push(a); return a;
  };
  const cut = name => stages[name] = { envelope: m.save(), assets: short(m) };
  const handover = () => { act('end_turn'); m.advanceOpponents(actions); };
  const computer = () => {
    act('place_data'); act('choose_target', a => a.target.target === 'computer');
    assert.equal(m.c.inspect().phase, 'idle');
  };
  try {
    const result = execute({ m, actions, act, cut, handover, computer });
    const end = m.save();
    m.restore(origin);
    actions.forEach(m.apply);
    assert.deepEqual(m.save(), end);
    m.restore(origin);
    assert.deepEqual(m.save(), origin);
    return { origin, end, stages, actions, result, exact: true };
  } finally { m.dispose(); }
}

const rows = {};
for (const [name, row] of Object.entries(roots)) {
  const preserve = name === 'preserve';
  assert(preserve || name === 'spend');
  const scan = replay(row.end, ({ m, actions, act, cut, handover, computer }) => {
    handover();
    cut('r4-turn2-start');
    actions.push(m.play('b_9.webp'));
    act('choose_target', 'nebula:sector-2-b');
    act('choose_card', 'public:card-67-0:sector-1-a');
    act('choose_card', 'public:done');
    act('choose_target', 'scan4:launch');
    act('choose_target', 'nebula:sector-2-b');
    cut('same-scan');
    assert.equal(short(m).wallet[4], 3);
    for (let i = 0; i < (preserve ? 2 : 3); i++) computer();
    cut('computer-funded');
    const readiness = canAnalyzeData(m.player(), { skipEnergyCost: true });
    assert.equal(readiness.ok, preserve);
    handover();
    cut('r4-turn3-start');
    assert.equal(m.menu().some(a => a.family === 'analyze'), preserve);
    return readiness;
  });
  const root = scan.end;
  const fixed = replay(root, ({ m, act, cut, handover, actions }) => {
    if (preserve) {
      act('analyze'); act('choose_target', 'trace:1:blue:state-extra');
    } else {
      actions.push(m.play('chong_4.webp')); act('choose_target', 'tech:orange4');
    }
    cut('main-settled');
    handover();
    cut('turn-complete');
  });
  const auto = replay(root, ({ m, actions, cut }) => {
    const startTurn = m.facts().turn;
    let cache;
    const decisions = [];
    for (let i = 0; i < 28; i++) {
      const a = m.menu()[0];
      if (a.actorId !== seat) m.advanceOpponents(actions);
      if (m.facts().turn !== startTurn) {
        cut('turn-complete');
        return { decisions, complete: true };
      }
      const u = m.automatic(cache);
      decisions.push({ action: u.a, n: u.n, ms: u.ms, complete: u.complete, value: u.value, ...(i === 0 ? { roots: u.roots } : {}) });
      if (!u.complete || !u.a || u.n > 256 || u.ms > 600) return { decisions, complete: false, reason: 'single-decision admission gate' };
      cache = u.checkpoint;
      actions.push(m.apply(u.a));
    }
    return { decisions, complete: false, reason: 'probe input cap' };
  });
  rows[name] = { scan, fixed, auto };
  const { decisions } = auto.result;
  console.log(JSON.stringify({ name, scan: scan.stages['computer-funded'].assets, ready: scan.result.ok,
    fixed: fixed.stages['turn-complete'].assets, auto: auto.stages['turn-complete']?.assets,
    complete: auto.result.complete, picks: decisions.map(x => x.action?.summary), best: decisions[0].value,
    native: Math.max(...decisions.map(d => d.n)), ms: Math.max(...decisions.map(d => d.ms)) }));
}
writeZ(output, { version, rows, scope: 'Two already-verified R3 alternatives. Fixed common known R4 second-turn scan; then native third-turn feasibility, fixed actions, and separately one gated autonomous turn. No new rollout policy or game.' });
