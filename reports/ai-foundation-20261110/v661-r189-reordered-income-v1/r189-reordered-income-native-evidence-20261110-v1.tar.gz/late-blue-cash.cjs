'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),saved=readZ(src),root=saved.rows.find(r=>r.label==='blue1').start;
const a=(h,f,p)=>h.act(f,p),choose=(h,f,id)=>a(h,f,q=>q.target.choiceId===id);
const end=h=>a(h,'end_turn');
const pick=(h,id)=>h.take(h.m.pick(id));
const corner=(h,id)=>h.take(h.m.corner(id));
const put=(h,slot)=>{a(h,'place_data');a(h,'choose_target',q=>slot?q.target.blueSlot===slot:q.target.target==='computer');};
function prep(h){
 h.take(h.m.play('amiba_5.webp'));pick(h,'dlc_17.png');choose(h,'choose_target','symbol:red_2');end(h);
 a(h,'analyze');choose(h,'choose_target','trace:1:blue:amiba:3');choose(h,'choose_card','amiba:display:2');
 h.cut('analyzed');
}
function fund(h,to){
 prep(h);
 h.take(...h.m.swap('b_16.webp',to));
 for(const id of ['dlc_17.png','amiba_2.webp',to])corner(h,id);
 for(let i=0;i<4;i++)put(h);
 a(h,'choose_card',q=>q.target.cardInstanceId===h.m.player().hand.find(c=>c.cardId==='dlc_25.png')?.id);
 h.cut('income');
}
function last(h,to,tile,card){
 fund(h,to);end(h);corner(h,'amiba_9.webp');a(h,'research_tech');a(h,'choose_target',q=>q.target.tileId===tile);
 if(card)pick(h,card);
 h.cut('after-last-tech');
}
const m=open(root);
try{
 const q=m.automatic();console.log('base',q.complete,q.n,q.ms,q.a?.summary);
 assert(q.complete&&q.n<=256&&q.ms<=600);
}finally{m.dispose();}
const rows=[
 ['amiba5-dlc17',prep],
 ['amiba5-dlc17-to-income',h=>fund(h,'dlc_15.png')],
 ['amiba5-income-orange3',h=>last(h,'dlc_15.png','orange3')],
 ...['dlc_20.png','dlc_16.png','dlc_14.png'].map(id=>['amiba5-income-orange1-'+id,h=>last(h,'dlc_15.png','orange1',id)]),
];
writeZ(out,{root,...runCases(root,rows)});
