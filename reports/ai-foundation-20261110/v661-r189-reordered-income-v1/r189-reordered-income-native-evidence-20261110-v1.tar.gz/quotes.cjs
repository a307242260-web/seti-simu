'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [early,formal,alt,out]=process.argv.slice(2),d=readZ(early).rows,f=readZ(formal).roots;
const e=readZ(alt).rows.find(x=>x.label==='amiba5-dlc17-to-income').checkpoints.income.state;
const rows={};
for(const [id,root] of [[186,d[186].e],[190,d[190].e],[203,d[203].e],[220,f[220].e],['new-income',e]]){
 const m=open(root),menu=m.menu();
 try{
  const q=m.automatic();assert(q.complete&&q.n<=256&&q.ms<=600);
  const ranking=q.roots.map(r=>[menu.find(a=>a.actionId===r.actionId)?.summary,r.value,r.realizedValue]);
  rows[id]={root,summary:short(m),complete:q.complete,n:q.n,ms:q.ms,a:q.a,ranking};
  console.log(id,q.n,q.ms,q.a?.summary,ranking.filter(x=>x[1]!=null));
 }finally{m.dispose();}
}
writeZ(out,rows);
