'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ,runCases}=require('./controlled-r3');
const [source,out]=process.argv.slice(2),root=readZ(source).roots[219].e;
const a=(h,f,p)=>h.act(f,p);
const end=h=>a(h,'end_turn');
const put=(h,slot)=>{a(h,'place_data');a(h,'choose_target',q=>slot?q.target.blueSlot===slot:q.target.target==='computer');};
const choose=(h,f,id)=>a(h,f,q=>q.target.choiceId===id);
const corner=(h,id)=>h.take(h.m.corner(id));
const pick=(h,id)=>h.take(h.m.pick(id));
function tech(h,id){a(h,'research_tech');a(h,'choose_target',q=>q.target.tileId===id&&(!q.target.blueSlot||q.target.blueSlot===3));}
function first(h){tech(h,'blue1');put(h);put(h);put(h,3);h.cut('ready');end(h);}
function analyze(h){first(h);a(h,'analyze');choose(h,'choose_target','trace:1:blue:amiba:3');choose(h,'choose_card','amiba:display:2');h.cut('analyzed');}
function prep(h,spend){
 analyze(h);put(h);corner(h,spend);put(h);corner(h,'amiba_9.webp');h.cut('launch-funded');end(h);
}
function launch(h,spend,id){prep(h,spend);tech(h,'orange1');pick(h,id);h.cut('launch');end(h);}
function finish(h,spend,id){
 launch(h,spend,id);
 h.take(h.m.play('amiba_5.webp'));pick(h,'dlc_15.png');
 choose(h,'choose_target','symbol:red_2');h.cut('after-amiba5');
}
const m=open(root);
try{const q=m.automatic();console.log('base',q.complete,q.n,q.ms,q.a?.summary);assert(q.complete&&q.n<=256&&q.ms<=600);}finally{m.dispose();}
const cases=[
 ['blue1',first],['blue1-analyze',analyze],
 ['blue1-analyze-launch-dlc17',h=>launch(h,'amiba_2.webp','dlc_17.png')],
 ['blue1-analyze-launch-dlc20',h=>launch(h,'amiba_2.webp','dlc_20.png')],
 ['blue1-analyze-launch-dlc17-amiba5',h=>finish(h,'amiba_2.webp','dlc_17.png')],
 ['blue1-analyze-launch-dlc20-amiba5',h=>finish(h,'amiba_2.webp','dlc_20.png')],
];
writeZ(out,{root,...runCases(root,cases)});
