'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [src,formal,out]=process.argv.slice(2),r=readZ(src),rows=[];
const fixture=[['formal',readZ(formal).roots[258].e],['orange3',r.rows.find(a=>a.label==='amiba5-income-orange3').settled.state]];
for(const [id,root] of fixture)for(const follow of ['skip','launch']){
 const m=open(root),actions=[],stages={};
 const act=(f,p)=>{const a=m.act(f,p);actions.push(a);return a;};
 const step=(f,c)=>act(f,a=>a.target.choiceId===c);
 const cut=k=>stages[k]={s:short(m),e:m.save()};
 const end=()=>{act('end_turn');m.advanceOpponents(actions);};
 try{
  act('pass');act('choose_card',a=>a.target.cardId==='b_111.webp');m.advanceOpponents(actions);cut('r4');
  const c=m.state().cards.publicCards.find(c=>c?.cardId==='b_16.webp');
  act('scan');step('choose_target','nebula:sector-4-a');
  act('choose_card',a=>a.target.cardInstanceId===c.id&&a.target.nebulaId==='sector-3-a');
  step('choose_card','public:done');
  if(m.menu().some(a=>a.target.choiceId==='scan4:'+follow))step('choose_target','scan4:'+follow);
  else assert.equal(follow,'skip',m.menu().map(a=>a.summary).join('/'));
  for(let i=m.facts().computer.length;i<6;i++){
   act('place_data');step('choose_target','data:computer');
  }
  end();cut('after-scan');
  act('analyze');step('choose_target','trace:1:blue:state-extra');end();cut('after-analysis');
  const e=m.save();m.restore(root);actions.forEach(m.apply);assert.deepEqual(m.save(),e);
  rows.push({id,follow,root,actions,stages,end:e,exact:true});
  console.log(id,follow,Object.fromEntries(Object.entries(stages).map(([k,x])=>[k,[x.s.wallet,x.s.established,x.s.probes,x.s.hand]])));
 }finally{m.dispose();}
}
writeZ(out,{rows});
