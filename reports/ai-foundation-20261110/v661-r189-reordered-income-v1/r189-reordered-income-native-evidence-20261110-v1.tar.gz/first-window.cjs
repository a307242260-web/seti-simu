'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),groups={};
const a=(h,f,p)=>h.act(f,p),c=(h,f,id)=>a(h,f,x=>x.target.choiceId===id);
const end=h=>a(h,'end_turn');
function analysis(h,which,open){
 if(open)a(h,'analyze');
 c(h,'choose_target',which===2?'trace:2:blue':'trace:1:blue:amiba:'+which);
 if(which===3||which===4)c(h,'choose_card','amiba:display:7');
 h.cut('first-analysis');
}
function remove(h,what){
 h.take(h.m.play('amiba_3.webp'));c(h,'choose_target',what);h.cut('amiba3');
}
const specs=[
 [186,[['analyze-first-blue4',h=>analysis(h,4,true)],
  ['analyze-blue4-then-amiba3-yellow',h=>{analysis(h,4,true);end(h);remove(h,'trace:yellow:1');}],
  ['analyze-blue4-then-purple1',h=>{analysis(h,4,true);end(h);a(h,'research_tech');a(h,'choose_target',q=>q.target.tileId==='purple1');h.cut('purple1');}]]],
 [187,[['amiba3-remove-blue',h=>c(h,'choose_target','trace:blue:1')],
  ['amiba3-remove-pink',h=>c(h,'choose_target','trace:pink:4')]]],
 [190,[['blue2-no-card',h=>c(h,'choose_target','trace:1:blue:amiba:2')],
  ['blue3-keep-blue4',h=>analysis(h,3,false)],
  ['blue-other',h=>analysis(h,2,false)]]]
];
for(const [at,cases] of specs){
 const root=d.rows[at].e,m=open(root);
 try{const q=m.automatic();console.log('cold',at,q.complete,q.n,q.ms,q.a?.summary);assert(q.complete&&q.n<=256&&q.ms<=600);}finally{m.dispose();}
 groups[at]={root,...runCases(root,cases)};
}
writeZ(out,groups);
