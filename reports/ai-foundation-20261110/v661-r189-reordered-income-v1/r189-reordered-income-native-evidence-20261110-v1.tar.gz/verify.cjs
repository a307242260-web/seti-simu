'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ}=require('./controlled-r3');
const p=process.argv[2]||__dirname,read=n=>readZ(path.join(p,n+'-20261110-v1.json.gz'));
let segments=0,inputs=0,decisions=0,maxNative=0,maxMs=0;
function replay(root,actions,end){
 const m=open(root);
 try{
  for(const x of actions){
   if(Number.isFinite(x.n)){assert(x.n<=256&&x.ms<=600);decisions++;maxNative=Math.max(maxNative,x.n);maxMs=Math.max(maxMs,x.ms);}
   m.apply(x.action||x);
  }
  assert.deepEqual(m.save(),end);
  inputs+=actions.length;segments++;
 }finally{m.dispose();}
}
function checkCases(x){
 for(const r of x.rows){
  assert.equal(r.stop,'r4-first-white-main');
  replay(x.root,[...r.prefix,...r.actions],r.end);
 }
}
for(const n of ['r189-paid-analysis','r189-blue-before-analyze','r189-blue-amiba5-cash-income'])checkCases(read(n));
for(const n of ['r189-first-window','r189-reordered-dark-controls']){
 const t=read(n);
 for(const x of Object.values(t.rows||t))checkCases(x);
}
for(const n of ['r189-matched-r4','r189-matched-r4-scan'])for(const r of read(n).rows)replay(r.root,r.actions,r.end);
const roots=read('r189-formal-roots').rows;
const list=Object.values(roots);
replay(list[0].e,list.slice(0,-1).map(r=>r.a),list.at(-1).e);
const q=read('r189-quotes');
for(const {complete,n,ms} of Object.values(q))assert(complete&&n<=256&&ms<=600);
assert.equal(q['220'].ranking.find(r=>r[0]==='研究 orange1')[1],181);
assert.equal(q['220'].ranking.find(r=>r[0]==='研究 blue1（蓝槽 3）')[1],180);
const dark=read('r189-reordered-dark-controls');
for(const r of Object.values(dark.rows)){
 assert.deepEqual(r.check.obs,dark.base.obs);assert.deepEqual(r.check.roots,dark.base.roots);
 const x=r.rows[0].settled.summary;
 if(r.code)assert(x.income[1]===4&&x.probes.length===1&&x.wallet[0]===118);
 else assert(x.income[1]===3&&!x.probes.length&&x.wallet[0]===121);
}
console.log(JSON.stringify({segments,inputs,decisions,maxNative,maxMs,quotes:Object.keys(q).length}));
