'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,runCases}=require('./controlled-r3');
const [roots,history,out]=process.argv.slice(2),d=readZ(roots),root=d.rows[203].e,historical=readZ(history)['earlier-analysis-blue3'].roots;
const a=(h,f,p)=>h.act(f,p);
const take=(h,id)=>h.take(h.m.pick(id));
const play=(h,id)=>h.take(h.m.play(id));
const corner=(h,id)=>h.take(h.m.corner(id));
const put=(h,slot)=>{a(h,'place_data');a(h,'choose_target',q=>slot?q.target.blueSlot===slot:q.target.target==='computer');};
const hand=(h,id)=>h.m.player().hand.find(c=>c.cardId===id)?.id;
const income=(h,id)=>a(h,'choose_card',q=>q.target.cardInstanceId===hand(h,id));
const end=h=>a(h,'end_turn');
function trade(h,tradeId,cards){
 a(h,'quick_trade',q=>q.target.tradeId===tradeId);
 for(const id of cards)a(h,'choose_payment',q=>q.target.cardInstanceId===hand(h,id));
 if(h.m.c.inspect().session?.decision)a(h,'choose_payment',q=>q.target.kind!=='discard-hand-card');
}
function research(h,tile){
 a(h,'research_tech');a(h,'choose_target',q=>q.target.tileId===tile&&(!q.target.blueSlot||q.target.blueSlot===3));
}
function prepare(h,mode){
 if(mode==='public')h.take(...h.m.swap('b_16.webp','dlc_25.png'));
 income(h,mode==='public'?'dlc_25.png':'amiba_9.webp');
 put(h);corner(h,'amiba_7.webp');put(h);end(h);
 a(h,'analyze');a(h,'choose_target',q=>q.target.choiceId==='trace:1:blue:amiba:3');
 a(h,'choose_card',q=>q.target.choiceId==='amiba:display:5');
 h.cut('analyzed');
 put(h);
 trade(h,'cards-for-credit',['amiba_1.webp',mode==='public'?'amiba_9.webp':'b_16.webp']);h.cut('funded');
 end(h);
 for(const i of [6,7,8])h.take(h.m.apply(historical[i].a));
 a(h,'choose_target',q=>q.target.choiceId==='trace:1:pink:amiba:3');
 a(h,'choose_card',q=>q.target.choiceId==='amiba:display:2');
 if(h.m.menu().some(q=>q.target.ruleId==='amiba0-pink-data'))a(h,'accept_optional_effect',q=>q.target.ruleId==='amiba0-pink-data');
 a(h,'complete_task',q=>q.summary.includes('dlc_9'));
 h.cut('after-scan');
}
function score(h,mode,pick){
 prepare(h,mode);
 for(let i=0;i<3;i++)put(h);
 income(h,'amiba_2.webp');end(h);
 play(h,'amiba_5.webp');take(h,pick);
 a(h,'choose_target',q=>q.target.choiceId==='symbol:red_2');h.cut('amiba5-played');
}
function transport(h,mode,card){
 score(h,mode,'dlc_20.png');end(h);
 research(h,'orange1');take(h,card);h.cut('after-launch');end(h);
 a(h,'move',q=>q.target.deltaX===0&&q.target.deltaY===1);
 a(h,'choose_payment',q=>q.target.cardIds?.includes(hand(h,'dlc_20.png')));
 corner(h,card);
 research(h,'blue1');h.cut('after-blue');
}
const m=open(root);
try{
 const q=m.automatic();console.log('base',q.complete,q.n,q.ms,q.a?.summary,q.roots.map(r=>[r.actionId,r.value]));
 assert(q.complete&&q.n<=256&&q.ms<=600);
}finally{m.dispose();}
const tests=[];
for(const mode of ['held','public']){
 tests.push([mode+':analyze-scan',h=>prepare(h,mode)]);
 for(const id of ['dlc_20.png','dlc_17.png'])tests.push([mode+':amiba5:'+id,h=>score(h,mode,id)]);
 for(const card of ['dlc_25.png','dlc_16.png'])tests.push([mode+':launch-and-blue:'+card,h=>transport(h,mode,card)]);
}
writeZ(out,{root,...runCases(root,tests)});
