'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,runCases}=require('./controlled-r3');
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const deck=require(path.resolve('randomizer/game/cards/deck'));
const [src,out]=process.argv.slice(2),root=readZ(src).rows.find(r=>r.label==='blue1').start,rows={};
const a=(h,f,p)=>h.act(f,p),ch=(h,f,id)=>a(h,f,q=>q.target.choiceId===id);
function afterAnalyze(h){
 h.take(h.m.play('amiba_5.webp'));h.take(h.m.pick('dlc_17.png'));ch(h,'choose_target','symbol:red_2');a(h,'end_turn');
 a(h,'analyze');ch(h,'choose_target','trace:1:blue:amiba:3');ch(h,'choose_card','amiba:display:2');h.cut('after-analysis');
}
function source(dataId){
 return h=>{
  afterAnalyze(h);
  assert(h.m.state().cards.publicCards.some(c=>c?.cardId===dataId&&deck.getDiscardActionRewardForCard(c)?.dataCount));
  h.take(...h.m.swap('b_16.webp',dataId));
  for(const id of ['dlc_17.png','amiba_2.webp',dataId])h.take(h.m.corner(id));
  for(let i=0;i<4;i++){a(h,'place_data');ch(h,'choose_target','data:computer');}
  const id=h.m.player().hand.find(c=>c.cardId==='dlc_25.png').id;
  a(h,'choose_card',q=>q.target.cardInstanceId===id);
  a(h,'end_turn');h.take(h.m.corner('amiba_9.webp'));a(h,'research_tech');ch(h,'choose_target','tech:orange1');h.take(h.m.pick('dlc_20.png'));
  h.cut('closed-payment');
 };
}
function audit(e){
 const m=open(e);
 try{
  const q=m.automatic();
  assert(q.complete&&q.n<=256&&q.ms<=600);
  return {obs:m.owner('player-white'),menu:m.menu(),chosen:q.a,roots:q.roots,n:q.n,ms:q.ms};
 }finally{m.dispose();}
}
assert(!root.session);
const base=audit(root);
for(const id of ['dlc_14.png','b_60.webp','b_9.webp','dlc_13.png']){
 const e=structuredClone(root),s=JSON.parse(e.committedState),pile=s.cards.drawPileCardIds,i=pile.indexOf(id);
 assert(i>0&&pile[0]==='dlc_15.png');
 [pile[0],pile[i]]=[pile[i],pile[0]];
 e.committedState=createStateStore(s).serialize().serialized;
 const check=audit(e);
 for(const k of ['obs','menu','chosen','roots','n'])assert.deepEqual(check[k],base[k],id+':'+k);
 const code=deck.getDiscardActionRewardForCard({cardId:id})?.dataCount||0;
 const test=code?[[id,source(id)]]:[[id,afterAnalyze]];
 rows[id]={code,check,...runCases(e,test),root:e};
}
writeZ(out,{root,base,rows});
