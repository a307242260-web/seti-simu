'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [source,save,out]=process.argv.slice(2),src=readZ(source).snapshots,m=open(src['171'].envelope),ref=JSON.parse(fs.readFileSync(save)).replaySteps,rows={};
try{
 for(let i=171;i<=214;i++){
  const a=ref[i-1].action,s=short(m),e=m.save(),menu=m.menu();
  if(src[i])assert.deepEqual(e,src[i].envelope);
  rows[i]={a,s,e,menu};
  console.log(i,s.turn,s.wallet.join('/'),s.income.join('/'),s.computer.join('')+'/'+s.blue.join(''),s.hand.join(','),s.market.join(','),a.family,a.summary,menu.filter(a=>a.family==='choose_target'||a.family==='choose_card'||a.family==='accept_optional_effect').map(a=>a.target.choiceId).join(' '));
  m.apply(a);
 }
 writeZ(out,{rows});
}finally{m.dispose();}
