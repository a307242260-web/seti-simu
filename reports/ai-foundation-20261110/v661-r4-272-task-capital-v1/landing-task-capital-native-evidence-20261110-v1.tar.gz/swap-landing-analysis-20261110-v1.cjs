'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),V=require(path.resolve('randomizer/game/ai/state-value'));
const read=p=>JSON.parse(z.gunzipSync(fs.readFileSync(p)));
const landFirst=read(process.argv[3]),analysis=read(process.argv[4]),landLast=read(process.argv[5]);
const root=landFirst.steps.at(-1).end,m=open(root),steps=[];
try{
 const found=[];
 for(const expected of analysis.result.steps.map(s=>s.a)){
  const a=m.menu().find(a=>a.actionId===expected.actionId);
  if(!a){found.push({missing:expected,currentMenu:m.menu()});break;}
  m.apply(a);steps.push({a,end:m.save(),facts:m.facts(),value:V.evaluateStateValue(m.owner(seat),seat)});
 }
 const end=m.save(),other=landLast.result.steps.at(-1).end;
 m.restore(root);for(const {a,end} of steps){m.apply(a);assert.deepEqual(m.save(),end);}
 m.restore(root);assert.deepEqual(m.save(),root);
 const s=JSON.parse(end.committedState),t=JSON.parse(other.committedState),eq=(a,b)=>require('node:util').isDeepStrictEqual(a,b);
 const diff=Object.keys(s).filter(key=>!eq(s[key],t[key]));
 const result={completed:!found.length,steps,found,originalOtherEnd:other,exactState:eq(s,t),differences:diff,sameRng:eq(s.meta.rngState,t.meta.rngState)};
 fs.writeFileSync(process.argv[6],z.gzipSync(JSON.stringify({root,result})),{flag:'wx'});
 console.log(JSON.stringify({actions:steps.map(s=>s.a.summary),missing:found.map(x=>x.missing.summary),differences:diff,sameRng:result.sameRng,last:steps.at(-1)?.value}));
}finally{m.dispose();}
