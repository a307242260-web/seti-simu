'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),V=require(path.resolve('randomizer/game/ai/state-value')),P=require(path.resolve('randomizer/game/ai/probe-capital'));
const data=JSON.parse(z.gunzipSync(fs.readFileSync(process.argv[3]))),root=(data.steps||data.result.steps).at(-1).end,m=open(root);
try{
 const f=P.factsFromObservation(m.owner(seat),seat),quote=P.quote({...f,investment:()=>0},V.DEFAULT_WEIGHTS),native=m.automatic();
 const ids=native.checkpoint?.plan.rows.map(r=>r.actionId)||[native.a.actionId],steps=[],turn=m.facts().turn;
 assert(native.complete);assert.equal(ids[0],native.a.actionId);
 const within=native.n<=256&&native.ms<=600;
 if(within)for(const id of ids){
  const a=m.menu().find(a=>a.actionId===id);assert(a);
  if(a.family==='pass')break;
  m.apply(a);steps.push({a,end:m.save(),facts:m.facts(),value:V.evaluateStateValue(m.owner(seat),seat)});
  if(m.facts().turn!==turn)break;
 }
 m.restore(root);for(const {a,end} of steps){m.apply(a);assert.deepEqual(m.save(),end);}
 m.restore(root);assert.deepEqual(m.save(),root);
 const result={quote:quote.selected,native:{n:native.n,ms:native.ms,v:native.value,a:native.a,within},steps};
 fs.writeFileSync(process.argv[4],z.gzipSync(JSON.stringify({root,result})),{flag:'wx'});
 console.log(JSON.stringify({quote:quote.selected,native:result.native,actions:steps.map(s=>s.a.summary),end:steps.at(-1)?.facts.wallet}));
}finally{m.dispose();}
