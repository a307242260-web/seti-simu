'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),stateValue=require(path.resolve('randomizer/game/ai/state-value'));
const d=JSON.parse(z.gunzipSync(fs.readFileSync(process.argv[3])));
const roots=[['direct-turn2',d.paths.triton[0].end],['direct-turn6',d.paths.triton[4].end],['hold6-turn2',d.paths['preserve-6'][0].end],['hold4-turn2',d.paths['preserve-4'][0].end],['scan-turn3',d.paths.scan[1].end]];
const result=[];
for(const [label,root] of roots){
 const m=open(root);
 try{
  const facts=m.facts(),legal=m.menu(),v=stateValue.evaluateStateValue(m.owner(seat),seat),actions=[];
  for(const family of ['research_tech','scan','launch','play_card','analyze']){
   for(const action of legal.filter(a=>a.family===family)){
    m.restore(root);m.apply(action);
    const menu=m.menu().map(a=>[a.family,a.summary,a.target]);
    actions.push({family,summary:action.summary,target:action.target,menu:menu.slice(0,25),decision:m.c.inspect().session?.decision?.decisionId||null});
   }
  }
  m.restore(root);
  assert.deepEqual(m.save(),root);
  result.push({label,facts,v,legal:legal.map(a=>[a.family,a.summary,a.target]),actions});
 }finally{m.dispose();}
}
fs.writeFileSync(process.argv[4],JSON.stringify(result,null,2)+'\n',{flag:'wx'});
