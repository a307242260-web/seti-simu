'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),V=require(path.resolve('randomizer/game/ai/state-value')),P=require(path.resolve('randomizer/game/ai/probe-capital'));
const data=JSON.parse(z.gunzipSync(fs.readFileSync(process.argv[3]))),root=data.root,m=open(root),steps=[];
const record=a=>steps.push({a,end:m.save(),facts:m.facts(),value:V.evaluateStateValue(m.owner(seat),seat)});
const go=(family,p)=>record(m.act(family,p));
try{
 const turn=m.facts().turn,quote=P.quote({...P.factsFromObservation(m.owner(seat),seat),investment:()=>0},V.DEFAULT_WEIGHTS).selected;
 assert.equal(quote.id,'7:land:neptune:triton');assert.equal(quote.route.path.length,1);
 for(const step of quote.route.path){
  go('move',a=>a.target.rocketId===7&&a.target.deltaX===step.deltaX&&a.target.deltaY===step.deltaY);
  if(m.c.inspect().session?.decision)go('choose_payment',a=>a.payload.energyCost===step.requiredMovePoints&&!a.target.cardIds?.length);
 }
 go('land');go('choose_target',a=>a.target.landTarget?.satelliteId==='triton'&&a.target.rocketId===7);
 if(!m.menu().some(a=>a.target?.ruleId==='b117-orbit-land-count-task'))throw Error('known B117 is not ready after land');
 go('complete_task',a=>a.target.ruleId==='b117-orbit-land-count-task');
 go('end_turn');assert.equal(m.facts().turn,turn+1);
 const result=steps.at(-1);
 m.restore(root);for(const {a,end} of steps){m.apply(a);assert.deepEqual(m.save(),end);}
 m.restore(root);assert.deepEqual(m.save(),root);
 fs.writeFileSync(process.argv[4],z.gzipSync(JSON.stringify({root,quote,steps})),{flag:'wx'});
 console.log(JSON.stringify({steps:steps.map(s=>s.a.summary),wallet:result.facts.wallet,value:result.value}));
}finally{m.dispose();}
