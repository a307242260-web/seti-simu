'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),{evaluateStateValue}=require(path.resolve('randomizer/game/ai/state-value'));
const {root:anchor,paths}=JSON.parse(z.gunzipSync(fs.readFileSync(process.argv[3])));
const roots=[['direct',paths.triton[0].end],['hold6',paths['preserve-6'][0].end],['hold4',paths['preserve-4'][0].end],['scan',paths.scan[1].end]];
const results=[];
for(const [label,root] of roots){
 const m=open(root),steps=[];
 const record=a=>steps.push({input:a,end:m.save(),facts:m.facts(),menu:m.menu().map(a=>[a.family,a.summary,a.target]),
  value:evaluateStateValue(m.owner(seat),seat)});
 const go=(family,pred)=>record(m.act(family,pred));
 try{
  go('research_tech');go('choose_target',a=>a.target.tileId==='orange1');
  let next=m.menu(),forced=0;
  while(m.c.inspect().session?.decision&&++forced<6){
   const a=next.find(a=>a.family==='choose_card'&&(a.target.cardInstanceId==='card-66-0'||a.target.source==='public'&&m.state().cards.publicCards[a.target.slotIndex]?.id==='card-66-0'));
   if(!a)break;
   assert(JSON.parse(root.committedState).cards.publicCards.some(c=>c?.id==='card-66-0'));
   record(m.apply(a));next=m.menu();
  }
  if(!m.c.inspect().session?.decision&&m.menu().some(a=>a.family==='end_turn'))go('end_turn');
  const final=m.save();m.restore(root);for(const step of steps){m.apply(step.input);assert.deepEqual(m.save(),step.end);}
  assert.deepEqual(m.save(),final);m.restore(root);assert.deepEqual(m.save(),root);
  results.push({label,root,steps});
 }finally{m.dispose();}
}
fs.writeFileSync(process.argv[4],z.gzipSync(JSON.stringify(results)),{flag:'wx'});
