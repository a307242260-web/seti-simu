Run from the root of the SETI source of this report.
node <archive-dir>/audit-data-score-and-menu-20261110-v1.cjs official <archive-dir>/v661-r4-full-preflight-20261109-v1.json /private/tmp/seti-data-score-audit.json
node <archive-dir>/verify-score-delta-guards-20261110-v1.cjs <archive-dir>/v661-r4-full-preflight-20261109-v1.json /private/tmp/seti-data-score-guards.json
The first script recomputes every fast scoring and menu result with the full implementation, and can also be run in teacher272, satellite and r3 modes with the matching included roots. The compare-full-graphs script produces the full graph digest when run from either source. All output files must be new.
