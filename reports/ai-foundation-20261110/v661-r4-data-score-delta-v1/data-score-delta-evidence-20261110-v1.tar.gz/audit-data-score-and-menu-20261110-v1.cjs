'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),assert=require('node:assert/strict'),Module=require('node:module');
const [mode,input,out]=process.argv.slice(2),counts={scoreFast:0,scoreFallback:0,scoreWalletSensitive:0,menu:0,menuWithFixedPick:0},rows=[];
function install(name,rewrite){
 const file=path.resolve('randomizer/game/ai/'+name+'.js'),m=new Module(file,module);
 m.filename=file;m.paths=Module._nodeModulePaths(path.dirname(file));Module._cache[file]=m;
 m._compile(rewrite(fs.readFileSync(file,'utf8')),file);m.loaded=true;
}
const sub=(s,old,next)=>{assert.equal(s.split(old).length,2,old);return s.replace(old,next);};
globalThis.auditFastScore=(state,p,copy,fast,full)=>{
 const expected=full();
 if(fast===null)counts.scoreFallback++;
 else {assert.equal(fast,expected);counts.scoreFast++;
  if(fast!==copy.resources.score-p.resources.score)counts.scoreWalletSensitive++;}
 return expected;
};
globalThis.auditMenu=(fast,old)=>{
 if(fast===undefined)return;
 assert.deepEqual(fast,old);counts.menu++;
 if(fast===null)counts.menuWithFixedPick++;
};
install('local-decision-plans',s=>{
 s=sub(s,'  if(proved!==null)return proved;','  return globalThis.auditFastScore(state,p,copy,proved,()=>fullDataScoreDelta(state,p,copy));\n }\n function fullDataScoreDelta(state,p,copy){');
 return s;
});
install('analysis-port',s=>{
 s=sub(s,'      // A regular Native reward menu cannot supply a new resource plan.','      let earlyResourceSpec;\n      // A regular Native reward menu cannot supply a new resource plan.');
 s=sub(s,'          resourceSpecs.set(node,spec);return spec;\n        }\n      }\n      const shipment=','          earlyResourceSpec=spec;\n        }\n      }\n      const shipment=');
 s=sub(s,'      if(cardPick?.fixed){resourceSpecs.set(node,null);return null;}','      if(cardPick?.fixed){globalThis.auditMenu(earlyResourceSpec,null);resourceSpecs.set(node,null);return null;}');
 return sub(s,'      resourceSpecs.set(node,result);return result;\n    }\n\n    function resourceView','      globalThis.auditMenu(earlyResourceSpec,result);\n      resourceSpecs.set(node,result);return result;\n    }\n\n    function resourceView');
});
const {open}=require('./native-late-r3'),d=JSON.parse(input.endsWith('.gz')?z.gunzipSync(fs.readFileSync(input)):fs.readFileSync(input));
const roots=mode==='r3'?d.rows.map(r=>r.root):[mode==='teacher272'?d.rows[0].root:d.checkpoint];
for(const root of roots){
 const m=open(root);
 try{const r=m.automatic();assert(r.complete);assert.deepEqual(m.save(),root);rows.push({action:r.a.actionId,native:r.n,value:r.value});}
 finally{m.dispose();}
}
fs.writeFileSync(out,JSON.stringify({counts,rows,sourceAndRngExact:true},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({counts,rows}));
