'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const [src,out]=process.argv.slice(2),load=n=>require(path.resolve('randomizer/game/'+n));
const file=path.resolve('randomizer/game/ai/local-decision-plans.js'),m=new Module(file,module);
m.filename=file;m.paths=Module._nodeModulePaths(path.dirname(file));
const source=fs.readFileSync(file,'utf8'),hook='return Object.freeze({VERSION,';
assert.equal(source.split(hook).length,2);
m._compile(source.replace(hook,'return Object.freeze({provedDataScoreDelta,dataScoreDelta,VERSION,'),file);
const {provedDataScoreDelta:prove,dataScoreDelta:score}=m.exports,deck=load('cards/deck'),effects=load('cards/effects'),end=load('end-game-scoring');
const seat='player-white',root=JSON.parse(JSON.parse(fs.readFileSync(src)).checkpoint.committedState),original=JSON.stringify(root);
const player=root.players.players.find(p=>p.id===seat);
const full=(s,before,after)=>{
 const context={...s,aliens:structuredClone(s.aliens),finalScoring:structuredClone(s.finalScoring),cardEffects:effects,
  getCardTypeCode:c=>effects.getRuntimeCardTypeCode(c,effects.getCardModel(c)?.cardType)};
 return end.computePlayerFinalScore({...context,players:s.players.players.map(p=>p.id===seat?after:p)},after).totalScore
  -end.computePlayerFinalScore({...context,players:s.players.players.map(p=>p.id===seat?before:p)},before).totalScore;
};
const byId=id=>deck.createCardInstance(deck.CARD_CATALOG.find(c=>c.card_id===id),'delta-proof:'+id);
const p={...player,reservedCards:[...player.reservedCards,byId('dlc_8.png'),byId('dlc_10.png')],
 resources:{...player.resources,availableData:3,publicity:4}};
const q={...p,resources:{...p.resources,score:p.resources.score+2,availableData:2,publicity:5}};
assert.equal(prove(root,p,q),0,'2 board + 1 publicity score - 3 spent data score');
assert.equal(prove(root,p,q),full(root,p,q));
const income={...q,income:{...q.income,credits:q.income.credits+1}};
assert.equal(prove(root,p,income),null);
assert.equal(score(root,p,income),full(root,p,income));
const threat=structuredClone(root);threat.aliens.jiuzhe.playerThreatById[seat]=4;
assert.equal(prove(threat,p,q),null);
assert.equal(score(threat,p,q),full(threat,p,q));
const runezu=structuredClone(root);runezu.aliens.runezu.revealInitialized=true;
const before={...p};delete before.runezuSymbols;
const after={...q};delete after.runezuSymbols;
assert.equal(prove(runezu,before,after),null);
assert.equal(JSON.stringify(root),original);
const result={dataAndPublicityCardDelta:0,expectedBaseGain:2,changedIncomeUsesFullScoring:true,jiuzhePenaltyUsesFullScoring:true,
 runezuNormalizationUsesFullScoring:true,rootExact:true};
fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result));
