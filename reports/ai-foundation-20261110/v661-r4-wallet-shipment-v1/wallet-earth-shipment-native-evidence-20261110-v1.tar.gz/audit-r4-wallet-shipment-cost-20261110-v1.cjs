'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,writeZ}=require('./controlled-r3'),{createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [file,out]=process.argv.slice(2),{rows}=readZ(file),outRows={};
for(const name of ['keep-amiba9','research-orange3']){
 const e=rows[name].stages.round4.state,m=open(e),seat='player-white';
 const port=createAnalysisPort({composition:m.c,seatId:seat});
 try{
  const menu=m.menu(),agent=createSearchAgent({seatId:seat,analysisPort:port}),result=agent.decide({seatId:seat,legalActions:menu}),q=result.search;
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),e);
  const plan=q.lines[0].resourcePolicy?.plans.find(p=>p.goal.kind==='wallet-earth-shipment');
  const root=q.roots.find(r=>r.goal?.kind==='wallet-earth-shipment');
  const edge=q.lines[0].edges.find(e=>e.resourcePlan?.kind==='wallet-earth-shipment'||e.goal?.kind==='wallet-earth-shipment'
    ||e.resourceGoal?.kind==='wallet-earth-shipment'||e.actionId===plan?.firstActionId);
  const descendants=new Set(),other=new Set(),visit=(i,set)=>{
   if(set.has(i))return;set.add(i);for(const child of q.lines[i].edges)visit(child.target,set);
  };
  visit(edge.target,descendants);
  for(const candidate of q.lines[0].edges)if(candidate!==edge)visit(candidate.target,other);
  const costs={},exclusive=[];
  for(const i of descendants)if(!other.has(i)){
   exclusive.push(i);
   for(const child of q.lines[i].edges){
    const family=child.actionId.split(':')[0];
    const row=costs[family]??={edges:0,logicalSteps:0};
    row.edges++;row.logicalSteps+=child.cost;
   }
  }
  const value=q.lines[edge.target].value,steps=[...edge.steps],seen=new Set();let i=edge.target;
  while(q.lines[i].edges.length){
   assert(!seen.has(i));seen.add(i);
   const node=q.lines[i],options=node.edges.filter(x=>q.lines[x.target].value===value&&q.lines[x.target].distance<node.distance);
   assert(options.length,JSON.stringify({i,d:node.distance,value}));const next=options.sort((a,b)=>a.cost+q.lines[a.target].distance-b.cost-q.lines[b.target].distance)[0];
   steps.push(...(next.steps?.length?next.steps:[next.actionId]));i=next.target;
  }
  const leaf=q.lines[i],accepted=[];
  for(const id of steps){
   const a=m.menu().find(a=>a.actionId===id);assert(a,JSON.stringify({id,menu:m.menu().map(a=>[a.actionId,a.summary])}));accepted.push(m.apply(a));
  }
  const end=m.save(),facts=m.facts();
  m.restore(e);accepted.forEach(a=>m.apply(a));assert.deepEqual(m.save(),end);m.restore(e);
  const afterCargo={descendants:descendants.size,exclusive:exclusive.length,costs,leaf,accepted,end,facts};
  const d={root:e,n:q.diagnostics.nativeExecutions,nodes:q.diagnostics.graphNodes,ms:q.rootAndSearchMilliseconds,roots:q.roots,value:q.value,chosen:q.actionId,
   plan,candidate:root,edge,analysis:q.analysis,sourceMenu:menu,afterCargo};
  outRows[name]=d;
  console.log(JSON.stringify({name,selected:menu.find(a=>a.actionId===q.actionId)?.summary,value:q.value,n:d.n,nodes:d.nodes,ms:Math.round(d.ms),afterCargo:{exclusive:afterCargo.exclusive,descendants:afterCargo.descendants,costs,leaf:leaf.status,steps:accepted.map(a=>a.summary),facts:{wallet:facts.wallet,income:facts.income,computer:facts.computer,blue:facts.blue,hand:facts.hand}}}));
 }finally{port.close();m.dispose();}
}
writeZ(out,outRows);
