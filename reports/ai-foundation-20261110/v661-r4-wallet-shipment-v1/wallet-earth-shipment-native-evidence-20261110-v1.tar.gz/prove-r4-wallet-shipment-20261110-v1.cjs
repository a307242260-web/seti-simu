'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),Module=require('node:module');
const file=path.resolve('randomizer/game/ai/analysis-port.js'),load=Module._extensions['.js'],captured=new WeakMap();
globalThis.captureWalletShipEnvelope=(n,e)=>captured.set(n,e);
Module._extensions['.js']=(m,f)=>{
 if(f!==file)return load(m,f);
 const s=fs.readFileSync(f,'utf8'),a='      nodeCount += 1;\n      return node;';
 assert.equal(s.split(a).length,2);
 m._compile(s.replace(a,'      globalThis.captureWalletShipEnvelope(node,envelope);\n'+a),f);
};
const {readZ,writeZ,open}=require('./controlled-r3');
const {createAnalysisPort}=require(file),[source,out]=process.argv.slice(2),{rows}=readZ(source),seat='player-white',result={};
function normalize(s){
 const q=typeof s==='string'?JSON.parse(s):structuredClone(s);
 delete q.meta.rngState;
 for(const v of Object.values(q.aliens))if(v&&v.initialConfiguration===null)delete v.initialConfiguration;
 return q;
}
function direct(m,cap){
 const port=createAnalysisPort({composition:m.c,seatId:seat});
 try{
  const root=port.openRoot();
  port.setDecisionPlanning({finalMarkPlanning:true,scanPlanning:true,rankKnownFossilTraces:true});
  port.setResourcePlanning(true);port.setCardPickPlanning(true);port.setMovementPlanning(true);
  const spec=port.resourceSpec(root),plan=spec?.plans.find(p=>p.goal.kind==='wallet-earth-shipment');
  if(!plan)return null;
  const fix=port.expandResourcePlan(root,plan,(prefix,contexts,charges)=>charges&&prefix>=cap?'controlled-step-limit':null);
  return {plan,fix,end:captured.get(fix.node),steps:fix.prefixes.map(p=>p.action),menu:fix.node.legalActions};
 }finally{port.close();}
}
function facts(m){const f=m.facts();return {credits:f.wallet.credits,energy:f.wallet.energy,data:f.wallet.availableData,taskCount:f.taskCount};}
for(const k of ['keep-amiba9','research-orange3']){
 const {stages,route}=rows[k],root=stages.round4.state,m=open(root);
 try{
  const fixed=direct(m,Infinity),limit=direct(m,1),before=m.save(),taskCount=facts(m).taskCount+1;
  assert.deepEqual(before,root);assert(fixed?.fix.complete);assert.equal(fixed.fix.goalStatus,'completed');
  assert.equal(fixed.plan.goal.paidMovementPoints,route.cost);
  assert.equal(fixed.steps.length,k==='keep-amiba9'?5:8);
  assert.equal(limit.fix.complete,false);assert.equal(limit.fix.stopReason,'controlled-step-limit');assert.equal(limit.steps.length,1);
  const cold=[];let mid;
  fixed.steps.forEach((a,i)=>{
   m.apply(a);
   if(i<fixed.steps.length-2){
    const e=m.save(),next=direct(m,Infinity);
    if(i===0)mid=e;
    if(next?.fix.complete){
     assert.deepEqual(next.steps.map(a=>a.actionId),fixed.steps.slice(i+1).map(a=>a.actionId));
     cold.push({after:i+1,next:next.steps[0].actionId,n:next.fix.submissions});
    }
   }
  });
  const exact=m.save(),ending=facts(m);m.restore(root);fixed.steps.forEach(a=>m.apply(a));assert.deepEqual(m.save(),exact);m.restore(root);
  assert.deepEqual(ending,k==='keep-amiba9'?{credits:10,energy:0,data:2,taskCount}:{credits:8,energy:0,data:2,taskCount});
  assert.deepEqual(normalize(exact.committedState),normalize(fixed.end.committedState));
  result[k]={plan:fixed.plan,steps:fixed.steps,cold,ending,end:exact,mid,limited:{steps:limit.steps.length,complete:limit.fix.complete,reason:limit.fix.stopReason}};
  console.log(JSON.stringify([k,fixed.steps.map(a=>a.summary),ending,cold]));
 }finally{m.dispose();}
}
const stock=rows['research-orange3'].stages.round4.state,insufficient=structuredClone(stock);
{
 const s=JSON.parse(insufficient.committedState),p=s.players.players.find(x=>x.id===seat);
 p.resources.credits=1;insufficient.committedState=JSON.stringify(s);
 const m=open(insufficient);
 try{assert.equal(direct(m,Infinity),null);assert.deepEqual(m.save(),insufficient);}finally{m.dispose();}
}
writeZ(out,{result,insufficient});
