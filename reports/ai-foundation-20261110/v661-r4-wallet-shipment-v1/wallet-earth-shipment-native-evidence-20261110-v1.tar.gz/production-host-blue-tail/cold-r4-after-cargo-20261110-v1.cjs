'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{readZ,open}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [source,index]=process.argv.slice(2),root=readZ(source)[index].root,seat='player-white',m=open(root);
const port=createAnalysisPort({composition:m.c,seatId:seat});
try {
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);
 assert.deepEqual(m.save(),root);
 const {actionId,value,roots,edges}=q;
 console.log(JSON.stringify({actionId,value,roots,edges,n:q.diagnostics.nativeExecutions,nodes:q.diagnostics.graphNodes,
  ms:q.rootAndSearchMilliseconds,completed:q.complete,analysis:q.analysis,rankGraph:q.graph?.map(x=>[x.index,x.status,x.value,x.realization,x.preparationDebt])??null}));
}finally{port.close();m.dispose();}
