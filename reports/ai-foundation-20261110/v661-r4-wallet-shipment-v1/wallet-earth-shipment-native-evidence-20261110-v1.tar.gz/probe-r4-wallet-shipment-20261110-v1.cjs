'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,writeZ}=require('./controlled-r3'),{createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [file,out]=process.argv.slice(2),{rows}=readZ(file),outRows={};
for(const name of ['keep-amiba9','research-orange3']){
 const e=rows[name].stages.round4.state,m=open(e),seat='player-white';
 const port=createAnalysisPort({composition:m.c,seatId:seat});
 try{
  const menu=m.menu(),agent=createSearchAgent({seatId:seat,analysisPort:port}),result=agent.decide({seatId:seat,legalActions:menu}),q=result.search;
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),e);
  const plan=q.lines[0].resourcePolicy?.plans.find(p=>p.goal.kind==='wallet-earth-shipment');
  const root=q.roots.find(r=>r.goal?.kind==='wallet-earth-shipment');
  const edge=q.lines[0].edges.find(e=>e.resourcePlan?.kind==='wallet-earth-shipment'||e.goal?.kind==='wallet-earth-shipment'
    ||e.resourceGoal?.kind==='wallet-earth-shipment'||e.actionId===plan?.firstActionId);
  const d={root:e,n:q.diagnostics.nativeExecutions,nodes:q.diagnostics.graphNodes,ms:q.rootAndSearchMilliseconds,roots:q.roots,value:q.value,chosen:q.actionId,
   plan,candidate:root,edge,analysis:q.analysis,sourceMenu:menu,planEvidence:q.plan};
  outRows[name]=d;
  console.log(JSON.stringify({name,selected:menu.find(a=>a.actionId===q.actionId)?.summary,value:q.value,n:d.n,nodes:d.nodes,ms:Math.round(d.ms),plan,root,edge}));
 }finally{port.close();m.dispose();}
}
writeZ(out,outRows);
