'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{open,z,seat}=require('./native-late-r3');
const [src,report,out]=process.argv.slice(2),d=JSON.parse(z.gunzipSync(fs.readFileSync(src))),rows=JSON.parse(fs.readFileSync(report)).rows;
const {pinkScoreBeforeUnknownFossil:plan}=require(path.resolve('randomizer/game/ai/local-decision-plans'));
const m=open(d.root);
try{
 const displays=m.owner(seat).publicState.board.aliens;
 let unknown=0;
 for(const row of rows){
  for(const a of row.candidates.filter(a=>!a.knownDisplay)){
   assert(row.policy.retained.includes(a.action));assert(!row.quote.some(q=>q.actionId===a.action));unknown++;
  }
 }
 assert.equal(unknown,12);
 m.restore(d.records[0].before);
 const state=m.state(),p=m.player(),actions=m.menu(),base={state,seatId:seat,actions,session:m.save().session.session,
  knownCards:new Set(p.reservedCards.map(c=>c.id)),knownFossilIds:new Set(),
  knownAmibaDisplay:displays.amibaTraces.displayedCardIndex,knownChongDisplay:displays.chongOffer.displayedCardIndex};
 assert(!plan(base).quotes,'a custom evaluator does not opt into V433 cross-species ranking');
 const full={...base,rankKnownFossilTraces:true};
 assert(plan(full).quotes.length>2);
 const ship={surface:'solar-board',kind:'standard',playerId:seat,id:9999};
 const withProbe={...state,pieces:{...state.pieces,rockets:[...state.pieces.rockets,ship]}};
 assert(!plan({...full,state:withProbe}).quotes,'the direct ranking is not a proof of probe opportunity cost');
 const amibaGain=actions.find(a=>a.target.speciesId==='amiba'&&a.target.position===4);
 const noKnown=plan({...full,knownAmibaDisplay:null});
 assert(amibaGain&&noKnown.retainedActionIds.includes(amibaGain.actionId));
 assert.deepEqual(m.save(),d.records[0].before);
 const result={retainedUnknown:unknown,unpricedProbeRetainsFallback:true,customEvaluatorKeepsOldRule:true,rootExact:true};
 fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(result));
}finally{m.dispose();}
