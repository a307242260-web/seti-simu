Unpack the preceding pink-score-dominance evidence bundle to obtain native-pink-fossil-roots-20261110-v1.json.gz; the input archive is shared and is not duplicated here.
Run from the SETI source root:
node <this-dir>/compare-fossil-traces-20261110-v1.cjs <prior-dir>/native-pink-fossil-roots-20261110-v1.json.gz /private/tmp/seti-fossil-quotes.json yes
node <this-dir>/verify-fossil-quote-guards-20261110-v1.cjs <prior-dir>/native-pink-fossil-roots-20261110-v1.json.gz /private/tmp/seti-fossil-quotes.json /private/tmp/seti-fossil-guards.json
Outputs must not exist. For baseline dc2e22346, omit "yes" and use a different output path. All quoted results stop at the same visible menu before selecting any fossil.
