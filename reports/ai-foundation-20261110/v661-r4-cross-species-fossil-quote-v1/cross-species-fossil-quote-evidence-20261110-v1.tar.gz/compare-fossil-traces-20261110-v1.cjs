'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{open,z,seat}=require('./native-late-r3');
const [src,out,verify]=process.argv.slice(2),e=JSON.parse(z.gunzipSync(fs.readFileSync(src))),load=n=>require(path.resolve('randomizer/game/'+n));
const {evaluateStateValue}=load('ai/state-value'),{sanitizeHiddenInformationObservation}=load('rule-composition'),local=load('ai/local-decision-plans');
const m=open(e.root),publicRoot=m.owner(seat),rootBoard=publicRoot.publicState.board.aliens;
const rootDisplay={amiba:rootBoard.amibaTraces.displayedCardIndex,chong:rootBoard.chongOffer.displayedCardIndex};
const known0=new Set([...publicRoot.selfState.hand,...publicRoot.selfState.reservedCards,...publicRoot.publicState.board.publicCards].filter(Boolean).map(c=>c.id));
let inputCount=0;const rows=[];
try{
 for(const [i,r] of e.records.entries()){
  m.restore(r.before);
  const rootNative=m.state(),p=m.player(),actions=m.menu();
  const known=new Set(known0);
  for(const c of p.hand)if(c.cardId===`amiba_${rootDisplay.amiba}.webp`||c.cardId===`chong_${rootDisplay.chong}.webp`)known.add(c.id);
  const before=p.hand.length,options={state:rootNative,seatId:seat,actions,session:r.before.session.session,knownCards:known,
   knownFossilIds:new Set(),rankKnownFossilTraces:true,knownAmibaDisplay:rootDisplay.amiba,knownChongDisplay:rootDisplay.chong};
  // Reserved cards visible from the chosen branch are either root-known or the
  // root-known play that created this queue. No blind reward becomes playable.
  for(const c of p.reservedCards)if(known0.has(c.id)||r.before.session.session.journal.actions.some(x=>x.action.target?.cardInstanceId===c.id))known.add(c.id);
  const input=local.pinkScoreBeforeUnknownFossil(options),alternatives=[];
  for(const a of actions){
   m.restore(r.before);inputCount++;m.apply(a);
   const h=()=>m.save().session?.session?.queue?.[0];
   let gained=null,unknownDisplay=false;
   if(h()?.type==='residual_alien_card_decision'){
    const {speciesId}=h().payload,offered=m.menu().find(b=>b.target?.source==='display');
    if(!offered){alternatives.push({action:a.actionId,target:a.target,open:'no-display'});continue;}
    if(offered.target.cardIndex!==rootDisplay[speciesId])unknownDisplay=true;
    const prior=new Set(m.player().hand.map(c=>c.id));
    inputCount++;m.apply(offered);
    const after=m.player().hand.find(c=>!prior.has(c.id));
    assert(after);
    if(!unknownDisplay)gained=after.id;
   }
   const afterKnown=new Set(known);
   if(gained)afterKnown.add(gained);
   if(h()?.type!=='card_play_domain_effect:decision:chong_pickup_fossil'||!m.menu().every(a=>a.target?.fossilId)){
    alternatives.push({action:a.actionId,target:a.target,open:h()?.type||'committed'});continue;
   }
   const f=m.facts(),observation=sanitizeHiddenInformationObservation(publicRoot,m.owner(seat),{code:'hidden_chong_fossil_offer'},afterKnown);
   const q=evaluateStateValue(observation,seat);
   alternatives.push({action:a.actionId,target:a.target,board:f.wallet.score,established:f.final,handDelta:f.wallet.handSize-before,
    value:q.total,probe:q.components.probePotential,mark:q.components.finalMarkPotential,knownDisplay:!unknownDisplay,
    fossils:m.menu().map(a=>a.actionId),rng:f.rng});
  }
  const closed=alternatives.filter(a=>Number.isFinite(a.value)&&a.knownDisplay);
  if(closed.length)assert(closed.every(a=>JSON.stringify(a.fossils)===JSON.stringify(closed[0].fossils)));
  const best=closed.length?Math.max(...closed.map(a=>a.value)):null;
  if(verify&&input?.quotes?.length){
   const quoted=input.quotes.map(q=>{
    const a=alternatives.find(a=>a.action===q.actionId);
    assert(a&&a.knownDisplay,JSON.stringify({i,q,a}));
    assert.equal(q.established,a.established,JSON.stringify({i,q,a}));
    assert.equal(q.handGain,a.handDelta);
    assert.equal(q.value,a.value,JSON.stringify({i,q,a}));
    return a;
   });
   const top=Math.max(...quoted.map(a=>a.value));
   for(const a of quoted.filter(a=>a.value<top))assert(input.excludedActionIds.includes(a.action));
   assert(quoted.some(a=>a.value===top&&input.retainedActionIds.includes(a.action)));
  }
  rows.push({i,sourceScore:p.resources.score,sourceHand:before,quote:input?.quotes||null,alternativeCount:actions.length,
   candidates:alternatives,policy:input&&{excluded:input.excludedActionIds,retained:input.retainedActionIds},best,
   winners:closed.filter(a=>a.value===best).map(a=>a.target)});
  m.restore(r.before);assert.deepEqual(m.save(),r.before);
 }
 m.restore(e.root);assert.deepEqual(m.save(),e.root);
 fs.writeFileSync(out,JSON.stringify({rows,inputCount,rootAndRngExact:true},null,2)+'\n',{flag:'wx'});
 const counts={};for(const r of rows)for(const a of r.winners){const k=[a.speciesId||'extra',a.position||a.alienSlotId].join(':');counts[k]=(counts[k]||0)+1;}
 console.log(JSON.stringify({menus:rows.length,inputCount,quoted:rows.filter(r=>r.quote).length,winners:counts,closed:rows.reduce((n,r)=>n+r.candidates.filter(a=>a.knownDisplay).length,0)}));
}finally{m.dispose();}
