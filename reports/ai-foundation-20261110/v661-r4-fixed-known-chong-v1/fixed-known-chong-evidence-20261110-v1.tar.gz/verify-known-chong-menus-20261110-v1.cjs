'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{open,z,seat}=require('./native-late-r3');
const load=n=>require(path.resolve('randomizer/game/'+n));
const {createAnalysisPort}=load('ai/analysis-port'),{evaluateStateValue}=load('ai/state-value'),{sanitizeHiddenInformationObservation}=load('rule-composition');
const [src,out]=process.argv.slice(2),records=JSON.parse(z.gunzipSync(fs.readFileSync(src))).menus,rows=[];
assert.equal(records.length,6);
function reversed(source){
 const e=structuredClone(source),committed=JSON.parse(e.committedState);
 for(const s of [committed,e.session.session.baseState,e.session.session.workingState]){
  const c=s.aliens.chong;
  const config=c.initialConfiguration?.cardDeck;
  if(Array.isArray(config)){
   const consumed=config.length-c.cardDeck.length;
   c.initialConfiguration.cardDeck=[...config.slice(0,consumed),...c.cardDeck.slice().reverse()];
  }
  c.cardDeck.reverse();
 }
 e.committedState=JSON.stringify(committed);
 return e;
}
for(const record of records){
 const m=open(record.checkpoint),result={context:record.key,worlds:[]};
 try {
  for(const reverse of [false,true]){
   const input=reverse?reversed(record.checkpoint):record.checkpoint;
   m.restore(input);
   const p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
   try {
    p.setCardPickPlanning(true);p.setResourcePlanning(true);
    const root=p.openRoot(),policy=p.cardPickSpec(root);
    assert.equal(root.observation.publicState.board.aliens.chongOffer.displayedCardIndex,9);
    assert(policy.fixed&&!policy.isEquivalence);assert.equal(policy.reason,'fixed-known-chong-reward');
    const action=root.legalActions.find(a=>a.actionId===policy.selectedActionId);
    assert.equal(action.target.choiceId,'chong:display:9');
    assert.equal(policy.excludedActionIds.length,2);
    const child=p.expand(root,action.actionId),seen=child.observation,compact=p.valueObservation(child);
    const card=seen.selfState.hand.find(c=>c.cardId==='chong_9.webp');
    assert(card?.id,JSON.stringify([record.key,seen.selfState.hand]));
    assert.equal(seen.publicState.board.aliens.chongOffer.displayedCardIndex,null);
    assert.deepEqual(evaluateStateValue(seen,seat),evaluateStateValue(compact,seat));
    assert.deepEqual(m.save(),input);
    const before=m.facts();
    m.apply(action);
    const after=m.facts(),actual=m.owner(seat),masked=sanitizeHiddenInformationObservation(root.observation,actual,{code:'hidden_alien_card'},[card.id]);
    assert.equal(after.wallet.handSize-before.wallet.handSize,1);
    assert.equal(after.hand.find(c=>c[0]===card.id)[1],'chong_9.webp');
    assert.deepEqual(evaluateStateValue(seen,seat),evaluateStateValue(masked,seat));
    const refill=actual.publicState.board.aliens.chongOffer.displayedCardIndex;
    const alts={};
    for(const name of ['blind','cancel']){
     m.restore(input);
     m.apply(m.menu().find(a=>a.target.choiceId==='chong:'+name));
     const facts=m.facts();
     assert.equal(facts.wallet.handSize-before.wallet.handSize,name==='blind'?1:0);
     alts[name]={score:facts.wallet.score,handDelta:facts.wallet.handSize-before.wallet.handSize,display:m.owner(seat).publicState.board.aliens.chongOffer.displayedCardIndex};
    }
    m.restore(input);assert.deepEqual(m.save(),input);
    result.worlds.push({reverse,selected:action.target.choiceId,score:after.wallet.score,knownCard:card.id,refill,
     maskedValue:evaluateStateValue(seen,seat).total,alts});
   }finally{p.close();}
  }
  const [a,b]=result.worlds;
  assert.notEqual(a.refill,b.refill);
  assert.deepEqual([a.selected,a.knownCard,a.score,a.maskedValue],[b.selected,b.knownCard,b.score,b.maskedValue]);
  m.restore(record.checkpoint);assert.deepEqual(m.save(),record.checkpoint);
  rows.push(result);
 }finally{m.dispose();}
}
fs.writeFileSync(out,JSON.stringify({rows,rootAndRngExact:true,displayAndBlindNotEquivalent:true},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({menus:rows.length,hiddenDeckWorlds:rows.length*2,maskedValueStable:true,rootAndRngExact:true}));
