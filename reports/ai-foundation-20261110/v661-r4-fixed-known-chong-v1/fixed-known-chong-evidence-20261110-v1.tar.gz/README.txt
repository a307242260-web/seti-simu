Run from the SETI repository root using the source of this report:
node <archive-dir>/verify-known-chong-menus-20261110-v1.cjs <archive-dir>/satellite-v431-native-menus-20261110-v1.json.gz /private/tmp/seti-chong-known-replay.json
The output path must not exist. Six authentic reward-menu checkpoints are embedded in the capture. The verifier checks both deck orders, the native displayed/hidden/cancel outcomes, the masked value, and unchanged authority/RNG.
