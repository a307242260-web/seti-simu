'use strict';
const fs=require('node:fs'),z=require('node:zlib'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const [infile,outfile]=process.argv.slice(2),d=JSON.parse(z.gunzipSync(fs.readFileSync(infile)));
const root=d['use-free'].start,m=open(root),rows=[],accepted=[];
try{
 for(let i=0;i<45&&!m.state().turn.gameEnded;i++){
  const before=m.save(),q=m.automatic();
  const row={i,action:q.a,native:q.n,ms:q.ms,value:q.value,complete:q.complete};
  rows.push(row);console.log(JSON.stringify([i,q.a?.family,q.a?.summary,q.n,q.ms,q.complete,q.value]));
  assert.deepEqual(m.save(),before);
  assert(q.complete&&q.n<=256&&q.ms<=600,JSON.stringify(row));
  accepted.push(m.apply(q.a));
 }
 const end=m.save(),s=m.state();
 assert(s.turn.gameEnded&&s.match.finalScoringSettled);
 const final=s.match.finalScores.find(p=>p.playerId===seat);
 m.restore(root);for(const a of accepted)m.apply(a);assert.deepEqual(m.save(),end);
 fs.writeFileSync(outfile,z.gzipSync(JSON.stringify({rows,accepted,root,end,final,exact:true})+'\n'),{flag:'wx'});
 console.log(JSON.stringify({score:final.totalScore,rows:rows.length,peakNative:Math.max(...rows.map(x=>x.native)),peakMs:Math.max(...rows.map(x=>x.ms))}));
}finally{m.dispose();}
