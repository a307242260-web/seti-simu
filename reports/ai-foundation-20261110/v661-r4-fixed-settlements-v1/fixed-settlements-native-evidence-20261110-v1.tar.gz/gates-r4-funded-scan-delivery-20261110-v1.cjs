'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open}=require('./native-late-r3'),read=n=>JSON.parse(fs.readFileSync(path.join(__dirname,n))),gz=n=>JSON.parse(z.gunzipSync(fs.readFileSync(path.join(__dirname,n))));
const cases={official:read('v661-r4-full-preflight-20261109-v1.json').checkpoint,
 'teacher265':gz('teacher-r4-first-four-cold-20261110-reuse.json.gz').rows.find(x=>x.decision.input===265).before,
 'teacher272':gz('r4-teacher-after-first-scan-root-20261110-v1.json.gz').rows[0].root};
const out={};
for(const [name,root] of Object.entries(cases)){
 const m=open(root);
 try{
  const q=m.automatic();assert.deepEqual(m.save(),root);
  out[name]={action:q.a?.summary,actionId:q.a?.actionId,value:q.value,native:q.n,milliseconds:q.ms,complete:q.complete,accepted:false,rootExact:true};
  console.log(JSON.stringify([name,out[name]]));
 }finally{m.dispose();}
}
fs.writeFileSync(process.argv[2],JSON.stringify(out,null,2)+'\n',{flag:'wx'});
