'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),z=require('node:zlib');
const {open,seat}=require('./native-late-r3');
const file=path.resolve('randomizer/game/ai/analysis-port.js'),loaded=new Module(file,module);
loaded.filename=file;loaded.paths=Module._nodeModulePaths(path.dirname(file));
const original=fs.readFileSync(file,'utf8'),anchor='    return Object.freeze({ openRoot, expand, identity, hasMovementIntent';
assert.equal(original.split(anchor).length,2);
loaded._compile(original.replace(anchor,'    return Object.freeze({ proofEnvelope:node=>nodes.get(node).envelope, openRoot, expand, identity, hasMovementIntent'),file);
const {createAnalysisPort}=loaded.exports;
const decision=require(path.resolve('randomizer/game/ai/decision-search')),agent=require(path.resolve('randomizer/game/ai/search-agent')),v=require(path.resolve('randomizer/game/ai/state-value'));
const descriptor=JSON.parse(fs.readFileSync('reports/ai-foundation-20261105/third-round-teacher-v1/v300-cold-actual-v298-r4-venus-late-orbit-20261107-v1.json'));
const f=JSON.parse(fs.readFileSync(descriptor.fixture)),root=f.compositionEnvelope,m=open(root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
const proofs=new Map(),evaluate=v.createStateValueEvaluator(seat),results=[];
try{
 const port={...p,turnTailBoundary(n,spec){if(spec.dataPlans?.length)proofs.set(spec,n);return p.turnTailBoundary(n,spec);}};
 const q=decision.searchDecision({port,root:p.openRoot(),evaluate,...agent.OPTIONS,modelKey:evaluate.modelKey,budget:agent.BUDGET});
 assert(q.complete&&q.actionId===descriptor.actionId);
 for(const [spec,source] of proofs){
  const actions=[],before=evaluate(p.valueObservation(source));let n=source;
  for(const item of spec.dataPlans){
   const plan=p.resourceSpec(n).plans.find(x=>x.goal.id===item.goal.id);
   if(!plan)throw Error('missing data plan: '+item.goal.id);
   const found=p.expandResourcePlan(n,plan,()=>null);
   assert(found.complete&&found.node.status!=='plan-infeasible');
   n=found.node;actions.push(...found.prefixes.map(t=>t.action));
  }
  const end=n.legalActions.find(a=>a.family==='end_turn');assert(end);
  actions.push(end);n=p.expand(n,end.actionId);
  while(n.status==='decision'){
   const mark=p.localDecisionSpec(n);assert.equal(mark?.kind,'fixed-final-mark');
   actions.push(n.legalActions.find(a=>a.actionId===mark.selectedActionId));n=p.expand(n,mark.selectedActionId);
  }
  assert.equal(actions.length,spec.requiredNativeInputs);
  const desired=p.proofEnvelope(n),sourceEnv=p.proofEnvelope(source),model=open(root);
  try{
   assert.equal(sourceEnv.session,null);assert(model.c.lifecycle.restore(sourceEnv).ok);
   assert.deepEqual(JSON.parse(model.save().committedState),JSON.parse(sourceEnv.committedState));
   for(const a of actions)model.apply(a);
   const actual=model.save();assert.equal(actual.session,null);assert.equal(desired.session,null);
   assert.deepEqual(JSON.parse(actual.committedState),JSON.parse(desired.committedState));
   const value=evaluate(p.valueObservation(n));
   assert.equal(value,v.sumValueParts([before,spec.netGain]));
   results.push({source:sourceEnv,actions,endpoint:actual,status:n.status,before,value,delta:spec.netGain,goals:spec.dataPlans.map(x=>x.goal.id)});
  }finally{model.dispose();}
 }
 assert.deepEqual(m.save(),root);
 const result={action:q.actionId,value:q.value,native:q.diagnostics.nativeExecutions,rootExact:true,proofs:results.length,
  inputs:results.reduce((n,r)=>n+r.actions.length,0),results};
 fs.writeFileSync(process.argv[2],z.gzipSync(JSON.stringify(result)+'\n'),{flag:'wx'});
 console.log(JSON.stringify({...result,results:undefined}));
}finally{p.close();m.dispose();}

