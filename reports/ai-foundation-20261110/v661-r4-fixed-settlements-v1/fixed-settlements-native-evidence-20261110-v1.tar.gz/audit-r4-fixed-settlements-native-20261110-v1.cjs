'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),assert=require('node:assert/strict'),Module=require('node:module');
const {open,seat}=require('./native-late-r3'),load=n=>JSON.parse(z.gunzipSync(fs.readFileSync(n)));
const [fixture,out]=process.argv.slice(2),root=load(fixture).rows[0].root;
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));let src=fs.readFileSync(file,'utf8');
function add(a,b){assert.equal(src.split(a).length,2);src=src.replace(a,b);}
add('        return rememberPrefix(key,node,actionId,remember(key,child));\n      }\n      const currencyIncome',
 '        globalThis.captureDataProof(dataReward.type,stored.envelope,requested,nodes.get(child).envelope,child,{restoreEnvelope,executeCurrent,snapshot,comp:fork.composition||fork,legalActions});\n        return rememberPrefix(key,node,actionId,remember(key,child));\n      }\n      const currencyIncome');
add('        return rememberPrefix(key,node,actionId,remember(key,finishProvedCommittedState(node,stored,requested,currencyIncome)));',
 '        const child=finishProvedCommittedState(node,stored,requested,currencyIncome);\n        globalThis.captureDataProof("currency",stored.envelope,requested,nodes.get(child).envelope,child,{restoreEnvelope,executeCurrent,snapshot,comp:fork.composition||fork,legalActions});\n        return rememberPrefix(key,node,actionId,remember(key,child));');
const extra='{restoreEnvelope,executeCurrent,snapshot,comp:fork.composition||fork,legalActions}';
for(const [anchor,condition,label] of [
 ['        provedPublicScanChoices++;','stored.envelope.session.session.queue.length===4&&quietMercuryScanStep(stored.envelope.session.session.queue[2])','public-before-mercury'],
 ['        provedScan4QuietMoves++;','stored.envelope.session.session.queue.length===3&&quietMercuryScanStep(stored.envelope.session.session.queue[1])','purple-before-mercury']
]) add(anchor,anchor+'\n        if('+condition+')globalThis.captureDataProof('+JSON.stringify(label)+',stored.envelope,requested,nodes.get(child).envelope,child,'+extra+');');
add('        return rememberPrefix(key,node,actionId,remember(key,finishProvedCommittedState(node,stored,requested,resourceCorner)));',
 '        const child=finishProvedCommittedState(node,stored,requested,resourceCorner);\n'+
 '        globalThis.captureDataProof("resource-corner",stored.envelope,requested,nodes.get(child).envelope,child,'+extra+');\n'+
 '        return rememberPrefix(key,node,actionId,remember(key,child));');
add('          null, stored.informationBarrier, requested, stored, {envelope:menuPreview, inspection});',
 '          null, stored.informationBarrier, requested, stored, {envelope:menuPreview, inspection});\n'+
 '        const preMain=!quietSource.players.players.find(p=>p.id===seatId).mainActionCompleted;\n        if(preMain||!globalThis.checkedFirstPostMain)globalThis.captureDataProof(preMain?"pre-main-data-menu":"first-post-main-data-menu",stored.envelope,requested,nodes.get(child).envelope,child,'+extra+');\n        if(!preMain)globalThis.checkedFirstPostMain=true;');
add('        const child = finishProvedCommittedState(node, stored, requested, state);\n        return rememberPrefix',
 '        const child = finishProvedCommittedState(node, stored, requested, state);\n'+
 '        if(!state.players.players.find(p=>p.id===seatId).mainActionCompleted)globalThis.captureDataProof("pre-main-data-slot",stored.envelope,requested,nodes.get(child).envelope,child,'+extra+');\n'+
 '        return rememberPrefix');
mod._compile(src,file);
const hits=[];
const counts={};
globalThis.captureDataProof=(kind,before,action,after,node,x)=>{
 x.restoreEnvelope(before,true);const applied=x.executeCurrent(action);
 assert(applied.result.ok);
 const native=x.snapshot(x.comp),d=[];
 const visit=(a,b,k)=>{
  if(a===b||d.length>=16)return;
  if(typeof a==="object"&&a&&typeof b==="object"&&b){
   for(const key of new Set([...Object.keys(a),...Object.keys(b)]))visit(a[key],b[key],k+"."+key);
  }else d.push([k,JSON.stringify(a)?.slice(0,90),JSON.stringify(b)?.slice(0,90)]);
 };
 const canonical=e=>{
  const session=e.session?.session?.sessionId,refs=new Set(["effectId","groupId","sessionId","parentEffectId","decisionId"]);
  const normalize=(v,k)=>{
   if(session&&refs.has(k)&&typeof v==="string"&&(v===session||v.startsWith(session+":")))return "<fork-session>"+v.slice(session.length);
   if(!v||typeof v!=="object")return v;
   if(Array.isArray(v))return v.map(x=>normalize(x,null));
   return Object.fromEntries(Object.entries(v).map(([key,x])=>[key,normalize(x,key)]));
  };
  return {...e,committedState:JSON.parse(e.committedState),session:normalize(e.session,null)};
 };
 visit(canonical(native),canonical(after),"");
 assert.equal(d.length,0,JSON.stringify({kind,action:action.summary,d}));
 assert.deepEqual(x.legalActions(x.comp),node.legalActions);
 counts[kind]=(counts[kind]||0)+1;
 hits.push({kind,before,action,after,status:node.status});
 x.restoreEnvelope(after,true);
};
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent')),m=open(root);
const port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
let summary;
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 const diagnostics=port.getDiagnostics();
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 summary={actionId:q.actionId,value:q.value,roots:q.roots.map(r=>[r.actionId,r.value,r.realization,r.preparationDebt,r.completion]),
   native:q.diagnostics.nativeExecutions,counts:[diagnostics.provedComputerIncomeMenus,diagnostics.provedCurrencyIncomeInputs]};
}finally{port.close();m.dispose();}
assert.equal(counts["public-before-mercury"],24);
assert.equal(counts["purple-before-mercury"],24);
assert.equal(counts["resource-corner"],71);
assert.equal(counts["pre-main-data-menu"],18);
assert.equal(counts["first-post-main-data-menu"],1);
assert.equal(counts["pre-main-data-slot"],16);
assert.equal(hits.length,291);
fs.writeFileSync(out,z.gzipSync(JSON.stringify({summary,counts,hits})+'\n'),{flag:'wx'});
console.log(JSON.stringify({native:summary.native,counts,choice:summary.actionId,value:summary.value,exact:true}));
