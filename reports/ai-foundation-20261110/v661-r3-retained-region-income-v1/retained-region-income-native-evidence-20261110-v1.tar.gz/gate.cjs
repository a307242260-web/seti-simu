'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,runCases}=require('./controlled-r3');
const [measurement,output,...ids]=process.argv.slice(2),results=readZ(measurement),rows={};
const roots=Object.keys(results);
for(const id of roots){
 const x=results[id];
 assert(x.complete&&x.n<=256&&x.ms<=600,id+': gate');
}
const ref=results.original;
for(const id of ['original','draw-dlc17','draw-b9','display-chong8-next']){
 const x=results[id];
 assert.deepEqual([x.view,x.menu,x.actionId,x.ranks,x.quotes,x.n],[ref.view,ref.menu,ref.actionId,ref.ranks,ref.quotes,ref.n],id);
 assert.equal(x.menu.find(a=>a.actionId===x.actionId).summary,'amiba_3.webp');
}
for(const id of ids.length?ids:['original','draw-dlc17','draw-b9','display-chong8-next'])rows[id]=runCases(results[id].root,[[id,()=>{}]]);
writeZ(output,rows);
