'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ}=require('./controlled-r3');
const [baseline,candidate,output]=process.argv.slice(2),a=readZ(baseline),b=readZ(candidate),report={};
const norm=x=>JSON.parse(JSON.stringify(x).replaceAll('seti-complete-decision-search-v436','seti-complete-decision-search-v435'));
for(const id of Object.keys(a)){
 const old=a[id],next=b[id];assert.deepEqual(next.root,old.root);
 if(id.startsWith('official')||['beforeAnalysis','afterAnalysis','beforeScan','r172','pinkBeforeReveal'].includes(id)){
  for(const k of ['actionId','value','n','nodes','ranks','graph'])assert.deepEqual(norm(next[k]),norm(old[k]),id+'/'+k);
 }else{
  assert.equal(old.menu.find(x=>x.actionId===old.actionId).summary,'2张牌 → 1信用点');
  assert.equal(next.menu.find(x=>x.actionId===next.actionId).summary,'amiba_3.webp');
  assert.equal(next.n,old.n);assert.equal(next.nodes,old.nodes);
 }
 assert(next.complete&&next.n<=256&&next.ms<=600);
 report[id]={before:[old.menu.find(x=>x.actionId===old.actionId).summary,old.value,old.n,old.ms],
  after:[next.menu.find(x=>x.actionId===next.actionId).summary,next.value,next.n,next.ms],quote:next.quotes,graphNodes:next.nodes};
 console.log(id,JSON.stringify(report[id]));
}
writeZ(output,report);
