'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib');
const [output,roots,native]=process.argv.slice(2),read=p=>JSON.parse(z.gunzipSync(fs.readFileSync(p)));
const cases=read(roots),proof=read(native);
fs.writeFileSync(path.join(output,'fixtures.json'),JSON.stringify([cases.original,cases['draw-b9'],proof.afterPlay,proof.noIncome].map(
 x=>({root:x.root,actionId:x.actionId,value:x.value,n:x.n,quotes:x.quotes,roots:x.ranks}))));
const action=`(async()=>{
 const fixtures=await fetch('/tools/fixtures.json').then(r=>r.json());
 for(const f of fixtures){
  const seed=JSON.parse(f.root.committedState).meta.seed,seat='player-white';
  const k=window.SetiProductionKernel.createSimulationRuleComposition({seed,random:window.SetiRandom.createSeededRandom(seed),
   activePlayerCount:4,trustedProjectionReader:true,projectCounterfactualState:(s,w)=>window.SetiRuleObservation.buildRuleObservation(s,seed,w?.playerId)});
  k.newGame({seed});const c=k.composition;
  try {
   if(!c.lifecycle.restore(f.root).ok)throw Error('restore');
   const before=JSON.stringify(c.lifecycle.save().envelope),port=window.SetiAnalysisPort.createAnalysisPort({composition:c,seatId:seat});
   const menu=c.inspect().session?.decision?.choices||c.inputPort.enumerateActions({});
   const q=window.SetiSearchAgent.createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:menu}).search;
   const quotes=q.lines.filter(a=>a.matchedAnalysisScan?.order==='retained-region-income').map(a=>a.matchedAnalysisScan);
   if(!q.complete||q.unresolved.length||q.actionId!==f.actionId||q.value!==f.value||q.diagnostics.nativeExecutions!==f.n
     ||JSON.stringify(q.roots)!==JSON.stringify(f.roots)||JSON.stringify(quotes)!==JSON.stringify(f.quotes)
     ||JSON.stringify(c.lifecycle.save().envelope)!==before)throw Error('browser changed search, forecast or root: '+JSON.stringify([q.actionId,f.actionId,q.value,f.value]));
  }finally{c.dispose();}
 }
 window.__retainedRegionOK=true;
})()`;
fs.writeFileSync(path.join(output,'browser-smoke-inventory.js'),'module.exports='+JSON.stringify([{id:'retained-region-income-browser',
 file:'randomizer/index.html',readyExpression:'Boolean(window.SetiAnalysisPort&&window.SetiSearchAgent&&window.SetiProductionKernel)',
 actionExpression:action,successExpression:'window.__retainedRegionOK===true',
 obligation:'Shared browser uses the same visible funding quote, cold yellow selection and no-income fallback.',
 counterexample:'Browser changes the settled root, counts, chosen action, quote or fallback.'}])+';\n');
