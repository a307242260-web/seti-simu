'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,writeZ,short}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const x=readZ(__dirname+'/early-reveal-orders-20261110-v1.json.gz'),y=readZ(__dirname+'/early-reveal-matched-funding-20261110-v1.json.gz'),
 official=JSON.parse(fs.readFileSync(__dirname+'/v661-first3-checkpoints.json'));
const origins={...Object.fromEntries(Object.entries(y.same).map(([k,v])=>[k,v.origin])),
 beforeAnalysis:x.fixes[17].origin,afterAnalysis:x.fixes[21].origin,beforeScan:x.fixes[35].origin,
 officialR1:official.roundStarts['1'].envelope,officialR2:official.roundStarts['2'].envelope,officialR3:official.roundStarts['3'].envelope};
if(process.argv.includes('r172')||process.argv.includes('pinkBeforeReveal')){
 const upstream=readZ(__dirname+'/r172-handoffs.json.gz');
 origins.r172=upstream.origins['r172-no-prefix'];
 origins.pinkBeforeReveal=upstream.origins['pink-menu-10'];
}
function evaluate(root){
 const seat='player-white',m=open(root),p=createAnalysisPort({composition:m.c,seatId:seat});
 try{
  const menu=m.menu(),q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:menu}).search;
  assert.deepEqual(m.save(),root);
  const labels=Object.fromEntries(menu.map(a=>[a.actionId,a.summary])),quotes=q.lines.filter(a=>a.matchedAnalysisScan?.order==='retained-region-income').map(a=>a.matchedAnalysisScan);
  return {root,view:m.owner(seat),menu,actionId:q.actionId,value:q.value,complete:q.complete&&!q.unresolved.length,n:q.diagnostics.nativeExecutions,
   ms:q.rootAndSearchMilliseconds,nodes:q.diagnostics.graphNodes,quotes,ranks:q.roots,roots:q.roots.filter(r=>r.value!=null).map(r=>[labels[r.actionId],r.value]),graph:q.lines};
 }finally{p.close();m.dispose();}
}
if(require.main===module){
 const [output,...ids]=process.argv.slice(2),r={};
 for(const id of ids.length?ids:Object.keys(origins)){
  const o=evaluate(origins[id]);r[id]=o;
  console.log(id,JSON.stringify({action:o.roots.find(a=>a[1]===o.value),v:o.value,n:o.n,ms:o.ms,nodes:o.nodes,complete:o.complete,quotes:o.quotes,roots:o.roots}));
 }
 writeZ(output,r);
}
module.exports={origins,evaluate};
