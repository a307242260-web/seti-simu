'use strict';
const path=require('node:path'),fs=require('node:fs'),{execFileSync}=require('node:child_process');
const root=process.cwd(),read=fs.readFileSync,restored=new Map();
fs.readFileSync=function(file,options){
 try{return read.apply(this,arguments);}catch(err){
  if(err.code!=='ENOENT'||typeof file!=='string')throw err;
  const rel=path.relative(root,path.resolve(file));
  if(!/^(adhoc|reports|seti-saves)\/.+\.json$/.test(rel))throw err;
  let bytes=restored.get(rel);
  if(!bytes){
   try {bytes=execFileSync('git',['show','HEAD:'+rel],{cwd:root,maxBuffer:32*1024*1024,stdio:['ignore','pipe','pipe']});}
   catch {throw err;}
   restored.set(rel,bytes);
  }
  const encoding=typeof options==='string'?options:options?.encoding;
  return encoding?bytes.toString(encoding):bytes;
 }
};
