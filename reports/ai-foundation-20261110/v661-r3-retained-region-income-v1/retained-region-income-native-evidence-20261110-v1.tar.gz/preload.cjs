'use strict';
const path=require('node:path'),fs=require('node:fs'),Module=require('node:module');
const dir=process.env.SETI_INCOME_CANDIDATE,load=Module._extensions['.js'],ai=path.resolve('randomizer/game/ai');
const phase=process.env.SETI_INCOME_PHASE||'v468';
const overrides=new Set(['analysis-port','local-decision-plans','decision-search']);
Module._extensions['.js']=(m,file)=>{
 const name=path.basename(file,'.js');
 return path.dirname(file)===ai&&overrides.has(name)?m._compile(fs.readFileSync(path.join(dir,name+'-'+phase+'.js'),'utf8'),file):load(m,file);
};
