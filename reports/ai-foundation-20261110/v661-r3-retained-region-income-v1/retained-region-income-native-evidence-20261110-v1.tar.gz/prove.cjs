'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,short}=require('./controlled-r3');
const {origins,evaluate}=require('./roots.cjs'),local=require(path.resolve('randomizer/game/ai/local-decision-plans'));
const [measurement,output]=process.argv.slice(2),evidence=readZ(measurement);
const d=readZ(__dirname+'/early-reveal-matched-funding-20261110-v1.json.gz'),seat='player-white';
const rows={};
for(const [id,{origin}] of Object.entries(d.same)){
 const m=open(origin),actions=[];
 try{
  const raw=m.state(),known=new Set([...m.player().hand,...m.player().reservedCards,...raw.cards.publicCards.filter(Boolean)].map(c=>c.id));
  const originalIndices=Object.fromEntries(Object.entries(raw.tech.stacks).map(([id,s])=>[id,s.bonusIndex]));
  const take=(f,choice)=>actions.push(m.act(f,a=>choice==null||a.target.choiceId===choice));
  actions.push(m.play('amiba_3.webp'));take('choose_target','trace:yellow:1');
  const q=structuredClone(m.state()),player=q.players.players.find(p=>p.id===seat);
  const unknown=player.hand.filter(c=>!known.has(c.id));assert.equal(unknown.length,1);
  player.hand=player.hand.map(c=>known.has(c.id)?c:{hidden:true,faceUp:false});
  const prediction=local.previewMatchedAnalysisScan({state:q,seatId:seat,knownCards:known,retainedRegion:true,
   amibaOffer:9,chongOffer:{slotId:2,displayedCardIndex:9},knownTech:(id,s)=>s&&!s.bonusHidden&&s.bonusIndex===originalIndices[id]});
  assert.equal(prediction.funding.value,evidence[id].value);
  m.restore(origin);actions.length=0;
  for(const a of d.prefix)actions.push(m.apply(a));
  take('scan');take('choose_target','nebula:sector-3-a');take('choose_card','public:card-61-0:sector-3-a');
  take('choose_target','trace:1:pink:amiba:4');take('choose_card','amiba:display:9');take('complete_task');take('end_turn');
  const end=m.save(),f=short(m),p=prediction.funding.state.players.players.find(p=>p.id===seat);
  assert.deepEqual(p.resources,m.player().resources);
  assert.deepEqual(p.income,m.player().income);
  assert.deepEqual(p.techState,m.player().techState);
  const visibleHand=hand=>hand.map(c=>c.cardId||null).filter(c=>c!==unknown[0].cardId&&c!==null).sort();
  assert.deepEqual(visibleHand(p.hand),visibleHand(m.player().hand));
  assert.deepEqual(m.state().data.sectorSettlements.winsByPlayerId[seat],prediction.funding.state.data.sectorSettlements.winsByPlayerId[seat]);
  assert.equal(m.player().completedTaskCount,p.completedTaskCount);
  m.restore(origin);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  console.log(id,f.wallet,f.income,f.hand,'quote',prediction.funding.value);
  rows[id]={origin,actions,end,final:f,quote:prediction.funding.value,opaqueCard:unknown[0].cardId};
 }finally{m.dispose();}
}
const m=open(origins.original);
try{
 m.play('amiba_3.webp');
 const afterPlay=evaluate(m.save());assert(afterPlay.complete&&afterPlay.n<=256&&afterPlay.ms<=600);
 assert.equal(afterPlay.menu.find(a=>a.actionId===afterPlay.actionId).target.choiceId,'trace:yellow:1');
 rows.afterPlay=afterPlay;
}finally{m.dispose();}
const native=JSON.parse(origins.original.committedState),p=native.players.players.find(p=>p.id===seat),g=native.players.players.find(p=>p.id==='player-green');
for(const [a,b] of [['amiba_1.webp','dlc_11.png'],['chong_7.webp','b_114.webp']]){
 const i=p.hand.findIndex(c=>c.cardId===a),j=g.hand.findIndex(c=>c.cardId===b);
 [p.hand[i],g.hand[j]]=[g.hand[j],p.hand[i]];
}
const h=native.aliens.chong.cardDeck.indexOf(8);
[native.aliens.chong.displayedCardIndex,native.aliens.chong.cardDeck[h]]=[native.aliens.chong.cardDeck[h],native.aliens.chong.displayedCardIndex];
const noIncome=evaluate({...origins.original,committedState:JSON.stringify(native)});
assert(!noIncome.quotes.length);
rows.noIncome=noIncome;
const credit=JSON.parse(origins.original.committedState);
credit.players.players.find(p=>p.id===seat).resources.publicity=5;
const cannotResearch=evaluate({...origins.original,committedState:JSON.stringify(credit)});
assert(!cannotResearch.quotes.length);
rows.cannotResearch=cannotResearch;
writeZ(output,rows);
