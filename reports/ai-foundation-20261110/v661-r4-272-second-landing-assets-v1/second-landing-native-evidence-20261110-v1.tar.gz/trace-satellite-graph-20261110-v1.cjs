'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),z=require('node:zlib');
const {open,seat}=require(process.argv[2]),{createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const root=JSON.parse(fs.readFileSync(process.argv[3])).checkpoint,m=open(root);
const port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 fs.writeFileSync(process.argv[4],z.gzipSync(JSON.stringify(q)),{flag:'wx'});
 console.log(JSON.stringify({action:q.actionId,value:q.value,ms:q.rootAndSearchMilliseconds,diagnostics:q.diagnostics,
 quiet:q.lines.reduce((n,l)=>n+(l.quietClaimEquivalences?.length||0),0)}));
}finally{port.close();m.dispose();}
