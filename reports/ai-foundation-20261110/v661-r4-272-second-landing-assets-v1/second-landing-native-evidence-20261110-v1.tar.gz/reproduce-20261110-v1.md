# Reproduce the #272 paired continuations

Run from an isolated checkout of `3a21f8759`. Apply the previous candidate at
`reports/ai-foundation-20261110/v661-r4-fossil-independent-task-v1/fossil-task-candidate-20261110-v1.patch`.
The archive contains fixed Native replays and diagnostics, not a product strategy patch.

Use Node 22. Set `evidence_dir` to the absolute directory that contains this file,
and `replay_dir` to an empty output directory. The scripts refuse to overwrite output.

```sh
native="$evidence_dir/native-compact-20261110-v1.cjs"
input="$evidence_dir/wallet-replay-input-20261110-v1.json.gz"
ranked="$replay_dir/ranked-first-turn.json.gz"
landing="$replay_dir/ranked-landings.json.gz"
launch="$replay_dir/common-orange1.json.gz"
reverse="$replay_dir/orange-first-held-enceladus.json.gz"
analysis="$replay_dir/common-free-analysis.json.gz"
node "$evidence_dir/replay-root-ranked-20261110-v1.cjs" "$native" "$input" "$evidence_dir/teacher272-v437-opportunity-20261110-v1.json.gz" "$ranked"
node "$evidence_dir/replay-ranked-landings-20261110-v1.cjs" "$native" "$ranked" "$input" "$landing"
node "$evidence_dir/replay-common-orange1-20261110-v1.cjs" "$native" "$landing" "$launch"
node "$evidence_dir/replay-orange-first-held-enceladus-20261110-v1.cjs" "$native" "$landing" "$launch" "$reverse"
node "$evidence_dir/replay-common-free-analysis-20261110-v1.cjs" "$native" "$landing" "$launch" "$reverse" "$analysis"
node "$evidence_dir/replay-scan-surplus-20261110-v1.cjs" "$native" "$landing" "$analysis" "$replay_dir/scan-surplus.json.gz"
```

For an independent single decision with a CPU profile (not a full game):

```sh
node --cpu-prof --cpu-prof-dir="$replay_dir" "$evidence_dir/trace-satellite-graph-20261110-v1.cjs" \
  "$native" "$evidence_dir/teacher272-checkpoint-20261110-v1.json" "$replay_dir/teacher272.json.gz"
```
