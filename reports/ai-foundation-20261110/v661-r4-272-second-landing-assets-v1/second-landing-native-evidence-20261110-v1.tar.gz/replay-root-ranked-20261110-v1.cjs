'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),read=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const load=f=>require(path.resolve('randomizer/game',f));
const {evaluateStateValue}=load('ai/state-value'),{sanitizeHiddenInformationObservation}=load('rule-composition');
const {root,recipes}=read(process.argv[3]),q=read(process.argv[4]),m=open(root),start=m.owner(seat);
const initialKnown=[...start.selfState.hand,...start.selfState.reservedCards,...start.publicState.board.publicCards].filter(Boolean).map(c=>c.id);
const rootTurn=m.state().turn.turnNumber;
function match(a,b){
 return a.family===b.family&&(!b.actionId||a.actionId===b.actionId)&&Object.entries(b.target||{}).every(([k,v])=>{
  if(v&&typeof v==='object')return Object.entries(v).every(([x,y])=>a.target[k]?.[x]===y);return a.target[k]===v;
 });
}
function collect(first){
 const edges=[];let i=0,e=first;
 while(e){
  edges.push(e);i=e.target;
  const n=q.lines[i];
  e=n.edges.find(x=>q.lines[x.target].value===n.value&&q.lines[x.target].distance+x.cost===n.distance
   &&q.lines[x.target].realization===n.realization)
   ||n.edges.find(x=>q.lines[x.target].value===n.value&&q.lines[x.target].distance+x.cost===n.distance);
  assert(e||!n.edges.length,JSON.stringify(n).slice(0,200));
 }
 return {leaf:q.lines[i],steps:edges.flatMap(e=>e.steps||[e.actionId]).map(actionId=>({actionId}))};
}
function run(label,steps,leaf=null){
 m.restore(root);
 const known=new Set(initialKnown),picks={amiba:start.publicState.board.aliens.amibaTraces.displayedCardIndex,
  chong:start.publicState.board.aliens.chongOffer.displayedCardIndex},timeline=[];
 for(const [i,b] of steps.entries()){
  const menu=m.menu(),a=menu.find(a=>b.family?match(a,b):a.actionId===b.actionId);
  assert(a,label+' '+i+' '+JSON.stringify(b)+' '+JSON.stringify(menu.map(c=>c.summary)).slice(0,280));
  const hand=new Set(m.player().hand.map(c=>c.id));
  const held=[a.target?.cardInstanceId,...(a.target?.cardInstanceIds||[]),...(a.target?.cardIds||[])].filter(Boolean);
  assert(held.every(id=>known.has(id)),label+': '+a.summary+' '+held);
  assert(!a.target?.fossilId);
  const display=/^(amiba|chong):display:(\d+)$/.exec(a.target?.choiceId||'');
  if(display)assert.equal(Number(display[2]),picks[display[1]]);
  m.apply(a);
  if(display){const c=m.player().hand.find(c=>!hand.has(c.id));assert(c);known.add(c.id);picks[display[1]]=null;}
  timeline.push(a);
 }
 const end=m.save(),actual=m.owner(seat);
 const obs=sanitizeHiddenInformationObservation(start,actual,{code:'hidden_card_reveal'},known);
 const v=evaluateStateValue(obs,seat),facts=m.facts();
 const stops=leaf?.status==='information-barrier';
 assert(stops||facts.turn===rootTurn+1&&!end.session,label);
 return {label,leaf,actions:timeline,facts,end,value:v.total,parts:v.components,opaque:obs.selfState.hand.filter(c=>c.hidden).length,
  nativeMenu:m.menu().map(a=>[a.actionId,a.summary,a.target])};
}
try{
 const main=m.menu(),rankedScan=q.roots.find(r=>main.find(a=>a.actionId===r.actionId)?.family==='scan');
 const winner=q.lines[0].edges.find(e=>e.actionId===q.actionId),scan=q.lines[0].edges.find(e=>e.target===rankedScan.target);
 assert(winner&&scan);
 const chosen=collect(winner),direct=collect(scan);
 const recipes2=[['orange3-ranked',chosen.steps,chosen.leaf],['scan-ranked',direct.steps,direct.leaf],
  ['scan-teacher',recipes.scan1],['triton-native',recipes.triton1]];
 const rows=recipes2.map(x=>run(...x));assert.deepEqual(recipes2.map(x=>run(...x)),rows);
 m.restore(root);assert.deepEqual(m.save(),root);
 fs.writeFileSync(process.argv[5],z.gzipSync(JSON.stringify({root,rows,rootRestored:true})),{flag:'wx'});
 console.log(JSON.stringify(rows.map(r=>({label:r.label,actions:r.actions.map(a=>a.summary),value:r.value,leaf:r.leaf?.value,f:r.facts.wallet,parts:r.parts,opaque:r.opaque}))));
}finally{m.dispose();}
