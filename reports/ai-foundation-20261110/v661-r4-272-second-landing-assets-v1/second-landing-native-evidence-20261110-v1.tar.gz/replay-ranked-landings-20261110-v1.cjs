'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),read=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const load=f=>require(path.resolve('randomizer/game',f));
const V=load('ai/state-value'),probe=load('ai/probe-capital'),{sanitizeHiddenInformationObservation}=load('rule-composition');
const {root,rows}=read(process.argv[3]),{recipes}=read(process.argv[4]),m=open(root),start=m.owner(seat),report=[];
const initialKnown=[...start.selfState.hand,...start.selfState.reservedCards,...start.publicState.board.publicCards].filter(Boolean).map(c=>c.id);
function run(row,mode,fossilId){
 m.restore(row.end);
 const from=m.facts().turn,steps=[],known=new Set(initialKnown),displays={
  amiba:start.publicState.board.aliens.amibaTraces.displayedCardIndex,chong:start.publicState.board.aliens.chongOffer.displayedCardIndex};
 // Only one prior alien card was acquired, and it was the root's public display.
 for(const a of row.actions){
  const display=/^(amiba|chong):display:(\d+)$/.exec(a.target?.choiceId||'');
  if(!display)continue;
  const species=display[1],c=m.player().hand.find(c=>c.cardId===`${species}_${display[2]}.webp`);
  assert.equal(Number(display[2]),displays[species]);assert(c);
  known.add(c.id);displays[species]=null;
 }
 const value=()=>{
  const obs=sanitizeHiddenInformationObservation(start,m.owner(seat),{code:'hidden_card_reveal'},known),v=V.evaluateStateValue(obs,seat);
  const f=probe.factsFromObservation(obs,seat),q=probe.quote({...f,investment:()=>0,initialInvestmentCapital:0},V.DEFAULT_WEIGHTS);
  return {facts:m.facts(),value:v.total,parts:v.components,quote:q.selected};
 };
 const before=value(),take=(family,predicate=()=>true)=>{
  const prev=new Set(m.player().hand.map(c=>c.id)),legal=m.menu().find(a=>a.family===family&&predicate(a));
  assert(legal,mode+': '+family+' '+JSON.stringify(m.menu().map(a=>[a.summary,a.target])).slice(0,2400));
  const ids=[legal.target?.cardInstanceId,...(legal.target?.cardIds||[]),...(legal.target?.cardInstanceIds||[])].filter(Boolean);
  assert(ids.every(id=>known.has(id)),JSON.stringify([legal.summary,ids]));
  const display=/^(amiba|chong):display:(\d+)$/.exec(legal.target?.choiceId||'');
  if(display)assert.equal(Number(display[2]),displays[display[1]]);
  assert(!legal.target?.fossilId||legal.target.fossilId===fossilId);
  const a=m.apply(legal);steps.push({a,checkpoint:m.save()});
  if(display){const c=m.player().hand.filter(c=>!prev.has(c.id));assert.equal(c.length,1);known.add(c[0].id);displays[display[1]]=null;}
  return a;
 };
 const byId=a=>take(a.family,b=>b.actionId===a.actionId);
 if(mode.startsWith('triton')){
  const plan=before.quote;assert.equal(plan.planet,'neptune');
  for(let j=0;j<plan.payment.energyPurchases+(mode==='triton-hold-ch4'?1:0);j++)
   take('quick_trade',a=>a.target.tradeId==='credits-for-energy');
  const funding=mode==='triton-hold-ch4'?['alien-chong-2-8']:plan.payment.cornerCardIds;
  for(const [j,dir] of plan.route.path.entries()){
   take('move',a=>a.target.rocketId===7&&a.target.deltaX===dir.deltaX&&a.target.deltaY===dir.deltaY);
   take('choose_payment',a=>a.target.choiceId===(funding[j]||'energy'));
  }
  take('land');
  take('choose_target',a=>a.target.landTarget?.satelliteId==='triton'&&a.target.rocketId===7);
  take('complete_task',a=>a.target.ruleId==='b117-orbit-land-count-task');
  take('end_turn');
 }else if(mode==='paid')for(const a of recipes.paid2)byId(a);
 else{
  take('play_card',a=>a.target.cardInstanceId==='alien-chong-6-16');
  take('choose_target',a=>a.target.landTarget?.satelliteId==='enceladus');
  // Same three public scan targets and two already displayed cards as the paid line.
  for(const a of recipes.paid2.slice(3,10))byId(a);
  const options=m.menu();
  assert(options.every(a=>a.target.fossilId&&a.target.planetId==='saturn'));
  take('choose_target',a=>a.target.fossilId===fossilId);
  for(const a of recipes.paid2.slice(10))byId(a);
 }
 const end=m.save(),after=value();assert.equal(after.facts.turn,from+1);assert.equal(end.session,null);
 m.restore(row.end);for(const {a,checkpoint} of steps){m.apply(a);assert.deepEqual(m.save(),checkpoint);}
 return {from:row.label,mode,fossilId:fossilId||null,before,after,steps,end};
}
try{
 const by=s=>rows.find(r=>r.label===s);
 for(const input of [[by('orange3-ranked'),'triton-quoted'],[by('orange3-ranked'),'triton-hold-ch4'],[by('scan-ranked'),'triton-quoted'],
  [by('scan-teacher'),'paid'],[by('scan-teacher'),'held','fossil_06'],[by('scan-teacher'),'held','fossil_01']]){
  const r=run(...input);report.push(r);
 }
 m.restore(root);assert.deepEqual(m.save(),root);
 fs.writeFileSync(process.argv[5],z.gzipSync(JSON.stringify({root,report,rootRestored:true,exactReplay:true})),{flag:'wx'});
 for(const r of report)console.log(JSON.stringify({from:r.from,mode:r.mode,id:r.fossilId,
  values:[r.before.value,r.after.value],now:[r.after.facts.wallet.score,r.after.facts.final],
  wallet:r.after.facts.wallet,hand:r.after.facts.hand,computer:r.after.facts.computer,blue:r.after.facts.blue,parts:r.after.parts}));
}finally{m.dispose();}
