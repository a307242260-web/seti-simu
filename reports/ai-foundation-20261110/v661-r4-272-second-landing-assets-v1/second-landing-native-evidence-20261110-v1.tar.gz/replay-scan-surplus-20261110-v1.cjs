'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),read=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const {root}=read(process.argv[3]),{rows}=read(process.argv[4]),m=open(root);
const {evaluateStateValue}=require(path.resolve('randomizer/game/ai/state-value'));
const result=[];
try{
 for(const row of rows.filter(x=>x.first==='scan'&&x.mode==='held'))for(const mode of ['publicity','card']){
  const before=row.after.checkpoint; m.restore(before);
  assert.deepEqual(m.player().hand.map(c=>c.id).sort(),['alien-amiba-9-20','alien-chong-8-12','card-67-0']);
  const steps=[],act=(...args)=>{const a=m.act(...args);steps.push({a,checkpoint:m.save()});return a;};
  if(mode==='publicity'){
   act('card_corner',a=>a.target.cardInstanceId==='alien-chong-8-12'&&a.payload.kind==='resource');
   act('research_tech');
  }else{
   act('quick_trade',a=>a.target.tradeId==='cards-for-credit');
   for(const id of ['alien-chong-8-12','alien-amiba-9-20'])
    act('choose_payment',a=>a.target.cardInstanceId===id&&a.target.select===true);
   act('choose_payment',a=>a.target.confirm===true);
   act('play_card',a=>a.target.cardInstanceId==='card-67-0');
  }
  act('choose_target',a=>a.target.tileId==='orange3');act('end_turn');
  assert.equal(m.facts().turn,row.after.facts.turn+1);assert(!m.save().session);
  const v=evaluateStateValue(m.owner(seat),seat),facts=m.facts(),checkpoint=m.save();
  assert.equal(facts.tech.ownedTiles.orange3,true);
  assert.deepEqual(facts.rng,row.after.facts.rng);
  m.restore(before);
  for(const {a,checkpoint} of steps){m.apply(a);assert.deepEqual(m.save(),checkpoint);}
  result.push({fossil:row.fossil,mode,steps,end:{value:v.total,parts:v.components,facts,checkpoint}});
 }
 m.restore(root);assert.deepEqual(m.save(),root);
 fs.writeFileSync(process.argv[5],z.gzipSync(JSON.stringify({result,rootRestored:true,exactReplay:true})),{flag:'wx'});
 for(const r of result)console.log(JSON.stringify([r.fossil,r.mode,r.end.value,r.end.facts.final,r.end.facts.wallet]));
}finally{m.dispose();}
