'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),read=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const load=f=>require(path.resolve('randomizer/game',f)),V=load('ai/state-value'),probe=load('ai/probe-capital'),cards=load('cards/deck');
const {sanitizeHiddenInformationObservation}=load('rule-composition');
const {root,report}=read(process.argv[3]),m=open(root),original=m.owner(seat),replays=[];
const originalKnown=new Set([...original.selfState.hand,...original.selfState.reservedCards,...original.publicState.board.publicCards].filter(Boolean).map(c=>c.id));
function run(r){
 const target=r.from==='scan-teacher'?'triton':'enceladus';
 m.restore(r.end);const known=new Set(originalKnown);
 for(const c of m.player().hand)if(c.cardId==='chong_9.webp'&&r.from==='scan-teacher'||c.cardId==='amiba_9.webp'&&r.from!=='orange3-ranked')known.add(c.id);
 const snapshot=()=>{
  const obs=sanitizeHiddenInformationObservation(original,m.owner(seat),{code:'hidden_card_reveal'},known);
  const v=V.evaluateStateValue(obs,seat);
  return {value:v.total,parts:v.components,facts:m.facts(),checkpoint:m.save(),obs};
 };
 let steps=[];
 const take=(family,predicate=()=>true)=>{
  const a=m.menu().find(a=>a.family===family&&predicate(a));
  assert(a,JSON.stringify([r.mode,target,family,m.menu().map(a=>[a.family,a.summary,a.target])]).slice(0,2800));
  const ids=[a.target?.cardInstanceId,...(a.target?.cardIds||[])].filter(Boolean);
  assert(ids.every(id=>known.has(id))&&!a.target?.fossilId,a.summary);
  m.apply(a);steps.push({a,checkpoint:m.save()});return a;
 };
 take('research_tech');
 take('choose_target',a=>a.target.tileId==='orange1');
 take('choose_card',a=>a.target.cardInstanceId==='card-66-0');
 take('end_turn');
 const third=snapshot(),thirdSteps=steps;steps=[];
 assert.equal(third.facts.turn,r.after.facts.turn+1);assert(!third.checkpoint.session);
 const facts=probe.factsFromObservation(third.obs,seat),goals=probe.requirements(facts);
 const goal=goals.find(g=>g.requirementId.endsWith(':'+target)&&g.endpointFamily==='land');
 assert(goal,target);
 const corner=facts.hand.filter(c=>!c.hidden&&cards.getDiscardActionMoveRewardForCard(c)?.movementPoints===1);
 // One fixed shortest route, one movement card per one-point step, and one
 // pair at most. Rank public payments before committing; never use a draw.
 const {cost}=goal.endpointFacts,path=goal.route.path;
 if(!path.every(x=>x.requiredMovePoints===1)||path.length>8||(cost.credits||0)){
  m.restore(r.end);for(const {a,checkpoint} of thirdSteps){m.apply(a);assert.deepEqual(m.save(),checkpoint);}
  delete third.obs;
  return {from:r.from,mode:r.mode,fossilId:r.fossilId,third,thirdSteps,funding:{target,path,cost,outsideFixedFunding:true},fourth:null,fourthSteps:[]};
 }
 const need=(cost.energy||0)+goal.route.cost,funds=facts.player;
 const pairs=facts.hand.filter(c=>!c.hidden&&!corner.includes(c));
 const corners=corner.slice(0,Math.min(path.length,Math.max(0,need-funds.energy)));
 const missing=need-funds.energy-corners.length,buys=Math.min(Math.max(0,missing),Math.floor(funds.credits/2));
 const short=missing-buys,usesPair=short===1&&pairs.length>=2;
 const funding={target,coordinate:goal.route.coordinate,path,cost,corner:corners.map(c=>c.id),buys,short,usesPair};
 let fourth=null;
 if(short<=0||usesPair){
  for(let j=0;j<buys;j++)take('quick_trade',a=>a.target.tradeId==='credits-for-energy');
  if(usesPair){
   take('quick_trade',a=>a.target.tradeId==='cards-for-energy');
   for(const c of pairs.slice(0,2))take('choose_payment',a=>a.target.cardInstanceId===c.id&&a.target.select===true);
   take('choose_payment',a=>a.target.kind==='confirm'&&a.target.confirm===true);
  }
  const id=third.facts.probes.find(p=>!p.kind)?.id;assert(id);
  for(const [j,d] of path.entries()){
   take('move',a=>a.target.rocketId===id&&a.target.deltaX===d.deltaX&&a.target.deltaY===d.deltaY);
   take('choose_payment',a=>a.target.choiceId===(corners[j]?.id||'energy'));
  }
  take('land');
  take('choose_target',a=>a.target.landTarget?.satelliteId===target&&a.target.rocketId===id);
  // No newly refilled display or unknown card is used in the continuation.
  // The Enceladus cases, if reachable, may present extra scans for separate validation.
  if(target==='triton'){take('end_turn');assert.equal(m.facts().turn,third.facts.turn+1);}
  fourth=snapshot();
 }
 m.restore(r.end);
 for(const {a,checkpoint} of [...thirdSteps,...steps]){m.apply(a);assert.deepEqual(m.save(),checkpoint);}
 delete third.obs;if(fourth)delete fourth.obs;
 return {from:r.from,mode:r.mode,fossilId:r.fossilId,third,thirdSteps,funding,fourth,fourthSteps:steps};
}
try{
 for(const r of report)replays.push(run(r));
 m.restore(root);assert.deepEqual(m.save(),root);
 fs.writeFileSync(process.argv[4],z.gzipSync(JSON.stringify({replays,rootRestored:true,exactReplay:true})),{flag:'wx'});
 for(const x of replays)console.log(JSON.stringify({from:x.from,mode:x.mode,fossil:x.fossilId,
  r3:[x.third.value,x.third.facts.final,x.third.facts.wallet],funding:x.funding,r4:x.fourth&&[x.fourth.value,x.fourth.facts.final,x.fourth.facts.wallet]}));
}finally{m.dispose();}
