'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),read=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const {root}=read(process.argv[3]),{replays}=read(process.argv[4]),{results}=read(process.argv[5]),m=open(root),original=m.owner(seat);
const {evaluateStateValue}=require(path.resolve('randomizer/game/ai/state-value'));
const {sanitizeHiddenInformationObservation}=require(path.resolve('randomizer/game/rule-composition'));
const known=new Set([...original.selfState.hand,...original.selfState.reservedCards,...original.publicState.board.publicCards].filter(Boolean).map(c=>c.id));
const inputs=[...results.map(r=>({first:'orange3',mode:r.mode,fossil:r.fossil,before:r.end})),
 ...replays.filter(r=>r.from==='scan-teacher').map(r=>({first:'scan',mode:r.mode,fossil:r.fossilId,before:r.fourth}))];
try{
 const rows=[];
 for(const {first,mode,fossil,before} of inputs){
  m.restore(before.checkpoint);
  const actions=[],apply=(...args)=>{const a=m.act(...args);actions.push({a,checkpoint:m.save()});};
  const fill=6-m.facts().computer.length;assert.equal(fill,first==='scan'?0:3);
  for(let j=0;j<fill;j++){apply('place_data');apply('choose_target',a=>a.target.choiceId==='data:computer');assert(!m.save().session);}
  apply('analyze',a=>a.target.requiredSlot===6);
  apply('choose_target',a=>a.target.choiceId==='trace:1:blue:state-extra');
  apply('end_turn');assert(!m.save().session&&m.facts().turn===before.facts.turn+1);
  const safe=new Set(known);
  if(first==='scan')for(const c of m.player().hand)if(c.cardId==='chong_9.webp'||c.cardId==='amiba_9.webp')safe.add(c.id);
  const o=sanitizeHiddenInformationObservation(original,m.owner(seat),{code:'hidden_card_reveal'},safe);
  const v=evaluateStateValue(o,seat),after={value:v.total,facts:m.facts(),parts:v.components,checkpoint:m.save()};
  assert.equal(after.facts.wallet.score-before.facts.wallet.score,3);
  assert.equal(after.facts.wallet.credits,before.facts.wallet.credits);
  assert.equal(after.facts.wallet.energy,before.facts.wallet.energy);
  m.restore(before.checkpoint);
  for(const {a,checkpoint} of actions){m.apply(a);assert.deepEqual(m.save(),checkpoint);}
  rows.push({first,mode,fossil,fill,actions,after});
 }
 m.restore(root);assert.deepEqual(m.save(),root);
 fs.writeFileSync(process.argv[6],z.gzipSync(JSON.stringify({rows,rootRestored:true,exactReplay:true})),{flag:'wx'});
 for(const r of rows)console.log(JSON.stringify([r.first,r.mode,r.fossil,r.fill,r.after.value,r.after.facts.final,r.after.facts.wallet,r.after.facts.computer,r.after.facts.income]));
}finally{m.dispose();}
