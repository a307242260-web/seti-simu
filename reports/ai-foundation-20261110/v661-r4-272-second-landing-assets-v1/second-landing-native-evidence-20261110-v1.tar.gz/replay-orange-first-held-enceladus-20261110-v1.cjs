'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),read=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const load=f=>require(path.resolve('randomizer/game',f)),V=load('ai/state-value'),{sanitizeHiddenInformationObservation}=load('rule-composition');
const {root}=read(process.argv[3]),{replays}=read(process.argv[4]),m=open(root),original=m.owner(seat);
const known=new Set([...original.selfState.hand,...original.selfState.reservedCards,...original.publicState.board.publicCards].filter(Boolean).map(c=>c.id));
function trial(r,fossil){
 m.restore(r.third.checkpoint);
 const input=m.save(),turn=m.facts().turn,steps=[],useExtraTrade=r.mode==='triton-quoted';
 const act=(family,match=()=>true)=>{
  const a=m.menu().find(x=>x.family===family&&match(x));
  assert(a,JSON.stringify([r.mode,family,m.menu().map(x=>[x.summary,x.target])]).slice(0,3500));
  assert([a.target?.cardInstanceId,...a.target?.cardIds||[]].filter(Boolean).every(id=>known.has(id)),a.summary);
  m.apply(a);steps.push({a,checkpoint:m.save()});return a;
 };
 if(useExtraTrade)act('quick_trade',a=>a.target.tradeId==='credits-for-energy');
 act('quick_trade',a=>a.target.tradeId==='cards-for-energy');
 for(const id of ['alien-chong-8-12','card-30-pass-3-1'])
  act('choose_payment',a=>a.target.cardInstanceId===id&&a.target.select===true);
 act('choose_payment',a=>a.target.kind==='confirm'&&a.target.confirm===true);
 const movements=useExtraTrade?['card-66-0','energy','energy']:['card-66-0','alien-chong-4-14','energy'];
 const ship=r.third.facts.probes.find(p=>!p.kind).id;
 for(const [j,d] of r.funding.path.entries()){
  act('move',a=>a.target.rocketId===ship&&a.target.deltaX===d.deltaX&&a.target.deltaY===d.deltaY);
  act('choose_payment',a=>a.target.choiceId===movements[j]);
 }
 act('play_card',a=>a.target.cardInstanceId==='alien-chong-6-16');
 act('choose_target',a=>a.target.landTarget?.satelliteId==='enceladus'&&a.target.rocketId===ship);
 for(const id of ['sector-3-b','sector-2-a','sector-4-a'])act('choose_target',a=>a.target.nebulaId===id);
 assert(m.menu().every(a=>a.target.fossilId&&a.target.planetId==='saturn'));
 act('choose_target',a=>a.target.fossilId===fossil);
 act('end_turn');
 assert.equal(m.facts().turn,turn+1);assert.equal(m.save().session,null);
 const obs=sanitizeHiddenInformationObservation(original,m.owner(seat),{code:'hidden_card_reveal'},known);
 const v=V.evaluateStateValue(obs,seat),end={facts:m.facts(),value:v.total,parts:v.components,checkpoint:m.save()};
 m.restore(input);for(const {a,checkpoint} of steps){m.apply(a);assert.deepEqual(m.save(),checkpoint);}
 return {mode:r.mode,fossil,steps,end};
}
try{
 const results=[];
 for(const r of replays.filter(r=>r.from==='orange3-ranked'))for(const id of ['fossil_06','fossil_01'])results.push(trial(r,id));
 m.restore(root);assert.deepEqual(m.save(),root);
 fs.writeFileSync(process.argv[5],z.gzipSync(JSON.stringify({results,rootRestored:true,exactReplay:true})),{flag:'wx'});
 for(const r of results)console.log(JSON.stringify({mode:r.mode,fossil:r.fossil,value:r.end.value,final:r.end.facts.final,wallet:r.end.facts.wallet,
  hand:r.end.facts.hand,computer:r.end.facts.computer,tech:r.end.facts.tech}));
}finally{m.dispose();}
