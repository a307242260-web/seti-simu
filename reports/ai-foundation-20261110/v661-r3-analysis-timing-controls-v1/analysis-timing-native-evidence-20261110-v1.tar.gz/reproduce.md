# V661 late analysis timing native controls

Use source dceaf83d0. Unpack the archive and run `node <dir>/verify-late-data.cjs` from the source root for exact Production replay.

To regenerate the checkpoints:
- Extract `formal-r3-roots-20261110-v1.json.gz` from the previous `formal-retention-native-evidence-20261110-v1.tar.gz`. Run late-data.cjs, earliest-analysis.cjs, repeat-data.cjs and blue-before-analysis.cjs with that file as input followed by the new output filename.
- Extract `reserve-upstream-20261110-v1.json.gz` from `blue-data-reserve-native-evidence-20261110-v1.tar.gz`. Run tech-and-scan.cjs with that file, the previous formal roots and the new output.
- Run late-data-roll-forward.cjs with the upstream evidence, then earliest-analysis, late-data and repeat-data outputs, then the new output. Run third-turn.cjs with that roll-forward output and the new output.
- Run blue-first-roll-forward.cjs with the blue-before-analysis output and the new output. Gate failures remain in the record without submitting the proposed move.
