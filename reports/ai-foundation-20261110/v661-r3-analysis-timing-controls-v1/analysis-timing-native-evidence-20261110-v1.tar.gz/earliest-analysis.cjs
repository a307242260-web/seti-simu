'use strict';
const {open,short,readZ,writeZ,runCases}=require('./controlled-r3');
const [file,out]=process.argv.slice(2),d=readZ(file),all={};
const ch=(h,id)=>h.act('choose_target',a=>a.target.choiceId===id);
const computer=h=>{h.act('place_data');ch(h,'data:computer');};
function trace(h,choice){
 h.act('analyze');h.act('choose_target',a=>a.target.choiceId===choice);
 if(h.m.menu().some(a=>a.target.source==='display'))h.act('choose_card',a=>a.target.source==='display');
 h.cut('analyzed');
}
for(const i of [218,219,222,223]){
 const root=d.roots[i].e;
 const m=open(root);
 try{
  const prefix=[];
  const apply=(f,p)=>prefix.push(m.act(f,p));
  while(m.facts().computer.length<6&&m.player().resources.availableData){apply('place_data');apply('choose_target',a=>a.target.target==='computer');}
  if(m.player().mainActionCompleted)apply('end_turn');
  const prepared=m.save(),facts=short(m);
  const q=m.automatic();
  if(!q.complete||q.n>256||q.ms>600){all[i]={root,prepared,prefix,stop:{q}};continue;}
  apply('analyze');
  const nativeMenu=m.menu().filter(a=>a.target.choiceId.includes('trace:1:'));
  const cases=[['prepared-autonomous',()=>{}],...nativeMenu.map(a=>[a.target.choiceId,h=>trace(h,a.target.choiceId)])];
  all[i]={root,prepared,prefix:prefix.slice(0,-1),facts,q:{...q,checkpoint:undefined},...runCases(prepared,cases)};
  console.log('root',i,facts.wallet,q.a?.summary,q.n,q.ms,nativeMenu.map(a=>a.summary));
 }finally{m.dispose();}
}
writeZ(out,all);
