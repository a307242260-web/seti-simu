'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ}=require('./controlled-r3');
const dir=process.argv[2]||__dirname,file=n=>readZ(path.join(dir,'formal-'+n+'-20261110-v1.json.gz'));
let inputs=0,segments=0,maxN=0,maxMs=0,turn3=0;
function replay(root,actions,end){
 const m=open(root);
 try{
  for(const x of actions){
   if(x.n!==undefined){assert(x.n<=256&&x.ms<=600);maxN=Math.max(maxN,x.n);maxMs=Math.max(maxMs,x.ms);}
   m.apply(x.action||x);
  }
  assert.deepEqual(m.save(),end);inputs+=actions.length;segments++;
 }finally{m.dispose();}
}
function round3(x,root=x.root){
 for(const r of x.rows){
  assert(r.replayExact);assert.equal(r.stop,'r4-first-white-main');replay(root,[...r.prefix,...r.actions],r.end);turn3++;
 }
 for(const r of x.failures){replay(root,r.prefix,r.checkpoint);}
}
for(const x of Object.values(file('late-data')))round3(x);
for(const x of Object.values(file('earliest-analysis'))){replay(x.root,x.prefix,x.prepared);round3(x,x.prepared);}
round3(file('repeat-data'));round3(file('blue-before-analysis'));
const x=file('tech-and-scan');round3(x.tech,x.origins[194].e);
for(const r of x.b16)replay(r.scanRoot,[r.a],r.after);
for(const n of ['late-data-roll-forward','blue-first-roll-forward','late-data-third-turn'])
 for(const r of Object.values(file(n)))replay(r.e,r.actions,r.end);
const r=file('late-data-third-turn');
assert.deepEqual(Object.values(r).map(r=>[r.summary.wallet[0],r.summary.established]),[[151,205],[147,203]]);
const data=file('late-data')[235].rows.find(r=>r.label==='analysis-visible-then-amiba-data').settled.summary;
assert.deepEqual([data.wallet[0],data.income[1],data.hand.length],[110,4,1]);
console.log(JSON.stringify({segments,inputs,maxN,maxMs,turn3}));
