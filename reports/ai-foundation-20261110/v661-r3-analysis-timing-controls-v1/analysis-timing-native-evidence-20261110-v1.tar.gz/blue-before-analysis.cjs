'use strict';
const {open,short,readZ,writeZ,runCases}=require('./controlled-r3');
const [file,out]=process.argv.slice(2),d=readZ(file),root=d.roots[220].e;
const ch=(h,id)=>h.act('choose_target',a=>a.target.choiceId===id);
const place=h=>{h.act('place_data');ch(h,'data:computer');};
const prep=h=>{
 ch(h,'tech:blue1:slot:3');place(h);place(h);h.act('place_data');
 h.act('choose_target',a=>a.target.blueSlot===3);h.act('end_turn');h.cut('blue-cash');
};
const analyze=h=>{h.act('analyze');ch(h,'trace:1:blue:amiba:3');h.act('choose_card',a=>a.target.source==='display');h.act('end_turn');h.cut('early-analysis');};
const amiba=h=>{h.take(h.m.play('amiba_5.webp'));h.take(h.m.pick('dlc_17.png'));ch(h,'symbol:red_1');h.cut('amiba-visible-data');};
function settle(h){
 for(const c of ['dlc_17.png','amiba_2.webp'])h.take(h.m.corner(c));
 for(let i=0;i<4;i++)place(h);
 const id=h.m.player().hand.find(c=>c.cardId==='dlc_25.png').id;h.act('choose_card',a=>a.target.cardInstanceId===id);
 h.act('end_turn');h.cut('electric-income');
}
function orange(h,id){
 h.take(h.m.corner('amiba_9.webp'));h.act('research_tech');ch(h,'tech:'+id);
 if(id==='orange1')h.take(h.m.pick('dlc_20.png'));
 h.cut('research');
}
const plan=h=>{prep(h);analyze(h);amiba(h);settle(h);};
const cases=[
 ['known-data-ai-tail',h=>{prep(h);analyze(h);amiba(h);}],
 ['known-data-funded-income',plan],
 ['known-data-late-orange1',h=>{plan(h);orange(h,'orange1');}],
 ['known-data-late-orange3',h=>{plan(h);orange(h,'orange3');}],
];
writeZ(out,{root,...runCases(root,cases)});
