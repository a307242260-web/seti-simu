'use strict';
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [file,out]=process.argv.slice(2),d=readZ(file),rows={};
const ch=(h,id)=>h.act('choose_target',a=>a.target.choiceId===id);
const settledBlue=h=>{h.act('analyze');ch(h,'trace:1:blue:amiba:3');h.act('choose_card',a=>a.target.source==='display');h.cut('analysis');};
const amiba=h=>{h.take(h.m.play('amiba_5.webp'));h.take(h.m.pick('dlc_17.png'));};
const corners=(h,ids)=>ids.forEach(id=>h.take(h.m.corner(id)));
function income(h,id){
 for(let i=0;i<4;i++){h.act('place_data');ch(h,'data:computer');}
 const card=h.m.player().hand.find(c=>c.cardId===id);h.act('choose_card',a=>a.target.cardInstanceId===card?.id);
 h.cut('income');
}
const lateCases=[
 ['red-data-policy',h=>{ch(h,'symbol:red_1');h.cut('red-data');}],
 ['red-data-same-buy-hold-dlc15',h=>{ch(h,'symbol:red_1');h.take(...h.m.swap('b_16.webp','dlc_15.png'));
    h.act('end_turn');settledBlue(h);corners(h,['dlc_17.png','amiba_2.webp']);income(h,'dlc_25.png');}],
 ['red-data-same-buy-hold-amiba2',h=>{ch(h,'symbol:red_1');h.take(...h.m.swap('b_16.webp','dlc_15.png'));
    h.act('end_turn');settledBlue(h);corners(h,['dlc_17.png','dlc_15.png']);income(h,'dlc_25.png');}],
 ['red-data-hold-b16-no-swap',h=>{ch(h,'symbol:red_1');h.act('end_turn');settledBlue(h);
    corners(h,['dlc_17.png','amiba_2.webp']);income(h,'dlc_25.png');}],
 ['red-data-hold-dlc14',h=>{ch(h,'symbol:red_1');h.take(...h.m.swap('b_16.webp','dlc_14.png'));
    h.act('end_turn');settledBlue(h);corners(h,['dlc_17.png','amiba_2.webp']);income(h,'dlc_25.png');}],
];
const earlierCases=[
 ['analysis-visible-card-policy',settledBlue],
 ['analysis-visible-then-amiba-data',h=>{settledBlue(h);h.act('end_turn');amiba(h);ch(h,'symbol:red_1');h.cut('second-main');}],
 ['analysis-visible-then-amiba-points',h=>{settledBlue(h);h.act('end_turn');amiba(h);ch(h,'symbol:red_2');h.cut('second-main');}],
 ['analysis-visible-then-b16',h=>{settledBlue(h);h.act('end_turn');h.take(h.m.play('b_16.webp'));h.cut('blue-scan-open');}],
];
for(const [key,cases] of [[237,lateCases],[235,earlierCases]]){
 const root=d.roots[key].e;rows[key]={root,...runCases(root,cases)};
}
writeZ(out,rows);
