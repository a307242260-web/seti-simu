'use strict';
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),root=d.roots[223].e;
const ch=(h,id)=>h.act('choose_target',a=>a.target.choiceId===id);
function prep(h,payer){
 for(const id of ['amiba_9.webp',payer])h.take(h.m.corner(id));
 h.act('research_tech');ch(h,'tech:blue1:slot:3');
 for(let i=0;i<2;i++){h.act('place_data');ch(h,'data:computer');}
 h.act('place_data');h.act('choose_target',a=>a.target.blueSlot===3);
 h.act('end_turn');h.cut('retained-repeat-card');
}
function analyze(h){h.act('analyze');ch(h,'trace:1:blue:amiba:3');h.act('choose_card',a=>a.target.source==='display');h.cut('analyzed');}
const cases=[
 ['pay-publicity-retain-repeat',h=>prep(h,'b_16.webp')],
 ['pay-publicity-retain-repeat-analyze',h=>{prep(h,'b_16.webp');analyze(h);}],
 ['repeat-dlc17-keep-amiba5',h=>{prep(h,'b_16.webp');analyze(h);h.take(...h.m.swap('amiba_2.webp','dlc_17.png'));
  h.act('end_turn');h.take(h.m.play('dlc_20.png'));h.cut('repeat-open');}],
 ['repeat-dlc15-keep-amiba2',h=>{prep(h,'b_16.webp');analyze(h);h.take(...h.m.swap('amiba_5.webp','dlc_15.png'));
  h.act('end_turn');h.take(h.m.play('dlc_20.png'));h.cut('repeat-open');}],
 ['swap-for-electric-income-source',h=>{prep(h,'dlc_25.png');analyze(h);h.take(...h.m.swap('amiba_2.webp','dlc_17.png'));
  h.act('end_turn');h.take(h.m.play('dlc_20.png'));h.cut('repeat-open');}],
];
writeZ(out,{root,...runCases(root,cases)});
