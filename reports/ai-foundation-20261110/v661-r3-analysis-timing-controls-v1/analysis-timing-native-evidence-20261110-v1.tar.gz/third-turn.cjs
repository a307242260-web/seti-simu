'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),x=readZ(src),rows={};
const id='player-white';
for(const k of ['formal-118','early-118-no-probe']){
 const e=x[k].end,m=open(e),s=short(m),actions=[];
 try{
  let stop,cache=null,root=null;
  for(let i=0;i<45;i++){
   if(m.menu()[0]?.actorId!==id){const a=[];m.advanceOpponents(a);a.forEach(action=>actions.push({action,passive:true}));continue;}
   if(!m.save().session&&short(m).turn>s.turn){stop='third-turn';break;}
   const q=m.automatic(cache);
   if(!root)root={...q,checkpoint:undefined};
   if(!q.complete||q.n>256||q.ms>600){stop={kind:'gate',n:q.n,ms:q.ms,action:q.a};break;}
   cache=q.checkpoint;const action=m.apply(q.a);
   actions.push({action,n:q.n,ms:q.ms,value:q.value});
   if(action.family==='pass'){stop='pass';break;}
  }
  assert(stop);const end=m.save(),summary=short(m);
  m.restore(e);actions.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),end);
  rows[k]={e,root,stop,actions,end,summary};
  console.log(k,JSON.stringify(stop),root.a.summary,JSON.stringify(summary),actions.filter(q=>q.action.actorId===id).map(q=>q.action.summary));
 }finally{m.dispose();}
}
writeZ(out,rows);
