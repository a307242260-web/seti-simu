'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [base,early,last,repeat,out]=process.argv.slice(2),a=readZ(base),b=readZ(early),g=readZ(last),z=readZ(repeat);
const id='player-white',rows={};
for(const [key,e] of [
 ['formal-118',a['r172-no-prefix'].rows[0].settled.state],
 ['early-118-no-probe',b[219].rows.find(r=>r.label==='prepared-autonomous').settled.state],
 ['early-112-blue3-income',b[219].rows.find(r=>r.label==='trace:1:blue:amiba:3').settled.state],
 ['late-110-amiba-red-data',g[235].rows.find(r=>r.label==='analysis-visible-then-amiba-data').settled.state],
 ['late-109-repeat-dlc15',z.rows.find(r=>r.label==='repeat-dlc15-keep-amiba2').settled.state]
]){
 const m=open(e),actions=[],checkpoints=[];
 try{
  const take=action=>actions.push({action,method:'fixed'});
  const other=()=>{const list=[];m.advanceOpponents(list);list.forEach(action=>actions.push({action,method:'passive'}));};
  take(m.act('pass'));take(m.act('choose_card',q=>q.target.cardId==='b_111.webp'));other();
  assert.equal(m.facts().round,4);assert(!m.save().session);
  const opening=m.save(),openingSummary=short(m),startTurn=openingSummary.turn;
  let cache=null,stop=null,observedTurn=startTurn;
  for(let i=0;i<120;i++){
   if(m.menu()[0]?.actorId!==id){other();continue;}
   const summary=short(m);
   if(!m.save().session&&summary.turn>observedTurn){
    checkpoints.push({state:m.save(),summary});
    observedTurn=summary.turn;
    if(checkpoints.length===2){stop='two-turns';break;}
   }
   const q=m.automatic(cache);
   if(!q.complete||q.n>256||q.ms>600){stop={kind:'gate',action:q.a,n:q.n,ms:q.ms};break;}
   cache=q.checkpoint;
   const action=m.apply(q.a);actions.push({action,method:'autonomous',n:q.n,ms:q.ms,value:q.value});
   if(action.family==='pass'){stop='autonomous-pass';break;}
  }
  assert(stop);
  const end=m.save();m.restore(e);actions.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),end);
  rows[key]={e,actions,opening,openingSummary,checkpoints,end,stop};
  console.log(key,JSON.stringify(stop),JSON.stringify(checkpoints.map(x=>x.summary)));
 }finally{m.dispose();}
}
writeZ(out,rows);
