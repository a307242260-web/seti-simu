'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ,runCases}=require('./controlled-r3');
const [upstream,formal,out]=process.argv.slice(2),x=readZ(upstream)['r172-no-prefix'],d=readZ(formal),src=open(x.root);
const origins={};
try{for(const [j,{action}] of x.rows[0].actions.entries()){
 const step=172+j;if([193,194,203,211].includes(step))origins[step]={e:src.save(),summary:short(src),menu:src.menu()};
 src.apply(action);
}}finally{src.dispose();}
const ch=(h,id)=>h.act('choose_target',a=>a.target.choiceId===id);
const tech=origins[194].menu.filter(a=>['purple2','purple3'].includes(a.target.tileId));
const cases=tech.map(a=>[a.target.tileId,h=>{h.take(h.m.apply(a));h.cut('chosen');}]);
const opts=runCases(origins[194].e,cases);
const m=open(d.roots[235].e),after=[];
try{
 m.act('analyze');m.act('choose_target',a=>a.target.choiceId==='trace:1:blue:amiba:3');m.act('choose_card',a=>a.target.source==='display');m.act('end_turn');m.play('b_16.webp');
 const e=m.save(),moves=m.menu();
 for(const v of moves){
  m.restore(e);m.apply(v);const q=m.save(),scans=m.menu().filter(a=>a.target.nebulaId);
  for(const a of scans){m.restore(q);m.apply(a);after.push({v,a,scanRoot:q,after:m.save(),facts:short(m),menu:m.menu()});}
 }
}finally{m.dispose();}
assert(after.length&&after.every(x=>x.facts.wallet[4]===2));
writeZ(out,{origins,tech:opts,b16:after});
