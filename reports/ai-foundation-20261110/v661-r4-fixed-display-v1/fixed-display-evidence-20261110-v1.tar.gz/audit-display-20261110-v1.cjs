'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const [file,out,fixture]=process.argv.slice(2),src=path.resolve('randomizer/game/ai/analysis-port.js');
const m=new Module(src,module),source=fs.readFileSync(src,'utf8');
m.filename=src;m.paths=Module._nodeModulePaths(path.dirname(src));Module._cache[src]=m;
const at='        provedAlienDisplays++;';
assert.equal(source.split(at).length,2);
m._compile(source.replace(at,`
        restoreEnvelope(stored.envelope,true);
        const real=executeCurrent(requested);
        const native=finishChild(real.before,real.result,movementPlanning?nextMovementIntent(node,requested):null,
          stored.resourceControl&&resourceStep(node,stored.resourceControl.goal,stored.resourceControl.operation).kind!=="complete"?stored.resourceControl:null,
          stored.informationBarrier,requested,stored);
        globalThis.auditDisplay(stored.envelope,requested,taskSession.queue,nodes.get(child),nodes.get(native),
          child,native,()=>valueObservation(child),()=>valueObservation(native));
`+at),src);m.loaded=true;
const {open}=require('./native-late-r3');
const {evaluateStateValue}=require(path.resolve('randomizer/game/ai/state-value'));
const rows=[],fixtures=new Map();
globalThis.auditDisplay=(root,action,queue,predicted,native,a,b,viewA,viewB)=>{
  assert.equal(predicted.envelope.session,null);
  assert.equal(native.envelope.session,null);
  const x=JSON.parse(predicted.envelope.committedState),y=JSON.parse(native.envelope.committedState);
  assert.deepEqual(x,y,action.summary+' committed state');
  assert.deepEqual(predicted.informationBarrier,native.informationBarrier);
  assert.deepEqual([a.status,a.boundary,a.legalActions],[b.status,b.boundary,b.legalActions]);
  const av=viewA(),bv=viewB();
  assert.deepEqual(av,bv);
  assert.deepEqual(evaluateStateValue(av,action.actorId),evaluateStateValue(bv,action.actorId));
  const key=action.target.choiceId+':'+queue.length;
  if(!fixtures.has(key))fixtures.set(key,{root,action,end:native.envelope,barrier:b.boundary});
  rows.push({action:action.target.choiceId,queue:queue.map(e=>e.type),barrier:a.boundary,status:a.status,
    value:evaluateStateValue(av,action.actorId).total});
};
const {checkpoint:root}=JSON.parse(fs.readFileSync(file)),k=open(root);
try{
  const r=k.automatic();
  assert(r.complete);
  assert.deepEqual(k.save(),root);
  const result={rows,rootAndRngExact:true,action:r.a.actionId,value:r.value};
  fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
  if(fixture)fs.writeFileSync(fixture,require('node:zlib').gzipSync(JSON.stringify([...fixtures.values()])+'\n'),{flag:'wx'});
  console.log(JSON.stringify({audited:rows.length,action:r.a.actionId,value:r.value,rootAndRngExact:true}));
}finally{k.dispose();}
