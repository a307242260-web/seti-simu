'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),base=d.rows.find(r=>r.label==='fossil_07');
assert(base?.replayExact);
const actions=base.actions.map(x=>x.action);
const income=actions.findIndex(a=>a.family==='choose_card'&&a.target.choiceId?.startsWith('income:'));
const claim=actions.findIndex(a=>a.family==='complete_task'&&a.summary.includes('chong_3'));
assert(income>claim&&claim>=0);
const rows=runCases(d.root,d.menu.map(p=>[p.target.fossilId,h=>{
 h.take(h.m.apply(p));
 for(let i=0;i<=income;i++){
  const expected=actions[i],a=h.m.menu().find(x=>x.actionId===expected.actionId);
  assert(a,expected.summary);
  h.take(h.m.apply(a));
  if(i===claim)h.cut('claimed');
 }
 h.cut('income');
}]));
writeZ(out,{root:d.root,...rows});
