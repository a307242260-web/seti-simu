'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ}=require('./controlled-r3');
const dir=process.argv[2]||__dirname,file=name=>readZ(path.join(dir,name+'-20261110-v1.json.gz'));
const ends={};
let inputs=0;
function replay(e,actions,end){
 const m=open(e);
 try{
  for(const x of actions)m.apply(x.action||x);
  assert.deepEqual(m.save(),end);inputs+=actions.length;
 }finally{m.dispose();}
}
function verify(e,r){
 assert.equal(r.stop,'r4-first-white-main');
 assert(r.replayExact&&r.actions.every(x=>x.n===undefined||x.n<=256&&x.ms<=600));
 replay(e,[...r.prefix,...r.actions],r.end);
}
const choice=file('r3-pickup-choice-native');
replay(choice.origin,choice.prefix,choice.root);
assert.equal(choice.q.a.target.fossilId,'fossil_01');
for(const n of ['r3-pickup-choice-native','r3-pickup-matched-native','r3-pickup-two-blue','r3-pickup-retain-blue-data']){
 const d=file(n);
 assert.equal(d.failures.length,0);
 for(const r of d.rows)verify(d.root||d.e,r);
 ends[n]=Object.fromEntries(d.rows.map(r=>[r.label,r.settled.summary.wallet[0]]));
}
const resume=file('r3-pickup-admission-resume');
for(const [label,{e,q,resume:r}] of Object.entries(resume)){
 assert(q.complete&&q.n<=256&&q.ms<=600&&r.failures.length===0);
 for(const x of r.rows){verify(e,x);assert.equal(x.settled.summary.wallet[0],123);assert.equal(x.settled.summary.income[1],4);}
 assert.equal(q.funding.length,label==='known-menu'?2:0);
}
const hidden=file('r3-pickup-hidden-controls');
for(const [k,r] of Object.entries(hidden)){
 for(const step of ['initial','before'])for(const field of ['obs','menu','a','roots','value','n','funding'])
  assert.deepEqual(r[step][field],hidden.original[step][field]);
 replay(r.e,choice.prefix,r.revealedEnvelope);
}
const upstream=file('r3-pickup-upstream');
for(const r of Object.values(upstream)){
 assert.equal(r.failures.length,0);for(const x of r.rows)verify(r.root,x);
}
assert.equal(upstream['r172-no-prefix'].rows[0].settled.summary.wallet[0],118);
const clean=x=>Object.fromEntries(Object.entries(x).map(([k,{ms,...q}])=>[k,q]));
const base=file('r3-cargo-parity-candidate'),next=file('r3-pickup-formal-parity');
assert.deepEqual(clean(base),clean(next));
assert(Object.values(next).every(q=>q.complete&&q.n<=256&&q.ms<=600));
console.log(JSON.stringify({inputs,standardRoots:Object.keys(next).length,ends}));
