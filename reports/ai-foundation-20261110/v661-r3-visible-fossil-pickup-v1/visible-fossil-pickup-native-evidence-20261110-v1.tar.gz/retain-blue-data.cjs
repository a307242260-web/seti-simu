'use strict';
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),x=readZ(src);
const cases=x.choices.filter(a=>['fossil_06','fossil_07'].includes(a.target.fossilId)).flatMap(a=>[
 [a.target.fossilId+':claim-and-end',h=>{
  h.take(h.m.apply(a));
  h.act('complete_task',q=>q.summary.includes('b_117'));
  h.act('end_turn');h.cut('after-pass-optional-data');
 }],
 [a.target.fossilId+':claim-and-fill',h=>{
  h.take(h.m.apply(a));
  h.act('complete_task',q=>q.summary.includes('b_117'));
  h.act('place_data');h.act('choose_target',q=>q.target.target==='computer');
  h.act('end_turn');h.cut('after-fill-computer');
 }]
]);
writeZ(out,{e:x.e,...runCases(x.e,cases)});
