'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,short,readZ,writeZ,runCases}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [f,out,...suffix]=process.argv.slice(2),d=readZ(f),rows={};
for(const [key,e] of [['known-menu',d.root],['before-menu',d.before],['before-card',d.origin]]){
 const m=open(e),port=createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});
 try{
  const q=createSearchAgent({seatId:'player-white',analysisPort:port}).decide({seatId:'player-white',legalActions:m.menu()}).search;
  assert.deepEqual(m.save(),e);
  const a=m.menu().find(a=>a.actionId===q.actionId),funding=q.lines.filter(r=>r.knownPickupFunding).map(r=>r.knownPickupFunding);
  rows[key]={q:{roots:q.roots,lines:q.lines,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,complete:q.complete,a,value:q.value,funding},e};
  console.log(key,a?.summary,q.value,rows[key].q.n,rows[key].q.ms,JSON.stringify(funding));
 }finally{port.close();m.dispose();}
}
if(suffix[0]==='resume')for(const key of Object.keys(rows)){
 const r=rows[key];
 if(r.q.complete&&r.q.n<=256&&r.q.ms<=600)r.resume=runCases(r.e,[[key,()=>{}]]);
}
writeZ(out,rows);
