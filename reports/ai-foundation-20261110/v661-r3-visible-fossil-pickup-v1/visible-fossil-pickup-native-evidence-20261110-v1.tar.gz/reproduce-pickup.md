# Native pickup evidence (2026-11-10)

Run from the source root on v438: `node <unpacked>/verify-pickup.cjs`.
The verifier replays native submissions only; it does not ask the policy again.

To reproduce the comparisons on the recorded sources:

- `r3-pickup-choice-native` comes from `capture.cjs`, taking the prior release's upstream evidence as input (extract `r3-cargo-upstream-candidate-20261110-v1.json.gz` from the previous report's `current-turn-delivery-upstream-20261110-v1.tar.gz`). Run on base `76bcabc8b`.
- On the same base run `node <unpacked>/matched.cjs <pickup-choice.gz> <matched.gz>`.
- On v438 run `node <unpacked>/gate.cjs <pickup-choice.gz> <resume.gz> resume` and `node <unpacked>/hidden-pickup.cjs <pickup-choice.gz> <hidden-controls.gz>`.
- Extract `v661-r172-preserve-assets-handoffs-20261109-v1.json.gz` from `v661-r172-preserve-assets-evidence-20261109-v1.tar.gz`. On v438 run `upstream-pickup.cjs <handoffs.gz> <upstream.gz>`, `earlier-pickup.cjs <upstream.gz> <two-blue.gz>`, and `retain-blue-data.cjs <two-blue.gz> <retain-blue-data.gz>`.
- The 89 formal root comparison inputs and `parity.cjs` are described in the prior `current-turn-delivery-native-evidence-20261110-v1.tar.gz` archive. Both output files are included here.
