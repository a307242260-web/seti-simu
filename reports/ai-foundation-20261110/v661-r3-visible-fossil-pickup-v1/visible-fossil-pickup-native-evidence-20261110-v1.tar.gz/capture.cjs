'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ,runCases}=require('./controlled-r3');
const [file,out]=process.argv.slice(2),d=readZ(file);
const x=d['before-chong3'],row=x.rows[0],m=open(x.root),prefix=[];
const idx=row.actions.findIndex(a=>a.action.target?.fossilId);
assert(idx>0);
let root,before,menu,q,preAction;
try{
 for(let i=0;i<idx;i++){before=m.save();preAction=row.actions[i].action;prefix.push(m.apply(preAction));}
 root=m.save();menu=m.menu();q=m.automatic();
 assert(q.complete&&q.n<=256&&q.ms<=600);
 console.log('prefix',prefix.map(a=>[a.family,a.summary,a.target]));
 console.log('pre',short(m),'menu',menu.map(a=>[a.actionId,a.summary,a.target]));
 console.log('search',q.n,q.ms,q.a?.summary,q.roots.map(a=>[a.actionId,a.value,a.target]));
 m.restore(x.root);prefix.forEach(m.apply);assert.deepEqual(m.save(),root);
}finally{m.dispose();}
const cases=menu.filter(a=>a.target?.fossilId).map(a=>[a.target.fossilId,({m,take,cut})=>{take(m.apply(a));cut('after-pick');}]);
const result=runCases(root,cases);
writeZ(out,{origin:x.root,root,before,preAction,menu,q:{...q,checkpoint:undefined},prefix,...result});
