'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [f,out]=process.argv.slice(2),x=readZ(f)['before-orange1'],r=x.rows[0],m=open(x.root);
let e,choices,summary;
try{
 for(const {action} of r.actions){
  if(action.target?.fossilId){e=m.save();break;}m.apply(action);
 }
 assert(e);summary=short(m);choices=m.menu();
}finally{m.dispose();}
const cases=choices.map(a=>[a.target.fossilId,({m,take,cut})=>{take(m.apply(a));cut('pickup');}]);
const result=runCases(e,cases);
for(const r of result.rows){
 const m=open(r.start);
 try{
  for(const {action} of r.actions.slice(0,20)){
   m.apply(action);
   console.log(r.label,action.summary,short(m).wallet,short(m).computer,short(m).blue);
  }
 }finally{m.dispose();}
}
writeZ(out,{e,summary,choices,...result});
