'use strict';
const assert=require('node:assert/strict');
const {readZ,writeZ,open}=require('./controlled-r3');
const [source,reference,out]=process.argv.slice(2),trace=readZ(source),snapshots=trace.snapshots;
const m=open(readZ(reference)[9].root),parentIds=new Set();
for(const row of trace.rows){
 if(!row.proved||row.family!=='choose_card')continue;
 const h=snapshots[row.envelopes].session?.session?.queue[0];
 if(h?.payload?.options?.mode==='public'&&h.payload.options.selected===0)parentIds.add(row.envelopes);
}
function canonical(value){if(Array.isArray(value))return value.map(canonical);
 if(value&&typeof value==='object')return Object.fromEntries(Object.keys(value).sort().map(k=>[k,canonical(value[k])]));
 return value;}
const code=x=>JSON.stringify(canonical(x));
const isPublic=a=>a.family==='choose_card'&&a.target?.cardInstanceId&&a.target?.nebulaId;
function read(){
 const e=m.save(),ss=e.session?.session,raw=ss?.workingState||JSON.parse(e.committedState),state=structuredClone(raw);
 const t=state.cards.discardPile;t.sort((a,b)=>String(a.id).localeCompare(String(b.id)));
 const s=state.meta.sequences;delete s.dataToken;
 for(const p of state.players.players){
  for(const d of p.dataState.poolTokens){delete d.id;delete d.index;delete d.slotIndex;}
 }
 const info=ss?.irreversibleBarrier?.code??null;
 const q=ss?.queue.map(x=>[x.type,x.kind,x.ownerId,x.payload])??null;
 return {state,queue:q,barrier:info,menu:m.menu().map(a=>[a.family,a.target]).map(code).sort()};
}
function diff(a,b,keys=[],out=[]){
 if(a===b)return out;
 if(a&&b&&typeof a==='object'&&typeof b==='object'){
  for(const k of new Set([...Object.keys(a),...Object.keys(b)]))diff(a[k],b[k],[...keys,k],out);
 }else out.push([keys.join('.'),a,b]);
 return out;
}
function signature(a){return a.target.choiceId;}
function play(e,first,second){
 assert(m.c.lifecycle.restore(e).ok);
 m.apply(m.menu().find(a=>signature(a)===first));
 if(m.save().session?.session?.queue[0]?.payload?.options?.mode!=='public')return null;
 const b=m.menu().find(a=>signature(a)===second);
 if(!b)return null;
 m.apply(b);
 return read();
}
const rows=[],counts={};
try {
 for(const id of parentIds){
  const root=snapshots[id];assert(m.c.lifecycle.restore(root).ok);
  const actions=m.menu().filter(isPublic);
  for(let i=0;i<actions.length;i++)for(let j=i+1;j<actions.length;j++){
   const x=actions[i],y=actions[j];
   if(x.target.cardInstanceId===y.target.cardInstanceId)continue;
   const a=play(root,signature(x),signature(y)),b=play(root,signature(y),signature(x));
   const sameSector=x.target.nebulaId===y.target.nebulaId;
   const ds=a&&b?diff(a,b):null;
   const group=!ds?'not-both-legal':ds.length===0?'forward-equal':ds.every(([k])=>k.endsWith('.replacementOrder')||k.endsWith('.lastScanNebulaId'))?'only-scan-order-fields':'other-differences';
   const key=[sameSector?'same-sector':'different-sectors',group].join(':');
   counts[key]=(counts[key]??0)+1;
   rows.push({id,a:signature(x),b:signature(y),sameSector,group,differences:ds});
  }
 }
 assert(m.c.lifecycle.restore(readZ(reference)[9].root).ok);
 writeZ(out,{roots:[...parentIds],counts,rows});
 console.log(parentIds.size,rows.length,counts);
}finally{m.dispose();}
