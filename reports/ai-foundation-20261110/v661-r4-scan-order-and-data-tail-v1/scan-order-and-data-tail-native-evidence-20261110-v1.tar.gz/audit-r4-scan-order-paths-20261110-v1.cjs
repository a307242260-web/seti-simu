'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),Module=require('node:module'),crypto=require('node:crypto');
const {readZ,writeZ,open}=require('./controlled-r3');
const [fixture,output]=process.argv.slice(2),root=readZ(fixture)[9].root;
function load(file,transform){
 const f=path.resolve('randomizer/game/ai',file+'.js'),m=new Module(f,module);
 m.filename=f;m.paths=Module._nodeModulePaths(path.dirname(f));
 m._compile(transform(fs.readFileSync(f,'utf8')),f);return m.exports;
}
function inject(s,needle,add){assert.equal(s.split(needle).length,2,needle);return s.replace(needle,add+'\n'+needle);}
const {createAnalysisPort}=load('analysis-port',s=>inject(s,'      return child;\n    }\n\n    function knownPostdrawDataView',`      globalThis.recordScan(child, envelope, sourceAction, barrier, intent, resourceControl, source?.envelope, source?.resourceControl);`));
const {searchDecision}=load('decision-search',s=>inject(s,'    const roots = root.legalActions.map(action => {',`    globalThis.recordGraph(nodes, lines);`));
const {createStateValueEvaluator}=require(path.resolve('randomizer/game/ai/state-value'));
const seat='player-white',m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
const recorded=new WeakMap(),publicEdges=[];
const digest=e=>crypto.createHash("sha256").update(JSON.stringify(e)).digest("hex");
globalThis.recordScan=(node,e,source,barrier,intent,control,before,beforeControl)=>{
 if(source?.family==='choose_card'&&source.target?.choiceId?.startsWith('public:')){
  const h=before?.session?.session?.queue[0];
  if(h?.payload?.options?.mode==='public'){
   publicEdges.push({origin:digest(before),next:digest(e),action:source.target.choiceId,
    step:h.payload.options.selected,status:node.status,goal:beforeControl?.goal?.id||null});
  }
 }
 const ss=e.session?.session,h=ss?.queue[0],mode=h?.payload?.options?.mode,step=h?.payload?.options?.selected;
 if(h?.type==='science_domain_scan_step'||h?.type==='science_domain_scan_action_4'){
  const parent=ss.journal.actions[0]?.action;
  recorded.set(node,{shape:h.type,mode,step,queue:ss.queue.map(x=>x.type),source:parent?.summary,last:source?.target,
   barrier:barrier?.code||null,intent:intent?.goal?.id,control:control?.goal?.id,
   menu:node.legalActions.map(a=>[a.actionId,a.family,a.target]),envelope:e});
 }
};
let evidence;
globalThis.recordGraph=(nodes,lines)=>{
 evidence=lines.map((l,i)=>{
  const e=nodes[i],r=recorded.get(e.node);
  return {node:l.node,status:l.status,value:l.value,realization:l.realization,preparationDebt:l.preparationDebt,distance:l.distance,
   scan:r,edges:l.edges.map(x=>({action:x.actionId,to:x.target,equivalent:x.equivalent,cost:x.cost,goal:x.resourcePlan?.goal.id})),
   alternatives:e.alternatives.map(a=>[a.firstActionId,a.resourcePlan?.goal.id||null]),best:e.best?.actionId,
   nativeMenu:r?null:e.node.legalActions.map(a=>[a.actionId,a.family])};
 });
};
try{
 const n=port.openRoot(),v=createStateValueEvaluator(seat);
 const q=searchDecision({port,root:n,evaluate:v,modelKey:v.modelKey,budget:{transitions:null,nodes:null,frontier:null,milliseconds:null},
 movementPlanning:true,cardPickPlanning:true,resourcePlanning:true,finalMarkPlanning:true,scanPlanning:true,resourceDominance:true,
 moneyCapacityDominance:true,cardTradePruning:true,postMainPruning:true,openingPruning:true,cardChoiceEquivalence:true,planReuse:true});
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 writeZ(output,{root,publicEdges,rows:evidence,q:{action:q.actionId,roots:q.roots,diagnostics:q.diagnostics}});
 console.log(q.actionId,q.diagnostics.graphNodes,q.diagnostics.nativeExecutions,'scan',evidence.filter(x=>x.scan).length);
}finally{port.close();m.dispose();}
