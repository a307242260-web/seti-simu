'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{open,z,seat}=require('./native-late-r3');
const {evaluateStateValue}=require(path.resolve('randomizer/game/ai/state-value'));
const {sanitizeHiddenInformationObservation}=require(path.resolve('randomizer/game/rule-composition'));
const [rootFile,witnessFile,out]=process.argv.slice(2),read=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const root=read(rootFile).rows[0].root,witness=read(witnessFile).witnesses.find(x=>x.label==='ai-selected');
const m=open(root),start=m.owner(seat),rows=[];
const known=new Set([...start.selfState.hand,...start.selfState.reservedCards,...start.publicState.board.publicCards].filter(Boolean).map(c=>c.id));
try{
 for(const variant of ['original','swap-chong8-for-dlc16']){
  m.restore(root);const actions=[],snapshot=()=>({envelope:m.save(),facts:m.facts(),value:evaluateStateValue(sanitizeHiddenInformationObservation(start,m.owner(seat),{code:'hidden_card_reveal'},known),seat).total});
  let change=null;
  for(const a of witness.steps){
   if(variant!=='original'&&a.family==='choose_payment'&&a.target.cardIds?.includes('alien-chong-4-14')){
    assert(change,'swap before the motion');
    actions.push(m.act('choose_payment',x=>x.target.cardIds?.length===1&&x.target.cardIds.includes(change.replacement)));
   }else{
    if(variant!=='original'&&!change&&a.family==='move'){
     const swap=m.swap('chong_8.webp','dlc_16.png');actions.push(...swap);
     change={replacement:m.player().hand.find(c=>c.cardId==='dlc_16.png')?.id};
     assert(known.has(change.replacement));
    }
    actions.push(m.apply(a));
   }
  }
  assert(m.facts().turn===8&&!m.save().session);
  const after=snapshot(),next=[];
  const held=m.player().hand.find(x=>x.cardId==='chong_4.webp');
  if(held){
   const orange=m.state().tech.stacks.orange1;
   assert.equal(orange.bonusId,start.publicState.board.techSupply.stacks.orange1.bonusId);
   next.push(m.play('chong_4.webp'));
   next.push(m.act('choose_target',a=>a.target.tileId==='orange1'));
   if(m.save().session)next.push(m.act('choose_card',a=>known.has(a.target.cardInstanceId)));
   next.push(m.act('end_turn'));
   if(m.save().session)next.push(m.act('accept_optional_effect',a=>a.target.choiceId.startsWith('skip:chong_task:')));
   assert(m.facts().turn===9&&!m.save().session);
  }
  rows.push({variant,change,actions,after,next,nextEnd:held?snapshot():null});
 }
 m.restore(root);assert.deepEqual(m.save(),root);
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({rows,rootExact:true})+'\n'),{flag:'wx'});
 for(const r of rows)console.log(JSON.stringify([r.variant,r.after.value,r.after.facts.wallet,r.after.facts.hand,r.next.map(a=>a.summary),r.nextEnd?.value,r.nextEnd?.facts.wallet,r.nextEnd?.facts.probes]));
}finally{m.dispose();}
