'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {open,z,seat}=require('./native-late-r3');
const {evaluateStateValue}=require(path.resolve('randomizer/game/ai/state-value'));
const {sanitizeHiddenInformationObservation}=require(path.resolve('randomizer/game/rule-composition'));
const read=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const [rootFile,threeFile,out]=process.argv.slice(2);
const root=read(rootFile).rows[0].root,three=read(threeFile),m=open(root),original=m.owner(seat);
const known=new Set(three.known),knownTech=Object.fromEntries(Object.entries(m.state().tech.stacks).map(([k,v])=>[k,[v.bonusIndex,v.bonusId]]));
const rows=[];
function compare(prior,goal){
 m.restore(prior.result.envelope);
 const actions=[],originalTurn=m.facts().turn;
 assert.equal(originalTurn,10);
 const knownBranch=new Set(known);
 for(const c of m.player().hand)if(c.cardId===`amiba_${original.publicState.board.aliens.amibaTraces.displayedCardIndex}.webp`)knownBranch.add(c.id);
 const take=(predicate)=>{const a=m.menu().find(predicate);if(!a)return false;actions.push(m.apply(a));return true;};
 const family=(f,p=()=>true)=>take(a=>a.family===f&&p(a));
 const card=(id,f)=>{const c=m.player().hand.find(x=>x.cardId===id&&knownBranch.has(x.id));return c&&family(f,a=>a.target?.cardInstanceId===c.id);};
 const chooseTech=(id)=>{
  const stack=m.state().tech.stacks[id];
  assert(!stack.bonusHidden,JSON.stringify(stack));
  assert.deepEqual([stack.bonusIndex,stack.bonusId],knownTech[id]);
  assert(family('choose_target',a=>a.target?.tileId===id&&(a.target.blueSlot==null||a.target.blueSlot===4)));
 };
 function chooseAnalyze(){
  assert(family('analyze'));
  assert(family('choose_target',a=>a.target?.traceType==='blue'&&a.target.stateExtra));
 }
 const unavailable=stage=>rows.push({line:prior.label,third:prior.goal,goal,stage,available:false});
 const alternative=prior.goal==='blue3'?'blue4':'blue3';
 if(goal==='discard-amiba9-then-research'){
  if(!card('amiba_9.webp','card_corner')||!family('research_tech'))return unavailable('funding');
  chooseTech(alternative);
 }else if(goal==='discard-dlc15-then-analyze'){
  if(!card('dlc_15.png','card_corner')||!family('place_data'))return unavailable('funding');
  assert(family('choose_target',a=>a.target?.target==='computer'));
  chooseAnalyze();
 }else if(goal==='dlc15-then-research'){
  if(!card('dlc_15.png','play_card'))return unavailable('funding');
  chooseTech(alternative);
 }else if(goal==='chong4-then-research'){
  if(!card('chong_4.webp','play_card'))return unavailable('funding');
  chooseTech('orange1');
 }else if(goal==='analyze'){
  chooseAnalyze();
 }else assert.equal(goal,'stop');
 for(let i=0;i<5&&m.save().session;i++){
  if(m.menu().some(a=>a.family==='choose_card')){
   if(!family('choose_card',a=>known.has(a.target?.cardInstanceId)))return unavailable('all-public-offers-are-new');
  }else assert.fail('unclassified continuation: '+m.menu().map(a=>a.summary).join(', '));
 }
 assert(!m.save().session,JSON.stringify([prior.label,prior.goal,goal,m.menu().map(x=>x.summary)]));
 if(goal!=='stop'){
  assert(family('end_turn'));
  if(goal==='chong4-then-research'&&m.save().session)
   assert(family('accept_optional_effect',a=>a.target?.choiceId?.startsWith('skip:chong_task:')),JSON.stringify(m.menu().map(a=>a.target)));
  assert(!m.save().session,JSON.stringify([prior.label,prior.goal,goal,m.menu().map(x=>x.summary)]));
  assert.equal(m.facts().turn,11);
 }
 const observation=m.owner(seat),publicOnly=sanitizeHiddenInformationObservation(original,observation,{code:'hidden_card_reveal'},knownBranch);
 const value=evaluateStateValue(publicOnly,seat),f=m.facts();
 rows.push({line:prior.label,third:prior.goal,goal,available:true,actions,facts:f,end:m.save(),masked:value.total,
   full:evaluateStateValue(observation,seat).total,components:value.components,opaque:publicOnly.selfState.hand.filter(c=>c.hidden).length});
}
try{
 for(const prior of three.rows.filter(x=>x.available&&x.deposit)){
  const alternatives=prior.label==='triton'
   ?['stop','discard-amiba9-then-research','discard-dlc15-then-analyze']
   :['stop','dlc15-then-research','chong4-then-research','analyze'];
  for(const goal of alternatives)compare(prior,goal);
 }
 m.restore(root);assert.deepEqual(m.save(),root);
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({rows,rootExact:true})+'\n'),{flag:'wx'});
 for(const r of rows)console.log(JSON.stringify([r.line,r.third,r.goal,r.available,r.available&&[r.masked,r.full,r.facts.wallet,r.facts.final,r.opaque,r.actions.map(a=>a.summary)]]));
}finally{m.dispose();}
