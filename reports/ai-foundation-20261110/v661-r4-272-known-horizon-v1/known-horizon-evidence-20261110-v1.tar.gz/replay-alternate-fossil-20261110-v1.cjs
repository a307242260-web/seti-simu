'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),{open,z}=require('./native-late-r3');
const [twoFile,saturnFile,out,mode]=process.argv.slice(2),read=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const two=read(twoFile),teacher=read(saturnFile).variants.find(r=>r.label==='teacher-scan-with-free-move-then-card');
const start=two['before-card'].envelope,actions=teacher.actions.slice(-19),m=open(start);
try{
 const replay=(alternate)=>{
  if(alternate&&mode==='blind-order'){
   const swapped=JSON.parse(start.committedState);
   const deck=swapped.aliens.chong.cardDeck;
   assert.deepEqual(deck,[1,5]);
   deck.reverse();
   m.restore({...start,committedState:JSON.stringify(swapped)});
  }else m.restore(start);
  let options,changed=0;
  const accepted=[];
  for(const old of actions){
   let a=m.menu().find(a=>a.actionId===old.actionId);
   if(old.target?.choiceId?.startsWith('chong-fossil:')){
    options=m.menu().map(a=>a.target.fossilId);
    if(alternate&&mode!=='blind-order'){a=m.menu().find(a=>a.target?.fossilId&&a.target.fossilId!==old.target.fossilId);changed++;}
   }
   assert(a,JSON.stringify([alternate,old.summary]));
   accepted.push(m.apply(a));
  }
  assert.equal(m.save().session,null);
  return {envelope:m.save(),facts:m.facts(),options,accepted,changed};
 };
 const original=replay(false);assert.deepEqual(original.envelope,two.stop.envelope);
 const alternate=replay(true);assert.equal(alternate.changed,mode==='blind-order'?0:1);
 if(mode==='blind-order'){
  assert(alternate.facts.hand.some(([,name])=>name==='chong_5.webp'));
  assert(!alternate.facts.hand.some(([,name])=>name==='chong_1.webp'));
 }
 assert.deepEqual(alternate.facts.wallet,original.facts.wallet);
 assert.deepEqual(alternate.facts.rng,original.facts.rng);
 m.restore(start);assert.deepEqual(m.save(),start);
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({...two,stop:alternate,alternateControl:{options:original.options,walletExact:true,rngExact:true,originalEndpointExact:true,mode:mode||"fossil"}})+'\n'),{flag:'wx'});
 console.log(JSON.stringify({options:original.options,alternate:alternate.accepted.find(a=>a.target?.fossilId)?.summary,wallet:alternate.facts.wallet}));
}finally{m.dispose();}
