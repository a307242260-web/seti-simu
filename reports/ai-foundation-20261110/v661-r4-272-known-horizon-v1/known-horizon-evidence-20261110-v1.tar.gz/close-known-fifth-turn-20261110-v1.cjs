'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{open,z,seat}=require('./native-late-r3');
const {evaluateStateValue}=require(path.resolve('randomizer/game/ai/state-value'));
const {sanitizeHiddenInformationObservation}=require(path.resolve('randomizer/game/rule-composition'));
const [rootFile,fifthFile,fourFile,alternateFile,out,variantOnly]=process.argv.slice(2),read=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const root=read(rootFile).rows[0].root,m=open(root),start=m.owner(seat),known=new Set([...start.selfState.hand,...start.selfState.reservedCards,...start.publicState.board.publicCards].filter(Boolean).map(c=>c.id));
const pre=read(fifthFile).rows,base=read(fourFile).rows,alternate=read(alternateFile).rows,rows=[];
try{
 for(const [line,variant,four,goal] of [['triton','original',base,'discard-amiba9-then-research'],['enceladus','original',base,'chong4-then-research'],['enceladus',variantOnly||'alternate-fossil',alternate,'chong4-then-research']].filter(([,variant])=>!variantOnly||variant===variantOnly)){
  const ref=four.find(x=>x.line===line&&x.third==='blue4'&&x.goal===goal),trial=pre.find(x=>x.line===line);
  assert(trial.gate);m.restore(ref.end);
  const accepted=[],byId=a=>m.menu().find(x=>x.actionId===a.actionId&&x.actorId===seat);
  const take=a=>{assert(a);accepted.push(m.apply(a));};
  const safe=new Set(known);
  for(const c of m.player().hand)if(c.cardId===`amiba_${start.publicState.board.aliens.amibaTraces.displayedCardIndex}.webp`)safe.add(c.id);
  for(const a of trial.replay.actions){
   if(a.family==='complete_task')break;
   const legal=byId(a);assert(legal,a.summary);
   assert(!legal.target.fossilId&&Object.entries({...legal.target,...legal.payload}).every(([k,v])=>
    k==='cardInstanceId'?v==null||safe.has(v):['cardIds','cardInstanceIds'].includes(k)?v.every(id=>safe.has(id)):true));
   take(legal);
  }
  if(m.facts().turn===11)take(m.menu().find(a=>a.family==='end_turn'));
  if(m.save().session)take(m.menu().find(a=>a.family==='accept_optional_effect'&&a.target.choiceId.startsWith('skip:chong_task:')));
  assert(m.facts().turn===12&&!m.save().session);
  const observation=sanitizeHiddenInformationObservation(start,m.owner(seat),{code:'hidden_card_reveal'},safe);
  const value=evaluateStateValue(observation,seat),facts=m.facts();
  rows.push({line,variant,actions:accepted,facts,value:value.total,components:value.components,end:m.save()});
 }
 m.restore(root);assert.deepEqual(m.save(),root);
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({rows,rootExact:true})+'\n'),{flag:'wx'});
 for(const r of rows)console.log(JSON.stringify([r.line,r.variant,r.value,r.facts.wallet,r.facts.final,r.components,r.actions.map(a=>a.summary)]));
}finally{m.dispose();}
