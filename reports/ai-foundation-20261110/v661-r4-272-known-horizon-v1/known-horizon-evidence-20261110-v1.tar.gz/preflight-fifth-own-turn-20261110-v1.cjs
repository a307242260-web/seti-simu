'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path'),{open,z,seat}=require('./native-late-r3');
const {evaluateStateValue}=require(path.resolve('randomizer/game/ai/state-value'));
const [rootFile,fourFile,out]=process.argv.slice(2),read=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const root=read(rootFile).rows[0].root,m=open(root),start=m.owner(seat),known=new Set([...start.selfState.hand,...start.selfState.reservedCards,...start.publicState.board.publicCards].filter(Boolean).map(c=>c.id));
const controls=read(fourFile).rows,rows=[];
try{
 for(const [line,goal] of [['triton','discard-amiba9-then-research'],['enceladus','chong4-then-research']]){
  const ref=controls.find(x=>x.line===line&&x.third==='blue4'&&x.goal===goal);
  m.restore(ref.end);
  const before=m.facts(),q=m.automatic(),gate=q.complete&&q.n<=256&&q.ms<=600;
  assert.deepEqual(m.save(),ref.end);
  const saved={line,goal,before,gate,search:{action:q.a,value:q.value,native:q.n,ms:q.ms,complete:q.complete}};
  if(gate&&q.checkpoint?.plan?.rows){
   const actions=[],uses=[];
   const safe=new Set(known);
   for(const c of m.player().hand)if(c.cardId===`amiba_${start.publicState.board.aliens.amibaTraces.displayedCardIndex}.webp`)safe.add(c.id);
   let stop='certificate-finished';
   for(const row of q.checkpoint.plan.rows){
    if(m.facts().turn!==before.turn){stop='turn-closed';break;}
    const a=m.menu().find(x=>x.actionId===row.actionId&&x.actorId===seat);
    if(!a){stop='native-menu-differs';break;}
    if(a.family==='pass'){stop='pass-before-round-end';break;}
    const names=Object.entries({...a.target,...a.payload}).flatMap(([k,v])=>k==='cardInstanceId'?[v]:['cardIds','cardInstanceIds'].includes(k)?v||[]:[]);
    if(names.some(id=>id!=null&&!safe.has(id))){stop='new-identity';break;}
    if(a.target?.fossilId){stop='fossil-identity';break;}
    uses.push(...names);actions.push(m.apply(a));
   }
   saved.replay={actions,uses,stop,closed:m.facts().turn!==before.turn&&!m.save().session,end:m.save(),facts:m.facts(),
    currentValue:evaluateStateValue(m.owner(seat),seat).total};
  }
  rows.push(saved);
 }
 m.restore(root);assert.deepEqual(m.save(),root);
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({rows,rootExact:true})+'\n'),{flag:'wx'});
 for(const r of rows)console.log(JSON.stringify([r.line,r.search.action?.summary,r.search.value,r.search.native,r.search.ms,r.gate,r.replay?.stop,r.replay?.actions.map(a=>a.summary),r.replay?.currentValue,r.replay?.facts.wallet]));
}finally{m.dispose();}
