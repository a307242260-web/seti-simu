'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {open,z,seat}=require('./native-late-r3');
const {evaluateStateValue}=require(path.resolve('randomizer/game/ai/state-value'));
const {sanitizeHiddenInformationObservation}=require(path.resolve('randomizer/game/rule-composition'));
const read=f=>JSON.parse(z.gunzipSync(fs.readFileSync(f)));
const [rootFile,twoFile,out,only]=process.argv.slice(2);
const root=read(rootFile).rows[0].root,two=read(twoFile),model=open(root),original=model.owner(seat);
const known=new Set([...original.selfState.hand,...original.selfState.reservedCards,...original.publicState.board.publicCards].filter(Boolean).map(c=>c.id));
const originalTech=new Map(Object.entries(original.publicState.board.techSupply.stacks).map(([k,t])=>[k,[model.state().tech.stacks[k].bonusIndex,t.bonusId]]));
const rows=[];
function run(label,source,goal,deposit=false){
 model.restore(source);
 const before=model.facts(),actions=[];
 assert.equal(before.round,4);assert.equal(before.turn,9);assert.equal(model.state().turn.currentPlayerId,seat);
 const seen=new Set(known);
 // The already public Amiba 9 could be identified when received. No blind
 // card or replenished public offer may pay or steer a later input.
 const publicAlien=original.publicState.board.aliens.amibaTraces.displayedCardIndex;
 for(const c of model.player().hand)if(c.cardId===`amiba_${publicAlien}.webp`)seen.add(c.id);
 const start=model.save();
 const take=(pred)=>{const a=model.menu().find(pred);if(!a)return false;actions.push(model.apply(a));return true;};
 const family=(f,p=()=>true)=>take(a=>a.family===f&&p(a));
 const hasFamily=(f)=>model.menu().some(a=>a.family===f);
 const end=()=>{
  const s=model.facts(),envelope=model.save(),current=model.owner(seat);
  const visible=sanitizeHiddenInformationObservation(original,current,{code:'hidden_card_reveal'},seen);
  const value=evaluateStateValue(visible,seat),full=evaluateStateValue(current,seat);
  return {facts:s,envelope,masked:value.total,full:full.total,components:value.components,opaque:visible.selfState.hand.filter(c=>c.hidden).length,
    menu:model.menu().map(a=>[a.family,a.summary])};
 };
 if(goal==='analyze'){
  if(!family('analyze'))return rows.push({label,goal,deposit,available:false,stage:'main-action'});
  assert(take(a=>a.target?.traceType==='blue'&&a.target.stateExtra),'trace must use an extra slot, no card draw');
 }else{
  if(model.state().tech.stacks[goal].bonusIndex!==originalTech.get(goal)[0]||model.state().tech.stacks[goal].bonusId!==originalTech.get(goal)[1]||!family('research_tech'))
   return rows.push({label,goal,deposit,available:false,stage:'main-action'});
  assert(take(a=>a.target?.tileId===goal&&a.target.blueSlot===3),goal);
 }
 for(let i=0;i<6&&model.save().session;i++){
  if(hasFamily('choose_card'))assert(family('choose_card',a=>known.has(a.target?.cardInstanceId)),'no root-known public card');
  else if(hasFamily('accept_optional_effect'))assert(family('accept_optional_effect',a=>a.target?.choiceId?.includes('amiba1-blue-tech')&&a.target.choiceId.startsWith('confirm:')),'unknown trigger');
  else if(hasFamily('choose_target'))assert(family('choose_target',a=>a.target?.slotId==='blue_1'&&a.target?.symbolId),'unexpected target');
  else assert.fail('unclassified native continuation');
 }
 assert.equal(model.save().session,null);
 if(deposit&&model.player().resources.availableData>0&&family('place_data')){
  if(label==='enceladus'){
   assert(take(a=>a.target?.blueSlot===3),'new blue slot is available');
   if(model.save().session)assert(family('choose_card',a=>known.has(a.target?.cardInstanceId)));
  }else{
   assert(take(a=>a.target?.target==='computer'),'regular computer placement');
  }
 }
 assert.equal(model.save().session,null);
 const preEnd=end();assert(family('end_turn'));
 assert.equal(model.save().session,null);
 assert.equal(model.facts().turn,10);
 const result=end();rows.push({label,goal,deposit,available:true,source:start,actions,preEnd,result});
}
try{
 for(const [label,source] of [['triton',two.replayed.end],['enceladus',two.stop.envelope]].filter(([label])=>!only||label===only))for(const [goal,deposit] of [['blue4',false],['blue4',true],['blue3',false],['blue3',true],['analyze',false]])run(label,source,goal,deposit);
 model.restore(root);assert.deepEqual(model.save(),root);
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({rows,known:[...known],rootExact:true})+'\n'),{flag:'wx'});
 for(const r of rows)console.log(JSON.stringify([r.label,r.goal,r.deposit,r.available,r.result&&[r.result.facts.wallet,r.result.facts.final,r.result.masked,r.result.full,r.result.opaque,r.actions.map(x=>x.summary)]]));
}finally{model.dispose();}
