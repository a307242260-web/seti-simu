from pathlib import Path
import sys
root = Path(sys.argv[1]) / 'randomizer/game/ai'
p = root / 'analysis-port.js'
a = p.read_text()
def replace(old,new):
    global a
    assert a.count(old)==1,old
    a=a.replace(old,new)
replace('''        if(child.status==="stable"&&knownRootAlienIds.has("虫")
          &&Object.keys(currencyIncome.aliens.chong?.transportTasksByRocketId||{}).length===1){
          const p=currencyIncome.players.players.find(x=>x.id===seatId);
          const before=readIdentityState(stored.envelope).players.players.find(x=>x.id===seatId);
          if(p.mainActionCompleted&&p.income.energy>before.income.energy){
            const settled=nodes.get(child),view=readPlanningState(settled),owner=view.players.players.find(x=>x.id===seatId);
            const paid=paidIncomeEarthCargoPlan(child,settled,view,owner);
            if(paid)settled.paidCargoPlan=freeze(paid);
          }
        }''','''        keepPaidIncomeCargoPlan(child,currencyIncome,()=>readIdentityState(stored.envelope));''')
replace('''    function paidCargoProvedBoundary(node,plan){''','''    function keepPaidIncomeCargoPlan(child,state,beforeState){
      if(child.status!=="stable"||!knownRootAlienIds.has("虫")
        ||Object.keys(state.aliens.chong?.transportTasksByRocketId||{}).length!==1)return;
      const player=state.players.players.find(x=>x.id===seatId);
      if(!player.mainActionCompleted||player.income.energy<=beforeState().players.players.find(x=>x.id===seatId).income.energy)return;
      const settled=nodes.get(child),view=readPlanningState(settled),owner=view.players.players.find(x=>x.id===seatId);
      const paid=paidIncomeEarthCargoPlan(child,settled,view,owner);
      if(paid)settled.paidCargoPlan=freeze(paid);
    }

    // Existing data pays for each computer slot and the plan names its one
    // known income card. There are no draws, payment choices or observers.
    // Close only the preparation; the settled state still competes normally.
    function fundedComputerIncomePrefix(node,plan){
      const stored=nodes.get(node),goal=plan.goal;
      if(node.status!=="stable"||!stored||goal.kind!=="income"||goal.targetComputerSlot!==4
        ||Object.keys(goal).some(k=>!["id","kind","incomeCardId","incomeBefore","targetComputerSlot","required"].includes(k))
        ||Object.keys(goal.required).length||plan.operation?.finalPlacement!==false||Object.keys(plan.operation).length!==1)return null;
      const action=node.legalActions.find(a=>a.actionId===plan.firstActionId),state=action&&quietDataMenuSource(stored,action);
      if(!state)return null;
      const owner=state.players.players.find(p=>p.id===seatId),known=knownCards(stored.envelope);
      const id=goal.incomeCardId,ix=owner.hand.findIndex(c=>c.id===id),card=owner.hand[ix];
      if(!owner.mainActionCompleted||!card||!known.has(id)||owner.reservedCards.some(c=>!known.has(c.id))
        ||Object.values(owner.income).reduce((a,b)=>a+b,0)!==goal.incomeBefore)return null;
      const income=cards.getIncomeGainForCard(card),keys=Object.keys(income||{});
      if(keys.length!==1||!["credits","energy","publicity"].includes(keys[0])||income[keys[0]]!==1)return null;
      const slots=data.listComputerPlacedTokens(owner),remaining=4-slots.length;
      if(remaining<1||!slots.every((s,i)=>s.placementSlot===i+1)
        ||owner.resources.availableData!==owner.dataState.poolTokens.length||owner.resources.availableData<remaining)return null;
      const player=copyForkData(owner);
      for(let slot=slots.length+1;slot<=4;slot++){
        const placed=data.placeDataToComputer(player);
        if(!placed.ok||placed.placementKind!=="computer"||placed.placementSlot!==slot)return null;
        if(slot===4&&(placed.slotBonuses.length!==1||placed.slotBonuses[0].type!=="income"))return null;
        const events=[{type:"placeData",playerId:seatId,placementKind:"computer",placementSlot:slot}];
        for(const bonus of placed.slotBonuses){
          if(slot===4)break;
          const key=bonus.type;
          if(!["credits","energy","publicity","score"].includes(key)||!Number.isSafeInteger(bonus[key])||bonus[key]<=0
            ||Object.keys(bonus).some(k=>k!=="type"&&k!==key))return null;
          const gain={[key]:bonus[key]};
          players.gainResources(player,gain,"blueTechScore");
          events.push({type:"science_resource_bonus",playerId:seatId,gain,sourceKey:"blueTechScore"});
        }
        if(events.some(e=>cardEffects.collectMatchingTriggers(player,e).length))return null;
      }
      if(cardEffects.collectMatchingTriggers(player,{type:"place_data_income",playerId:seatId,cardInstanceId:id}).length)return null;
      const deck={...state.cards,removedFromGameCardIds:[...state.cards.removedFromGameCardIds],drawPileCardIds:[...state.cards.drawPileCardIds]};
      const removed=cards.discardFromHandAtIndex(player,ix);
      if(!removed.ok)throw Error("ANALYSIS_FIXED_INCOME_CARD_MISSING");
      cards.addRemovedFromGame(deck,removed.card);
      players.gainIncome(player,income);
      const settled={...state,cards:deck,meta:quietSavedMeta(state.meta,state.meta.stateVersion+remaining),
        players:{...state.players,players:state.players.players.map(p=>p===owner?player:p)}};
      const child=finishProvedCommittedState(node,stored,action,settled);
      if(child.status!=="stable"||child.boundary!==node.boundary)return null;
      keepPaidIncomeCargoPlan(child,settled,()=>state);
      return {node:child,cost:remaining*2+1};
    }

    function paidCargoProvedBoundary(node,plan){''')
replace('''    function matchesPaidCargoBoundary(proved,actual){''','''    function matchesProvedResourceEndpoint(proved,actual){''')
replace('''        &&exactClaimState(a.informationBarrier,b.informationBarrier)
        &&exactClaimState(readIdentityState(a.envelope),readIdentityState(b.envelope)));''','''        &&exactClaimState(a.informationBarrier,b.informationBarrier)
        &&exactClaimState(a.intent,b.intent)&&exactClaimState(a.resourceControl,b.resourceControl)
        &&exactClaimState(a.paidCargoPlan,b.paidCargoPlan)&&exactClaimState(proved.legalActions,actual.legalActions)
        &&exactClaimState(readIdentityState(a.envelope),readIdentityState(b.envelope)));''')
replace('''expandResourcePlan, paidCargoProvedBoundary, matchesPaidCargoBoundary''','''expandResourcePlan, paidCargoProvedBoundary, fundedComputerIncomePrefix, matchesProvedResourceEndpoint''')
p.write_text(a)
p=root/'decision-search.js'
a=p.read_text()
replace('seti-complete-decision-search-v440','seti-complete-decision-search-v441')
a=a.replace('paidCargoProofLeaves','provedResourceEndpoints')
i=a.index('          const proved=unlimited&&planReuse&&modelKey&&realizationTies')
j=a.index('          const fixed=port.expandResourcePlan',i)
a=a[:i]+'''          const plan=alternative.resourcePlan;
          if(unlimited&&planReuse&&modelKey&&realizationTies){
            const cargo=plan.goal.kind==="paid-income-earth-cargo"&&port.paidCargoProvedBoundary?.(entry.node,plan);
            const income=plan.goal.kind==="income"&&port.fundedComputerIncomePrefix?.(entry.node,plan);
            const proved=cargo||income?.node;
            if(proved){
              const added=add(proved,income?1:0),cost=income?income.cost:plan.goal.path.length*2+2;
              if(added.equivalent)equivalents++;
              entry.edges.push({actionId:alternative.firstActionId,target:added.index,cost,equivalent:added.equivalent,
                resourcePlan:plan,goalStatus:income?"completed":"boundary",actualNativeInputs:0,provedNativeInputs:cost,
                proof:income?"seti-native-funded-computer-income-prefix-v1":"seti-native-paid-cargo-quiet-turn-boundary-v1"});
              provedResourceEndpoints.set(entry.edges.at(-1),proved);
              continue;
            }
          }
'''+a[j:]
replace('''          if(best.proof==="seti-native-paid-cargo-quiet-turn-boundary-v1"){''','''          if(provedResourceEndpoints.has(best)){''')
replace('''              ||!port.matchesPaidCargoBoundary(provedResourceEndpoints.get(best),macro.node))
              throw new Error("SEARCH_WINNING_PAID_CARGO_WITNESS_MISMATCH");''','''              ||!port.matchesProvedResourceEndpoint(provedResourceEndpoints.get(best),macro.node))
              throw new Error(`SEARCH_WINNING_RESOURCE_WITNESS_MISMATCH: ${best.proof}`);''')
p.write_text(a)
