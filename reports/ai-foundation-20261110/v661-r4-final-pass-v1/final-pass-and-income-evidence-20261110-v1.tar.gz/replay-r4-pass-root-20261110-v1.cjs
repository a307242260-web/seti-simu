'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),load=f=>require(path.resolve('randomizer/game/ai',f));
const round=JSON.parse(fs.readFileSync(process.argv[3])).coreState.compositionEnvelope,terminal=JSON.parse(fs.readFileSync(process.argv[4]));
const r=terminal.replaySteps.slice(121),m=open(round),natives=[];
try{
 for(const row of r.slice(0,2))m.apply(row.action);
 const root=m.save();assert.equal(m.player().resources.score,50);assert.equal(m.player().resources.credits,6);
 assert.equal(m.player().resources.energy,2);
 const previous=m.automatic();
 const v=load('state-value'),report={root,priorDecision:{id:previous.a.actionId,score:previous.value,n:previous.n,ms:previous.ms,roots:previous.roots}};
 const p=load('analysis-port').createAnalysisPort({composition:m.c,seatId:seat});
 try{
   const n=p.openRoot(),e=p.expand(n,r[2].action.actionId),o=p.valueObservation(e);
   report.passLeaf={status:e.status,round:o.publicState.roundNumber,passed:o.publicState.passedPlayerIds,passing:o.publicState.passingPlayerIds,
     details:v.evaluateStateValue(o,seat)};
 }finally{p.close();}
 for(const row of r.slice(2)){
   const a=m.apply(row.action);
   natives.push({id:a.actionId,actor:a.actorId,family:a.family,score:m.facts().final,resources:m.player().resources});
 }
 const end=m.save();assert.deepEqual(end,terminal.coreState.compositionEnvelope);
 report.nativePassReplay=natives;
 fs.writeFileSync(process.argv[5],JSON.stringify(report,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({choice:report.priorDecision.id,value:previous.value,n:previous.n,ms:previous.ms,passLeaf:report.passLeaf,final:natives.at(-1).score}));
}finally{m.dispose();}
