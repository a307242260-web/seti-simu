'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),z=require('node:zlib');
const load=f=>require(path.resolve('randomizer/game',f));
const data=load('data'),cards=load('cards/deck'),players=load('players'),effects=load('cards/effects'),local=load('ai/local-decision-plans'),{copyForkData}=load('state/state-store');
const old=Module._extensions['.js'],seen=[];
const same=require('node:util').isDeepStrictEqual;
const seat='player-white';
function owner(s){return s.players.players.find(p=>p.id===seat);}
function preview(s,plan,a){
 const p=owner(s),t=s.turn,id=plan.goal.incomeCardId,card=p.hand.find(c=>c.id===id);
 const g=card&&cards.getIncomeGainForCard(card),keys=Object.keys(g||{});
 if(t.roundNumber!==4||t.currentPlayerId!==seat||t.gameEnded||!p.mainActionCompleted||p.passCompletionPending||t.cardTurnEventBonuses?.length
  ||t.passedPlayerIds.includes(seat)||a?.family!=='place_data'||!card||keys.length!==1||!['energy','credits','publicity'].includes(keys[0])||g[keys[0]]!==1)
  return {reason:'scope-or-income'};
 const slots=data.listComputerPlacedTokens(p),remaining=4-slots.length;
 if(remaining<1||!slots.every((v,i)=>v.placementSlot===i+1)||p.resources.availableData!==p.dataState.poolTokens.length||p.resources.availableData<remaining)return {reason:'stock'};
 if(local.hasPendingFossilArrival(s))return {reason:'pending-cargo'};
 const q=copyForkData(p),board={...s.players,players:s.players.players.map(x=>x===p?q:x)};
 for(let i=0;i<remaining;i++){
  const at=slots.length+i+1,r=data.placeDataToComputer(q);
  if(!r.ok||r.placementKind!=='computer'||r.placementSlot!==at)return {reason:'placement'};
  if(effects.collectMatchingTriggers(q,{type:'placeData',playerId:seat,placementKind:'computer',placementSlot:at}).length)return {reason:'observer'};
  for(const bonus of r.slotBonuses){
   const resource=bonus.type;
   if(resource==='income'&&at===4&&r.slotBonuses.length===1)continue;
   if(!['credits','energy','publicity','score'].includes(resource)||!Number.isSafeInteger(bonus[resource])||bonus[resource]<=0
     ||Object.keys(bonus).some(k=>k!=='type'&&k!==resource))return {reason:'bonus'};
   const gain={[resource]:bonus[resource]};
   players.gainResources(q,gain,'blueTechScore');
   if(effects.collectMatchingTriggers(q,{type:'science_resource_bonus',playerId:seat,gain,sourceKey:'blueTechScore'}).length)return {reason:'reward-observer'};
  }
 }
 if(effects.collectMatchingTriggers(q,{type:'place_data_income',playerId:seat,cardInstanceId:id}).length)return {reason:'income-observer'};
 const deck={...s.cards,removedFromGameCardIds:[...s.cards.removedFromGameCardIds],drawPileCardIds:[...s.cards.drawPileCardIds]};
 const removed=cards.discardFromHandAtIndex(q,q.hand.findIndex(c=>c.id===id));
 assert(removed.ok,id);
 cards.addRemovedFromGame(deck,removed.card);
 players.gainIncome(q,g);
 const meta={...s.meta,stateVersion:s.meta.stateVersion+remaining};
 if(meta.rngState?.branch===true){meta.rngState={...meta.rngState};delete meta.rngState.branch;}
 return {state:{...s,meta,cards:deck,players:board},remaining};
}
function diff(x,y,at='',out=[]){
 if(same(x,y)||out.length>=20)return out;
 if(!x||!y||typeof x!=='object'||typeof y!=='object'){out.push(at);return out;}
 for(const k of new Set([...Object.keys(x),...Object.keys(y)]))diff(x[k],y[k],at+'.'+k,out);
 return out;
}
globalThis.auditIncome=(s,node,plan,out,result,scope,afterScope)=>{
 const p=preview(s,plan,node.legalActions.find(a=>a.actionId===plan.firstActionId));
 const raw=JSON.parse(result.committedState);
 const comparison=p.state?diff(JSON.parse(JSON.stringify(p.state)),raw):[];
 seen.push({reason:p.reason||null,proved:!!p.state,remaining:p.remaining??null,submissions:out.submissions,status:out.goalStatus,
  session:!!result.session,comparison,scope,afterScope,steps:out.prefixes.map(x=>x.action.actionId),
  ...(p.state?{source:s,expected:raw,plan}:{} )});
};
Module._extensions['.js']=(mod,file)=>{
 if(!file.endsWith('/randomizer/game/ai/analysis-port.js'))return old(mod,file);
 const src=fs.readFileSync(file,'utf8'),mark='    function expandResourcePlan(node,plan,hasCapacity) {';
 assert.equal(src.split(mark).length,2);
 mod._compile(src.replace(mark,`    function expandResourcePlan(node,plan,hasCapacity){
      const r=expandResourcePlanAudit(node,plan,hasCapacity);
      if(plan.goal.kind==="income"&&node.status==="stable"){
        const source=nodes.get(node),last=nodes.get(r.node);
        globalThis.auditIncome(readIdentityState(source.envelope),node,plan,r,last.envelope,source.informationBarrier?.code??null,last.informationBarrier?.code??null);
      }
      return r;
    }
    function expandResourcePlanAudit(node,plan,hasCapacity) {`),file);
};
const {open}=require(process.argv[2]),root=JSON.parse(fs.readFileSync(process.argv[3])).checkpoint,m=open(root);
const p=load('ai/analysis-port').createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=load('ai/search-agent').createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 const result={count:seen.length,proofs:seen.filter(x=>x.proved).length,exact:seen.filter(x=>x.proved&&!x.comparison.length&&!x.session&&x.scope===x.afterScope).length,seen};
 fs.writeFileSync(process.argv[4],z.gzipSync(JSON.stringify(result)),{flag:'wx'});
 console.log(JSON.stringify({count:result.count,proofs:result.proofs,exact:result.exact,action:q.actionId,value:q.value,
  diff:[...new Set(seen.flatMap(x=>x.comparison))],reasons:seen.reduce((n,x)=>(n[x.reason]=(n[x.reason]||0)+1,n),{})}));
}finally{p.close();m.dispose();}
