'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),assert=require('node:assert/strict'),Module=require('node:module');
const compile=Module._extensions['.js'];
Module._extensions['.js']=(module,file)=>{
  if(!file.endsWith('/game/ai/analysis-port.js'))return compile(module,file);
  const src=fs.readFileSync(file,'utf8'),mark='resourceSpec, expandResourcePlan, paidCargoProvedBoundary, fundedComputerIncomePrefix';
  assert.equal(src.split(mark).length,2);
  module._compile(src.replace(mark,mark+', auditEnvelope:node=>nodes.get(node).envelope'),file);
};
const {open,seat}=require(process.argv[2]),load=f=>require(path.resolve('randomizer/game/ai',f));
const root=JSON.parse(fs.readFileSync(process.argv[3])).checkpoint,m=open(root),replay=open(root);
const p=load('analysis-port').createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
const same=require('node:util').isDeepStrictEqual;
function diff(a,b,k=''){if(same(a,b))return null;if(!a||!b||typeof a!=='object'||typeof b!=='object')return [k,a,b];for(const key of new Set([...Object.keys(a),...Object.keys(b)])){const d=diff(a[key],b[key],k+'.'+key);if(d)return d;}return [k,'object-shape','object-shape'];}
const evaluate=load('state-value').createStateValueEvaluator(seat),proofs=[];
const proxy={...p,close(){},fundedComputerIncomePrefix(node,plan){
  const proved=p.fundedComputerIncomePrefix(node,plan);
  if(proved)proofs.push({node,plan,...proved,source:node});
  return proved;
}};
try{
  const agent=load('search-agent').createSearchAgent({seatId:seat,analysisPort:proxy});
  const q=agent.decide({seatId:seat,legalActions:m.menu()}).search,ai=agent.createCheckpoint();
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
  const before=p.getDiagnostics().submissionCount,cases=[];
  for(const {source,node,plan,cost} of proofs){
    const native=p.expandResourcePlan(source,plan,()=>null);
    assert(native.complete&&native.goalStatus==='completed');
    assert.equal(native.submissions,cost);
    assert(p.matchesProvedResourceEndpoint(node,native.node),plan.goal.id);
    const actual=evaluate.details(p.valueObservation(native.node)),predicted=evaluate.details(p.valueObservation(node));
    assert.deepEqual(actual,predicted);
    const start=p.auditEnvelope(source),result=p.auditEnvelope(node);
    const input=JSON.parse(JSON.stringify(start));
    const restore=replay.c.lifecycle.restore(input);
    assert(restore.ok,JSON.stringify(restore).slice(0,500));
    const restored=replay.save();
    assert.equal(diff(JSON.parse(restored.committedState),JSON.parse(input.committedState)),null,'restore');
    assert.equal(restored.session,null);
    for(const {action} of native.prefixes)replay.apply(action);
    const end=replay.save();
    assert.equal(end.session,null);
    assert.equal(diff(JSON.parse(end.committedState),JSON.parse(result.committedState)),null,plan.goal.id);
    cases.push({id:plan.goal.id,cardId:plan.goal.incomeCardId,cost,boundary:node.boundary,legalActions:node.legalActions.length,
      scope:p.resourceSpec(node)?.plans.map(a=>a.goal.kind)??[],value:actual.value,inputs:native.prefixes.map(x=>x.action.actionId)});
  }
  assert.deepEqual(m.save(),root);
  assert(cases.length>0);
  const report={rootExact:true,closureCases:cases,searchNative:before,auditNative:p.getDiagnostics().submissionCount-before,
    action:q.actionId,value:q.value,certificateInputs:ai.plan?.rows.length??0};
  fs.writeFileSync(process.argv[4],JSON.stringify(report,null,2)+'\n',{flag:'wx'});
  fs.writeFileSync(process.argv[5],z.gzipSync(JSON.stringify({q,ai})),{flag:'wx'});
  console.log(JSON.stringify({cases:cases.length,steps:cases.reduce((n,r)=>n+r.cost,0),searchNative:before,auditNative:report.auditNative,action:q.actionId,value:q.value}));
}finally{p.close();m.dispose();replay.dispose();}
