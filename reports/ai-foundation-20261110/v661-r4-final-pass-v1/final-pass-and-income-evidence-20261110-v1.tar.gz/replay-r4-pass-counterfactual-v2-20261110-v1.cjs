'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),root=JSON.parse(fs.readFileSync(process.argv[3])).root,m=open(root);
const output={initial:m.facts(),rows:[],terminal:false};
let ai=null;
try{
 for(let i=0;i<80&&!m.state().turn.gameEnded;i++){
   const before=m.state().turn;
   assert.equal(before.roundNumber,4);
   assert.equal(before.currentPlayerId,seat);
   const decision=m.automatic(ai),r={actionId:decision.a?.actionId,summary:decision.a?.summary,family:decision.a?.family,ms:decision.ms,n:decision.n,
     value:decision.value,roots:decision.roots.filter(v=>v.value!==null).map(x=>[x.actionId,x.value])};
   output.rows.push(r);
   if(!decision.complete||!decision.a||decision.n>256||decision.ms>600){
     output.stop='individual-decision-gate';break;
   }
   ai=decision.checkpoint;
   m.apply(decision.a);
   r.afterOwn=m.facts();
   const others=[];
   if(!m.state().turn.gameEnded&&m.state().turn.currentPlayerId!==seat)m.advanceOpponents(others);
   r.others=others.map(a=>[a.actorId,a.actionId]);
 }
 output.terminal=m.state().turn.gameEnded;
 output.final=m.facts();
 output.end=m.save();
 fs.writeFileSync(process.argv[4],JSON.stringify(output,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({terminal:output.terminal,stop:output.stop,score:output.final.wallet.score,final:output.final.final,rows:output.rows.map(r=>[r.family,r.summary,r.afterOwn?.wallet.score,r.n,Math.round(r.ms)])}));
}finally{m.dispose();}
