'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require(process.argv[2]),load=f=>require(path.resolve('randomizer/game/ai',f));
const root=JSON.parse(fs.readFileSync(process.argv[3])).root,m=open(root);
const p=load('analysis-port').createAnalysisPort({composition:m.c,seatId:seat});
try{
 const n=p.openRoot(),a=n.legalActions.find(a=>a.family==='pass'),e=p.expand(n,a.actionId);
 const {createDecisionObservation}=load('outcome-model'),{evaluateStateValue}=load('state-value');
 const observations=[e.observation,p.valueObservation(e),createDecisionObservation(e.observation,{seatId:seat,stateVersion:a.stateVersion,decisionVersion:a.decisionVersion})];
 const values=observations.map(o=>{
  assert(o.publicState.passedPlayerIds.includes(seat));
  return evaluateStateValue(o,seat);
 });
 for(const value of values){
  assert.equal(value.total,77);assert.equal(value.terminal,false);
  assert.deepEqual(value,values[0]);
 }
 assert.deepEqual(m.save(),root);
 console.log('[PASS] completed-final-pass: authoritative/full/compact/canonical agree at 77, game continues for other seats, root and RNG unchanged');
}finally{p.close();m.dispose();}
