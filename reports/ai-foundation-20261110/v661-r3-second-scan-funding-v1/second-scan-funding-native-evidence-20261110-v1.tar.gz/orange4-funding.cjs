'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,runCases}=require('./controlled-r3');
const [file,out,mode]=process.argv.slice(2),d=readZ(file),root=d.roots[220].e;
const ch=(h,id)=>h.act('choose_target',a=>a.target.choiceId===id);
function place(h,slot=null){h.act('place_data');h.act('choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');}
function analyze(h){
 h.act('analyze');ch(h,'trace:1:blue:amiba:3');h.act('choose_card',a=>a.target.source==='display');h.cut('analysis');
}
function buyWithTwo(h,ids){
 h.act('quick_trade',a=>a.target.tradeId==='cards-for-credit');
 for(const id of ids){
  const c=h.m.player().hand.find(c=>c.cardId===id);assert(c,id);
  h.act('choose_payment',a=>a.target.cardInstanceId===c.id||a.summary===id);
 }
 h.act('choose_payment',a=>a.summary.includes('确认弃牌'));
}
function firstOrange(h){
 ch(h,'tech:orange4');place(h);place(h);h.act('end_turn');h.cut('energy-funded');
 analyze(h);place(h);place(h,1);h.cut('two-energy');
}
function firstBlue(h){
 ch(h,'tech:blue1:slot:3');place(h);place(h);place(h,3);h.act('end_turn');
 analyze(h);h.take(h.m.corner('amiba_2.webp'));place(h);place(h,1);
 h.act('end_turn');h.take(h.m.corner('amiba_9.webp'));h.take(h.m.corner('b_16.webp'));
 h.act('research_tech');ch(h,'tech:orange4');h.act('end_turn');h.cut('two-energy');
}
const pairs=[
 ['orange-first-known-pay',h=>{firstOrange(h);buyWithTwo(h,['amiba_9.webp','b_16.webp']);h.act('end_turn');}],
 ['orange-first-hold-amiba9',h=>{firstOrange(h);buyWithTwo(h,['dlc_25.png','b_16.webp']);h.act('end_turn');}],
 ['orange-first-hold-b16',h=>{firstOrange(h);buyWithTwo(h,['dlc_25.png','amiba_9.webp']);h.act('end_turn');}],

];
const cases=(mode==='blue-first'?[["blue-first-orange4",firstBlue]]:pairs).flatMap(([k,f])=>[false,true].map(launch=>[k+(launch?':scan':':ready'),h=>{
 f(h);h.cut('second-scan-ready');if(launch){h.act('scan');h.cut('scan-menu');}
}]));
writeZ(out,{root,...runCases(root,cases)});
