'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ}=require('./controlled-r3');
const dir=process.argv[2]||__dirname,read=n=>readZ(path.join(dir,n+'-20261110-v1.json.gz'));
let inputs=0,segments=0;
function replay(e,actions,end){
 const m=open(e);
 try{for(const x of actions){assert(x.n===undefined||x.n<=256&&x.ms<=600);m.apply(x.action||x);}assert.deepEqual(m.save(),end);}
 finally{m.dispose();}
 inputs+=actions.length;segments++;
}
function run(e,x){
 for(const r of x.rows)replay(e,[...r.prefix,...r.actions],r.end);
 for(const r of x.failures)replay(e,r.prefix,r.checkpoint);
}
for(const n of ['second-scan-funded','second-scan-orange4-first','blue-first-scan','second-scan-blue-then-orange4','second-scan-blue1-energy-admitted']){
 const x=read(n);run(x.root,x);
}
const old=read('second-scan-blue1-r2-resume'),resume=read('second-scan-blue1-energy-admitted');
for(const r of Object.values(old))run(r.root,r.result);
assert.equal(old['buy-known-energy'].result.rows[0].stop.n,417);
assert.equal(resume.rows[0].settled.summary.wallet[0],103);
const a=read('second-scan-blue1-budget'),b=read('second-scan-blue1-budget-admitted');
for(const k of ['e','s','roots','lines'])assert.deepEqual(a[k],b[k]);
assert.equal(b.summary.n,256);assert.equal(a.diagnostics.transitions,b.diagnostics.transitions);
const proofs=read('second-scan-budget-native-proof-admitted');
assert.equal(proofs.rows.length,212);
assert.deepEqual(Object.keys(proofs.fixtures).sort(),['corner','data-menu','end','income','income-menu','placement','public-scan']);
const clean=x=>Object.fromEntries(Object.entries(x).map(([k,{ms,n,...q}])=>[k,q]));
const oldFormal=read('reserve-formal-parity'),next=read('second-scan-budget-formal-parity-admitted');
assert.deepEqual(clean(oldFormal),clean(next));assert.equal(next['opening:136'].n,79);
assert(Object.values(next).every(q=>q.complete&&q.n<=256&&q.ms<=600));
console.log(JSON.stringify({inputs,segments,proofs:proofs.rows.length,formalRoots:Object.keys(next).length}));
