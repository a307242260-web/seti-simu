'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,runCases}=require('./controlled-r3');
const [file,out]=process.argv.slice(2),d=readZ(file),root=d.roots[220].e;
const ch=(h,id)=>h.act('choose_target',a=>a.target.choiceId===id);
const place=(h,slot=null)=>{h.act('place_data');h.act('choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');};
function payCards(h,ids){
 h.act('quick_trade',a=>a.target.tradeId==='cards-for-energy');
 for(const id of ids){
  const c=h.m.player().hand.find(c=>c.cardId===id);
  assert(c,id);h.act('choose_payment',a=>a.target.cardInstanceId===c.id||a.summary===id);
 }
 h.act('choose_payment',a=>a.summary.includes('确认弃牌'));
}
function start(h){
 ch(h,'tech:blue1:slot:3');place(h);place(h);place(h,3);
 h.act('end_turn');h.cut('cash');
 h.act('analyze');ch(h,'trace:1:blue:amiba:3');
 h.act('choose_card',a=>a.target.source==='display');h.cut('analysis');
}
function funded(h,source,payers,corner='amiba_2.webp'){
 start(h);
 if(source)h.take(...h.m.swap(source[0],source[1]));
 h.take(h.m.corner(corner));
 place(h);place(h,1);
 payCards(h,payers);
 h.act('end_turn');h.cut('second-scan-ready');
}
const cases=[];
for(const [k,source,payers,corner] of [
 ['hold-dlc25',null,['b_16.webp','amiba_9.webp']],
 ['hold-amiba9',null,['b_16.webp','dlc_25.png']],
 ['hold-b16',null,['amiba_9.webp','dlc_25.png']],
 ['hold-dlc17',['amiba_5.webp','dlc_17.png'],['b_16.webp','amiba_9.webp']],
 ['keep-amiba5',['amiba_2.webp','dlc_17.png'],['b_16.webp','amiba_9.webp'],'dlc_17.png'],
]){
 for(const doScan of [false,true])cases.push([k+(doScan?':scan':':ready'),h=>{
  funded(h,source,payers,corner);
  if(doScan){h.act('scan');h.cut('scan-menu');}
 }]);
}
writeZ(out,{root,...runCases(root,cases)});
