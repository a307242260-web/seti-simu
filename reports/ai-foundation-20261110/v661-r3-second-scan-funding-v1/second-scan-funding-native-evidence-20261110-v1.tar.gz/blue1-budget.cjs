'use strict';
const path=require('node:path'),assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [f,out]=process.argv.slice(2),x=readZ(f),r=x['buy-known-energy'].result.rows[0],e=r.end,m=open(e),id='player-white';
const port=createAnalysisPort({composition:m.c,seatId:id,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:id,analysisPort:port}).decide({seatId:id,legalActions:m.menu()}).search;
 assert.deepEqual(m.save(),e);
 const steps=q.lines.flatMap(l=>l.edges.flatMap(a=>a.steps||[])),unique=new Map();
 for(const s of steps){const a=s.action||s,k=a.family||a.action?.family||s.kind||'unlabelled';unique.set(k,(unique.get(k)||0)+1);}
 const s=short(m),summary={n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,nodeCount:q.lines.length,
  complete:q.complete,choice:m.menu().find(a=>a.actionId===q.actionId)?.summary,stepDistribution:Object.fromEntries([...unique].sort((a,b)=>b[1]-a[1]))};
 console.log(s,summary,steps[0]);
 writeZ(out,{e,s,summary,roots:q.roots,lines:q.lines,diagnostics:q.diagnostics});
}finally{port.close();m.dispose();}
