'use strict';
const fs=require('node:fs'),{open,short,writeZ,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=JSON.parse(fs.readFileSync(src)),rows={};
for(const b of d.cases){
 const root=b.startR3.envelope,m=open(root),q=m.automatic(),opening=short(m);m.dispose();
 console.log('cold',b.label,q.complete,q.n,q.ms,q.a?.summary,JSON.stringify(opening.wallet));
 rows[b.label]={root,q:{...q,checkpoint:undefined},opening,priorEnd:b.end};
 if(q.complete&&q.n<=256&&q.ms<=600)rows[b.label].result=runCases(root,[[b.label,()=>{}]]);
}
writeZ(out,rows);
