'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ}=require('./controlled-r3');
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const [src,out,mode]=process.argv.slice(2),origin=readZ(src).e,rows={};
assert(!origin.session);
for(const id of [null,'b_9.webp','b_60.webp']){
 const e=structuredClone(origin),s=JSON.parse(e.committedState);
 if(id){
  const a=s.cards.drawPileCardIds,i=a.indexOf(id);
  assert(i>0);[a[0],a[i]]=[a[i],a[0]];e.committedState=createStateStore(s).serialize().serialized;
 }
 const m=open(e);
 try{
  const q=m.automatic(),{a,roots,n,ms,value,complete}=q;
  const row={e,a,roots,n,ms,value,complete,obs:m.owner('player-white'),menu:m.menu()};
  assert(complete&&(mode==='baseline'||n<=256&&ms<=600));
  if(id)for(const k of ['a','roots','value','complete','obs','menu'])assert.deepEqual(row[k],rows.original[k]);
  rows[id||'original']=row;
  console.log(id||'original',a.summary,n,ms,value);
 }finally{m.dispose();}
}
writeZ(out,rows);
