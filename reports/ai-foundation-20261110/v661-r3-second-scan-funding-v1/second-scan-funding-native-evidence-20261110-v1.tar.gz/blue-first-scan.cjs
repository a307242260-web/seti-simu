'use strict';
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [file,out]=process.argv.slice(2),d=readZ(file),root=d.rows[194].e;
const ch=(h,id)=>h.act('choose_target',a=>a.target.choiceId===id);
function place(h,slot=null){h.act('place_data');h.act('choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');}
function prep(h,slot){
 ch(h,'tech:blue1:slot:'+slot);place(h);place(h,1);place(h,slot);
 h.act('end_turn');h.cut('first-scan-funded');
}
const cases=[];
for(const slot of [3,4])for(const forced of [false,true])cases.push([
 'blue1-'+slot+(forced?':scan':':ready'),h=>{prep(h,slot);if(forced){h.act('scan');h.cut('scan-menu');}}
]);
cases.push(['blue1-raw-handoff',h=>{ch(h,'tech:blue1:slot:3');h.cut('blue');}]);
writeZ(out,{root,...runCases(root,cases)});
