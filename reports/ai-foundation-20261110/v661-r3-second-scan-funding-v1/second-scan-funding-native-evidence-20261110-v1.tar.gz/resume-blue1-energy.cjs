'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,runCases}=require('./controlled-r3');
const [f,out]=process.argv.slice(2),x=readZ(f);
assert(x.summary.complete&&x.summary.n<=256&&x.summary.ms<=600);
writeZ(out,{root:x.e,...runCases(x.e,[['known-energy-blue1',()=>{}]])});
