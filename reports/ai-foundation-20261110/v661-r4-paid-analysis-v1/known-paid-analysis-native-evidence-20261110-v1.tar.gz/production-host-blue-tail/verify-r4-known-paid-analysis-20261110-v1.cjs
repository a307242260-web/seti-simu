'use strict';
const assert=require('node:assert/strict');
const {readZ,writeZ,open}=require('./controlled-r3');
const [original,swapped,out]=process.argv.slice(2),x=readZ(original),y=readZ(swapped);
for(const k of ['rootView','menu','roots','candidate','edge','target','steps','prepMenu','selected','value','n'])assert.deepEqual(x[k],y[k],k);
assert.notDeepEqual(x.prepFacts.market,y.prepFacts.market);
function normalizedState(s){
 const v=structuredClone(s);delete v.meta.rngState;
 for(const a of Object.values(v.aliens))if(a&&a.initialConfiguration===null)delete a.initialConfiguration;
 return v;
}
function queue(e){
 const s=e.session.session;
 return JSON.parse(JSON.stringify(s.queue).replaceAll(s.sessionId,'@session'));
}
for(const d of [x,y]){
 const n=d.terminalPreparation,p=d.proof;
 assert.deepEqual(normalizedState(n.session.session.workingState),normalizedState(p.session.session.workingState));
 assert.deepEqual(normalizedState(JSON.parse(n.committedState)),normalizedState(JSON.parse(p.committedState)));
 assert.deepEqual(queue(n),queue(p));
 assert.notDeepEqual(n.session.session.baseState,p.session.session.baseState);
}
const trade=x.edge.actionId,company=x.selected,results=[];
for(const d of [x,y]){
 const m=open(d.root);
 try{
  const turn=d.paths[company][0].actions;
  const notes=[],applied=[];
  const apply=(a,menu)=>{const n=menu.find(q=>q.actionId===a.actionId);if(n){m.apply(n);applied.push(n);return true;}return false;};
  for(const a of d.steps.slice(0,2))assert(apply(a,m.menu()));
  for(const [i,a] of turn.slice(3).entries()){
   const menu=m.menu(),match=a.target.cardInstanceId==='alien-amiba-9-17'&&a.family==='choose_card';
   if(match){
    const alternative=menu.find(q=>q.family===a.family&&q.target.cardInstanceId==='card-66-0'&&q.target.nebulaId===a.target.nebulaId);
    notes.push({index:i+3,status:alternative?'replaced-amiba9-with-dlc16':'dlc16-not-in-current-scan-menu',
     expected:a,menu:menu.map(q=>[q.actionId,q.summary,q.family,q.target]),assets:m.facts()});
    if(!alternative)break;
    m.apply(alternative);applied.push(alternative);continue;
   }
   if(!apply(a,menu)){notes.push({index:i+3,status:'company-suffix-diverges',expected:a,
    menu:menu.map(q=>[q.actionId,q.summary,q.family,q.target]),assets:m.facts()});break;}
  }
  const end=m.save(),assets=m.facts();m.restore(d.root);applied.forEach(a=>m.apply(a));assert.deepEqual(m.save(),end);
  results.push({notes,applied,end,assets,company:d.paths[company][0],purchase:d.paths[trade],changedMarket:d.prepFacts.market});
 }finally{m.dispose();}
}
writeZ(out,{trade,company,results});
for(const r of results)console.log(JSON.stringify({market:r.changedMarket,steps:r.applied.map(a=>a.summary),
 notes:r.notes.map(n=>({status:n.status,expected:n.expected.summary,menu:n.menu.map(a=>a[1])})),
 companyWallet:r.company.facts.wallet,purchaseWallet:r.purchase[1].facts.wallet,substitutionWallet:r.assets.wallet,substitutionIncome:r.assets.income}));
