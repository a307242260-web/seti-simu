'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),Module=require('node:module');
const ai=path.resolve('randomizer/game/ai'),portFile=path.join(ai,'analysis-port.js');
const readJS=Module._extensions['.js'], nodes=new Map(), chains=[];
globalThis.paidAnalysisNode=(n,e)=>nodes.set(n,e);
globalThis.paidAnalysisFixed=(n,bought,end,steps)=>{if(bought)chains.push({n,bought,end,steps});};
Module._extensions['.js']=(m,f)=>{
 if(f!==portFile)return readJS(m,f);
 let s=fs.readFileSync(f,'utf8');
 const insert=(a,b)=>{assert.equal(s.split(a).length,2);s=s.replace(a,b+a);};
 insert('      nodeCount += 1;\n      return node;','      globalThis.paidAnalysisNode(node,envelope);\n');
 insert('      return{complete:true,node:current,submissions:prefixes.length,prefixes,fixedChoices};\n    }\n\n    function knownPaidAnalysisStep','      globalThis.paidAnalysisFixed(node,boughtAnalysisCard,current,prefixes.map(p=>p.action));\n');
 m._compile(s,f);
};
const {readZ,writeZ,open}=require('./controlled-r3');
const {createAnalysisPort}=require(portFile),{createSearchAgent}=require(path.join(ai,'search-agent'));
const [fixture,key,output,mutation]=process.argv.slice(2),initial=readZ(fixture)[key].root,root=structuredClone(initial);
if(mutation==='swap-hidden-refill'){
 assert(!root.session);
 const s=JSON.parse(root.committedState),deck=s.cards.drawPileCardIds;
 assert(deck.length>=2);assert.notEqual(deck[0],deck[1]);
 [deck[0],deck[1]]=[deck[1],deck[0]];
 root.committedState=JSON.stringify(s);
}
const m=open(root),seat='player-white',port=createAnalysisPort({composition:m.c,seatId:seat});
const canonical=e=>{
 const c=structuredClone(e);c.committedState=JSON.parse(c.committedState);
 const normalizeState=s=>{
  if(!s)return;
  if(s.meta) delete s.meta.rngState; // fork has its own RNG algorithm and seed
  for(const v of Object.values(s.aliens||{}))if(v&&v.initialConfiguration===null)delete v.initialConfiguration;
 };
 const ss=c.session?.session;
 for(const state of [c.committedState,ss?.workingState,ss?.baseState])normalizeState(state);
 if(ss){
  ss.undoFrames=[];
  if(ss.sessionId){
   const visit=v=>typeof v==='string'?v.replaceAll(ss.sessionId,'@session'):Array.isArray(v)?v.map(visit):v&&typeof v==='object'?Object.fromEntries(Object.entries(v).map(([k,x])=>[k,visit(x)])):v;
   c.session=visit(c.session);
  }
 }
 return c;
};
try{
 const menu=m.menu(),trade=menu.find(a=>a.target?.tradeId==='publicity-for-card');
 const rootView=m.owner(seat);
 const agent=createSearchAgent({seatId:seat,analysisPort:port});
 const q=agent.decide({seatId:seat,legalActions:menu}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 const candidate=q.roots.find(r=>r.actionId===trade.actionId);
 const edge=q.lines[0].edges.find(e=>e.actionId===trade.actionId),target=q.lines[edge.target];
 const hit=chains.find(c=>c.steps[0].actionId===trade.actionId&&c.steps.map(x=>x.actionId).join()===edge.steps.join());
 assert(hit&&hit.steps.at(-1).family==='analyze');
 const apply=(id)=>{
  const a=m.menu().find(x=>x.actionId===id);assert(a,JSON.stringify({id,menu:m.menu().map(x=>[x.actionId,x.summary])}));m.apply(a);return a;
 };
 const steps=hit.steps.map(a=>{const n=apply(a.actionId);assert.deepEqual(n.target,a.target);return n;});
 const terminalPreparation=m.save(),prepFacts=m.facts(),prepMenu=m.menu().map(a=>[a.actionId,a.family,a.target]);
 const proof=nodes.get(hit.end);
 assert(proof);
 let endpointMatch=true,delta=null;
 try{assert.deepEqual(canonical(terminalPreparation),canonical(proof));}
 catch(e){endpointMatch=false;delta=String(e).slice(0,2600);}
 const allowedTrace=target.edges.map(e=>e.actionId);
 assert(allowedTrace.every(id=>prepMenu.some(a=>a[0]===id)));
 m.restore(root);
 steps.forEach(a=>m.apply(a));assert.deepEqual(m.save(),terminalPreparation);
 const rootEdges=Object.fromEntries(q.lines[0].edges.filter(e=>e.actionId===trade.actionId||e.actionId===q.actionId).map(e=>[e.actionId,e]));
 const details=q.lines.map(x=>({node:x.node,status:x.status,value:x.value,boundary:x.boundary,distance:x.distance,edges:x.edges?.map(e=>({actionId:e.actionId,target:e.target,steps:e.steps,kind:e.resourceGoal?.kind}))}));
 const paths={};
 for(const id of [trade.actionId,q.actionId]){
  const e=rootEdges[id],chosen=q.roots.find(r=>r.actionId===id),visited=new Set();
  const collect=(edge,line=details[edge.target])=>{
   const first=edge.steps?.length?edge.steps:[edge.actionId];
   if(!line||visited.has(line.node)||!line.edges?.length)return [first];
   visited.add(line.node);
   return line.edges.filter(n=>details[n.target]?.value===chosen.value).flatMap(n=>collect(n)).slice(0,4).map(rest=>[...first,...rest]);
  };
  paths[id]=collect(e).map(seq=>{
   m.restore(root);
   try{const actions=seq.map(apply);return {actions,facts:m.facts(),remaining:m.menu().map(a=>[a.actionId,a.family])};}
   catch(error){return {seq,error:String(error).slice(0,800)};}
  });
 }
 m.restore(root);assert.deepEqual(m.save(),root);
 const d={root,rootView,menu,endpointRng:{native:prepFacts.rng,fork:proof.session.session.workingState.meta.rngState},proof,selected:q.actionId,value:q.value,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,roots:q.roots,candidate,
  edge,target,steps,prepFacts,prepMenu,terminalPreparation,endpointMatch,delta,paths};
 writeZ(output,d);
 console.log(JSON.stringify({key,mutation,selected:d.selected,value:d.value,n:d.n,ms:Math.round(d.ms),
  price:candidate.value,endpointMatch,delta,prep:{wallet:prepFacts.wallet,income:prepFacts.income,hand:prepFacts.hand,market:prepFacts.market},steps:steps.map(a=>a.summary),
  paths:Object.fromEntries(Object.entries(paths).map(([k,v])=>[k,v.map(x=>x.error||[x.actions.map(a=>a.summary),x.facts.wallet,x.facts.income])]))}));
}finally{port.close();m.dispose();}
