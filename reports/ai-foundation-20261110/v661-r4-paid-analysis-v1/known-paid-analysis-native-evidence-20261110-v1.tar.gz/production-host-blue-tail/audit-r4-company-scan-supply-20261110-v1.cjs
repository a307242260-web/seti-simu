'use strict';
const assert=require('node:assert/strict');
const {readZ,writeZ,open}=require('./controlled-r3');
const [file,out]=process.argv.slice(2),d=readZ(file),m=open(d.root),rows=[];
const eligible=m.player().hand.map(c=>[c.id,c.cardId]).filter(([,id])=>id!=='b_9.webp');
try{
 for(const [id,name,spentAmiba9] of [...eligible,[...eligible.find(r=>r[1]==='chong_7.webp'),true]]){
  m.restore(d.root);const actions=[];
  if(spentAmiba9)actions.push(m.corner('amiba_9.webp'));
  const act=(f,p)=>actions.push(m.act(f,p));
  const sector=a=>a.target.nebulaId==='sector-4-a';
  actions.push(...m.swap(name,'dlc_15.png'));
  act('place_data');act('choose_target',a=>a.target.blueSlot===1);
  actions.push(m.play('b_9.webp'));
  act('choose_target',sector);
  act('choose_card',a=>sector(a)&&a.target.cardInstanceId==='card-64-0');
  const atMenu=m.save();
  const offers=m.menu().filter(a=>a.family==='choose_card').map(a=>[a.summary,a.target]);
  const target=m.menu().find(a=>sector(a)&&a.family==='choose_card'&&a.target.cardInstanceId===id);
  if(target){
   actions.push(m.apply(target));
   act('choose_target',a=>a.target.mode==='launch');
   act('choose_target',sector);
  }
  const immediate=m.facts(),failure=[],payments=[];
  if(target){
   const suffix=d.paths[d.selected][0].actions.slice(11);
   for(const a of suffix){
    let current=m.menu().find(x=>x.actionId===a.actionId);
    if(!current&&a.family==='choose_payment'){
     const score=b=>b.target.cardIds.filter(id=>a.target.cardIds.includes(id)).length;
     const choices=m.menu().filter(x=>x.family==='choose_payment'&&x.payload.energyCost===a.payload.energyCost
      &&x.target.cardIds.length===a.target.cardIds.length).sort((x,y)=>score(y)-score(x)||x.actionId.localeCompare(y.actionId));
     current=choices[0];
     if(current)payments.push({original:a.target.cardIds,new:current.target.cardIds});
    }
    if(!current){failure.push({at:a.summary,menu:m.menu()});break;}
    actions.push(m.apply(current));
   }
  }
  const end=m.save(),facts=m.facts();m.restore(d.root);actions.forEach(a=>m.apply(a));assert.deepEqual(m.save(),end);
  rows.push({id,name,spentAmiba9:!!spentAmiba9,atMenu,offers,canScanVirgo:!!target,actions,end,facts,immediate,failure,payments});
 }
 assert.deepEqual(rows.filter(r=>r.canScanVirgo).map(r=>r.name),['chong_7.webp','amiba_9.webp','dlc_13.png','chong_7.webp']);
 writeZ(out,{root:d.root,rows});
 for(const r of rows)console.log(JSON.stringify([r.name,r.spentAmiba9,r.canScanVirgo,r.offers.map(x=>x[0]),[r.facts.wallet.score,r.facts.wallet.publicity,r.facts.final,r.facts.hand.map(h=>h[1])],r.immediate.wallet.score,r.facts.wins,r.payments,r.failure.map(f=>[f.at,f.menu.map(a=>a.summary)])]));
}finally{m.dispose();}
