'use strict';
const {open,read,z,seat}=require('./native-late-r3');
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {previewLastPlainPinkTrace}=require(path.resolve('randomizer/game/effects/residual-domain-session'));
const [root,witness,result]=process.argv.slice(2);
const data=JSON.parse(z.gunzipSync(fs.readFileSync(witness)));
const model=open(read(root).checkpoint);
const count={},eligible=[];
function firstDiff(a,b,key='state'){
 if(Object.is(a,b))return;
 if(!a||!b||typeof a!=='object'||typeof b!=='object')return {key,a,b};
 for(const k of new Set([...Object.keys(a),...Object.keys(b)])){
  if(Object.hasOwn(a,k)!==Object.hasOwn(b,k))return {key:key+'.'+k,a:a[k],b:b[k]};
  const p=firstDiff(a[k],b[k],key+'.'+k);if(p)return p;
 }
}
try {
 for(const [i,{envelope,action}] of data.rows.entries()){
  assert(model.c.lifecycle.restore(envelope).ok);
  const session=model.save().session.session;
  const known=new Set(session.workingState.players.players.find(p=>p.id===seat).reservedCards.map(c=>c.id));
  const current=JSON.stringify(model.save()),p=previewLastPlainPinkTrace(session,action,known);
  assert.equal(JSON.stringify(model.save()),current);
  if(!p)continue;
  model.apply(action);
  const diff=firstDiff(p,model.state());
  assert(!model.save().session&&diff===undefined,JSON.stringify({i,action:action.target,session:model.save().session?.session?.queue.map(q=>q.type),diff}).slice(0,1400));
  const target=action.target;
  const key=target.stateExtra?'extra':target.speciesId+':'+target.position;
  count[key]=(count[key]||0)+1;eligible.push(i);
 }
}finally{model.dispose()}
fs.writeFileSync(result,JSON.stringify({observed:data.rows.length,exact:eligible.length,count,eligible},null,2)+'\n');
console.log(JSON.stringify({observed:data.rows.length,exact:eligible.length,count}));
