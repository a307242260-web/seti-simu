'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{open,z}=require('./native-late-r3');
const [root,source,out]=process.argv.slice(2);
const d=JSON.parse(z.gunzipSync(fs.readFileSync(source)));
const m=open(JSON.parse(fs.readFileSync(root)).checkpoint),chong=require(path.resolve('randomizer/game/aliens/chong'));
const rows=[];
try{
 for(const e of d.examples){
  const [group,choice,,prior]=e.key.split(' / ');
  if(!['chong_pickup_fossil','science_domain_public_refill','residual_alien_card_decision'].includes(group))continue;
  assert(m.c.lifecycle.restore(e.envelope).ok);
  const old=m.state(),owner=m.player();
  const last=old.match?.cardPlayContext?.lastLanding?.planetId;
  const available=group==='chong_pickup_fossil' ? chong.getAvailablePlanetFossils(old.aliens,last).length : null;
  const display=()=>m.owner(owner.id).publicState.board.aliens.chongOffer?.displayedCardIndex;
  const displayBefore=display();
  m.apply(e.action);
  const after=m.save().session?.session,s=m.state(),q=m.player();
  rows.push({group,choice,prior,weight:d.counts[e.key],origin:e.envelope.session.session.journal.actions[0].action.family,last,available,
    result:after?.queue?.map(x=>x.type)||[],drawDelta:q.hand.length-owner.hand.length,marketDelta:s.cards.drawPileCardIds.length-old.cards.drawPileCardIds.length,
    displayBefore,displayAfter:display()});
 }
}finally{m.dispose();}
fs.writeFileSync(out,JSON.stringify(rows,null,2)+'\n');
const summary={};for(const r of rows){const key=[r.group,r.available,r.result[0]||'committed',r.drawDelta,r.marketDelta].join('/');summary[key]=(summary[key]||0)+1;}
console.log(summary);
