'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const [root,out]=process.argv.slice(2),file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));Module._cache[file]=mod;
const at='      loadedEnvelope = null;\n      const executeAt = now();',source=fs.readFileSync(file,'utf8');
assert.equal(source.split(at).length,2);
mod._compile(source.replace(at,'      globalThis.captureNext(current,session,loadedEnvelope);\n'+at),file);mod.loaded=true;
const {open}=require('./native-late-r3'),checkpoint=JSON.parse(fs.readFileSync(root)).checkpoint,m=open(checkpoint),counts={},first={},examples=[];
globalThis.captureNext=(action,s,envelope)=>{
 const [head,...tail]=s?.queue||[];
 if(!head)return;
 const eligibleTrace=head.type==='science_domain_alien_trace'&&head.payload.traceType==='pink';
 const publicRefill=tail.some(e=>e.type==='science_domain_public_refill');
 const fossil=tail.some(e=>e.payload?.cardEffect?.type==='chong_pickup_fossil'||e.payload?.effect?.type==='chong_pickup_fossil'||e.type==='chong_pickup_fossil');
 if(!eligibleTrace&&!action.target?.choiceId?.includes('chong'))return;
 const category=eligibleTrace?[...tail.map(e=>e.payload?.cardEffect?.type||e.payload?.effect?.type||e.type)].join(',')||'plain-pink':head.type;
 const market=publicRefill?s.workingState.cards.publicCards.filter(c=>!c).length:null;
 const key=[category,action.target?.choiceId,market,Boolean(s.irreversibleBarrier)].join(' / ');
 counts[key]=(counts[key]||0)+1;
 if(!first[key]){first[key]=true;examples.push({action,envelope,market,fossil,key});}
};
try{
 const q=m.automatic();assert.equal(q.n,2008);assert(q.complete);assert.deepEqual(m.save(),checkpoint);
 const result={native:q.n,counts,examples};
 fs.writeFileSync(out,z.gzipSync(JSON.stringify(result)+'\n'));
 console.log(JSON.stringify({native:q.n,counts:Object.entries(counts).sort((a,b)=>b[1]-a[1]).slice(0,50),examples:examples.length}));
}finally{m.dispose();}
