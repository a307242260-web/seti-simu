'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const [root,out]=process.argv.slice(2),file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));Module._cache[file]=mod;
const at='      loadedEnvelope = null;\n      const executeAt = now();',source=fs.readFileSync(file,'utf8');
assert.equal(source.split(at).length,2);
mod._compile(source.replace(at,'      globalThis.captureTrace(current,session,loadedEnvelope);\n'+at),file);mod.loaded=true;
const {open,seat}=require('./native-late-r3'),checkpoint=JSON.parse(fs.readFileSync(root)).checkpoint,m=open(checkpoint),counts={},rows=[];
globalThis.captureTrace=(action,s,envelope)=>{
 const head=s?.queue?.[0];
 if(head?.type!=='science_domain_alien_trace')return;
 const origin=s.journal.actions[0].action.family,headType=head.payload?.traceType||null;
 const type=[headType||'card',s.queue.map(e=>e.type).join(':'),origin,s.undoFrames.length,Boolean(s.irreversibleBarrier)].join('/');
 counts[type]=(counts[type]||0)+1;
 if(headType==='pink'&&s.queue.length===1)rows.push({action,envelope});
};
try{
 const q=m.automatic();assert.equal(q.n,2168);assert(q.complete);assert.deepEqual(m.save(),checkpoint);
 const result={total:Object.values(counts).reduce((a,b)=>a+b,0),native:q.n,counts,rows};
 fs.writeFileSync(out,z.gzipSync(JSON.stringify(result)+'\n'),{flag:'wx'});
 console.log(JSON.stringify({native:q.n,traces:result.total,singlePink:rows.length,
   profiles:Object.entries(counts).sort((a,b)=>b[1]-a[1]).slice(0,22)}));
}finally{m.dispose();}
