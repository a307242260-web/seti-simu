'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),crypto=require('node:crypto');
const {readZ,writeZ,open}=require('./controlled-r3');
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
let code=fs.readFileSync(file,'utf8');
for(const [marker,gate,kind] of [
 ['        provedPublicScanChoices++;','publicScan.barrier','public-scan'],
 ['        provedBluePickSettlements++;','!cards.getCatalogEntryForCard(taskSession.workingState.cards.publicCards[requested.target.publicSlotIndex])','alien-pick']
]){
 assert.equal(code.split(marker).length,2);
 code=code.replace(marker,'        if('+gate+')globalThis.auditRefill('+JSON.stringify(kind)+',stored,requested,nodes.get(child),child);\n'+marker);
}
mod._compile(code,file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const args=process.argv.slice(2),output=args.shift(),rows=[],snapshots={},decisions=[];
function save(e){const key=crypto.createHash('sha256').update(JSON.stringify(e)).digest('hex');snapshots[key]??=e;return key;}
let key;
globalThis.auditRefill=(kind,s,a,child,n)=>{
 const before=s.envelope.session.session.workingState,after=JSON.parse(child.envelope.committedState),seat='player-white';
 const expected=before.cards.publicCards.map(c=>c?.id??null);
 if(kind==='public-scan'&&!a.target.done||kind==='alien-pick')expected[a.target.publicSlotIndex]=null;
 const exposed=after.cards.publicCards.filter((card,i)=>card&&!expected[i]).map(c=>c.id);
 assert(exposed.length>0&&child.informationBarrier?.code==='hidden_card_reveal');
 const publicObservation=n.observation?.publicState?.board?.publicCards||[];
 for(const id of exposed){
  assert(!JSON.stringify(publicObservation).includes(JSON.stringify(id)));
  assert(!JSON.stringify(n.legalActions).includes(JSON.stringify(id)));
 }
 if(kind==='alien-pick'){
  const owner=after.players.players.find(p=>p.id===seat);
  assert(owner.hand.some(c=>c.id===a.target.cardInstanceId&&c.blueBonusOwnerId===seat));
 }
 rows.push({key,kind,proved:true,action:a,family:a.family,target:a.target,barrier:s.informationBarrier??null,
  envelopes:save(s.envelope),nextEnvelope:save(child.envelope),nextBarrier:child.informationBarrier,exposed,
  sourceCard:before.cards.publicCards[a.target.publicSlotIndex]?.cardId,
  nextMenu:n.legalActions.map(x=>[x.family,x.target]),publicObservation,nextStatus:n.status});
};
while(args.length){
 const fixture=args.shift();key=args.shift();
 const root=readZ(fixture)[key].root,seat='player-white',m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat});
 try{
  const n=rows.length,q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
  
  decisions.push({key,rows:rows.length-n,n:q.diagnostics.nativeExecutions,nodes:q.diagnostics.graphNodes,value:q.value,actionId:q.actionId});
 }finally{port.close();m.dispose();}
}
writeZ(output,{rows,snapshots,decisions});
console.log(JSON.stringify(decisions));
