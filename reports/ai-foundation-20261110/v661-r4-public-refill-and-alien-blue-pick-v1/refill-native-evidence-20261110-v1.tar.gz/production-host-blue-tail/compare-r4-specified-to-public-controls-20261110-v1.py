from pathlib import Path
import gzip,json,subprocess,sys
base,new,source,output=sys.argv[1:]
runner=Path(__file__).resolve().with_name('cold-r4-after-cargo-20261110-v1.cjs')
rows={}
for key in json.load(gzip.open(source)):
    pair=[json.loads(subprocess.check_output(['node',str(runner),source,key],cwd=root,text=True)) for root in [base,new]]
    a,b=pair
    assert all(a[k]==b[k] for k in ('actionId','value','roots','nodes','rankGraph','completed')),key
    rows[key]=pair
    print(key,[(x['n'],round(x['ms'],1)) for x in pair],flush=True)
with open(output,'x') as out:json.dump(rows,out,ensure_ascii=False)
