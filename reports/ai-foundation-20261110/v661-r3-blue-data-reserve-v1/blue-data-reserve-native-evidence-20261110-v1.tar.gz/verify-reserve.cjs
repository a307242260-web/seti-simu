'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ}=require('./controlled-r3');
const dir=process.argv[2]||__dirname,file=n=>readZ(path.join(dir,n+'-20261110-v1.json.gz'));
let inputs=0;
function replay(e,actions,end){
 const m=open(e);
 try{
  for(const x of actions)m.apply(x.action||x);
  assert.deepEqual(m.save(),end);inputs+=actions.length;
 }finally{m.dispose();}
}
function gates(a){assert(a.every(x=>x.n===undefined||x.n<=256&&x.ms<=600));}
const base=file('r3-pickup-before-blue-reserve'),next=file('reserve-final-gate');
for(const [k,r] of Object.entries(next)){
 assert(r.pass);const pick=k==='earlier-pick';
 assert.equal(pick?r.a.target.fossilId:r.a.family,
  pick?'fossil_06':k==='fossil_01'?'place_data':'end_turn');
 if(!pick){
  assert.equal(base[k].q.a.family,'place_data');assert.equal(base[k].q.n,r.n);
  assert.deepEqual(r.values.map(x=>x[1]),[191.5,191.5]);
 }
 assert.equal(r.run.failures.length,0);
 for(const q of r.run.rows){assert.equal(q.stop,'r4-first-white-main');gates(q.actions);replay(r.e,q.actions,q.end);}
}
const prior=file('r3-pickup-upstream'),up=file('reserve-upstream');
for(const [k,x] of Object.entries(up)){
 const r=x.rows[0],old=prior[k].rows[0];assert.equal(r.stop,'r4-first-white-main');gates(r.actions);replay(x.root,r.actions,r.end);
 if(k==='before-orange1'||k==='pink-menu-38'){
  assert.deepEqual([old.settled.summary.wallet[0],r.settled.summary.wallet[0]],[117,123]);
  assert.deepEqual([old.settled.summary.income[1],r.settled.summary.income[1]],[3,4]);
 }else{
  assert.deepEqual(old.actions.map(x=>x.action),r.actions.map(x=>x.action));assert.deepEqual(old.end,r.end);
 }
}
const r4=file('reserve-roll-forward');
for(const [k,r] of Object.entries(r4)){
 assert.equal(r.stop,'two-turns');assert.equal(r.actions[1].action.target.cardId,'b_111.webp');gates(r.actions);replay(r.e,r.actions,r.end);
 assert.equal(r.checkpoints.length,2);
}
assert.deepEqual(Object.values(r4).map(r=>r.checkpoints[1].summary.wallet[0]),[129,156,154,143]);
const decks=file('reserve-hidden-decks');
for(const r of Object.values(decks))for(const k of ['obs','menu','a','roots','funding','n'])
 assert.deepEqual(r[k],decks.original[k]);
const hidden=file('reserve-hidden-pickup'),choice=file('r3-pickup-choice-native');
for(const r of Object.values(hidden)){
 for(const step of ['initial','before'])for(const k of ['obs','menu','a','roots','value','n','funding'])
  assert.deepEqual(r[step][k],hidden.original[step][k]);
 replay(r.e,choice.prefix,r.revealedEnvelope);
}
const clean=x=>Object.fromEntries(Object.entries(x).map(([k,{ms,...q}])=>[k,q]));
const formal=file('reserve-formal-parity');
assert.deepEqual(clean(file('r3-pickup-formal-parity')),clean(formal));
assert(Object.values(formal).every(q=>q.complete&&q.n<=256&&q.ms<=600));
console.log(JSON.stringify({inputs,standardRoots:Object.keys(formal).length,phase4:Object.values(r4).map(r=>r.checkpoints[1].summary.wallet[0])}));
