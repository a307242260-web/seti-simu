# R3 data reserve native evidence (2026-11-10)

Run `node <unpacked>/verify-reserve.cjs` from the source root. It replays submissions against the Production kernel and checks exact final state, effect session and RNG without asking the policy again.

- Baseline is `15fd2b92b`; `r3-pickup-before-blue-reserve` measures the three legal states after the B117 claim, using the three continuations in `r3-pickup-two-blue`.
- On v439, `reserve-gate.cjs <base-root.gz> <two-blue.gz> <result.gz> resume` and `reserve-hidden.cjs <base-root.gz> <hidden-results.gz>` reconstruct the root experiments.
- Run `upstream-pickup.cjs <handoffs.gz> <upstream.gz>` with `v661-r172-preserve-assets-handoffs-20261109-v1.json.gz` from the prior evidence noted in the source documentation. Then `reserve-roll-forward.cjs <old-upstream.gz> <upstream.gz> <gate.gz> <roll-forward.gz>` fixes the same B111 reserve choice and runs two white turns of round 4.
- `hidden-pickup.cjs <pickup-choice.gz> <hidden-pickup-result.gz>` physically swaps unrevealed fossils before the reveal.
- The 89 formal cold-root comparison uses the same input and script listed in the archive for the original current-turn delivery. Both output files are included here.
