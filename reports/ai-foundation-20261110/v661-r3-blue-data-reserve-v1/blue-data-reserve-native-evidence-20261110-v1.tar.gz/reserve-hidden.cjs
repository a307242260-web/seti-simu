'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const [src,out]=process.argv.slice(2),root=readZ(src).fossil_06.e,rows={},id='player-white';
assert(!root.session);
for(const label of ['original','normal-deck','amiba-deck','both-decks']){
 const e=structuredClone(root),s=JSON.parse(e.committedState);
 const swap=a=>{assert(a.length>2&&a[0]!==a[2]);[a[0],a[2]]=[a[2],a[0]];};
 if(label==='normal-deck'||label==='both-decks')swap(s.cards.drawPileCardIds);
 if(label==='amiba-deck'||label==='both-decks')swap(s.aliens.amiba.cardDeck);
 e.committedState=createStateStore(s).serialize().serialized;
 const m=open(e),port=createAnalysisPort({composition:m.c,seatId:id,maxCacheEntries:0});
 try{
  const q=createSearchAgent({seatId:id,analysisPort:port}).decide({seatId:id,legalActions:m.menu()}).search;
  assert.deepEqual(m.save(),e);
  const a=m.menu().find(a=>a.actionId===q.actionId);
  assert(q.complete&&!q.unresolved.length&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600);
  assert.equal(a.family,'end_turn');
  const funding=q.lines.filter(r=>r.knownPickupFunding).map(r=>r.knownPickupFunding);
  assert.equal(funding.length,1);
  const row={e,obs:m.owner(id),menu:m.menu(),a,funding,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,roots:q.roots};
  if(rows.original)for(const k of ['obs','menu','a','funding','n','roots'])assert.deepEqual(row[k],rows.original[k]);
  rows[label]=row;console.log(label,a.summary,q.value,row.n,row.ms,funding[0]);
 }finally{port.close();m.dispose();}
}
writeZ(out,rows);
