'use strict';
const {open,readZ,writeZ,short}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),x=readZ(src),rows={};
for(const r of x.rows){
 const m=open(r.start);
 try{
  const claim=m.act('complete_task',q=>q.summary.includes('b_117'));
  const e=m.save(),before=short(m),q=m.automatic();
  console.log(r.label,before.wallet,q.a?.summary,q.n,q.ms,q.roots.map(a=>[m.menu().find(b=>b.actionId===a.actionId)?.summary,a.value,a.status,a.reason]));
  const checks={};
  for(const family of ['end_turn','place_data']){
   const a=m.menu().find(a=>a.family===family);
   if(!a)continue;
   m.restore(e);m.apply(a);checks[family]={action:a,after:short(m),menu:m.menu(),envelope:m.save()};
  }
  rows[r.label]={e,claim,before,q:{...q,checkpoint:undefined},checks};
 }finally{m.dispose();}
}
writeZ(out,rows);
