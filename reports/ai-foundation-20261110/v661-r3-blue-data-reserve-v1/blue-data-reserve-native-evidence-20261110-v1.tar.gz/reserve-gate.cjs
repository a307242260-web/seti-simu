'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,runCases}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [before,pick,out,mode]=process.argv.slice(2),old=readZ(before),earlier=readZ(pick);
const rows={},id='player-white';
for(const [key,e] of [['earlier-pick',earlier.e],...Object.entries(old).map(([k,v])=>[k,v.e])]){
 const m=open(e),port=createAnalysisPort({composition:m.c,seatId:id,maxCacheEntries:0});
 try{
  const q=createSearchAgent({seatId:id,analysisPort:port}).decide({seatId:id,legalActions:m.menu()}).search;
  assert.deepEqual(m.save(),e);
  const a=m.menu().find(a=>a.actionId===q.actionId),funding=q.lines.filter(r=>r.knownPickupFunding).map(r=>r.knownPickupFunding);
  const pass=q.complete&&!q.unresolved.length&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600;
  const values=q.roots.filter(x=>x.value!=null).map(x=>[m.menu().find(a=>a.actionId===x.actionId)?.summary,x.value]);
  rows[key]={e,a,values,funding,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,pass,roots:q.roots,lines:q.lines};
  console.log(key,a?.summary,q.value,rows[key].n,rows[key].ms,JSON.stringify(funding),JSON.stringify(values));
 }finally{port.close();m.dispose();}
 if(mode==='resume'&&rows[key].pass)rows[key].run=runCases(e,[[key,()=>{}]]);
}
writeZ(out,rows);
