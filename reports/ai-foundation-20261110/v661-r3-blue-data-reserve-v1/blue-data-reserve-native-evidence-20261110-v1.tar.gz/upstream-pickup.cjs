'use strict';
const {open,readZ,runCases,writeZ}=require('./controlled-r3');
const [saved,target]=process.argv.slice(2),data=readZ(saved),rows={};
for(const label of ['before-blue1','before-orange1','pink-menu-38','pink-menu-10','after-amiba0','r172-no-prefix']){
 const root=data.origins[label],m=open(root),q=m.automatic();m.dispose();
 console.log(label,q.complete,q.n,q.ms,q.a?.summary,q.value);
 if(q.complete&&q.n<=256&&q.ms<=600)rows[label]={root,...runCases(root,[[label,()=>{}]])};
 else rows[label]={root,stop:{kind:'gate',n:q.n,ms:q.ms,action:q.a}};
}
writeZ(target,rows);
