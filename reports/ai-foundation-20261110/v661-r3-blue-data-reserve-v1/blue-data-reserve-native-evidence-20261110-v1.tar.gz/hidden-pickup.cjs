'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,writeZ}=require('./controlled-r3');
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [f,out]=process.argv.slice(2),d=readZ(f),rows={};
const id='player-white';
function swapWorld(swaps){
 const e=structuredClone(d.origin),s=JSON.parse(e.committedState),c=s.aliens.chong;
 assert(!e.session);
 for(const [a,b] of swaps){
  const [l,r]=[c.fossilsById[a],c.fossilsById[b]];
  assert(l.planetId!==r.planetId&&[l,r].every(f=>f.status==='available'&&!f.visibleToPlayerIds.length));
  const x=c.planetFossilIds[l.planetId],y=c.planetFossilIds[r.planetId];
  [x[x.indexOf(a)],y[y.indexOf(b)]]=[b,a];
  [l.planetId,r.planetId]=[r.planetId,l.planetId];
  const o=c.initialConfiguration.fossilOrder;
  [o[o.indexOf(a)],o[o.indexOf(b)]]=[b,a];
 }
 e.committedState=createStateStore(s).serialize().serialized;
 return e;
}
function measure(m){
 const e=m.save(),port=createAnalysisPort({composition:m.c,seatId:id,maxCacheEntries:0});
 try{
  const q=createSearchAgent({seatId:id,analysisPort:port}).decide({seatId:id,legalActions:m.menu()}).search;
  assert.deepEqual(m.save(),e);
  assert(q.complete&&!q.unresolved.length&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600);
  const funding=q.lines.filter(l=>l.knownPickupFunding).map(l=>l.knownPickupFunding);
  return {obs:m.owner(id),menu:m.menu(),a:m.menu().find(x=>x.actionId===q.actionId),
   roots:q.roots,value:q.value,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,funding};
 }finally{port.close();}
}
for(const [label,swaps,expect] of [
 ['original',[],'fossil_06'],
 ['no-energy-fossil',[['fossil_06','fossil_02']],'fossil_07'],
 ['neither-currency-fossil',[['fossil_06','fossil_02'],['fossil_07','fossil_05']],'fossil_01']
]){
 const e=swapWorld(swaps),m=open(e);
 try{
  const initial=measure(m),fixed=d.prefix.slice(0,-1);
  fixed.forEach(m.apply);
  const before=measure(m);
  m.apply(d.preAction);
  const revealed=measure(m);
  assert.equal(revealed.a.target.fossilId,expect);
  assert.equal(revealed.funding.length,3-Object.keys(rows).length-1);
  for(const x of [initial,before])assert.equal(x.funding.length,0);
  if(rows.original)for(const [k,q] of [['initial',initial],['before',before]])for(const field of ['obs','menu','a','roots','value','n','funding'])
    assert.deepEqual(q[field],rows.original[k][field],label+':'+k+':'+field);
  rows[label]={e,initial,before,revealed,revealedEnvelope:m.save()};
  console.log(label,initial.a.summary,before.a.summary,revealed.a.summary,revealed.funding,revealed.n,revealed.ms);
 }finally{m.dispose();}
}
writeZ(out,rows);
