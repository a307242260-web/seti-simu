'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {open,z,seat}=require('./native-compact-20261110-v1.cjs');
const probe=require(path.resolve('randomizer/game/ai/probe-capital'));
const values=require(path.resolve('randomizer/game/ai/state-value'));
const {sanitizeHiddenInformationObservation}=require(path.resolve('randomizer/game/rule-composition'));
const [file,out]=process.argv.slice(2),fixture=JSON.parse(z.gunzipSync(fs.readFileSync(file))),root=fixture.end;
const m=open(root),obs=m.owner(seat),owner=m.player();
const known=new Set([...obs.selfState.hand,...obs.selfState.reservedCards,...obs.publicState.board.publicCards].filter(Boolean).map(c=>c.id));
const q=probe.fromObservation(obs,seat,values.DEFAULT_WEIGHTS,()=>0);
assert(q.selected.id.endsWith(':enceladus'));
const quoteFacts=probe.fromState(m.state(),owner,values.DEFAULT_WEIGHTS,()=>0);
assert.deepEqual(quoteFacts,q);
const start=values.evaluateStateValue(obs,seat);
function run(pinkAt){
 m.restore(root);const actions=[],ids=new Set(known),gains=[];
 const action=(family,fn)=>{const a=m.act(family,fn);assert.equal(a.actorId,seat);actions.push(a);return a;};
 action('quick_trade',a=>a.target.tradeId==='credits-for-energy');
 action('land');
 action('choose_target',a=>a.target.landTarget?.satelliteId==='enceladus');
 for(const [i,step] of q.selected.ledger.filter(l=>l.selected).entries()){
   action('choose_target',a=>a.target.nebulaId===step.selected.id);
   if(!step.selected.sectorClosure)continue;
   if(i===pinkAt){
     const before=m.facts(),hand=new Set(m.player().hand.map(c=>c.id));
     action('choose_target',a=>a.target.speciesId==='amiba'&&a.target.traceType==='pink'&&a.target.position===4);
     action('choose_card',a=>a.target.choiceId===`amiba:display:${obs.publicState.board.aliens.amibaTraces.displayedCardIndex}`);
     const [card]=m.player().hand.filter(c=>!hand.has(c.id));assert(card);ids.add(card.id);
     gains.push({cardId:card.cardId,score:m.facts().wallet.score-before.wallet.score});
   }else action('choose_target',a=>a.target.stateExtra&&a.target.alienSlotId===1);
 }
 assert.equal(m.save().session,null);
 const masked=sanitizeHiddenInformationObservation(obs,m.owner(seat),{code:'hidden_card_reveal'},ids);
 return {pinkAt,actions,gains,facts:m.facts(),value:values.evaluateStateValue(masked,seat),maskedDisplay:masked.publicState.board.aliens.amibaTraces.displayedCardIndex,end:m.save()};
}
try{
 const rows=[-1,0,2].map(run);
 assert.deepEqual([-1,0,2].map(run),rows);
 m.restore(root);assert.deepEqual(m.save(),root);
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({start,q,rows})),{flag:'wx'});
 console.log(JSON.stringify({start:start.total,quote:q.value,rows:rows.map(r=>[r.pinkAt,r.value.total,r.facts.wallet.score,r.facts.final,r.gains,r.maskedDisplay])}));
}finally{m.dispose();}
