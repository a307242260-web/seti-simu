'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),Module=require('node:module');
const ai=path.resolve('randomizer/game/ai'),file=path.join(ai,'analysis-port.js'),load=Module._extensions['.js'],native=[];
globalThis.captureNative=(a,s)=>native.push({
 family:a.family,phase:a.phase,target:a.target,summary:a.summary,
 effect:s?.queue[0]?.type,parent:s?.journal.actions[0]?.action?.summary
});
Module._extensions['.js']=(m,f)=>{
 if(f!==file)return load(m,f);
 const src=fs.readFileSync(f,'utf8'),anchor='      loadedEnvelope = null;\n      const executeAt = now();';
 assert.equal(src.split(anchor).length,2);
 m._compile(src.replace(anchor,'      globalThis.captureNative(current,session);\n'+anchor),f);
};
const {readZ,writeZ,open,short}=require('./controlled-r3'),{createAnalysisPort}=require(file),{createSearchAgent}=require(path.join(ai,'search-agent'));
const [source,output]=process.argv.slice(2),root=readZ(source).rows['draw-b9'].rows[0].end,m=open(root),seat='player-white';
const port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);assert.equal(q.diagnostics.nativeExecutions,native.length);
 const tab={};
 for(const r of native){
  const k=[r.family,r.effect||r.target?.kind||r.phase,r.parent].filter(Boolean).join(' / ');
  tab[k]=(tab[k]||0)+1;
 }
 const summary=Object.entries(tab).sort((a,b)=>b[1]-a[1]),actions=m.menu();
 console.log(JSON.stringify({n:native.length,ms:q.rootAndSearchMilliseconds,best:actions.find(x=>x.actionId===q.actionId)?.summary,summary}));
 writeZ(output,{root,facts:short(m),native,summary,roots:q.roots,selected:q.actionId,value:q.value});
}finally{port.close();m.dispose();}
