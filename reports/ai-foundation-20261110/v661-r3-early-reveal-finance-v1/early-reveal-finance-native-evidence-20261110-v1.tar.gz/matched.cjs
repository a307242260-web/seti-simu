'use strict';
const assert=require('node:assert/strict');
const {open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const [routes,controls,output]=process.argv.slice(2);
const d=readZ(routes),c=readZ(controls),root=d.fixes[14].origin;
const original=d.followup14.rows.find(r=>r.label==='yellow-first');
const same={};
function check(m,actions){
 const start=m.save(),cuts=[];
 let turn=m.facts().turn;
 for(const a of actions){
  m.apply(a);
  if(m.facts().turn!==turn){
   cuts.push({f:short(m),envelope:m.save()});
   turn=m.facts().turn;
   if(turn===11)break;
  }
 }
 assert.equal(turn,11);
 const next=m.save();m.restore(start);actions.slice(0,moves).forEach(m.apply);assert.deepEqual(m.save(),next);
 return cuts;
}
const route=[...original.prefix,...original.actions.map(x=>x.action)];
let moves=route.findIndex((a,i)=>i>7&&a.family==='end_turn')+1;
// Select the exact prefix at the first scanning decision in the recorded route.
moves=route.findIndex(a=>a.family==='scan');
assert(moves>0);
const proofRoots={original:root,...Object.fromEntries(Object.entries(c.rows).filter(([id])=>id!=='original').map(([id,r])=>[id,r.rows[0].start]))};
for(const [id,r] of Object.entries(proofRoots)){
 const origin=id==='original'?r:(()=>{const cp=structuredClone(root),s=JSON.parse(cp.committedState);
  if(id==='draw-dlc17')[s.cards.drawPileCardIds[0],s.cards.drawPileCardIds[1]]=[s.cards.drawPileCardIds[1],s.cards.drawPileCardIds[0]];
  else if(id==='draw-b9')[s.cards.drawPileCardIds[0],s.cards.drawPileCardIds[5]]=[s.cards.drawPileCardIds[5],s.cards.drawPileCardIds[0]];
  else [s.aliens.chong.cardDeck[0],s.aliens.chong.cardDeck[1]]=[s.aliens.chong.cardDeck[1],s.aliens.chong.cardDeck[0]];
  return {...cp,committedState:JSON.stringify(s)};
 })();
 const m=open(origin);
 try {
  const cuts=check(m,route);
  const {wallet,income,established,computer,blue,tech}=cuts.at(-1).f;
  assert.deepEqual({wallet,income,established,computer,blue,tech},{wallet:[81,1,2,6,0],income:[7,3,2,1],established:114,computer:[1,2,3,4],blue:[1],tech:['blue2','blue3','purple1','purple4']});
  console.log(id,JSON.stringify(cuts.map(x=>x.f)));
  same[id]={origin,cuts,defaultPolicy:id==='original'?d.followup14.rows[0]:runCases(origin,[[id+'-default',()=>{}]]).rows[0]};
 }finally{m.dispose();}
}
writeZ(output,{same,prefix:route.slice(0,moves),nativeFixedPrefixExact:true,scope:'Matched first three white turns; count and do not use blind draw. Verified 81/114 and permanent cash 7 in all four root-equivalent decks.'});
