'use strict';
const assert=require('node:assert/strict');
const {open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const [data,output]=process.argv.slice(2),origin=readZ(data).fixes[14].origin;
function before(e){
 const m=open(e);
 try {
  const q=m.automatic(),{rng}=m.facts();
  return {view:m.owner('player-white'),menu:m.menu(),rng,quotes:q.roots,best:q.a.actionId,n:q.n,ms:q.ms,complete:q.complete};
 } finally{m.dispose();}
}
const same=before(origin),variants=[
 ['draw-dlc17',s=>[s.cards.drawPileCardIds[0],s.cards.drawPileCardIds[1]]=[s.cards.drawPileCardIds[1],s.cards.drawPileCardIds[0]]],
 ['draw-b9',s=>[s.cards.drawPileCardIds[0],s.cards.drawPileCardIds[5]]=[s.cards.drawPileCardIds[5],s.cards.drawPileCardIds[0]]],
 ['display-chong8-next',s=>[s.aliens.chong.cardDeck[0],s.aliens.chong.cardDeck[1]]=[s.aliens.chong.cardDeck[1],s.aliens.chong.cardDeck[0]]]
];
function region(color){
 return ({m,take,act,cut})=>{
  take(m.play('amiba_3.webp'));act('choose_target',a=>a.target.choiceId===`trace:${color}:1`);
  cut('paid-region');act('end_turn');cut('turn-end');
 };
}
const rows={original:runCases(origin,[['pink-first',region('pink')],['blue-first',region('blue')]])};
for(const [id,update] of variants){
 const s=JSON.parse(origin.committedState);update(s);
 const root={...origin,committedState:JSON.stringify(s)},beforeVariant=before(root);
 assert.deepEqual({...beforeVariant,ms:null},{...same,ms:null});
 assert(beforeVariant.complete&&beforeVariant.n<=256&&beforeVariant.ms<=600);
 rows[id]=runCases(root,[[id,region('yellow')]]);
}
writeZ(output,{origin,same,rows,observationAndRankingExact:true});
