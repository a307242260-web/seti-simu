'use strict';
const assert=require('node:assert/strict');
const {open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const {timeline,origin}=readZ(__dirname+'/base.json.gz');
const m=open(origin);
const fixes={};
try {
 for(let i=0;i<35;i++){
  if([14,17,21,35].includes(i)){
   const q=m.automatic(), choices=Object.fromEntries(m.menu().map(a=>[a.actionId,a.summary]));
   fixes[i]={origin:m.save(),summary:short(m),best:q.a.summary,roots:q.roots.map(x=>[choices[x.actionId],x.value]),n:q.n,ms:q.ms,complete:q.complete};
   console.log('root',i,JSON.stringify({...fixes[i],origin:null}));
  }
  m.apply(timeline[i]);
 }
 const q=m.automatic(), choices=Object.fromEntries(m.menu().map(a=>[a.actionId,a.summary]));
 fixes[35]={origin:m.save(),summary:short(m),best:q.a.summary,roots:q.roots.map(x=>[choices[x.actionId],x.value]),n:q.n,ms:q.ms,complete:q.complete};
 console.log('root',35,JSON.stringify({...fixes[35],origin:null}));
} finally {m.dispose();}
for(const f of Object.values(fixes))assert(f.complete&&f.n<=256&&f.ms<=600,'same-root single-decision performance gate before rollout');
const target=(act,id)=>act('choose_target',a=>a.target.choiceId===id);
function blue9({act,take,m,cut}){
 act('analyze');target(act,'trace:2:blue:chong:9');act('choose_card',a=>a.target.source==='display');
 act('end_turn');cut('blue9-resolved');
}
function yellow({act,take,m,cut}){
 take(m.play('amiba_3.webp'));target(act,'trace:yellow:1');
 act('end_turn');cut('yellow-resolved');
}
const cases14=[
 ['reveal-autonomy',()=>{}],['blue9-first',blue9],['yellow-first',yellow],
 ['blue9-then-yellow',x=>{blue9(x);yellow(x)}],['yellow-then-blue9',x=>{yellow(x);blue9(x)}]
];
const cases21=[
 ['after-blue9-autonomy',()=>{}],
 ['only-purple1',x=>{x.act('research_tech');x.act('choose_target',a=>a.target.techId==='purple1'||a.summary==='研究 purple1');}],
 ['purple1-funded-tail',x=>timeline.slice(21,35).forEach(a=>x.take(x.m.apply(a)))]
];
writeZ(process.argv[2],{source:'exact replayed prefix of v661-r172-preserve-assets-handoffs-20261109-v1',fixes,followup14:runCases(fixes[14].origin,cases14),followup21:runCases(fixes[21].origin,cases21)});
