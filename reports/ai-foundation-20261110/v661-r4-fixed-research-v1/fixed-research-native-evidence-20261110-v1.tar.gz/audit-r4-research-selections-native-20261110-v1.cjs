'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),assert=require('node:assert/strict'),Module=require('node:module');
const {open,seat}=require('./native-late-r3'),load=n=>JSON.parse(z.gunzipSync(fs.readFileSync(n)));
const [fixture,out]=process.argv.slice(2),root=load(fixture).rows[0].root,file=path.resolve('randomizer/game/ai/analysis-port.js');
const mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));let src=fs.readFileSync(file,'utf8');
const anchor='        if(researchPick)provedResearchPicks++;else if(researchSelection)provedResearchSelections++;else provedEmptyAmibaResearch++;';
assert.equal(src.split(anchor).length,2);
src=src.replace(anchor,anchor+'\n        globalThis.auditResearchPrefix(researchPick?"pick":researchSelection?"research":"empty-trigger",stored.envelope,requested,nodes.get(child).envelope,child,\n'+
 '          {restoreEnvelope,executeCurrent,snapshot,comp:fork.composition||fork,legalActions,carriedBarrier:stored.informationBarrier,finish:(before,result)=>finishChild(before,result,movementPlanning?nextMovementIntent(node,requested):null,control,stored.informationBarrier,requested,stored)});');
mod._compile(src,file);
const hits=[],counts={};
globalThis.auditResearchPrefix=(kind,before,action,after,node,x)=>{
 x.restoreEnvelope(before,true);const applied=x.executeCurrent(action);
 assert(applied.result.ok);
 const native=x.snapshot(x.comp),d=[];
 const visit=(a,b,k)=>{
  if(a===b||d.length>=10)return;
  if(typeof a==='object'&&a&&typeof b==='object'&&b){
   for(const key of new Set([...Object.keys(a),...Object.keys(b)]))visit(a[key],b[key],k+'.'+key);
  }else d.push([k,JSON.stringify(a)?.slice(0,90),JSON.stringify(b)?.slice(0,90)]);
 };
 visit({...native,committedState:JSON.parse(native.committedState)},{...after,committedState:JSON.parse(after.committedState)},'');
 assert.equal(d.length,0,JSON.stringify({kind,action:action.summary,d}));
 const witness=x.finish(applied.before,applied.result);
 assert.equal(witness.status,node.status);assert.equal(witness.boundary,node.boundary);
 assert.deepEqual(witness.legalActions,node.legalActions);
 counts[kind]=(counts[kind]||0)+1;
 hits.push({kind,before,action,after,status:node.status});
 x.restoreEnvelope(after,true);
};
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent')),m=open(root);
const port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
let summary;
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 summary={actionId:q.actionId,value:q.value,roots:q.roots.map(r=>[r.actionId,r.value,r.realization,r.preparationDebt,r.completion]),nativeWithWitnesses:q.diagnostics.nativeExecutions};
}finally{port.close();m.dispose();}
assert(counts.pick===40&&counts['empty-trigger']===32&&counts.research===56);
fs.writeFileSync(out,z.gzipSync(JSON.stringify({summary,counts,hits})+'\n'),{flag:'wx'});
console.log(JSON.stringify({summary:{...summary,roots:undefined},counts,exact:true}));
