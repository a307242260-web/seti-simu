'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,writeZ}=require('./controlled-r3');
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const [source,out]=process.argv.slice(2);
const rows=readZ(source).results;
const evidence=[1,7].map(index=>{
  const root=rows[index].entry,alternate=structuredClone(root),state=JSON.parse(root.committedState);
  assert.equal(root.session,null);
  for(const pile of [state.cards.drawPileCardIds,state.aliens.amiba.cardDeck,state.aliens.chong.cardDeck]){
    assert(pile.length>=2&&pile[0]!==pile[1]);
    [pile[0],pile[1]]=[pile[1],pile[0]];
  }
  alternate.committedState=createStateStore(state).serialize().serialized;
  const cases=[root,alternate].map(e=>{
    const m=open(e);
    try{
      const visible=m.owner('player-white'),legal=m.menu(),rng=m.facts().rng,q=m.automatic();
      assert(q.complete&&q.n<=256&&q.ms<=600,JSON.stringify([q.complete,q.n,q.ms]));
      assert.deepEqual(m.save(),e);
      return {e,visible,legal,rng,chosen:q.a,value:q.value,roots:q.roots,n:q.n,ms:q.ms};
    }finally{m.dispose();}
  });
  for(const key of ['visible','legal','rng','chosen','value','roots','n'])
    assert.deepEqual(cases[0][key],cases[1][key],key);
  console.log(JSON.stringify([index,cases.map(r=>[r.chosen.summary,r.value,r.n,r.ms])]));
  return {index,cases};
});
writeZ(out,evidence);
