# V667 direct Earth shipment evidence

Run from a checkout of the V667 source, with this archive extracted elsewhere as `$proof`.
Use new output paths: evidence writers reject an existing file. The scripts invoke the same production composition, action menu and seat search as the experiment.

```sh
node "$proof/autonomous.cjs" "$proof/return-cargo-20261111-v1.json.gz" /tmp/v667-autonomous-fresh.json.gz
node "$proof/hidden.cjs" "$proof/return-cargo-20261111-v1.json.gz" /tmp/v667-hidden-fresh.json.gz
node "$proof/standard-gate.cjs" "$PWD" reports/ai-foundation-20261109/v660-public-transport-chain-v1/v660-first3-independent-replay-20261109-v1.checkpoint.json /tmp/v667-standard-fresh.json.gz 31f6eb84.c30b18dd.quick-400.json
node tools/run_node_tests.js --match stationary-cargo-income --match scan-income-after-free-move --match r4-company-tail
node tools/audit_v_state_inputs.js
node tools/run_browser_smokes.js --match production-resource-goal-plan --match production-search-agent-entry
```

Optional expensive dual execution: in a disposable checkout copy `randomizer/game/ai/analysis-port.js` to `randomizer/game/ai/analysis-port.parity.cjs`, then run
`patch randomizer/game/ai/analysis-port.parity.cjs < "$proof/analysis-port-parity.patch"` and
`node "$proof/check-parity.cjs" "$proof/return-cargo-20261111-v1.json.gz"`.
The instrumented file is never used by the production search. Expect 354 native comparisons and 10 root results.
