'use strict';
const assert = require('node:assert/strict');
const {open,readZ,writeZ} = require('./controlled-r3');
const [fixture,out] = process.argv.slice(2), rows=[];
for (const source of readZ(fixture).results) {
  const m = open(source.entry), actions = [];
  try {
    let checkpoint, stop;
    for (let i=0; i<180; i++) {
      if (m.state().turn.gameEnded) {stop='terminal'; break;}
      if (m.menu()[0].actorId!=='player-white') {
        const passive=[];
        m.advanceOpponents(passive);
        actions.push(...passive.map(action=>({action})));
        continue;
      }
      const decision=m.automatic(checkpoint);
      if (!decision.a || !decision.complete || decision.n>256 || decision.ms>600) {
        stop={n:decision.n,ms:decision.ms,summary:decision.a?.summary};
        break;
      }
      checkpoint=decision.checkpoint;
      actions.push({action:m.apply(decision.a),n:decision.n,ms:decision.ms,value:decision.value,
        ...(actions.length===0?{roots:decision.roots}:{})});
    }
    assert(stop);
    const end=m.save(), final=stop==='terminal'?m.state().match.finalScores.find(s=>s.playerId==='player-white').totalScore:null;
    m.restore(source.entry);
    const fixed=actions.slice(0,source.fixed.length);
    assert.deepEqual(fixed.map(x=>x.action),source.fixed);
    fixed.forEach(x=>m.apply(x.action));
    assert.deepEqual(m.save(),source.afterFixed);
    actions.slice(source.fixed.length).forEach(x=>m.apply(x.action));
    assert.deepEqual(m.save(),end);
    const max=[Math.max(...actions.map(x=>x.n||0)),Math.max(...actions.map(x=>x.ms||0))];
    console.log(JSON.stringify([source.name,source.card,stop,final,max,actions.length]));
    rows.push({name:source.name,card:source.card,entry:source.entry,actions,stop,end,final,max});
  } finally {m.dispose();}
}
writeZ(out,{rows});
