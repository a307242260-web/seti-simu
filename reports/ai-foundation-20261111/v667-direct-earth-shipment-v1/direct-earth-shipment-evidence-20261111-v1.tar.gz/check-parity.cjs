const path=require('node:path');
const {open,readZ}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port.parity.cjs'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const data=readZ(process.argv[2]);
for(const r of data.results) {
 const m=open(r.entry);const seatId='player-white';
 try {
   const analysisPort=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
   const q=createSearchAgent({analysisPort,seatId}).decide({seatId,legalActions:m.menu()}).search;
   console.log('PARITY_RESULT',q.actionId,q.value);
 } finally {m.dispose();}
}
