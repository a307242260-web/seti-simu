'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs');
const {open,readZ,writeZ,short}=require('./controlled-r3');
const d=readZ(process.argv[2]),read=f=>JSON.parse(fs.readFileSync(f)),record=read('reports/research/17300415.95a42c16.quick-400.json');
const saved=read(record.savePath),rows=[];
for(const mode of ['new-plan','restore-every-input']){
 const m=open(d.root);
 try{
  let cp;const actions=[];
  for(let i=145;i<172;i++){
   const a=saved.replaySteps[i-1].action;
   if(a.actorId==='player-white'){
    const q=m.automatic(mode==='new-plan'?cp:undefined);
    assert(q.complete&&q.n<=256&&q.ms<=600,JSON.stringify([i,q.n,q.ms,q.complete]));
    if(q.a.actionId!==a.actionId){actions.push({i,a,chosen:q.a,n:q.n,ms:q.ms,V:q.value});break;}
    cp=q.checkpoint;actions.push({i,a,n:q.n,ms:q.ms,V:q.value});
   }
   m.apply(a);
  }
  const matched=actions.filter(r=>!r.chosen).length;
  console.log(JSON.stringify({mode,matched,peak:[Math.max(...actions.map(r=>r.n)),Math.max(...actions.map(r=>r.ms))],last:actions.at(-1),current:short(m)}));
  rows.push({mode,matched,actions,end:m.save(),summary:short(m)});
 }finally{m.dispose();}
}
writeZ(process.argv[3],rows);
