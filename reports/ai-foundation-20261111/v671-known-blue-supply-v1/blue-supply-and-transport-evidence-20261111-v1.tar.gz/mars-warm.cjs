'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs');
const {open,readZ,writeZ,short}=require('./controlled-r3');
const read=f=>JSON.parse(fs.readFileSync(f));
const opener=read('reports/ai-foundation-20261109/v660-public-transport-chain-v1/v660-first3-independent-replay-20261109-v1.checkpoint.json').roundStarts[1];
const record=read('reports/research/17300415.95a42c16.quick-400.json'),history=read(record.savePath).replaySteps,search=new Map(record.metrics.searches.map(x=>[x.step,x]));
const m=open(opener.envelope),replayed=[];
try {
 let cp;
 for(let i=opener.beforeInput;i<145;i++){
  const old=search.get(i);
  if(old){
   const q=m.automatic(cp);
   assert(q.complete&&q.n<=256&&q.ms<=600,JSON.stringify([i,q.n,q.ms]));
   assert.deepEqual([q.a.actionId,q.value,q.n],[old.actionId,old.value,old.diagnostics.nativeExecutions],String(i));
   cp=q.checkpoint;replayed.push(i);
  }
  m.apply(history[i-1].action);
 }
 const root=m.save(),archived=readZ(process.argv[2]).root;
 assert.deepEqual(root,archived);
 const cold=m.automatic(),warm=m.automatic(cp),old=search.get(145);
 assert.deepEqual([warm.a.actionId,warm.value,warm.n],[old.actionId,old.value,old.diagnostics.nativeExecutions]);
 assert.notEqual(cold.a.actionId,warm.a.actionId);
 const summary=short(m);
 writeZ(process.argv[3],{root,summary,carriedCheckpoint:cp,replayed,warm,cold,old});
 console.log(JSON.stringify({replayed:replayed.length,summary,warm:[warm.a.summary,warm.n,warm.value],cold:[cold.a.summary,cold.n,cold.value]}));
}finally{m.dispose();}
