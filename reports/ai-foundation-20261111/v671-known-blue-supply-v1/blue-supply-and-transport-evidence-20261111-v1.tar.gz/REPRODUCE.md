Run from the repository root on Node 22. The .cjs files in this archive use the same directory for their helpers. Output paths must not exist. Parent source for the cold/warm, Mars alternatives, transport-release and transport-payment evidence is V670 (`95a42c162`). The remaining scripts were measured with the restored blue-supply candidate (`4a33e0c06`). All saves are native composition envelopes.

```sh
proof=/absolute/path/to/extracted/archive
node "$proof/mars-warm.cjs" "$proof/mars-credit-20261111-v2.json.gz" /tmp/v671-mars-warm.json.gz
node "$proof/research.cjs" "$proof/mars-credit-20261111-v2.json.gz" /tmp/v671-mars-alternatives.json.gz
node "$proof/transport-release.cjs" "$proof/v661-r172-preserve-assets-handoffs-20261109-v1.json.gz" /tmp/v671-transport-release.json.gz
node "$proof/transport-early.cjs" "$proof/v661-r172-preserve-assets-handoffs-20261109-v1.json.gz" /tmp/v671-transport-early.json.gz
node "$proof/transport-payment.cjs" "$proof/transport-release-20261111-v2.json.gz" /tmp/v671-transport-payment.json.gz
node "$proof/transport-minimal.cjs" "$proof/transport-release-20261111-v2.json.gz" /tmp/v671-transport-minimal.json.gz

# Candidate or the registered V671 source:
node "$proof/mars-prefix-gate.cjs" "$proof/mars-warm-20261111-v1.json.gz" /tmp/v671-mars-prefix.json.gz
node "$proof/mars-hidden.cjs" "$proof/mars-warm-20261111-v1.json.gz" /tmp/v671-mars-hidden.json.gz
node "$proof/standard-gate.cjs" "$PWD" reports/ai-foundation-20261109/v660-public-transport-chain-v1/v660-first3-independent-replay-20261109-v1.checkpoint.json /tmp/v671-standard-gate.json.gz 17300415.95a42c16.quick-400.json
node "$proof/verify-official.cjs" reports/research/17300415.95a42c16.quick-400.json reports/research/93d07f1e.4a33e0c0.quick-400.json reports/ai-foundation-20261109/v660-public-transport-chain-v1/v660-first3-independent-replay-20261109-v1.checkpoint.json /tmp/v671-verified.json.gz 4a33e0c0
```

`transport-release.cjs` and `transport-early.cjs` normalize only the runtime effect-session identifier when comparing independently recreated checkpoints. Each autonomous suffix is then restored and replayed within its original composition, comparing exact envelope bytes. Watchdog timings vary with load; do not run the experiments concurrently with unrelated benchmarks.
