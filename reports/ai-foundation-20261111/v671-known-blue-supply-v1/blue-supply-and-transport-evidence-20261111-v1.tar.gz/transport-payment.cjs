'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,runCases}=require('./controlled-r3');
const d=readZ(process.argv[2]),root=d.cuts.find(c=>c.i===64).state,m=open(root),menu=m.menu();
try{
 assert(menu.length===3&&menu.every(a=>a.family==='choose_payment'));
 const choices=menu.map(a=>{const c=m.player().hand.find(x=>x.id===a.target.cardIds[0]);assert(c);return {a,name:c.cardId};});
 const cold=m.automatic(),start=d.cuts.find(c=>c.i===63).state;
 m.restore(start);
 const move=m.automatic();
 assert.equal(move.a.actionId,d.fixed[63].actionId);
 m.apply(move.a);
 const warm=m.automatic(move.checkpoint);
 assert.notEqual(warm.a.actionId,cold.a.actionId);
 const r=runCases(root,choices.map(({a,name})=>[name,h=>h.take(h.m.apply(a))]));
 writeZ(process.argv[3],{root,cold,warm,move,choices,...r});
 console.log(JSON.stringify({choices:choices.map(({a,name})=>[a.actionId,name]),warm:warm.a.actionId,cold:cold.a.actionId,
 rows:r.rows.map(r=>[r.label,r.settled?.summary])}));
}finally{m.dispose();}
