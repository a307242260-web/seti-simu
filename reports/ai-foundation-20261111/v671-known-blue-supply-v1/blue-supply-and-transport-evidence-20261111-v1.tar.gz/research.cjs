'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {readZ,writeZ,runCases,open,short}=require('./controlled-r3');
const [file,out]=process.argv.slice(2);
const {root,rows}=readZ(file);
function end(h){h.act('end_turn');const acts=[];h.m.advanceOpponents(acts);h.take(...acts);}
function source(k){return rows.find(r=>r.label===k+' / none');}
function untilLastIncome(r){return r.prefix.slice(0,r.prefix.findIndex(a=>a.family==='choose_card'&&a.summary==='收入 b_101.webp'));}
const approaches=[];
for(const k of ['company','publicity']){
 const r=source(k),a=untilLastIncome(r);
 const lastLand=a.findLastIndex(x=>x.family==='choose_target'&&x.target?.traceType==='yellow');
 assert(lastLand>=0);
 approaches.push([k+' / 到达前先交回',h=>{
  for(const action of a.slice(0,a.findIndex(x=>x.family==='end_turn')))h.take(h.m.apply(action));
 }]);
 approaches.push([k+' / 登陆后交回',h=>{for(const action of a.slice(0,lastLand+1))h.take(h.m.apply(action));}]);
}
const publicity=untilLastIncome(source('publicity')),company=untilLastIncome(source('company'));
const attach=(h,p)=>p.forEach(a=>h.take(h.m.apply(a)));
const choices={
 'DLC32 永久钱':h=>{attach(h,publicity);h.act('choose_card',a=>a.summary==='收入 dlc_32.png');end(h);},
 'DLC25 永久电':h=>{
  const source=publicity.slice(0,-4);
  attach(h,source);
  h.take(...h.m.swap('dlc_32.png','dlc_25.png'));
  attach(h,publicity.slice(-4));
  h.act('choose_card',a=>a.summary==='收入 dlc_25.png');end(h);
 },
 '公司登陆后不插收入':h=>{attach(h,company.slice(0,-4));end(h);},
 '宣传购牌后不插收入':h=>{attach(h,publicity.slice(0,-4));end(h);},
};
const placements=[];
for(const [name,prep] of Object.entries(choices)){
 approaches.push([name+' / 自主',prep]);
 const m=open(root);try{
   const h={m,take:(...a)=>a[0],act:(f,p)=>m.act(f,p)};prep(h);m.play('b_101.webp');
   placements.push({name,summary:short(m),choices:m.menu()});
   for(const t of m.menu().filter(a=>a.target?.tileId)){
    approaches.push([name+' / B101 研究 '+t.summary,h=>{
      prep(h);h.take(h.m.play('b_101.webp'));
      h.act('choose_target',a=>a.target.tileId===t.target.tileId&&a.target.blueSlot===t.target.blueSlot);
    }]);
   }
 }catch(e){console.log('KNOWN_SETUP_FAILURE',name,String(e).slice(0,300));}finally{m.dispose();}
}
const result=runCases(root,approaches);
writeZ(out,{root,placements,...result});
