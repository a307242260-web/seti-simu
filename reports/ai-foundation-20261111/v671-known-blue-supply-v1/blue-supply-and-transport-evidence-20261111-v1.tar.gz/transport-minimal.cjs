'use strict';
const {readZ,writeZ,runCases}=require('./controlled-r3');
const d=readZ(process.argv[2]),cases=[];
for(const mode of ['direct','amiba0','amiba0+fill']){
 for(const pink of ['amiba','reveal']){
  cases.push([mode+'/'+pink,h=>{
   if(mode!=='direct'){
    for(const a of d.fixed.slice(0,mode==='amiba0'?2:6))h.take(h.m.apply(a));
    h.act('end_turn');const passive=[];h.m.advanceOpponents(passive);passive.forEach(a=>h.take(a));
   }
   h.take(h.m.play('dlc_19.png'));
   h.act('choose_target',a=>a.summary.includes('织女一'));
   h.act('choose_target',a=>a.summary.includes('织女一'));
   h.act('choose_target',a=>pink==='reveal'?a.target.choiceId==='trace:2:pink':a.target.choiceId==='trace:1:pink:amiba:4');
  }]);
 }
}
writeZ(process.argv[3],runCases(d.root,cases));
