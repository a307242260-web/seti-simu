'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,writeZ}=require('./controlled-r3');
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const [input,out]=process.argv.slice(2),rows=[];
for(const x of [readZ(input)]){
 const alternative=structuredClone(x.root),s=JSON.parse(alternative.committedState);
 for(const deck of [s.cards.drawPileCardIds,s.aliens.amiba.cardDeck,s.aliens.chong.cardDeck]){
  assert(deck.length>=2);[deck[0],deck[1]]=[deck[1],deck[0]];
 }
 alternative.committedState=createStateStore(s).serialize().serialized;
 const variants=[x.root,alternative].map(e=>{
  const m=open(e);
  try{
   const visible=m.owner('player-white'),legal=m.menu(),rng=m.facts().rng,q=m.automatic();
   assert(q.complete&&q.n<=256&&q.ms<=600);assert.deepEqual(m.save(),e);
   return {e,visible,legal,rng,choice:q.a,value:q.value,n:q.n,ms:q.ms,roots:q.roots};
  }finally{m.dispose();}
 });
 for(const key of ['visible','legal','rng','choice','value','n','roots'])assert.deepEqual(variants[0][key],variants[1][key],key);
 console.log(JSON.stringify(["standard-145",variants.map(r=>[r.choice.summary,r.value,r.n,r.ms])]));
 rows.push({card:"standard-145",variants});
}
writeZ(out,{rows});
