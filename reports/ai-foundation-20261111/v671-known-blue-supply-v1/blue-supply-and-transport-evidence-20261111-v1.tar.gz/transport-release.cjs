'use strict';
const path=require('node:path'),assert=require('node:assert/strict');
const {open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const canonical=e=>JSON.parse(JSON.stringify(e).replace(/effect-session-\d+/g,'effect-session-local'));
const [input,out]=process.argv.slice(2),d=readZ(input);
const read=f=>require(path.resolve(f));
const record=read('reports/research/17300415.95a42c16.quick-400.json');
const history=read(record.savePath).replaySteps;
const from=record.roundEnds[1].beforeInput,opening=read(record.roundEnds[1].checkpointPath).coreState.compositionEnvelope;
const m=open(opening);let root,blocked=null,first;
const fixed=[],cuts=[];
try{
 for(let n=from;n<172;n++)m.apply(history[n-1].action);
 root=m.save();first=short(m);
 assert(m.menu().some(a=>a.family==='play_card'&&a.summary==='amiba_0.webp'));
 for(const [i,a] of d.timeline.entries()){
  const match=m.menu().find(x=>x.actionId===a.actionId&&x.actorId===a.actorId);
  if(!match){blocked={i,needed:a,menu:m.menu(),state:m.save(),facts:short(m)};break;}
  fixed.push(m.apply(a));
  if(Object.values(d.checkpoints).some(x=>x.index===i+1))cuts.push({i:i+1,state:m.save(),facts:short(m)});
 }
 const cases=cuts.filter((c,i)=>i===0||[7,10,38,41,58,63,64,72].includes(c.i)).map(c=>[String(c.i),h=>{
   for(const a of fixed.slice(0,c.i))h.take(h.m.apply(a));
   assert.deepEqual(canonical(h.m.save()),canonical(c.state));
 }]);
 const result=runCases(root,cases);
 console.log(JSON.stringify({root:first,fixed:fixed.length,blocked:blocked&&{i:blocked.i,action:blocked.needed.summary,menu:blocked.menu.map(x=>x.summary),facts:blocked.facts},cuts:cuts.map(c=>c.i)}));
 writeZ(out,{root,first,fixed,cuts,blocked,...result});
}finally{m.dispose();}
