'use strict';
const { readZ, writeZ, runCases } = require('./controlled-r3');
const [source, out] = process.argv.slice(2);
const root = readZ(source).rows.find(row => row.i === 194).before;

function place(h, slot) {
  h.act('place_data');
  h.act('choose_target', action => slot ? action.target.blueSlot === slot : action.target.target === 'computer');
}

const cases = [];
for (const income of ['amiba_1.webp', 'b_16.webp']) {
  const available = income === 'b_16.webp' ? 'amiba_1.webp' : 'b_16.webp';
  for (const swap of ['dlc_25.png', available]) {
    cases.push([income + ' / swap ' + swap + ' for exposed DLC17', h => {
      h.act('choose_target', action => action.target.tileId === 'purple2');
      h.take(h.m.corner('amiba_7.webp'));
      for (let i = 0; i < 4; i++) place(h);
      h.act('choose_card', action => action.summary === '收入 ' + income);
      h.act('quick_trade', action => action.target.tradeId === 'publicity-for-card');
      h.take(h.m.pick('dlc_25.png'));
      h.cut('after-market-refill');
      if (!h.m.facts().market.some(card => card?.[1] === 'dlc_17.png')) return;
      h.take(...h.m.swap(swap, 'dlc_17.png'));
      h.take(h.m.corner('dlc_17.png'));
      place(h, 1);
      h.cut('funded-before-end');
      h.act('end_turn');
      const passive = [];
      h.m.advanceOpponents(passive);
      h.take(...passive);
      h.cut('funded');
      h.act('scan');
    }]);
  }
}
writeZ(out, { root, ...runCases(root, cases) });
