'use strict';
const {open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const [source,out]=process.argv.slice(2),d=readZ(source),root=d.rows.find(r=>r.i===219).before;
const end=h=>{h.act('end_turn');const a=[];h.m.advanceOpponents(a);h.take(...a);};
function research(h,tile,slot){h.act('research_tech');h.act('choose_target',a=>a.target.tileId===tile&&(!slot||a.target.blueSlot===slot));}
function fill(h,slot){h.act('place_data');h.act('choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');}
function prep(h,techFirst=true,keepLast=false){
 if(techFirst){research(h,'purple2');end(h);h.take(h.m.corner('amiba_9.webp'));research(h,'blue1',3);}
 else {research(h,'blue1',3);h.take(h.m.corner('amiba_9.webp'));}
 fill(h);fill(h,3);
 if(!keepLast)fill(h);
 end(h);
 if(!techFirst){research(h,'purple2');end(h);}
 h.cut('before-analysis');
 h.act('analyze');h.cut('analysis-target');
}
function settle(h,choice){
 h.act('choose_target',a=>a.summary.includes(choice));
 const a=h.m.menu().find(a=>a.family==='choose_card'&&a.summary.startsWith('获得展示的'));
 if(a)h.take(h.m.apply(a));
 h.cut('analysis-result');
}
function trade(h,pair,resource='energy'){
 h.act('quick_trade',a=>a.target.tradeId==='cards-for-'+resource);
 for(const card of pair)h.act('choose_payment',a=>a.summary===card&&a.target.select);
 h.act('choose_payment',a=>a.target.confirm===true);
}
function quickData(h){fill(h);fill(h,1);}
const cases=[];
for(const first of [true,false])for(const keep of [true,false]){
 const label=(first?'purple-first':'blue-first')+(keep?'-hold-1D':'-fill6');
 for(const target of ['蓝3号','蓝2号','额外痕迹位','外星人 2 蓝色']){
  cases.push([label+' '+target+' auto',h=>{prep(h,first,keep);settle(h,target);}]);
 }
}
const r=runCases(root,cases);
writeZ(out,{root,...r});
