'use strict';
const {open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const [source,out]=process.argv.slice(2),d=readZ(source),results={};
function end(h){h.act('end_turn');const a=[];h.m.advanceOpponents(a);h.take(...a);}
function trade(h,pair){
 h.act('quick_trade',a=>a.target.tradeId==='cards-for-energy');
 for(const card of pair)h.act('choose_payment',a=>a.summary===card&&a.target.select);
 h.act('choose_payment',a=>a.target.confirm===true);
}
function fill(h,slot){h.act('place_data');h.act('choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');}
function corner(h,card){h.take(h.m.corner(card));}
function income(h,card){
 for(let i=h.m.facts().computer.length;i<4;i++)fill(h);
 h.act('choose_card',a=>a.summary==='收入 '+card);
}
function payScan(h,data,energy,publicity){
 corner(h,data);fill(h);fill(h,1);trade(h,energy);
 if(publicity)corner(h,publicity);
 end(h);h.cut('scan-payer');h.act('scan');
}
function b16(h){end(h);h.take(h.m.play('b_16.webp'));h.act('choose_target',a=>a.target.skip||a.summary==='跳过');}
function a5(h,card){end(h);h.take(h.m.play('amiba_5.webp'));h.take(h.m.pick(card));}
const rows=d.rows.filter(r=>r.label.includes('蓝3号')||r.label.includes('蓝2号'));
for(const row of rows){
 const cases=[],m=open(row.start),origin=m.save();
 const add=(label,prep,suffix,doPrep=true)=>cases.push([label,h=>{if(doPrep)prep(h);suffix(h);}]);
 const builders=[];
 if(row.label.includes('蓝3号')){
  for(const data of ['amiba_5.webp','amiba_2.webp']) for(const pair of [['b_16.webp','dlc_25.png'],[data==='amiba_2.webp'?'amiba_5.webp':'amiba_2.webp','b_16.webp']]){
   const base=h=>payScan(h,data,pair);
   builders.push(['standard scan '+data+' '+pair.join('+'),base]);
  }
 }
 if(row.label.includes('蓝2号')){
  builders.push(['standard scan hold publicity',h=>{
   fill(h);corner(h,'amiba_5.webp');fill(h,1);trade(h,['b_16.webp','dlc_25.png']);end(h);h.cut('scan-payer');h.act('scan');
  }]);
 }
 builders.push(['B16',b16],['Amiba5 take DLC17',h=>a5(h,'dlc_17.png')]);
 try{
  for(const [label,prep] of builders){
   m.restore(origin);const accepted=[];
   const h={m,take:(...a)=>accepted.push(...a),act:(f,p)=>{const a=m.act(f,p);accepted.push(a);return a;},cut:()=>{}};
   prep(h);
   const rec=h=>accepted.forEach(a=>h.take(h.m.apply(a)));
   const start=m.save(),options=m.menu().filter(a=>a.target?.nebulaId||a.summary.includes('红色区域'));
   if(!options.length){console.log(label,'NO TARGETS',m.menu().map(a=>a.summary));continue;}
   for(const option of options){
    m.restore(start);m.apply(option);
    const b=m.menu().filter(a=>a.family==='choose_card'&&a.target?.nebulaId);
    for(const pub of b.length?b:[null]){
     m.restore(start);m.apply(option);if(pub)m.apply(pub);
     const s=short(m),key=label+' / '+option.summary+(pub?' / '+pub.summary:'');
     const fixed=h=>{rec(h);h.take(h.m.apply(option));if(pub)h.take(h.m.apply(pub));h.cut('scan-or-red-result');};
     add(key+' auto',fixed,()=>{});
     if(s.hand.includes('dlc_25.png')&&!m.save().session){
      const known=s.hand.filter(card=>['amiba_2.webp','amiba_5.webp','dlc_17.png'].includes(card));
      const missing=4-s.computer.length-s.wallet[4];
      if(missing<=known.length)add(key+' fixed DLC25 E',fixed,h=>{for(const card of known.slice(0,Math.max(0,missing)))corner(h,card);income(h,'dlc_25.png');});
     }
    }
   }
  }
 }finally{m.dispose();}
 results[row.label]={root:origin,...runCases(origin,cases)};
}
writeZ(out,results);
