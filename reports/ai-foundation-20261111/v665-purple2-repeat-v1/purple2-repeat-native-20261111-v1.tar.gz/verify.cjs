'use strict';

const assert = require('node:assert/strict');
const path = require('node:path');
const { open, readZ, short } = require('./controlled-r3');

const checkoutWithOfficialRecord = path.resolve(process.argv[2] || '.');
const record = require(path.join(checkoutWithOfficialRecord, 'reports/research/926c5bc2.9a1cafee.quick-400.json'));
const official = require(path.join(checkoutWithOfficialRecord, record.savePath));
const checkpoint = require(path.join(checkoutWithOfficialRecord, record.roundEnds[1].checkpointPath));
const data = name => readZ(path.join(__dirname, name));
const roots = new Map(data('official-roots-20261111-v1.json.gz').rows.map(row => [row.i, row.before]));
const standard = open(checkpoint.coreState.compositionEnvelope);
let officialInputs = 0;
try {
  for (const { stepIndex, action } of official.replaySteps.slice(checkpoint.replayCursor.stepIndex)) {
    if (roots.has(stepIndex + 1)) assert.deepEqual(standard.save(), roots.get(stepIndex + 1));
    standard.apply(action);
    officialInputs += 1;
  }
  assert.equal(standard.save().committedState, official.committedState);
  assert.deepEqual(standard.save().session, official.session);
} finally {
  standard.dispose();
}

const funding = data('funding-20261111-v1.json.gz');
const earlyData = data('early-data-20261111-v1.json.gz');
const scans = data('scans-20261111-v2.json.gz');
const latePair = data('late-pair-20261111-v1.json.gz');
const latePay = data('late-pay-20261111-v1.json.gz');
const lateRed = data('late-red-20261111-v1.json.gz');
assert.deepEqual(funding.root, roots.get(194));
assert.deepEqual(earlyData.root, roots.get(194));
assert.deepEqual(latePair.root, roots.get(219));
for (const [label, group] of Object.entries(scans)) {
  assert.deepEqual(group.root, funding.rows.find(row => row.label === label).checkpoints['scan-first-menu'].state);
}
for (const collection of [latePay, lateRed]) {
  for (const [label, group] of Object.entries(collection)) {
    assert.deepEqual(group.root, latePair.rows.find(row => row.label === label).start);
  }
}

const totals = { officialInputs, branches: 0, controlledFailures: 0, nativeInputs: 0, peakNative: 0, peakMs: 0 };
for (const group of [funding, earlyData, ...Object.values(scans), latePair, ...Object.values(latePay), ...Object.values(lateRed)]) {
  const machine = open(group.root);
  try {
    for (const row of group.rows) {
      machine.restore(group.root);
      for (const action of row.prefix) machine.apply(action);
      assert.deepEqual(machine.save(), row.start);
      for (const action of row.actions) {
        if (action.action.family === 'pass' && action.action.actorId === 'player-white' && machine.facts().round === 3) {
          assert.deepEqual(machine.save(), row.settled.state);
          assert.deepEqual(JSON.parse(JSON.stringify(short(machine))), row.settled.summary);
        }
        if (action.n !== undefined) {
          assert(action.n <= 256 && action.ms <= 600, row.label);
          totals.peakNative = Math.max(totals.peakNative, action.n);
          totals.peakMs = Math.max(totals.peakMs, action.ms);
        }
        machine.apply(action.action);
      }
      assert.deepEqual(machine.save(), row.end);
      assert.equal(row.stop, 'r4-first-white-main');
      assert.equal(machine.facts().round, 4);
      totals.branches += 1;
      totals.nativeInputs += row.prefix.length + row.actions.length;
    }
    for (const row of group.failures) {
      machine.restore(group.root);
      for (const action of row.prefix) machine.apply(action);
      assert.deepEqual(machine.save(), row.checkpoint);
      totals.controlledFailures += 1;
    }
  } finally {
    machine.dispose();
  }
}
console.log(JSON.stringify(totals, null, 2));
