'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),root=d.rows.find(r=>r.i===194).before;
function end(h){h.act('end_turn');const actions=[];h.m.advanceOpponents(actions);h.take(...actions);}
function prepare(h,income='amiba_1.webp'){
 h.act('choose_target',a=>a.target.tileId==='purple2');
 h.take(h.m.corner('amiba_7.webp'));
 for(let i=1;i<=4;i++){
  h.act('place_data');h.act('choose_target',a=>a.target.target==='computer');
 }
 h.act('choose_card',a=>a.summary==='收入 '+income);
 h.cut('income-paid');
}
function acquire(h,id){h.act('quick_trade',a=>a.target.tradeId==='publicity-for-card');h.take(h.m.pick(id));}
function trade(h,pair){
 h.act('quick_trade',a=>a.target.tradeId==='cards-for-energy');
 for(const name of pair)h.act('choose_payment',a=>a.summary===name&&a.target.select);
 h.act('choose_payment',a=>a.target.confirm===true);
}
function scan(h){
 h.act('scan');
 h.cut('scan-first-menu');
}
const cases=[
 ['Purple2-pay-income-then-auto',h=>prepare(h)],
 ['Purple2-two-held-cards-then-auto',h=>{prepare(h);trade(h,['amiba_9.webp','b_16.webp']);end(h);h.cut('funded');}],
 ['Purple2-two-held-cards-then-fixed-scan',h=>{prepare(h);trade(h,['amiba_9.webp','b_16.webp']);end(h);h.cut('funded');scan(h);}],
];
for(const card of ['dlc_25.png','dlc_20.png','dlc_24.png']){
 for(const pay of ['b_16.webp','amiba_1.webp']) {
  const income=pay==='b_16.webp'?'amiba_1.webp':'b_16.webp';
  cases.push([['Purple2-buy',card,'pay',pay,'income',income].join(' '),h=>{
   prepare(h,income);acquire(h,card);trade(h,[pay,card]);end(h);h.cut('funded');scan(h);
  }]);
 }
}
cases.push(['Purple2-keep-A9-then-Orange4',h=>{
 prepare(h);h.take(h.m.corner('b_16.webp'));end(h);
 h.act('research_tech');h.act('choose_target',a=>a.target.tileId==='orange4');
 h.cut('extra-tech');end(h);h.cut('funded');scan(h);
}]);
const result=runCases(root,cases);
for(const row of result.rows){
 if(!row.checkpoints.funded)continue;
 const m=open(row.checkpoints.funded.state);
 try{
  let mercury=[];
  for(const x of row.actions){
   if(x.action.target?.nebulaId||x.action.family==='scan') {
    const step=m.save().session?.session?.queue[0];
    const source=step?.payload?.options?.cost??null;
    mercury.push([x.action.summary,source,m.facts().wallet.availableData]);
   }
   const a=m.menu().find(a=>a.actionId===x.action.actionId);if(!a)break;
   m.apply(x.action);
  }
  console.log('SCAN',row.label,JSON.stringify(mercury));
 }finally{m.dispose();}
}
writeZ(out,{root,...result});
