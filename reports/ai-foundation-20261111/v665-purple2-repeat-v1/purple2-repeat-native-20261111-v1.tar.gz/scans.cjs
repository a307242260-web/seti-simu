'use strict';
const assert=require('node:assert/strict');
const {open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),result={};
const selected=d.rows.filter(r=>['Purple2-two-held-cards-then-fixed-scan',
 'Purple2-buy dlc_20.png pay b_16.webp income amiba_1.webp','Purple2-keep-A9-then-Orange4'].includes(r.label));
for(const row of selected){
 const root=row.checkpoints['scan-first-menu'].state,m=open(root),cases=[],menu=[];
 try{
  for(const earth of m.menu().filter(a=>a.target?.nebulaId)){
   m.restore(root);m.apply(earth);
   for(const pub of m.menu().filter(a=>a.target?.nebulaId||a.target?.done)){
    m.restore(root);m.apply(earth);m.apply(pub);
    const pre=m.save();
    const mercury=m.menu().filter(a=>a.family==='choose_target'&&(a.target?.nebulaId||a.target?.skip));
    for(const choice of mercury.length ? mercury : [null]){
     m.restore(pre);
     const before=short(m);
     if(choice)m.apply(choice);
     const p=choice?[earth,pub,choice]:[earth,pub];
     const label=p.map(a=>a.summary).join(' / ');
     menu.push({label,p,before,ready:short(m)});
     cases.push([label,h=>p.forEach(a=>h.take(h.m.apply(a)))]);
    }
   }
  }
 }finally{m.dispose();}
 result[row.label]={root,menu,...runCases(root,cases)};
}
writeZ(out,result);
