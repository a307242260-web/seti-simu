Run from the V669 source checkout. Extract this archive to a separate fresh directory (`$proof`).
Extract the three input fixtures from the two earlier evidence archives into that directory:
- V667 retain-Amiba: `cargo-cash-retain-20261111-v1.json.gz`, `r3-retained-amiba5-fourth-20261111-v1.json.gz`.
- V668 loaded-cash-swap: `loaded-cash-choice-20261111-v1.json.gz`.

```sh
node "$proof/admission.cjs" /tmp/v669-company-admission-fresh.json.gz
node "$proof/standard-gate.cjs" "$PWD" reports/ai-foundation-20261109/v660-public-transport-chain-v1/v660-first3-independent-replay-20261109-v1.checkpoint.json /tmp/v669-standard-fresh.json.gz 08d5a8d9.6071c49f.quick-400.json
node tools/run_node_tests.js --match stationary-cargo-income --match decision-search --match scan-income-after-free-move --match r4-company-tail
node tools/audit_v_state_inputs.js
node tools/run_browser_smokes.js --match production-resource-goal-plan --match production-search-agent-entry
```
The two original R4 no-swap controls (214/220 and 214/212) are the fully replayed V668 terminal records in the prior loaded-cash archive. The two new R3 paths match the fixed cash-preparation endpoints and independently replay the four archived same-retained-card R4 paths.
