'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {readZ,writeZ,open,runCases}=require('./controlled-r3');
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent,OPTIONS,BUDGET}=require(path.resolve('randomizer/game/ai/search-agent'));
const {createStateValueEvaluator}=require(path.resolve('randomizer/game/ai/state-value'));
const {searchDecision}=require(path.resolve('randomizer/game/ai/decision-search'));
const amiba=require(path.resolve('randomizer/game/aliens/amiba'));
const [out]=process.argv.slice(2),seatId='player-white';
const inputs=readZ(path.join(__dirname,'cargo-cash-retain-20261111-v1.json.gz')).groups.filter(g=>g.label.includes('saturn'));
const controlled=readZ(path.join(__dirname,'loaded-cash-choice-20261111-v1.json.gz')).groups;
const fourth=readZ(path.join(__dirname,'r3-retained-amiba5-fourth-20261111-v1.json.gz')).results;
const rows=[];
function variant(e,edit){
 const s=JSON.parse(e.committedState);edit(s);
 return {...e,committedState:createStateStore(s).serialize().serialized};
}
function check(e,cap){
 const m=open(e),port=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
 try{
  const start=performance.now(),visible=m.owner(seatId),menu=m.menu();
  const q=cap==null?createSearchAgent({analysisPort:port,seatId}).decide({seatId,legalActions:menu}).search
   :searchDecision({port,root:port.openRoot(),evaluate:createStateValueEvaluator(seatId),budget:BUDGET,...OPTIONS,
     modelKey:'cap-test',scanOrbitBudget:{nativeInputs:cap,deadline:start+600}});
  assert(q.complete&&!q.unresolved.length&&(q.rootAndSearchMilliseconds??performance.now()-start)<=600);
  assert(q.diagnostics.nativeExecutions<=256);
  assert.deepEqual(m.save(),e);
  return {visible,menu,choice:q.actionId,proof:q.retainRegionCard,roots:q.roots,value:q.value,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds};
 }finally{port.close();m.dispose();}
}
for(const [i,source] of inputs.entries()){
 const control=controlled.find(r=>r.origin===source.label).rows.at(-1);
 const base=check(source.root);
 assert.equal(base.value,186+i);assert.equal(base.n,27);assert.equal(base.proof.nativeInputs,15);
 const changed=variant(source.root,s=>{
  for(const p of [s.cards.drawPileCardIds,s.aliens.amiba.cardDeck,s.aliens.chong.cardDeck]){
   assert(p.length>=2);[p[0],p[1]]=[p[1],p[0]];
  }
 });
 const hidden=check(changed);
 for(const k of ['visible','menu','choice','proof','roots','value','n'])assert.deepEqual(base[k],hidden[k],k);
 const noRegion=check(variant(source.root,s=>{
  for(const symbol of amiba.listSymbolsInRegion(s.aliens,'red'))
   if(Object.keys(symbol.reward.gain).length)assert(amiba.resolveSymbolAtSlot(s.aliens,symbol.slotId).ok);
 }));
 assert.equal(noRegion.proof,undefined);
 const active=check(variant(source.root,s=>{s.turn.passedPlayerIds=s.turn.passedPlayerIds.filter(id=>id!=='player-green');}));
 assert.equal(active.proof,undefined);
 const exhausted=check(source.root,15);
 assert.equal(exhausted.proof,undefined);assert.equal(exhausted.n,15);assert.equal(exhausted.choice,base.proof.visibleActionId);
 const row=runCases(source.root,[['无固定行动',()=>{}]]).rows[0];
 assert.deepEqual(row.actions.map(a=>a.action),[...control.prefix,...control.actions.map(a=>a.action)]);
 assert.deepEqual(row.settled.state,control.settled.state);assert.deepEqual(row.end,control.end);
 assert.deepEqual(row.actions.slice(1,12).map(a=>a.n),Array(11).fill(0));
 const replays=[];
 for(const witness of fourth.filter(w=>w.name===source.label)){
  assert.deepEqual(row.settled.state,witness.root);
  const m=open(witness.root);
  try{
   witness.actions.forEach(x=>m.apply(x.action));
   assert.deepEqual(m.save(),witness.end);
   replays.push({card:witness.card,score:witness.terminal.totalScore,n:witness.actions.length});
  }finally{m.dispose();}
 }
 assert.equal(replays.length,2);
 rows.push({origin:source.label,base,hidden,noRegion,active,exhausted,row,replays});
 console.log(JSON.stringify([source.label,base.proof,base.ms,hidden.ms,noRegion.n,active.n,exhausted.n,replays]));
}
writeZ(out,{rows});
