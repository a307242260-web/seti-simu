'use strict';
const path=require('node:path'),assert=require('node:assert/strict');
const {readZ,writeZ,open}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port.profile.cjs'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [input,out]=process.argv.slice(2);
const results=readZ(input).results.filter(r=>r.stop!=='terminal').map(r=>{
 const m=open(r.root),seatId='player-white',analysisPort=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
 try{
  r.actions.forEach(x=>m.apply(x.action));const root=m.save();
  const q=createSearchAgent({analysisPort,seatId}).decide({seatId,legalActions:m.menu()}).search;
  assert.equal(q.diagnostics.nativeExecutions,r.stop.n);
  assert.deepEqual(m.save(),root);
  return {card:r.card,root,q};
 }finally{m.dispose();}
});
writeZ(out,results);
