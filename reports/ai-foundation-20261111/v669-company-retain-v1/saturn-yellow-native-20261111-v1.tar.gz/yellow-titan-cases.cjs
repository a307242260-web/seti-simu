'use strict';
const path=require('node:path');
const {readZ,writeZ,open,runCases}=require('./controlled-r3');
const [out]=process.argv.slice(2);
const source=readZ(path.join(__dirname,'early-electric-route-20261111-v1.json.gz')).rows
 .find(x=>x.label==='dlc_17.png / ccw / saturn / defer tech');
const root=source.checkpoints['cargo-menu'].state,m=open(root);
const menu=m.menu(),baseline=m.automatic();m.dispose();
const cases=[['全自主',()=>{}],...menu.filter(a=>a.family==='choose_target'&&a.actionId!==baseline.a.actionId)
 .map(a=>[a.summary,h=>h.take(h.m.apply(a))])];
const report=runCases(root,cases);
writeZ(out,{root,baseline:{action:baseline.a,roots:baseline.roots,value:baseline.value,n:baseline.n},...report});
