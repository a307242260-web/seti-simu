Run from V669 source (5d8c52287). Extract this archive and the single input `early-electric-route-20261111-v1.json.gz` from the V666 funded-fossil evidence archive into the same directory (`$proof`).

```sh
node "$proof/yellow-titan-cases.cjs" /tmp/v669-yellow.json.gz
node "$proof/yellow-titan-fourth.cjs" /tmp/v669-yellow.json.gz /tmp/v669-yellow-r4.json.gz
```
The ten R3 cases start from the same Saturn trace menu. Each forced alternative fixes only the yellow trace and releases the following real menu to the AI. R4 fixes a single pass retention card for each compared endpoint; all other inputs are autonomous. The gated R4 paths stop before submitting the indicated root action.
For a diagnostic input distribution, in a disposable checkout copy `analysis-port.js` to `analysis-port.profile.cjs` in its original folder, apply the included patch to the latter, and run
`node "$proof/profile.cjs" /tmp/v669-yellow-r4.json.gz /tmp/v669-yellow-profile.json.gz`.
