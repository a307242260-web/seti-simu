OLD 指向 Production cbd73e00c98455dac868bd43be3e1759130088a7 的独立快照。NEW 是同一快照，只叠加本提交的三个扫描报价源文件。A 是证据解包目录。旧存档文件不得改写。

    node "$A/verify-source.cjs" "$OLD" "$NEW" "$A/root-b_111.webp.gz" "$A/root-b_32.webp.gz"

此命令比较原生候选 token、原生扫描菜单与探测估值。到 OLD 根目录，在新进程中用以下命令重现含其余隔离策略的 R4 速度诊断。B32 使用同命令，更换根和输出名。候选只在进程内加载，不修改 Production；墙钟时间非确定值。

    OPT="$(cat "$A/mode")-turn-copy-card-screen-data-screen-scan-quote"
    SETI_SCAN_PRIOR="$A/prior.cjs" node "$A/cold-root.cjs" "$OPT" "$A/root-b_111.webp.gz" "$A/replay-b111.json.gz"

单位测试与 V 输入审计运行在 NEW；隔离快照缺少的旧测试存档只从 dev 对应受版本控制的对象取回，没有修改测试、Production 源快照或历史记录。
