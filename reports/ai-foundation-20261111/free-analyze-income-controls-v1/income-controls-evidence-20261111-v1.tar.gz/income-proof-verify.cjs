'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const [roots,proof]=process.argv.slice(2),read=n=>JSON.parse(z.gunzipSync(fs.readFileSync(n)));
const a=read(roots),b=read(proof);
const {createEnvironment}=require(path.resolve('tools/research-free-analyze-random20'));
const base=require(path.resolve('reports/iteration/free-analyze-random20-pass-opportunity-20261111/summary-39f19bec-20261111.json'));
assert.equal(b.rows.length,a.cases.length*2);
for(const root of a.cases){
 const expected=root.expect||(()=>{
  const prior=base.rows.find(r=>r.board===root.board),p='reports/research/'+prior.f;
  const record=JSON.parse(fs.readFileSync(p));
  const traces=fs.readFileSync(p+'.decisions.jsonl','utf8').trim().split('\n').map(JSON.parse);
  const start=root.beforeInput-1-(record.steps-traces.length);
  assert.equal(traces[start].context.requestId,root.req);
  return {score:prior.score,suffix:traces.slice(start).map(q=>q.actionId)};
 })();
 for(const row of b.rows.filter(r=>r.board===root.board&&r.round===root.round)){
  const env=createEnvironment({},{id:'free-analyze-random20-guarded-v1'});
  try{
   assert.equal(row.failure,undefined);assert(row.peak[0]<=256&&row.peak[1]<=600);
   env.loadCheckpoint(root.checkpoint);
   for(const r of row.moves){
    const m=env.legalActions().find(q=>q.actionId===r.actionId);assert(m,r.actionId);
    assert.deepEqual(m.target,r.target);assert(env.step(m).ok,r.actionId);
   }
   assert(env.isTerminal());
   const end=env.createCheckpoint().coreState;
   assert.deepEqual(end.compositionEnvelope,row.end.coreState.compositionEnvelope);
   assert.equal(JSON.parse(end.committedState).match.finalScores.find(x=>x.playerId==='player-white').totalScore,row.score);
   if(row.label==='baseline'){
    assert.equal(row.score,expected.score);
    assert.deepEqual(row.moves.map(m=>m.actionId),expected.suffix);
   }
   console.log('verified',row.board,row.round,row.label,row.score,row.moves.length,row.peak.map(Math.ceil));
  }finally{env.dispose();}
 }
}
