'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),z=require('node:zlib');
const suite=require(path.resolve('reports/iteration/free-analyze-random20-strict-20261111/summary-532563ef-20261111.json'));
const scenario=require(path.resolve('tools/research-free-analyze-random20'));
const read=p=>JSON.parse(fs.readFileSync(p)),arr=p=>fs.readFileSync(p,'utf8').trim().split('\n').map(JSON.parse);
const seat='player-white',cases=[];
for(const b of suite.rows){
 const file='reports/research/'+b.f,record=read(file),rows=arr(file+'.decisions.jsonl');
 const indexes=new Map();
 rows.forEach((t,i)=>{
  const c=t.context,o=c.observation;if(c.seatId!==seat||!t.search||o.publicState.roundNumber>2)return;
  const action=c.legalActions.find(a=>a.actionId===t.actionId);
  if(!action?.target?.choiceId?.startsWith('income:'))return;
  const hand=new Map(o.selfState.hand.map(card=>[card.id,card]));
  const cash=c.legalActions.filter(a=>a.target?.choiceId?.startsWith('income:')&&hand.get(a.target.cardInstanceId)?.incomeCode===0);
  if(cash.length&&hand.get(action.target.cardInstanceId)?.incomeCode!==0)indexes.set(i,{baseline:action,cash,round:o.publicState.roundNumber,req:c.requestId});
 });
 if(!indexes.size)continue;
 const config=read(record.rounds[0].checkpointPath).config;
 const env=scenario.createEnvironment({},record.scenario);
 try{
  const opened=scenario.initialize(env,config,record.scenario);
  assert.equal(opened.length,record.steps-rows.length);
  for(let i=0;i<=Math.max(...indexes.keys());i++){
   const t=rows[i],menu=env.legalActions();
   const choice=menu.find(a=>a.actionId===t.actionId);assert(choice,t.context.requestId);
   if(indexes.has(i)){
    const k=indexes.get(i),checkpoint=env.createCheckpoint();
    assert(k.cash.every(x=>menu.some(a=>a.actionId===x.actionId)));
    cases.push({board:b.board,record:b.f,beforeInput:opened.length+i+1,...k,checkpoint});
   }
   const result=env.step(choice);assert(result.ok,t.context.requestId);
  }
 }finally{env.dispose();}
}
assert.equal(cases.length,4);
fs.writeFileSync(process.argv[2],z.gzipSync(JSON.stringify({source:suite.head,cases})),{flag:'wx'});
console.log(cases.map(({board,round,baseline,cash})=>[board,round,baseline.summary,cash.map(a=>a.summary)]));
