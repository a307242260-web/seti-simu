'use strict';
const assert=require('node:assert/strict');
const {open,readZ,writeZ}=require('./controlled-r3');
const [inputPath,out]=process.argv.slice(2),input=readZ(inputPath),rows=[];
for(const r of input.results.filter(r=>typeof r.stop==='object')){
 const m=open(r.end);
 try{
  const q=m.automatic();
  assert.deepEqual(m.save(),r.end);
  const row={name:r.name,card:r.card,old:r.stop,n:q.n,ms:q.ms,complete:q.complete,choice:q.a?.summary,value:q.value,roots:q.roots,root:r.end};
  rows.push(row);
  console.log(JSON.stringify({name:row.name,card:row.card,old:r.stop.n,n:q.n,ms:q.ms,complete:q.complete,choice:row.choice,value:row.value}));
 }finally{m.dispose();}
}
assert.equal(rows.length,6);
writeZ(out,{source:'39f19bec97bef4d5623c3cf57afb578a1d28d65c',rows});
