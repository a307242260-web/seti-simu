'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),z=require('node:zlib');
const {createEnvironment}=require(path.resolve('tools/research-free-analyze-random20'));
const {open,short}=require('./controlled-r3');
const [input,out]=process.argv.slice(2),archive=JSON.parse(z.gunzipSync(fs.readFileSync(input))),rows=[];
const seat='player-white';
for(const source of archive.cases)for(const label of ['baseline','cash']){
 const root=source.checkpoint;
 const env=createEnvironment({},{id:'free-analyze-random20-guarded-v1'}),moves=[],roundEnds=[],diag=[];
 const before=performance.now();let failure;
 try{
  env.loadCheckpoint(root);
  assert.deepEqual(env.createCheckpoint().coreState.compositionEnvelope,root.coreState.compositionEnvelope);
  for(let i=0;i<240&&!env.isTerminal();i++){
   const menu=env.legalActions(),actor=menu[0]?.actorId;assert(actor);
   const at=actor===seat&&menu.some(a=>a.family==='pass')?env.createCheckpoint():null;
   let result,action;
   if(!i){
    const id=(label==='cash'?source.cash[0]:source.baseline).actionId;
    action=menu.find(a=>a.actionId===id);assert(action);
    result=env.step(action);assert(result.ok,result.error);
   }else{
    try{result=env.runAgentDecision();}catch(err){
     const q=err.cause?.search||err.search;
     failure={message:err.message,n:q?.diagnostics?.nativeExecutions,ms:q?.rootAndSearchMilliseconds,choice:q?.actionId};
     if(at)assert.deepEqual(env.createCheckpoint().coreState.compositionEnvelope,at.coreState.compositionEnvelope);
     break;
    }
    action=menu.find(a=>a.actionId===result.agentTrace?.actionId);
    assert(action,JSON.stringify({keys:Object.keys(result),trace:result.agentTrace?.actionId,step:result.action?.actionId}));
   }
   const q=result.searches?.[0];if(q)diag.push({n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,value:q.value});
   moves.push(action);
   if(actor===seat&&action.family==='pass'&&at){
    const m=open(at.coreState.compositionEnvelope);
    try{roundEnds.push({round:m.facts().round,summary:short(m),checkpoint:at.coreState.compositionEnvelope});}finally{m.dispose();}
   }
  }
  const end=env.createCheckpoint(),state=JSON.parse(end.coreState.committedState),score=state.match.finalScores?.find(x=>x.playerId===seat)?.totalScore;
  const row={board:source.board,round:source.round,label,moves,roundEnds,diag,end,score,failure,wallMs:performance.now()-before,
   peak:[Math.max(0,...diag.map(d=>d.n)),Math.max(0,...diag.map(d=>d.ms))]};
  rows.push(row);
  console.log(JSON.stringify({board:source.board,round:source.round,label,score,failure,steps:moves.length,peak:row.peak,
   roundEnds:roundEnds.map(r=>[r.round,r.summary.wallet,r.summary.income,r.summary.established,r.summary.tech,r.summary.hand,r.summary.probes])}));
 }finally{env.dispose();}
}
fs.writeFileSync(out,z.gzipSync(JSON.stringify({source:archive.source,rows})),{flag:'wx'});
