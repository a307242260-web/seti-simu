'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),z=require('node:zlib');
const [initial,proof,out]=process.argv.slice(2),read=p=>JSON.parse(z.gunzipSync(fs.readFileSync(p)));
const {createEnvironment}=require(path.resolve('tools/research-free-analyze-random20'));
const origin=read(initial).cases.find(r=>r.board===19);
const rows=read(proof).rows.filter(r=>r.board===19),cases=[];
for(const row of rows){
 const env=createEnvironment({},{id:'free-analyze-random20-guarded-v1'});
 try{
  const hadCash=row.label==='cash',index=row.moves.findIndex(a=>hadCash?a.summary==='收入 dlc_25.png':a.family==='play_card'&&a.summary==='b_30.webp');
  assert(index>0);
  env.loadCheckpoint(origin.checkpoint);
  for(const move of row.moves.slice(0,index)){
   const a=env.legalActions().find(q=>q.actionId===move.actionId);assert(a);assert(env.step(a).ok);
  }
  const menu=env.legalActions(),baseline=menu.find(a=>a.actionId===row.moves[index].actionId);
  const alternative=menu.find(a=>hadCash?a.summary==='收入 dlc_38.png':a.family==='pass');
  assert(baseline&&alternative);
  cases.push({board:19,round:hadCash?2:1,baseline,cash:[alternative],expect:{label:row.label,score:row.score,suffix:row.moves.slice(index).map(a=>a.actionId)},checkpoint:env.createCheckpoint()});
 }finally{env.dispose();}
}
fs.writeFileSync(out,z.gzipSync(JSON.stringify({source:'39f19bec97bef4d5623c3cf57afb578a1d28d65c',cases})),{flag:'wx'});
