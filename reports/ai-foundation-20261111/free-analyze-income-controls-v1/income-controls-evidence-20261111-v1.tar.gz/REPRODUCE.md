Use Node 22 from the repository root at 80952f116 (the report commit adds evidence only). The production code SHA is 39f19bec97bef4d5623c3cf57afb578a1d28d65c. Use a fresh temporary output directory. Initial roots were reconstructed from the 532563ef cohort; the verifier proves the full default suffix for each root against the current 39f19bec cohort. The warm continuation uses the shared strict host after the single forced input. Fixtures and score outcomes contain complete seeded rule envelopes. Do not overlap measured workloads.

```sh
proof=/path/to/extracted/archive
out=$(mktemp -d)
node "$proof/income-roots.cjs" "$out/roots.json.gz"
node "$proof/income-host-contrast.cjs" "$out/roots.json.gz" "$out/branches.json.gz"
node "$proof/income-proof-verify.cjs" "$out/roots.json.gz" "$out/branches.json.gz"
node "$proof/income-b19-followup-roots.cjs" "$out/roots.json.gz" "$out/branches.json.gz" "$out/b19-roots.json.gz"
node "$proof/income-host-contrast.cjs" "$out/b19-roots.json.gz" "$out/b19-branches.json.gz"
node "$proof/income-proof-verify.cjs" "$out/b19-roots.json.gz" "$out/b19-branches.json.gz"
prior=reports/ai-foundation-20261111/v673-standard-retention-frontier-v1/standard-retention-frontier-evidence-20261111-v1.tar.gz
tar -xOf "$prior" ./standard-stops-fourth-20261111-v1.json.gz > "$out/standard-stops-fourth.json.gz"
node "$proof/retention-gate.cjs" "$out/standard-stops-fourth.json.gz" "$out/retention-gates.json.gz"
```

For the two Board 19 follow-ups the runner's `cash` label means “the forced alternative”: PASS at the first root and DLC38 electricity income at the second root. The two checks are independent. A timing over the strict gate invalidates an autonomous trajectory. The separate R4 gate probe measures one cold decision, verifies exact restoration, and never submits that decision.
