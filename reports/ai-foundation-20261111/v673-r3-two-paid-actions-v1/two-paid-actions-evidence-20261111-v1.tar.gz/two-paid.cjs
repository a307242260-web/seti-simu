'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [ledger,out]=process.argv.slice(2),d=readZ(ledger),get=k=>d.rows.find(x=>x.k===k),groups=[];
const b=(c,k)=>c.act(get(k).action.family,a=>a.target.choiceId===get(k).action.target.choiceId);
const pick=(c,id)=>c.act('choose_card',a=>a.summary===id&&a.target.source!=='blind');
const end=c=>{c.act('end_turn');const a=[];c.m.advanceOpponents(a);c.take(...a);};
const capture=(c,k)=>c.cut(k);
function cash(c,ids){
 c.act('quick_trade',a=>a.target.tradeId==='cards-for-credit');
 for(const id of ids)c.act('choose_payment',a=>a.summary===id);
 c.act('choose_payment',a=>a.summary.startsWith('确认弃牌'));
}
function data(c,slot=null){
 c.act('place_data');c.act('choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');
}
function prepare(c,mode){
 if(mode==='keep-DLC25'){
  end(c);c.take(c.m.corner('b_16.webp'),c.m.corner('amiba_9.webp'));
 }else{
  pick(c,'dlc_20.png');end(c);c.act('scan');b(c,211);
  c.act('choose_card',a=>a.target.nebulaId==='sector-3-a'&&a.summary.startsWith('dlc_24.png'));
  for(const k of [213,214,215])b(c,k);
  c.act('complete_task',a=>a.target.ruleId==='dlc9-three-sector-wins');end(c);
  c.act('research_tech');b(c,219);pick(c,'dlc_16.png');end(c);
  c.act('move',a=>a.target.deltaX===0&&a.target.deltaY===1&&a.target.rocketId===6);
  const id=c.m.player().hand.find(a=>a.cardId==='dlc_16.png').id;
  c.act('choose_payment',a=>a.target.cardIds?.[0]===id);
  c.take(c.m.corner('amiba_9.webp'));
 }
 c.act('research_tech');b(c,226);data(c);data(c);data(c,3);
 capture(c,'first-cash');end(c);
}
function both(c,mode,repeatCard,second=true){
 prepare(c,mode);
 c.take(c.m.play('amiba_5.webp'));pick(c,repeatCard);b(c,236);
 capture(c,'red-four');end(c);
 c.act('analyze');b(c,242);b(c,243);
 capture(c,'cash-gap');
 if(!second)return;
 const funding=mode==='keep-DLC25'?'dlc_25.png':'b_16.webp';
 cash(c,[funding,'amiba_2.webp']);end(c);
 c.take(c.m.play('dlc_20.png'));pick(c,repeatCard);
 capture(c,'repeat-four-data');
 assert.equal(c.m.facts().wallet.availableData,4);assert.equal(c.m.player().hand.length,0);
}
function enumerateMoves(c){
 data(c);data(c,1);
 capture(c,'blue-electricity');
 c.act('quick_trade',a=>a.target.tradeId==='energy-for-move');
 return c.m.menu().filter(a=>a.target.deltaX!=null);
}
for(const mode of ['keep-DLC25','keep-B16']){
 const root=get(mode==='keep-DLC25'?221:208).root,cases=[],matrix=[];
 for(const id of ['dlc_17.png','dlc_15.png']){
  const m=open(root),probe={m,act:m.act,take:(...a)=>a[0],cut:()=>{}};
  try{
   both(probe,mode,id);
   const start=m.save(),c=()=>({wallet:short(m).wallet,market:short(m).market,actions:m.menu().map(a=>[a.family,a.target.tradeId??null])});
   const paid=c();for(let i=0;i<4;i++)data(probe);
   const computer=c();assert(!m.menu().some(a=>a.target.tradeId==='publicity-for-card'));
   m.restore(start);
   const moves=enumerateMoves(probe),pending=m.save(),moveRows=[];
   for(const a of moves){
    m.restore(pending);m.apply(a);
    const x={action:a,summary:short(m),buy:m.menu().some(a=>a.target.tradeId==='publicity-for-card')};
    moveRows.push(x);
    if(x.buy){
     for(const income of m.state().cards.publicCards.filter(x=>x&&['dlc_14.png','dlc_25.png'].includes(x.cardId)).map(c=>c.cardId)){
      cases.push([id+' / spend blue data to move and buy '+income+' / '+a.summary,c=>{
       both(c,mode,id);const legal=enumerateMoves(c);c.take(c.m.apply(legal.find(x=>x.actionId===a.actionId)));
       c.act('quick_trade',a=>a.target.tradeId==='publicity-for-card');c.take(c.m.pick(income));
       capture(c,'bought-electricity-one-data-short');
      }]);
     }
    }
   }
   matrix.push({repeat:id,paid,computer,moveRows});
   cases.push([id+' / both paid, rest autonomous',c=>both(c,mode,id)]);
   cases.push([id+' / keep income card, stop before second paid action',c=>both(c,mode,id,false)]);
  }catch(err){matrix.push({repeat:id,error:String(err),facts:short(m),menu:m.menu()});}
  finally{m.dispose();}
 }
 const r=runCases(root,cases);groups.push({mode,root,matrix,...r});
}
writeZ(out,{groups});
