'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ}=require('./controlled-r3'),
 {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port')),{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const d=readZ(process.argv[2]),rows=[];
for(const g of d.groups){
 const proof=g.rows.find(r=>r.label==='dlc_17.png / both paid, rest autonomous');
 for(const [name,root] of ['cash-gap','repeat-four-data'].map(k=>[k,proof.checkpoints[k].state])){
  const m=open(root),seatId='player-white',port=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
  try{
   const menu=m.menu(),q=createSearchAgent({seatId,analysisPort:port}).decide({seatId,legalActions:menu}).search;
   assert.deepEqual(m.save(),root);
   assert(q.complete&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600);
   const picks=menu.filter(a=>a.target.tradeId==='cards-for-credit'||a.family==='place_data'||a.actionId===q.actionId)
    .map(a=>[a.summary,q.roots.find(x=>x.actionId===a.actionId)]);
   console.log(JSON.stringify({mode:g.mode,name,selected:menu.find(a=>a.actionId===q.actionId).summary,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,picks:picks.map(([a,b])=>[a,b?.value,b?.completion])}));
   rows.push({mode:g.mode,name,root,picks,q});
  }finally{port.close();m.dispose();}
 }
}
writeZ(process.argv[3],{rows});
