'use strict';
const fs=require('fs'),assert=require('assert/strict'),{open,writeZ}=require('./controlled-r3');
const name='reports/research/d3183131.cbd73e00.quick-400.json.round-end-';
const read=n=>JSON.parse(fs.readFileSync(name+n+'.checkpoint.json'));
const b=read(2),e=read(3),root=b.coreState.compositionEnvelope,m=open(root),rows=[];
try{
 for(const [k,r] of e.replaySteps.entries()){
  if(k<b.replayCursor.stepIndex)continue;
  if(k>=195){
   const p=m.player(),f=m.facts(),state=m.state(),ins=m.c.inspect().session,menu=m.menu();
   const row={k,action:r.action,root:m.save(),public:m.owner('player-white'),legal:menu};
   rows.push(row);
   if(k>=211)console.log(k,r.action.family,r.action.summary,[p.resources.credits,p.resources.energy,p.resources.publicity,p.resources.availableData],p.hand.map(c=>c.cardId).join(','),f.market.map(x=>x?.[1]).join(','),'comp='+f.computer.length,'blue='+f.blue,'phase='+ins?.decision?.kind);
  }
  m.apply(r.action);
 }
 assert.deepEqual(m.save(),e.coreState.compositionEnvelope);
 writeZ(process.argv[2],{rows,ending:m.save()});
}finally{m.dispose();}
