'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,runCases}=require('./controlled-r3');
const [input,out]=process.argv.slice(2),d=readZ(input),results=[];
function data(c,slot=null){c.act('place_data');c.act('choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');}
for(const g of d.groups)for(const r of g.rows.filter(r=>r.label.includes('both paid'))){
 const root=r.checkpoints['repeat-four-data'].state;
 const m=open(root),moves=[];
 try{
  for(const a of g.matrix.find(x=>r.label.startsWith(x.repeat)).moveRows){
   m.restore(root);
   const prep=(c)=>{
    data(c);data(c,1);data(c);
    c.act('quick_trade',x=>x.target.tradeId==='energy-for-move');
    c.act('choose_target',x=>x.target.deltaX===a.action.target.deltaX&&x.target.deltaY===a.action.target.deltaY);
    c.cut('after-move-and-two-placements');
   };
   const probe={m,act:m.act,take:(...v)=>v[0],cut:()=>{}};
   prep(probe);
   const buy=m.menu().some(x=>x.target.tradeId==='publicity-for-card');
   const store={direction:a.action.summary,pub:m.facts().wallet.publicity,n:m.facts().wallet.availableData+m.facts().computer.length,buy,state:m.save()};
   if(buy){
    const targets=m.state().cards.publicCards.filter(x=>x&&['dlc_14.png','dlc_25.png'].includes(x.cardId)).map(x=>x.cardId);
    const cases=targets.map(id=>[id,c=>{
     prep(c);c.act('quick_trade',x=>x.target.tradeId==='publicity-for-card');c.take(c.m.pick(id));
     c.cut('bought-electric');
     assert.equal(c.m.facts().wallet.availableData+c.m.facts().computer.length,3);
    }]);
    store.purchases=runCases(root,cases);
   }
   console.log(JSON.stringify([g.mode,r.label,store.direction,store.pub,store.n,store.buy]));
   moves.push(store);
  }
 }finally{m.dispose();}
 results.push({mode:g.mode,label:r.label,root,moves});
}
writeZ(out,{results});
