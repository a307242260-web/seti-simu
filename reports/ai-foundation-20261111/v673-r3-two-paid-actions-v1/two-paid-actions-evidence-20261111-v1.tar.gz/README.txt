Production JS: 433765e936e26b6a25c8b599f580792471e3445b. Run from repo root with Node 22. Let E be the extracted directory and choose fresh output paths.
node "$E/ledger.cjs" /tmp/seti-two-paid-ledger.json.gz
node "$E/two-paid.cjs" /tmp/seti-two-paid-ledger.json.gz /tmp/seti-two-paid-r3.json.gz
node "$E/buy-after-move.cjs" /tmp/seti-two-paid-r3.json.gz /tmp/seti-two-paid-buy.json.gz
node "$E/gap-quote.cjs" /tmp/seti-two-paid-r3.json.gz /tmp/seti-two-paid-quote.json.gz
node "$E/fourth.cjs" /tmp/seti-two-paid-r3.json.gz /tmp/seti-two-paid-buy.json.gz /tmp/seti-two-paid-r4.json.gz
node "$E/verify.cjs" "$E/two-paid-r3-20261111-v1.json.gz" "$E/two-paid-buy-after-move-20261111-v1.json.gz" "$E/two-paid-r4-20261111-v1.json.gz" /tmp/seti-two-paid-replay.json.gz
