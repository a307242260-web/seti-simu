'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ}=require('./controlled-r3');
const [a,b,c,out]=process.argv.slice(2),d=readZ(a),bought=readZ(b),r4=readZ(c),stats={r3:0,purchases:0,r4:0,inputs:0,peak:[0,0]};
function verify(root,rows,field){
 const m=open(root);
 try{
  for(const row of rows){
   m.restore(root);
   for(const x of row.prefix||[]){assert.deepEqual(m.apply(x),x);stats.inputs++;}
   for(const x of row.actions){
    assert.deepEqual(m.apply(x.action),x.action);stats.inputs++;
    if(x.n!=null){assert(x.n<=256&&x.ms<=600);stats.peak[0]=Math.max(stats.peak[0],x.n);stats.peak[1]=Math.max(stats.peak[1],x.ms);}
   }
   assert.deepEqual(m.save(),row.end);
   if(field==='r4')assert.deepEqual(m.state().match.finalScores.find(x=>x.playerId==='player-white'),row.terminal);
   stats[field]++;
  }
 }finally{m.dispose();}
}
for(const g of d.groups)verify(g.root,g.rows,'r3');
for(const g of bought.results)for(const m of g.moves)if(m.purchases)verify(g.root,m.purchases.rows,'purchases');
for(const r of r4.results)verify(r.root,[r],'r4');
console.log(JSON.stringify(stats));writeZ(out,stats);
