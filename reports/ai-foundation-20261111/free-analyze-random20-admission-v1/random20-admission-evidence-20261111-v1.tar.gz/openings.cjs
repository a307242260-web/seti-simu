'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{open,writeZ}=require('./controlled-r3');
const scenario=require(path.resolve('tools/research-free-analyze-random20'));
const list=JSON.parse(fs.readFileSync('reports/fixed-boards/free-analyze-random20-20261104-v1.json')).boards,rows=[];
for(const b of list){
 const cfg={seed:b.seed,activePlayerCount:4,agentType:'search',compactReplay:true};
 const env=scenario.createEnvironment(),meta=scenario.describe(cfg,{full:true});
 try{
  const prefix=scenario.initialize(env,cfg,meta);
  while(env.legalActions()[0]?.actorId!=='player-white')env.runAgentDecision();
  const root=env.createCheckpoint().coreState.compositionEnvelope,m=open(root);
  try{
   const q=m.automatic();
   const pass=q.complete&&q.n<=256&&q.ms<=600;
   assert.deepEqual(m.save(),root);
   rows.push({board:b.number,seed:b.seed,root,setupInputs:prefix.length,action:q.a?.summary,n:q.n,ms:q.ms,complete:q.complete,pass});
   console.log(JSON.stringify({...rows.at(-1),root:undefined}));
  }catch(e){assert.deepEqual(m.save(),root);rows.push({board:b.number,seed:b.seed,root,error:e.message,pass:false});console.log(JSON.stringify({board:b.number,error:e.message}));}
  finally{m.dispose();}
 }finally{env.dispose();}
}
writeZ(process.argv[2],{rows});
