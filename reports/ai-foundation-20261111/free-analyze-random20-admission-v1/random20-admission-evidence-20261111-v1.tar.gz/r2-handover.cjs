'use strict';
const assert=require('node:assert/strict');
function sub(s,a,b){assert.equal(s.split(a).length,2,a);return s.replace(a,b);}
exports.local=s=>{
 const n=' function previewFinalEndPrelude({state,seatId,action,knownCards,allowSameSeat=false,allowUnrevealedR3=false}){';
 const start=s.indexOf(n),stop=s.indexOf(' function previewQuietChongEndPrelude',start);assert(start>=0&&stop>start);
 const region=s.slice(start,stop).replace('allowUnrevealedR3=false','allowUnrevealedQuiet=false').replace('allowUnrevealedR3&&turn.roundNumber===3','allowUnrevealedQuiet&&[2,3].includes(turn.roundNumber)').replace('turn.roundNumber===3&&preview.settlements.length','turn.roundNumber<4&&preview.settlements.length');
 return s.slice(0,start)+region+s.slice(stop);
};
exports.port=(s,witness)=>{
 const a='allowSameSeat:true,allowUnrevealedR3:isUnrevealedRoundThree(readIdentityState(stored.envelope))';
 s=sub(s,a,`allowSameSeat:true,allowUnrevealedQuiet:isUnrevealedRoundThree(readIdentityState(stored.envelope))
            ||quietSecondRoundHandover(readIdentityState(stored.envelope))`);
 const before='    function quietFirstTurnData(state) {';
 s=sub(s,before,`    function quietSecondRoundHandover(state) {
      const t=state.turn;
      return t.roundNumber===2&&t.activePlayerIds.every(id=>id===seatId||t.passedPlayerIds.includes(id))
        &&Object.values(state.aliens.aliens).every(slot=>!slot.revealed&&!alienState.isAlienReadyToReveal(slot));
    }

`+before);
 if(witness)s=sub(s,'        const child=finishProvedTurnBoundary(stored,requested,endPrelude.finished);',`        const child=finishProvedTurnBoundary(stored,requested,endPrelude.finished);
        if(endPrelude.finished.turn.roundNumber===2)globalThis.endWitnesses.push({source:stored.envelope,
          target:nodes.get(child).envelope,action:requested});`);
 return s;
};
