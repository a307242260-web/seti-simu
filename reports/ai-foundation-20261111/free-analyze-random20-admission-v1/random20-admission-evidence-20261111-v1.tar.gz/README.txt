Opening baseline Production JS 433765e936e26b6a25c8b599f580792471e3445b.
Run from repo root on Node 22. E is the extracted evidence directory; use fresh output paths.
node "$E/openings.cjs" /tmp/seti-openings.json.gz
node "$E/profile-open.cjs" "$E/openings-20261111-v1.json.gz" /tmp/seti-opening-profiles.json.gz
node "$E/admit-open.cjs" "$E/opening-profiles-20261111-v1.json.gz" /tmp/seti-opening-witness.json.gz
R2 repro uses a4b3f7dc (includes opening data reuse and strict harness):
node "$E/admit-r2.cjs" "$E/canary02-r2-profile-20261111-v1.json.gz" /tmp/seti-r2-witness.json.gz
node "$E/resume-canary.cjs" "$E/b629df5d.a4b3f7dc.full.json.failed-checkpoint.json" /tmp/seti-canary-resume.json.gz
The suffix is diagnostic; only a naturally finished game on one registered version counts toward the 20-game batch.
