'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{open,writeZ}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port')),{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [out,...files]=process.argv.slice(2),rows=[];
for(const file of files){
 const root=JSON.parse(fs.readFileSync(file)).coreState.compositionEnvelope,m=open(root),seatId='player-white',p=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
 try{
  const legal=m.menu(),before=m.facts(),r=createSearchAgent({seatId,analysisPort:p}).decide({seatId,legalActions:legal});
  const q=r.search,n=q.diagnostics.nativeExecutions,ms=q.rootAndSearchMilliseconds;
  assert.deepEqual(m.save(),root);
  const row={id:path.basename(file),root,round:before.round,turn:before.turn,n,ms,complete:q.complete&&!q.unresolved.length,pass:n<=256&&ms<=600&&q.complete&&!q.unresolved.length,action:legal.find(a=>a.actionId===q.actionId),q};
  rows.push(row);console.log(JSON.stringify({...row,root:undefined,q:undefined,action:row.action?.summary}));
 }catch(e){assert.deepEqual(m.save(),root);rows.push({id:path.basename(file),root,error:{code:e.code,message:e.message}});console.log(JSON.stringify({id:path.basename(file),code:e.code,error:e.message}));}
 finally{p.close();m.dispose();}
}
writeZ(out,{rows});
