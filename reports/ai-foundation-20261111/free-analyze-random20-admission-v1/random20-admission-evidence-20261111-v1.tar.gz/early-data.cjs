'use strict';
const assert=require('node:assert/strict');
module.exports=(code,mode)=>{
 const sub=(a,b)=>{assert.equal(code.split(a).length,2,a);code=code.replace(a,b);};
 const anchor='    function quietDataMenuSource(stored, action) {';
 sub(anchor,`    // The first white turn can use the same inert placement proof. The
    // original effect, owner, payload and trigger guards still apply.
    function quietFirstTurnData(state) {
      return state.turn.roundNumber===1&&state.turn.turnNumber===1
        &&Object.values(state.aliens.aliens).every(slot=>!slot.revealed&&!alienState.isAlienReadyToReveal(slot));
    }

`+anchor);
 sub('if ((t.roundNumber !== 4 && !isUnrevealedRoundThree(state) && !quietR3RevealedData(state) && !quietR3AmibaPostMain(state,owner)\n','if ((t.roundNumber !== 4 && !quietFirstTurnData(state) && !isUnrevealedRoundThree(state) && !quietR3RevealedData(state) && !quietR3AmibaPostMain(state,owner)\n');
 sub('!(computer&&(isUnrevealedRoundThree(state)||quietR3RevealedData(state)))','!(computer&&(quietFirstTurnData(state)||isUnrevealedRoundThree(state)||quietR3RevealedData(state)))');
 sub('if ((t.roundNumber !== 4 && !isUnrevealedRoundThree(state) && !quietR3RevealedData(state) && !quietR3AmibaPostMain(state,owner)) ||','if ((t.roundNumber !== 4 && !(computer&&quietFirstTurnData(state)) && !isUnrevealedRoundThree(state) && !quietR3RevealedData(state) && !quietR3AmibaPostMain(state,owner)) ||');
 if(mode!=='witness')return code;
 const helper=`
        if(readIdentityState(stored.envelope).turn.roundNumber===1)
          globalThis.dataProof.push({source:stored.envelope,target:nodes.get(child).envelope,action:requested,kind:KIND,raw:RAW});`;
 const menu='      const dataReward=previewDataRewardMenu(stored,requested);';
 const find=(start,end,kind,raw)=>{
  const i=code.indexOf(start),j=code.indexOf(end,i),k=code.lastIndexOf('        return rememberPrefix',j);
  assert(i>=0&&k>i&&k<j);code=code.slice(0,k)+helper.replace('KIND',JSON.stringify(kind)).replace('RAW',raw)+'\n'+code.slice(k);
 };
 find('      if (menuPreview) {',menu,'data-menu','choices');
 find('      if(rewardMenu){','      const currencyIncome=','income-menu','choices');
 find('      if (fixedData) {','      if(previewOnly)return null;','computer-placement','null');
 return code;
};
