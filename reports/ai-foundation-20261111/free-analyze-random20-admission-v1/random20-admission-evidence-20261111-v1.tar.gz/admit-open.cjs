'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const [input,out]=process.argv.slice(2),f=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(f,module);
mod.filename=f;mod.paths=Module._nodeModulePaths(path.dirname(f));mod._compile(require('./early-data.cjs')(fs.readFileSync(f,'utf8'),'witness'),f);
mod.loaded=true;require.cache[f]=mod;
const {open,readZ,writeZ}=require('./controlled-r3'),{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent')),rows=[];
const fields=['actionId','value','realization','preparationDebt','complete','roots','lines','unresolved','selectionPlan','candidates','sharedPrefixGraph'];
function normal(e){
 const c=structuredClone(e);c.committedState=JSON.parse(c.committedState);
 const s=c.session?.session;
 if(s){s.undoFrames=[];c.session=JSON.parse(JSON.stringify(c.session).replaceAll(s.sessionId,'@session'));}
 return c;
}
for(const r of readZ(input).rows){
 const m=open(r.root),seatId='player-white',p=mod.exports.createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});globalThis.dataProof=[];
 try{
  const q=createSearchAgent({seatId,analysisPort:p}).decide({seatId,legalActions:m.menu()}).search;
  const archival=JSON.parse(JSON.stringify(q)),n=q.diagnostics.nativeExecutions;
  for(const k of fields)assert.deepEqual(archival[k],r.q[k],k);
  assert.deepEqual(m.save(),r.root);
  assert.equal(globalThis.dataProof.length,r.n-n);
  const groups={};
  for(const x of globalThis.dataProof){
   m.restore(x.source);m.apply(x.action);
   assert.deepEqual(normal(m.save()),normal(x.target),x.kind);
   if(x.raw)assert.deepEqual(m.menu(),x.raw);
   groups[x.kind]=(groups[x.kind]||0)+1;
  }
  console.log(JSON.stringify({board:r.board,old:r.n,n,ms:q.rootAndSearchMilliseconds,groups}));
  rows.push({board:r.board,root:r.root,n,q,groups,witnesses:globalThis.dataProof});
 }finally{p.close();m.dispose();}
}
writeZ(out,{rows});
