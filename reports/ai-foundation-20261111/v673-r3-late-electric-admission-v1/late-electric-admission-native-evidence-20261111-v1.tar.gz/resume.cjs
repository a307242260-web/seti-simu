'use strict';
const assert=require('node:assert/strict');
const {open,readZ,short,writeZ}=require('./controlled-r3');
const [d,out]=process.argv.slice(2),input=readZ(d+'/check-20261111-v1.json.gz'),r=input.rows[0],x={root:input.root,ids:r.edge.steps};
const m=open(x.root),actions=[];
try{
 assert(r.checkpoint&&r.q.complete&&r.q.diagnostics.nativeExecutions<=256);
 let cp=r.checkpoint;
 actions.push({action:m.apply(m.menu().find(a=>a.actionId===r.q.actionId))});
 let stop;
 for(const id of x.ids.slice(1)){
  const saved=m.save();m.restore(saved);
  const q=m.automatic(cp);
  assert.deepEqual(m.save(),saved);
  if(!q.complete||q.n>256||q.ms>600||q.a.actionId!==id){
   stop={kind:'divergent-or-gate',expected:id,actual:q.a?.actionId,n:q.n,ms:q.ms};break;
  }
  cp=q.checkpoint;actions.push({action:m.apply(q.a),n:q.n,ms:q.ms});
 }
 const end=m.save(),summary=short(m);if(!stop)stop={kind:'complete'};
 m.restore(x.root);actions.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),end);
 console.log(JSON.stringify({stop,summary,count:actions.length,peak:Math.max(...actions.map(a=>a.n||0))}));
 writeZ(out,{root:x.root,stop,end,summary,actions});
}finally{m.dispose();}
