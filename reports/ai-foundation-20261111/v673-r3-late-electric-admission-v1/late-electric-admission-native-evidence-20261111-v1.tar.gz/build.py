from pathlib import Path
import sys
p=Path('randomizer/game/ai/analysis-port.js')
s=p.read_text()
def sub(a,b):
 global s
 assert s.count(a)==1, (a,s.count(a))
 s=s.replace(a,b)
start='    function resourceStep(node,goal,operation={}) {'
sub(start,'''    // A post-analysis electricity target can be one public data card short.
    // The full plan uses one named supplier and one recipient, no draw/refill
    // or alternative direction, and competes with the original data tail.
    function lateKnownElectricSwap(node,stored,session) {
      if(node!==openedRoot||stored.resourceControl||stored.intent||stored.informationBarrier)return null;
      const head=session?.queue?.[0],source=session?.journal?.actions?.[0]?.action;
      const pending=node.status==="decision"&&session?.queue.length===1
        &&head?.type==="residual_company_decision"&&head.ownerId===seatId
        &&source?.family==="industry"&&source.target.abilityId==="deepspace_swap_cards"
        &&["swap_hand","swap_public"].includes(head.payload?.step);
      if(!pending&&node.status!=="stable")return null;
      if(!pending&&!node.legalActions.some(a=>a.family==="industry"&&a.target.abilityId==="deepspace_swap_cards"))return null;
      const known=knownCards(stored.envelope),state=pending?planningState(session.baseState,null,known):readPlanningState(stored);
      const t=state.turn,p=state.players.players.find(x=>x.id===seatId);
      if(t.roundNumber!==3||t.currentPlayerId!==seatId||!p.mainActionCompleted||p.passCompletionPending
        ||t.passedPlayerIds.includes(seatId)||t.activePlayerIds.some(id=>id!==seatId&&!t.passedPlayerIds.includes(id))
        ||t.cardTurnEventBonuses?.length||p.industryRoundMarkRound===t.roundNumber
        ||p.industryBorrowedTechTileId||p.resources.energy!==0||p.resources.credits!==0
        ||p.resources.availableData!==1||p.dataState.poolTokens.length!==1||data.listComputerPlacedTokens(p).length
        ||p.hand.length!==4||[...p.hand,...p.reservedCards].some(c=>!known.has(c.id))
        ||!hasPostMainInertReservations(state,hasOwnVisitSource(state),true,true))return null;
      const corners=p.hand.filter(c=>{
        const x=cards.getDiscardActionRewardForCard(c);
        return x?.dataCount===1&&Object.keys(x.gain).every(k=>k==="score")
          &&(!Object.hasOwn(x.gain,"score")||x.gain.score===1);
      });
      const income=p.hand.filter(c=>{
        const x=cards.getIncomeGainForCard(c);
        return x?.energy===1&&Object.keys(x).length===1&&!(cards.getDiscardActionRewardForCard(c)?.dataCount>0);
      });
      if(corners.length!==2||income.length!==1)return null;
      const out=p.hand.filter(c=>!corners.includes(c)&&!income.includes(c)
        &&!(cards.getDiscardActionRewardForCard(c)?.dataCount>0));
      const offers=state.cards.publicCards.filter(c=>{
        const x=c&&cards.getDiscardActionRewardForCard(c);
        return c&&known.has(c.id)&&x?.dataCount===1&&!Object.keys(x.gain).length;
      });
      if(out.length!==1||offers.length!==1||pending&&head.payload.step==="swap_public"&&head.payload.handCardInstanceId!==out[0].id)return null;
      const gain=corners.reduce((sum,c)=>sum+(cards.getDiscardActionRewardForCard(c).gain.score||0),0)
        +[1,2,3,4].filter(i=>data.getComputerSlotBonus(i)?.score).length*2;
      // The column rewards before slot 4 are bounded by eight even when
      // every column scores. An unresolved score mark needs normal play.
      if(state.finalScoring.thresholds.some(n=>p.resources.score+gain+8>=n
        &&!Object.values(state.finalScoring.tiles).some(tile=>tile.marks.some(m=>m.playerId===seatId&&m.threshold===n))))return null;
      const goal={kind:"known-electric-data-swap",id:"income:known-data-swap:"+offers[0].id,required:{},
        out:out[0].id,offer:offers[0].id,income:income[0].id,corners:[...corners.map(c=>c.id),offers[0].id],energy:p.income.energy};
      const operation={lateElectricInput:pending?(head.payload.step==="swap_hand"?1:2):0};
      const step=lateKnownElectricSwapStep(node,readPlanningState(stored),goal,operation);
      return step.actionId?{id:goal.id,goal,operation,firstActionId:step.actionId,mode:"greedy",reason:"one-known-data-card-funds-electricity"}:null;
    }

    function lateKnownElectricSwapStep(node,state,goal,operation) {
      const i=operation.lateElectricInput??0,p=state.players.players.find(x=>x.id===seatId),find=f=>node.legalActions.find(f);
      const stable=node.status==="stable",slots=data.listComputerPlacedTokens(p).length;
      const miss=()=>({kind:"infeasible",reason:"known-electric-data-menu-changed"});
      let action;
      if(i===0&&stable)action=find(a=>a.family==="industry"&&a.target.abilityId==="deepspace_swap_cards");
      else if(i===1&&!stable)action=find(a=>a.family==="choose_card"&&a.target.choiceId==="hand:"+goal.out);
      else if(i===2&&!stable)action=find(a=>a.family==="choose_card"&&a.target.cardInstanceId===goal.offer&&a.target.choiceId?.startsWith("public:"));
      else if(i>=3&&i<6&&stable&&p.resources.availableData===i-2)action=find(a=>a.family==="card_corner"
        &&a.payload.kind==="resource"&&a.payload.multiplier===1&&a.target.cardInstanceId===goal.corners[i-3]);
      else if(i>=6&&i<14&&slots===((i-6)>>1)&&p.resources.availableData===4-slots)
        action=i%2===0&&stable?find(a=>a.family==="place_data"):i%2===1&&!stable?find(a=>a.family==="choose_target"&&a.target.target==="computer"):null;
      else if(i===14&&!stable&&slots===4)action=find(a=>a.family==="choose_card"&&a.target.choiceId==="income:"+goal.income);
      else if(i===15&&stable&&slots===4&&p.income.energy===goal.energy+1&&!p.hand.some(c=>c.id===goal.income))
        return {kind:"complete",reason:"known-electric-income-paid"};
      return action?{kind:"fixed",actionId:action.actionId,lateElectricInput:i+1,reason:"known-electric-data-swap"}:miss();
    }

'''+start)
sub('      if(goal.kind==="data-funded-cargo")return dataFundedCargoStep(node,state,goal,operation);',
'''      if(goal.kind==="known-electric-data-swap")return lateKnownElectricSwapStep(node,state,goal,operation);
      if(goal.kind==="data-funded-cargo")return dataFundedCargoStep(node,state,goal,operation);''')
sub('      const shipment=node===openedRoot&&!stored.resourceControl&&!stored.intent',
'''      const electricSwap=lateKnownElectricSwap(node,stored,pending);
      if(electricSwap&&node.status==="decision"){
        const fixed=freeze({policy:resourceDemand.VERSION,isEquivalence:false,
          plans:[electricSwap],retainedActionIds:[],excludedActionIds:node.legalActions.map(a=>a.actionId)});
        resourceSpecs.set(node,fixed);return fixed;
      }
      const shipment=node===openedRoot&&!stored.resourceControl&&!stored.intent''')
sub('        plans:compareFixedPurposes?plans:swapAction?', '        plans:electricSwap?[...plans,electricSwap]:compareFixedPurposes?plans:swapAction?')
sub('!["transport-data-prep","funded-earth-shipment","satellite-scan-setup","data-funded-cargo"].includes(plan.goal.kind)',
    '!["transport-data-prep","funded-earth-shipment","satellite-scan-setup","data-funded-cargo","known-electric-data-swap"].includes(plan.goal.kind)')
sub('...(chosen.cargoInput!==undefined?{cargoInput:chosen.cargoInput}:{}),',
    '...(chosen.cargoInput!==undefined?{cargoInput:chosen.cargoInput}:{}),...(chosen.lateElectricInput!==undefined?{lateElectricInput:chosen.lateElectricInput}:{}),')
# The old stable tail certificate can suppress evaluation of a newly reachable
# known supplier. The guard also handles genuinely cold starts in the swap.
sub('      if(node.status==="stable"&&row.actionId.startsWith("card_corner:")',
'''      if(node.status==="stable"&&row.actionId.startsWith("card_corner:")&&lateKnownElectricSwap(node,stored,null))
        return {hit:false,reason:"known-electric-data-swap-needs-comparison"};
      if(node.status==="stable"&&row.actionId.startsWith("card_corner:")''')
Path(sys.argv[1]).write_text(s)
