'use strict';
const assert=require('node:assert/strict');
const {open,readZ}=require('./controlled-r3');
const d=process.argv[2],r=n=>readZ(d+'/'+n+'-20261111-v1.json.gz');
const check=r('check'),x=r('resume'),prior=r('lines').rows.find(x=>x.label==='A5-first/4分/swap-B16');
assert.deepEqual(x.end,prior.checkpoints.E4.state);assert.equal(x.stop.kind,'complete');
let count=0;
for(const row of check.rows){
 assert(row.q.complete&&!row.q.unresolved.length&&row.q.diagnostics.nativeExecutions<=256&&row.q.rootAndSearchMilliseconds<=600);
 if(!row.edge)continue;
 const m=open(row.state);
 try{
  for(const id of row.edge.steps){const a=m.menu().find(x=>x.actionId===id);assert(a);m.apply(a);count++;}
  const facts=m.facts();assert.equal(facts.wallet.score,118);assert.equal(facts.income.energy,4);
  assert.equal(facts.computer.length,4);assert.equal(facts.hand.length,0);
 }finally{m.dispose();}
}
const m=open(x.root);
try{for(const y of x.actions){assert((y.n||0)<=256&&(y.ms||0)<=600);m.apply(y.action);count++;}assert.deepEqual(m.save(),x.end);}finally{m.dispose();}
assert.equal(count,102);
console.log(JSON.stringify({nativeReplayInputs:count,roots:check.rows.length,standard:r('standard').standard.searches}));
