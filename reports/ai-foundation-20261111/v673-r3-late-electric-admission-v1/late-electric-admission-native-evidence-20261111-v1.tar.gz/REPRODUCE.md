# V673 public data exchange candidate

Run in a Production checkout at cbd73e00c98455dac868bd43be3e1759130088a7.
Let p be the absolute path of the extracted archive. Outputs must use new names.
build.py produces a private source copy; the hook loads only that copy for tests.
The optional historical-fixture lookup in the hook expects the local SETI Git
repository; a full checkout of the same source already contains those files.

```sh
(cd "$p" && shasum -a 256 -c SHA256SUMS)
python3 "$p/build.py" "$p/analysis-port.cjs"
node "$p/verify.cjs" "$p"
node "$p/check.cjs" "$p" "$p/replay-check.json.gz"
NODE_OPTIONS="--require=$p/hook.cjs" node "$p/resume.cjs" "$p" "$p/replay-resume.json.gz"
NODE_OPTIONS="--require=$p/hook.cjs" node "$p/standard-gate.cjs" "$PWD" reports/ai-foundation-20261109/v660-public-transport-chain-v1/v660-first3-independent-replay-20261109-v1.checkpoint.json "$p/replay-standard.json.gz" d3183131.cbd73e00.quick-400.json
NODE_OPTIONS="--require=$p/hook.cjs" node tools/run_node_tests.js --match company-card-trade --match amiba-currency-tail --match resource --match income-choice --match data-full --match search-agent
NODE_OPTIONS="--require=$p/hook.cjs" node tools/audit_v_state_inputs.js
node "$p/profile.cjs" "$p" "$p/replay-profile.json.gz"
```

Independent verification replays Native inputs without searching.
Timing varies by load. The R4 profile is diagnostic; no action is submitted.
