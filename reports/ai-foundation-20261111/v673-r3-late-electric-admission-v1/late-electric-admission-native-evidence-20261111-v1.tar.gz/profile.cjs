'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {open,readZ,writeZ}=require('./controlled-r3');
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const src=path.resolve('randomizer/game/ai/analysis-port.js'),base=fs.readFileSync(src,'utf8');
const anchor='      const result = before.phase === "awaiting_input"';
assert.equal(base.split(anchor).length,2);
const mod=new Module(src,module);mod.filename=src;mod.paths=Module._nodeModulePaths(path.dirname(src));
mod._compile(base.replace(anchor,`      globalThis.electricRootProfile.push({family:current.family,text:current.summary,head:head?.type??null,origin:session?.journal.actions[0]?.action?.summary??null});
`+anchor),src);
const [dir,out]=process.argv.slice(2),data=readZ(dir+'/fourth-auto-20261111-v1.json.gz');
const rows=[];
for(const x of data.results){
 globalThis.electricRootProfile=[];
 const m=open(x.end),p=mod.exports.createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});
 try{
  const q=createSearchAgent({analysisPort:p,seatId:'player-white'}).decide({seatId:'player-white',legalActions:m.menu()}).search;
  assert.deepEqual(m.save(),x.end);assert.equal(q.diagnostics.nativeExecutions,x.stop.n);
  const raw=globalThis.electricRootProfile;assert.equal(raw.length,x.stop.n);
  const by=(pick)=>Object.entries(raw.reduce((a,v)=>{const k=pick(v);a[k]=(a[k]||0)+1;return a;},{})).sort((a,b)=>b[1]-a[1]);
  const family=by(x=>x.family),head=by(x=>x.head||'stable'),groups=by(x=>[x.head,x.origin,x.text].join(' / '));
  console.log(JSON.stringify([x.card,x.stop.n,family,head,groups.slice(0,12)]));
  rows.push({card:x.card,state:x.end,family,head,groups,raw,q});
 }finally{p.close();m.dispose();}
}
writeZ(out,{rows});
