'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
const filename=path.resolve(process.cwd(),'randomizer/game/ai/analysis-port.js'),original=Module._extensions['.js'];
const replacement=fs.readFileSync(path.join(__dirname,'analysis-port.cjs'),'utf8');
Module._extensions['.js']=(m,name)=>name===filename?m._compile(replacement,name):original(m,name);
// Tests in this selective checkout may reference original immutable fixtures.
const {spawnSync}=require('node:child_process'),read=fs.readFileSync,root=process.cwd();
fs.readFileSync=function(file,options){
 try{return read.apply(this,arguments);}
 catch(error){
  if(error.code!=='ENOENT'||typeof file!=='string')throw error;
  const rel=path.relative(root,path.resolve(file));
  if(!/^(?:adhoc|reports)\//.test(rel))throw error;
  const r=spawnSync('git',['-C','/Users/bilibili/code/seti-simu','show','cbd73e00c:'+rel],{maxBuffer:100*1024*1024});
  if(r.status!==0)throw error;
  const enc=typeof options==='string'?options:options?.encoding;
  return enc?r.stdout.toString(enc):r.stdout;
 }
};
