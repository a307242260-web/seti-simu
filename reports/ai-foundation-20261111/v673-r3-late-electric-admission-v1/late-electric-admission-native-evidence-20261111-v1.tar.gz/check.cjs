'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {open,readZ,writeZ,short}=require('./controlled-r3');
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const [d,out]=process.argv.slice(2),old=readZ(d+'/admit-20261111-v1.json.gz'),root=old.root;
const filename=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(filename,module);
mod.filename=filename;mod.paths=Module._nodeModulePaths(path.dirname(filename));
mod._compile(fs.readFileSync(d+'/analysis-port.cjs','utf8'),filename);
const {createAnalysisPort}=mod.exports,rows=[];
function bench(name,state){
 const m=open(state),p=createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});
 try{
  const menu=m.menu(),agent=createSearchAgent({analysisPort:p,seatId:'player-white'}),q=agent.decide({seatId:'player-white',legalActions:menu}).search;
  assert.deepEqual(m.save(),state);
  const chosen=menu.find(a=>a.actionId===q.actionId),edge=q.lines[0]?.edges.find(e=>e.resourcePlan?.goal.kind==='known-electric-data-swap');
  const proof={name,state,menu,visible:m.owner('player-white'),q,chosen,edge,checkpoint:agent.createCheckpoint()};
  console.log(JSON.stringify([name,chosen.summary,q.value,q.complete,q.diagnostics.nativeExecutions,q.rootAndSearchMilliseconds,edge&&[edge.goalStatus,edge.cost,edge.steps.length]]));
  rows.push(proof);return proof;
 }finally{p.close();m.dispose();}
}
const first=bench('original',root);
assert(first.edge&&first.chosen.family==='industry');
assert.deepEqual(first.edge.steps,old.ids);
const m=open(root);
try{
 for(let i=0;i<2;i++){
  const a=m.menu().find(a=>a.actionId===old.ids[i]);assert(a);m.apply(a);
  const x=bench('cold-'+(i+1),m.save());
  assert.equal(x.chosen.actionId,old.ids[i+1]);assert.deepEqual(x.edge.steps,old.ids.slice(i+1));
 }
}finally{m.dispose();}
for(const name of ['ordinary-hidden','amiba-hidden','combined-hidden','spent-company','missing-offer','known-extra-data']){
 const variant=structuredClone(root),state=JSON.parse(variant.committedState),p=state.players.players.find(x=>x.id==='player-white');
 const swap=a=>{assert(a.length>=2);[a[0],a[1]]=[a[1],a[0]];};
 if(name==='ordinary-hidden'||name==='combined-hidden')swap(state.cards.drawPileCardIds);
 if(name==='amiba-hidden'||name==='combined-hidden')swap(state.aliens.amiba.cardDeck);
 if(name==='spent-company')p.industryRoundMarkRound=state.turn.roundNumber;
 if(name==='missing-offer')state.cards.publicCards=state.cards.publicCards.map(x=>x?.cardId==='dlc_15.png'?null:x);
 if(name==='known-extra-data')require(path.resolve('randomizer/game/data')).gainData(p,{root:state});
 variant.committedState=createStateStore(state).serialize().serialized;
 const x=bench(name,variant);
 if(name.endsWith('hidden')){
  assert.deepEqual(x.visible,first.visible);assert.deepEqual(x.menu,first.menu);
  for(const k of ['actionId','value','roots','lines','sharedPrefixGraph','candidates'])assert.deepEqual(x.q[k],first.q[k],k);
 }else assert(!x.edge);
}
assert(rows.every(x=>x.q.complete&&x.q.diagnostics.nativeExecutions<=256&&x.q.rootAndSearchMilliseconds<=600));
writeZ(out,{root,rows});
