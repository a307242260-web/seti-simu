基础源码为 0d7db90b6ef75acb5c8f79d45cb0036a1967e1b0。A 指向解包目录，OLD 指向该源码快照，NEW 只叠加本提交的 resource-demand.js。两局冷测均为独立 Node 进程；现有隔离路线和扫描优化由脚本注入，完整候选未准入。

    OPT="$(cat "$A/mode")-turn-copy-card-screen-data-screen-closed-r4-income"
    SETI_SCAN_PRIOR="$A/prior.cjs" node "$A/cold-root.cjs" "$OPT" "$A/root-b_111.webp.gz" "$A/replay-b_111.webp.json.gz"
    node "$A/compare.cjs" "$A" "$A"
    node "$A/verify-income.cjs" "$OLD" "$NEW" "$A/root-b_111.webp.gz" "$A/root-b_32.webp.gz" "$A/teacher-20261111-v1.json.gz" "$A/native-income-witness-20261111-v1.json.gz"

B32 同理，换根和输出名。检查不改变根/RNG、根报价、候选、搜索图及全部29输入的续跑证书。单独的最后一轮关闭收入准备是本次唯一源码变更：原估值的未来准备与扫描筹资都在第四轮返回零，因此直接使用同一个即时价值，仍保留真实收入奖励与现有探测器用途。八项定向回归和估值输入审计通过。

首次冷测149次/597.556ms、159次/612.819ms；两个根仍没有同时通过600ms。菜单及数据复用的独立试验见 content.log：仅9个菜单形状，能省242/245次菜单重建；按完整数据切片可省191/193次放置预览。完整报价不变，时间收益不足以加入。未运行新整局或新标准前三轮，实验中心历史不变。

r3-ledger.cjs 从既有原生存档生成逐项账本。将以下已跟踪文件放入输入目录后，用NEW运行 node "$A/r3-ledger.cjs" "$A"（复现时删除输出或用新目录）：
- reports/research/d3183131.cbd73e00.quick-400.json.round-end-2.checkpoint.json
- reports/research/d3183131.cbd73e00.quick-400.json.round-end-3.checkpoint.json
- reports/research/db594a2e.1609bf50.full.json.round-end-3.checkpoint.json
- V189 full 的 resumedFrom：seti-saves/seti-save-research-ai-search-v189-white-first2-20261105-93989585-quick-400-v53.json，复制为 v189-r3-resume-20261105.json。
V673只重放第二轮结束后两条已登记输入来定位边界；教师为既有合法复放，V189为唯一整局记录。三者分别按开局和PASS前的资产比较。教师34→105、V189 50→77、V673 48→118；三者起点的钱电、电脑和盘面用途已经不同，不能把41分的版本差值全归因于第三轮策略。V189第三轮没有提高永久电，也没有继续增加扫描盘信号；V673补到4永久电，仍少教师的3手牌、3池数据、2蓝槽和化石07。
