'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [input,out]=process.argv.slice(2),report=readZ(input),rows=[];
for(const c of report.rows)for(const card of ['b_111.webp','b_32.webp']){
 const m=open(c.state),accepted=[],turns=[];
 try{
  for(const [f,p] of [['pass'],['choose_card',a=>a.summary===card]])accepted.push({action:m.act(f,p),fixed:true});
  let stop,cp;
  for(let i=0;i<200;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!=='player-white'){
    const a=[];m.advanceOpponents(a);accepted.push(...a.map(action=>({action,passive:true})));continue;
   }
   const q=m.automatic(cp);
   if(!q.complete||!q.a||q.n>256||q.ms>600){stop={n:q.n,ms:q.ms,choice:q.a?.summary,complete:q.complete};break;}
   if(!cp||q.a.phase==='main'||q.a.family==='pass')turns.push({action:q.a,state:short(m)});
   cp=q.checkpoint;accepted.push({action:m.apply(q.a),n:q.n,ms:q.ms});
  }
  assert(stop);
  const end=m.save(),state=short(m),terminal=stop==='terminal'?m.state().match.finalScores.find(p=>p.playerId==='player-white'):null;
  m.restore(c.state);accepted.forEach(r=>m.apply(r.action));assert.deepEqual(m.save(),end);
  const peak=[Math.max(0,...accepted.map(x=>x.n||0)),Math.max(0,...accepted.map(x=>x.ms||0))];
  rows.push({label:c.label,card,root:c.state,accepted,turns,end,state,terminal,stop,peak});
  console.log(JSON.stringify({label:c.label,card,stop,score:terminal?.totalScore,breakdown:terminal&&[terminal.baseScore,terminal.tileScore,terminal.cardScore],peak}));
 }finally{m.dispose();}
}
writeZ(out,{rows});
