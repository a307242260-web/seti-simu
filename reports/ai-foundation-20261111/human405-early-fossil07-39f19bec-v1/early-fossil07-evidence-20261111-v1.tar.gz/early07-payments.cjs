'use strict';
const assert=require('node:assert/strict');
const {open,short,readZ,writeZ}=require('./controlled-r3');
const [input,out]=process.argv.slice(2),d=readZ(input),m=open(d.origin),rows=[];
const payId=(m,a)=>m.player().hand.find(c=>c.cardId===a)?.id;
function run(label,{direct,corner,payer1='chong_2.webp',payer2='dlc_20.png'}={}){
 m.restore(d.origin);const accepted=[],cuts={};
 const add=a=>accepted.push(m.apply(a));
 const act=(f,p)=>{const a=m.menu().find(q=>q.family===f&&(!p||p(q)));assert(a,JSON.stringify([label,f,m.menu().map(q=>[q.summary,q.target])]));add(a);};
 const applyRange=(a,b)=>d.timeline.slice(a-1,b).forEach(add);
 const resource=id=>{const c=payId(m,id);act('card_corner',a=>a.target.cardInstanceId===c&&a.payload.kind==='resource');};
 const place=(kind,slot)=>{act('place_data');act('choose_target',a=>a.target.target===kind&&(slot===undefined||a.target.blueSlot===slot));};
 const move=(id)=>{
  const c=payId(m,id);assert(c,id);
  if(corner){
   act('card_corner',a=>a.target.cardInstanceId===c&&a.payload.kind==='move');
   act('choose_target',a=>a.target.rocketId===6&&a.target.deltaX===0&&a.target.deltaY===1);
  }else{
   act('move',a=>a.target.rocketId===6&&a.target.deltaX===0&&a.target.deltaY===1);
   act('choose_payment',a=>a.target.choiceId===c);
  }
 };
 try{
  applyRange(1,direct?44:55);
  if(direct){
   act('choose_card',a=>a.summary==='dlc_20.png');
   place('computer');
   act('end_turn');
  }
  cuts.beforeFirst=m.save();
  move(payer1);
  cuts.afterFirst=m.save();
  resource(direct?'b_16.webp':'dlc_25.png');
  applyRange(59,63);
  cuts.beforeSecond=m.save();
  move(payer2);
  applyRange(66,74);
  const state=m.save(),assets=short(m),facts=m.facts();
  assert.equal(facts.probes[0]?.fossilId,'fossil_07');
  assert.equal(Object.keys(facts.tech.ownedTiles).length,6);
  assert(m.menu().some(a=>a.family==='pass'));
  m.restore(d.origin);accepted.forEach(addReplay);assert.deepEqual(m.save(),state);
  function addReplay(a){m.apply(a);}
  rows.push({label,accepted,cuts,state,assets,facts});
  console.log(JSON.stringify({label,accepted:accepted.length,assets}));
 }catch(e){
  const failed={label,message:e.message,menu:m.menu(),assets:short(m),state:m.save(),accepted};
  rows.push(failed);console.log(JSON.stringify({label,failure:e.message,assets:failed.assets}));
 }
}
try{
 run('baseline');
 run('native movement corners',{corner:true});
 run('launch takes DLC20 directly',{direct:true});
 run('launch DLC20 and movement corners',{direct:true,corner:true});
 run('launch DLC20, pay Chong7 on first move',{direct:true,corner:true,payer1:'chong_7.webp'});
 run('launch DLC20, pay Chong9 on first move',{direct:true,corner:true,payer1:'chong_9.webp'});
 assert.deepEqual(rows[0].state,d.origins['fully-fixed-before-pass'].state??d.origins['fully-fixed-before-pass']);
 writeZ(out,{source:d.origin,rows});
}finally{m.dispose();}
