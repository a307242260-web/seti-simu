Use Node 22 from the repository root at report parent 3942849df (AI source 39f19bec). Use a fresh output directory. Do not run timed commands concurrently.

```sh
proof=/path/to/extracted/archive
out=$(mktemp -d)
old=reports/ai-foundation-20261109/v661-early-transport-boundary-v1/v661-r172-preserve-assets-evidence-20261109-v1.tar.gz
reuse=reports/ai-foundation-20261111/human405-retention-search-39f19bec-v1/retention-search-evidence-20261111-v1.tar.gz
tar -xOf "$old" v661-r172-preserve-assets-handoffs-20261109-v1.json.gz > "$out/source.json.gz"
mkdir "$out/reuse"
tar -xzf "$reuse" -C "$out/reuse" ./reuse-scan.cjs ./reuse-yellow2.cjs ./prior.cjs
node "$proof/early07-payments.cjs" "$out/source.json.gz" "$out/payments.json.gz"
node "$proof/early07-income.cjs" "$out/payments.json.gz" "$out/income.json.gz"
node "$proof/early07-tail.cjs" "$out/income.json.gz" "$out/tails.json.gz"
node "$proof/salary-gates.cjs" "$out/tails.json.gz" "$out/reuse" "$out/gates.json.gz"
node "$proof/early07-refill.cjs" "$out/payments.json.gz" "$out/refill.json.gz"
node "$proof/early07-tail.cjs" "$out/refill.json.gz" "$out/refill-tail.json.gz"
node "$proof/early07-matched-payroll.cjs" "$out/payments.json.gz" "$out/matched.json.gz"
node "$proof/early07-tail.cjs" "$out/matched.json.gz" "$out/matched-tail.json.gz"
```

Only the old scripted 74-input segment is replayed from the shared R3 root. The new R3 variants fix public actions explicitly and the R4 continuations force the same keep-card, then use strict Production decisions. The matching hidden-deck experiment rotates three existing facedown cards solely as a controlled replay; public observation, native legal menu and RNG are unchanged before any reveal. Its scores are not original-world results. Search candidates in the isolated exact-settlement probe are submitted only after both gates pass and the original search graph is reproduced.
