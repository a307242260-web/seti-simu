'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [input,out]=process.argv.slice(2),a=readZ(input).rows,old=a[1],direct=a[3];
const source=JSON.parse(direct.state.committedState),other=JSON.parse(old.state.committedState);
assert.equal(direct.state.session,null);assert.equal(old.state.session,null);
const before=source.cards.drawPileCardIds.slice(0,3),salary=other.cards.drawPileCardIds.slice(0,2);
const name=c=>typeof c==='string'?c:c.cardId;
assert.deepEqual(before.map(name),['dlc_15.png','dlc_14.png','b_9.webp']);
assert.deepEqual(salary.map(name),['dlc_14.png','b_9.webp']);
const changed={...source,cards:{...source.cards,drawPileCardIds:[before[1],before[2],before[0],...source.cards.drawPileCardIds.slice(3)]}};
const state={...direct.state,committedState:JSON.stringify(changed)},m=open(direct.state);
try{
 const seen=m.owner('player-white'),legal=m.menu(),rng=m.facts().rng;
 m.restore(state);
 assert.deepEqual(m.owner('player-white'),seen);assert.deepEqual(m.menu(),legal);assert.deepEqual(m.facts().rng,rng);
 const assets=short(m);
 writeZ(out,{before,after:changed.cards.drawPileCardIds.slice(0,3),visibleExact:true,rows:[{label:'shortcut / matched hidden payroll',state,source:direct.state,assets}]});
}finally{m.dispose();}
