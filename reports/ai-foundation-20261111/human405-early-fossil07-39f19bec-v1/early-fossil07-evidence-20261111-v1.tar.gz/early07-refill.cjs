'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [input,out]=process.argv.slice(2),base=readZ(input).rows[3],rows=[];
for(const card of ['dlc_25.png','dlc_17.png']){
 const m=open(base.state),accepted=[],label='visible refill / '+card;
 try{
  const hand=m.player().hand.find(c=>c.cardId==='chong_8.webp'),slot=m.state().cards.publicCards.findIndex(c=>c?.cardId===card);
  assert(hand&&slot>=0);
  accepted.push(m.corner(hand.cardId));
  accepted.push(m.act('quick_trade',a=>a.target.tradeId==='publicity-for-card'));
  accepted.push(m.pick(card));
  const after=m.save(),assets=short(m),facts=m.facts();
  assert(m.menu().some(a=>a.family==='pass'));
  m.restore(base.state);accepted.forEach(a=>m.apply(a));assert.deepEqual(m.save(),after);
  rows.push({label,state:after,root:base.state,accepted,assets,facts});
  console.log(JSON.stringify({label,assets}));
 }finally{m.dispose();}
}
writeZ(out,{rows});
