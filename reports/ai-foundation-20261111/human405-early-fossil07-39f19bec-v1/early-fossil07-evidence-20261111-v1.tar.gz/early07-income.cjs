'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [input,out]=process.argv.slice(2),d=readZ(input),rows=[];
const cases=[...d.rows.slice(0,4).map(r=>({source:r,kind:'hold'})),...[['chong_7.webp','chong_8.webp'],['chong_9.webp','chong_8.webp'],['chong_7.webp','amiba_9.webp'],['chong_9.webp','amiba_9.webp']].map(([swap,income])=>({source:d.rows[3],kind:'salary',swap,income}))];
for(const {source,kind,swap,income} of cases){
 const label=kind==='hold'?source.label:swap+' / salary '+income;
 const m=open(source.state),accepted=[],checkpoints={};
 try{
  const apply=a=>accepted.push(m.apply(a));
  const act=(f,p)=>{const a=m.menu().find(x=>x.family===f&&(!p||p(x)));assert(a,JSON.stringify([label,f,m.menu().map(x=>x.summary)]));apply(a);};
  const place=()=>{act('place_data');act('choose_target',a=>a.target.target==='computer');};
  if(kind==='salary'){
   place();act('analyze');act('choose_target',a=>a.target.choiceId==='trace:1:blue:amiba:4');
   act('choose_card',a=>a.target.source==='display');
   assert.equal(m.player().resources.availableData,3);assert(m.player().hand.some(c=>c.cardId==='amiba_9.webp'));
   checkpoints.afterAnalysis=m.save();
   const c=m.player().hand.find(c=>c.cardId===swap);assert(c);
   act('industry',a=>a.target.abilityId==='deepspace_swap_cards');act('choose_card',a=>a.target.cardInstanceId===c.id);
   act('choose_card',a=>a.summary==='dlc_17.png');
   const payer=m.player().hand.find(c=>c.cardId==='dlc_17.png');assert(payer);
   act('card_corner',a=>a.target.cardInstanceId===payer.id&&a.payload.kind==='resource');
   const revenue=m.player().hand.find(c=>c.cardId===income);assert(revenue);
   for(let i=0;i<4;i++)place();
   act('choose_card',a=>a.target.cardInstanceId===revenue.id);
   act('end_turn');const a=[];m.advanceOpponents(a);accepted.push(...a);
  }
  assert(m.menu().some(a=>a.family==='pass'));
  const state=m.save(),assets=short(m),facts=m.facts();
  assert.equal(facts.income.credits,7);assert.equal(facts.income.energy,kind==='salary'?4:3);
  assert.equal(Object.keys(facts.tech.ownedTiles).length,6);assert.equal(facts.probes[0]?.fossilId,'fossil_07');
  m.restore(source.state);accepted.forEach(a=>m.apply(a));assert.deepEqual(m.save(),state);
  rows.push({label,kind,root:source.state,accepted,state,assets,facts,checkpoints});
  console.log(JSON.stringify({label,assets,n:accepted.length}));
 }finally{m.dispose();}
}
writeZ(out,{rows});
