'use strict';
const path=require('node:path'),assert=require('node:assert/strict');
const {getProbeRouteRequirements,comparePlannedMovementTiming}=require(path.resolve('randomizer/game/production-kernel'));
const {open,short,readZ,writeZ}=require('./controlled-r3');
const [d,out]=process.argv.slice(2),g=readZ(d+'/geometry-20261111-v1.json.gz'),result=[];
const seat='player-white',trade='credits-for-energy';
const get=(state,planet)=>(getProbeRouteRequirements(state,seat)?.candidates||[]).find(q=>q.rocketId===6&&q.endpointFamily==='land'&&q.planetId===planet&&q.endpointTarget?.type==='planet');
const pre=open(g.before),ship=pre.facts().probes[0],t=[];
for(const planet of ['mercury','saturn'])for(const [dir,deltaX,deltaY] of [['CW',1,0],['out',0,1]]){
 const q=get(pre.state(),planet);assert(q);
 t.push({planet,dir,value:comparePlannedMovementTiming(pre.state(),seat,q.requirementId,[{rocketId:ship.id,deltaX,deltaY,requiredMovePoints:1}],1)});
}
assert.deepEqual(pre.save(),g.before);pre.dispose();
for(const x of g.results)for(const planet of ['mercury','saturn']){
 const root=x.entry.envelope,m=open(root),actions=[];
 try{
  const wallet=m.facts().wallet,opening=short(m),goal=get(m.state(),planet);assert(goal);
  const e=goal.required.energy,c=goal.required.credits,buy=Math.max(0,e-wallet.energy);
  if(c+buy*2>wallet.credits){
   result.push({name:x.name,planet,root,opening,goal,buy,cost:c+buy*2,stop:'cash-lower-bound'});
   continue;
  }
  for(let i=0;i<buy;i++)actions.push(m.act('quick_trade',a=>a.target.tradeId===trade));
  for(let i=0;i<goal.required.movementSteps;i++){
   const next=get(m.state(),planet);assert(next?.nextStep);
   const a=next.nextStep;
   actions.push(m.act('move',q=>q.target.rocketId===a.rocketId&&q.target.deltaX===a.deltaX&&q.target.deltaY===a.deltaY));
   actions.push(m.act('choose_payment',q=>q.target?.kind==='move-payment'&&!q.target.cardIds.length));
  }
  const now=get(m.state(),planet);assert.equal(now.required.movementSteps,0);
  assert(m.facts().wallet.energy>=now.endpointFacts.cost.energy);
  actions.push(m.act('land',q=>q.target.rocketId===undefined||q.target.rocketId===6));
  if(m.menu().some(a=>a.target.landTarget?.type==='planet'&&a.target.planetId===planet))
   actions.push(m.act('choose_target',q=>q.target.landTarget?.type==='planet'&&q.target.planetId===planet));
  const end=m.save(),assets=short(m),menu=m.menu();
  m.restore(root);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  assert.equal(assets.wallet[1],wallet.credits-c-buy*2);
  assert.equal(assets.wallet[2],wallet.energy+buy-e);
  assert.equal(assets.wallet[0]-opening.wallet[0],goal.targetBenefit.score);
  assert.equal(assets.wallet[4]-opening.wallet[4],goal.targetBenefit.dataCount);
  result.push({name:x.name,planet,root,opening,goal,buy,cost:c+buy*2,stop:'landed-before-trace',actions,end,assets,menu});
 }finally{m.dispose();}
}
for(const a of result)console.log(JSON.stringify([a.name,a.planet,a.opening.wallet.slice(1,3),a.goal.required.energy,a.buy,a.cost,a.stop,a.assets?.wallet,a.actions?.length]));
console.log(JSON.stringify(t.map(x=>[x.planet,x.dir,x.value.waitPaidPoints,x.value.alternatives.at(-1)])));
writeZ(out,{timing:t,result});
