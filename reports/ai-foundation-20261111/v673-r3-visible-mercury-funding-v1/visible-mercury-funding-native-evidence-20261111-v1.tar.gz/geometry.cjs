'use strict';
const path=require('node:path'),assert=require('node:assert/strict');
const {getProbeRouteRequirements,comparePlannedMovementTiming}=require(path.resolve('randomizer/game/production-kernel'));
const {open,short,readZ,writeZ}=require('./controlled-r3');
const [d,out]=process.argv.slice(2),r=n=>readZ(d+'/original/'+n+'-20261111-v1.json.gz');
const t=r('round3').rows.find(x=>x.label.endsWith('corner-A9')),orig=r('fourth').results,stock=r('fourth-stock').results;
const sat=s=>(getProbeRouteRequirements(s,'player-white')?.candidates||[]).find(q=>q.rocketId===6&&q.endpointFamily==='land'&&q.planetId==='saturn'&&q.endpointTarget?.type==='planet');
const m=open(t.settled.state),at=m.facts().probes[0],s=m.state();
const initial=sat(s);assert(initial);
const timing=[];
for(const [dir,deltaX,deltaY] of [['顺时针',1,0],['向外',0,1]]){
 const step={rocketId:at.id,deltaX,deltaY,requiredMovePoints:1};
 const row=comparePlannedMovementTiming(s,'player-white',initial.requirementId,[step],1);
 timing.push({dir,step,row});
}
assert.deepEqual(m.save(),t.settled.state);m.dispose();
const results=[];
for(const x of [...stock,...orig].filter(x=>x.card==='b_111.webp')){
 const a=open(x.root);
 try{
  let entry,landing,landed;
  const first=a.facts().round;
  for(const row of x.actions){
   const q=row.action;
   if(!entry&&a.facts().round===4&&q.actorId==='player-white'){
    entry={envelope:a.save(),assets:short(a),saturn:sat(a.state()),wallet:a.facts().wallet,solar:a.state().solarSystem};
   }
   if(q.family==='land'&&q.actorId==='player-white'&&!landing)
    landing={envelope:a.save(),assets:short(a),saturn:sat(a.state()),wallet:a.facts().wallet};
   a.apply(q);
   if(landing&&!landed&&!a.c.inspect().session){
    const p=a.state().pieces.rockets.find(q=>q.id===6), state=a.state();
    landed={assets:short(a),probe:p,planets:Object.fromEntries(Object.entries(state.planets.planets).map(([k,v])=>[k,Object.keys(v).filter(q=>q.toLowerCase().includes('land')).map(q=>[q,v[q]])]))};break;
   }
  }
  assert(entry&&landing&&landed);
  results.push({name:x.name,entry,landing,landed});
  console.log(JSON.stringify([x.name,entry.assets.probes,entry.assets.wallet,entry.saturn&&[entry.saturn.required,entry.saturn.endpointFacts.cost],landing.assets.probes,landing.assets.wallet,landing.saturn?.required,landed.probe?.surface]));
 }finally{a.dispose();}
}
console.log(JSON.stringify({before:{root:t.settled.summary,required:initial.required,endpoint:initial.endpointFacts.cost},timing:timing.map(x=>[x.dir,x.row])}));
writeZ(out,{before:t.settled.state,initial,timing,results});
