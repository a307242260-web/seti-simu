# V673 known Mercury funding after a free B16 step

Run from a clean Production checkout at cbd73e00c98455dac868bd43be3e1759130088a7.
Let p be the absolute path to the extracted archive. Original seed records are
in original/ and are used as frozen inputs. The paired and directional
diagnostics compile a private in-memory module without writing Production files.
Use fresh filenames for all outputs.

```sh
(cd "$p" && shasum -a 256 -c SHA256SUMS)
node "$p/verify.cjs" "$p"
node "$p/hidden-roots.cjs" "$p" "$p/replay-hidden-roots.json.gz"
node "$p/paired.cjs" "$p" "$p/replay-hidden-policy.json.gz" paired hidden
node "$p/third.cjs" "$p" "$p/replay-third.json.gz"
node "$p/fourth.cjs" "$p" "$p/replay-fourth.json.gz"
node "$p/geometry.cjs" "$p" "$p/replay-geometry.json.gz"
node "$p/funding.cjs" "$p" "$p/replay-funding.json.gz"
node "$p/direction.cjs" "$p" "$p/replay-direction.json.gz"
node "$p/valuation.cjs" "$p" "$p/replay-valuation.json.gz"
```

The verification command replays the archived native actions without searching.
The timings in a rerun can vary; keep the original budget gates.
