'use strict';
const path=require('node:path'),assert=require('node:assert/strict');
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const {open,readZ,writeZ}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),x=readZ(dir+'/move-corner-20261111-v1.json.gz'),roots=[];
const view=m=>({visible:m.owner('player-white'),menu:m.menu(),rng:m.facts().rng});
const m=open(x.root),base=view(m);m.dispose();
for(const mode of ['ordinary-top','amiba-top','both-top','ordinary-B9-delayed','ordinary-DLC3-delayed','chong-top']){
 const root=structuredClone(x.root),raw=JSON.parse(root.committedState),changed=[];
 const swap=(name,deck,i,j)=>{assert(j<deck.length&&deck[i]!==deck[j]);changed.push({name,indices:[i,j],identities:[deck[i],deck[j]]});[deck[i],deck[j]]=[deck[j],deck[i]];};
 if(['ordinary-top','both-top'].includes(mode))swap('ordinary',raw.cards.drawPileCardIds,0,1);
 if(['amiba-top','both-top'].includes(mode))swap('amiba',raw.aliens.amiba.cardDeck,0,1);
 if(mode==='ordinary-B9-delayed')swap('ordinary',raw.cards.drawPileCardIds,2,9);
 if(mode==='ordinary-DLC3-delayed')swap('ordinary',raw.cards.drawPileCardIds,11,15);
 if(mode==='chong-top')swap('chong',raw.aliens.chong.cardDeck,0,1);
 root.committedState=createStateStore(raw).serialize().serialized;
 const n=open(root);try{assert.deepEqual(view(n),base);assert.deepEqual(n.save(),root);}finally{n.dispose();}
 roots.push({mode,changed,root});
 console.log(JSON.stringify([mode,changed]));
}
writeZ(out,{baseRoot:x.root,roots});
