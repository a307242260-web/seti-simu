'use strict';
const assert=require('node:assert/strict');
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [d,out]=process.argv.slice(2),src=readZ(d+'/hidden-policy-20261111-v1.json.gz');
const result=[];
for(const {variant,root,q} of src.results){
 const stock=q.lines[0].edges.filter(e=>e.actionId===q.actionId&&q.lines.find(n=>n.node===e.target).value===q.value);
 assert.equal(stock.length,1);
 const corner=q.lines[0].edges.find(e=>e.resourcePlan?.id.endsWith('proof-corner-A9'));assert(corner);
 const prep=e=>h=>{for(const id of e.steps){const a=h.m.menu().find(x=>x.actionId===id);assert(a,id);h.take(h.m.apply(a));}h.cut('release');};
 const r=runCases(root,[[variant+'/stock',prep(stock[0])],[variant+'/corner',prep(corner)]]);
 const after=r.rows.find(x=>x.label.endsWith('/corner'));
 const extra=after?.settled&&runCases(after.settled.state,[[variant+'/corner-CW-Procyon',h=>{
  const f=h.m.facts();
  assert.equal(f.wallet.credits,1);
  assert(f.probes.some(q=>q.sectorX===4&&q.sectorY===2));
  h.take(h.m.play('b_16.webp'));h.act('choose_target',a=>a.summary.endsWith('顺时针'));
  h.act('choose_target',a=>a.summary==='扫描 南河三');h.cut('B16');
 }]]);
 result.push({variant,root,...r,extra});
}
writeZ(out,{result});
