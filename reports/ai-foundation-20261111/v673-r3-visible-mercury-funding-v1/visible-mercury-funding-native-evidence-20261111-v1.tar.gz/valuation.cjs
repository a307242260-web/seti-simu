'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {readZ,open,writeZ}=require('./controlled-r3');
const {factsFromObservation}=require(path.resolve('randomizer/game/ai/probe-capital'));
const {DEFAULT_WEIGHTS,purposeCapital,evaluateStateValue}=require(path.resolve('randomizer/game/ai/state-value'));
const [d,out]=process.argv.slice(2),r=n=>readZ(d+'/'+n+'-20261111-v1.json.gz');
const g=r('geometry'),f=r('funding'),q=r('direction').results.find(x=>x.mode==='known-direction').q;
const [pass,play]=['pass','play_card'].map(f=>q.roots.find(x=>x.actionId.startsWith(f+':')).value);
const original=r('original/extra');
const cases=[['留B16',g.before],...original.rows.filter(x=>x.label.endsWith('/南河三')).map(x=>[x.label,x.settled.state])];
const base=f.result.find(x=>x.name==='留B16'&&x.planet==='mercury');
const results=[];
for(const [name,root] of cases){
 const p=open(root);
 try{
  const obs=p.owner('player-white'),facts=factsFromObservation(obs,'player-white'),withProbe=purposeCapital(facts);
  const withoutProbe=purposeCapital({...facts,board:{...facts.board,rockets:facts.board.rockets.filter(x=>x.playerId!=='player-white')}});
  assert.equal(withProbe.total,withoutProbe.total);
  const compared=f.result.find(x=>x.name===name&&x.planet==='mercury');assert(compared);
  const funded=compared.stop==='landed-before-trace';
  const premium=funded?(base.cost-compared.cost)*DEFAULT_WEIGHTS.credits:null;
  const score=name==='留B16'?pass:play;
  assert.deepEqual(p.save(),root);
  const report={name,root,score,rawStableValue:evaluateStateValue(obs,'player-white'),funded,premium,shadow:premium===null?null:score+premium};
  console.log(JSON.stringify({name,score,rawStableValue:report.rawStableValue.total,funded,premium,shadow:report.shadow}));
  results.push(report);
 }finally{p.dispose();}
}
assert.deepEqual(results.map(x=>x.shadow),[189,null,190.5]);
writeZ(out,results);
