'use strict';
const assert=require('node:assert/strict');
const {readZ,open}=require('./controlled-r3');
const dir=process.argv[2],r=n=>readZ(dir+'/'+n+'-20261111-v1.json.gz');
let count=0,terminals=0,r3=0,land=0;
function replay(root,trace,end){
 const m=open(root);
 try{
  for(const x of trace){if(x.n!==undefined)assert(x.n<=256&&x.ms<=600);
   if(x.passive)assert.notEqual(x.action.actorId,'player-white');
   m.apply(x.action||x);count++;
  }
  assert.deepEqual(m.save(),end);
  return m.state().match.finalScores?.find(x=>x.playerId==='player-white');
 }finally{m.dispose();}
}
for(const v of r('hidden-policy').results){
 const q=v.q,old=r('paired-fixed').results[0].q;
 assert(q.complete&&!q.unresolved.length&&q.diagnostics.nativeExecutions===74&&q.rootAndSearchMilliseconds<=600);
 for(const k of ['actionId','value','roots','lines','sharedPrefixGraph','candidates','selectionPlan'])assert.deepEqual(q[k],old[k]);
}
for(const g of r('third').result){
 assert(g.rows.length===2&&!g.failures.length&&g.extra?.rows.length===1&&!g.extra.failures.length);
 for(const x of g.rows){replay(g.root,x.prefix,x.start);replay(x.start,x.actions,x.end);r3++;}
 const x=g.extra.rows[0],root=g.rows.find(x=>x.label.endsWith('/corner')).settled.state;
 replay(root,x.prefix,x.start);replay(x.start,x.actions,x.end);r3++;
}
const d4=r('fourth'),totals=new Map(d4.results.map(x=>[x.name+'/'+x.card,x.terminal.totalScore]));
let min=Infinity,max=-Infinity;
for(const x of d4.results){
 assert.equal(x.stop,'terminal');assert.deepEqual(replay(x.root,x.actions,x.end),x.terminal);terminals++;
 if(x.name.endsWith('/corner-CW-Procyon')){
  const gap=x.terminal.totalScore-totals.get(x.name.replace('/corner-CW-Procyon','/stock')+'/'+x.card);
  min=Math.min(min,gap);max=Math.max(max,gap);
 }
}
for(const x of r('funding').result.filter(x=>x.actions)){
 replay(x.root,x.actions,x.end);land++;
 assert(x.actions.every(a=>a.family!=='choose_payment'||!a.target.cardIds.length));
}
assert.deepEqual([terminals,r3,land,min,max],[24,18,7,24,44]);
console.log(JSON.stringify({nativeReplayInputs:count,terminals,r3,land,min,max}));
