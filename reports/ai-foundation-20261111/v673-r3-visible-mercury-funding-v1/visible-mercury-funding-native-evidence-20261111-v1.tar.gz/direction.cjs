'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {readZ,open,writeZ}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),d=readZ(dir+'/geometry-20261111-v1.json.gz');
const src=path.resolve('randomizer/game/ai/analysis-port.js'),base=fs.readFileSync(src,'utf8');
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const anchor='      const stay=stayForFreePickupLanding(node,stored,state);';
assert.equal(base.split(anchor).length,2);
const patch=`      const probeTurn=state.turn,head=stored.envelope.session?.session?.queue?.[0];
      const moveSource=stored.envelope.session?.session?.journal?.actions?.[0]?.action;
      const named=moveSource?.family==="play_card"&&openedRoot?.observation?.selfState.hand
        ?.some(c=>c.id===moveSource.target.cardInstanceId&&c.cardId==="b_16.webp");
      if(node.status==="decision"&&named&&head?.payload?.remaining===1&&probeTurn.roundNumber===3
        &&probeTurn.activePlayerIds.every(id=>id===seatId||probeTurn.passedPlayerIds.includes(id))){
        const p=state.players.players.find(x=>x.id===seatId),directions=node.legalActions.filter(goalMovement.isDirection);
        const skip=node.legalActions.find(a=>a.target.skip===true);
        const cand=(productionKernel||globalThis.SetiProductionKernel).getProbeRouteRequirements(state,seatId)?.candidates
          .find(c=>c.planetId==="mercury"&&c.endpointFamily==="land"&&c.endpointTarget.type==="planet");
        if(skip&&cand&&directions.length&&p.resources.credits===0&&p.resources.energy===1
          &&p.income.credits===7&&p.income.energy===3&&cand.targetBenefit.score===12&&cand.targetBenefit.dataCount===3){
          const query=timingForOneGoalQuery(state), energy=p.resources.energy+p.income.energy, cash=p.resources.credits+p.income.credits;
          const total=n=>2*Math.max(0,n+(cand.endpointFacts.cost.energy||0)-energy);
          const payments=directions.filter(a=>a.target.rocketId===cand.rocketId).map(a=>{
            const q=query(cand.requirementId,[{...a.target,requiredMovePoints:1}],1);
            return {a,now:q.comparable?total(q.alternatives[1].remainingPaidPoints):null,wait:q.comparable?total(q.waitPaidPoints):null};
          }).filter(x=>x.now!==null&&x.now<x.wait&&x.now<=cash);
          payments.sort((a,b)=>a.now-b.now||a.a.actionId.localeCompare(b.a.actionId));
          if(payments.length&&(!payments[1]||payments[1].now>payments[0].now)){
            const {a,now,wait}=payments[0];
            const result=freeze({policy:"diagnostic-known-next-round-landing-direction",selectionBasis:"same-known-public-landing",
              isEquivalence:false,reason:"minimum-known-movement-payment",selectedActionId:a.actionId,intent:null,
              retainedActionIds:[a.actionId],excludedActionIds:node.legalActions.filter(x=>x!==a).map(x=>x.actionId),
              excludedDirectionCount:directions.length-1,routingNodes:0});
            globalThis.directionProof.push({action:a,now,wait});
            movementPolicies.set(node,result);return result;
          }
        }
      }
`;
const results=[];
for(const mode of ['baseline','known-direction']){
 const m=open(d.before),mod=new Module(src,module);mod.filename=src;mod.paths=Module._nodeModulePaths(path.dirname(src));
 globalThis.directionProof=[];
 mod._compile(mode==='baseline'?base:base.replace(anchor,patch+anchor),src);
 const p=mod.exports.createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});
 try{
  const legal=m.menu(),q=createSearchAgent({seatId:'player-white',analysisPort:p}).decide({seatId:'player-white',legalActions:legal}).search;
  assert(q.complete&&!q.unresolved.length&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600);
  assert.deepEqual(m.save(),d.before);
  const proof=structuredClone(globalThis.directionProof),play=legal.find(a=>a.family==='play_card'&&a.summary==='b_16.webp');
  const pRoot=q.roots.find(r=>r.actionId===play.actionId);
  console.log(JSON.stringify({mode,proof,chosen:legal.find(a=>a.actionId===q.actionId).summary,value:q.value,B16:pRoot.value,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds}));
  results.push({mode,q,proof,legal});
 }finally{p.close();m.dispose();}
}
writeZ(out,{root:d.before,results});
