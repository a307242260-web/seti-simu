'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [prior,out]=process.argv.slice(2),d=readZ(prior),old=d.rows.find(r=>r.label==='cash / dlc_17.png / amiba / out / autonomous');
const idx=old.prefix.findIndex(a=>a.target.tradeId==='cards-for-energy'),m=open(d.root);
let root,legal;
try{
 assert(idx>=0);
 old.prefix.slice(0,idx).forEach(m.apply);root=m.save();legal=m.menu();
 console.log(JSON.stringify({root:short(m),hand:m.player().hand.map(x=>x.cardId),legal:legal.map(x=>x.summary)}));
}finally{m.dispose();}
const cases=[],prefix=[];
function end(h){h.act('end_turn');const passive=[];h.m.advanceOpponents(passive);h.take(...passive);}
function trade(h,kind,pay){
 h.act('quick_trade',a=>a.target.tradeId===kind);
 pay.forEach(id=>h.act('choose_payment',a=>a.target.select&&a.summary===id));
 h.act('choose_payment',a=>a.target.confirm);
}
function place(h,slot){h.act('place_data');h.act('choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');}
function scan(h,{pay,selected,buy}){
 if(buy){h.act('quick_trade',a=>a.target.tradeId==='publicity-for-card');h.take(h.m.pick(buy));}
 trade(h,'cards-for-energy',pay);h.cut('wallet');end(h);
 h.act('scan');h.act('choose_target',a=>a.target.nebulaId==='sector-3-a');
 h.act('choose_card',a=>a.summary===selected+' → 开普勒22');
 h.act('choose_target',a=>a.target.choiceId==='scan4:move:6:out');
 h.act('choose_target',a=>a.target.choiceId==='trace:1:pink:amiba:3');
 for(let i=0;i<5&&h.m.save().session;i++){
  const a=h.m.menu().find(a=>a.target.source==='display'||a.target.choiceId?.startsWith('confirm:trigger:'));
  assert(a);h.take(h.m.apply(a));
 }
 h.act('complete_task',a=>a.target.ruleId==='dlc9-three-sector-wins');
 h.cut('after-scan');end(h);
}
for(const data of [
 {name:'保 B16',pay:['dlc_32.png','amiba_7.webp']},
 {name:'保 DLC32',pay:['b_16.webp','amiba_7.webp']},
 {name:'买 DLC20 作燃料，保 B16',pay:['dlc_32.png','dlc_20.png'],buy:'dlc_20.png'},
 {name:'买 DLC17 作燃料，保 B16',pay:['dlc_32.png','dlc_17.png'],buy:'dlc_17.png'}
])for(const selected of ['dlc_17.png','dlc_24.png']){
 if(data.buy===selected)continue;
 const spec={...data,selected},tag=data.name+' / '+selected;
 cases.push([tag+' / only pay and scan',h=>scan(h,spec)]);
 if(!data.name.includes('B16'))continue;
 cases.push([tag+' / keep early blue1 and cash',h=>{
  scan(h,spec);h.act('research_tech');h.act('choose_target',a=>a.target.tileId==='blue1'&&a.target.blueSlot===3);
  place(h);place(h);place(h,3);h.cut('cash');end(h);
 }]);
 cases.push([tag+' / early blue1 and B16 scan',h=>{
  scan(h,spec);h.act('research_tech');h.act('choose_target',a=>a.target.tileId==='blue1'&&a.target.blueSlot===3);
  place(h);place(h);place(h,3);end(h);
  h.take(h.m.play('b_16.webp'));h.act('choose_target',a=>a.target.skip);
  h.act('choose_target',a=>a.target.nebulaId==='sector-1-a');h.cut('b16-scan');
 }]);
}
const r=runCases(root,cases);
writeZ(out,{old:{origin:d.root,prefix:old.prefix.slice(0,idx),cash:old.settled.summary},root,...r});
