'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ}=require('./controlled-r3'),
 {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port')),{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const tech=readZ(process.argv[2]),early=readZ(process.argv[3]),rows=[];
const cases=[['last-orange-choice',tech.root],['energy-after-analysis',early.root]];
for(const r of tech.rows.filter(x=>x.label==='orange1 / dlc_16.png'||x.label==='orange1 / only tile')){
 const m=open(r.settled.state);
 try{m.act('pass');cases.push([r.label+' reserve card',m.save()]);}finally{m.dispose();}
}
for(const [name,root] of cases){
 const m=open(root),seatId='player-white',p=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
 try{
  const menu=m.menu(),q=createSearchAgent({seatId,analysisPort:p}).decide({seatId,legalActions:menu}).search;
  assert.deepEqual(m.save(),root);assert(q.complete&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600);
  const chosen=menu.find(x=>x.actionId===q.actionId),r=menu.filter(x=>x===chosen||x.target.tileId?.startsWith('orange')
   ||x.target.tradeId==='cards-for-energy'||['b_111.webp','b_32.webp','dlc_16.png'].includes(x.summary))
   .map(a=>[a.summary,q.roots.find(r=>r.actionId===a.actionId)]);
  console.log(JSON.stringify({name,chosen:chosen.summary,ms:q.rootAndSearchMilliseconds,n:q.diagnostics.nativeExecutions,roots:r.map(([x,y])=>[x,y?.value,y?.completion])}));
  rows.push({name,root,q,picks:r});
 }finally{p.close();m.dispose();}
}
writeZ(process.argv[4],{rows});
