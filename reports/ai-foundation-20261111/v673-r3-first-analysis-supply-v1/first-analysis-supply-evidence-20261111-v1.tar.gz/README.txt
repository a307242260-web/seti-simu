Production JS: 433765e936e26b6a25c8b599f580792471e3445b. Run from the repo root with Node 22; E is this extracted directory. Choose fresh outputs.
Input early-electric-cargo-20261111-v2.json.gz is from the V666 funded-fossil archive linked in the report.
node "$E/early-energy-payers.cjs" /path/to/early-electric-cargo-20261111-v2.json.gz /tmp/seti-payers-r3.json.gz
node "$E/last-research.cjs" /path/to/early-electric-cargo-20261111-v2.json.gz /tmp/seti-last-tech-r3.json.gz
node "$E/quotes.cjs" /tmp/seti-last-tech-r3.json.gz /tmp/seti-payers-r3.json.gz /tmp/seti-supply-quotes.json.gz
node "$E/fourth.cjs" /tmp/seti-last-tech-r3.json.gz reports/research/d3183131.cbd73e00.quick-400.json.round-end-3.checkpoint.json /tmp/seti-supply-r4.json.gz
For n in new-orange, dlc_16, dlc_20:
node "$E/profile.cjs" "$E/${n}-b32-root-20261111-v1.json.gz" "/tmp/seti-${n}-b32-baseline.json.gz"
node "$E/admit.cjs" witness "$E/${n}-b32-root-20261111-v1.json.gz" "$E/${n}-b32-baseline-20261111-v1.json.gz" "/tmp/seti-${n}-b32-witness.json.gz"
node "$E/continue.cjs" "$E/${n}-b32-scan-witness-20261111-v1.json.gz" "/tmp/seti-${n}-b32-resume.json.gz"
Replay without search:
node "$E/verify.cjs" "$E/early-energy-payers-20261111-v1.json.gz" "$E/analysis-supply-last-tech-20261111-v1.json.gz" "$E/analysis-supply-fourth-20261111-v1.json.gz" /tmp/seti-supply-verified.json.gz "$E/new-orange-b32-resume-20261111-v1.json.gz" "$E/dlc_16-b32-resume-20261111-v1.json.gz" "$E/dlc_20-b32-resume-20261111-v1.json.gz"
