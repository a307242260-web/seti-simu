'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),Module=require('node:module');

const [archive,out,yellow]=process.argv.slice(2),src=path.resolve('randomizer/game/ai/analysis-port.js');
const mod=new Module(src,module);mod.filename=src;mod.paths=Module._nodeModulePaths(path.dirname(src));
let code=fs.readFileSync(src,'utf8');
const anchor='      submissionCount += 1;';
assert.equal(code.split(anchor).length,2);
code=code.replace(anchor,anchor+`
      const delta=globalThis.cargoNative, k=JSON.stringify([current.family,head?.type||null,current.summary,
        before.session?.actions?.[0]?.family||null]);
      delta[k]=(delta[k]||0)+1;`);
if(yellow)code=require(yellow)(code);
const {open,readZ,writeZ}=require('./controlled-r3');
mod._compile(code,src);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const {root}=readZ(archive).results.find(r=>r.card==='b_32.webp');
const m=open(root),seatId='player-white',port=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
try{
 globalThis.cargoNative={};
 const agent=createSearchAgent({seatId,analysisPort:port}),q=agent.decide({seatId,legalActions:m.menu()}).search;
 assert.deepEqual(m.save(),root);
 const counts=Object.entries(globalThis.cargoNative).sort((a,b)=>b[1]-a[1]),groups={};
 for(const [s,n] of counts){const [family,head]=JSON.parse(s);const key=[family,head].filter(Boolean).join(' / ');groups[key]=(groups[key]||0)+n;}
 assert.equal(counts.reduce((n,[,b])=>n+b,0),q.diagnostics.nativeExecutions);
 console.log(JSON.stringify({complete:q.complete,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,value:q.value,action:m.menu().find(a=>a.actionId===q.actionId)?.summary,groups:Object.entries(groups).sort((a,b)=>b[1]-a[1]),top:counts.slice(0,20)}));
 writeZ(out,{root,q,counts});
}finally{port.close();m.dispose();}
