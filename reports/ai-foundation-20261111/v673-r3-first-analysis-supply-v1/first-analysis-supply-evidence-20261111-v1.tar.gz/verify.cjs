'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ}=require('./controlled-r3');
const [early,tech,r4,out,...resumes]=process.argv.slice(2),d=readZ(early),t=readZ(tech),f=readZ(r4);
let inputs=0;
function verify(root,actions,end,terminal){
 const m=open(root);
 try{
  for(const x of actions){assert.deepEqual(m.apply(x),x);inputs++;}
  assert.deepEqual(m.save(),end);
  if(terminal)assert.deepEqual(m.state().match.finalScores.find(p=>p.playerId==='player-white'),terminal);
 }finally{m.dispose();}
}
verify(d.old.origin,d.old.prefix,d.root);
verify(t.parent.root,t.parent.actions,t.root);
for(const a of [d,t])for(const r of a.rows)verify(a.root,[...r.prefix,...r.actions.map(x=>x.action)],r.end);
for(const r of [...f.results,...resumes.map(readZ)])verify(r.root,r.actions.map(x=>x.action),r.end,r.terminal);
const proof={inputs,r3:d.rows.length+t.rows.length,terminal:f.results.filter(x=>x.terminal).length+resumes.length,gate:f.results.filter(x=>!x.terminal).length};
console.log(JSON.stringify(proof));writeZ(out,proof);
