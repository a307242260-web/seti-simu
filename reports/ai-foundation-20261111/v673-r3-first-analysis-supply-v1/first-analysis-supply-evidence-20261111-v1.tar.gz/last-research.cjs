'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [prior,out]=process.argv.slice(2),d=readZ(prior),r=d.rows.find(r=>r.label==='cash / dlc_17.png / amiba / out / autonomous');
const i=r.actions.findIndex(x=>x.action.target.tileId==='orange3'),actions=r.actions.slice(0,i).map(x=>x.action),m=open(r.start);
let root,options;
try{
 actions.forEach(m.apply);root=m.save();options=m.menu().filter(a=>a.target.tileId?.startsWith('orange'));
 console.log(JSON.stringify({before:short(m),options:options.map(a=>a.target.tileId)}));
}finally{m.dispose();}
const cases=[];
function choose(h,tile,reward){
 h.act('choose_target',a=>a.target.tileId===tile);
 if(reward)h.act('choose_card',a=>a.summary===reward);
 h.cut('after-research');
}
for(const t of options.filter(a=>a.target.tileId!=='orange3')){
 cases.push([t.target.tileId+' / only tile',h=>choose(h,t.target.tileId)]);
 if(t.target.tileId==='orange1'){
  const m=open(root);
  try{
   m.apply(t);
   for(const a of m.menu().filter(a=>a.family==='choose_card')){
    cases.push(['orange1 / '+a.summary,h=>choose(h,'orange1',a.summary)]);
   }
  }finally{m.dispose();}
 }
}
const result=runCases(root,cases);
writeZ(out,{root,parent:{root:r.start,actions},...result});
