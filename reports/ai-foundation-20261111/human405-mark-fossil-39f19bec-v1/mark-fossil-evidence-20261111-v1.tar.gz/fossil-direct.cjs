'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,short,readZ,writeZ}=require('./controlled-r3');
const load=p=>require(path.resolve(p)),solar=load('randomizer/solar-system/core'),rocket=load('randomizer/game/abilities/rocket'),rockets=load('randomizer/game/rockets'),trade=load('randomizer/game/actions/quick-trades');
const effects=load('randomizer/game/cards/effects'),chong=load('randomizer/game/aliens/chong');
const [input,out]=process.argv.slice(2),rows=[];
function paidRoute(s,p,ship,dest){
 const start=rockets.getRocketSectorCoordinate(ship),key=p=>p.x+':'+p.y;
 const seen=new Set([key(start)]),queue=[{at:start,steps:[]}],move=rockets.createStaticCoordinateMoveQuery(s.pieces,ship.id);
 for(const {at,steps} of queue){
  if(key(at)===key(dest))return steps;
  if(steps.length>=5||rocket.getRequiredMovePointsFromCoordinate(s,p,at)!==1)continue;
  for(const d of rocket.MOVE_DIRECTIONS){
   const v=move(at,d.deltaX,d.deltaY);
   if(!v.ok||seen.has(key(v.to)))continue;
   seen.add(key(v.to));queue.push({at:v.to,steps:[...steps,d]});
  }
 }
 return null;
}
for(const row of readZ(input).results.filter(r=>r.label==='fossil01')){
 const m=open(row.root),accepted=[];let stop,cp;
 try{
  const append=(action,kind,diag={})=>accepted.push({action:m.apply(action),kind,...diag});
  for(const t of row.rows){
   if(!t.controlled&&!t.passive)break;
   append(t.action,t.controlled?'setup':'passive');
  }
  const first=m.save(),s=m.state(),p=m.player(),job=Object.values(s.aliens.chong.transportTasksByRocketId)[0],ship=m.facts().probes.find(r=>r.fossilId===job.fossilId),dest=solar.collectPlanetLocations(s.solarSystem).find(q=>q.planetId===job.destinationPlanetId);
  const path=paidRoute(s,p,ship,dest),pricing={distance:path?.length??null,energy:p.resources.energy,credits:p.resources.credits,
   observers:p.reservedCards.flatMap(c=>effects.getCardModel(c)?.triggers?.map(t=>[c.cardId,t.id])||[])};
  console.log(JSON.stringify({card:row.card,pricing,from:rockets.getRocketSectorCoordinate(ship),to:[dest.x,dest.y],task:chong.getCardTask(p.reservedCards.find(c=>c.id===job.cardId))}));
  assert(path?.length,'No single-turn one-point path within five steps');
  const exchange=trade.getTradeAction('credits-for-energy'),need=Math.max(0,path.length-p.resources.energy);
  assert(need<=2&&p.resources.credits>=need*exchange.cost.credits);
  for(let i=0;i<need;i++)append(m.menu().find(a=>a.target?.tradeId===exchange.id),'return');
  for(const step of path){
   const q=m.menu().find(a=>a.family==='move'&&a.target.rocketId===ship.id&&a.target.deltaX===step.deltaX&&a.target.deltaY===step.deltaY);
   assert(q&&q.payload.requiredMovePoints===1);
   append(q,'return');append(m.menu().find(a=>a.family==='choose_payment'&&a.payload.energyCost===1),'return');
  }
  const claim=m.menu().find(a=>a.family==='complete_task'&&a.target.cardInstanceId===job.cardId);
  assert(claim,m.menu().map(a=>a.summary).join(' | '));append(claim,'return');
  const at=m.save(),after=short(m);
  for(let i=0;i<190;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!=='player-white'){
    const forced=[];m.advanceOpponents(forced);accepted.push(...forced.map(action=>({action,kind:'passive'})));continue;
   }
   const q=m.automatic(cp);
   if(!q.a||!q.complete||q.n>256||q.ms>600){stop={kind:'gate',a:q.a?.summary,n:q.n,ms:q.ms,complete:q.complete};break;}
   cp=q.checkpoint;append(q.a,'auto',{n:q.n,ms:q.ms});
  }
  assert(stop);
  const end=m.save(),score=stop==='terminal'?m.state().match.finalScores.find(p=>p.playerId==='player-white'):null;
  m.restore(row.root);accepted.forEach(r=>m.apply(r.action));assert.deepEqual(m.save(),end);
  rows.push({card:row.card,root:row.root,first,path,pricing,after,at,accepted,stop,end,score});
  console.log(JSON.stringify({card:row.card,stop,score:score?.totalScore,after:after.wallet,peak:[Math.max(...accepted.map(x=>x.n||0)),Math.max(...accepted.map(x=>x.ms||0))]}));
 }finally{m.dispose();}
}
writeZ(out,{rows});
