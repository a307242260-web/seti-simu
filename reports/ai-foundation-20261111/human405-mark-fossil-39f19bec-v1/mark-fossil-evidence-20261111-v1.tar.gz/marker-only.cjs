'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const {open,short,writeZ}=require('./controlled-r3');
const [file,out]=process.argv.slice(2),r=JSON.parse(fs.readFileSync(file)),d=fs.readFileSync(file+'.decisions.jsonl','utf8').trim().split('\n').map(JSON.parse),offset=r.steps-d.length;
const start=JSON.parse(fs.readFileSync(r.roundEnds[1].checkpointPath)).coreState.compositionEnvelope;
const expected=JSON.parse(fs.readFileSync(r.roundEnds[2].checkpointPath)).coreState.compositionEnvelope;
const first=r.roundEnds[1].beforeInput,last=r.roundEnds[2].beforeInput,rows=[];
for(const step of [null,156,178]){
 const m=open(start),accepted=[];let failure=null,split;
 try{
  for(let i=first;i<last;i++){
   const t=d[i-1-offset],menu=m.menu();
   const native=menu.find(q=>q.actionId===t.actionId);
   const a=i===step?menu.find(q=>q.summary==='标记 C'):native;
   if(!a){failure={at:i,expected:t.actionId,summary:t.context.legalActions.find(a=>a.actionId===t.actionId)?.summary,menu:menu.map(a=>a.summary)};break;}
   if(i===step){assert(native&&a.actionId!==native.actionId);split=m.save();}
   accepted.push(m.apply(a));
  }
  const end=m.save(),summary=short(m);
  if(step===null){assert(!failure);assert.deepEqual(end,expected);}
  const marks=m.state().finalScoring,slots=Object.values(marks.tiles).map(t=>[t.id??t.tileId,t.marks?.filter(a=>a.playerId==='player-white')]);
  console.log(JSON.stringify({step,last,failure,summary,slots}));
  rows.push({step,start,accepted,split,end,failure,summary,slots});
 }finally{m.dispose();}
}
writeZ(out,{source:r.gitCommit,first,last,rows});
