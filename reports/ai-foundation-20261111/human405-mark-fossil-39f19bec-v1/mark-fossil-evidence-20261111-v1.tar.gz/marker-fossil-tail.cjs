'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [markers,pink,out,mode]=process.argv.slice(2),outward=mode==='outward';
const native=require(require('node:path').resolve('randomizer/game/production-kernel'));
const a=readZ(markers),b=readZ(pink),roots=a.rows.filter(r=>outward||r.step).map(r=>({label:r.step?'C'+r.step:'standard',e:r.end}));
const fossil=b.samples['虫'].rows.find(r=>r.label==='reveal').settled;
if(!outward)roots.push({label:'fossil01',e:fossil.state});
const results=[];
for(const {label,e} of roots)for(const card of ['b_111.webp','b_32.webp']){
 const m=open(e),rows=[],turns=[];
 try{
  rows.push({action:m.act('pass'),controlled:true},{action:m.act('choose_card',a=>a.summary===card),controlled:true});
  const at=m.save(),opening=short(m);
  let stop,cp;
  for(let i=0;i<220;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!=='player-white'){
    const forced=[];m.advanceOpponents(forced);rows.push(...forced.map(action=>({action,passive:true})));continue;
   }
   if(outward&&!turns.length&&rows.filter(r=>r.controlled).length===2){
    const route=native.getProbeRouteRequirements(m.state(),'player-white').candidates.find(c=>c.planetId==='saturn'&&c.endpointFamily==='land'&&c.endpointTarget.type==='planet');
    assert(route);const step=route.path[0];assert(step.deltaX===0&&step.deltaY===1);
    rows.push({action:m.act('move',a=>a.target.rocketId===route.rocketId&&a.target.deltaX===step.deltaX&&a.target.deltaY===step.deltaY),controlled:true});
    rows.push({action:m.act('choose_payment',a=>a.payload.energyCost===1),controlled:true});
    continue;
   }
   const q=m.automatic(cp);
   if(!q.a||!q.complete||q.n>256||q.ms>600){
    stop={kind:'gate',action:q.a?.summary,n:q.n,ms:q.ms,complete:q.complete};break;
   }
   if(!cp||q.a.phase==='main'||q.a.family==='pass')turns.push({action:q.a,assets:short(m),n:q.n,ms:q.ms});
   cp=q.checkpoint;rows.push({action:m.apply(q.a),n:q.n,ms:q.ms});
  }
  assert(stop);
  const end=m.save(),terminal=stop==='terminal'?m.state().match.finalScores.find(p=>p.playerId==='player-white'):null;
  const peak=[Math.max(0,...rows.map(r=>r.n||0)),Math.max(0,...rows.map(r=>r.ms||0))];
  m.restore(e);rows.forEach(r=>m.apply(r.action));assert.deepEqual(m.save(),end);
  results.push({label,card,root:e,at,opening,stop,terminal,peak,end,rows,turns});
  console.log(JSON.stringify({label,card,stop,score:terminal?.totalScore,breakdown:terminal&&[terminal.baseScore,terminal.tileScore,terminal.cardScore],peak,inputs:rows.length}));
 }finally{m.dispose();}
}
writeZ(out,{results});
