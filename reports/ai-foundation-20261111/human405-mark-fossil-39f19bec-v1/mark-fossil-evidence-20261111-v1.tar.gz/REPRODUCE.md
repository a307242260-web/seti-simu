Run from the repository root with Node 22 at report parent 5218b2f0e (AI source 39f19bec). Use fresh temporary outputs; do not overlap timed probes.

```sh
proof=/path/to/this/archive
out=$(mktemp -d)
titan=reports/ai-foundation-20261111/v666-titan-funding-v1/titan-funding-native-20261111-v1.tar.gz
reuses=reports/ai-foundation-20261111/human405-retention-search-39f19bec-v1/retention-search-evidence-20261111-v1.tar.gz
report=reports/research/98e52daa.39f19bec.quick-400.json
tar -xOf "$titan" ./pink-worlds-20261111-v1.json.gz > "$out/pink.json.gz"
mkdir "$out/reuses"
tar -xzf "$reuses" -C "$out/reuses" ./reuse-yellow2.cjs ./reuse-scan.cjs ./prior.cjs
node "$proof/marker-only.cjs" "$report" "$out/mark-only.json.gz"
node "$proof/marker-fossil-tail.cjs" "$out/mark-only.json.gz" "$out/pink.json.gz" "$out/tails.json.gz"
node "$proof/marker-fossil-tail.cjs" "$out/mark-only.json.gz" "$out/pink.json.gz" "$out/outward.json.gz" outward
node "$proof/fossil-direct.cjs" "$out/tails.json.gz" "$out/direct.json.gz"
node "$proof/fossil-credit-candidate.cjs" "$out/direct.json.gz" "$out/candidate.json.gz"
node "$proof/fossil-credit-candidate.cjs" "$out/direct.json.gz" "$out/exact.json.gz" "$out/reuses"
```

The marker-only experiment forces the historical legal R3 actions except for the named marker. The R4 tails force PASS/keep-card and, in the outward group, the first move and its payment. The fossil-direct experiment fixes a one-exchange delivery and task claim before returning to AI. Autonomous inputs are only submitted inside both gates; the compiled credit candidate is never submitted. The standard no-move terminal pair is already recorded by the preceding same-source evidence and is not rerun.
