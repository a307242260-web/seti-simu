'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {open,readZ,writeZ}=require('./controlled-r3');
const [input,out,exact]=process.argv.slice(2),src=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(src,module);
mod.filename=src;mod.paths=Module._nodeModulePaths(path.dirname(src));
let code=fs.readFileSync(src,'utf8');
function sub(from,to){assert.equal(code.split(from).length,2,from);code=code.replace(from,to);}
sub('          const input = operation.cargoInput ?? 0;',`          const raw = operation.cargoInput ?? 0;
          const input = raw - Number(Boolean(goal.creditTopUp));
          if(input<0){
            const a=find(a=>a.family==="quick_trade"&&a.target.tradeId==="credits-for-energy");
            return a?{...fixed(a,"fund-final-earth-shipment-step"),cargoInput:raw+1}
              :{kind:"infeasible",reason:"funded-earth-shipment-top-up-unavailable"};
          }`);
sub('cargoInput:input+1}', 'cargoInput:raw+1}');
sub(`      const path = from && earth && shortEarthPath(state, p, ship, from, earth, Math.min(3, p.resources.energy));
      if (!path?.length) return null;`,`      let path=from&&earth&&shortEarthPath(state,p,ship,from,earth,Math.min(3,p.resources.energy));
      if(!path?.length&&from&&earth&&p.resources.energy===3&&p.resources.credits>=2){
        const topUp=node.legalActions.find(a=>a.family==="quick_trade"&&a.target.tradeId==="credits-for-energy");
        const card=p.reservedCards.find(c=>c.id===job.cardId),task=chong.getCardTask(card);
        // Diagnostic: no extra main action, card or unknown identity can pay.
        if(topUp&&task?.kind==="transport"&&task.destinationPlanetId==="earth"&&task.gain?.score>0){
          const extended=shortEarthPath(state,p,ship,from,earth,4);
          if(extended?.length===4)return {action:topUp,quote:{kind:"funded-earth-shipment",directEnergy:true,
            creditTopUp:true,path:extended,cardId:job.cardId}};
        }
      }
      if(!path?.length)return null;`);
if(exact)code=require(exact+"/reuse-yellow2.cjs")(require(exact+"/reuse-scan.cjs")(code,require(exact+"/prior.cjs")));
mod._compile(code,src);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const rows=[];
for(const row of readZ(input).rows){
 const m=open(row.first),seatId='player-white',port=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
 try{
  const original=m.automatic(),q=createSearchAgent({analysisPort:port,seatId}).decide({seatId,legalActions:m.menu()}).search;
  assert.deepEqual(m.save(),row.first);
  const label=id=>m.menu().find(a=>a.actionId===id)?.summary;
  const root=q.lines[0].edges.find(e=>e.resourcePlan?.goal.creditTopUp===true);
  assert(root?.resourcePlan&&root.goalStatus==='completed');
  const originalRoots=new Map(original.roots.map(r=>[r.actionId,r.value]));
  const summary={card:row.card,original:original.a.summary,originalValue:original.value,choice:label(q.actionId),value:q.value,
    routeValue:q.lines.find(l=>l.node===root.target).value,complete:q.complete&&!q.unresolved.length,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,
    otherQuotes:q.roots.filter(r=>r.actionId!==root.actionId&&originalRoots.get(r.actionId)!==r.value).map(r=>[label(r.actionId),originalRoots.get(r.actionId),r.value])};
  const actions=[];for(const id of root.steps){const a=m.menu().find(x=>x.actionId===id);assert(a,id);actions.push(m.apply(a));}
  assert.deepEqual(m.save(),row.at);
  assert.deepEqual(actions.map(a=>a.actionId),row.accepted.filter(x=>x.kind==='return').map(x=>x.action.actionId));
  rows.push({summary,root:row.first,q,actions,end:m.save()});
  console.log(JSON.stringify(summary));
 }finally{port.close();m.dispose();}
}
writeZ(out,{rows});
