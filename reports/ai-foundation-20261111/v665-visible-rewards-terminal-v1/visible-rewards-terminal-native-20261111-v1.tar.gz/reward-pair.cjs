'use strict';

const assert = require('node:assert/strict');
const { open, readZ, runCases, writeZ } = require('./controlled-r3');
const [source, out] = process.argv.slice(2);
const steps = new Map(readZ(source).rows.map(row => [row.i, row]));
const root = steps.get(190).before;
const cases = [];

function original(h, first, last) {
  for (let i = first; i <= last; i++) {
    const action = steps.get(i).a;
    h.take(h.m.apply(action));
  }
}

function fixedFirstReward(h, blueSlot, publicCard) {
  h.act('choose_target', action => action.target.speciesId === 'amiba' && action.target.position === blueSlot);
  original(h, 191, 208);
  h.take(h.m.pick(publicCard));
  original(h, 210, 220);
}

function fixedResearch(h) {
  const passive = [];
  h.act('end_turn');
  h.m.advanceOpponents(passive);
  h.take(...passive);
  h.take(h.m.corner('b_16.webp'));
  h.take(h.m.corner('amiba_9.webp'));
  h.act('research_tech');
  h.act('choose_target', action => action.target.tileId === 'blue1' && action.target.blueSlot === 3);
}

const machine = open(root);
try {
  for (const blueSlot of [3, 4]) {
    for (const publicCard of ['dlc_20.png', 'dlc_25.png']) {
      machine.restore(root);
      const action = (family, predicate) => machine.act(family, predicate);
      fixedFirstReward({ m: machine, act: action, take: () => {} }, blueSlot, publicCard);
      const options = machine.menu();
      assert.equal(options.length, 3);
      for (const reward of options) {
        for (const after of ['auto', 'held publicity to blue1']) {
          if (blueSlot === 4 && publicCard === 'dlc_25.png' && reward.summary === 'dlc_20.png' && after === 'auto') continue;
          const label = [blueSlot, publicCard, reward.summary, after].join(' / ');
          cases.push([label, h => {
            fixedFirstReward(h, blueSlot, publicCard);
            h.take(h.m.apply(reward));
            h.cut('orange1-reward');
            if (after !== 'auto') fixedResearch(h);
          }]);
        }
      }
    }
  }
} finally {
  machine.dispose();
}
writeZ(out, { root, ...runCases(root, cases) });
