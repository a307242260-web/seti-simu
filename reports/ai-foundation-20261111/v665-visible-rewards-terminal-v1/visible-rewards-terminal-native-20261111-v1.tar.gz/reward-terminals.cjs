'use strict';
const assert=require('node:assert/strict'),crypto=require('node:crypto');
const {open,readZ,writeZ,short}=require('./controlled-r3');
const [rewardSource,officialSource,out]=process.argv.slice(2);
const reward=readZ(rewardSource);
const official=readZ(officialSource);
const root=official.rows.find(r=>r.i===258).before;
const seats=['b_111.webp','b_32.webp'];
const picked=reward.rows.filter(row=>row.label.endsWith(' / auto')&&
 (row.settled?.summary.wallet[0]===118||row.label.includes(' / dlc_25.png / dlc_16.png / ')));
const sources=[{label:'official',settled:{state:root}},...picked];
const cases=[],duplicates=[],seen=new Map();
for(const row of sources)for(const keep of seats){
 const m=open(row.settled.state),steps=[],label=row.label+' / '+keep;
 try{
  steps.push(m.act('pass'));
  steps.push(m.act('choose_card',a=>a.target.cardId===keep));
  m.advanceOpponents(steps);
  const start=m.save();
  assert.equal(m.facts().round,4);
  assert(!start.session);
  const key=crypto.createHash('sha256').update(JSON.stringify(start)).digest('hex');
  if(seen.has(key)){
   duplicates.push({label,earlier:seen.get(key),key,round3:row.settled.state,steps});
   continue;
  }
  seen.set(key,label);
  if(row.label==='official'){
   duplicates.push({label,earlier:'V665 existing 239/253 controls',key,round3:row.settled.state,steps});
   continue;
  }
  cases.push({label,r4:{start:{env:start,summary:short(m)}},round3:row.settled.state,steps});
 }finally{m.dispose();}
}
writeZ(out,{cases,duplicates});
console.log(JSON.stringify({cases:cases.map(r=>r.label),duplicates:duplicates.map(r=>[r.label,r.earlier])}));
