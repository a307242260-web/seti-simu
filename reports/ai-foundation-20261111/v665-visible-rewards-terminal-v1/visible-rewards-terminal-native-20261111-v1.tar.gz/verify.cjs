'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,short}=require('./controlled-r3');
const repo=path.resolve(process.argv[2]||'.');
const record=require(path.join(repo,'reports/research/926c5bc2.9a1cafee.quick-400.json'));
const save=require(path.join(repo,record.savePath));
const checkpoint=require(path.join(repo,record.roundEnds[1].checkpointPath));
const load=name=>readZ(path.join(__dirname,name+'-20261111-v1.json.gz'));
const totals={official:0,r3Branches:0,continuedGames:0,replayed:0,peakNative:0,peakMs:0};
function apply(m,a){
 const action=a.action||a.a||a;
 if(a.n!==undefined){
  assert(a.n<=256&&a.ms<=600);
  totals.peakNative=Math.max(totals.peakNative,a.n);
  totals.peakMs=Math.max(totals.peakMs,a.ms);
 }
 m.apply(action);
 totals.replayed+=1;
}
const origins={};
const official=open(checkpoint.coreState.compositionEnvelope);
try {
 for(const {stepIndex,action} of save.replaySteps.slice(checkpoint.replayCursor.stepIndex)){
  if([190,221,235,236,240,258].includes(stepIndex+1))origins[stepIndex+1]=official.save();
  official.apply(action);totals.official+=1;
 }
 assert.equal(official.save().committedState,save.committedState);
 assert.deepEqual(official.save().session,save.session);
} finally {official.dispose();}

const keep=load('current-keep');
const base=open(origins[236]);
try{
 const proof=base.automatic();
 assert(proof.complete&&proof.n<=256&&proof.ms<=600);
 for(const [label,group] of Object.entries(keep)){
  const m=open(group.origin);
  try {
   if(!group.hidden)assert.deepEqual(group.origin,origins[label.endsWith('/240')?240:236]);
   else{
    m.restore(group.hidden.start);apply(m,group.hidden.action);
    assert.deepEqual(m.save(),group.origin);
    assert.deepEqual(m.owner('player-white'),base.owner('player-white'));
    assert.deepEqual(m.menu(),base.menu());
    assert.deepEqual(m.facts().rng,base.facts().rng);
    const q=m.automatic();
    for(const field of ['a','complete','n','roots','value'])assert.deepEqual(q[field],proof[field]);
   }
   for(const row of group.rows){
    m.restore(group.origin);row.prefix.forEach(a=>apply(m,a));
    assert.deepEqual(m.save(),row.start);
    for(const a of row.actions){
     if(a.action.family==='pass'&&a.action.actorId==='player-white')assert.deepEqual(m.save(),row.settled.state);
     apply(m,a);
    }
    assert.deepEqual(m.save(),row.end);
    totals.r3Branches+=1;
   }
  } finally {m.dispose();}
 }
} finally {base.dispose();}

const reward=load('reward-pair');
assert.deepEqual(reward.root,origins[190]);
assert.equal(reward.failures.length,0);
for(const row of reward.rows){
 const m=open(reward.root);
 try{
  row.prefix.forEach(a=>apply(m,a));
  assert.deepEqual(m.save(),row.start);
  for(const a of row.actions){
   if(a.action.family==='pass'&&a.action.actorId==='player-white')assert.deepEqual(m.save(),row.settled.state);
   apply(m,a);
  }
  assert.deepEqual(m.save(),row.end);
  totals.r3Branches+=1;
 } finally{m.dispose();}
}

const current=load('current-handoffs');
const rewardHandoffs=load('reward-terminals-handoffs');
for(const row of [...current.cases,...current.duplicates,...rewardHandoffs.cases]){
 const origin=row.root||row.round3,m=open(origin);
 try {
  if(row.root)assert.deepEqual(origin,keep[row.name].rows.find(r=>r.label===row.card).settled.state);
  else assert.deepEqual(origin,reward.rows.find(r=>row.label.startsWith(r.label+' / ')).settled.state);
  row.steps.forEach(a=>apply(m,a));
  assert.deepEqual(m.save(),row.r4.start.env);
 } finally{m.dispose();}
}

for(const [name,group] of [['current-terminal',current],['reward-terminal',rewardHandoffs]]){
 for(const row of load(name)){
  assert.deepEqual(row.start,group.cases.find(r=>r.label===row.label).r4.start.env);
  const m=open(row.start);
  try{
   row.steps.forEach(a=>apply(m,a));
   assert.deepEqual(m.save(),row.end);
   assert.equal(row.stop,'terminal');
   assert(m.state().turn.gameEnded);
   assert.deepEqual(JSON.parse(JSON.stringify(short(m))),row.summary);
   totals.continuedGames+=1;
  } finally{m.dispose();}
 }
}
console.log(JSON.stringify(totals,null,2));
