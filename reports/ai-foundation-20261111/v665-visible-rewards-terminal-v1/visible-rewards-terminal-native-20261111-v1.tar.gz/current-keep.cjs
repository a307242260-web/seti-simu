'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,runCases,writeZ}=require('./controlled-r3');
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const [source,out]=process.argv.slice(2);
const rows=new Map(readZ(source).rows.map(row=>[row.i,row]));
const baseline=open(rows.get(236).before),groups={};
try {
 const proof=baseline.automatic();
 assert(proof.complete&&proof.n<=256&&proof.ms<=600);
 for(const name of ['original/236','original/240','ordinary','wages','amiba']){
  const official=rows.get(name==='original/240'?240:236);
  let origin=official.before,hidden=null;
  if(!name.startsWith('original')){
   const play=rows.get(235);
   const modified=structuredClone(play.before);
   const state=JSON.parse(modified.committedState);
   const [cards,i,j]=name==='amiba'?[state.aliens.amiba.cardDeck,0,1]:[state.cards.drawPileCardIds,...(name==='ordinary'?[1,3]:[2,5])];
   assert(cards[i]!==cards[j]&&cards[i]!=null&&cards[j]!=null);
   [cards[i],cards[j]]=[cards[j],cards[i]];
   modified.committedState=createStateStore(state).serialize().serialized;
   const machine=open(modified);
   try{
    machine.apply(play.a);origin=machine.save();
    assert.deepEqual(machine.owner('player-white'),baseline.owner('player-white'));
    assert.deepEqual(machine.menu(),baseline.menu());
    assert.deepEqual(machine.facts().rng,baseline.facts().rng);
    const q=machine.automatic();
    for(const field of ['a','complete','n','roots','value'])assert.deepEqual(q[field],proof[field]);
    hidden={start:modified,action:play.a};
   }finally{machine.dispose();}
  }
  const options=name.startsWith('original')?['dlc_16.png']:['dlc_17.png','dlc_16.png'];
  groups[name]={origin,hidden,...runCases(origin,options.map(card=>[card,h=>h.take(h.m.pick(card))]))};
 }
}finally{baseline.dispose();}
writeZ(out,groups);
