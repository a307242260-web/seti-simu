'use strict';
const assert=require('node:assert/strict'),crypto=require('node:crypto');
const {open,readZ,writeZ,short}=require('./controlled-r3');
const [source,out]=process.argv.slice(2),groups=readZ(source);
const cases=[],duplicates=[],seen=new Map();
function move(m,steps){
 steps.push(m.act('move',a=>a.target.deltaX===0&&a.target.deltaY===1));
 steps.push(m.act('choose_payment',a=>a.target?.resource==='energy'||a.summary.includes('能量')));
}
for(const [name,group] of Object.entries(groups))for(const row of group.rows){
 for(const keep of ['b_111.webp','b_32.webp'])for(const when of name.startsWith('original')?['auto','before-pass','after-income']:['auto']){
  const label=[name,row.label,keep,when].join(' / '),root=row.settled.state,steps=[],m=open(root);
  try {
   if(when==='before-pass')move(m,steps);
   steps.push(m.act('pass'));
   steps.push(m.act('choose_card',a=>a.target.cardId===keep));
   m.advanceOpponents(steps);
   assert.equal(m.facts().round,4);
   assert(!m.save().session);
   const opening=short(m);
   if(when==='after-income')move(m,steps);
   const start=m.save();
   const key=crypto.createHash('sha256').update(JSON.stringify(start)).digest('hex');
   const item={label,name,card:row.label,root,steps,opening,r4:{start:{env:start,summary:short(m)}}};
   if(seen.has(key)){
    duplicates.push({...item,earlier:seen.get(key)});
   }else{
    cases.push(item);seen.set(key,label);
   }
  }finally{m.dispose();}
 }
}
writeZ(out,{cases,duplicates});
