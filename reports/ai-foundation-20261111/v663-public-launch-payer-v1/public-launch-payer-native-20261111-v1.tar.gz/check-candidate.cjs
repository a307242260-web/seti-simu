'use strict';
const assert=require('node:assert/strict');
const path=require('node:path');
const {open,readZ,writeZ,runCases}=require('./controlled-r3');
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const [input,out,fixture]=process.argv.slice(2);
const d=readZ(input),origin=d.revealed.root;
const root=d.revealed.rows.find(r=>r.label==='after-amiba0-and-dlc9-resolution').start;
function hiddenOrder(envelope, decks){
 const state=JSON.parse(envelope.committedState);
 for(const deck of decks) [deck(state)[0],deck(state)[1]]=[deck(state)[1],deck(state)[0]];
 const encoded=createStateStore(state).serialize(state);
 assert(encoded.ok);
 return {...envelope,committedState:encoded.serialized};
}
const ordinary=s=>s.cards.drawPileCardIds,chong=s=>s.aliens.chong.cardDeck;
const bases=[
 ['revealed',root],
 ['ordinary-swapped',hiddenOrder(root,[ordinary])],
 ['chong-swapped',hiddenOrder(root,[chong])],
 ['both-swapped',hiddenOrder(root,[ordinary,chong])],
];
const runs={};
let expected;
for(const [name,e] of bases){
 const m=open(e);
 try {
  const observation=m.owner('player-white');
  const a=m.automatic();
  m.act('research_tech');
  const b=m.automatic();
  const fields=[observation,a.a,a.value,a.roots,a.n,b.a,b.value,b.roots,b.n];
  if(expected)assert.deepEqual(fields,expected);
  else expected=fields;
  assert(a.complete&&a.n<=256&&a.ms<=600);
  assert(b.complete&&b.n<=256&&b.ms<=600);
  assert.equal(b.a.target.tileId,'orange1');
  runs[name]={research:{a:a.a,value:a.value,roots:a.roots,n:a.n,ms:a.ms},tile:{a:b.a,value:b.value,roots:b.roots,n:b.n,ms:b.ms},
   ...runCases(e,[[name,()=>{}]])};
  assert.equal(runs[name].rows[0].stop,'r4-first-white-main');
 } finally {m.dispose();}
}
const earlier={root:origin,...runCases(origin,[['immediate-public-reveal',()=>{}]])};
assert.equal(earlier.rows[0].stop,'r4-first-white-main');
writeZ(out,{root,runs,earlier});
if(fixture)writeZ(fixture,{root});
