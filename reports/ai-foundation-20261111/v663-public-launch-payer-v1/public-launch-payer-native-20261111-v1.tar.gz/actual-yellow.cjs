'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,short,readZ,writeZ,runCases}=require('./controlled-r3');
const [current,controls,out]=process.argv.slice(2),a=readZ(current),b=readZ(controls);
const roots={},comparisons={};
for(const [name,run] of Object.entries(a.runs)){
 const origin=run.rows[0].start,m=open(origin);
 try{
  for(const {action} of run.rows[0].actions){
   if(action.target?.kind==='planet-reward-alien-trace'&&action.target.traceType==='yellow')break;
   m.apply(action);
  }
  const r=m.automatic();
  const menu=m.menu();
  const amiba=menu.find(x=>x.target.alienSlotId===1&&x.target.position===4);
  const state=m.save();
  roots[name]={state,summary:short(m),amiba,ai:r.a,value:r.value,candidates:r.roots,peak:[r.n,r.ms]};
  assert(r.complete&&r.n<=256&&r.ms<=600);
  comparisons[name]={...runCases(state,[
   ['amiba-yellow4-only-fixed',h=>h.take(h.m.apply(amiba))],
  ])};
 }finally{m.dispose();}
}
const previous=b.revealed.rows.find(r=>r.label==='after-amiba0-and-dlc9-resolution').settled.state;
const finalRoots=[
 ['v663-blue1-no-transport',previous],
 ['candidate-chong-yellow4',a.runs.revealed.rows[0].settled.state],
 ...Object.entries(comparisons).map(([name,run])=>[name+'-amiba-yellow4',run.rows[0].settled?.state]),
];
const final=[];
for(const [name,root] of finalRoots.filter(x=>x[1])) {
 const m=open(root),actions=[];
 try{
  const retain=m.menu();
  actions.push({action:m.act('pass')});
  const choice=m.menu().find(x=>x.summary==='b_111.webp');
  if(!choice){final.push({name,root,stop:'B111 unavailable',options:m.menu().map(x=>x.summary)});continue;}
  actions.push({action:m.apply(choice)});
  let stop,cp;
  for(let i=0;i<180;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!=='player-white'){
    const a=[];m.advanceOpponents(a);actions.push(...a.map(action=>({action,passive:true})));continue;
   }
   const q=m.automatic(cp);
   if(!q.a||!q.complete||q.n>256||q.ms>600){stop={kind:'gate',n:q.n,ms:q.ms,a:q.a?.summary,turn:m.facts().turn};break;}
   cp=q.checkpoint;
   actions.push({action:m.apply(q.a),n:q.n,ms:q.ms,value:q.value});
  }
  assert(stop);
  const end=m.save(),peak=[Math.max(...actions.map(a=>a.n||0)),Math.max(...actions.map(a=>a.ms||0))];
  const terminal=stop==='terminal'?m.state().match.finalScores.find(x=>x.playerId==='player-white'):null;
  console.log('R4',JSON.stringify([name,stop,terminal?.totalScore,peak]));
  m.restore(root);actions.forEach(a=>m.apply(a.action));assert.deepEqual(m.save(),end);
  final.push({name,root,end,actions,stop,peak,terminal});
 }finally{m.dispose();}
}
for(const [name,x] of Object.entries(roots)){
 console.log('TRACE',JSON.stringify([name,x.summary,x.ai.summary,x.value,x.candidates.filter(r=>r.actionId===x.amiba.actionId)]));
}
writeZ(out,{roots,comparisons,final});
