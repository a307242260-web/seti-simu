'use strict';
const assert = require('node:assert/strict');
const path = require('node:path');
const {open, readZ, writeZ, runCases, short} = require('./controlled-r3');
const [archive, out] = process.argv.slice(2);
const load = name => readZ(path.join(archive, name + '-20261111-v1.json.gz'));
const ledger = load('funding-ledger');
const source = Object.entries(ledger).find(([name]) => name.startsWith('dlc_20.png'))[1];
const fixedReveal = source.slice(0, 6).map(row => row.a);
const afterReveal = source[6].e;
const research = load('reverse-research')['dlc_20.png'];
const reverse = research.rows.find(row => row.label === 'orange1-first-but-spend-amiba9');
const yellow = readZ(path.join(archive, 'yellow-options-20261111-v1-dlc_20.png.json.gz'));
const step = reverse.actions.findIndex(({action}) => action.target?.traceType === 'yellow' && action.target.kind === 'planet-reward-alien-trace');
assert(step > 0);
const fixedOrangeAndLanding = [...reverse.prefix, ...reverse.actions.slice(0, step).map(row => row.action)];
const m = open(source[0].e);
let afterResolvedReveal, yellowRoot;
try {
 fixedReveal.forEach(m.apply);
 assert.deepEqual(m.save(), afterReveal);
 source.slice(6, 9).forEach(row => m.apply(row.a));
 afterResolvedReveal = m.save();
 assert.deepEqual(afterResolvedReveal, research.root);
 fixedOrangeAndLanding.forEach(m.apply);
 yellowRoot = m.save();
 const normalizeSessionId = envelope => JSON.stringify(envelope).replace(/effect-session-\d+/g, 'effect-session-ID');
 assert.deepEqual(JSON.parse(normalizeSessionId(yellowRoot)), JSON.parse(normalizeSessionId(yellow.root)));
} finally {
 m.dispose();
}
function run(root, cases) {
 return {root, ...runCases(root, cases)};
}
const results = {};
results.revealed = run(afterReveal, [
 ['immediately-after-chong-reveal', () => {}],
 ['after-amiba0-and-dlc9-resolution', h => source.slice(6, 9).forEach(row => h.take(h.m.apply(row.a)))],
 ['after-fixed-orange1', h => {
  source.slice(6, 9).forEach(row => h.take(h.m.apply(row.a)));
  const endTurn = fixedOrangeAndLanding.findIndex(action => action.family === 'end_turn');
  assert(endTurn > 0);
  fixedOrangeAndLanding.slice(0, endTurn + 1).forEach(a => h.take(h.m.apply(a)));
 }],
 ['autonomous-yellow-trace', h => {
  source.slice(6, 9).forEach(row => h.take(h.m.apply(row.a)));
  fixedOrangeAndLanding.forEach(a => h.take(h.m.apply(a)));
 }],
]);
results.yellow = run(yellowRoot, yellow.rows.filter(row => /黄[34]号位/.test(row.label)).map(row => [
 row.label, h => row.prefix.forEach(a => h.take(h.m.apply(a))),
]));
const probe = open(afterResolvedReveal);
try {
 const q = probe.automatic();
 const key = fixedOrangeAndLanding[0].family;
 results.researchMenu = {before:short(probe),chosen:q.a,roots:q.roots,menu:probe.menu(),n:q.n,ms:q.ms,complete:q.complete,forcedFamily:key};
 for (const action of fixedOrangeAndLanding.slice(0, 5)) {
  const selected = probe.automatic();
  console.log('ORANGE',JSON.stringify([action.family,action.summary,selected.a?.summary,selected.value,selected.n,selected.ms,selected.complete,short(probe), selected.roots.map(r=>[r.actionId,r.value])]));
  probe.apply(action);
 }
} finally {
 probe.dispose();
}
writeZ(out,{sourceRoot:source[0].e,fixedReveal,fixedOrangeAndLanding,...results});
