'use strict';
const {open,readZ,writeZ,short}=require('./controlled-r3');
const [input,out]=process.argv.slice(2),d=readZ(input),rows=[];
for(const r of d.final){
 const m=open(r.root);
 try {
  for(const {action} of r.actions.slice(0,4))m.apply(action);
  const q=m.automatic();
  const row={name:r.name,before:m.save(),summary:short(m),a:q.a,value:q.value,n:q.n,ms:q.ms,complete:q.complete,roots:q.roots};
  console.log(JSON.stringify([r.name,row.summary,row.a?.summary,row.value,row.n,row.ms]));
  rows.push(row);
 }finally{m.dispose();}
}
writeZ(out,rows);
