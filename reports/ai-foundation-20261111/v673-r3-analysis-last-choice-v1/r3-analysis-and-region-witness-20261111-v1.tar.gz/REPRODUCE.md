本次仅登记证据，Production 策略仍为 433765e936e26b6a25c8b599f580792471e3445b。A 指向解包目录；在该源码根目录执行：

    OPT="$(cat "$A/mode")-turn-copy-card-screen-data-screen"
    SETI_SCAN_PRIOR="$A/prior.cjs" node "$A/cold-root.cjs" "$OPT-region-draw-draw-proof" "$A/root-b_111.webp.gz" "$A/replay-b_111.webp.json.gz"
    node "$A/prove-region.cjs" "$A" "$A/replay-b_111.webp.json.gz"
    node "$A/verify-graphs.cjs" "$A" "$A"
    node "$A/analysis-tail-controls.cjs" "$A/r3-analysis-fork-20261111-v1.json.gz" "$A/replay-r3-20261111-v1.json.gz"

B32 换根和文件名。两套冷根照旧使用同一隔离候选，region-draw 是相对变化。第 243 步既有正式存档的四个痕迹与阿米巴展示／盲抽／取消，合计六条受控后缀、78个原生输入，全部独立复放完整信封；只有原先选展示阿米巴 2 能补第三轮第四格永久电，仍为 118、6 科技和 7钱／4电。其他留牌结果 114–116、7钱／3电；未启动第四轮搜索。根查询11次、71.887ms，实际报价 192.5 优于其他三个 186.5／189.5／186.5。盲抽变体只代表原暗牌顺序。

第四轮隔离候选采用正式区域结算、真实抽牌和原任务菜单，保留更新后的 hidden_card_draw 边界；不添加任何后续分支。30条逐边对照原生信封、RNG、效果队列和菜单。换普通和阿米巴暗牌顶位后首选、图、估值、输入数相同；完整证书仅在同一原生世界比较，跨世界核对动作和公开计划行，因原生恢复键本应随隐藏物理状态改变。原生执行149/159降至135/143，但无插桩冷测612.014/622.526毫秒，未通过600ms；减拷贝等配套变体也没有过线，不进入 Production。隔离源码八项 Node 回归及 V 输入审计通过。没有新整局、标准前三轮或终局分数，实验中心记录不变。
