'use strict';

const assert = require('node:assert/strict');
const path = require('node:path');
const {open, readZ, writeZ, runCases, short} = require('./controlled-r3');
const {getProbeRouteRequirements} = require(path.resolve('randomizer/game/production-kernel'));
const cards = require(path.resolve('randomizer/game/cards/deck'));
const [source, out] = process.argv.slice(2);
const worlds = readZ(source);
const original = worlds.samples[worlds.assignment].rows.find(row => row.label === 'reveal');
const root = (() => {
 const m = open(original.start);
 try { original.actions.slice(0,7).forEach(x => m.apply(x.action)); return m.save(); }
 finally { m.dispose(); }
})();
function place(h, slot) {
 h.act('place_data'); h.act('choose_target', a => slot ? a.target.blueSlot === slot : a.target.target === 'computer');
}
function move(h, step, card) {
 h.act('move', a => a.target.deltaX === step.deltaX && a.target.deltaY === step.deltaY);
 const pay = h.m.menu().find(a => card
   ? a.target.cardIds?.some(id => h.m.player().hand.some(c => c.id === id && c.cardId === card))
   : a.summary === '消耗 1 能量');
 assert(pay, `no move payment ${card}`); h.take(h.m.apply(pay));
}
function end(h) {
 h.act('end_turn'); const passive=[]; h.m.advanceOpponents(passive); h.take(...passive);
}
function tradeCredit(h, pair) {
 h.act('quick_trade', a => a.target.tradeId === 'cards-for-credit');
 for(const card of pair) h.act('choose_payment', a => a.target.select && a.summary === card);
 h.act('choose_payment', a => a.target.confirm);
}
function prep(h, first, mover, publication, tile) {
 if(first) move(h, first, mover);
 if(h.m.player().resources.publicity<6) h.take(h.m.corner(publication));
 h.act('research_tech'); h.act('choose_target', a=>a.target.tileId===tile&&(tile!=='blue1'||a.target.blueSlot===3));
 h.cut('after-tech');
 place(h); place(h);
 if(tile==='blue1') place(h,3);
 end(h);
 h.act('analyze');
 h.act('choose_target', a=>a.target.choiceId==='trace:2:blue:chong:9');
 h.act('choose_card', a=>a.target.source==='display'&&a.target.cardIndex===9);
 end(h);
 h.cut('after-analysis');
}
function fund(h, tile, protect) {
 const routes=getProbeRouteRequirements(h.m.state(),'player-white').candidates;
 const endpoint=tile==='orange4'?'titan':null;
 const goal=routes.find(g=>g.planetId==='saturn'&&g.endpointFamily==='land'&&(g.endpointTarget?.satelliteId||null)===endpoint);
 assert(goal, 'no Saturn route');
 const player=h.m.player(), {credits,energy}=player.resources;
 const needCredit=Math.max(0,2-credits), moves=goal.path.length, paidByEnergy=Math.min(energy,moves), needMovers=moves-paidByEnergy;
 const available=player.hand.filter(c=>c.cardId!=='chong_9.webp'&&(!protect||c.cardId!=='dlc_25.png'));
 const moveCards=available.filter(c=>cards.getDiscardActionMoveRewardForCard(c)).slice(0,needMovers);
 const moneyCards=available.filter(c=>!moveCards.includes(c)).slice(0,needCredit*2);
 assert(moveCards.length===needMovers&&moneyCards.length===needCredit*2,
  `Saturn ${moves} moves, needs ${needCredit} credit and ${needMovers} movement cards, holds ${available.map(c=>c.cardId).join(',')}`);
 while(moneyCards.length)tradeCredit(h,moneyCards.splice(0,2).map(c=>c.cardId));
 goal.path.forEach((step,i)=>move(h,step,moveCards[i]?.cardId));
 h.take(h.m.play('chong_9.webp'));
 h.act('choose_target', a=>a.target.planetId==='saturn'&&(a.target.landTarget?.satelliteId||null)===endpoint);
 h.cut('landed');
}
const cases=[];
const directions=[null,{deltaX:0,deltaY:1},{deltaX:0,deltaY:-1},{deltaX:1,deltaY:0},{deltaX:-1,deltaY:0}];
for(const tile of ['blue1','orange4'])for (const first of directions){
 const controls=first?['b_16.webp','amiba_9.webp']:['amiba_9.webp'];
 for(const pub of controls)cases.push([`${tile} / ${first?Object.values(first).join(','):'no move'} / ${pub}`,h=>{
   prep(h,first,'dlc_20.png',pub,tile); fund(h,tile,true);
 }]);
}
const results=runCases(root,cases);
writeZ(out,{root,results});
