'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const {open,readZ,short} = require('./controlled-r3');
const read = stem => readZ(path.join(__dirname, `${stem}-20261111-v1.json.gz`));
const json = file => JSON.parse(fs.readFileSync(file));
const official = read('official-roots');
const report = json(official.report);
assert.equal(report.gitCommit, official.gitCommit);
const saved = json(report.savePath);
const startRound = report.roundEnds[1];
const compare = new Map(official.rows.map(r => [r.i,r.before]));
compare.set(report.roundEnds[2].beforeInput,json(report.roundEnds[2].checkpointPath).coreState.compositionEnvelope);
const original = open(json(startRound.checkpointPath).coreState.compositionEnvelope);
let formalInputs = 0;
try {
 for (let i=startRound.beforeInput; i<=saved.replaySteps.length; i++) {
  if(compare.has(i)) assert.deepEqual(original.save(),compare.get(i));
  original.apply(saved.replaySteps[i-1].action); formalInputs++;
 }
 assert.equal(original.save().committedState,saved.committedState);
 assert.deepEqual(original.save().session,saved.session);
} finally { original.dispose(); }

let exact = 0, rejected = 0, replayed = 0, terminal = 0, largest = 0, slowest = 0;
function verifyGroup(root, group) {
 const m = open(root);
 try {
  for (const row of group.rows) {
   m.restore(root);
   row.prefix.forEach(a=>{m.apply(a);replayed++;});
   assert.deepEqual(m.save(),row.start);
   for (const {action,n,ms} of row.actions) {
    if (row.settled && action.actorId==='player-white' && action.family==='pass' && m.facts().round===3) {
     assert.deepEqual(m.save(),row.settled.state);
     assert.deepEqual(JSON.parse(JSON.stringify(short(m))),row.settled.summary);
    }
    if (n!==undefined) {
     assert(n<=256 && ms<=600);
     largest=Math.max(largest,n); slowest=Math.max(slowest,ms);
    }
    m.apply(action); replayed++;
   }
   assert.deepEqual(m.save(),row.end); exact++;
   if (row.stop.kind==='gate') assert(row.stop.n>256 || row.stop.ms>600);
  }
  for(const row of group.failures){
   m.restore(root);
   row.prefix.forEach(a=>{m.apply(a);replayed++;});
   assert.deepEqual(m.save(),row.checkpoint);
   rejected++;
  }
 } finally { m.dispose(); }
}
const funding=read('titan-funding'), worlds=read('pink-worlds');
const marks=read('titan-marks'), retain=read('titan-retain'), landed=read('landing-funds');
assert.deepEqual(funding.root,compare.get(227));
assert.deepEqual(worlds.samples[worlds.assignment].root,compare.get(214));
assert.deepEqual(marks.paidRoot,funding.rows[0].start);
assert.deepEqual(retain.incomeRoot,marks.paid.rows[0].start);
assert.deepEqual(retain.marksRoot,funding.rows[0].start);
verifyGroup(funding.root,funding);
for(const sample of Object.values(worlds.samples)) verifyGroup(sample.root,sample);
verifyGroup(marks.paidRoot,marks.paid);
verifyGroup(marks.chongRoot,marks.chong);
verifyGroup(retain.incomeRoot,retain.income);
verifyGroup(retain.marksRoot,retain.choices);
verifyGroup(landed.root,landed.results);
for(const row of read('titan-fourth').results){
 const m=open(row.root);
 try{
  for(const {action,n,ms} of row.actions){
   if(n!==undefined){assert(n<=256 && ms<=600);largest=Math.max(largest,n);slowest=Math.max(slowest,ms);}
   m.apply(action);replayed++;
  }
  assert.deepEqual(m.save(),row.end);
  assert(m.state().turn.gameEnded);
  assert.deepEqual(m.state().match.finalScores.find(p=>p.playerId==='player-white'),row.terminal);
  terminal++;
 }finally{m.dispose();}
}
console.log(JSON.stringify({formalInputs,exact,rejected,terminal,replayed,largest,slowest}));
