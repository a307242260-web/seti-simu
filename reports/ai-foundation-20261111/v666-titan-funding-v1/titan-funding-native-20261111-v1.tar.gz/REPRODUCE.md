# 复放 V666 第三轮土卫六与第二物种对照

在 `c30b18dd1` 的源码目录运行 `node /解压目录/verify.cjs`。源码目录须带有 `26a0e5d91` 登记的正式 V666 报告、轮末存档和动作记录。验证器重放正式第二轮末到第三轮终点，并独立重放归档的受控输入、失败前缀与第四轮终局。所有结果来自同一套 Production 规则。

如要重新生成诊断数据，仍在同一源码目录执行以下命令。`BUNDLE` 指向归档解压目录，`OUTPUT` 指向空的输出目录。

```sh
node "$BUNDLE/verify-official.cjs" reports/research/31f6eb84.c30b18dd.quick-400.json - "$OUTPUT/official.gz"
node "$BUNDLE/pink-worlds.cjs" "$OUTPUT/official.gz" "$OUTPUT/worlds.gz"
node "$BUNDLE/titan-funding.cjs" "$OUTPUT/official.gz" "$OUTPUT/funding.gz"
node "$BUNDLE/landing-funds.cjs" "$OUTPUT/worlds.gz" "$OUTPUT/landing-funds.gz"
node "$BUNDLE/titan-marks.cjs" "$OUTPUT/funding.gz" "$OUTPUT/worlds.gz" "$OUTPUT/marks.gz"
node "$BUNDLE/titan-retain.cjs" "$OUTPUT/funding.gz" "$OUTPUT/marks.gz" "$OUTPUT/retention.gz"
node "$BUNDLE/titan-fourth.cjs" "$OUTPUT/marks.gz" "$OUTPUT/retention.gz" "$OUTPUT/fourth.gz"
```

固定输入在 `prefix`，此后白席自主输入在 `actions`。`settled` 是第三轮白席提交 PASS 之前的存档。正式记录使用从 1 开始的报告步号。七个暗面各使用一个规则允许的分配，用来核对已知信息与结果敏感性。自主决定超过 256 原生输入或 600 毫秒时停在该决定前，冷测耗时随运行环境变化。
