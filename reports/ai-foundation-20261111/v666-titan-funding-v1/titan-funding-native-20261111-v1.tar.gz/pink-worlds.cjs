'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,open,runCases,short}=require('./controlled-r3');
const {createStateStore}=require(require('node:path').resolve('randomizer/game/state/state-store'));
const [data,out]=process.argv.slice(2);
const root=readZ(data).rows.find(row=>row.i===214).before,seat='player-white',m=open(root);
const view=m.owner(seat),menu=m.menu(),before=m.automatic(),reference=[before.a.actionId,before.value,before.roots];
const assignment=m.state().aliens.aliens['2'].assignedAlienId,pool=m.state().aliens.revealPoolAlienIds.filter(x=>x!=='阿米巴');
const worlds=new Map([[assignment,{envelope:root,seed:null}]]);
for(let i=0;i<256&&worlds.size<pool.length;i++){
 const seed='r214-public-control-world-v1:'+i;
 const envelope=m.c.counterfactualPort.prepareRoot(root,{publicSeed:seed,restoreRandomState:false});
 const native=envelope.session.session.workingState,assumed=native.aliens.aliens['2'].assignedAlienId;
 assert.deepEqual(native.meta.rngState,m.state().meta.rngState);
 if(!worlds.has(assumed)){
  const canonical=JSON.parse(envelope.committedState),encoded=createStateStore(canonical).serialize(canonical);assert(encoded.ok);
  worlds.set(assumed,{envelope:{...envelope,committedState:encoded.serialized},seed});
 }
}
m.dispose();assert.equal(worlds.size,pool.length);
const samples={};
for(const species of pool){
 const {envelope:e,seed}=worlds.get(species),m=open(e);
 try{
  assert.deepEqual(m.owner(seat),view);assert.deepEqual(m.menu(),menu);
  const u=m.automatic();assert.deepEqual([u.a.actionId,u.value,u.roots],reference);
  const a=m.act('choose_target',a=>a.target.choiceId==='trace:2:pink');
  while(m.c.inspect().phase==='awaiting_input'){
   const choices=m.menu(),pick=choices.find(x=>x.target.choiceId?.startsWith('confirm:trigger:'))||choices.find(x=>x.target.choiceId?.startsWith('skip:'));
   if(!pick)break;m.apply(pick);
  }
  const s=short(m);console.log('pre-reveal',species,s.wallet,s.hand.length);
 }finally{m.dispose();}
 const pick=[['amiba3',({act})=>act('choose_target',a=>a.target.choiceId==='trace:1:pink:amiba:3')], ['reveal',({act})=>act('choose_target',a=>a.target.choiceId==='trace:2:pink')]];
 try{samples[species]={authentic:species===assignment,sourceSeed:seed,root:e,...runCases(e,pick)};}
 catch(e){samples[species]={authentic:species===assignment,sourceSeed:seed,error:String(e).slice(0,1900)};
 console.log(species,String(e).slice(0,400));}
}
writeZ(out,{scope:'Each publicly eligible species shares the same exact observations, RNG state and legal menu before reveal. The two arms force one pink target each before resuming the same gated policy. This is diagnostic sensitivity, not the original-seed autonomous score and not a calibrated distribution over deck orders.',assignment,pool,priorRevealChoice:reference,samples});
