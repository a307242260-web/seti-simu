'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const {open, readZ, writeZ, short} = require('./controlled-r3');
const [reportPath, observedPath, out] = process.argv.slice(2);
const read = p => JSON.parse(fs.readFileSync(p));
const report = read(reportPath), formal = read(report.savePath);
const r2 = report.roundEnds[1], r3 = report.roundEnds[2];
const first = read(r2.checkpointPath).coreState.compositionEnvelope;
const last = read(r3.checkpointPath).coreState.compositionEnvelope;
const previous = observedPath === '-' ? null : readZ(observedPath), found = [];
const m = open(first);
try {
 for (let input = r2.beforeInput; input <= formal.replaySteps.length; input++) {
  if ([214,227].includes(input)) {
   const root = m.save();
   if (previous) assert.deepEqual(root, previous.rows.find(r => r.i === input).before);
   found.push({i:input, before:root, summary:short(m)});
  }
  if (input === r3.beforeInput) assert.deepEqual(m.save(), last);
  m.apply(formal.replaySteps[input-1].action);
 }
 const lastSave = m.save();
 assert.equal(lastSave.committedState, formal.committedState);
 assert.deepEqual(lastSave.session, formal.session);
} finally { m.dispose(); }
assert.equal(found.length, 2);
writeZ(out,{report:reportPath, gitCommit:report.gitCommit, source:report.fingerprint,
 passedRoundEnds:[r2.beforeInput,r3.beforeInput], officialRound3:r3, rows:found});
