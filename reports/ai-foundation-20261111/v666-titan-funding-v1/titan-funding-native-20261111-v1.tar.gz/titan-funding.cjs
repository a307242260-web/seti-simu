'use strict';

const assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const {getProbeRouteRequirements}=require(path.resolve('randomizer/game/production-kernel'));
const [source,out]=process.argv.slice(2);
const root=readZ(source).rows.find(row=>row.i===227).before;

function end(h){h.act('end_turn');const steps=[];h.m.advanceOpponents(steps);h.take(...steps);}
function place(h,slot){
 h.act('place_data');h.act('choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');
}
function settle(h){
 for(let i=0;i<12&&h.m.save().session;i++){
  const menu=h.m.menu();
  const choice=menu.find(a=>a.target.source==='display')||
    menu.find(a=>a.family==='accept_optional_effect'&&a.target.ruleId?.includes('amiba0'))||
    (menu.length===1?menu[0]:null);
  if(!choice)break;
  h.take(h.m.apply(choice));
 }
}
function techAndAnalysis(h,mark){
 h.act('choose_target',a=>a.target.tileId==='orange4');
 h.cut('after-orange4');
 place(h);place(h);end(h);
 h.act('analyze');
 h.act('choose_target',a=>a.target.speciesId==='amiba'&&a.target.position===mark);
 settle(h);
 h.cut('analysis-paid');
}
function trade(h,pair){
 h.act('quick_trade',a=>a.target.tradeId==='cards-for-energy');
 for(const card of pair)h.act('choose_payment',a=>a.target.select&&a.summary===card);
 h.act('choose_payment',a=>a.target.confirm);
}
function travel(h,cardToSwap,land){
 const before=getProbeRouteRequirements(h.m.state(),'player-white').candidates;
 const goal=before.find(a=>a.planetId==='saturn'&&a.endpointFamily==='land'&&a.endpointTarget?.satelliteId==='titan');
 assert(goal,JSON.stringify(before.filter(a=>a.planetId==='saturn').map(x=>[x.targetId,x.required])));
 h.cut('route');
 const held=h.m.facts().hand.map(x=>x[1]);
 assert(held.includes(cardToSwap),held.join(','));
 h.take(...h.m.swap(cardToSwap,'dlc_16.png'));
 const pair=h.m.facts().hand.map(x=>x[1]).filter(c=>!['dlc_16.png','dlc_25.png'].includes(c));
 if(pair.length===2)trade(h,pair);
 place(h);place(h,1);
 h.cut('paid');
 end(h);
 const route=getProbeRouteRequirements(h.m.state(),'player-white').candidates.find(a=>a.targetId===goal.targetId);
 assert(route);
 for(const [i,step] of route.path.entries()){
  h.act('move',a=>a.target.deltaX===step.deltaX&&a.target.deltaY===step.deltaY&&a.target.rocketId===route.rocketId);
  h.act('choose_payment',a=>i===0?a.summary.includes('弃')&&a.summary.includes('移动'):a.summary==='消耗 1 能量');
  const card=h.m.menu().find(a=>a.summary==='dlc_16.png'&&a.target.select);
  if(card){
   h.take(h.m.apply(card));h.act('choose_payment',a=>a.target.confirm);
  }
 }
 h.cut('at-saturn');
 h.act('land');
 h.cut('landing-menu');
 if(land)h.act('choose_target',a=>a.target.landTarget?.satelliteId==='titan');
 h.cut('titan-mark');
}

const cases=[];
for(const mark of [2,3])for(const card of ['b_16.webp','amiba_5.webp','amiba_2.webp']){
 cases.push([mark+' / swap '+card+' / Titan',h=>{techAndAnalysis(h,mark);travel(h,card,true);}]);
}
writeZ(out,{root,...runCases(root,cases)});
