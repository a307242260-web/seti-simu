'use strict';

const assert = require('node:assert/strict');
const {open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [fund,marks,out]=process.argv.slice(2);
const paid=readZ(fund).rows[0];
const previous=readZ(marks).paid.rows[0];
function place(h){h.act('place_data');h.act('choose_target',a=>a.target.target==='computer');}
function insert(h){
 h.act('choose_card',a=>a.summary==='收入 dlc_25.png');
 assert.equal(h.m.player().income.energy,4);
}
function buy(h,id){h.act('quick_trade',a=>a.target.tradeId==='publicity-for-card');h.take(h.m.pick(id));}
function end(h){h.act('end_turn'); const passive=[];h.m.advanceOpponents(passive);h.take(...passive);}
function mark(h,id){
 h.act('choose_target',a=>a.target.choiceId===id);
 for(let j=0;j<6&&h.m.save().session;j++){
  const a=h.m.menu().find(x=>x.target.source==='display'||x.target.choiceId?.startsWith('confirm:trigger:'));
  if(!a)return;
  h.take(h.m.apply(a));
 }
}
function claim(h){h.act('complete_task',a=>a.summary.includes('b_117.webp'));}
const income=runCases(previous.start,[
 ['pink + yellow / insert DLC25 using DLC14 and public DLC17',h=>{
  buy(h,'dlc_17.png');h.take(h.m.corner('dlc_17.png'),h.m.corner('dlc_14.png'));
  place(h);place(h);place(h);insert(h);h.cut('electricity');
 }],

]);
const choices=runCases(paid.start,[
 ['both known yellow4 + yellow3, keep hand',h=>{
  mark(h,'trace:1:yellow:amiba:4');mark(h,'trace:1:yellow:amiba:3');claim(h);end(h);h.cut('turn16');
 }],
 ['both known yellow4 + yellow3, buy missing corner',h=>{
  mark(h,'trace:1:yellow:amiba:4');mark(h,'trace:1:yellow:amiba:3');claim(h);end(h);h.cut('turn16');
  buy(h,'dlc_17.png');h.take(h.m.corner('dlc_17.png'));
  place(h);place(h);place(h);insert(h);h.cut('electricity');
 }],
 ['both known yellow3 + yellow4, buy missing corner',h=>{
  mark(h,'trace:1:yellow:amiba:3');mark(h,'trace:1:yellow:amiba:4');claim(h);end(h);h.cut('turn16');
  buy(h,'dlc_17.png');h.take(h.m.corner('dlc_17.png'));
  place(h);place(h);place(h);insert(h);h.cut('electricity');
 }],
]);
writeZ(out,{incomeRoot:previous.start,marksRoot:paid.start,income,choices});
