'use strict';

const assert = require('node:assert/strict');
const {open, readZ, writeZ, runCases, short} = require('./controlled-r3');
const [paid, revealed, out] = process.argv.slice(2);
const funding = readZ(paid);
const worlds = readZ(revealed);
const early = worlds.samples[worlds.assignment].rows.find(row => row.label === 'reveal');
const paidRoot = funding.rows[0].start;
const chongRoot = (() => {
 const m = open(early.start);
 try { early.actions.slice(0,32).forEach(x => m.apply(x.action)); return m.save(); }
 finally { m.dispose(); }
})();
function trace(h, id) { h.act('choose_target', a => a.target.choiceId === id); }
function resolveKnown(h) {
 for (let i=0; i<16 && h.m.save().session; i++) {
  const menu = h.m.menu();
  const action = menu.find(a => a.target.source === 'display')
   || menu.find(a => a.family === 'accept_optional_effect' && a.target.choiceId?.includes('amiba0'))
   || (menu.length === 1 ? menu[0] : null);
  if (!action) return;
  h.take(h.m.apply(action));
 }
}
function end(h) {
 h.act('end_turn');
 if (h.m.save().session) {
  h.act('accept_optional_effect', a => a.target.choiceId?.endsWith(':b117-orbit-land-count-task') && a.target.choiceId.startsWith('confirm:'));
 }
 const passive = [];
 h.m.advanceOpponents(passive);
 h.take(...passive);
}
const paidCases = [
 ['paid standard / pink then known yellow4', h => {
  trace(h, 'trace:2:pink');
  assert.equal(h.m.owner('player-white').publicState.board.aliens.slots[1].revealed, false);
  trace(h, 'trace:1:yellow:amiba:4');
  resolveKnown(h);
  assert.equal(h.m.save().session, null);
  assert.equal(h.m.facts().probes.length, 0);
  h.cut('stable-before-reveal');
  end(h);
  assert.equal(h.m.owner('player-white').publicState.board.aliens.slots[1].alienId, '虫');
  h.cut('after-reveal');
 }],
 ['paid standard / yellow4 then pink', h => {
  trace(h, 'trace:1:yellow:amiba:4');
  resolveKnown(h);
  trace(h, 'trace:2:pink');
  h.cut('stable-before-reveal');
  end(h);
  h.cut('after-reveal');
 }],
];
const chongCases = [['Chong9 directly reaches Titan', h => {
 h.act('choose_target', a => a.target.landTarget?.satelliteId === 'titan');
 h.cut('titan-mark');
}]];
for (const [first, second] of [
 ['trace:1:yellow:amiba:4','trace:1:blue:amiba:2'],
 ['trace:1:yellow:amiba:4','trace:2:yellow:chong:4'],
 ['trace:2:yellow:chong:4','trace:1:yellow:amiba:4'],
 ['trace:1:yellow:amiba:4','trace:1:yellow:amiba:3'],
]) {
 chongCases.push([`Chong9 Titan / ${first} / ${second}`, h => {
  h.act('choose_target', a => a.target.landTarget?.satelliteId === 'titan');
  trace(h, first); resolveKnown(h);
  trace(h, second); resolveKnown(h);
  h.cut('fossil-menu');
  h.act('choose_target', a => a.target.fossilId === 'fossil_01');
  h.cut('picked');
 }]);
}
writeZ(out,{paidRoot,chongRoot,paid:runCases(paidRoot,paidCases),chong:runCases(chongRoot,chongCases)});
