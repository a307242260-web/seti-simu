'use strict';
const path=require('node:path'),assert=require('node:assert/strict');
const {open,short,writeZ,readZ}=require('./controlled-r3');
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const d=readZ(process.argv[2]),b=readZ(process.argv[3]),controlled=d.rows[2];
const eq=(a,b)=>{assert.deepEqual(JSON.parse(a.committedState),JSON.parse(b.committedState));assert.deepEqual(a.session,b.session);};
const proof=[];
for(let i=0;i<2;i++){
 const target=d.rows[i],prior=b.rows[i];eq(target.start,prior.start);
 assert.equal(target.stop,'r4-first-white-main');assert.equal(prior.stop,'r4-first-white-main');
 const count=2*(2-i);
 const expected=controlled.prefix.slice(-count),actual=target.actions.slice(0,count).map(a=>a.action);
 assert.deepEqual(actual,expected);
 eq(target.settled.state,controlled.settled.state);
 assert.deepEqual(target.actions.slice(count).map(a=>a.action),controlled.actions.map(a=>a.action));
 const modified=structuredClone(target.start),s=JSON.parse(modified.committedState);
 for(const deck of [s.cards.drawPileCardIds,s.aliens.amiba.cardDeck,s.aliens.chong.cardDeck]){
  assert(deck.length>=2);[deck[0],deck[1]]=[deck[1],deck[0]];
 }
 modified.committedState=createStateStore(s).serialize().serialized;
 const variants=[target.start,modified].map(e=>{
  const m=open(e);
  try{
   const visible=m.owner('player-white'),legal=m.menu(),rng=m.facts().rng,q=m.automatic();
   assert(q.complete&&q.n<=256&&q.ms<=600&&q.a.family==='place_data');assert.deepEqual(m.save(),e);
   let cp=q.checkpoint;const after=[];
   m.apply(q.a);
   for(const a of expected.slice(1)){
    const next=m.automatic(cp);assert(next.complete&&next.n===0&&next.a.actionId===a.actionId);
    cp=next.checkpoint;m.apply(next.a);after.push(next.n);
   }
   return {visible,legal,rng,choice:q.a,value:q.value,n:q.n,ms:q.ms,roots:q.roots,after,ready:m.save()};
  }finally{m.dispose();}
 });
 for(const key of ['visible','legal','rng','choice','value','n','roots','after'])assert.deepEqual(variants[0][key],variants[1][key],key);
 eq(variants[0].ready,controlled.start);
 console.log(JSON.stringify([target.label,prior.settled.summary.wallet[0],target.settled.summary.wallet[0],variants[0].n,variants[0].ms,variants[0].value,variants[0].after]));
 proof.push({label:target.label,expected,variants});
}
writeZ(process.argv[4],{proof});
