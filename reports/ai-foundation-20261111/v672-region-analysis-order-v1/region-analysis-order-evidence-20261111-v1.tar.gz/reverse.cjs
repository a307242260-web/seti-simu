'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,runCases}=require('./controlled-r3');
const d=readZ(process.argv[2]),cases=[];
const place=h=>{h.act('place_data');h.act('choose_target',a=>a.target.target==='computer');};
function marks(h){for(let i=0;i<5;i++){const list=h.m.menu();if(!list.every(a=>a.target?.choiceId?.startsWith('final:')))break;const q=h.m.automatic();assert(q.complete&&q.n<=256&&q.ms<=600);h.take(h.m.apply(q.a));}}
function end(h){h.act('end_turn');marks(h);const passive=[];h.m.advanceOpponents(passive);passive.forEach(a=>h.take(a));}
for(const pink of ['amiba','reveal']){
 for(const prefix of ['before-amiba','amiba-only','amiba+fill1','amiba+fill2','amiba+fill2+analyze']){
  cases.push([pink+'/'+prefix,h=>{
   h.take(h.m.play('dlc_19.png'));
   h.act('choose_target',a=>a.summary.includes('织女一'));h.act('choose_target',a=>a.summary.includes('织女一'));
   h.act('choose_target',a=>pink==='reveal'?a.target.choiceId==='trace:2:pink':a.target.choiceId==='trace:1:pink:amiba:4');
   if(pink==='amiba')h.act('choose_card',a=>a.target.source==='display');
   end(h);
   if(prefix==='before-amiba')return;
   h.take(h.m.play('amiba_0.webp'));
   h.act('choose_target',a=>a.summary.startsWith('blue_3'));
   if(prefix.includes('fill'))for(let i=0;i<(prefix.includes('fill1')?1:2);i++)place(h);
   if(prefix.endsWith('analyze'))h.act('analyze');
  }]);
 }
}
writeZ(process.argv[3],runCases(d.root,cases));
