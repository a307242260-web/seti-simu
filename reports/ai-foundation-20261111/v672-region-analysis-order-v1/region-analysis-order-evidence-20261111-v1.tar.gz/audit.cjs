'use strict';
const {readZ,open,short,writeZ}=require('./controlled-r3');
const d=readZ(process.argv[2]),m=open(d.root),rows=[];
try{
 for(let i=0;i<=11;i++){
  const q=m.automatic();
  const menu=m.menu();
  const row={i,checkpoint:m.save(),facts:short(m),menu,result:q};
  rows.push(row);
  console.log(JSON.stringify({i,chosen:q.a.summary,n:q.n,V:q.value,
    roots:q.roots.map(x=>[menu.find(a=>a.actionId===x.actionId)?.summary,x.completion,x.value,x.goalId??x.resourceGoal?.id??x.resourcePlan?.goal?.id]),
    matched:d.fixed[i]?.actionId===q.a.actionId,expected:d.fixed[i]?.summary}));
  if(i===11)break;
  m.apply(d.fixed[i]);
 }
 writeZ(process.argv[3],rows);
}finally{m.dispose();}
