Run from the repo root on Node 22. Put these scripts and their helpers in the same directory. Obtain `transport-release-20261111-v2.json.gz` and `transport-payment-20261111-v1.json.gz` from the V671 evidence archive; existing output paths are rejected.

```sh
proof=/path/to/this/archive
prev=/path/to/extracted/v671/archive
fixture="$prev/transport-release-20261111-v2.json.gz"
# V671 baseline (4a33e0c06):
node "$proof/audit.cjs" "$fixture" /tmp/v672-audit.json.gz
node "$proof/timing.cjs" "$fixture" /tmp/v672-timing.json.gz
node "$proof/reverse.cjs" "$fixture" /tmp/v672-reverse.json.gz
node "$proof/next-main-compare.cjs" "$fixture" /tmp/v672-before.json.gz
node "$proof/retain.cjs" "$prev/transport-payment-20261111-v1.json.gz" reports/research/93d07f1e.4a33e0c0.quick-400.json.round-end-3.checkpoint.json /tmp/v672-retention.json.gz
# V672 candidate (a1ac8bc91):
node "$proof/reveal-variants.cjs" "$proof/r172-policy-audit-20261111-v1.json.gz" /tmp/v672-reveal-variants.json.gz
node "$proof/next-main-compare.cjs" "$fixture" /tmp/v672-after.json.gz
node "$proof/admission.cjs" /tmp/v672-after.json.gz /tmp/v672-before.json.gz /tmp/v672-admission.json.gz
node "$proof/standard-gate.cjs" "$PWD" reports/ai-foundation-20261109/v660-public-transport-chain-v1/v660-first3-independent-replay-20261109-v1.checkpoint.json /tmp/v672-standard-gate.json.gz 93d07f1e.4a33e0c0.quick-400.json
node "$proof/verify-official.cjs" reports/research/93d07f1e.4a33e0c0.quick-400.json reports/research/04214205.a1ac8bc9.quick-400.json reports/ai-foundation-20261109/v660-public-transport-chain-v1/v660-first3-independent-replay-20261109-v1.checkpoint.json /tmp/v672-verified.json.gz a1ac8bc9
```

The timing archive includes two deliberately logged invalid cuts before the pending final mark; the matched legal next-main controls are in the separate baseline and candidate archives. The reverse archive preserves two rejected post-main analyze attempts. The fourth-round archive retains the first over-watchdog decision without applying it. Wall timing is machine/load dependent.
