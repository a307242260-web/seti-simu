'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),{open,writeZ}=require('./controlled-r3');
const [r0,r1,starter,out,sourceSha]=process.argv.slice(2),read=p=>JSON.parse(fs.readFileSync(p)),prev=read(r0),fresh=read(r1),opener=read(starter).roundStarts[1];
const a=read(prev.savePath),b=read(fresh.savePath),same=(x,y)=>{assert.deepEqual(JSON.parse(x.committedState),JSON.parse(y.committedState));assert.deepEqual(x.session,y.session);};
assert.equal(fresh.gitCommit.slice(0,8),sourceSha);assert.deepEqual(fresh.roundEnds.map(x=>x.score),[15,48,118]);assert.equal(fresh.terminal,false);
assert.deepEqual(a.replaySteps.map(x=>x.action),b.replaySteps.map(x=>x.action));
const clean=x=>[x.actionId,x.value,x.diagnostics.nativeExecutions,x.complete];
assert.equal(fresh.metrics.searches.length,211);assert.deepEqual(fresh.metrics.searches.map(clean),prev.metrics.searches.map(clean));
for(let i=0;i<3;i++)same(read(fresh.roundEnds[i].checkpointPath).coreState.compositionEnvelope,read(prev.roundEnds[i].checkpointPath).coreState.compositionEnvelope);
const m=open(opener.envelope);
try{
 for(let i=opener.beforeInput;i<=b.replaySteps.length;i++)m.apply(b.replaySteps[i-1].action);
 same(m.save(),b);same(a,b);
}finally{m.dispose();}
const peaks=[Math.max(...fresh.metrics.searches.map(x=>x.diagnostics.nativeExecutions)),Math.max(...fresh.metrics.searches.map(x=>x.rootAndSearchMilliseconds??x.diagnostics.rootAndSearchMilliseconds??x.searchMs??0))];
const result={record:r1,scores:fresh.roundEnds.map(x=>x.score),source:fresh.gitCommit,peaks,searches:211,inputs:b.replaySteps.length,nativeReplayed:b.replaySteps.length-opener.beforeInput+1};
console.log(JSON.stringify(result));writeZ(out,result);
