'use strict';
const path=require('node:path'),assert=require('node:assert/strict');
const {open,short,writeZ,readZ,runCases}=require('./controlled-r3');
const aliens=require(path.resolve('randomizer/game/aliens')), {createSeededRandom}=require(path.resolve('randomizer/game/random'));
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const d=readZ(process.argv[2]),base=d[6].checkpoint;assert(!base.session);
const variants=[];let comparison;
for(const id of ['虫','奥陌陌','半人马','九折','方舟','符文族','异常点']){
 const root=structuredClone(base),s=JSON.parse(root.committedState);
 assert(!s.aliens.aliens[2].revealed&&s.aliens.aliens[1].revealed);
 s.aliens.aliens[2].assignedAlienId=id;
 const key=['chong','aomomo','banrenma','jiuzhe','fangzhou','runezu','yichangdian'].find(key=>aliens[key].ALIEN_ID===id);
 if(!s.aliens[key].initialConfiguration)s.aliens[key].initialConfiguration=aliens[key].createInitialConfiguration(
  createSeededRandom('r172-reveal-variant-20261111:'+key),s.players.players);
 root.committedState=createStateStore(s).serialize().serialized;
 const m=open(root);let view;
 try{m.act('end_turn');m.play('dlc_19.png');m.act('choose_target',a=>a.summary.includes('织女一'));m.act('choose_target',a=>a.summary.includes('织女一'));
  const q=m.automatic();assert(q.complete&&q.n<=256&&q.ms<=600);
  view={choices:m.menu(),observation:m.owner('player-white'),rng:m.facts().rng,roots:q.roots,actionId:q.a.actionId,n:q.n};
  if(comparison)assert.deepEqual(view,comparison);
  comparison=view;
 }finally{m.dispose();}
 let result;try{result=runCases(root,['known','reveal'].map(type=>[id+'/'+type,h=>{
  h.act('end_turn');h.take(h.m.play('dlc_19.png'));
  h.act('choose_target',a=>a.summary.includes('织女一'));h.act('choose_target',a=>a.summary.includes('织女一'));
  h.act('choose_target',a=>a.target.choiceId===(type==='known'?'trace:1:pink:amiba:4':'trace:2:pink'));
 }]));}catch(error){result={error:String(error)};console.log(id,result.error.slice(0,350));}
 variants.push({id,root,view,...result});
}
writeZ(process.argv[3],{variants});
