'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,runCases}=require('./controlled-r3');
const d=readZ(process.argv[2]);
const cases=[];
const place=h=>{h.act('place_data');h.act('choose_target',a=>a.target.target==='computer');};
const end=h=>{h.act('end_turn');const passive=[];h.m.advanceOpponents(passive);passive.forEach(a=>h.take(a));};
for(const timing of ["before-next-main"]){
 for(const count of [0,1,2]){
  cases.push([timing+'/'+count,h=>{
   d.fixed.slice(0,2).forEach(a=>h.take(h.m.apply(a)));
   if(timing==='before-dlc19')for(let i=0;i<count;i++)place(h);
   end(h);
   h.take(h.m.play('dlc_19.png'));
   h.act('choose_target',a=>a.summary.includes('织女一'));
   h.act('choose_target',a=>a.summary.includes('织女一'));
   h.act('choose_target',a=>a.target.choiceId==='trace:2:pink');
   if(timing!=='before-dlc19')h.act('accept_optional_effect');
   if(timing==='after-dlc19'||timing==='after-reveal')for(let i=0;i<count;i++)place(h);
   if(timing==="before-next-main"){end(h);h.act("choose_target",a=>a.target?.choiceId==="final:b");for(let i=0;i<count;i++)place(h);}
  }]);
 }
}
const result=runCases(d.root,cases);
for(const r of result.rows)assert(r.settled,r.label);
writeZ(process.argv[3],result);
