'use strict';
const {open,readZ,writeZ,runCases}=require('./controlled-r3');
const d=readZ(process.argv[2]),r=d.rows.find(x=>x.label==='amiba_9.webp/insert'),m=open(r.start);
for(const x of r.actions.slice(0,15))m.apply(x.action);
const root=m.save(),menu=m.menu(),q=m.automatic(),facts=m.facts();
m.dispose();
const result=runCases(root,menu.map(a=>[a.summary,h=>h.take(h.m.apply(a))]));
writeZ(process.argv[3],{root,menu,q,facts,...result});
