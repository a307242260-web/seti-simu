'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const d=readZ(process.argv[2]),r=d.rows.find(x=>x.label==='amiba_9.webp/insert'),cases=[
 ['hold-after-income',1],['hold-after-scan',10],['hold-computer-full',14],['standard-insert-continuation',18]];
const rows=[];
for(const [label,n] of cases){
 const m=open(r.start);
 try {
  const actions=r.actions.slice(0,n).map(e=>m.apply(e.action));
  if(m.menu()[0].family==='end_turn'||!m.menu().some(a=>a.family==='pass'))actions.push(m.act('end_turn'));
  assert(m.menu().some(a=>a.family==='pass'));
  const state=m.save(),facts=short(m);
  const reserve=[];
  for(const card of ['b_111.webp','b_32.webp']){
   m.restore(state);m.act('pass');reserve.push([card,m.menu().some(a=>a.summary===card)]);
  }
  m.restore(r.start);actions.forEach(a=>m.apply(a));assert.deepEqual(m.save(),state);
  console.log(JSON.stringify([label,actions.length,facts,reserve]));rows.push({label,actions,settled:{state,summary:facts}});
 }finally{m.dispose();}
}
writeZ(process.argv[3],{rows});
