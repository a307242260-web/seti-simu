Run from the SETI repo root on Node 22. Extract these files to one directory. Use the V671 evidence archive for `transport-payment-20261111-v1.json.gz`. Output paths must not exist.

```sh
proof=/path/to/this/archive
prev=/path/to/extracted/v671/archive
checkpoint=reports/research/04214205.a1ac8bc9.quick-400.json.round-end-3.checkpoint.json
# V672 (a1ac8bc91); the original income witness was also captured on this source.
node "$proof/transport-income.cjs" "$prev/transport-payment-20261111-v1.json.gz" /tmp/v673-income.json.gz
node "$proof/retain-stocks.cjs" /tmp/v673-income.json.gz /tmp/v673-retain.json.gz
node "$proof/late-trace.cjs" /tmp/v673-income.json.gz /tmp/v673-trace.json.gz
node "$proof/fourth.cjs" /tmp/v673-retain.json.gz "$checkpoint" /tmp/v673-fourth.json.gz
node "$proof/trace-fourth.cjs" /tmp/v673-trace.json.gz "$checkpoint" /tmp/v673-trace-fourth.json.gz
node "$proof/profile.cjs" /tmp/v673-fourth.json.gz /tmp/v673-profile.json.gz
# V673 (cbd73e00c):
node "$proof/buy-fourth.cjs" /tmp/v673-income.json.gz "$checkpoint" /tmp/v673-buy-fourth.json.gz
node "$proof/scan-stock.cjs" /tmp/v673-income.json.gz /tmp/v673-scan.json.gz
node "$proof/parity.cjs" "$proof/cargo-hold-profile-20261111-v1.json.gz" /tmp/v673-parity.json.gz
node "$proof/hidden.cjs" /tmp/v673-parity.json.gz /tmp/v673-hidden.json.gz
node "$proof/resume.cjs" "$proof/cargo-income-fourth-20261111-v1.json.gz" /tmp/v673-resume.json.gz
node "$proof/standard-gate.cjs" "$PWD" reports/ai-foundation-20261109/v660-public-transport-chain-v1/v660-first3-independent-replay-20261109-v1.checkpoint.json /tmp/v673-standard.json.gz 04214205.a1ac8bc9.quick-400.json
node "$proof/verify-official.cjs" reports/research/04214205.a1ac8bc9.quick-400.json reports/research/d3183131.cbd73e00.quick-400.json reports/ai-foundation-20261109/v660-public-transport-chain-v1/v660-first3-independent-replay-20261109-v1.checkpoint.json /tmp/v673-verified.json.gz cbd73e00
```

Do not run benchmarks concurrently. Native profile excludes inputs with an already verified summary. The original fixed `hold-now` at a post-main menu is recorded as illegal; the valid hold variant first ends the current turn and takes the checkpoint before PASS.
