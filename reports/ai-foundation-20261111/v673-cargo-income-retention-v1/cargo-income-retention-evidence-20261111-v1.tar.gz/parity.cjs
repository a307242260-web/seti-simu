'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {open,readZ,writeZ}=require('./controlled-r3');
const [input,out]=process.argv.slice(2),src=path.resolve('randomizer/game/ai/analysis-port.js');
const mod=new Module(src,module);mod.filename=src;mod.paths=Module._nodeModulePaths(path.dirname(src));
const code=fs.readFileSync(src,'utf8');
let witnesses=[];
globalThis.recordScanProof=(kind,source,action,target,child,raw,barrier)=>witnesses.push({kind,source:source.envelope,action,target:target.envelope,
 legal:child.legalActions.map(a=>[a.actionId,a.family,a.target]),raw:raw?.map(a=>[a.actionId,a.family,a.target]),barrier});
const hooks=[['        if(requested.target.mode==="move")provedScan4QuietMoves++;',`        if(requested.target.mode==="move"){
          provedScan4QuietMoves++;
          if(knownStationaryCargoForScan(stored.envelope.session.session.workingState))
            globalThis.recordScanProof("stationary-comet",stored,requested,nodes.get(child),child,scanAction.prepared?.inspection.session?.decision?.choices,scanAction.barrier||scanAction.prepared?.inspection.session?.irreversibleBarrier);
        }`]];
let decorated=code;
for(const [anchor,replacement] of hooks){assert.equal(decorated.split(anchor).length,2);decorated=decorated.replace(anchor,replacement);}
mod._compile(decorated,src);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
function normalized(envelope){
 const e=structuredClone(envelope);e.committedState=JSON.parse(e.committedState);
 const session=e.session?.session;if(!session)return e;session.undoFrames=[];
 const visit=x=>{
  if(typeof x==='string')return x.replaceAll(session.sessionId,'@session');
  if(Array.isArray(x))return x.map(visit);
  if(x&&typeof x==='object')return Object.fromEntries(Object.entries(x).map(([k,v])=>[k,visit(v)]));
  return x;
 };
 e.session=visit(e.session);
 return e;
}
const fields=['actionId','value','realization','preparationDebt','complete','roots','lines','unresolved','selectionPlan','candidates','sharedPrefixGraph'];
const seats='player-white',results=[];
for(const row of readZ(input)){
 witnesses=[];
 const m=open(row.root),port=createAnalysisPort({composition:m.c,seatId:seats,maxCacheEntries:0});
 try{
  const q=createSearchAgent({seatId:seats,analysisPort:port}).decide({seatId:seats,legalActions:m.menu()}).search;
  assert.deepEqual(m.save(),row.root);
  const archived=JSON.parse(JSON.stringify(q));
  for(const field of fields)assert.deepEqual(archived[field],row.q[field],field);
  const counts={};let tests=0;
  for(const w of witnesses){
   assert(m.c.lifecycle.restore(w.source).ok);
   assert.deepEqual(normalized(m.save()),normalized(w.source));
   const a=m.menu().find(a=>a.actionId===w.action.actionId),d=m.c.inspect().session?.decision;
   assert(a&&d);assert.deepEqual(a.target,w.action.target);
   const r=m.c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a});
   assert(r.ok);
   if(w.barrier)assert.deepEqual(r.irreversibleBarrier||m.save().session?.session?.irreversibleBarrier,w.barrier);
   else assert(!r.irreversibleBarrier);
   try{assert.deepEqual(normalized(m.save()),normalized(w.target));}
   catch(err){console.log(w.kind,w.action.summary,err.message.slice(0,1800));throw err;}
   const menu=m.menu().map(a=>[a.actionId,a.family,a.target]);
   if(w.raw)assert.deepEqual(menu,w.raw);
   assert(w.legal.every(a=>menu.some(b=>JSON.stringify(a)===JSON.stringify(b))));
   counts[w.kind]=(counts[w.kind]||0)+1;tests++;
  }
  assert(tests===(row.card==="b_111.webp"?37:55));
  results.push({card:row.card,root:row.root,counts,n:q.diagnostics.nativeExecutions,witnesses});
  console.log(JSON.stringify([row.card,counts,q.diagnostics.nativeExecutions]));
 }finally{port.close();m.dispose();}
}
writeZ(out,{results});
