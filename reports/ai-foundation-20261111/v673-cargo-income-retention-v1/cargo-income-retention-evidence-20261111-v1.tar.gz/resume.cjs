'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const d=readZ(process.argv[2]),results=[];
for(const r of d.results.filter(r=>typeof r.stop==='object')){
 const m=open(r.end),actions=[];let cp,stop;
 try{
  for(let i=0;i<150;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!=='player-white'){const passive=[];m.advanceOpponents(passive);actions.push(...passive.map(action=>({action,passive:true})));continue;}
   const q=m.automatic(cp);
   if(!q.a||!q.complete||q.n>256||q.ms>600){stop={kind:'gate',n:q.n,ms:q.ms,action:q.a?.summary,turn:m.facts().turn};break;}
   cp=q.checkpoint;actions.push({action:m.apply(q.a),n:q.n,ms:q.ms,value:q.value});
  }
  assert(stop);
  const end=m.save(),terminal=stop==='terminal'?m.state().match.finalScores.find(p=>p.playerId==='player-white'):null;
  const facts=short(m),peak=[Math.max(0,...actions.map(x=>x.n||0)),Math.max(0,...actions.map(x=>x.ms||0))];
  m.restore(r.end);actions.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),end);
  console.log(JSON.stringify([r.card,stop,terminal?.totalScore,peak,facts]));
  results.push({card:r.card,root:r.end,stop,terminal,facts,peak,end,actions});
 }finally{m.dispose();}
}
writeZ(process.argv[3],{results});
