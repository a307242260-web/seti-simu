'use strict';
const {open,readZ,writeZ,runCases}=require('./controlled-r3');
const d=readZ(process.argv[2]),r=d.rows.find(r=>r.label==='chong_7.webp'),m=open(r.start);
for(const x of r.actions.slice(0,20))m.apply(x.action);
const root=m.save();m.dispose();
const cases=[['default',()=>{}],['hold-now',h=>h.act('pass')]];
for(const [payer,income] of [['amiba_9.webp','chong_8.webp'],['chong_8.webp','amiba_9.webp']]){
 for(const after of ['buy','insert']){
  cases.push([payer+'/'+after,h=>{
   h.take(h.m.corner(payer));
   h.act('quick_trade',a=>a.summary.includes('3宣传'));
   h.take(h.m.pick('dlc_15.png'));
   if(after==='buy')return;
   h.take(h.m.corner('dlc_15.png'));h.act('place_data');h.act('choose_target',a=>a.target.target==='computer');
   h.act('choose_card',a=>a.summary==='收入 '+income);
  }]);
 }
}
writeZ(process.argv[3],runCases(root,cases));
