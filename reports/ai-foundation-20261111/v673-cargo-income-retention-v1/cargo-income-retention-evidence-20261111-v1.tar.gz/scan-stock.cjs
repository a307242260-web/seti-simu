'use strict';
const {open,readZ,writeZ,runCases}=require('./controlled-r3');
const d=readZ(process.argv[2]),r=d.rows.find(x=>x.label==='amiba_9.webp/insert'),m=open(r.start);
for(const x of r.actions.slice(0,6))m.apply(x.action);
const root=m.save(),first=m.menu(),pairs=[];
for(const a of first){
 m.restore(root);m.apply(a);
 for(const b of m.menu().filter(b=>b.target?.nebulaId===a.target.nebulaId))pairs.push([a,b]);
}
m.dispose();
const result=runCases(root,pairs.map(([a,b])=>[a.summary+' / '+b.summary,h=>{h.take(h.m.apply(a));h.take(h.m.apply(b));}]));
writeZ(process.argv[3],{root,...result});
