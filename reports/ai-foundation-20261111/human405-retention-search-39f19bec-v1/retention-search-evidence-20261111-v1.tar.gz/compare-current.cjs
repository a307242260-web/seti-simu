'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {open,readZ,writeZ}=require('./controlled-r3');
const [input,out,mode='exact']=process.argv.slice(2);
const src=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(src,module);
mod.filename=src;mod.paths=Module._nodeModulePaths(path.dirname(src));
let s=require('./reuse-yellow2.cjs')(require('./reuse-scan.cjs')(fs.readFileSync(src,'utf8'),require('./prior.cjs')));
if(mode==='count'){
 const anchor='      submissionCount += 1;\n      return { before, result };';
 assert.equal(s.split(anchor).length,2);
 s=s.replace(anchor,'      submissionCount += 1;\n      globalThis.remaining.push([current.family,current.summary,head?.type,session?.journal?.actions?.[0]?.action?.summary,current.actionId]);\n      return { before, result };');
}
mod._compile(s,src);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const rows=[],seatId='player-white';
for(const r of readZ(input)){
 const m=open(r.root),port=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
 try{
  globalThis.remaining=[];
  const q=createSearchAgent({analysisPort:port,seatId}).decide({seatId,legalActions:m.menu()}).search;
  assert.deepEqual(m.save(),r.root);
  const actual=JSON.parse(JSON.stringify(q));
  for(const k of ['actionId','value','realization','preparationDebt','complete','roots','lines','unresolved','selectionPlan','candidates','sharedPrefixGraph'])assert.deepEqual(actual[k],r.q[k],k);
  console.log(JSON.stringify([r.name,r.card,r.q.diagnostics.nativeExecutions,q.diagnostics.nativeExecutions,q.rootAndSearchMilliseconds]));
  rows.push({name:r.name,card:r.card,prior:r.q.diagnostics.nativeExecutions,q,root:r.root,profile:globalThis.remaining});
 }finally{port.close();m.dispose();}
}
writeZ(out,rows);
