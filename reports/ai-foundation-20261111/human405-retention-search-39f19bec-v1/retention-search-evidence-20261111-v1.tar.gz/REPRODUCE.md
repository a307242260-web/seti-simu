Run from the repository root, using Node 22 and the production source of 931ddada5 (AI source 39f19bec). Work in a fresh temporary output directory. Do not run the timed commands in parallel.

```sh
proof=/path/to/this/archive
out=$(mktemp -d)
orig=reports/ai-foundation-20261111/v673-standard-retention-frontier-v1/standard-retention-frontier-evidence-20261111-v1.tar.gz
tar -xOf "$orig" ./standard-stops-fourth-20261111-v1.json.gz > "$out/old-stops.json.gz"
node "$proof/first-decision-profile.cjs" "$out/old-stops.json.gz" "$out/profile.json.gz"
node "$proof/compare-current.cjs" "$out/profile.json.gz" "$out/exact.json.gz" count
node - "$proof" "$out" <<'NODE'
const [proof,out]=process.argv.slice(2),{readZ,writeZ}=require(proof+'/controlled-r3');
writeZ(out+'/probe-roots.json.gz',{rows:readZ(out+'/profile.json.gz').map(r=>({name:r.name,card:r.card,state:r.root,q:r.q}))});
NODE
SETI_SCAN_PRIOR="$proof/prior.cjs" node "$proof/prove-yellow2.cjs" "$out/probe-roots.json.gz" "$out/all-1250-witnesses.json.gz"
SETI_SCAN_PRIOR="$proof/prior.cjs" node "$proof/bind-joined.cjs" bound-move-join-route-yellow "$out/probe-roots.json.gz" "$out/wide-binding.json.gz"
SETI_SCAN_PRIOR="$proof/prior.cjs" node "$proof/bind-joined.cjs" bound-research-join-route-yellow "$out/probe-roots.json.gz" "$out/data-only.json.gz"
node "$proof/winner-paths.cjs" "$out/profile.json.gz" "$out/wide-binding.json.gz" "$out/path-proof.json.gz"
```

The archive contains all graphs and one replay sample per rule shape and root (18 samples). The verifier replays all 1,250 transitions and generates a larger archive. The path proof independently replays the explicit inputs; it labels an analytic tail as such and does not convert it into a terminal result. None of the candidate sources modifies the repository or submits a root decision.
