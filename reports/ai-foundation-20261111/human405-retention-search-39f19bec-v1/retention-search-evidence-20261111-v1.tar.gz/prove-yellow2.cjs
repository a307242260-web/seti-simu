'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const prepare=require('./reuse-scan.cjs');
const {open,readZ,writeZ}=require('./controlled-r3');
const [input,out]=process.argv.slice(2),src=path.resolve('randomizer/game/ai/analysis-port.js');
const mod=new Module(src,module);mod.filename=src;mod.paths=Module._nodeModulePaths(path.dirname(src));
const code=fs.readFileSync(src,'utf8');
let witnesses=[];
globalThis.captureProof=(kind,stored,action,target,child,raw,barrier)=>witnesses.push({kind,source:stored.envelope,action,target:target.envelope,
 legal:child.legalActions.map(a=>[a.actionId,a.family,a.target]),raw:raw?.map(a=>[a.actionId,a.family,a.target]),barrier});
globalThis.captureYellow=(s,a,t,c,p)=>globalThis.captureProof('yellow-landing',s,a,t,c,p?.inspection?.session?.decision?.choices,null);
const hooks=[
 ['        provedQuietSpecifiedScans++;',`        provedQuietSpecifiedScans++;
        const opt=taskSession.queue[0].payload.options;
        if(opt.mode==="any"||taskSession.queue[1]?.type===scienceSession.EFFECT_TYPES.SCAN_STEP)
          globalThis.captureProof(opt.mode==="any"?"B9-final":"scan-public-prefix",stored,requested,nodes.get(child),child,
            fixedScan.inspection.session?.decision?.choices, fixedScan.barrier||taskSession.irreversibleBarrier);`]
];
let decorated=require('./reuse-yellow2.cjs')(prepare(code,require(process.env.SETI_SCAN_PRIOR)),true);
for(const [anchor,replacement] of hooks){assert.equal(decorated.split(anchor).length,2);decorated=decorated.replace(anchor,replacement);}
mod._compile(decorated,src);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
function normalized(envelope){
 const e=structuredClone(envelope);e.committedState=JSON.parse(e.committedState);
 const session=e.session?.session;if(!session)return e;
 session.undoFrames=[]; // Search forks do not export UI undo; verify no undo was legal below.
 const visit=x=>{
  if(typeof x==='string')return x.replaceAll(session.sessionId,'@session');
  if(Array.isArray(x))return x.map(visit);
  if(x&&typeof x==='object')return Object.fromEntries(Object.entries(x).map(([k,v])=>[k,visit(v)]));
  return x;
 };
 e.session=visit(e.session);
 return e;
}
const seats='player-white',results=[];
for(const row of readZ(input).rows.map(r=>({...r,root:r.state}))){
 witnesses=[];
 const m=open(row.root),port=createAnalysisPort({composition:m.c,seatId:seats,maxCacheEntries:0});
 try{
  const agent=createSearchAgent({seatId:seats,analysisPort:port});
  const q=agent.decide({seatId:seats,legalActions:m.menu()}).search;
  const checkpoint=agent.createCheckpoint();
  assert.deepEqual(m.save(),row.root);
  const archived=JSON.parse(JSON.stringify(q));
  for(const field of ['actionId','value','realization','preparationDebt','complete','roots','lines','unresolved','selectionPlan','candidates','sharedPrefixGraph'])assert.deepEqual(archived[field],row.q[field],field);
  const counts={};
  for(const w of witnesses){
   assert(m.c.lifecycle.restore(w.source).ok);
   assert.deepEqual(normalized(m.save()),normalized(w.source));
   const a=m.menu().find(a=>a.actionId===w.action.actionId),d=m.c.inspect().session?.decision;
   assert(a&&d);assert.deepEqual(a.target,w.action.target);
   const r=m.c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a});
   assert(r.ok);
   if(w.barrier){
    const real=r.irreversibleBarrier||m.save().session?.session?.irreversibleBarrier;
    if(real)assert.deepEqual(real,w.barrier);
    else assert.equal(w.kind,"B9-final");
   }else assert(!r.irreversibleBarrier);
   assert.deepEqual(normalized(m.save()),normalized(w.target),w.kind+' '+w.action.summary);
   const menu=m.menu().map(a=>[a.actionId,a.family,a.target]);
   assert(!menu.some(a=>a[1]==='undo'));
   if(w.raw)assert.deepEqual(menu,w.raw);
   assert(w.legal.every(a=>menu.some(b=>JSON.stringify(a)===JSON.stringify(b))));
   counts[w.kind]=(counts[w.kind]||0)+1;
  }
  assert.equal(Object.values(counts).reduce((a,b)=>a+b,0),row.q.diagnostics.nativeExecutions-q.diagnostics.nativeExecutions);
  results.push({root:row.root,counts,n:q.diagnostics.nativeExecutions,actionId:q.actionId,checkpoint,witnesses});
  console.log(JSON.stringify([counts,q.diagnostics.nativeExecutions,Boolean(checkpoint)]));
 }finally{port.close();m.dispose();}
}
writeZ(out,{results});
