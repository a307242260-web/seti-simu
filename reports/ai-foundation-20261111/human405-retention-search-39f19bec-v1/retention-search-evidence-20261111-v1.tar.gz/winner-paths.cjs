'use strict';
const assert=require('node:assert/strict');
const {readZ,writeZ,open}=require('./controlled-r3');
const [baseline,bound,out]=process.argv.slice(2),rows=[];
const result=[readZ(baseline),readZ(bound)];
for(const [i,entry] of result[0].entries()){
 const origins=open(entry.root);const names=new Map(origins.menu().map(x=>[x.actionId,x.summary]));origins.dispose();
 for(const [j,r] of result.entries()){
  const q=r[i].q,lines=new Map(q.lines.map(l=>[l.node,l]));
  const relevant=q.roots.filter(t=>names.get(t.actionId)==='深空探测 1x 行动'||t.actionId===q.actionId||t.value===q.value);
  for(const root of relevant){
   const path=[],visited=new Set();
   let cur=lines.get(0).edges.find(e=>e.actionId===root.actionId&&e.target===root.target);
   assert(cur,root.actionId);
   while(cur){
    assert(!visited.has(cur.target));visited.add(cur.target);
    path.push(cur);
    const next=lines.get(cur.target);
    if(!next?.edges?.length)break;
    cur=next.edges.find(e=>lines.get(e.target)?.value===next.value);
    if(!cur)break;
   }
   const m=open(entry.root),replayed=[],mode=j?'bound':'original';
   let analytic=null,ledger=null;
   try{
    for(const edge of path){
     if(!edge.steps){
      assert(edge.turnTailPlanValue||edge.incomePlanValue,'unexplained abstract edge');
      assert.equal(edge,path.at(-1));
      analytic=edge.turnTailPlanValue||edge.incomePlanValue;
      assert(m.menu().some(x=>x.actionId===edge.actionId));
      break;
     }
     for(const id of edge.steps){
      const a=m.menu().find(x=>x.actionId===id);assert(a,id);replayed.push(a);m.apply(a);
     }
    }
    const f=m.facts();
    ledger={wallet:f.wallet,income:f.income,hand:f.hand,computer:f.computer,blue:f.blue,rng:f.rng};
   }finally{m.dispose();}
   const summary=replayed.map(a=>a.summary);
   console.log(JSON.stringify({name:entry.name,card:entry.card,mode,value:root.value,root:names.get(root.actionId),analytic:analytic?.proof,summary}));
   rows.push({name:entry.name,card:entry.card,mode,value:root.value,root,rootSummary:names.get(root.actionId),path,replayed,analytic,ledger,summary});
  }
 }
}
writeZ(out,{rows});
