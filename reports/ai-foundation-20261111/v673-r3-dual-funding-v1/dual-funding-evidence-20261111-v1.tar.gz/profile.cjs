'use strict';
const path=require('node:path'),assert=require('node:assert/strict'),fs=require('node:fs'),Module=require('node:module');
const {readZ,writeZ,open}=require('./controlled-r3');
const source=path.resolve('randomizer/game/ai/analysis-port.js'),m=new Module(source,module);
m.filename=source;m.paths=Module._nodeModulePaths(path.dirname(source));
const text=fs.readFileSync(source,'utf8'),anchor='      submissionCount += 1;\n      return { before, result };';
assert.equal(text.split(anchor).length,2);
m._compile(text.replace(anchor,`      submissionCount += 1;
      globalThis.__cargoProfile.push([current.family,current.summary,head?.type,session?.journal?.actions?.[0]?.action?.summary,current.actionId]);
      return { before, result };`),source);
const {createAnalysisPort}=m.exports;
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const d=readZ(process.argv[2]),rows=[];
for(const r of d.results.filter(r=>typeof r.stop==='object')){
 const m=open(r.end),seatId='player-white',port=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
 try{
  globalThis.__cargoProfile=[];
  const q=createSearchAgent({analysisPort:port,seatId}).decide({seatId,legalActions:m.menu()}).search;
  assert.deepEqual(m.save(),r.end);
  const counts={};
  for(const [family,summary,head,origin] of globalThis.__cargoProfile){
   const k=JSON.stringify([family,summary,head,origin]);counts[k]=(counts[k]||0)+1;
  }
  const top=Object.entries(counts).sort((a,b)=>b[1]-a[1]);
  console.log(JSON.stringify([r.name,r.card,q.diagnostics.nativeExecutions,q.rootAndSearchMilliseconds,top.slice(0,15)]));
  rows.push({card:r.card,name:r.name,root:r.end,profile:globalThis.__cargoProfile,top,q});
 }finally{port.close();m.dispose();}
}
writeZ(process.argv[3],rows);
