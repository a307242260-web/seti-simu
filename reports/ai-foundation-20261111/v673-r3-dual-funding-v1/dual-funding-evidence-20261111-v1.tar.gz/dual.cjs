'use strict';
const assert=require('node:assert/strict');
const {open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),d=readZ(dir+'/audit-20261111-v1.json.gz'),root=d.roots[179],off=new Map(d.ledger.map(x=>[x.i,x.input]));
const fixed=(h,i)=>h.take(h.m.apply(off.get(i)));
const a5='amiba_5.webp',a2='amiba_2.webp',b16='b_16.webp',d25='dlc_25.png';
const pay=(h,ids)=>{
 h.act('quick_trade',q=>q.target.tradeId==='cards-for-credit');
 for(const id of ids)h.act('choose_payment',q=>q.summary===id);
 h.act('choose_payment',q=>q.summary.startsWith('确认弃牌'));
};
const fill=(h,n)=>{for(let i=1;i<=n;i++){h.act('place_data');h.act('choose_target',a=>a.summary==='第一排放置位 '+i);}};
const path=(h,symbol,market,mode,move,red='data')=>{
 fixed(h,179);
 if(symbol==='publicity')h.act('choose_target',a=>a.target.slotId==='blue_3');else fixed(h,180);
 for(let i=181;i<=235;i++)fixed(h,i);
 h.take(h.m.pick(market));
 if(red==='point')h.act('choose_target',a=>a.summary.includes('4分'));
 else if(red==='data')h.act('choose_target',a=>a.summary.includes('1数据'));
 else h.take(h.m.apply(h.m.menu()[0]));
 h.cut('regional');
 h.act('end_turn');h.act('analyze');
 h.act('choose_target',a=>a.target.speciesId==='amiba'&&a.target.position===3);
 h.act('choose_card',a=>a.summary.includes('科学论文'));h.cut('visible');
 if(mode==='none')return;
 if(mode==='swap-late'){
  h.take(...h.m.swap(a2,'dlc_14.png'));
  pay(h,[d25,market]);
 }else{
  pay(h,[a2,market]);
 }
 h.act('end_turn');h.take(h.m.play(b16));
 h.act('choose_target',a=>a.summary.endsWith(move));
 h.act('choose_target',a=>a.target.nebulaId==='sector-1-a');
 h.cut('scan');
};
const cases=[];
for(const symbol of ['publicity','point'])for(const market of ['dlc_17.png','dlc_15.png','dlc_16.png'])for(const mode of ['no-swap','swap-late']){
 cases.push([symbol+'/'+market+'/'+mode,h=>path(h,symbol,market,mode,'顺时针',symbol==='point'?'point':'data')]);
}
for(const move of ['向外','结束移动','逆时针'])cases.push(['publicity/dlc17/no swap/'+move,h=>path(h,'publicity','dlc_17.png','no-swap',move)]);
cases.push(['publicity/dlc17 release after analysis',h=>path(h,'publicity','dlc_17.png','none','向外')]);
writeZ(out,runCases(root,cases));
