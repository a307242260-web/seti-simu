'use strict';
const assert=require('node:assert/strict');
const {open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),d=readZ(dir+'/dual-20261111-v1.json.gz');
const a2='amiba_2.webp',b16='b_16.webp',d25='dlc_25.png';
const cases=[];
const piece=(h,k)=>{
 h.act('place_data');h.act('choose_target',a=>a.summary==='第一排放置位 '+k);
};
const pay=(h,ids)=>{
 h.act('quick_trade',q=>q.target.tradeId==='cards-for-credit');
 for(const id of ids)h.act('choose_payment',q=>q.summary===id);
 h.act('choose_payment',q=>q.summary.startsWith('确认弃牌'));
};
for(const card of ['dlc_15.png','dlc_16.png','dlc_14.png'])for(const move of ['顺时针','向外'])for(const mode of ['auto','keep','pool']){
 cases.push([card+'/'+move+'/'+mode,h=>{
  piece(h,1);piece(h,2);h.cut('public-credit');
  h.act('quick_trade',q=>q.target.tradeId==='publicity-for-card');h.take(h.m.pick(card));
  pay(h,[card,'dlc_17.png']);
  h.act('end_turn');h.take(h.m.play(b16));
  h.act('choose_target',a=>a.summary.endsWith(move));
  h.act('choose_target',a=>a.target.nebulaId==='sector-1-a');
  h.cut('paid');
  if(mode==='auto')return;
  piece(h,3);piece(h,4);h.act('choose_card',a=>a.summary==='收入 '+d25);
  if(mode==='pool')h.take(h.m.corner(a2));
  h.act('end_turn');h.cut('pass');
  // PASS itself remains autonomous. In this cashless state no other paid action is available.
 }]);
}
const root=d.rows.find(r=>r.label==='publicity/dlc17 release after analysis').checkpoints.visible.state;
writeZ(out,runCases(root,cases));
