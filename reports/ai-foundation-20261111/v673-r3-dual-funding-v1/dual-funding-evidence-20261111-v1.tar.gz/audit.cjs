'use strict';
const path=require('node:path'),{open,short,writeZ}=require('./controlled-r3');
const r=require(path.resolve('reports/research/d3183131.cbd73e00.quick-400.json')),v=require(path.resolve(r.savePath)),e=require(path.resolve(r.roundEnds[0].checkpointPath));
const m=open(e.coreState.compositionEnvelope),roots={},ledger=[];
const s=m.state();
for(let i=r.roundEnds[0].beforeInput;i<=258;i++){
 const f=m.facts(),row={i,round:f.round,turn:f.turn,main:f.main,summary:short(m),token:f.wallet.additionalPublicScan,
  sectors:Object.fromEntries(Object.entries(m.state().data.nebulae).map(([k,q])=>[k,q.tokens.map(t=>t.replacedByPlayerColor?.[0]||'.').join('')])),
  wins:m.state().data.sectorSettlements.winsByPlayerId?.['player-white'],
  input:v.replaySteps[i-1].action};
 ledger.push(row);
 if([72,74,75,76,78,84,104,125,128,136,138,139,145,172,179,186,189,193,203,209,211,235,242,258].includes(i))roots[i]=m.save();
 m.apply(row.input);
}
writeZ(process.argv[2],{roots,ledger});
