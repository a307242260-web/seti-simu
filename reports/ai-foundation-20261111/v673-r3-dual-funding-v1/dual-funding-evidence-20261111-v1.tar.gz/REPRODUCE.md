# V673 dual funding controls
From clean Production source cbd73e00c with the registered research JSON,
round-one checkpoint and replay save. Set p to the absolute extraction path.
Scripts read the archived checkpoints; new outputs do not overwrite them.
```sh
node "$p/audit.cjs" "$p/replay-audit.json.gz"
node "$p/dual.cjs" "$p" "$p/replay-dual.json.gz"
node "$p/retain.cjs" "$p" "$p/replay-retain.json.gz"
node "$p/swap-blue.cjs" "$p" "$p/replay-swap-blue.json.gz"
node "$p/fourth.cjs" "$p" "$p/replay-fourth.json.gz"
node "$p/blue-fourth.cjs" "$p" "$p/replay-blue-fourth.json.gz"
node "$p/profile.cjs" "$p/fourth-20261111-v1.json.gz" "$p/replay-profile.json.gz"
node "$p/try-b9.cjs" "$p/profile-20261111-v1.json.gz" "$p/replay-b9.json.gz"
```
Timing can vary. All moves are gated before native submission. The last two
commands diagnose the stopped decision and do not commit any game inputs.
