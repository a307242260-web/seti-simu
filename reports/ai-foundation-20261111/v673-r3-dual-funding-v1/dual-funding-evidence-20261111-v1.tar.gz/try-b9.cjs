"use strict";
const fs=require("node:fs"),path=require("node:path"),assert=require("node:assert/strict"),Module=require("node:module");
const {open,readZ,writeZ}=require("./controlled-r3");
const src=path.resolve("randomizer/game/ai/analysis-port.js"),mod=new Module(src,module);
mod.filename=src;mod.paths=Module._nodeModulePaths(path.dirname(src));
let s=fs.readFileSync(src,"utf8");
const anchor='      if(s?.phase!=="awaiting_input"||s.failure||s.interruptContext||s.undoFrames.length\n        ||head.type!==types.SCAN_STEP||head.kind!=="decision"||head.ownerId!==seatId||head.allowQuickActions||!simple(opts)';
assert.equal(s.split(anchor).length,2);
s=s.replace(anchor,`      const start=s?.journal.actions[0]?.action;
      const lastB9=s?.queue.length===2&&s.irreversibleBarrier?.code==="hidden_card_reveal"
        &&opts?.mode==="any"&&opts.gainData===true&&opts.sameSectorRemaining===1
        &&Object.keys(opts).every(k=>["mode","gainData","label","sameSectorRemaining"].includes(k))
        &&start?.family==="play_card"&&rootObservation.selfState.hand
          .some(c=>!c.hidden&&c.id===start.target.cardInstanceId&&c.cardId==="b_9.webp")
        &&s.workingState.cards.publicCards.every(Boolean);
`+anchor+'&&!lastB9');
mod._compile(s,src);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve("randomizer/game/ai/search-agent"));
const seats="player-white",rows=[];
for(const r of readZ(process.argv[2])){
 const m=open(r.root),port=createAnalysisPort({composition:m.c,seatId:seats,maxCacheEntries:0});
 try{
  const q=createSearchAgent({seatId:seats,analysisPort:port}).decide({seatId:seats,legalActions:m.menu()}).search;
  assert.deepEqual(m.save(),r.root);
  const actual=JSON.parse(JSON.stringify(q));
  for(const k of ["actionId","value","complete","roots","lines","unresolved","selectionPlan","candidates","sharedPrefixGraph"])assert.deepEqual(actual[k],r.q[k],k);
  console.log(JSON.stringify([r.name,r.card,r.q.diagnostics.nativeExecutions,q.diagnostics.nativeExecutions,q.rootAndSearchMilliseconds]));
  rows.push({name:r.name,card:r.card,prior:r.q.diagnostics.nativeExecutions,q,root:r.root});
 }finally{port.close();m.dispose();}
}
writeZ(process.argv[3],{rows});
