'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,writeZ}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [file,out]=process.argv.slice(2),r=readZ(file).find(x=>x.stop?.kind==='gate');
const m=open(r.end),root=m.save(),legal=m.menu(),port=createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:'player-white',analysisPort:port}).decide({seatId:'player-white',legalActions:legal}).search;
 assert.deepEqual(m.save(),root);
 const active=q.analysis;
 const counts=Object.fromEntries(Object.entries(active).filter(([k,v])=>typeof v==='number'&&v));
 console.log(q.complete,q.value,q.diagnostics.nativeExecutions,q.rootAndSearchMilliseconds,JSON.stringify(counts));
 console.log(Object.keys(q.diagnostics),Object.keys(q.analysis));
 writeZ(out,{root,legal,q});
}finally{port.close();m.dispose();}
