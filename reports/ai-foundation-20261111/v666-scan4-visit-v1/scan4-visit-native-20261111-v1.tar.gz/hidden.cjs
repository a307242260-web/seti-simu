'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,writeZ}=require('./controlled-r3');
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const [source,out]=process.argv.slice(2);
const root=readZ(source).root,alternate=structuredClone(root);
const s=JSON.parse(alternate.committedState);
assert.equal(alternate.session,null);
const deck=s.cards.drawPileCardIds;
assert(deck[0]&&deck[1]&&deck[0]!==deck[1]);
[deck[0],deck[1]]=[deck[1],deck[0]];
alternate.committedState=createStateStore(s).serialize().serialized;
const results=[root,alternate].map(e=>{
 const m=open(e);
 try {
  const visible=m.owner('player-white'),legal=m.menu(),rng=m.facts().rng;
  const q=m.automatic();
  assert(q.complete&&q.n<=256&&q.ms<=600,JSON.stringify([q.complete,q.n,q.ms]));
  assert.deepEqual(m.save(),e);
  return {e,visible,legal,rng,chosen:q.a,value:q.value,roots:q.roots,n:q.n,ms:q.ms};
 }finally{m.dispose();}
});
for(const key of ['visible','legal','rng','chosen','value','roots','n'])assert.deepEqual(results[0][key],results[1][key],key);
writeZ(out,results);
console.log(JSON.stringify(results.map(r=>[r.chosen.summary,r.value,r.n,r.ms])));
