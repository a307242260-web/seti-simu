'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {open,readZ,writeZ}=require('./controlled-r3');
const [beforeFile,afterFile,out]=process.argv.slice(2);
const before=readZ(beforeFile),after=readZ(afterFile),file=path.resolve('randomizer/game/ai/analysis-port.js');
const mod=new Module(file,module);mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const anchor='        if(requested.target.mode==="move")provedScan4QuietMoves++;';
const code=fs.readFileSync(file,'utf8');assert.equal(code.split(anchor).length,2);
const witnesses=[];
globalThis.recordArrivalProof=(source,action,target,child,barrier)=>witnesses.push({source:source.envelope,action,target:target.envelope,
 legal:child.legalActions.map(a=>[a.actionId,a.family,a.target]),barrier});
mod._compile(code.replace(anchor,'        if(requested.target.mode==="move"){provedScan4QuietMoves++;globalThis.recordArrivalProof(stored,requested,nodes.get(child),child,scanAction.barrier);}'),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
function normalized(envelope){
 const e=structuredClone(envelope);
 e.committedState=JSON.parse(e.committedState);
 const session=e.session?.session;
 if(!session)return e;
 session.undoFrames=[];
 const visit=x=>{
  if(typeof x==='string')return x.replaceAll(session.sessionId,'@session');
  if(Array.isArray(x))return x.map(visit);
  if(x&&typeof x==='object')return Object.fromEntries(Object.entries(x).map(([k,v])=>[k,visit(v)]));
  return x;
 };
 e.session=visit(e.session);
 return e;
}
const fields=['actionId','value','realization','preparationDebt','complete','roots','lines','unresolved','selectionPlan','candidates','sharedPrefixGraph'];
for(const field of fields)assert.deepEqual(before.q[field],after.q[field],field);
assert.equal(before.q.diagnostics.nativeExecutions-after.q.diagnostics.nativeExecutions,50);
assert.deepEqual(before.root,after.root);
const m=open(before.root),port=createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:'player-white',analysisPort:port}).decide({seatId:'player-white',legalActions:m.menu()}).search;
 assert.deepEqual(m.save(),before.root);
 assert.equal(witnesses.length,50);
 const archived=JSON.parse(JSON.stringify(q));
 for(const field of fields)assert.deepEqual(archived[field],after.q[field],field);
 const types={};
 for(const [i,w] of witnesses.entries()){
  assert(m.c.lifecycle.restore(w.source).ok);
  assert.deepEqual(normalized(m.save()),normalized(w.source));
  const choice=m.menu().find(a=>a.actionId===w.action.actionId),d=m.c.inspect().session?.decision;
  assert(choice&&d);assert.deepEqual(choice.target,w.action.target);
  const result=m.c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice});
  assert(result.ok);assert.deepEqual(result.irreversibleBarrier,w.barrier);
  try{assert.deepEqual(normalized(m.save()),normalized(w.target));}
  catch(error){console.error(i,w.action.target,error.message.slice(0,3500));throw error;}
  const menu=new Set(m.menu().map(a=>JSON.stringify([a.actionId,a.family,a.target])));
  assert(w.legal.every(x=>menu.has(JSON.stringify(x))));
  const key=[w.source.session.session.journal.actions[0].action.family,w.target.session?.session?.queue[0]?.type??'committed'].join('/');
  types[key]=(types[key]??0)+1;
 }
 console.log(JSON.stringify({witnesses:witnesses.length,types,native:q.diagnostics.nativeExecutions}));
 writeZ(out,{root:before.root,witnesses,types});
}finally{port.close();m.dispose();}
