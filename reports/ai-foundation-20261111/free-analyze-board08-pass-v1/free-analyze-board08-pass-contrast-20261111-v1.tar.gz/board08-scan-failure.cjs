'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const f=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(f,module);mod.filename=f;mod.paths=Module._nodeModulePaths(path.dirname(f));
const a='      const { before, result } = executeCurrent(requested);',s=fs.readFileSync(f,'utf8');
assert.equal(s.split(a).length,2);
mod._compile(s.replace(a,`      let execution;
      try{execution=executeCurrent(requested);}catch(e){
        globalThis.failedNative={action:requested,envelope:stored.envelope,error:e.message};throw e;
      }
      const {before,result}=execution;`),f);mod.loaded=true;require.cache[f]=mod;
const {open,writeZ}=require('./controlled-r3'),[input,out]=process.argv.slice(2),root=JSON.parse(fs.readFileSync(input)).coreState.compositionEnvelope,m=open(root);
const moves=[];let cached,failed;
try{
 moves.push(m.act('scan'));
 for(let i=0;i<160;i++){
  const a=m.menu()[0];if(a.actorId!=='player-white'){m.advanceOpponents(moves);continue;}
  if(m.facts().round===4&&!m.c.inspect().session)break;
  try{
   const q=m.automatic(cached);
   if(!q.complete||q.n>256||q.ms>600){failed={reason:'gate',n:q.n,ms:q.ms};break;}
   cached=q.checkpoint;moves.push(m.apply(q.a));
  }catch(e){
   failed={reason:e.message,action:globalThis.failedNative?.action?.summary,queue:globalThis.failedNative?.envelope.session?.session?.queue.map(x=>x.type)};
   break;
  }
 }
 const end=m.save();
 console.log({steps:moves.length,round:m.facts().round,turn:m.facts().turn,failed});
 writeZ(out,{root,end,moves,failed,failedNative:globalThis.failedNative});
}finally{m.dispose();}
