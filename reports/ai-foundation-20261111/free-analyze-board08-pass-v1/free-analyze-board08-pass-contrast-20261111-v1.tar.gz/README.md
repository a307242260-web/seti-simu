# 第 8 盘第二轮 PASS 的原生同根对照
从项目根运行 board08-host-contrast.cjs，第一参数使用正式第 8 盘记录 0aef5774.532563ef.full.json 的 .round-end-2.checkpoint.json，第二参数是新的 gzip 文件。保留同一原生状态、RNG 和其他三席 PASS 策略；仅首个动作可被固定。
board08-scan-failure.cjs 可在旧源码 532563ef4 上从相同根复现失败。证据内有失败的具体原生提交，以及修复后三条路线的行动、轮末和终局。
