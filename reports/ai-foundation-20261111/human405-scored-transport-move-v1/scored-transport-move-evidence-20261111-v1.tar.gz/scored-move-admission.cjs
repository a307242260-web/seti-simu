'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [input,out]=process.argv.slice(2),r=readZ(input).rows[1],root=r.cuts.beforeFirst,m=open(root),actions=[],checks=[];
let cp,stop;
try{
 for(let i=0;i<140;i++){
  if(m.menu()[0].actorId!=='player-white'){const a=[];m.advanceOpponents(a);actions.push(...a.map(action=>({action,passive:true})));continue;}
  const q=m.automatic(cp);
  if(!q.complete||q.n>256||q.ms>600){stop={action:q.a?.summary,n:q.n,ms:q.ms};break;}
  if(i<2){
   const exact=r.accepted[55+i];assert.equal(q.a.actionId,exact.actionId);
   const before=m.save(),cold=m.automatic();assert.equal(cold.a.actionId,q.a.actionId);assert.deepEqual(m.save(),before);
   checks.push({before,choice:q.a,n:q.n,ms:q.ms,cold:cold.n});
  }
  if(q.a.family==='pass'){stop='settled';break;}
  cp=q.checkpoint;actions.push({action:m.apply(q.a),n:q.n,ms:q.ms});
 }
 assert(stop);
 const end=m.save(),assets=short(m);
 m.restore(root);actions.forEach(r=>m.apply(r.action));assert.deepEqual(m.save(),end);
 const peak=[Math.max(...actions.map(a=>a.n||0)),Math.max(...actions.map(a=>a.ms||0))];
 writeZ(out,{root,end,assets,actions,checks,stop,peak});
 console.log(JSON.stringify({stop,assets,peak,actions:actions.length}));
}finally{m.dispose();}
