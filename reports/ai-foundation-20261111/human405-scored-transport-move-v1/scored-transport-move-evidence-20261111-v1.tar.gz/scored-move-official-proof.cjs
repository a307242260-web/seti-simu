'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const [base,newer]=process.argv.slice(2),read=p=>JSON.parse(fs.readFileSync(p)),traces=p=>fs.readFileSync(p+'.decisions.jsonl','utf8').trim().split('\n').map(JSON.parse);
const r=read(newer),prior=read(base),a=traces(newer),b=traces(base);
const digest=t=>({actionId:t.actionId,value:t.search?.value,n:t.search?.diagnostics?.nativeExecutions,complete:t.search?.complete});
assert.equal(r.steps,259);assert.equal(a.length,236);assert.deepEqual(a.map(digest),b.map(digest));
assert.equal(r.stopReason,'first-three-rounds-settled');assert.deepEqual(r.roundEnds.map(x=>x.score),[15,48,118]);
const {createEnvironment,initialize}=require(path.resolve('tools/research-human405-round1'));
const env=createEnvironment({},r.scenario),checkpoints=r.roundEnds.map(x=>read(x.checkpointPath));
try{
 assert.equal(initialize(env,checkpoints[0].config,r.scenario).length,23);
 const byStep=new Map(r.roundEnds.map((x,i)=>[x.beforeInput,i]));
 for(const [i,t] of a.entries()){
  const step=i+24,at=byStep.get(step);
  if(at!==undefined){
   const original=read(prior.roundEnds[at].checkpointPath).coreState.compositionEnvelope;
   assert.deepEqual(checkpoints[at].coreState.compositionEnvelope,original);
   assert.deepEqual(env.createCheckpoint().coreState.compositionEnvelope,original);
  }
  const m=env.legalActions().find(x=>x.actionId===t.actionId);assert(m,t.actionId);assert(env.step(m).ok,t.actionId);
 }
 const settled=env.createCheckpoint().coreState.compositionEnvelope;
 const last=read(r.savePath),oldLast=read(prior.savePath);
 assert.equal(JSON.parse(settled.committedState).turn.roundNumber,4);
 assert.equal(settled.committedState,last.committedState);
 assert.equal(last.committedState,oldLast.committedState);
 assert.deepEqual(settled.session,last.session);
 const searches=a.filter(t=>t.search);
 const n=Math.max(...searches.map(t=>t.search.diagnostics.nativeExecutions));
 const ms=Math.max(...searches.map(t=>t.search.rootAndSearchMilliseconds));
 assert(n<=256&&ms<=600);
 console.log(JSON.stringify({source:r.gitCommit,rounds:r.roundEnds.map(x=>x.score),formalInputs:r.steps,independentlyReplayed:a.length,searches:searches.length,peakInputs:n,peakMs:ms,wallMs:r.wallMs,scoreSearchParity:true,allEnvelopesAndRngExact:true}));
}finally{env.dispose();}
