'use strict';
const assert=require('node:assert/strict');
function sub(s,a,b){assert.equal(s.split(a).length,2,a);return s.replace(a,b);}
module.exports=(s,witness)=>{
 const before=`    function previewQuietCurrencyTrade(stored,action) {
      // Leave card selection and its menu to the rule engine. Only settle
      // the already chosen, known pair when payment cannot open an effect.
      if(!resourcePlanning||action.family!=="choose_payment"||action.target?.confirm!==true)return null;`;
 s=sub(s,before,`    function quietCurrencyTradeSource(stored,action) {
      if(!resourcePlanning||action.family!=="choose_payment")return null;`);
 s=sub(s,'        ||pending.selected?.length!==2||pending.selected[0]===pending.selected[1]',
  '        ||!Array.isArray(pending.selected)||pending.selected.length>2||new Set(pending.selected).size!==pending.selected.length');
 const at=`      const known=knownCards(stored.envelope);
      if(pending.selected.some(id=>!known.has(id)))return null;
      const player={...p,hand:[...p.hand],resources:{...p.resources},blueBonusResources:{...p.blueBonusResources}};`;
 s=sub(s,at,`      const known=knownCards(stored.envelope);
      return pending.selected.some(id=>!known.has(id))?null:{session,head,pending,source,p,known,tradeId};
    }

    function previewQuietCurrencyTradeSelection(stored,action){
      if(action.target?.kind!=="discard-hand-card"||stored.informationBarrier)return null;
      const entry=quietCurrencyTradeSource(stored,action);
      if(!entry)return null;
      const {session:s,head,pending,source,p,known,tradeId}=entry,id=action.target.cardInstanceId;
      const selected=[...pending.selected],index=selected.indexOf(id);
      if(!known.has(id)||!p.hand.some(c=>c.id===id)||index<0&&selected.length===2)return null;
      if(index<0)selected.push(id);else selected.splice(index,1);
      const event={type:"quick_trade_discard_selection",tradeId,playerId:seatId,cardInstanceId:id,selected};
      if(cardEffects.collectMatchingTriggers(p,event).length)return null;
      const offered=head.payload.choices.filter(a=>!a.target?.confirm);
      if(offered.length!==p.hand.length||offered.some((a,i)=>a.target?.kind!=="discard-hand-card"
        ||a.target.cardInstanceId!==p.hand[i].id||a.family!=="choose_payment"||!known.has(a.target.cardInstanceId)))return null;
      const choices=offered.map(a=>a.presentation?{...a,presentation:{...a.presentation,selected:selected.includes(a.target.cardInstanceId)}}:a);
      if(selected.length===2)choices.push(...scienceSession.formalizeChoices(source,seatId,[{
        family:"choose_payment",target:{kind:"confirm",confirm:true},payload:{},summary:"确认弃牌（2/2）",
      }]));
      const j=s.journal,cursor=j.replay.length,revision=s.revision+1,nextEffectSequence=s.nextEffectSequence+1,nextGroupSequence=s.nextGroupSequence+1;
      const effect={effectId:head.effectId,groupId:head.groupId,groupKind:head.groupKind,type:head.type,revision};
      const decision={decisionId:head.effectId,decisionVersion:s.revision,ownerId:seatId,choice:action};
      const checkpoint=stored.envelope.session;
      const session=freeze({...checkpoint,replayCursor:cursor+1,session:{...s,revision,nextEffectSequence,nextGroupSequence,
        queue:[{...head,effectId:s.sessionId+":effect:"+nextEffectSequence,groupId:s.sessionId+":group:"+nextGroupSequence,
          source:{parentEffectId:head.effectId,priority:"direct"},payload:{choices,decisionContext:{...pending,selected}}}],
        journal:{...j,decisions:[...j.decisions,decision],events:[...j.events,event],effects:[...j.effects,effect],
          replay:[...j.replay,{cursor,kind:"decision",confirmed:true,...decision}]}}});
      return {envelope:withEnvelopeSession(stored.envelope,session),inspection:{phase:"awaiting_input",session:{decision:{choices}}}};
    }

    function previewQuietCurrencyTrade(stored,action) {
      if(action.target?.confirm!==true)return null;
      const entry=quietCurrencyTradeSource(stored,action);
      if(!entry||entry.pending.selected.length!==2)return null;
      const {session,head,pending,source,p,tradeId}=entry;
      const player={...p,hand:[...p.hand],resources:{...p.resources},blueBonusResources:{...p.blueBonusResources}};`);
 const anchor='      const currencyTrade=previewQuietCurrencyTrade(stored,requested);';
 s=sub(s,anchor,`      const currencySelection=previewQuietCurrencyTradeSelection(stored,requested);
      if(currencySelection){
        const control=stored.resourceControl&&resourceStep(node,stored.resourceControl.goal,stored.resourceControl.operation).kind!=="complete"?stored.resourceControl:null;
        const child=finishChild({session:null},{},movementPlanning?nextMovementIntent(node,requested):null,
          control,stored.informationBarrier,requested,stored,currencySelection);
${witness?'        globalThis.dataProof.push({kind:"trade-select",source:stored.envelope,target:currencySelection.envelope,action:requested,raw:currencySelection.inspection.session.decision.choices});\n':''}        return rememberPrefix(key,node,actionId,remember(key,child));
      }
`+anchor);
 return s;
};
