'use strict';
const assert=require('node:assert/strict');
function sub(s,a,b){assert.equal(s.split(a).length,2,a);return s.replace(a,b);}
module.exports=(s,witness)=>{
 const needle='!(t.roundNumber===3&&quietEarlySameSeatHandover(state))';
 const targets=['quietDataMenuSource','previewQuietFinalDataPlacement','previewFixedResearchPick','previewFixedResearchSelection'];
 for(const name of targets){
  const a=s.indexOf('    function '+name+'('),b=s.indexOf('    function ',a+15),r=s.slice(a,b);assert(a>=0&&b>a);
  const changed=name==='previewFixedResearchSelection'
    ?sub(r,'const quietRoundThree=t.roundNumber===3&&quietEarlySameSeatHandover(state);','const quietRoundThree=quietEarlySameSeatHandover(state);')
    :sub(r,needle,'!quietEarlySameSeatHandover(state)');
  s=s.slice(0,a)+changed+s.slice(b);
 }
 if(witness){
  const a='        provedFinalDataMenuInputs++;';
  s=sub(s,a,a+`\n        if(readIdentityState(stored.envelope).turn.roundNumber===2)
          globalThis.dataProof.push({kind:"menu",source:stored.envelope,target:menuPreview,action:requested,raw:choices});`);
  const b='        const child = finishProvedCommittedState(node, stored, requested, state);\n        return rememberPrefix(key,node,actionId,remember(key,child));';
  s=sub(s,b,b.split('\n')[0]+`\n        if(readIdentityState(stored.envelope).turn.roundNumber===2)
          globalThis.dataProof.push({kind:"placement",source:stored.envelope,target:nodes.get(child).envelope,action:requested});
`+b.split('\n')[1]);
  const c='        if(researchPick)provedResearchPicks++;';
  s=sub(s,c,`        if(readIdentityState(stored.envelope).turn.roundNumber===2)
          globalThis.dataProof.push({kind:"research",source:stored.envelope,target:nodes.get(child).envelope,action:requested,raw:prepared.inspection.session?.decision?.choices});\n`+c);
 }
 return s;
};
