'use strict';
const assert=require('node:assert/strict');
function sub(s,a,b){assert.equal(s.split(a).length,2,a);return s.replace(a,b);}
module.exports=(s,witness)=>{
 const at=`        const mark=node.observation.selfState?.nextFinalMark;
        if(Array.isArray(active)&&active.length>0&&active.filter(id=>id!==seatId).every(id=>passed.includes(id))
          &&mark?.valuationSafe&&mark.options.some(option=>option.currentValue>0)){postMainValueBounds.set(node,null);return null;}`;
 return sub(s,at,`        if(Array.isArray(active)&&active.length>0&&active.every(id=>id===seatId||passed.includes(id))){
          const state=readIdentityState(stored.envelope);
          // The shared observation publishes this rule-derived mark unchanged
          // through a card or tech reveal. This bound needs no other projection.
          const direct=state.turn.roundNumber===2&&quietEarlySameSeatHandover(state)
            &&Object.hasOwn(rootObservation.selfState||{},"nextFinalMark");
          const mark=direct?endScoring.describeNextFinalMark({...state,cardEffects,
            getCardTypeCode:card=>cardEffects.getRuntimeCardTypeCode(card,cardEffects.getCardModel(card)?.cardType)},
            state.players.players.find(p=>p.id===seatId)):node.observation.selfState?.nextFinalMark;
${witness?'          if(direct){globalThis.markBoundWitnesses++;if(JSON.stringify(mark)!==JSON.stringify(node.observation.selfState?.nextFinalMark))throw new Error("R2_MARK_BOUND_PROJECTION_MISMATCH");}\n':''}          if(mark?.valuationSafe&&mark.options.some(option=>option.currentValue>0)){postMainValueBounds.set(node,null);return null;}
        }`);
};
