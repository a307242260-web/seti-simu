# 第 11 盘：第二轮搜索和第四轮付款
以源码 f41d6e839 的项目根为工作目录。先运行 admit-r2-known-work.cjs，输入 tail11-profile 的 gzip；然后将 r2-known-work.cjs 的非见证变换应用到分析端口，再运行 admit-r2-b38-tail.cjs，输入 tail11-known-work-proof 的 gzip。
admit-r2-score-and-bound.cjs 使用随档的两个变换前源码并在内存里加审计，输入 tail11-b38-tail-proof 的 gzip。第四轮的 admit-r4-trade-click.cjs 以未安装付款点击变换的候选源码为基准，输入 tail11-r4-profile 的 gzip。各审计脚本的第二个参数均为新输出文件。
完整新源码下，用 resume-current.cjs 从 fixtures 中的失败根分别验证第二轮和第四轮，第二参数指定新 gzip 输出文件。历史复放和当前基准保存于证据中。
