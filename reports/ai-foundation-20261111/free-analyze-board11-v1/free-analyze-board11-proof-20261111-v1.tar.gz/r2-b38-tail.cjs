'use strict';
const assert=require('node:assert/strict');
function sub(s,a,b){assert.equal(s.split(a).length,2,a);return s.replace(a,b);}
module.exports=(s,witness)=>{
 const start='    function previewFixedResearchSelection(',end='    function prepareDecisionContinuation(';
 const a=s.indexOf(start),b=s.indexOf(end,a);assert(a>=0&&b>a);
 let r=s.slice(a,b);
 r=sub(r,'      if(s?.phase!=="awaiting_input"||s.failure||s.interruptContext||s.irreversibleBarrier||s.undoFrames.length||s.queue.length!==1',
 `      const finalize=s?.queue[1],scanTail=s?.queue.length===2&&finalize.type===scienceSession.EFFECT_TYPES.SCAN_FINALIZE
        &&finalize.kind==="effect"&&finalize.ownerId===seatId&&!finalize.allowQuickActions&&!Object.keys(finalize.payload).length;
      if(s?.phase!=="awaiting_input"||s.failure||s.interruptContext||s.irreversibleBarrier||s.undoFrames.length||s.queue.length!==1&&!scanTail`);
 r=sub(r,'      // Rotation and research can write several rule slices.',`      if(scanTail&&(t.roundNumber!==2||!quietEarlyRound||origin.family!=="play_card"
        ||origin.target?.cardId!=="b_38.webp"&&cardInstanceIdForB38(state,origin)!==origin.target?.cardInstanceId
        ||!options.skipCost||options.techTypes?.length!==1||options.techTypes[0]!=="purple"
        ||Object.keys(state.aliens.chong?.transportTasksByRocketId||{}).length
        ||data.NEBULA_IDS.some(id=>data.isSectorReadyToSettle(state.data,id))))return null;
      // Rotation and research can write several rule slices.`);
 r=sub(r,'const next=structuredClone(state),result=scienceSession.resolveResearchSelection(next,head,action);',
  'const next=scanTail?copyForkData(state):structuredClone(state),result=scienceSession.resolveResearchSelection(next,head,action);');
 r=sub(r,'      next.meta=quietSavedMeta(next.meta,s.baseVersion+Number(!augmented.spawnedEffects.length));',
 `      if(scanTail){
        if(augmented.spawnedEffects.length||data.NEBULA_IDS.some(id=>data.isSectorReadyToSettle(next.data,id)))return null;
        const missing=next.cards.publicCards.filter(c=>!c).length;
        if(missing&&!refillQuietScan4(next,missing))return null;
        if(missing){
          const refill={ownerId:seatId,type:scienceSession.EFFECT_TYPES.PUBLIC_REFILL};
          const events=localPlans.augmentEffectResult(next,{ok:true,events:[{type:"publicRefill",count:missing}]},refill);
          if(events.spawnedEffects.length||events.events.length!==1)return null;
        }
        next.meta=quietSavedMeta(next.meta,s.baseVersion+1);
        return {state:next,barrier:missing?{effectId:s.sessionId+":effect:"+(s.nextEffectSequence+2),
          revision:s.revision+4,code:"hidden_card_reveal",reason:"公共牌补牌翻出新牌"}
          :{effectId:head.effectId,revision:s.revision+1,...augmented.irreversible}};
      }
      next.meta=quietSavedMeta(next.meta,s.baseVersion+Number(!augmented.spawnedEffects.length));`);
 const helper=`    function cardInstanceIdForB38(state,origin){
      const id=origin.target?.cardInstanceId;
      const isB38=c=>c.id===id&&c.cardId==="b_38.webp";
      return state.cards.discardPile.find(isB38)?.id||state.players.players.find(p=>p.id===seatId).reservedCards.find(isB38)?.id;
    }

`;
 s=s.slice(0,a)+helper+r+s.slice(b);
 if(witness){
  const point='        if(researchPick)provedResearchPicks++;';
  s=sub(s,point,`        if(taskSession.workingState.turn.roundNumber===2&&taskSession.queue[1]?.type===scienceSession.EFFECT_TYPES.SCAN_FINALIZE)
          globalThis.dataProof.push({kind:"b38-tail",source:stored.envelope,target:nodes.get(child).envelope,action:requested,raw:prepared.inspection.session?.decision?.choices});\n`+point);
 }
 return s;
};
