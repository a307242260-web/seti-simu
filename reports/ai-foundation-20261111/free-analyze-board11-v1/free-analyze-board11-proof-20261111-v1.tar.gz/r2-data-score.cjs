'use strict';
const assert=require('node:assert/strict');
function sub(s,a,b){assert.equal(s.split(a).length,2,a);return s.replace(a,b);}
module.exports=(s,witness)=>{
 s=sub(s,'if(state.turn.roundNumber!==4||p.techState!==copy.techState',`const quietSecondRound=state.turn.roundNumber===2&&Object.values(state.aliens.aliens).every(slot=>!slot.revealed);
  if((state.turn.roundNumber!==4&&!quietSecondRound)||p.techState!==copy.techState`);
 if(witness){
  s=sub(s,'if(proved!==null)return proved;','if(proved!==null&&state.turn.roundNumber!==2)return proved;');
  const before='return endScoring.computePlayerFinalScore(context,copy).totalScore-endScoring.computePlayerFinalScore({...context,players:state.players.players},p).totalScore;';
  s=sub(s,before,`const native=endScoring.computePlayerFinalScore(context,copy).totalScore-endScoring.computePlayerFinalScore({...context,players:state.players.players},p).totalScore;
  if(proved!==null){
   if(native!==proved)throw new Error("R2_DATA_SCORE_PROOF_MISMATCH "+JSON.stringify({native,proved}));
   globalThis.dataScoreWitnesses++;
  }
  return native;`);
 }
 return s;
};
