'use strict';
const assert=require('node:assert/strict');
function sub(s,a,b){assert.equal(s.split(a).length,2,a);return s.replace(a,b);}
exports.local=s=>s.replaceAll('allowUnrevealedQuiet','allowQuietEarlyRound');
exports.port=(s,witness)=>{
 s=sub(s,'allowUnrevealedQuiet:isUnrevealedRoundThree(readIdentityState(stored.envelope))',
   'allowQuietEarlyRound:isUnrevealedRoundThree(readIdentityState(stored.envelope))');
 s=sub(s,'||quietSecondRoundHandover(readIdentityState(stored.envelope))}):null;',
   '||quietEarlySameSeatHandover(readIdentityState(stored.envelope))}):null;');
 const start='    function quietSecondRoundHandover(state) {';
 const end='    function quietFirstTurnData(state) {';
 const a=s.indexOf(start),b=s.indexOf(end,a);assert(a>=0&&b>a);
 s=s.slice(0,a)+`    function quietEarlySameSeatHandover(state) {
      const t=state.turn;
      if(!t.activePlayerIds.every(id=>id===seatId||t.passedPlayerIds.includes(id)))return false;
      return t.roundNumber===2&&Object.values(state.aliens.aliens).every(slot=>!slot.revealed&&!alienState.isAlienReadyToReveal(slot))
        ||t.roundNumber===3&&Object.values(state.aliens.aliens).every(slot=>slot.revealed
          ?knownRootAlienIds.has(slot.alienId):!alienState.isAlienReadyToReveal(slot));
    }

`+s.slice(b);
 if(witness)s=sub(s,'        const child=finishProvedTurnBoundary(stored,requested,endPrelude.finished);',
  `        const child=finishProvedTurnBoundary(stored,requested,endPrelude.finished);
        globalThis.endWitnesses.push({source:stored.envelope,target:nodes.get(child).envelope,action:requested});
`);
 return s;
};
