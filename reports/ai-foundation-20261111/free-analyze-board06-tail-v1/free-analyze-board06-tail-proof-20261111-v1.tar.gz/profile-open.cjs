'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const [input,out]=process.argv.slice(2),f=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(f,module);
mod.filename=f;mod.paths=Module._nodeModulePaths(path.dirname(f));
const js=fs.readFileSync(f,'utf8'),anchor='      submissionCount += 1;';
assert.equal(js.split(anchor).length,2);
mod._compile(js.replace(anchor,anchor+`
 const old=globalThis.collectNative,action=before.session?.decision;
 old.push([current.family,head?.type||null,current.summary,action?.ownerId||null]);`),f);
mod.loaded=true;require.cache[f]=mod;
const {open,readZ,writeZ,short}=require('./controlled-r3'),{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent')),rows=[];
for(const o of readZ(input).rows.filter(r=>!r.pass)){
 const m=open(o.root),seatId='player-white',p=mod.exports.createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
 globalThis.collectNative=[];
 try{
  const q=createSearchAgent({seatId,analysisPort:p}).decide({seatId,legalActions:m.menu()}).search;
  assert.deepEqual(m.save(),o.root);assert.equal(q.diagnostics.nativeExecutions,o.n);
  const family={},detail={};
  for(const [a,b,c] of globalThis.collectNative){const k=[a,b].filter(Boolean).join(' / ');family[k]=(family[k]||0)+1;detail[k+' '+c]=(detail[k+' '+c]||0)+1;}
  const top=Object.entries(detail).sort((a,b)=>b[1]-a[1]).slice(0,16);
  console.log(JSON.stringify({board:o.board,facts:short(m),n:o.n,family,top,value:q.value}));
  rows.push({...o,q,family,top,operations:globalThis.collectNative});
 }finally{p.close();m.dispose();}
}
writeZ(out,{rows});
