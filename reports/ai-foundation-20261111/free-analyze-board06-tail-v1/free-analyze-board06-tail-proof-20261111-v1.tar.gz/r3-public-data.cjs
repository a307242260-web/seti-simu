'use strict';
const assert=require('node:assert/strict');
function sub(s,a,b){assert.equal(s.split(a).length,2,a);return s.replace(a,b);}
module.exports=(s,witness)=>{
 const first='!quietR3RevealedData(state) && !quietR3AmibaPostMain(state,owner)';
 assert.equal(s.split(first).length,3);
 s=s.replaceAll(first,first+' && !(t.roundNumber===3&&quietEarlySameSeatHandover(state))');
 if(witness){
  const a='        provedFinalDataMenuInputs++;';
  s=sub(s,a,a+`\n        if(readIdentityState(stored.envelope).turn.roundNumber===3)
          globalThis.dataProof.push({kind:"menu",source:stored.envelope,target:menuPreview,action:requested,raw:choices});`);
  const b='        const child = finishProvedCommittedState(node, stored, requested, state);\n        return rememberPrefix(key,node,actionId,remember(key,child));';
  s=sub(s,b,b.split('\n')[0]+`\n        if(readIdentityState(stored.envelope).turn.roundNumber===3)
          globalThis.dataProof.push({kind:"placement",source:stored.envelope,target:nodes.get(child).envelope,action:requested});
`+b.split('\n')[1]);
 }
 return s;
};
