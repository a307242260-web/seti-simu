'use strict';
const assert=require('node:assert/strict');
function sub(s,a,b){assert.equal(s.split(a).length,2,a);return s.replace(a,b);}
exports.local=s=>{
 const at=' function previewFinalEndPrelude(';
 s=sub(s,at,` function quietSingleEndMark(state,seatId){
  const t=state.turn,p=owner(state,seatId);
  if(!p||state.match.initialSetup||t.activePlayerCount!==4||t.currentPlayerId!==seatId||!p.mainActionCompleted
    ||p.passCompletionPending||t.gameEnded||t.passedPlayerIds.includes(seatId)||t.cardTurnEventBonuses?.length
    ||!t.turnOrderPlayerIds.includes(seatId)||residual.hasPendingFossilArrival(state)
    ||effects.collectMatchingTriggers(p,{type:"end_turn_handoffs_started",playerId:seatId}).length)return false;
  const board=copyForkData(state.finalScoring);
  return state.players.players.every(q=>finalScoring.getPendingMarksForPlayer(board,q).length===(q===p?1:0));
 }
 function previewSingleEndMarkCommit({state,seatId,tileId,action,knownCards}){
  if(!quietSingleEndMark(state,seatId))return null;
  const marked={...state,meta:{...state.meta,sequences:{...state.meta.sequences}},finalScoring:copyForkData(state.finalScoring)};
  if(!finalScoring.markTile(marked.finalScoring,tileId,owner(state,seatId),{root:marked}).ok)return null;
  return previewFinalEndPrelude({state:marked,seatId,action,knownCards,allowSameSeat:true,allowQuietEarlyRound:true})?.finished||null;
 }
`+at);
 return sub(s,'pureOptional,previewFinalPositiveTaskClaim','pureOptional,quietSingleEndMark,previewSingleEndMarkCommit,previewFinalPositiveTaskClaim');
};
exports.port=(s,witness)=>{
 s=sub(s,'quietEndPreludeTemplate=null, provedQuietEndMenus','quietEndPreludeTemplate=null, quietEndMarkTemplate=null, provedQuietEndMenus');
 s=sub(s,'quietEndPreludeTemplate=null; provedQuietEndMenus','quietEndPreludeTemplate=null; quietEndMarkTemplate=null; provedQuietEndMenus');
 const at='    function rememberQuietEndPrelude(action,child,preview){';
 s=sub(s,at,`    const quietEndMarkQueue=["alien:turn_end_neutral_milestone","alien:turn_end_reveal","company:turn_end","card_trigger:turn_end"];
    function quietEndMarkTail(queue,state){
      if(queue.length!==6||queue.some(e=>e.ownerId!==seatId||e.allowQuickActions))return false;
      const [mark,...tail]=queue,end=tail.pop(),t=state.turn;
      const boundary=data=>data?.roundNumber===t.roundNumber&&data?.turnNumber===t.turnNumber&&data?.didPass===false;
      return mark.type==="residual_final_mark"&&mark.kind==="decision"&&!Object.keys(mark.payload).length
        &&end.type==="probe_turn_advance"&&end.kind==="effect"&&boundary(end.payload)
        &&tail.every((e,i)=>e.type==="game_domain_handoff"&&e.kind==="effect"
          &&e.payload.domain+":"+e.payload.effectType===quietEndMarkQueue[i]&&boundary(e.payload.data));
    }

    function rememberQuietEndMark(action,child,state){
      const cp=nodes.get(child).envelope.session,s=cp?.session,j=s?.journal;
      if(child.status!=="decision"||s?.phase!=="awaiting_input"||s.revision!==2||s.interruptContext||s.irreversibleBarrier
        ||s.failure||s.undoFrames.length||!quietEndMarkTail(s.queue,state)||j.actions.length!==1
        ||j.actions[0].action.actionId!==action.actionId||j.replay.length!==1||j.effects.length!==2||j.decisions.length
        ||j.rng.length||j.logs.length||j.history.length!==1||j.events.length!==2
        ||j.events[0].type!=="end_turn_handoffs_started"||j.events[1].type!=="final_milestone_pending"
        ||JSON.stringify(s.baseState)!==JSON.stringify(s.workingState))return;
      quietEndMarkTemplate={...cp,session:{...s,baseState:null,workingState:null}};
    }

    function makeQuietEndMark(stored,action,state){
      const template=quietEndMarkTemplate,s=template?.session;
      if(s?.journal.actions[0].action.actionId!==action.actionId)return null;
      const choices=residualSession.listFinalMarkChoices({...state,finalScoring:copyForkData(state.finalScoring)},seatId);
      if(!choices.length)return null;
      const working=state.meta.rngState?.branch===true?{...state,meta:quietSavedMeta(state.meta)}:state;
      const session=freeze({...template,session:{...s,baseState:working,workingState:working,baseVersion:state.meta.stateVersion,
        journal:{...s.journal,actions:[{...s.journal.actions[0],action}],replay:[{...s.journal.replay[0],action}]}}});
      return {envelope:withEnvelopeSession(stored.envelope,session),inspection:{phase:"awaiting_input",session:{decision:{choices}}}};
    }

`+at);
 const point='      const endPrelude=resourcePlanning&&node.status==="stable"';
 s=sub(s,point,`      const markSource=resourcePlanning&&node.status==="stable"&&!stored.resourceControl&&requested.family==="end_turn"
        ?readIdentityState(stored.envelope):null;
      const quietMark=markSource?.turn.roundNumber===3&&quietEarlySameSeatHandover(markSource)
        &&localPlans.quietSingleEndMark(markSource,seatId);
      const markMenu=quietMark&&makeQuietEndMark(stored,requested,markSource);
      if(markMenu){
        const child=finishChild({session:null},{},movementPlanning?nextMovementIntent(node,requested):null,
          null,stored.informationBarrier,requested,stored,markMenu);
${witness?'        globalThis.dataProof.push({kind:"mark-menu",source:stored.envelope,target:markMenu.envelope,action:requested,raw:markMenu.inspection.session.decision.choices});\n':''}        return rememberPrefix(key,node,actionId,remember(key,child));
      }
      const markState=taskSession?.workingState;
      const markCommit=resourcePlanning&&node.status==="decision"&&!stored.resourceControl&&requested.family==="choose_target"
        &&taskSession?.queue[0]?.type==="residual_final_mark"&&taskSession.phase==="awaiting_input"
        &&!taskSession.failure&&!taskSession.interruptContext&&!taskSession.irreversibleBarrier&&!taskSession.undoFrames.length
        &&markState.turn.roundNumber===3&&quietEarlySameSeatHandover(markState)&&quietEndMarkTail(taskSession.queue,markState)
        ?localPlans.previewSingleEndMarkCommit({state:markState,seatId,tileId:requested.target.tileId,
          action:taskSession.journal.actions[0]?.action,knownCards:knownCards(stored.envelope)}):null;
      if(markCommit){
        const child=finishProvedTurnBoundary(stored,requested,markCommit);
${witness?'        globalThis.dataProof.push({kind:"mark-commit",source:stored.envelope,target:nodes.get(child).envelope,action:requested});\n':''}        return rememberPrefix(key,node,actionId,remember(key,child));
      }
`+point);
 return sub(s,'      if(endPrelude?.task&&!quietEndPreludeTemplate)',`      if(quietMark&&!quietEndMarkTemplate)rememberQuietEndMark(requested,child,markSource);
      if(endPrelude?.task&&!quietEndPreludeTemplate)`);
};
