'use strict';
const assert=require('node:assert/strict');
function sub(s,a,b){assert.equal(s.split(a).length,2,a);return s.replace(a,b);}
module.exports=(s,witness)=>{
 function region(from,to,change){const a=s.indexOf(from),b=s.indexOf(to,a);assert(a>=0&&b>a);s=s.slice(0,a)+change(s.slice(a,b))+s.slice(b);}
 region('    function previewQuietPublicScan(','    function previewQuietScan4Action(',r=>sub(r,
  'const quietRoundThree=quietAmiba||source==="scan"&&isUnrevealedRoundThree(root);',
  'const quietRoundThree=quietAmiba||source==="scan"&&(isUnrevealedRoundThree(root)||t.roundNumber===3&&quietEarlySameSeatHandover(root));'));
 region('    function previewQuietScan4Action(','    function previewFixed',r=>sub(r,
  'if(t.roundNumber!==4||t.currentPlayerId',
  'if((t.roundNumber!==4&&!(source==="scan"&&t.roundNumber===3&&quietEarlySameSeatHandover(state)))||t.currentPlayerId'));
 region('    function previewFixedResearchPick(','    function previewFixedResearchSelection(',r=>sub(r,
  'if(t.roundNumber!==4||t.currentPlayerId',
  'if((t.roundNumber!==4&&!(t.roundNumber===3&&quietEarlySameSeatHandover(state)))||t.currentPlayerId'));
 region('    function previewFixedResearchSelection(','    function prepareDecisionContinuation(',r=>sub(r,
  'const quietRoundThree=t.roundNumber===3&&quietR3AmibaOnly(state)\n        &&t.activePlayerIds.every(id=>id===seatId||t.passedPlayerIds.includes(id));',
  'const quietRoundThree=t.roundNumber===3&&quietEarlySameSeatHandover(state);'));
 if(witness){
  for(const [kind,at,raw] of [
   ['public-scan','        provedPublicScanChoices++;','publicScan.inspection.session?.decision?.choices'],
   ['scan4','        if(requested.target.mode==="move")provedScan4QuietMoves++;','prepared.inspection.session?.decision?.choices'],
   ['research','        if(researchPick)provedResearchPicks++;','prepared.inspection.session?.decision?.choices'],
  ]){
   s=sub(s,at,`        if(readIdentityState(stored.envelope).turn.roundNumber===3)
          globalThis.dataProof.push({kind:"${kind}",source:stored.envelope,target:nodes.get(child).envelope,action:requested,raw:${raw}});\n`+at);
  }
 }
 return s;
};
