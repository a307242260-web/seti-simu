# 第 6 盘：固定尾段原生复用
在源码 5bfc31ae8 根目录运行本目录 admit-r3-public-end.cjs，以 trade06-profile-20261111-v1.json.gz 为输入。
然后仅采用 r3-public-end.cjs 中的两个源码补丁，运行 admit-r3-all.cjs，以 trade06-r3t8-profile-20261111-v1.json.gz 为输入；脚本会在内存中加载余下三个补丁。
两次运行第二参数均为新 gzip 输出文件。第一处 48 次和第二处 420 次复用的原生前后状态和完整搜索图在原始输出中。
完整新源码下，resume-current.cjs 可从 fixtures 内第一处失败存档继续，参数二为新 gzip 输出文件。测试仅在项目根目录运行。
