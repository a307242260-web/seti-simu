# 第 4 盘：货币兑换的弃牌确认
以源码 bfacb7827 的项目根为工作目录，运行本目录 profile-open.cjs，输入本目录的 move04-failed-root-20261111-v1.json.gz；再运行 admit-quiet-trade.cjs，输入刚生成的逐输入诊断。两个脚本的第二参数分别为新 gzip 输出文件。
采用新源码后，从项目根运行 resume-current.cjs，传入 fixtures 的失败存档和新 gzip 输出文件。实际比较过的结果、完整搜索图、25 笔原生见证和续跑均随档保存。
