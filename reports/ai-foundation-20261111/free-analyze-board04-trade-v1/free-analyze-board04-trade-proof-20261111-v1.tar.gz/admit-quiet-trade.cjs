'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const [input,out]=process.argv.slice(2),fix=require('./quiet-trade.cjs');
function load(rel,change){
 const f=path.resolve(rel),mod=new Module(f,module);
 mod.filename=f;mod.paths=Module._nodeModulePaths(path.dirname(f));mod._compile(change(fs.readFileSync(f,'utf8')),f);
 mod.loaded=true;require.cache[f]=mod;return mod.exports;
}
const {createAnalysisPort}=load('randomizer/game/ai/analysis-port.js',s=>fix.port(s,true));
const {open,readZ,writeZ}=require('./controlled-r3'),{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const r=readZ(input).rows[0],m=open(r.root),seatId='player-white',p=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});globalThis.moveWitnesses=[];
try{
 const q=createSearchAgent({seatId,analysisPort:p}).decide({seatId,legalActions:m.menu()}).search,n=q.diagnostics.nativeExecutions;
 const fields=['actionId','value','realization','preparationDebt','complete','roots','lines','unresolved','selectionPlan','candidates','sharedPrefixGraph'];
 for(const k of fields)assert.deepEqual(JSON.parse(JSON.stringify(q))[k],r.q[k],k);
 assert.deepEqual(m.save(),r.root);assert.equal(globalThis.moveWitnesses.length,r.n-n);
 for(const {source,target,action,kind} of globalThis.moveWitnesses){
  assert(m.c.lifecycle.restore(source).ok);
  const restored=m.save();
  assert.deepEqual(JSON.parse(restored.committedState),JSON.parse(source.committedState));
  assert.deepEqual(restored.session,source.session);
  m.apply(action);
  const actual=m.save(),nativeMenu=m.menu();
  assert.deepEqual(JSON.parse(actual.committedState),JSON.parse(target.committedState));
  assert.deepEqual(actual.session,target.session,kind);
  assert(m.c.lifecycle.restore(target).ok);
  assert.deepEqual(m.menu(),nativeMenu);
 }
 console.log(JSON.stringify({old:r.n,n,ms:q.rootAndSearchMilliseconds,witnesses:globalThis.moveWitnesses.length,moveMenus:globalThis.moveWitnesses.filter(x=>x.kind==="provedMoveMenus").length,admitted:n<=256&&q.rootAndSearchMilliseconds<=600}));
 writeZ(out,{root:r.root,q,witnesses:globalThis.moveWitnesses});
}finally{p.close();m.dispose();}
