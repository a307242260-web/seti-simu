'use strict';
const path=require('node:path'),assert=require('node:assert/strict');
const {open,readZ,writeZ,short}=require('./controlled-r3');
const [teacher,comparison,out]=process.argv.slice(2);
const standard=require(path.resolve('reports/research/cd3032b2.5d8c5228.quick-400.json.round-end-3.checkpoint.json'));
const yellow=readZ(comparison).results;
const source=[
 ['教师复放',readZ(teacher).current],
 ['标准自主',standard.coreState.compositionEnvelope],
 ['土星虫族黄4',yellow.find(r=>r.name==='全自主').root],
 ['土星阿米巴黄4',yellow.find(r=>r.name.includes('外星人 1 黄4号位')).root],
];
const rows=source.map(([name,e])=>{
 const m=open(e);
 try{
  const s=m.state(),p=m.player();
  assert(s.turn.roundNumber===3&&m.menu().some(a=>a.family==='pass'&&a.actorId===p.id));
  return {name,summary:short(m),tech:p.techState,income:p.income,wallet:p.resources,
   traces:m.facts().traces,
   signals:Object.entries(s.data.nebulae).flatMap(([id,b])=>{
    const own=b.tokens.filter(t=>t.replacedByPlayerId===p.id).length;
    return own?[{id,own,total:b.tokens.length}]:[];
   }),
   finalMarks:Object.entries(s.finalScoring.tiles).flatMap(([id,t])=>t.marks.filter(x=>x.playerId===p.id)
    .map(x=>({id,threshold:x.threshold,slot:x.slotIndex}))),
   launched:s.pieces.rockets.filter(x=>x.playerId===p.id),
   reserved:p.reservedCards.map(x=>x.cardId),
  };
 }finally{m.dispose();}
});
for(const r of rows)console.log(JSON.stringify([r.name,r.signals,r.traces,r.finalMarks,r.reserved]));
writeZ(out,{rows});
