Run from V670 source. Extract this archive and `saturn-yellow-profile-20261111-v1.json.gz`, `yellow-titan-fourth-20261111-v1.json.gz` from the earlier V669 `saturn-yellow-native-20261111-v1.tar.gz` into one fresh directory (`$proof`).

```sh
node "$proof/cold.cjs" "$proof/saturn-yellow-profile-20261111-v1.json.gz" /tmp/v670-cold.json.gz
node "$proof/parity.cjs" "$proof/saturn-yellow-profile-20261111-v1.json.gz" /tmp/v670-parity.json.gz
node "$proof/hidden.cjs" /tmp/v670-cold.json.gz /tmp/v670-hidden.json.gz
node "$proof/resume.cjs" "$proof/yellow-titan-fourth-20261111-v1.json.gz" /tmp/v670-cold.json.gz /tmp/v670-resume.json.gz
node "$proof/teacher.cjs" /tmp/v670-teacher.json.gz
node "$proof/ledger.cjs" /tmp/v670-teacher.json.gz "$proof/yellow-titan-fourth-20261111-v1.json.gz" /tmp/v670-ledger.json.gz
node "$proof/standard-gate.cjs" "$PWD" reports/ai-foundation-20261109/v660-public-transport-chain-v1/v660-first3-independent-replay-20261109-v1.checkpoint.json /tmp/v670-standard.json.gz cd3032b2.5d8c5228.quick-400.json
```
The parity script wraps a disposable module and independently replays all 140 newly reused native effects. It checks both complete search graphs, rule/RNG state, queue, and exact unfiltered public-pick menu; for masked post-refill states the retained legal menu is checked against the full Native menu.
