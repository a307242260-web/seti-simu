'use strict';
const path=require('node:path'),assert=require('node:assert/strict');
const {readZ,writeZ,open}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve(process.env.PARITY_PORT||'randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [input,out]=process.argv.slice(2),seatId='player-white';
const rows=[];
for(const r of readZ(input)){
 const m=open(r.root),analysisPort=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
 try{
  const q=createSearchAgent({analysisPort,seatId}).decide({seatId,legalActions:m.menu()}).search;
  const score=x=>x.map(a=>[a.actionId,a.value,a.completion,a.valueType]);
  assert.equal(q.actionId,r.q.actionId);assert.equal(q.value,r.q.value);
  assert.deepEqual(score(q.roots),score(r.q.roots));assert.deepEqual(m.save(),r.root);
  rows.push({card:r.card,root:r.root,actionId:q.actionId,value:q.value,roots:q.roots,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,
   quiet:q.analysis.provedScan4QuietLaunchSkips,publicScans:q.analysis.provedPublicScanChoices});
  console.log(r.card,q.value,q.diagnostics.nativeExecutions,q.rootAndSearchMilliseconds,q.analysis.provedScan4QuietLaunchSkips,q.analysis.provedPublicScanChoices);
 }finally{m.dispose();}
}
writeZ(out,{rows});
