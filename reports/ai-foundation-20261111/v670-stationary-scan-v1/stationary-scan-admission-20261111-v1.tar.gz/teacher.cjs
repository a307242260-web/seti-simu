'use strict';
const path=require('node:path'),assert=require('node:assert/strict');
const {open,writeZ,short}=require('./controlled-r3');
const dir='reports/ai-foundation-20261105/third-round-teacher-v1/';
const read=name=>require(path.resolve(dir+name));
const initial=read('initial-native-audit-20261105-v1.json');
const earlier=read('teacher-third-current-replay-20261105-v1.json'),late=read('teacher-third-current-replay-20261105-v2.json');
const origin=read('teacher-before-input-107-20261105-v1.checkpoint.json').coreState.compositionEnvelope;
const priorEnd=read('teacher-round3-before-pass-current-20261105-v2.checkpoint.json').coreState.compositionEnvelope;
const actions=[...initial.teacher.rows.filter(r=>r.input<160),...earlier.rows,...late.rows];
const m=open(origin),done=[];
try{
 for(const row of actions)try{done.push({i:row.input??row.historicalInput,action:m.apply(row.action)});}
 catch(e){throw Error('TEACHER_REPLAY_INPUT '+(row.input??row.historicalInput)+' '+row.action.summary,{cause:e});}
 const current=m.save(),record=short(m);
 assert.equal(record.wallet[0],105);
 const state=JSON.parse(current.committedState),old=JSON.parse(priorEnd.committedState);
 const asset=s=>({
  turn:s.turn,rng:s.meta.rngState,owner:s.players.players.find(x=>x.id==='player-white'),
  aliens:s.aliens,data:s.data,planets:s.planets,finalScoring:s.finalScoring,probes:s.pieces.rockets.filter(r=>r.playerId==='player-white')
 });
 assert.deepEqual(asset(state),asset(old));
 console.log(JSON.stringify({n:done.length,inputs:[done[0].i,done.at(-1).i],semanticAssetsExact:true,score:record.wallet[0],facts:record}));
 writeZ(process.argv[2],{origin,done,current,semanticAssetsExact:true,record});
}finally{m.dispose();}
