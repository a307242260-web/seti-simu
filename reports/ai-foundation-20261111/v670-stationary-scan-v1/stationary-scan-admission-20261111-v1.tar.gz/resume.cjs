'use strict';
const assert=require('node:assert/strict');
const {readZ,writeZ,open,short}=require('./controlled-r3');
const [input,proof,out]=process.argv.slice(2);
const admission=readZ(proof).rows;
const rows=[];
for(const base of readZ(input).results.filter(x=>x.stop!=='terminal')){
 const m=open(base.root),actions=[...base.actions];
 try{
  actions.forEach(x=>m.apply(x.action));const entry=m.save();
  const gate=admission.find(x=>x.card===base.card);
  assert(gate.n<=256&&gate.ms<=600);
  assert.deepEqual(entry,gate.root);assert.deepEqual(entry,base.end);
  let checkpoint,stop;
  for(let i=0;i<180;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!=='player-white'){
    const passive=[];m.advanceOpponents(passive);actions.push(...passive.map(action=>({action,passive:true})));continue;
   }
   const q=m.automatic(checkpoint);
   if(!q.a||!q.complete||q.n>256||q.ms>600){stop={kind:'gate',n:q.n,ms:q.ms,summary:q.a?.summary};break;}
   if(i===0)assert.deepEqual([q.a.actionId,q.value,q.n],[gate.actionId,gate.value,gate.n]);
   checkpoint=q.checkpoint;actions.push({action:m.apply(q.a),n:q.n,ms:q.ms,value:q.value});
  }
  assert(stop);
  const end=m.save(),terminal=stop==='terminal'?m.state().match.finalScores.find(p=>p.playerId==='player-white'):null;
  const peak=[Math.max(0,...actions.map(x=>x.n||0)),Math.max(0,...actions.map(x=>x.ms||0))],assets=short(m);
  m.restore(base.root);actions.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),end);
  rows.push({card:base.card,root:base.root,entry,actions,stop,terminal,peak,assets,end});
  console.log(JSON.stringify([base.card,stop,terminal?.totalScore,peak,actions.length,assets]));
 }finally{m.dispose();}
}
writeZ(out,{rows});
