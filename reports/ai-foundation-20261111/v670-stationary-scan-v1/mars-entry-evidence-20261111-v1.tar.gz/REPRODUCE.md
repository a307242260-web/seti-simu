Run from V670 source. Extract `mars-credit-20261111-v2.json.gz` from the V666 funded-fossil archive into a separate directory. Then run:
```sh
node "$proof/mars-entry.cjs" "$prior/mars-credit-20261111-v2.json.gz" /tmp/v670-mars-entry.json.gz
```
The original search still chooses the Uranus direction and excludes data and company swap. The fixed native counterfactual proves affordability and known information up to the next input. Its later legal replay assumes the recorded passive choices. Hidden income draws are outcomes rather than evidence for the initial pick.
