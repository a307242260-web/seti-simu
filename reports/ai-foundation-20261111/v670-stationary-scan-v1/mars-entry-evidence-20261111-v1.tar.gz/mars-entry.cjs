'use strict';
const path=require('node:path'),assert=require('node:assert/strict');
const {open,short,readZ,writeZ}=require('./controlled-r3');
const [input,out]=process.argv.slice(2),d=readZ(input),source=d.rows.find(r=>r.label==='company / none');
const m=open(d.root),r=[];
try{
 const root=m.save(),q=m.automatic(),menu=m.menu();
 assert(q.complete&&q.n<=256&&q.ms<=600);
 const action=menu.find(a=>a.family==='industry'&&a.target?.abilityId==='deepspace_swap_cards');
 const data=menu.find(a=>a.family==='place_data');
 assert(q.roots.find(x=>x.actionId===data.actionId).completion==='excluded-by-movement-policy');
 assert(q.roots.find(x=>x.actionId===action.actionId).completion==='excluded-by-card-pick-policy');
 const expected=source.prefix.slice(0,source.prefix.findIndex(a=>a.family==='end_turn'));
 for(const a of expected)r.push(m.apply(a));
 const prepared=m.save(),pre=short(m),before=JSON.parse(root.committedState),after=JSON.parse(prepared.committedState);
 assert.deepEqual(after.meta.rngState,before.meta.rngState);
 assert.deepEqual(after.cards.drawPileCardIds,before.cards.drawPileCardIds);
 assert(pre.hand.includes('dlc_31.png')&&pre.hand.includes('b_101.webp')&&pre.wallet[2]===1);
 for(const a of source.prefix.slice(expected.length))r.push(m.apply(a));
 const entry=m.save();assert.deepEqual(entry,source.start);
 const afterLand=source.checkpoints['after-income'].summary;
 const movement=q.roots.find(x=>x.actionId===data.actionId).chosenGoal;
 const result={root,visiblePlan:q.a,visibleValue:q.value,visibleN:q.n,roots:q.roots,movement,prepared,pre,afterLand,entry,prefix:r};
 console.log(JSON.stringify({visibleChoice:q.a.summary,V:q.value,n:q.n,goal:movement.planetId,
  paidBeforeRotation:movement.movementTiming.bestTotalPaidPoints,paidAfterWaiting:movement.movementTiming.waitPaidPoints,
  prepared:pre,afterLand,prefix:r.length}));
 writeZ(out,result);
}finally{m.dispose();}
