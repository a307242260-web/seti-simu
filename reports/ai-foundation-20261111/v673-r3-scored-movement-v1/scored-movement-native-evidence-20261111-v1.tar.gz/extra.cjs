'use strict';
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [d,out,mode]=process.argv.slice(2),t=readZ(d+'/round3-20261111-v1.json.gz');
const x=t.rows.find(r=>r.label.endsWith(mode==='paid'?'payment-A9':'corner-A9')),root=x.settled.state,cases=[];
for(const move of (mode==='paid'?['顺时针']:['向外','顺时针']))for(const scan of (mode==='paid'?['南河三']:['南河三','天狼星A'])){
 cases.push([move+'/'+scan,h=>{
   h.take(h.m.play('b_16.webp'));h.act('choose_target',a=>a.summary.endsWith(move));
   h.act('choose_target',a=>a.summary==='扫描 '+scan);h.cut('after-scan');
 }]);
}
writeZ(out,{root,...runCases(root,cases)});
