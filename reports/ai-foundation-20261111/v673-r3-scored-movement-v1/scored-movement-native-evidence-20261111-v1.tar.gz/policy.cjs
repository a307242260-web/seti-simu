'use strict';
const path=require('node:path'),assert=require('node:assert/strict');
const {readZ,open,short,writeZ}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const [d,out]=process.argv.slice(2),x=readZ(d+'/move-corner-20261111-v1.json.gz');
const audit=readZ(d+'/audit-20261111-v1.json.gz');
const std=open(audit.roots[211]);for(const a of audit.ledger.filter(x=>x.i>=211&&x.i<=222))std.apply(a.input);const st=std.save();std.dispose();
const snapshots=[['paid-root',x.root],...x.trials.map(t=>['after-'+t.mode,t.end]),['standard-223',st]];
const result=[];
for(const [name,state] of snapshots){
 if(!state)continue;
 const m=open(state),p=createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});
 try{
  p.setResourcePlanning(true);p.setCardPickPlanning(true);p.setMovementPlanning(true);p.setDecisionPlanning({finalMarkPlanning:true,scanPlanning:true});
  const n=p.openRoot(),resource=p.resourceSpec(n),move=p.goalMovementSpec(n);
  assert.deepEqual(m.save(),state);
  const z={name,state,assets:short(m),move,resource};
  console.log(JSON.stringify([name,z.assets.wallet,move?.reason,move?.selectedActionId,move?.chosenGoal,resource?.plans.map(q=>[q.goal.id,q.goal.movementFunding,q.firstActionId])]));
  result.push(z);
 }finally{p.close();m.dispose();}
}
writeZ(out,result);
