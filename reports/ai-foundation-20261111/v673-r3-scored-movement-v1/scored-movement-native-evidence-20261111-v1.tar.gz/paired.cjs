'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {readZ,open,writeZ}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),d=readZ(dir+'/move-corner-20261111-v1.json.gz');
const source=path.resolve('randomizer/game/ai/analysis-port.js'),real=fs.readFileSync(source,'utf8');
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const modes=[process.argv[4]||'paired'];
function modify(s){
 const step='      if(goal.movementFunding){';
 const push='        if(candidate)goals=[...goals,candidate];';
 assert.equal(s.split(step).length,2);assert.equal(s.split(push).length,2);
 return s.replace(step,`      if(goal.pairedMove){
        const p=state.players.players.find(x=>x.id===seatId),stage=operation.cargoInput??0;
        if(stage<goal.pairedMove.length){
          const choice=node.legalActions.find(a=>a.actionId===goal.pairedMove[stage]);
          return choice?{kind:"fixed",actionId:choice.actionId,reason:"proof-fixed-move-source",cargoInput:stage+1}
            :{kind:"infeasible",reason:"proof-fixed-move-source-changed"};
        }
        if(stage===2&&(p.resources.publicity<4||p.resources.energy
          ||p.hand.some(c=>c.id===goal.pairedPayer)))return{kind:"infeasible",reason:"proof-fixed-move-wallet-changed"};
      }
`+step).replace(push,push+`
        const diagnosticOwner=state.players.players.find(p=>p.id===seatId);
        if(node.status==="stable"&&diagnosticOwner.resources.score===97&&diagnosticOwner.resources.publicity===3
          &&globalThis.scoredRouteProof?.trials.every(t=>node.legalActions.some(a=>a.actionId===t.ids[0]))){
          globalThis.scoredRouteProof.fires++;
          for(const item of globalThis.scoredRouteProof.trials)goals=[...goals,{
            id:"tech:blue1:3:proof-"+item.mode,kind:"research_tech",tileId:"blue1",blueSlot:3,
            required:{publicity:6},pairedMove:item.ids,pairedPayer:globalThis.scoredRouteProof.payer}];
        }
`);
}
globalThis.scoredRouteProof={fires:0,payer:d.trials[0].inputs[1].target.cardIds[0],
 trials:d.trials.flatMap(t=>{
 const ids=t.inputs.map(a=>a.actionId),a9=d.choices.find(a=>a.family==='card_corner'&&a.summary.startsWith('amiba_9.webp'));
 assert(a9);
 return [{mode:t.mode,ids},{mode:t.mode+'-A9',ids:[...ids,a9.actionId]}];
 })};
const results=[];
for(const mode of modes){
 const mod=new Module(source,module);mod.filename=source;mod.paths=Module._nodeModulePaths(path.dirname(source));
 mod._compile(mode==='paired'?modify(real):real,source);
 const m=open(d.root),p=mod.exports.createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});
 try{
  const q=createSearchAgent({seatId:'player-white',analysisPort:p}).decide({seatId:'player-white',legalActions:m.menu()}).search;
  assert.deepEqual(m.save(),d.root);
  const tests=q.lines[0].edges.filter(e=>e.resourcePlan?.id.includes('proof-')).map(e=>{
 const n=q.lines.find(x=>x.node===e.target);
 return [e.resourcePlan.id,e.steps,e.goalStatus,n?.value,n?.completion];
 });
  console.log(JSON.stringify({mode,fires:globalThis.scoredRouteProof.fires,choice:m.menu().find(a=>a.actionId===q.actionId).summary,value:q.value,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,complete:q.complete,
    tests}));
  results.push({mode,q});
 }finally{p.close();m.dispose();}
}
writeZ(out,{root:d.root,results});
