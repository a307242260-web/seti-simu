# V673 scored movement and Blue 1 joint funding

Run from a clean Production checkout at cbd73e00c98455dac868bd43be3e1759130088a7.
Let p be the absolute path of the extracted archive. The working source is not
modified by the diagnostic module; it compiles a private in-memory copy.
Outputs below must use fresh names. The included archived data is immutable.

```sh
(cd "$p" && shasum -a 256 -c SHA256SUMS)
node "$p/verify.cjs" "$p"
node "$p/policy.cjs" "$p" "$p/replay-policy.json.gz"
node "$p/paired.cjs" "$p" "$p/replay-baseline.json.gz" baseline
node "$p/paired.cjs" "$p" "$p/replay-paired.json.gz"
node "$p/round3.cjs" "$p" "$p/replay-round3.json.gz"
node "$p/extra.cjs" "$p" "$p/replay-extra.json.gz"
node "$p/extra.cjs" "$p" "$p/replay-extra-paid.json.gz" paid
node "$p/stock.cjs" "$p" "$p/replay-stock.json.gz"
node "$p/fourth.cjs" "$p" "$p/replay-fourth.json.gz"
node "$p/fourth-controls.cjs" "$p" "$p/replay-fourth-controls.json.gz"
node "$p/fourth-stock.cjs" "$p" "$p/replay-fourth-stock.json.gz"
node "$p/pass.cjs" "$p" "$p/replay-pass.json.gz"
```

The verification command resubmits the recorded actions without invoking
search. The rerun commands test the same bounds; wall-clock timings vary.
