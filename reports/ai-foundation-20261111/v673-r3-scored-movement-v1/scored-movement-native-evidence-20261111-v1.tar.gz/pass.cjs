'use strict';
const assert=require('node:assert/strict');
const {readZ,writeZ,open}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),r=n=>readZ(dir+'/'+n+'-20261111-v1.json.gz');
const cases=[['stock',r('stock').rows[0]],['corner',r('extra').rows.find(r=>r.label==='顺时针/南河三')]];
const results=[];
for(const [name,row] of cases){
 const m=open(row.settled.state);
 try{
  const input=m.act('pass'),root=m.save(),q=m.automatic();
  assert(q.complete&&q.n<=256&&q.ms<=600);assert.deepEqual(m.save(),root);
  const {a,n,ms,value,roots}=q;
  console.log(JSON.stringify([name,a.summary,n,ms,value,roots.map(x=>[x.actionId,x.value])]));
  results.push({name,source:row.settled.state,input,root,q:{a,n,ms,value,roots}});
 }finally{m.dispose();}
}
writeZ(out,results);
