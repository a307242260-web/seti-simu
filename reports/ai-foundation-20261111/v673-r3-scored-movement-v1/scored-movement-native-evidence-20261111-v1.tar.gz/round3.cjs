'use strict';
const assert=require('node:assert/strict');
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [d,out]=process.argv.slice(2),src=readZ(d+'/paired-fixed-20261111-v1.json.gz'),q=src.results[0].q;
assert(q.complete&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600);
const cases=q.lines[0].edges.filter(e=>e.resourcePlan?.id.includes('proof-')).map(e=>[e.resourcePlan.id,h=>{
 for(const id of e.steps){const a=h.m.menu().find(x=>x.actionId===id);assert(a,id);h.take(h.m.apply(a));}
 h.cut('research');
}]);
writeZ(out,{root:src.root,...runCases(src.root,cases)});
