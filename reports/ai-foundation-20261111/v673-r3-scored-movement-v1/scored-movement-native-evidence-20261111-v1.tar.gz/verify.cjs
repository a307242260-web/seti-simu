'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ}=require('./controlled-r3');
const {knownBlueCashOffers}=require(path.resolve('randomizer/game/ai/local-decision-plans'));
const dir=process.argv[2],r=n=>readZ(dir+'/'+n+'-20261111-v1.json.gz');
let count=0;
function replay(root,trace,end){
 const m=open(root);
 try{
  for(const x of trace){if(x.n!==undefined)assert(x.n<=256&&x.ms<=600);
   if(x.passive)assert.notEqual(x.action.actorId,'player-white');
   m.apply(x.action||x);count++;
  }
  assert.deepEqual(m.save(),end);
  return m.state().match.finalScores?.find(x=>x.playerId==='player-white');
 }finally{m.dispose();}
}
const a=r('move-corner'),q=r('paired-fixed').results[0].q;
assert(q.complete&&!q.unresolved.length&&q.diagnostics.nativeExecutions===74&&q.rootAndSearchMilliseconds<=600);
assert.equal(q.actionId,a.result.a.actionId);assert.equal(q.value,188);
for(const t of a.trials)replay(a.root,t.inputs,t.end);
for(const {name,state,resource} of r('policy-standard').filter(x=>['paid-root','standard-223'].includes(x.name))){
 const m=open(state);
 try{
  const s=m.state(),p=m.player(),known=new Set([...s.cards.publicCards,...p.hand,...p.reservedCards].filter(Boolean).map(c=>c.id));
  assert.deepEqual(knownBlueCashOffers(s,known).map(c=>c.cardId),name==='paid-root'?['dlc_17.png']:['dlc_17.png','dlc_15.png']);
  assert.equal(resource.plans.some(q=>q.goal.id==='tech:blue1:3:funded-route'),name==='standard-223');
 }finally{m.dispose();}
}
const edges=q.lines[0].edges.filter(x=>x.resourcePlan?.id.includes('proof-'));
assert.deepEqual(edges.map(e=>q.lines.find(n=>n.node===e.target).value),[175,176,176,177]);
for(const label of ['round3','extra','extra-paid','stock']){
 const t=r(label);assert.equal(t.rows.length,['round3','extra'].includes(label)?4:1);assert(!t.failures.length);
 for(const x of t.rows){
  if(label==='round3')assert.deepEqual(x.prefix.map(a=>a.actionId),edges.find(e=>e.resourcePlan.id===x.label).steps);
  replay(t.root,x.prefix,x.start);replay(x.start,x.actions,x.end);
 }
}
for(const x of r('pass')){
 replay(x.source,[x.input],x.root);assert.equal(x.q.a.summary,'b_111.webp');
 assert.equal(x.q.n,2);assert(x.q.roots.every(y=>y.value===x.q.value));
}
let terminals=0,gates=0;
for(const label of ['fourth','fourth-controls','fourth-stock'])for(const x of r(label).results){
 const score=replay(x.root,x.actions,x.end);
 if(x.stop==='terminal'){assert.deepEqual(score,x.terminal);terminals++;}
 else {assert(x.stop.n>256||x.stop.ms>600);gates++;}
}
assert.deepEqual([terminals,gates],[12,0]);
console.log(JSON.stringify({nativeReplayInputs:count,thirdRoundChecks:10,fourthRoundTerminals:terminals,gates}));
