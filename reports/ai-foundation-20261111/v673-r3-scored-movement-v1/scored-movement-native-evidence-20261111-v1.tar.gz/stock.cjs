'use strict';
const assert=require('node:assert/strict');
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [d,out]=process.argv.slice(2),src=readZ(d+'/paired-guarded-20261111-v1.json.gz'),q=src.results[0].q;
assert(q.complete&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600);
const candidates=q.lines[0].edges.filter(e=>e.actionId===q.actionId&&q.lines.find(n=>n.node===e.target).value===q.value);
assert.equal(candidates.length,1);
const [best]=candidates;
const cases=[[best.resourcePlan.id,h=>{
 for(const id of best.steps){const a=h.m.menu().find(x=>x.actionId===id);assert(a,id);h.take(h.m.apply(a));}
 h.cut('stock');
}]];
writeZ(out,{root:src.root,...runCases(src.root,cases)});
