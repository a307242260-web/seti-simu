'use strict';
const {readZ,writeZ,runCases,open}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),d=readZ(dir+'/audit-20261111-v1.json.gz');
const off=(h,i)=>h.take(h.m.apply(d.ledger.find(r=>r.i===i).input));
const a=(h,f,t)=>h.act(f,q=>q.summary===t);
const step=(h,k)=>{h.act('place_data');a(h,'choose_target','第一排放置位 '+k);};
const end=h=>h.act('end_turn');
const advance=h=>{if(h.m.menu()[0].actorId!=='player-white'){const q=[];h.m.advanceOpponents(q);h.take(...q);}};
const buy=(h,id)=>{h.act('quick_trade',q=>q.target.tradeId==='publicity-for-card');h.take(h.m.pick(id));};
const first=(h,id,zone)=>{a(h,'choose_card',id+' → '+zone);a(h,'choose_card','结束公共牌扫描');};
const r2=[];
for(const id of ['b_2.webp','dlc_21.png'])for(const tail of ['auto','launch','orbit prep']){
 r2.push([id+' / '+tail,h=>{
  first(h,id,'天狼星A');
  if(tail!=='auto'){off(h,76);off(h,77);}
  if(tail==='orbit prep'){for(let i=78;i<=83;i++)off(h,i);}
  h.cut('carry');
 }]);
}
const r3=[];
for(const id of ['b_14.webp','dlc_30.png'])for(const mode of ['skip-auto','swap','buy','buy and fix land','buy and fix land and refill']){
 r3.push([id+' / '+mode,h=>{
  first(h,id,'南河三');
  if(mode==='skip-auto')return;
  for(let i=140;i<=144;i++)off(h,i);
  if(mode==='swap')h.take(...h.m.swap('dlc_32.png','dlc_31.png'));
  else buy(h,'dlc_31.png');
  step(h,1);step(h,2);
  if(mode!=='swap'){h.take(h.m.corner('dlc_32.png'));step(h,3);}
  h.cut('carry');
  end(h);
  if(!mode.includes('fix'))return;
  off(h,156);advance(h);
  for(let i=160;i<=164;i++)off(h,i);
  off(h,165);
  if(mode.endsWith('refill'))buy(h,'dlc_25.png');
  step(h,4);a(h,'choose_card','收入 b_101.webp');
  h.act('place_data');a(h,'choose_target','blue2 下方');
  h.cut('after-income');
  end(h);
 }]);
}
writeZ(out,{r2:runCases(d.roots[74],r2),r3:runCases(d.roots[138],r3)});
