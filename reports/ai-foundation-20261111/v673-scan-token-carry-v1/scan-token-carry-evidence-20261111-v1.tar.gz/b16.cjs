'use strict';
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),d=readZ(dir+'/audit-20261111-v1.json.gz');
const a=(h,f,t)=>h.act(f,q=>q.summary===t);
const computer=(h,n)=>{for(let i=1;i<=n;i++){h.act('place_data');a(h,'choose_target','第一排放置位 '+i);}};
const analysis=h=>{h.act('analyze');h.act('choose_target',q=>q.summary.includes('蓝3号位'));h.act('choose_card',q=>q.summary.includes('科学论文'));h.act('end_turn');};
const fixed=[];
for(const direction of ['向外','顺时针','逆时针','向内','结束移动'])for(const zone of ['南河三','天狼星A']){
 for(const force of ['natural','income']){
 fixed.push([direction+'/'+zone+'/'+force,h=>{
  analysis(h);h.take(h.m.play('b_16.webp'));h.act('choose_target',q=>q.summary.endsWith(direction));
  a(h,'choose_target','扫描 '+zone);h.cut('extra-data');
  if(force==='income'){
   for(const id of ['amiba_2.webp','amiba_5.webp'])h.take(h.m.corner(id));
   computer(h,4);a(h,'choose_card','收入 dlc_25.png');h.cut('income');
  }
 }]);
 }
}
fixed.push(['analyze then release',analysis]);
writeZ(out,runCases(d.roots[235],fixed));
