'use strict';
const path=require('node:path'),{open,readZ,writeZ,runCases}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),d=readZ(dir+'/audit-20261111-v1.json.gz'),r=require(path.resolve('reports/research/d3183131.cbd73e00.quick-400.json'));
const start=require(path.resolve(r.roundEnds[0].checkpointPath)).coreState.compositionEnvelope;
const fixed=(h,i)=>h.take(h.m.apply(d.ledger.find(x=>x.i===i).input));
const card='dlc_4.png';
const alt=(h,move)=>{h.act('pass');h.act('choose_card',a=>a.summary===card);
 const a=[];h.m.advanceOpponents(a);h.take(...a);h.cut('round2-open');
 if(move==='none')return;
 if(move==='before scan'){h.take(h.m.play(card));if(h.m.menu().some(a=>a.target?.skip===true))h.act('choose_target',a=>a.target.skip===true);h.act('end_turn');h.cut('token');return;}
 for(let i=72;i<=77;i++)fixed(h,i);
 h.take(h.m.play(card));
 if(move==='out')h.act('choose_target',a=>a.target.deltaY===1);
 if(move==='stop')h.act('choose_target',a=>a.target.skip===true);
 h.cut('token');
};
writeZ(out,runCases(start,['none','before scan','out','stop'].map(x=>[x,h=>alt(h,x)])));
