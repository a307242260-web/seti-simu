# V673 public scan marker and late B16 controls
Run from clean V673 Production (cbd73e00c) with the registered research JSON,
first round-end checkpoint and action replay save. Set p to the absolute
directory where the archive was extracted. New outputs do not overwrite the
included fixtures. Every accepted suffix is replayed through the native port.
```sh
node "$p/audit.cjs" "$p/replay-audit.json.gz"
node "$p/carry.cjs" "$p" "$p/replay-carry.json.gz"
node "$p/reserve.cjs" "$p" "$p/replay-reserve.json.gz"
node "$p/b16.cjs" "$p" "$p/replay-b16.json.gz"
node "$p/fourth.cjs" "$p" "$p/replay-fourth.json.gz"
```
The fourth-round starts fix the same offered reserve card per branch, then all
white decisions are autonomous. Wall-clock gates are checked before submitting
every decision. In the archived run one branch stopped at 600.301917 ms.
