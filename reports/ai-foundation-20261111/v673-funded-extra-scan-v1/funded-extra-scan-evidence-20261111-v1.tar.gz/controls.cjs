'use strict';
const {open,runCases,readZ,writeZ,short}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),b=readZ(dir+'/ledger-20261111-v1.json.gz');
const a1='amiba_1.webp',a7='amiba_7.webp',a9='amiba_9.webp',b16='b_16.webp';
const tech=(h,t,slot)=>h.act('choose_target',a=>a.target.tileId===t&&(slot==null||a.target.blueSlot===slot));
const data=(h,name)=>{h.act('place_data');h.act('choose_target',a=>a.summary===name)};
const fill=(h,n)=>{for(let i=1;i<=n;i++)data(h,'第一排放置位 '+i)};
const income=(h,id)=>h.act('choose_card',a=>a.summary==='收入 '+id);
const corner=(h,id)=>h.take(h.m.corner(id));
const end=h=>h.act('end_turn');
const trade=(h,kind,ids)=>{h.act('quick_trade',a=>a.target.tradeId===kind);for(const id of ids)h.act('choose_payment',a=>a.summary===id);h.act('choose_payment',a=>a.summary.startsWith('确认'));};
const scan=(h,mode)=>{
 if(mode==='auto')return;
 h.act('scan');
 if(mode==='Kepler'){
  h.act('choose_target',a=>a.summary==='扫描 开普勒22');
  const q=h.m.menu().find(a=>a.family==='choose_card'&&a.summary.endsWith('→ 开普勒22'));
  if(q)h.take(h.m.apply(q));
 }
};
const cases=[];
for(const t of ['orange2','orange4'])for(const incomeId of [a1,b16])for(const sm of ['auto','scan']){
 cases.push([t+' funded with '+incomeId+' '+sm,h=>{tech(h,t);corner(h,a7);fill(h,4);income(h,incomeId);h.cut('funded');end(h);scan(h,sm);}]);
}
for(const [id,slot] of [['blue1',3],['blue1',4]])for(const sm of ['auto','scan']){
 cases.push([id+'/'+slot+' cash and energy '+sm,h=>{tech(h,id,slot);data(h,'blue1 下方');data(h,'blue2 下方');h.cut('funded');end(h);scan(h,sm);}]);
}
for(const sm of ['auto','scan']){
 cases.push(['purple2 + energy income + 2 for cash '+sm,h=>{tech(h,'purple2');corner(h,a7);fill(h,4);income(h,a9);trade(h,'cards-for-credit',[a1,b16]);h.cut('funded');end(h);scan(h,sm);}]);
 cases.push(['purple2 + cash income + 2 for energy '+sm,h=>{tech(h,'purple2');corner(h,a7);fill(h,4);income(h,a1);trade(h,'cards-for-energy',[a9,b16]);h.cut('funded');end(h);scan(h,sm);}]);
}
for(const t of ['blue1','orange4'])for(const sm of ['auto','scan']){
 cases.push(['purple2 then '+t+' via A9 corner '+sm,h=>{tech(h,'purple2');corner(h,a7);fill(h,4);income(h,a1);corner(h,a9);end(h);h.act('research');tech(h,t,t==='blue1'?3:null);h.cut('funded');end(h);scan(h,sm);}]);
}
const root=b.full.standard194.q;
writeZ(out,{root,...runCases(root,cases)});
