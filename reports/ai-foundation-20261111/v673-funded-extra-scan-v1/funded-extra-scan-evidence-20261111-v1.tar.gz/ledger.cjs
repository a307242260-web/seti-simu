const assert=require('node:assert/strict'),path=require('node:path'),{readZ,open,short,writeZ}=require('./controlled-r3');
const [out,teacherPath]=process.argv.slice(2),record=require(path.resolve('reports/research/d3183131.cbd73e00.quick-400.json')),saved=require(path.resolve(record.savePath));
const t=readZ(teacherPath),book={},full={};
for(const [label,start,steps] of [['standard',require(path.resolve(record.roundEnds[1].checkpointPath)).coreState.compositionEnvelope,saved.replaySteps.map((r,j)=>({i:j+1,action:r.action})).filter(r=>r.i>=record.roundEnds[1].beforeInput&&r.i<258)],['teacher',t.origin,t.done]]){
 const m=open(start),all=[];
 for(const {i,action} of steps){
  const prior=short(m),q=m.save(),choices=m.menu().map(a=>[a.family,a.summary,a.target]); m.apply(action);
  const post=short(m),gain=post.wallet.map((x,k)=>x-prior.wallet[k]);
  const row={i,action:action.summary,f:action.family,target:action.target,prior,post,gain};
  all.push(row); if([172,179,186,194,195,196,198,201,206,210,211,214,218,221,235,242].includes(i))full[label+i]={q,prior,choices};
  if((label==='standard'&&i>=179&&i<=215)||(label==='teacher'&&i>=170&&gain.some(x=>x!==0)))console.log(JSON.stringify([label,i,action.summary,gain,post.wallet,post.hand]));
 }
 if(label==='teacher')assert.deepEqual(m.save(),t.current);
 book[label]=all;m.dispose();
}
writeZ(out,{book,full});
