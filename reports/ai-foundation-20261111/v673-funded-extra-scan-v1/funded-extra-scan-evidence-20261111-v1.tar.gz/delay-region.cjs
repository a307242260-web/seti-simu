'use strict';
const {open,runCases,readZ,writeZ,short}=require('./controlled-r3'),assert=require('node:assert/strict');
const [dir,out]=process.argv.slice(2),b=readZ(dir+'/second-funding-20261111-v1.json.gz'),base=b.group219.rows.find(r=>r.label==='orange2 replaces Orange1 / research');
const root=base.start,a2='amiba_2.webp',a5='amiba_5.webp',d25='dlc_25.png';
const data=(h,name)=>{h.act('place_data');h.act('choose_target',a=>a.summary===name)};
const income=(h,id)=>h.act('choose_card',a=>a.summary==='收入 '+id);
const corner=(h,id)=>h.take(h.m.corner(id));
const end=h=>h.act('end_turn');
const scan=h=>h.act('scan');
const analysis=h=>{
 h.act('analyze');h.act('choose_target',a=>a.summary.includes('蓝3号位'));
 h.act('choose_card',a=>a.summary.includes('科学论文'));
 data(h,'第一排放置位 1');corner(h,a2);data(h,'blue2 下方');
 h.cut('analysis-cash');end(h);
 assert.deepEqual(short(h.m).wallet.slice(1),[1,2,0,0]);
};
const m=open(root);
const h={m,take:(...a)=>a,act:m.act,cut:()=>{}};
analysis(h);const funded=m.save(),initial=short(m),quoted=m.automatic();scan(h);
const first=m.save(),earth=m.menu().filter(a=>a.family==='choose_target'),fixed=[];
for(const e of earth){
 m.restore(first);m.apply(e);
 for(const p of m.menu().filter(a=>a.family==='choose_card')){
  const options={e,p};m.apply(p);fixed.push({...options,post:short(m),menu:m.menu().map(a=>a.summary)});
  m.restore(first);m.apply(e);
 }
}
m.dispose();
const afterScan=(h,e,p)=>{scan(h);h.take(h.m.apply(e));h.take(h.m.apply(p));};
const variants=[
 ['Analyze first, otherwise autonomous',analysis],
 ...fixed.map(({e,p})=>[e.summary+'/'+p.summary,h=>{afterScan(h,e,p);h.cut('scan-raw')}]),
 ...fixed.slice(0,1).map(({e,p})=>['Conserve DLC25, spend A5 only to finish income',h=>{
  afterScan(h,e,p);assert(!h.m.c.inspect().session);corner(h,a5);for(const i of [2,3,4])data(h,'第一排放置位 '+i);income(h,d25);h.cut('income');
 }]),
];
const [, ...pairVariants]=variants;
const a=runCases(root,[variants[0]]);
const c=runCases(funded,pairVariants);
writeZ(out,{root,funded,initial,quoted,fixed,...a,scanCases:c});
