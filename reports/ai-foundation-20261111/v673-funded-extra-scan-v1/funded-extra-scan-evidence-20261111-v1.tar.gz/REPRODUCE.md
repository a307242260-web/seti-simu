# V673 extra-scan funding controls (2026-11-11)
Run with working directory at clean Production source cbd73e00c plus the registered
V673 experiment JSON, round-end-2 checkpoint and save published with it. Inspect
report docs/human405-v673-r3-funded-extra-scan-20261111.md for interpretation.
The teacher fixture is the verified V670 native replay. Its complete R3 final
envelope must match the new replay. Keep PASS cards and next income outside the
R3 terminal ledger. All fixed inputs use the same native submit path as the
autonomous decisions; a fixed menu miss is not a policy result.
```sh
# Set p to the absolute directory where this archive was extracted.
node "$p/ledger.cjs" "$p/new-ledger.json.gz" "$p/teacher-20261111-v1.json.gz"
# The other scripts read the included gz files by their archived names; compare
# output actions, assets and RNG with the archive. Timings need not be identical.
node "$p/controls.cjs" "$p" "$p/new-tech.json.gz"
node "$p/extra.cjs" "$p" "$p/new-second.json.gz"
node "$p/delay-region.cjs" "$p" "$p/new-delay.json.gz"
node "$p/fourth.cjs" "$p" "$p/new-fourth.json.gz"
node "$p/summary.cjs" "$p" "$p/new-summary.json.gz"
```
