'use strict';
const {open,runCases,readZ,writeZ}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),b=readZ(dir+'/ledger-20261111-v1.json.gz');
const a1='amiba_1.webp',a7='amiba_7.webp',a9='amiba_9.webp',b16='b_16.webp',a5='amiba_5.webp',d25='dlc_25.png';
const tech=(h,t,slot)=>h.act('choose_target',a=>a.target.tileId===t&&(slot==null||a.target.blueSlot===slot));
const data=(h,name)=>{h.act('place_data');h.act('choose_target',a=>a.summary===name)};
const comp=(h,...ids)=>ids.forEach(i=>data(h,'第一排放置位 '+i));
const income=(h,id)=>h.act('choose_card',a=>a.summary==='收入 '+id);
const corner=(h,id)=>h.take(h.m.corner(id));
const end=h=>h.act('end_turn');
const trade=(h,kind,ids)=>{h.act('quick_trade',a=>a.target.tradeId===kind);for(const id of ids)h.act('choose_payment',a=>a.summary===id);h.act('choose_payment',a=>a.summary.startsWith('确认'));};
const get=(h,id)=>h.take(h.m.pick(id)),play=(h,id)=>h.take(h.m.play(id));
const research=(h,t,slot)=>{h.act('research_tech');tech(h,t,slot)};
const scan=h=>h.act('scan');
const cases194=[],cases218=[];
for(const t of ['orange2','orange4','purple1','blue1'])for(const suffix of ['auto','scan']){
 cases194.push(['purple2 + cash then '+t+' / '+suffix,h=>{
  tech(h,'purple2');corner(h,a7);comp(h,1,2,3,4);income(h,a1);corner(h,a9);
  end(h);research(h,t,t==='blue1'?3:null);
  if(t==='purple1')data(h,'blue2 下方');
  h.cut('funding');end(h);if(suffix==='scan')scan(h);
 }]);
}
for(const suffix of ['auto','scan']){
 cases194.push(['purple2 + use Blue2, A7 corner and preserve two cards / '+suffix,h=>{
  tech(h,'purple2');comp(h,1);data(h,'blue2 下方');corner(h,a7);comp(h,2,3);
  trade(h,'cards-for-credit',[a1,b16]);
  h.cut('funding');end(h);if(suffix==='scan')scan(h);
 }]);
}
for(const t of ['orange2','orange4','purple2'])for(const style of ['research','analyze','play-region']){
 cases218.push([t+' replaces Orange1 / '+style,h=>{
  research(h,t);if(style==='research'){
    corner(h,a9);corner(h,b16);end(h);research(h,'blue1',3);
    comp(h,5,6);data(h,'blue1 下方');h.cut('funding');end(h);
  } else if(style==='analyze'){
    comp(h,5,6);end(h);h.act('analyze');
  } else {
    corner(h,a9);corner(h,b16);end(h);research(h,'blue1',3);
    comp(h,5,6);data(h,'blue1 下方');end(h);play(h,a5);
  }
 }]);
}
for(const t of ['orange2','orange4','purple2'])for(const d of [b16,d25]){
 cases218.push(['Blue1 now, '+t+' after with '+d,h=>{
  research(h,'blue1',3);comp(h,5,6);data(h,'blue1 下方');corner(h,a9);corner(h,d);
  end(h);research(h,t);end(h);
 }]);
}
const start218=(()=>{const m=open(b.full.standard218.q);m.act('end_turn');const q=m.save();m.dispose();return q})();
writeZ(out,{group194:runCases(b.full.standard194.q,cases194),group219:runCases(start218,cases218)});
