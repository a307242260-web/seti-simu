'use strict';
const path=require('node:path'),{readZ,short,open,writeZ}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),ledger=readZ(dir+'/ledger-20261111-v1.json.gz');
const control=readZ(dir+'/tech-funding-20261111-v1.json.gz'),second=readZ(dir+'/second-funding-20261111-v1.json.gz'),delay=readZ(dir+'/delay-region-20261111-v1.json.gz'),fourth=readZ(dir+'/fourth-20261111-v1.json.gz');
const groups=[control,second.group194,second.group219,delay,delay.scanCases];
const actions=groups.flatMap(g=>g.rows.flatMap(r=>r.actions)).concat(fourth.results.flatMap(r=>r.actions));
const account=(name)=>{
 const book=ledger.book[name],last=book.findLast(x=>x.f==='analyze').i;
 return {scans:book.filter(x=>x.f==='scan').map(x=>x.i),last,after:book.filter(x=>x.i>last&&x.gain[4]>0).map(x=>[x.i,x.action,x.gain[4]])};
};
const probe=(envelope)=>{
 const m=open(envelope),z=m.automatic();
 const summary={assets:short(m),first:z.a,complete:z.complete,n:z.n,ms:z.ms,value:z.value,roots:z.roots};
 m.dispose();return summary;
};
const roots={};
for(const i of [194,235,242])roots['standard'+i]=probe(ledger.full['standard'+i].q);
const m=open(ledger.full.standard218.q);m.act('end_turn');m.act('research_tech');roots.standard220=probe(m.save());m.dispose();
roots.orange2Amiba5=probe(second.group219.rows.find(r=>r.label==='orange2 replaces Orange1 / research').start);
roots.orange2FundedScan=probe(delay.funded);
const q={teacher:account('teacher'),standard:account('standard'),groups:groups.map(g=>({closed:g.rows.filter(r=>r.settled).length,failed:g.failures.length,gate:g.rows.filter(r=>typeof r.stop==='object').length})),fourth:fourth.results.map(r=>[r.name,r.card,r.stop,r.terminal?.totalScore]),maxInput:Math.max(...actions.map(a=>a.n||0)),maxMs:Math.max(...actions.map(a=>a.ms||0)),fourthRaw:fourth.first,roots};
writeZ(out,q);
console.log(JSON.stringify({...q,roots:Object.fromEntries(Object.entries(roots).map(([n,r])=>[n,[r.first.summary,r.n,r.ms,r.value,r.roots.map(y=>[y.actionId,y.value]).slice(0,35)]]))}));
