'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {open,readZ,writeZ}=require('./controlled-r3');
const [input,out,reuse]=process.argv.slice(2),src=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(src,module);
mod.filename=src;mod.paths=Module._nodeModulePaths(path.dirname(src));
let code=fs.readFileSync(src,'utf8');
function sub(from,to){assert.equal(code.split(from).length,2,from);code=code.replace(from,to);}
sub('    function directEarthShipment(node, stored) {',`    // Diagnostic fixed named path: use wallet only, no purchase or card.
    function directMixedEarthPath(state,owner,ship,from,earth){
      if(owner.resources.energy<3)return null;
      const move=rockets.createStaticCoordinateMoveQuery(state.pieces,ship.id);
      const steps=(at)=>rocketAbilities.MOVE_DIRECTIONS.flatMap(d=>{
        const r=move(at,d.deltaX,d.deltaY);
        return r.ok?[{rocketId:ship.id,deltaX:d.deltaX,deltaY:d.deltaY,to:r.to,
          requiredMovePoints:rocketAbilities.getRequiredMovePointsFromCoordinate(state,owner,at)}]:[];
      });
      const same=(x,y)=>x.x===y.x&&x.y===y.y;
      for(const a of steps(from))for(const b of steps(a.to)){
        if(same(b.to,earth)&&a.requiredMovePoints+b.requiredMovePoints===3
          &&[a.requiredMovePoints,b.requiredMovePoints].every(n=>n===1||n===2))return [a,b];
      }
      return null;
    }

    function directEarthShipment(node, stored) {`);
sub('      const path = from && earth && shortEarthPath(state, p, ship, from, earth, Math.min(3, p.resources.energy));',`      const path=from&&earth&&(shortEarthPath(state,p,ship,from,earth,Math.min(3,p.resources.energy))
        ||directMixedEarthPath(state,p,ship,from,earth));`);
sub('&& a.target.deltaX === first.deltaX && a.target.deltaY === first.deltaY && a.payload?.requiredMovePoints === 1);', '&& a.target.deltaX === first.deltaX && a.target.deltaY === first.deltaY && a.payload?.requiredMovePoints === (first.requiredMovePoints??1));');
sub(`            : input % 2 === 0 ? find(a => a.family === "move" && matches(a) && a.payload?.requiredMovePoints === 1)
            : source?.family === "move" && matches(source) && find(a => a.family === "choose_payment"
              && a.target?.kind === "move-payment" && a.target.choiceId === "energy" && a.payload?.energyCost === 1);`,`            : input % 2 === 0 ? find(a => a.family === "move" && matches(a) && a.payload?.requiredMovePoints === (move.requiredMovePoints??1))
            : source?.family === "move" && matches(source) && find(a => a.family === "choose_payment"
              && a.target?.kind === "move-payment" && a.target.choiceId === "energy" && a.payload?.energyCost === (move.requiredMovePoints??1));`);
if(reuse)code=require(reuse+'/reuse-yellow2.cjs')(require(reuse+'/reuse-scan.cjs')(code,require(reuse+'/prior.cjs')));
mod._compile(code,src);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent')),rows=[];
for(const row of readZ(input).rows){
 const m=open(row.root),seatId='player-white',port=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
 try{
  const original=m.automatic(),q=createSearchAgent({analysisPort:port,seatId}).decide({seatId,legalActions:m.menu()}).search;
  assert.deepEqual(m.save(),row.root);
  const choices=m.menu();
  const edge=q.lines[0].edges.find(e=>e.resourcePlan?.goal?.directEnergy&&e.resourcePlan.goal.path.some(x=>x.requiredMovePoints===2));
  assert(edge&&edge.goalStatus==='completed');
  const action=choices.find(a=>a.actionId===q.actionId);
  const steps=[];for(const id of edge.steps){const a=m.menu().find(a=>a.actionId===id);assert(a);steps.push(m.apply(a));}
  assert.deepEqual(m.save(),row.delivered);
  const result={label:row.label,card:row.card,action:action.summary,base:[original.a.summary,original.value,original.n,original.ms],
   candidate:[q.value,q.diagnostics.nativeExecutions,q.rootAndSearchMilliseconds],added:q.lines.find(l=>l.node===edge.target).value,chosen:edge.actionId===q.actionId,
   complete:q.complete&&!q.unresolved.length};
  rows.push({result,root:row.root,q,steps,end:m.save()});
  console.log(JSON.stringify(result));
 }finally{port.close();m.dispose();}
}
writeZ(out,{rows});
