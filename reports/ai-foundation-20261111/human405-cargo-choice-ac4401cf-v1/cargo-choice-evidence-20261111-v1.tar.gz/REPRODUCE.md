# 复现
使用 Node 22，从生产源码 ac4401cf7 或 5526a2154 的仓库根目录执行。先将本包解到一个临时目录，记为 CASE_DIR。
从仓库内的 reports/ai-foundation-20261111/human405-scored-transport-move-v1/scored-transport-move-evidence-20261111-v1.tar.gz 解出 scored-move-admission-20261111-v1.json.gz，放到同一目录。不要覆盖已记录的结果。

```sh
node "$CASE_DIR/cargo-choice.cjs" "$CASE_DIR/scored-move-admission-20261111-v1.json.gz" "$CASE_DIR/choice-check.json.gz"
node "$CASE_DIR/cargo-choice-tail.cjs" "$CASE_DIR/choice-check.json.gz" "$CASE_DIR/tail-check.json.gz"
node "$CASE_DIR/weighted-return.cjs" "$CASE_DIR/tail-check.json.gz" "$CASE_DIR/return-check.json.gz"
node "$CASE_DIR/weighted-return-candidate.cjs" "$CASE_DIR/return-check.json.gz" "$CASE_DIR/candidate-check.json.gz"
```

若复查 07／B111 后续超限点，从 reports/ai-foundation-20261111/human405-retention-search-39f19bec-v1/retention-search-evidence-20261111-v1.tar.gz 提取 reuse-yellow2.cjs、reuse-scan.cjs、prior.cjs 到同一临时目录后执行：

```sh
node "$CASE_DIR/salary-gates.cjs" "$CASE_DIR/return-check.json.gz" "$CASE_DIR" "$CASE_DIR/gate-check.json.gz"
```

用随包的 SHA256SUMS 校验已记录输入、脚本及输出。计时随机器负载变化；涉及单点准入的实验在超限时拒绝继续提交动作。
