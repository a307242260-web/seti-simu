'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,short,readZ,writeZ}=require('./controlled-r3');
const load=p=>require(path.resolve(p)),sun=load('randomizer/solar-system/core'),ability=load('randomizer/game/abilities/rocket'),rockets=load('randomizer/game/rockets');
const [input,out]=process.argv.slice(2),rows=[];
function cheapest(state,owner,ship,dest,max){
 const at=rockets.getRocketSectorCoordinate(ship),move=rockets.createStaticCoordinateMoveQuery(state.pieces,ship.id);
 const key=p=>p.x+':'+p.y,seen=new Set(),q=[{at,cost:0,steps:[]}];
 while(q.length){
  q.sort((a,b)=>a.cost-b.cost||a.steps.length-b.steps.length);
  const node=q.shift(),k=key(node.at);if(seen.has(k))continue;
  seen.add(k);if(k===key(dest))return node;
  const need=ability.getRequiredMovePointsFromCoordinate(state,owner,node.at);
  if(!Number.isSafeInteger(need)||need<=0||node.cost+need>max)continue;
  for(const d of ability.MOVE_DIRECTIONS){
   const a=move(node.at,d.deltaX,d.deltaY);
   if(!a.ok||seen.has(key(a.to)))continue;
   q.push({at:a.to,cost:node.cost+need,steps:[...node.steps,{...d,need}]});
  }
 }
 return null;
}
for(const row of readZ(input).rows.filter(r=>r.label.includes('leave-on-board'))){
 const m=open(row.root),accepted=[];
 try{
  const add=(a,kind,d={})=>{assert(a);accepted.push({action:m.apply(a),kind,...d});};
  for(const x of row.accepted){
   if(!x.fixed&&!x.passive)break;
   add(x.action,'setup');
  }
  const root=m.save(),state=m.state(),owner=m.player(),ship=m.facts().probes[0];
  const job=Object.values(state.aliens.chong.transportTasksByRocketId).find(x=>x.fossilId===ship.fossilId);
  const dest=sun.collectPlanetLocations(state.solarSystem).find(p=>p.planetId===job.destinationPlanetId);
  const route=cheapest(state,owner,ship,dest,owner.resources.energy),before=short(m);
  assert(route?.steps.length===2);assert.equal(route.cost,3);assert.deepEqual(route.steps.map(x=>x.need),[1,2]);
  for(const d of route.steps){
   add(m.menu().find(a=>a.family==='move'&&a.target.rocketId===ship.id&&a.target.deltaX===d.deltaX&&a.target.deltaY===d.deltaY
    &&a.payload.requiredMovePoints===d.need),'delivery');
   add(m.menu().find(a=>a.family==='choose_payment'&&a.payload.energyCost===d.need&&a.target.choiceId==='energy'),'delivery');
  }
  add(m.menu().find(a=>a.family==='complete_task'&&a.target.cardInstanceId===job.cardId&&a.target.ruleId==='transport'),'delivery');
  const delivered=m.save(),after=short(m);
  let cp,stop;
  for(let i=0;i<180;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!=='player-white'){const a=[];m.advanceOpponents(a);a.forEach(action=>accepted.push({action,kind:'passive'}));continue;}
   const q=m.automatic(cp);
   if(!q.a||!q.complete||q.n>256||q.ms>600){stop={kind:'gate',a:q.a?.summary,n:q.n,ms:q.ms};break;}
   cp=q.checkpoint;add(q.a,'auto',{n:q.n,ms:q.ms});
  }
  assert(stop);
  const score=stop==='terminal'?m.state().match.finalScores.find(x=>x.playerId==='player-white'):null,end=m.save();
  m.restore(row.root);accepted.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),end);
  rows.push({label:row.label,card:row.card,first:row.root,root,route,before,after,delivered,accepted,stop,score,end});
  console.log(JSON.stringify({label:row.label,card:row.card,cost:route.cost,after:after.wallet,score:score?.totalScore,stop,original:row.terminal.totalScore,
   peak:[Math.max(...accepted.map(x=>x.n||0)),Math.max(...accepted.map(x=>x.ms||0))]}));
 }finally{m.dispose();}
}
assert.equal(rows.length,4);
writeZ(out,{rows});
