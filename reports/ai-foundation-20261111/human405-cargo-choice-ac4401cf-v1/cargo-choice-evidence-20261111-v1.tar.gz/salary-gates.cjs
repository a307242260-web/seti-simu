'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {open,readZ,writeZ,short}=require('./controlled-r3');
const [input,reuse,out]=process.argv.slice(2),src=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(src,module);
mod.filename=src;mod.paths=Module._nodeModulePaths(path.dirname(src));
const source=fs.readFileSync(src,'utf8'),{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
mod._compile(require(reuse+'/reuse-yellow2.cjs')(require(reuse+'/reuse-scan.cjs')(source,require(reuse+'/prior.cjs'))),src);
const createOriginal=require(src).createAnalysisPort,createPreview=mod.exports.createAnalysisPort,rows=[];
function decide(m,portFactory,cp){
 const seatId='player-white',port=portFactory({composition:m.c,seatId,maxCacheEntries:0});
 const agent=createSearchAgent({analysisPort:port,seatId});
 try{
  if(cp)agent.loadCheckpoint(cp);
  const q=agent.decide({seatId,legalActions:m.menu()}).search;
  return {q,cp:structuredClone(agent.createCheckpoint()),a:m.menu().find(a=>a.actionId===q.actionId)};
 }finally{port.close();}
}
const pass=q=>q.complete&&!q.unresolved.length&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600;
for(const r of readZ(input).rows.filter(r=>r.stop!=='terminal')){
 const m=open(r.end),accepted=[];
 try{
  const baseline=decide(m,createOriginal),variant=decide(m,createPreview);
  for(const k of ['actionId','value','realization','preparationDebt','complete','roots','lines','unresolved','selectionPlan','candidates','sharedPrefixGraph'])assert.deepEqual(baseline.q[k],variant.q[k],k);
  assert.deepEqual(m.save(),r.end);
  const stats=d=>[d.q.diagnostics.nativeExecutions,d.q.rootAndSearchMilliseconds,d.a?.summary];
  console.log(JSON.stringify({label:r.label,base:stats(baseline),fast:stats(variant),pass:pass(variant.q)}));
  if(!pass(variant.q)){rows.push({label:r.label,card:r.card,root:r.end,baseline:baseline.q,variant:variant.q,stop:'first-gate'});continue;}
  let current=variant,cp,stop;
  for(let i=0;i<140;i++){
   if(!pass(current.q)||!current.a){stop={kind:'gate',root:m.save(),stats:stats(current)};break;}
   cp=current.cp;accepted.push({action:m.apply(current.a),auto:true,stats:stats(current)});
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!=='player-white'){
    const a=[];m.advanceOpponents(a);accepted.push(...a.map(action=>({action,passive:true})));
   }
   if(m.state().turn.gameEnded){stop='terminal';break;}
   current=decide(m,createPreview,cp);
  }
  assert(stop);
  const end=m.save(),score=stop==='terminal'?m.state().match.finalScores.find(x=>x.playerId==='player-white'):null;
  m.restore(r.end);accepted.forEach(a=>m.apply(a.action));assert.deepEqual(m.save(),end);
  rows.push({label:r.label,card:r.card,root:r.end,baseline:baseline.q,variant:variant.q,stop,accepted,end,score,assets:short(m)});
  console.log(JSON.stringify({label:r.label,stop:typeof stop==='string'?stop:stop.stats,score:score?.totalScore,accepted:accepted.length}));
 }finally{m.dispose();}
}
writeZ(out,{rows});
