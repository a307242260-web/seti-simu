'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [input,out]=process.argv.slice(2),d=readZ(input),m=open(d.root),rows=[];
const before=d.actions.findIndex(x=>x.action.target?.choiceId==='chong-fossil:fossil_06');assert.equal(before,16);
d.actions.slice(0,before).forEach(x=>m.apply(x.action));
const root=m.save(),original=m.automatic();
assert(original.complete&&original.n<=256&&original.ms<=600);
console.log(JSON.stringify({pickup:original.a.summary,value:original.value,n:original.n,ms:original.ms,options:m.menu().map(a=>a.summary)}));
const cases=[...['01','06','07'].map(id=>[id,'auto']),...['06','07'].flatMap(id=>['leave-on-board','before-scan','before-last-analysis'].map(k=>[id,k]))];
for(const [id,mode] of cases){
 m.restore(root);const actions=[],qrows=[];let stop,cp,settledCargo,insert,firstDrop;
 const add=(action,extra={})=>actions.push({action:m.apply(action),...extra});
 const find=(f,p)=>m.menu().find(a=>a.family===f&&(!p||p(a)));
 const fixed=(f,p)=>{const a=find(f,p);assert(a,JSON.stringify([id,mode,f,m.menu().map(a=>a.summary)]));add(a,{fixed:true});};
 fixed('choose_target',a=>a.target.choiceId==='chong-fossil:fossil_'+id);
 if(mode==='leave-on-board'){
  fixed('complete_task',a=>a.summary.includes('b_117.webp'));fixed('end_turn');
  const others=[];m.advanceOpponents(others);actions.push(...others.map(action=>({action,passive:true})));
  assert(find('pass'));stop='settled';
 }
 for(let i=0;!stop&&i<140;i++){
  if(m.menu()[0].actorId!=='player-white'){
   const others=[];m.advanceOpponents(others);actions.push(...others.map(action=>({action,passive:true})));continue;
  }
  const q=m.automatic(cp),a=q.a;
  if(!q.complete||!a||q.n>256||q.ms>600){stop={kind:'gate',n:q.n,ms:q.ms,choice:a?.summary};break;}
  if(a.family==='pass'){stop='settled';break;}
  if(settledCargo&&find('pass')&&(mode==='before-scan'&&a.family==='scan'
    ||mode==='before-last-analysis'&&a.family==='analyze')){
   stop='settled';firstDrop={a,n:q.n,ms:q.ms,value:q.value};break;
  }
  const before=short(m);
  cp=q.checkpoint;add(a,{n:q.n,ms:q.ms,v:q.value});
  if(!settledCargo&&a.family==='complete_task'&&a.target.ruleId==='transport')settledCargo={before,after:short(m),state:m.save()};
  if(!insert&&a.target?.choiceId?.startsWith('income:'))insert={before,after:short(m)};
  if(a.phase==='main'||a.family==='end_turn')qrows.push({action:a,before,n:q.n,ms:q.ms});
 }
 assert(stop);
 const state=m.save(),assets=short(m),facts=m.facts();
 const peak=[Math.max(...actions.map(x=>x.n||0)),Math.max(...actions.map(x=>x.ms||0))];
 m.restore(root);actions.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),state);
 const label=id+' / '+mode;
 rows.push({id,mode,label,root,actions,qrows,assets,facts,state,stop,settledCargo,insert,firstDrop,peak});
 console.log(JSON.stringify({label,stop,assets,peak,delivery:!!settledCargo,insert:!!insert,drop:firstDrop?.a.summary}));
}
writeZ(out,{root,original,rows});
m.dispose();
