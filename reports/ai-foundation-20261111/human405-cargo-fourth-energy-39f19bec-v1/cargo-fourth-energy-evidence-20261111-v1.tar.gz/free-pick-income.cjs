'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [input,out,mode]=process.argv.slice(2),prior=readZ(input),m=open(prior.source),cases=[];
const setup=prior.cases.find(c=>c.label.startsWith('buy dlc_15.png / income dlc_14.png / keep')).prefix;
const knownFill=setup.slice(0,setup.findIndex(a=>a.target?.tradeId==='publicity-for-card'));
const WHITE='player-white',D14='dlc_14.png',A5='amiba_5.webp',D15='dlc_15.png',D17='dlc_17.png';
function run(label,forced){
 m.restore(prior.source);
 const accepted=[],diagnostics=[],checkpoints={};
 const add=(a,kind='fixed',d={})=>accepted.push({action:m.apply(a),kind,...d});
 const act=(kind,p)=>{const a=m.menu().find(x=>x.family===kind&&(!p||p(x)));assert(a,JSON.stringify([label,kind,m.menu().map(q=>q.summary)]));add(a);};
 const end=()=>{act('end_turn');const pass=[];m.advanceOpponents(pass);accepted.push(...pass.map(action=>({action,kind:'passive'})));};
 const pick=id=>{const q=m.state().cards.publicCards.find(c=>c?.cardId===id);assert(q);act('choose_card',a=>a.target.cardInstanceId===q.id||a.target.source==='public'&&m.state().cards.publicCards[a.target.slotIndex]?.id===q.id);};
 const swap=(out,incoming)=>{
  const c=m.player().hand.find(c=>c.cardId===out);assert(c);
  act('industry',a=>a.target.abilityId==='deepspace_swap_cards');
  act('choose_card',a=>a.target.cardInstanceId===c.id);
  pick(incoming);
 };
 const play=id=>act('play_card',a=>a.target.cardInstanceId===m.player().hand.find(c=>c.cardId===id)?.id);
 const corner=id=>act('card_corner',a=>a.target.cardInstanceId===m.player().hand.find(c=>c.cardId===id)?.id&&a.payload.kind==='resource');
 const place=target=>{act('place_data');act('choose_target',a=>target==='computer'?a.target.target==='computer':a.target.target==='blueBonus'&&a.target.blueSlot===target);};
 const tuck=id=>{const c=m.player().hand.find(c=>c.cardId===id);assert(c);place('computer');act('choose_card',a=>a.target.cardInstanceId===c.id);};
 const trade=id=>act('quick_trade',a=>a.target.tradeId===id);
 const buy=id=>{trade('publicity-for-card');pick(id);};
 const peek=k=>{const q=m.automatic();assert(m.menu().some(a=>a.actionId===q.a?.actionId));diagnostics.push({k,root:m.save(),q,short:short(m),menu:m.menu()});};
 const capture=k=>{checkpoints[k]=m.save();};
 knownFill.forEach(a=>add(a));capture('after-B117');
 forced({act,end,pick,play,corner,tuck,place,trade,buy,peek,capture,swap});
 const cut=accepted.length,from=short(m);
 let cp,stop;
 for(let i=0;i<100;i++){
  if(m.menu()[0].actorId!==WHITE){const pass=[];m.advanceOpponents(pass);accepted.push(...pass.map(action=>({action,kind:'passive'})));continue;}
  const q=m.automatic(cp);
  if(!q.a||!q.complete||q.n>256||q.ms>600){stop={kind:'gate',a:q.a?.summary,n:q.n,ms:q.ms,complete:q.complete};break;}
  if(q.a.family==='pass'){stop='settled';break;}
  cp=q.checkpoint;add(q.a,'auto',{n:q.n,ms:q.ms});
 }
 assert(stop);
 const e=m.save(),assets=short(m),facts=m.facts(),peak=[Math.max(0,...accepted.map(x=>x.n||0)),Math.max(0,...accepted.map(x=>x.ms||0))];
 m.restore(prior.source);accepted.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),e);
 cases.push({label,accepted,diagnostics,checkpoints,cut,from,stop,e,assets,facts,peak});
 console.log(JSON.stringify({label,stop,assets,peak,auto:accepted.slice(cut).map(x=>x.action.summary)}));
}
const launch=h=>{h.end();h.play(A5);};
const take=h=>{h.act('choose_target',a=>a.target.choiceId==='symbol:red_1');};
try{
 if(mode==='salary'){
  for(const card of [D15,D17])for(const tuck of [D14,'b_60.webp']){
   run('A5 / free '+card+' / new B60 / electricity '+tuck,h=>{
    launch(h);h.pick(card);take(h);h.buy(card===D15?D17:D15);
    h.swap(card===D15?D17:D15,'b_60.webp');
    h.corner(card);h.tuck(tuck);h.end();
   });
  }
 } else if(mode==='swap'){
  for(const card of [D15,D17]){
   run('swap A5 for '+card+' / electricity / leave market',h=>{h.swap(A5,card);h.corner(card);h.tuck(D14);h.end();});
   run('swap A5 for '+card+' / electricity / buy back',h=>{h.swap(A5,card);h.corner(card);h.tuck(D14);h.buy(A5);h.end();});
  }
  run('swap DLC14 for DLC17 / electricity / leave market',h=>{h.swap(D14,D17);h.corner(D17);h.tuck(A5);h.end();});
 } else {
 run('current-after-B117' ,h=>h.peek('B117'));
 run('A5-start-only',h=>{launch(h);h.peek('free-pick');});
 for(const id of [D15,D17]){
  run('A5 / free '+id,h=>{launch(h);h.pick(id);h.peek('red-symbol');});
  run('A5 / free '+id+' / red4 / electricity',h=>{launch(h);h.pick(id);take(h);h.peek('post-A5');h.corner(id);h.tuck(D14);});
  run('A5 / free '+id+' / red4 / electricity / keep other',h=>{launch(h);h.pick(id);take(h);h.corner(id);h.tuck(D14);h.buy(id===D15?D17:D15);h.end();});
 }
 }
 writeZ(out,{source:prior.source,cases});
}finally{m.dispose();}
