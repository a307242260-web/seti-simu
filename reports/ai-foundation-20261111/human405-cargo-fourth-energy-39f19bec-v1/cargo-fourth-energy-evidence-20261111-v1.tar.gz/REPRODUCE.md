Use Node 22 from the repository root at 27bacf364 (AI source 39f19bec). Use fresh outputs and avoid other measured workloads.

```sh
proof=/path/to/this/archive
out=$(mktemp -d)
old=reports/ai-foundation-20261111/v661-r3-cargo-income-retention-v1/cargo-income-retention-native-20261111-v1.tar.gz
reuse=reports/ai-foundation-20261111/human405-retention-search-39f19bec-v1/retention-search-evidence-20261111-v1.tar.gz
tar -xOf "$old" ./retained-income-20261111-v1.json.gz > "$out/start.json.gz"
mkdir "$out/reuse"
tar -xzf "$reuse" -C "$out/reuse" ./reuse-scan.cjs ./reuse-yellow2.cjs ./prior.cjs
for mode in free swap salary; do
  node "$proof/free-pick-income.cjs" "$out/start.json.gz" "$out/${mode}-r3.json.gz" "$mode"
  node "$proof/free-pick-tail.cjs" "$out/${mode}-r3.json.gz" "$out/${mode}-r4.json.gz"
done
node "$proof/salary-gates.cjs" "$out/salary-r4.json.gz" "$out/reuse" "$out/resumed.json.gz"
```

R3 starts at the same recorded post-landing checkpoint. Fixed actions are marked as such; the later autonomous suffix respects both search gates. The R4 trials fix the keep-card to B111 or B32 after PASS. For the three continuations the script independently compares the cold original and isolated equivalent-settlement graph at the original stop, then proceeds only inside both gates. This is not a new autonomous game from setup.
