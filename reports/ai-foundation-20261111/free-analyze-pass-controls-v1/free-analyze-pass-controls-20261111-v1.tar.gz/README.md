# 接近 PASS 的扫描控制
使用 32985c4af 的项目根，运行 pass-other-contrast.cjs，参数为正式记录的轮末 checkpoint 路径和新 gzip 输出文件。
三个源记录的文件名和轮次见 pass-near-main-filtered-20261111-v1.json。各 gzip 保留共用原根、动作、逐轮结果和两处未提交的超限存档。
