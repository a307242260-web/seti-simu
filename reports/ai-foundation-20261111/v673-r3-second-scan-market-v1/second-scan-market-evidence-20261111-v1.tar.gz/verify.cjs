'use strict';
const assert=require('node:assert/strict'),{open,readZ}=require('./controlled-r3');
const r3=readZ(process.argv[2]),r4=readZ(process.argv[3]);
const white='player-white';let inputs=0,third=0,fourth=0;
for(const r of r3.rows){
 const m=open(r3.root);
 try{
  for(const a of r.prefix){assert.deepEqual(m.apply(a),a);inputs++;}
  assert.deepEqual(m.save(),r.start);
  for(const x of r.actions){assert.deepEqual(m.apply(x.action),x.action);inputs++;}
  assert.deepEqual(m.save(),r.end);third++;
 }finally{m.dispose();}
}
for(const r of r4.results){
 const m=open(r.root);
 try{
  for(const x of r.actions){assert.deepEqual(m.apply(x.action),x.action);inputs++;}
  assert.deepEqual(m.save(),r.end);
  assert(m.state().turn.gameEnded);
  assert.deepEqual(m.state().match.finalScores.find(p=>p.playerId===white),r.terminal);
  fourth++;
 }finally{m.dispose();}
}
console.log(JSON.stringify({inputs,third,fourth}));
