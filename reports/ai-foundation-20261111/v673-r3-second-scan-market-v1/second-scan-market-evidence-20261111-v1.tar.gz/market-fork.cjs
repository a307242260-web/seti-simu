'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [input,out]=process.argv.slice(2),ledger=readZ(input),get=k=>ledger.rows.find(r=>r.k===k),root=get(212).root;
const key=k=>get(k).action.target.choiceId;
const by=(c,k)=>c.act(get(k).action.family,a=>a.target.choiceId===key(k));
const rep=(c,k)=>c.take(c.m.apply(get(k).action));
const pass=c=>{c.act('end_turn');const a=[];c.m.advanceOpponents(a);c.take(...a);};
const cut=(c,where)=>c.cut(where);
function scan(c){
 c.act('choose_card',a=>a.target.nebulaId==='sector-3-a'&&a.summary.startsWith('dlc_17.png'));
 for(const k of [213,214,215,216])byOrRep(c,k);
 cut(c,'same-sector-settled');
 pass(c);
}
function byOrRep(c,k){const a=get(k).action;return a.target.choiceId?by(c,k):c.act(a.family,x=>x.summary===a.summary);}
function choosePublic(c,id){return c.act('choose_card',a=>a.summary===id&&a.target.source!=='blind');}
function fund(c,reward,move=true){
 scan(c);
 c.act('research_tech');by(c,219);choosePublic(c,reward);pass(c);
 if(move){
  rep(c,222);
  const id=c.m.player().hand.find(x=>x.cardId===reward)?.id;
  c.act('choose_payment',a=>a.target.cardIds?.length===1&&a.target.cardIds[0]===id);
 }else c.take(c.m.corner('b_16.webp'));
 c.take(c.m.corner('amiba_9.webp'));
 c.act('research_tech');by(c,226);
 for(const slot of [null,null,3]){
  c.act('place_data');
  c.act('choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');
 }
 cut(c,'blue-cash');
 pass(c);
}
const cases=[['scan alternate only',scan]];
for(const reward of ['dlc_20.png','dlc_16.png']){
 cases.push([reward+' fixed orange and blue',c=>fund(c,reward)]);
 const m=open(root),probe={m,take:(...a)=>a[0],act:m.act,cut:()=>{}};
 try{
  fund(probe,reward);m.play('amiba_5.webp');
  for(const card of m.menu().filter(a=>a.target.source==='public').map(a=>a.summary)){
   const play=c=>{fund(c,reward);c.take(c.m.play('amiba_5.webp'));choosePublic(c,card);by(c,236);cut(c,'after-4pts');};
   cases.push([reward+' then four points with '+card,play]);
   const before=m.save();
   try{
    choosePublic(probe,card);by(probe,236);
    const options=m.state().cards.publicCards.map(a=>a?.cardId).filter(Boolean);
    for(const company of options.filter(id=>['dlc_14.png','dlc_15.png','dlc_17.png'].includes(id))){
     cases.push([reward+' then four points with '+card+' / swap '+company,c=>{play(c);c.take(...c.m.swap('b_16.webp',company));}]);
    }
    cases.push([reward+' then four points with '+card+' / analyze before company',c=>{
     play(c);pass(c);c.act('analyze');by(c,242);by(c,243);cut(c,'analyzed-with-company');}]);
   }finally{m.restore(before);}
  }
 }finally{m.dispose();}
}
const result=runCases(root,cases);
const before=ledger.rows.find(r=>r.k===217),settled=result.rows[0]?.checkpoints['same-sector-settled'];
if(settled){
 const a=open(before.root),b=open(settled.state);
 try{
 const af=a.facts(),bf=b.facts();
 for(const k of ['wallet','income','computer','blue','hand','tech','rng','probes','wins','traces'])assert.deepEqual(bf[k],af[k],k);
 assert.notDeepEqual(af.market,bf.market);
 console.log('same realized scan and rewards, different market',JSON.stringify([af.market,bf.market]));
 }finally{a.dispose();b.dispose();}
}
writeZ(out,{root,...result});
