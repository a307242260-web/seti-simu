Run on Node 22 from the repository root with Production JS at 433765e936e26b6a25c8b599f580792471e3445b. Let E be the directory where this archive was extracted. Choose fresh output names.
node "$E/ledger.cjs" /tmp/seti-r3-market-ledger.json.gz
node "$E/market-fork.cjs" /tmp/seti-r3-market-ledger.json.gz /tmp/seti-r3-market-forks.json.gz
node "$E/why.cjs" /tmp/seti-r3-market-forks.json.gz /tmp/seti-r3-market-quote.json.gz
node "$E/without-supply.cjs" /tmp/seti-r3-market-quote.json.gz /tmp/seti-r3-market-quote-control.json.gz
node "$E/fourth.cjs" /tmp/seti-r3-market-forks.json.gz reports/research/d3183131.cbd73e00.quick-400.json.round-end-3.checkpoint.json /tmp/seti-r3-market-fourth.json.gz
node "$E/verify.cjs" /tmp/seti-r3-market-forks.json.gz /tmp/seti-r3-market-fourth.json.gz
For validation without rerunning search, point verify.cjs at the two archived fork/fourth files.
