'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
const [input,out]=process.argv.slice(2),p=path.resolve('randomizer/game/ai/analysis-port.js');
const source=fs.readFileSync(p,'utf8'),needle='      return dataCards[0].id;';assert.equal(source.split(needle).length,2);
const mod=new Module(p,module);mod.filename=p;mod.paths=Module._nodeModulePaths(path.dirname(p));
const supply=[];globalThis.rejectedSupplyProof=(goal,card)=>supply.push({goal,card});
mod._compile(source.replace(needle,'      globalThis.rejectedSupplyProof(goal.nebulaId,dataCards[0]);\n      return null;'),p);
mod.loaded=true;require.cache[p]=mod;
const {open,readZ,writeZ}=require('./controlled-r3'),{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const {root,q:original}=readZ(input),m=open(root),seatId='player-white',port=mod.exports.createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
try{
 const legalActions=m.menu(),q=createSearchAgent({seatId,analysisPort:port}).decide({seatId,legalActions}).search,summary=id=>legalActions.find(a=>a.actionId===id)?.summary;
 assert.deepEqual(m.save(),root);assert(q.complete&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600);
 const info={supply,selected:[summary(original.actionId),summary(q.actionId)],values:[original.value,q.value],native:[original.diagnostics.nativeExecutions,q.diagnostics.nativeExecutions],ms:q.rootAndSearchMilliseconds};
 console.log(JSON.stringify(info));writeZ(out,{root,q,...info});
}finally{port.close();m.dispose();}
