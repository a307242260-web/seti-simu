'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ}=require('./controlled-r3'),
 {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port')),{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const root=readZ(process.argv[2]).root,m=open(root),seatId='player-white',port=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
try{
 const legal=m.menu(),q=createSearchAgent({seatId,analysisPort:port}).decide({seatId,legalActions:legal}).search;
 assert.deepEqual(m.save(),root);
 const pair=legal.filter(a=>a.target.nebulaId==='sector-3-a').map(a=>({summary:a.summary,root:q.roots.find(r=>r.actionId===a.actionId)}));
 console.log(JSON.stringify({n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,choice:legal.find(a=>a.actionId===q.actionId).summary,pair}).slice(0,3400));
 writeZ(process.argv[3],{root,q,pair});
}finally{port.close();m.dispose();}
