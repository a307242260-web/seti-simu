'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,short,runCases,readZ,writeZ}=require('./controlled-r3');
const deck=require(path.resolve('randomizer/game/cards/deck'));
const [src,marsPath,out]=process.argv.slice(2),e=readZ(src),mars=readZ(marsPath),results={};
const hand=(h,id)=>h.m.player().hand.find(x=>x.cardId===id);
const pick=(h,id)=>h.take(h.m.pick(id));
const corner=(h,id)=>h.take(h.m.corner(id));
const play=(h,id)=>h.take(h.m.play(id));
const white=h=>{const a=[];h.m.advanceOpponents(a);h.take(...a);};
function place(h,t='computer'){
 h.act('place_data');h.act('choose_target',a=>t==='computer'?a.target.target==='computer':a.target.target==='blueBonus'&&a.target.blueSlot===t);
}
const select=(h,id)=>h.act('choose_card',a=>a.target.cardInstanceId===hand(h,id)?.id);
function insert(h,id){
 while(h.m.facts().computer.length<4)place(h);
 select(h,id);h.cut('after-income');
}
const chooseTech=h=>{h.act('research_tech');h.act('choose_target',a=>a.target.tileId==='blue1');place(h);place(h);place(h,3);h.act('end_turn');white(h);};
function analyze(h){
 h.act('analyze');h.act('choose_target',a=>a.target.choiceId==='trace:1:blue:amiba:3');h.act('choose_card',a=>a.target.source==='display');
 h.cut('after-analysis');h.act('end_turn');white(h);
}
function trade(h,id){h.act('quick_trade',a=>a.target.tradeId===id);}
function fixedPass(h){
 const menu=h.m.menu();
 if(!menu.some(a=>a.family==='pass')){h.act('end_turn');white(h);}
 h.cut('pass');h.act('pass');
 if(h.m.menu()[0]?.actorId==='player-white'&&h.m.menu()[0]?.family==='choose_card')pick(h,'b_111.webp');
 white(h);
}
function candidate(h,id,chooseSlot,finish){
 play(h,'dlc_20.png');select(h,id);h.cut('after-DLC20');
 if(finish==='automatic')return;
 if(h.m.facts().wallet.availableData+h.m.facts().computer.length<4&&chooseSlot==='dlc_25.png'){
   const other=h.m.player().hand.find(c=>c.cardId==='amiba_5.webp'||c.cardId==='amiba_2.webp');
   assert(other,'missing fourth data');
   corner(h,other.cardId);
 }
 insert(h,chooseSlot);
 if(finish==='fixed-pass')fixedPass(h);
}
for(const [blue,g] of Object.entries(e.mat)){
 const cases=[];
 for(const source of ['b_16.webp','dlc_25.png']){
  for(const target of ['amiba_2.webp','amiba_5.webp']){
   for(const finish of ['automatic','insert','fixed-pass']){
    if(finish!=='automatic'&&source==='dlc_25.png'&&target==='amiba_5.webp')continue;
    cases.push([source+' pays / DLC20 repeats '+target+' / '+finish,h=>{
     corner(h,source);corner(h,'amiba_9.webp');chooseTech(h);analyze(h);
     candidate(h,target,source==='dlc_25.png'?'amiba_5.webp':'dlc_25.png',finish);
    }]);
   }
  }
 }
 if(blue==='blue_3'){
  cases.push(['DLC25 pays / B16 main then keep DLC20',h=>{
   corner(h,'dlc_25.png');corner(h,'amiba_9.webp');chooseTech(h);analyze(h);
   play(h,'b_16.webp');h.cut('B16-menu');
   if(h.m.c.inspect().session)throw Error('enumerate B16 effects from observed menu');
  }]);
 }
 results[blue]={origin:g.before,...runCases(g.before,cases)};
}
const marsBase=mars.results.find(x=>x.i===35).rows[0].checkpoints['same-mars'].state;
const m=open(marsBase),offered=m.state().cards.publicCards.filter(x=>deck.getIncomeGainForCard(x)?.handSize===1).map(x=>x.cardId);
console.log('mars-draw-supply',JSON.stringify(offered));m.dispose();
const cases=offered.flatMap(id=>[false,true].map(fix=>[id+(fix?' / choose income / follow standard black scan':' / choose income / autonomous'),h=>{
 trade(h,'publicity-for-card');pick(h,id);insert(h,id);
 if(fix){
  h.act('end_turn');white(h);h.cut('following-wallet');
  play(h,'dlc_19.png');h.cut('black-menu');
  if(h.m.c.inspect().session)throw Error('enumerate DLC19 from actual options');
 }
}]));
results.mars={origin:marsBase,...runCases(marsBase,cases)};
writeZ(out,results);
