'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ,runCases}=require('./controlled-r3');
const [extra,late,ret,out]=process.argv.slice(2),src=readZ(extra),draft=readZ(late),cash=readZ(ret);
const held=(m,id)=>m.player().hand.find(c=>c.cardId===id)?.id;
const d=(s)=>[s.wallet,s.established,s.income,s.hand,s.computer,s.blue,s.probes];
const seat='player-white';
function place(h,t='computer'){
 h.act('place_data');h.act('choose_target',a=>t==='computer'?a.target.target==='computer':a.target.target==='blueBonus'&&a.target.blueSlot===t);
}
const srcB16=draft.blue_3.failures.find(x=>x.label.includes('B16 main')).checkpoint;
const b16=runCases(srcB16,['sector-1-a','sector-2-a'].map(target=>[target+' / publicly funded fourth data',h=>{
 h.act('choose_target',a=>a.target.skip);h.act('choose_target',a=>a.target.nebulaId===target);h.cut('scan');
 h.act('quick_trade',a=>a.target.tradeId==='publicity-for-card');h.take(h.m.pick('dlc_17.png'));
 h.take(h.m.corner('amiba_2.webp'),h.m.corner('dlc_17.png'));
 for(let i=0;i<4;i++)place(h);
 h.act('choose_card',a=>a.target.cardInstanceId===held(h.m,'amiba_5.webp'));h.cut('income');
}]));
function run(c){
 const m=open(c.root),actions=[],turns=[];let stop,nextTurn=false,cp;
 try{
  for(let j=0;j<140;j++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!==seat){
    const passive=[];m.advanceOpponents(passive);actions.push(...passive.map(a=>({a,passive:true})));
   }
   if(nextTurn&&!m.save().session){turns.push({state:m.save(),summary:short(m)});nextTurn=false;if(turns.length===3){stop='three-turns';break;}}
   const q=m.automatic(cp);
   if(!q.complete||q.n>256||q.ms>600){stop={n:q.n,ms:q.ms,a:q.a?.summary};break;}
   cp=q.checkpoint;actions.push({a:m.apply(q.a),n:q.n,ms:q.ms,value:q.value});nextTurn=q.a.family==='end_turn';
  }
  assert(stop);const end=m.save(),summary=short(m);
  m.restore(c.root);for(const x of actions)m.apply(x.a);assert.deepEqual(m.save(),end);
  const peak=[Math.max(0,...actions.map(a=>a.n||0)),Math.max(0,...actions.map(a=>a.ms||0))];
  console.log(JSON.stringify([c.label,d(c.r3),stop,turns.map(x=>d(x.summary)),peak]));
  return {...c,actions,turns,summary,end,stop,peak};
 }finally{m.dispose();}
}
const rows=[];
for(const r of cash.cash.rows)rows.push({label:'cash '+r.label,r3:r.settled?.summary||r.checkpoints.pass.summary,root:r.end});
const one=src.mat.blue_3.next.rows.find(r=>r.label==='analysis / amiba_5.webp to dlc_15.png / ai');
rows.push({label:'swap + DLC20, 110 and two blue slots',r3:one.settled.summary,root:one.end});
for(const r of b16.rows){
 assert(r.settled);
 const selection=r.actions.find(x=>x.action.family==='choose_card'&&x.action.target.kind==='pass-reserve-card');
 if(selection?.action.summary==='b_111.webp')rows.push({label:r.label,r3:r.settled.summary,root:r.end});
}
writeZ(out,{srcB16,b16,rows:rows.map(run)});
