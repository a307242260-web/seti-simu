'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [dir,record,out]=process.argv.slice(2),load=name=>readZ(dir+'/'+name+'-20261111-v1.json.gz');
const r=JSON.parse(fs.readFileSync(record)),raw=JSON.parse(fs.readFileSync(r.savePath)),official=JSON.parse(fs.readFileSync(r.roundEnds[1].checkpointPath));
const extra=load('extra-data'),mars=load('mars-wallet'),held=load('late-held'),red=load('red-carry'),reopen=load('reopen-cash'),money=load('retention-cash'),fourth=load('retention-carry'),end=load('finalize-retention');
const anchor=open(official.coreState.compositionEnvelope),counts={};
const norm=x=>x.a||x.action||x;
try{
 for(let i=r.roundEnds[1].beforeInput;i<=raw.replaySteps.length;i++){
  if(i===141)assert.deepEqual(anchor.save(),mars.source);
  if(i===180)assert.deepEqual(anchor.save(),extra.root);
  if(i===258)assert.equal(short(anchor).wallet[0],118);
  anchor.apply(raw.replaySteps[i-1].action);
 }
 assert.equal(anchor.save().committedState,raw.committedState);
}finally{anchor.dispose();}
function verify(bucket,origin,seq,target){
 const m=open(origin);
 try{
  for(const x of seq){
   if(!x.passive&&typeof x.n==='number')assert(x.n<=256&&x.ms<=600,[bucket,x.n,x.ms].join(':'));
   m.apply(norm(x));
  }
  assert.deepEqual(m.save(),target);
  counts[bucket]??=[0,0];counts[bucket][0]++;counts[bucket][1]+=seq.length;
  return m.state().turn.gameEnded?m.state().match.finalScores.find(x=>x.playerId==='player-white').totalScore:null;
 }finally{m.dispose();}
}
function group(bucket,root,g){
 for(const x of g.rows)verify(bucket,root,[...x.prefix,...x.actions],x.end);
 for(const x of g.failures)verify(bucket,root,x.prefix,x.checkpoint);
}
for(const c of mars.cfg)verify('mars-geometries',mars.source,[...c.start,...c.boundary],c.root);
for(const t of mars.results)group('mars-executed',mars.cfg[t.i].root,t);
for(const [id,g] of Object.entries(extra.mat)){
 verify('same-standard-prefix',extra.root,g.prep,g.before);
 group('alternate-research-prep',g.before,g.first);
 group('early-repeat',g.first.rows[0].start,g.next);
 assert.deepEqual(held[id].origin,g.before);group('held-role',held[id].origin,held[id]);
 assert.deepEqual(reopen[id].root,g.first.rows[0].start);group('cash-blue-slot',reopen[id].root,reopen[id]);
}
group('replacement-mars-income',held.mars.origin,held.mars);
group('explicit-cash',money.cash.base,money.cash);
group('b16',money.b16.probe,money.b16);group('b16',fourth.srcB16,fourth.b16);group('b16',fourth.srcB16,end.b16);
for(const x of red.cases){
 if(x.label==='standard B111'){
  assert.deepEqual(x.root,red.outputs[0].root);continue;
 }
 const name=x.label.split(' / ')[0];
 const origin=extra.mat.blue_3.next.rows.find(y=>y.label==='analysis / amiba_5.webp to '+name+' / ai').start;
 verify('red-choice-fixed',origin,x.prefix,x.root);
}
for(const x of red.outputs)verify('red-fourth',x.root,x.steps,x.end);
for(const x of fourth.rows)verify('carry-fourth',x.root,x.actions,x.end);
for(const x of end.rows){
 const prior=[...red.outputs,...fourth.rows].find(r=>r.label===x.label);
 assert.deepEqual(prior.turns.at(-1).state,x.origin);
 assert.equal(verify('natural-terminal',x.origin,x.actions,x.end),x.final);
}
const summary={source:r.gitCommit,save:r.savePath,exactCounts:counts,segments:Object.values(counts).reduce((s,x)=>s+x[0],0),inputs:Object.values(counts).reduce((s,x)=>s+x[1],0)};
console.log(JSON.stringify(summary));writeZ(out,summary);
