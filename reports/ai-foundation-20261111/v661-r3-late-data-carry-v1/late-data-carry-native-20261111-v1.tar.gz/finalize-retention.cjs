'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,open,short,runCases}=require('./controlled-r3');
const [carry,reds,out]=process.argv.slice(2),a=readZ(carry),b=readZ(reds);
const sources=[a.rows.find(x=>x.label==='cash pool'),a.rows.find(x=>x.label.startsWith('swap +')),
 ...b.outputs.filter(x=>x.label.startsWith('dlc_15.png / dlc_16.png'))];
function run(row){
 const origin=row.turns.at(-1).state,m=open(origin),actions=[];let cp,stop;
 try{
  for(let i=0;i<150;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!=='player-white'){const passive=[];m.advanceOpponents(passive);actions.push(...passive.map(a=>({a,passive:true})));continue;}
   const q=m.automatic(cp);if(!q.complete||q.n>256||q.ms>600){stop={a:q.a?.summary,n:q.n,ms:q.ms};break;}
   cp=q.checkpoint;actions.push({a:m.apply(q.a),n:q.n,ms:q.ms,value:q.value});
  }
  assert(stop);const end=m.save(),asset=short(m),final=stop==='terminal'?m.state().match.finalScores.find(x=>x.playerId==='player-white').totalScore:null;
  if(final!==null)assert.equal(asset.established,final);
  m.restore(origin);for(const {a} of actions)m.apply(a);assert.deepEqual(m.save(),end);
  const peak=[Math.max(0,...actions.map(a=>a.n||0)),Math.max(0,...actions.map(a=>a.ms||0))];
  console.log(JSON.stringify([row.label,stop,final,asset.wallet,peak,actions.filter(x=>x.a.phase==='main').map(x=>x.a.summary)]));
  return {label:row.label,origin,actions,end,final,asset,stop,peak};
 }finally{m.dispose();}
}
const b16=runCases(a.srcB16,[['B16 south / computer publicity funds fourth',h=>{
 const place=()=>{h.act('place_data');h.act('choose_target',t=>t.target.target==='computer');};
 h.act('choose_target',t=>t.target.skip);h.act('choose_target',t=>t.target.nebulaId==='sector-1-a');
 h.take(h.m.corner('amiba_2.webp'));for(let i=0;i<3;i++)place();
 h.act('quick_trade',t=>t.target.tradeId==='publicity-for-card');h.take(h.m.pick('dlc_17.png'),h.m.corner('dlc_17.png'));place();
 h.act('choose_card',t=>t.target.cardInstanceId===h.m.player().hand.find(c=>c.cardId==='amiba_5.webp')?.id);h.cut('income');
}]]);
writeZ(out,{b16,rows:sources.map(run)});
