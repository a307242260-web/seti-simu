# SETI R3: late data / reserve B111 (2026-11-11)

Canonical checkpoint and replay: `reports/research/c619bd0c.5ab926be.quick-400.json` and its round 2 checkpoint. The three rules files changed after 5ab926be7 in the test checkout match tree 6008244cc exactly. All paths in this file are relative to the repository root unless shown under B (the extracted archive directory). Extract to a fresh B for additional outputs; writers refuse overwrites.

To verify existing evidence without running AI:
```sh
node "$B/verify-late-carry.cjs" "$B" reports/research/c619bd0c.5ab926be.quick-400.json /tmp/late-data-independent-check.json.gz
```

The standard anchor 141/180 is re-derived from the registry's second-round checkpoint and replay inside the verifier; it is never treated as a new standard simulation. The B111 R4 reference starts from the independently proved 239 route. See docs/human405-v661-r3-public-blue-pair-20261111.md and docs/human405-v661-r3-standard-pass-route-20261111.md.

Evidence generation order (see each script's argv; use a fresh output directory for every new invocation): mars-wallet and extra-data read standard-anchors and the registered save; late-held reads extra-data and mars-wallet; red-carry reads extra-data and b111-reference-anchor; reopen-cash reads extra-data; retention-cash reads extra-data, reopen-cash, and late-held; retention-carry reads extra-data, late-held, and retention-cash; finalize-retention reads retention-carry and red-carry. Output files are labeled by script name. Failure records are failed named control attempts (e.g. an unavailable target), not production errors. The verifier replays their accepted prefixes but never submits the rejected choice.

All autonomous submissions require complete search and 256 native inputs / 600 ms. Only the scripted sections use fixed inputs. Unknown cards are never used as advance knowledge; choosing them after a legal reveal is recorded in the observed menu.
