'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),{open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const {getDiscardActionRewardForCard}=require(path.resolve('randomizer/game/cards/deck'));
const [src,save,out]=process.argv.slice(2),s=readZ(src),raw=JSON.parse(fs.readFileSync(save)),e=s.rows.find(r=>r.i===180).before,m=open(e),mat={};
const exact=(h,a)=>h.take(h.m.apply(a)),play=(h,id)=>h.take(h.m.play(id)),pick=(h,id)=>h.take(h.m.pick(id)),corner=(h,id)=>h.take(h.m.corner(id));
const end=h=>h.act('end_turn');
function place(h,t='computer'){
 h.act('place_data');h.act('choose_target',a=>t==='computer'?a.target.target==='computer':a.target.target==='blueBonus'&&a.target.blueSlot===t);
}
function same(m,i){
 const old=raw.replaySteps[i-1].action,actions=m.menu();
 const a=actions.find(b=>b.actorId===old.actorId&&b.family===old.family&&JSON.stringify(b.target)===JSON.stringify(old.target));
 assert(a,JSON.stringify([i,old.summary,actions.map(b=>[b.family,b.summary])]));
 return m.apply(a);
}
function analyze(h){
 h.act('analyze');h.act('choose_target',a=>a.target.choiceId==='trace:1:blue:amiba:3');
 h.act('choose_card',a=>a.target.source==='display');
 h.cut('after-analysis');
}
function swap(h,out,into){h.take(...h.m.swap(out,into));}
function repeat(h,into){
 play(h,'dlc_20.png');
 h.act('choose_card',a=>a.target.cardInstanceId===h.m.player().hand.find(c=>c.cardId===into)?.id);
 h.cut('after-DLC20');
}
function insert(h,id){
 while(h.m.facts().computer.length<4)place(h);
 h.act('choose_card',a=>a.target.cardInstanceId===h.m.player().hand.find(c=>c.cardId===id)?.id);
 h.cut('after-income');
}
const variations=[];
for(const blue of ['blue_1','blue_3']){
 m.restore(e);const prep=[m.act('choose_target',a=>a.target.slotId===blue)];
 try{
  for(let i=181;i<=222;i++)prep.push(same(m,i));
  const before=m.save(),wallet=short(m);
  const cases=[
   ['skip DLC20 movement / B16 and A9 pay blue1',h=>{corner(h,'b_16.webp');corner(h,'amiba_9.webp');h.act('research_tech');h.act('choose_target',a=>a.target.tileId==='blue1');place(h);place(h);place(h,3);end(h);}],
  ];
  const first=runCases(before,cases);
  const r=first.rows[0];if(!r)throw Error('blue 1 line infeasible');
  const root=r.start;
  mat[blue]={prep,before,wallet,first};
  console.log('prefinal',blue,JSON.stringify(r.summary));
  const work=[];
  for(const source of ['amiba_5.webp','amiba_2.webp']){
   for(const offered of ['dlc_15.png','dlc_17.png']){
    for(const suffix of ['ai','pool','blue']){
     work.push(['analysis / '+source+' to '+offered+' / '+suffix,h=>{
       analyze(h);
       swap(h,source,offered);
       const supply=h.m.player().hand.find(c=>c.cardId===offered);assert(getDiscardActionRewardForCard(supply)?.dataCount===1);
       end(h);repeat(h,offered);
       if(suffix!=='ai'){
        insert(h,'dlc_25.png');
        if(suffix==='blue')place(h,1);
        end(h);
       }
      }]);
    }
   }
  }
  mat[blue].next=runCases(root,work);
 }catch(err){variations.push({blue,prep,reason:String(err),state:m.save()});console.log('prefix failed',blue,String(err).slice(0,250));}
}
m.dispose();
writeZ(out,{root:e,mat,variations});
