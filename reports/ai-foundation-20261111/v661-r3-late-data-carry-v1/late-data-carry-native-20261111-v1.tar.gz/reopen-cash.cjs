'use strict';
const assert=require('node:assert/strict'),{runCases,open,short,readZ,writeZ}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),results={};
const white=h=>{h.act('end_turn');const a=[];h.m.advanceOpponents(a);h.take(...a);};
function place(h,t='computer'){
 h.act('place_data');h.act('choose_target',a=>t==='computer'?a.target.target==='computer':a.target.target==='blueBonus'&&a.target.blueSlot===t);
}
function native(root){
 const m=open(root);
 try{m.play('amiba_5.webp');m.pick('dlc_17.png');return m.menu().map(a=>[a.target.slotId,a.summary]);}finally{m.dispose();}
}
for(const [blue,g] of Object.entries(d.mat)){
 const root=g.first.rows[0].start,cases=[];
 for(const [red,redText] of native(root)){
  for(const pos of [2,3]){
   cases.push([blue+' / '+redText+' before analysis / blue '+pos+' / reuse cash slot',h=>{
    h.take(h.m.play('amiba_5.webp'),h.m.pick('dlc_17.png'));
    h.act('choose_target',a=>a.target.slotId===red);h.cut('after-A5');
    white(h);h.act('analyze');
    h.act('choose_target',a=>a.target.choiceId==='trace:1:blue:amiba:'+pos);
    if(pos===3)h.act('choose_card',a=>a.target.source==='display');
    h.cut('after-analysis');
    place(h,3);assert.equal(h.m.facts().wallet.credits,1,'blue1 must fund the next main action');h.cut('repaid');
    white(h);h.take(h.m.play('dlc_20.png'));
    h.act('choose_card',a=>a.target.cardInstanceId===h.m.player().hand.find(c=>c.cardId==='dlc_17.png')?.id);
    h.cut('after-DLC20');
    if(h.m.facts().wallet.availableData<4&&h.m.player().hand.some(c=>c.cardId==='amiba_2.webp'))h.take(h.m.corner('amiba_2.webp'));
    if(h.m.facts().wallet.availableData>=4){
     for(let i=0;i<4;i++)place(h);
     h.act('choose_card',a=>a.target.cardInstanceId===h.m.player().hand.find(c=>c.cardId==='dlc_25.png')?.id);
     h.cut('after-income');
    }
   }]);
  }
 }
 results[blue]={root,...runCases(root,cases)};
}
writeZ(out,results);
