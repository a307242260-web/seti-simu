'use strict';
const assert=require('node:assert/strict'),{runCases,open,short,readZ,writeZ}=require('./controlled-r3');
const [early,failed,late,out]=process.argv.slice(2),d=readZ(early),g=readZ(failed),b16=readZ(late),results={};
const hand=(h,id)=>h.m.player().hand.find(x=>x.cardId===id)?.id;
function place(h,t='computer'){
 h.act('place_data');h.act('choose_target',a=>t==='computer'?a.target.target==='computer':a.target.target==='blueBonus'&&a.target.blueSlot===t);
}
function white(h){h.act('end_turn');const a=[];h.m.advanceOpponents(a);h.take(...a);}
function trade(h,id){h.act('quick_trade',a=>a.target.tradeId===id);}
function fill(h,id){
 while(h.m.facts().computer.length<4)place(h);
 h.act('choose_card',a=>a.target.cardInstanceId===hand(h,id));h.cut('income');
}
function pass(h){
 if(!h.m.menu().some(a=>a.family==='pass'))white(h);
 h.cut('pass');h.act('pass');h.act('choose_card',a=>a.summary==='b_111.webp');
 const a=[];h.m.advanceOpponents(a);h.take(...a);
}
const base=g.blue_3.failures.find(x=>x.label.includes('/ blue 3 /')).checkpoint;
for(const discardOrder of [['dlc_25.png','amiba_2.webp']]){
 results.cash={base,...runCases(base,['auto','pool','one-blue'].map(mode=>[mode,h=>{
  h.act('choose_target',t=>t.target.target==='computer');
  trade(h,'cards-for-credit');
  for(const id of discardOrder)h.act('choose_payment',a=>a.target.cardInstanceId===hand(h,id));
  if(h.m.c.inspect().session)h.act('choose_payment',a=>!a.target.cardInstanceId);
  assert.equal(h.m.facts().wallet.credits,1);
  white(h);h.take(h.m.play('dlc_20.png'));
  h.act('choose_card',a=>a.target.cardInstanceId===hand(h,'dlc_17.png'));
  h.cut('repeat');
  trade(h,'publicity-for-card');h.take(h.m.pick('dlc_14.png'));fill(h,'dlc_14.png');
  if(mode==='one-blue'){place(h,1);pass(h);}
  if(mode==='pool')pass(h);
 }]))};
}
const b=b16.blue_3.failures.find(x=>x.label.includes('B16 main'));
const probe=b.checkpoint,m=open(probe);m.act('choose_target',a=>a.target.skip);const targets=m.menu().map(a=>a.target.nebulaId);m.dispose();
results.b16={probe,...runCases(probe,targets.flatMap(nebula=>[false,true].map(force=>[nebula+(force?' / force income':' / auto'),h=>{
 h.act('choose_target',a=>a.target.skip);
 h.act('choose_target',a=>a.target.nebulaId===nebula);h.cut('scan');
 if(!force)return;
 if(h.m.facts().wallet.availableData<4&&hand(h,'amiba_2.webp'))h.take(h.m.corner('amiba_2.webp'));
 fill(h,'amiba_5.webp');
}])) )};
writeZ(out,results);
