'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),{open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const native=require(path.resolve('randomizer/game/production-kernel'));
const [standard,saveFile,out]=process.argv.slice(2),s=readZ(standard),raw=JSON.parse(fs.readFileSync(saveFile));
const e=s.rows.find(r=>r.i===141).before,m=open(e),cfg=[],failures=[];
const dirs=(m)=>m.menu().filter(a=>a.family==='move'&&Number.isInteger(a.target.deltaX));
const simple=a=>[a.family,a.summary,a.target];
function apply(m,input){
 const a=m.menu().find(a=>a.actionId===input.actionId&&a.actorId===input.actorId)
  ||m.menu().find(a=>a.family===input.family&&a.actorId===input.actorId&&a.summary===input.summary);
 assert(a,JSON.stringify(simple(input)));
 return m.apply(a);
}
function advance(m,boundary){
 for(let i=145;i<=156;i++)boundary.push(apply(m,raw.replaySteps[i-1].action));
 m.advanceOpponents(boundary);
}
function marsRoute(m){
 const h=native.getProbeRouteRequirements(m.state(),'player-white').candidates
  .find(q=>q.planetId==='mars'&&q.endpointFamily==='land'&&q.endpointTarget.type==='planet');
 return h||null;
}
function list(prefix){
 const pre=m.save(),moves=dirs(m),choices=[];
 for(const a of moves){
  m.restore(pre);m.apply(a);
  for(const b of m.menu().filter(x=>x.family==='choose_payment'))
   choices.push([a,b]);
 }
 m.restore(pre);
 return choices;
}
function get(start){
 const before=m.save(),boundary=[],shell=[];
 try{
  advance(m,boundary);
  const root=m.save(),q=marsRoute(m),f=short(m);
  cfg.push({start,boundary,root,q,f});
  console.log(JSON.stringify([start.map(x=>x.summary),f.wallet,f.hand,f.probes,q&&[q.required.paidMovementPoints,q.path]]));
 }catch(err){failures.push({start,boundary,reason:String(err)});}
 finally{m.restore(before);}
}
try{
 get([]);
 for(const first of list([])){
  m.restore(e);first.forEach(a=>apply(m,a));get(first);
  for(const second of list(first)){
   m.restore(e);const start=first.concat(second);
   try{start.forEach(a=>apply(m,a));get(start);}catch(err){failures.push({start,reason:String(err)});}
  }
 }
}finally{m.dispose();}
const results=[];
for(const [i,c] of cfg.entries()){
 if(!c.q)continue;
 const e=c.root,m=open(e),credits=m.facts().wallet.credits,remaining=m.facts().wallet.energy;
 const use=m.player().hand.find(x=>x.cardId==='b_10.webp');
 const routes=[];
 function next(h,useCards){
  for(const q of c.q.path){
   const mm=h.m,a=h.act('move',a=>a.target.deltaX===q.deltaX&&a.target.deltaY===q.deltaY);
   const menu=mm.menu().filter(x=>x.family==='choose_payment');
   const card=useCards&&menu.find(x=>x.target.cardIds?.includes(use?.id)&&!x.payload.energyCost);
   const selected=card||menu.find(x=>x.payload.energyCost<=mm.facts().wallet.energy&&!x.target.cardIds?.length);
   if(!selected)break;
   h.take(mm.apply(selected));
  }
  h.take(h.m.play('dlc_31.png'));
  h.act('choose_target',a=>a.target.planetId==='mars'&&a.target.landTarget?.type==='planet');
  h.act('choose_target',a=>a.target.alienSlotId===1&&a.target.traceType==='yellow');
  h.cut('same-mars');
 }
 try{
  if(c.q.required.paidMovementPoints<=remaining)routes.push(['same Mars: energy only',h=>next(h,false)]);
  if(use&&c.q.required.paidMovementPoints<=remaining+1)routes.push(['same Mars: spare B10',h=>next(h,true)]);
 }finally{m.dispose();}
 if(routes.length){const res=runCases(e,routes);results.push({i,...res});}
}
writeZ(out,{source:e,cfg,failures,results});
