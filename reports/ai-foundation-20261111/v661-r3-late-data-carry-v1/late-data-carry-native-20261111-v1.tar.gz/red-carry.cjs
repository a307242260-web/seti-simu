'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,short,readZ,writeZ}=require('./controlled-r3');
const deck=require(path.resolve('randomizer/game/cards/deck'));
const [src,known,out]=process.argv.slice(2),d=readZ(src),reference=readZ(known)['only-redirect-the-two-public-scans'];
const seat='player-white',cases=[],map={},duplicates=[],outputs=[];
function settlePassive(m,steps){if(m.state().turn.gameEnded||m.menu()[0]?.actorId===seat)return;
 const a=[];m.advanceOpponents(a);steps.push(...a.map(a=>({a,passive:true})));
}
function replay(m,steps){for(const x of steps)m.apply(x.a||x);}
function gate(q){return q.complete&&q.n<=256&&q.ms<=600&&q.a;}
function summary(s){return [s.wallet,s.established,s.income,s.hand,s.computer,s.blue,s.probes];}
function runFourth(root){
 const m=open(root),steps=[],turns=[],roots=[];let cp,stop,afterEnd=false;
 try{
  for(let j=0;j<120;j++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   settlePassive(m,steps);
   if(afterEnd&&!m.save().session){
    turns.push({state:m.save(),summary:short(m)});afterEnd=false;
    if(turns.length===3){stop='three-turns';break;}
   }
   const q=m.automatic(cp);if(!gate(q)){stop={n:q.n,ms:q.ms,a:q.a?.summary};break;}
   cp=q.checkpoint;
   const a=q.a;if(a.phase==='main'||a.family==='pass')roots.push({a,n:q.n,ms:q.ms,value:q.value});
   steps.push({a:m.apply(a),n:q.n,ms:q.ms,value:q.value});afterEnd=a.family==='end_turn';
  }
  assert(stop);const end=m.save(),endSummary=short(m);
  m.restore(root);replay(m,steps);assert.deepEqual(m.save(),end);
  return {steps,turns,roots,end,endSummary,stop,peak:[Math.max(0,...steps.map(x=>x.n||0)),Math.max(0,...steps.map(x=>x.ms||0))]};
 }finally{m.dispose();}
}
function pass(m,prefix,expected){
 if(!m.menu().some(a=>a.family==='pass')){prefix.push({a:m.act('end_turn')});settlePassive(m,prefix);}
 const r3={state:m.save(),summary:short(m)};
 prefix.push({a:m.act('pass')});
 const choice=m.menu().find(a=>a.family==='choose_card'&&a.summary===expected);
 assert(choice,JSON.stringify(m.menu().map(x=>[x.family,x.summary])));
 prefix.push({a:m.apply(choice)});
 settlePassive(m,prefix);
 assert.equal(m.facts().round,4);assert(!m.save().session);
 return r3;
}
function put(m,prefix,label,r3){
 const root=m.save(),key=JSON.stringify(root);
 if(map[key]){duplicates.push({label,source:map[key]});return;}
 map[key]=label;cases.push({root,prefix:[...prefix],label,r3});
}
cases.push({root:reference.e,label:'standard B111',prefix:[]});
for(const row of d.mat.blue_3.next.rows.filter(r=>r.label.endsWith('/ ai')&&r.label.startsWith('analysis / amiba_5.webp'))){
 const m=open(row.start),name=row.label.match(/to (dlc_1[57].png)/)[1];
 const prefix=[];
 try{
  for(const x of row.actions){
   if(x.action.family==='play_card'&&x.action.summary==='amiba_5.webp')break;
   prefix.push({a:m.apply(x.action)});
  }
  const before=m.save(),base=[...prefix],preplay=short(m);
  for(const pub of preplay.market){
   m.restore(before);prefix.splice(0,prefix.length,...base);
   prefix.push({a:m.play('amiba_5.webp')},{a:m.pick(pub)});
   const choose=m.save(),actions=[...prefix],root=m.automatic();
   console.log('symbol decision',name,pub,JSON.stringify([root.a?.summary,root.value,root.n,root.ms,root.roots.map(x=>[x.actionId,x.value])]));
   for(const id of ['red_1','red_2']){
    m.restore(choose);prefix.splice(0,prefix.length,...actions);
    prefix.push({a:m.act('choose_target',a=>a.target.slotId===id)});
    const prepass=m.save(),saved=[...prefix];
    try{const r3=pass(m,prefix,'b_111.webp');put(m,prefix,name+' / '+pub+' / '+id+' / held',r3);}
    catch(err){console.log('not comparable',name,pub,id,String(err).slice(0,260));}
    if(id==='red_2'){
     m.restore(prepass);prefix.splice(0,prefix.length,...saved);
     const c=m.player().hand.find(x=>x.cardId===pub);
     if(deck.getDiscardActionRewardForCard(c)?.dataCount===1){
      prefix.push({a:m.corner(pub)});
      try{const r3=pass(m,prefix,'b_111.webp');put(m,prefix,name+' / '+pub+' / red_2 / convert card to pool',r3);}
      catch(err){console.log('not comparable',name,pub,id,String(err).slice(0,260));}
     }
    }
   }
  }
 }finally{m.dispose();}
}
const selected=cases.filter(c=>c.label==='standard B111'||c.label.includes('/ red_2 /')||c.label.includes('dlc_16.png / red_1'));
for(const c of selected){
 const a=runFourth(c.root);outputs.push({...c,...a});
 console.log(JSON.stringify([c.label,c.r3&&summary(c.r3.summary),a.stop,a.turns.map(t=>summary(t.summary)),a.peak]));
}
writeZ(out,{cases,duplicates,outputs});
