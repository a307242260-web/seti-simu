# V673 last-computer-slot known swap

Run from a clean Production checkout at cbd73e00c98455dac868bd43be3e1759130088a7.
Let p be the absolute extracted directory. Use fresh output paths. The
diagnostic compiles an isolated module; it does not edit Production.

```sh
(cd "$p" && shasum -a 256 -c SHA256SUMS)
node "$p/verify.cjs" "$p"
node "$p/lines.cjs" "$p" "$p/replay-lines.json.gz"
node "$p/admit.cjs" "$p" "$p/replay-admit.json.gz"
node "$p/admit.cjs" "$p" "$p/replay-checkpoint.json.gz" checkpoint
node "$p/resume.cjs" "$p" "$p/replay-resume.json.gz"
node "$p/recover.cjs" "$p" "$p/replay-recover.json.gz"
node "$p/fourth.cjs" "$p" "$p/replay-fourth.json.gz"
node "$p/fourth-auto.cjs" "$p" "$p/replay-fourth-auto.json.gz"
```

The verifier replays recorded actions and does not invoke search.
