'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,short,readZ,writeZ}=require('./controlled-r3');
const {createStateValueEvaluator}=require(path.resolve('randomizer/game/ai/state-value'));
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const [d,out]=process.argv.slice(2),src=readZ(d+'/lines-20261111-v1.json.gz'),evaluate=createStateValueEvaluator('player-white');
const labels=['A5-first/4分/auto','A5-first/4分/swap-B16'],paths=[];
const snap=x=>({state:x.save(),assets:short(x),value:evaluate.details(x.owner('player-white'))});
for(const label of labels){
 const r=src.rows.find(x=>x.label===label),m=open(r.checkpoints.analysis.state);
 try{
  const before=snap(m);
  const port=createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});let pick;
  try{port.setCardPickPlanning(true);port.setResourcePlanning(true);const n=port.openRoot();pick=port.cardPickSpec(n);assert.deepEqual(m.save(),before.state);}finally{port.close();}
  assert.deepEqual(m.save(),before.state);
  const x=open(r.settled.state);
  try {
   const after=snap(x);
   console.log(JSON.stringify([label,pick?.reason,pick?.goal,after.value.total,after.value.components,after.assets.wallet,after.assets.hand,after.assets.computer]));
   paths.push({label,before,after,pick});
  }finally{x.dispose();}
 }finally{m.dispose();}
}
assert.deepEqual(paths[0].before.state,paths[1].before.state);
writeZ(out,{paths});
