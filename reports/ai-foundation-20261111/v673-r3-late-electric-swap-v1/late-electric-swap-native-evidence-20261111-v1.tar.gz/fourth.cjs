'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const {open,readZ,writeZ,short}=require('./controlled-r3');
const white='player-white', read=p=>JSON.parse(fs.readFileSync(p));
const [dir,out]=process.argv.slice(2),r=n=>readZ(dir+'/'+n+'-20261111-v1.json.gz');
const round3=r('lines');
const names=['A5-first/4分/swap-B16','analysis-first/1数据/keep-B16','B16-first/南河三/DLC25-income'];
const cases=names.map(name=>[name,round3.rows.find(x=>x.label===name).settled.state]);
const prior=r('previous-fourth');
for(const [,root] of cases)assert(!prior.results.some(x=>JSON.stringify(x.root)===JSON.stringify(root)),'previously tested exact root');
assert.equal(new Set(cases.map(x=>JSON.stringify(x[1]))).size,cases.length);
const first=[];
for(const [name,root] of cases){const m=open(root);try{m.act('pass');first.push([name,m.menu().filter(a=>a.family==='choose_card').map(a=>a.summary)]);}finally{m.dispose();}}
const common=['b_111.webp','b_32.webp'].filter(id=>first.every(([,options])=>options.includes(id)));
assert(common.length,JSON.stringify(first));
const results=[];
for(const [name,root] of cases)for(const card of common){
 const m=open(root),actions=[];
 try{
  actions.push({action:m.act('pass')},{action:m.act('choose_card',a=>a.summary===card)});
  let cp,stop;
  const turns=[];
  for(let i=0;i<200;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!==white){const passive=[];m.advanceOpponents(passive);actions.push(...passive.map(action=>({action,passive:true})));continue;}
   const q=m.automatic(cp);
   if(!q.a||!q.complete||q.n>256||q.ms>600){stop={kind:'gate',n:q.n,ms:q.ms,action:q.a?.summary,turn:m.facts().turn};break;}
   if(!cp||q.a.phase==='main'||q.a.family==='pass')turns.push({choice:q.a,n:q.n,ms:q.ms,assets:short(m)});
   cp=q.checkpoint;actions.push({action:m.apply(q.a),n:q.n,ms:q.ms,value:q.value});
  }
  assert(stop);
  const end=m.save(),terminal=stop==='terminal'?m.state().match.finalScores.find(p=>p.playerId===white):null;
  const peak=[Math.max(...actions.map(x=>x.n||0)),Math.max(...actions.map(x=>x.ms||0))];
  console.log(JSON.stringify([name,card,stop,terminal?.totalScore,peak,short(m)]));
  m.restore(root);actions.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),end);
  results.push({name,card,root,actions,turns,stop,terminal,peak,end});
 }finally{m.dispose();}
}
writeZ(out,{first,common,results});
