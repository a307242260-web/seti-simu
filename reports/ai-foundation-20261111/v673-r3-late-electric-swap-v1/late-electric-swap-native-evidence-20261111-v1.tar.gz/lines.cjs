'use strict';
const assert=require('node:assert/strict');
const {open,readZ,writeZ,runCases}=require('./controlled-r3');
const [d,out]=process.argv.slice(2),src=readZ(d+'/round3-20261111-v1.json.gz');
const root=src.rows.find(x=>x.label.endsWith('corner-A9')).start;
const a2='amiba_2.webp',a5='amiba_5.webp',b16='b_16.webp',d25='dlc_25.png';
const x17='dlc_17.png',x15='dlc_15.png',x14='dlc_14.png',x20='dlc_20.png';
const end=h=>h.act('end_turn');
const comp=(h,...ns)=>ns.forEach(n=>place(h,'第一排放置位 '+n));
function place(h,label){h.act('place_data');h.act('choose_target',a=>a.summary===label);}
function ready(h){comp(h,5,6);place(h,'blue1 下方');end(h);h.cut('ready');}
function analyze(h,slot){
 h.act('analyze');h.act('choose_target',a=>a.target.speciesId==='amiba'&&a.target.traceType==='blue'&&a.target.position===slot);
 h.act('choose_card',a=>a.summary.includes('科学论文'));h.cut('analysis');
}
const hand=(h,id)=>h.m.facts().hand.some(x=>x[1]===id);
function a5play(h,pick,symbol){
 h.take(h.m.play(a5));h.take(h.m.pick(pick));
 const chosen=h.m.menu().find(a=>a.summary.includes(symbol));assert(chosen,JSON.stringify(h.m.menu().map(x=>x.summary)));h.take(h.m.apply(chosen));h.cut('A5');
}
function b16play(h,scan){
 h.take(h.m.play(b16));h.act('choose_target',a=>a.summary.endsWith('顺时针'));
 h.act('choose_target',a=>a.summary==='扫描 '+scan);h.cut('B16');
}
function settle(h,corners,e,swap=null){
 if(swap)h.take(...h.m.swap(...swap));
 for(const id of corners)if(h.m.facts().wallet.availableData<4&&hand(h,id))h.take(h.m.corner(id));
 comp(h,1,2,3,4);
 h.act('choose_card',a=>a.summary==='收入 '+e);h.cut('E4');
}
const cases=[];
for(const order of ['A5-first','analysis-first'])for(const symbol of ['4分','1数据'])for(const plan of ['auto','keep-B16','swap-B16']){
 cases.push([[order,symbol,plan].join('/'),h=>{
  ready(h);
  if(order==='A5-first'){a5play(h,x17,symbol);end(h);analyze(h,3);}
  else{analyze(h,3);end(h);a5play(h,x17,symbol);}
  if(plan==='auto')return;
  const market=h.m.facts().market.map(x=>x?.[1]);
  const swap=plan==='swap-B16'?[b16,[x15,x14].find(x=>market.includes(x))]:null;
  settle(h,[x17,a2,x15,x14],d25,swap);
 }]);
}
for(const order of ['B16-first','analysis-first'])for(const scan of ['南河三','天狼星A'])for(const plan of ['auto','DLC25-income','A5-income']){
 cases.push([[order,scan,plan].join('/'),h=>{
  ready(h);
  if(order==='B16-first'){b16play(h,scan);end(h);analyze(h,3);}
  else{analyze(h,3);end(h);b16play(h,scan);}
  if(plan==='auto')return;
  if(plan==='DLC25-income')settle(h,[a2,a5],d25);
  else{
   const market=h.m.facts().market.map(x=>x?.[1]);
   settle(h,[a2,x17,x15,x14],a5,[d25,[x17,x15,x14].find(x=>market.includes(x))]);
  }
 }]);
}
writeZ(out,{root,...runCases(root,cases)});
