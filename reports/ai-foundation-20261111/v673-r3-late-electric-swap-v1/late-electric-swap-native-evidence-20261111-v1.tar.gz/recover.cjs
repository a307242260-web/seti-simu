'use strict';
const assert=require('node:assert/strict');
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [d,out]=process.argv.slice(2),x=readZ(d+'/admit-20261111-v1.json.gz'),cases=[];
for(const count of [1,2,3,4]){
 cases.push(['cold-after-'+count,h=>{
  for(const id of x.ids.slice(0,count)){const a=h.m.menu().find(x=>x.actionId===id);assert(a,id);h.take(h.m.apply(a));}
  h.cut('cold');
 }]);
}
writeZ(out,{root:x.root,...runCases(x.root,cases)});
