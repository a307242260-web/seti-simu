'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {open,readZ,writeZ}=require('./controlled-r3');
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [dir,out]=process.argv.slice(2),x=readZ(dir+'/lines-20261111-v1.json.gz');
const funded=x.rows.find(x=>x.label==='A5-first/4分/swap-B16'),root=funded.checkpoints.analysis.state,source=path.resolve('randomizer/game/ai/analysis-port.js');
const index=funded.prefix.findIndex(a=>a.summary.includes('获得展示的科学论文'));
assert(index>=0);
const ids=funded.prefix.slice(index+1).map(a=>a.actionId);assert(ids[0].startsWith('industry:')&&ids.at(-1).startsWith('choose_card:'));
const base=fs.readFileSync(source,'utf8');
const step='      if(goal.kind==="data-funded-cargo")return dataFundedCargoStep(node,state,goal,operation);';
const result='        plans:compareFixedPurposes?plans:swapAction?[...supplyPlans,...plans.filter(p=>p.goal.analysisPreparation||p===dataCargo)]:forcedKind?plans.filter(p=>p.goal.kind===forcedKind||p.goal.kind==="blue-landing-supply"||p.goal.analysisPreparation||p===dataCargo):plans,';
const before='      const result=freeze({policy:resourceDemand.VERSION,isEquivalence:false,\n        ...(adjacentCargo?.paid';
const pick='!["transport-data-prep","funded-earth-shipment","satellite-scan-setup","data-funded-cargo"].includes(plan.goal.kind)';
for(const anchor of [step,result,before,pick])assert.equal(base.split(anchor).length,2);
const modified=base.replace(step,`      if(goal.kind==="diagnostic-electric-swap"){
        const index=operation.cargoInput??0;
        if(index===goal.inputs.length)return {kind:"complete",reason:"known-electric-income-paid"};
        const a=node.legalActions.find(x=>x.actionId===goal.inputs[index]);
        return a?{kind:"fixed",actionId:a.actionId,cargoInput:index+1,reason:"diagnostic-fixed-electric-swap"}
          :{kind:"infeasible",reason:"diagnostic-swap-menu-changed"};
      }
`+step).replace(before,`      const fixture=globalThis.electricSwapFixture,p0=state.players.players.find(x=>x.id===seatId);
      const diagnostic=node===openedRoot&&node.status==="stable"&&state.turn.roundNumber===3
        &&p0.resources.score===113&&p0.resources.availableData===1&&p0.hand.length===4
        &&node.legalActions.some(a=>a.actionId===fixture[0])?{
          id:"diagnostic-electric-swap",goal:{id:"diagnostic-electric-swap",kind:"diagnostic-electric-swap",required:{},inputs:fixture},
          firstActionId:fixture[0],operation:{},mode:"greedy",reason:"compare-public-data-for-income"}:null;
`+before).replace(result,result.replace('plans:','plans:diagnostic?[...plans,diagnostic]:')).replace(pick,pick.replace('"data-funded-cargo"','"data-funded-cargo","diagnostic-electric-swap"'));
globalThis.electricSwapFixture=ids;
const results=[];
for(const mode of (process.argv[4]==='checkpoint'?['admitted']:['baseline','admitted'])){
 const mod=new Module(source,module);mod.filename=source;mod.paths=Module._nodeModulePaths(path.dirname(source));mod._compile(mode==='admitted'?modified:base,source);
 const m=open(root),p=mod.exports.createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});
 try{
  const menu=m.menu(),agent=createSearchAgent({analysisPort:p,seatId:'player-white'});
  const q=agent.decide({seatId:'player-white',legalActions:menu}).search,checkpoint=agent.createCheckpoint();
  assert.deepEqual(m.save(),root);
  const edge=q.lines[0].edges.find(x=>x.resourcePlan?.id==='diagnostic-electric-swap');
  const tail=edge&&q.lines.find(x=>x.node===edge.target);
  const chosen=menu.find(a=>a.actionId===q.actionId)?.summary;
  if(mode==='admitted')assert.deepEqual(edge.steps,ids);
  console.log(JSON.stringify({mode,chosen,value:q.value,complete:q.complete,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,edge:edge&&[edge.goalStatus,edge.cost,tail?.value]}));
  results.push({mode,q,chosen,edge,tail,checkpoint});
 }finally{p.close();m.dispose();}
}
writeZ(out,{root,ids,results});
