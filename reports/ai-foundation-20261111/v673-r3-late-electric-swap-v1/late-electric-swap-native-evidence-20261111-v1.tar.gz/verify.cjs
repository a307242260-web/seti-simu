'use strict';
const assert=require('node:assert/strict');
const {open,readZ}=require('./controlled-r3');
const dir=process.argv[2],r=n=>readZ(dir+'/'+n+'-20261111-v1.json.gz');let count=0;
function replay(root,trace,end){
 const m=open(root);
 try{
  for(const x of trace){if(x.n!==undefined)assert(x.n<=256&&x.ms<=600);m.apply(x.action||x);count++;}
  assert.deepEqual(m.save(),end);
  return m.state().match.finalScores?.find(x=>x.playerId==='player-white');
 }finally{m.dispose();}
}
const lines=r('lines'),recover=r('recover');
for(const a of [lines,recover]){
 for(const x of a.rows){replay(a.root,x.prefix,x.start);replay(x.start,x.actions,x.end);}
 for(const x of a.failures)replay(a.root,x.prefix,x.checkpoint);
}
const q=r('admit');
assert.deepEqual(q.results.map(x=>[x.chosen,x.q.value,x.q.diagnostics.nativeExecutions]),[['dlc_17.png：弃牌角标',189.5,0],['深空探测 1x 行动',192.5,10]]);
assert.deepEqual(q.ids,q.results[1].edge.steps);
const x=r('resume'),expected=lines.rows.find(x=>x.label==='A5-first/4分/swap-B16').checkpoints.E4.state;
replay(x.root,x.actions,x.end);assert.deepEqual(x.end,expected);assert.equal(x.stop.kind,'complete');
let terminal=0,gate=0;
for(const r4 of [r('fourth'),r('fourth-auto')])for(const x of r4.results){
 const score=replay(x.root,x.actions,x.end);
 if(x.stop==='terminal'){assert.deepEqual(score,x.terminal);terminal++;}
 else {assert(x.stop.n>256||x.stop.ms>600);assert(x.actions.slice(2).every(a=>a.passive&&a.n===undefined));gate++;}
}
assert.deepEqual([lines.rows.length,lines.failures.length,recover.rows.length,terminal,gate],[19,5,4,6,2]);
console.log(JSON.stringify({nativeReplayInputs:count,r3:lines.rows.length,invalid:lines.failures.length,recover:recover.rows.length,terminal,gate}));
