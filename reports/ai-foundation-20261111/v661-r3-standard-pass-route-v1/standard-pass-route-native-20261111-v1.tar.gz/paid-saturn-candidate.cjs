'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const target=path.resolve('randomizer/game/ai/decision-search.js'),old=Module._extensions['.js'];
Module._extensions['.js']=function(mod,file){
 if(file!==target)return old(mod,file);
 const s=fs.readFileSync(file,'utf8');
 const before='      const retainedActions = node.legalActions.filter(action => (!localPlan || localPlan.retainedActionIds.includes(action.actionId))';
 const filter='&& (!resourcePolicy || movementPolicy?.forceExecution || resourcePolicy.retainedActionIds.includes(action.actionId))';
 assert.equal(s.split(before).length,2);assert.equal(s.split(filter).length,2);
 const plan=String.raw`      const fundedLanding = node===root&&resourcePlanning&&movementPlanning&&realizationTies
        &&node.observation.publicState.roundNumber===4&&node.status==="stable"&&movementPolicy?.chosenGoal?.timing==="current-turn"
        &&movementPolicy.chosenGoal.kind==="land"&&movementPolicy.chosenGoal.endpointTarget?.type==="planet"
        &&movementPolicy.intent?.path.length<=2&&(movementPolicy.chosenGoal.endpointCost?.credits||0)===0
        &&node.observation.publicState.players.some(p=>p.playerId===evaluate.seatId&&p.energy>=(movementPolicy.chosenGoal.endpointCost.energy||0)
          +movementPolicy.intent.path.reduce((n,s)=>n+s.requiredMovePoints,0))?movementPolicy.selectedActionId:null;
`;
 mod._compile(s.replace(before,plan+before).replace(filter,filter.replace('|| resourcePolicy.retained','|| action.actionId===fundedLanding || resourcePolicy.retained')),file);
};
