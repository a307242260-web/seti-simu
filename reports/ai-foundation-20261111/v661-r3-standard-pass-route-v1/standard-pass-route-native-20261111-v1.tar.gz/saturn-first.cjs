'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,short}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port')),native=require(path.resolve('randomizer/game/production-kernel'));
const [file,alt,out]=process.argv.slice(2),known=readZ(file)['only-redirect-the-two-public-scans'],matrix=readZ(alt),results=[];
function diagnostic(m){
 const p=createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});p.setMovementPlanning(true);p.setResourcePlanning(true);p.setCardPickPlanning(true);
 try{
  const n=p.openRoot(),u=m.automatic(),g=p.goalMovementSpec(n),rs=p.resourceSpec(n),cs=p.cardPickSpec(n),menu=m.menu();
  return {a:u.a,n:u.n,ms:u.ms,value:u.value,roots:u.roots.map(r=>({...r,summary:menu.find(a=>a.actionId===r.actionId)?.summary})),
   movement:g,preparation:rs&&{plans:rs.plans,excludedActionIds:rs.excludedActionIds},card:cs};
 }finally{p.close();}
}
const cfg=[['no R3 move / B111',known.e],['no R3 move / B32',matrix.results.find(r=>r.label==='standard / B32').start.e]];
for(const [label,root] of cfg){
 const m=open(root);try{
  const base=diagnostic(m),route=native.getProbeRouteRequirements(m.state(),'player-white').candidates.find(c=>c.planetId==='saturn'&&c.endpointFamily==='land'&&c.endpointTarget.type==='planet');
  assert(base.n<=256&&base.ms<=600);console.log('base',JSON.stringify([label,base.a.summary,base.value,base.n,base.movement?.reason,base.movement?.chosenGoal?.id,base.roots.filter(r=>r.value!==null).map(r=>[r.summary,r.value,r.goal?.id])]));
  const prefix=[],same=()=>assert.deepEqual(m.save(),root),move=step=>{prefix.push(m.act('move',a=>a.target.deltaX===step.deltaX&&a.target.deltaY===step.deltaY&&a.target.rocketId===route.rocketId));prefix.push(m.act('choose_payment',a=>a.payload.energyCost===1));};
  for(const k of ['start-only','all-moves','all-moves-and-land']){
   m.restore(root);same();prefix.length=0;
   (k==='start-only'?route.path.slice(0,1):route.path).forEach(move);
   if(k==='all-moves-and-land'){prefix.push(m.act('land'));const landing=m.menu().find(a=>a.target.planetId==='saturn'&&a.target?.landTarget?.type==='planet');if(landing)prefix.push(m.apply(landing));}
   const steps=[],turns=[],start=m.save();let cp,stop,pendingTurn=false;
   for(let j=0;j<170;j++){
    if(m.state().turn.gameEnded){stop='terminal';break;}
    if(m.menu()[0].actorId!=='player-white'){const a=[];m.advanceOpponents(a);steps.push(...a.map(a=>({a,passive:true})));continue;}
    if(pendingTurn&&!m.save().session){turns.push(short(m));pendingTurn=false;}
    const q=m.automatic(cp);if(!q.complete||q.n>256||q.ms>600){stop={n:q.n,ms:q.ms,a:q.a?.summary};break;}
    cp=q.checkpoint;steps.push({a:m.apply(q.a),n:q.n,ms:q.ms,value:q.value});pendingTurn=q.a.family==='end_turn';
   }
   assert(stop);
   const end=m.save(),summary=short(m);
   m.restore(root);prefix.forEach(m.apply);assert.deepEqual(m.save(),start);steps.forEach(x=>m.apply(x.a));assert.deepEqual(m.save(),end);
   const peak=[Math.max(0,...steps.map(x=>x.n||0)),Math.max(0,...steps.map(x=>x.ms||0))];
   results.push({label,k,root,base,prefix:[...prefix],start,steps,turns,end,summary,stop,peak});
   console.log(JSON.stringify([label,k,stop,summary.established,turns.slice(0,3).map(s=>[s.wallet,s.established,s.hand,s.blue,s.probes]),peak,steps.slice(0,20).map(x=>x.a.summary)]));
  }
 }finally{m.dispose();}
}
writeZ(out,results);
