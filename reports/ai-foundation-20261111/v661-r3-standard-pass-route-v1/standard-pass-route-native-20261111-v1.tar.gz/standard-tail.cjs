'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,runCases,open}=require('./controlled-r3'),path=require('node:path');
const deck=require(path.resolve('randomizer/game/cards/deck'));
const [src,out]=process.argv.slice(2),d=readZ(src),root=i=>d.rows.find(x=>x.i===i).before;
const exact=(h,a)=>h.take(h.m.apply(a)),play=(h,id)=>h.take(h.m.play(id)),pick=(h,id)=>h.take(h.m.pick(id)),corner=(h,id)=>h.take(h.m.corner(id));
const data=(h,target='computer')=>{h.act('place_data');h.act('choose_target',a=>target==='computer'?a.target.target==='computer':a.target.target==='blueBonus'&&a.target.blueSlot===target);};
const target=(h,id)=>h.act('choose_target',a=>a.target.nebulaId===id);
const show=(h,id)=>h.act('choose_card',a=>a.summary===id);
const end=h=>h.act('end_turn');
function prep(h,reward='blue_1'){
 play(h,'amiba_0.webp');h.act('choose_target',a=>a.summary.startsWith(reward));data(h);data(h);end(h);
}
function orderScan(h,pair,which){
 play(h,'dlc_19.png');for(const x of pair)target(h,x);
 if(which)h.act('choose_target',a=>a.target?.kind==='planet-reward-alien-trace'&&a.target.traceType==='pink'&&a.target.alienSlotId===which);
}
function activeFinish(h){
 const forced=[];
 for(let j=0;h.m.save().session&&j<12;j++){
  const choices=h.m.menu();assert(choices.length);
  const a=choices.find(a=>a.family==='accept_optional_effect'&&a.target.choiceId?.startsWith('confirm:'))
   ||choices.find(a=>a.family==='choose_card'&&a.target.source==='display')||(choices.length===1?choices[0]:null);
  if(!a)break;
  forced.push(exact(h,a));
 }
 return forced;
}
const groups=[
 [172,[
  ['A0 blue1 then DLC19 double Kepler, slot 2',h=>{prep(h);orderScan(h,['sector-3-a','sector-3-a'],2);}],
  ['A0 blue3 then DLC19 double Kepler, slot 2',h=>{prep(h,'blue_3');orderScan(h,['sector-3-a','sector-3-a'],2);}],
  ['A0 blue1 then DLC19 double Kepler, slot 2, A3 remove yellow',h=>{
    prep(h);orderScan(h,['sector-3-a','sector-3-a'],2);activeFinish(h);end(h);
    play(h,'amiba_3.webp');h.act('choose_target',a=>a.summary.startsWith('黄色痕迹'));activeFinish(h);end(h);
   }],
  ['A0 blue1 then DLC19 Kepler / Virgo',h=>{prep(h);orderScan(h,['sector-3-a','sector-1-b']);}],
  ['A0 blue1 then DLC19 double Kepler, Amiba pink4',h=>{prep(h);orderScan(h,['sector-3-a','sector-3-a']);h.act('choose_target',a=>a.target.alienSlotId===1&&a.target.position===4);}]
 ]],
 [203,['amiba_7.webp','amiba_9.webp','b_16.webp'].map(id=>['third computer income '+id,h=>{
  const c=h.m.player().hand.find(c=>c.cardId===id);console.log('INCOME-ICON',id,deck.getIncomeGainForCard(c));
  h.act('choose_card',a=>a.target.cardInstanceId===c.id);h.cut('after-income');
 }])],
 [235,[['play DLC25 instead of A5',h=>play(h,'dlc_25.png')]]],
 [239,[
  ['swap DLC17 for DLC14 (retain B16)',h=>{show(h,'dlc_17.png');pick(h,'dlc_14.png');}],
  ['swap DLC25 for DLC14 (retain B16)',h=>{show(h,'dlc_25.png');pick(h,'dlc_14.png');}],
  ['swap DLC25 for DLC15 (retain B16)',h=>{show(h,'dlc_25.png');pick(h,'dlc_15.png');}]
 ]],
 [242,[['play DLC17 instead of analysis',h=>play(h,'dlc_17.png')]]],
];
for(const [i,cases] of groups){
 const e=root(i),res=runCases(e,cases);writeZ(out+'-'+i+'.json.gz',{root:e,...res});
}
