'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const target=path.resolve('randomizer/game/ai/decision-search.js'),port=path.resolve('randomizer/game/ai/analysis-port.js'),old=Module._extensions['.js'];
Module._extensions['.js']=function(mod,file){
 if(file!==target&&file!==port)return old(mod,file);
 let s=fs.readFileSync(file,'utf8');
 const edit=(from,to)=>{assert.equal(s.split(from).length,2,from);s=s.replace(from,to);};
 if(file===target){
  const before='      const retainedActions = node.legalActions.filter(action => (!localPlan || localPlan.retainedActionIds.includes(action.actionId))';
  const filter='&& (!resourcePolicy || movementPolicy?.forceExecution || resourcePolicy.retainedActionIds.includes(action.actionId))';
  const plan=String.raw`      const fundedLanding = readyHeldTask&&node===root&&node.status==="stable"&&movementPolicy?.chosenGoal?.timing==="current-turn"
        &&movementPolicy.chosenGoal.kind==="land"&&movementPolicy.chosenGoal.endpointTarget?.type==="planet"
        &&movementPolicy.intent?.path.length<=2&&(movementPolicy.chosenGoal.endpointCost?.credits||0)===0
        &&node.observation.publicState.players.some(p=>p.playerId===evaluate.seatId&&p.energy>=(movementPolicy.chosenGoal.endpointCost.energy||0)
          +movementPolicy.intent.path.reduce((n,s)=>n+s.requiredMovePoints,0))?movementPolicy.selectedActionId:null;
`;
  edit(before,plan+before);
  edit(filter,filter.replace('|| resourcePolicy.retained','|| action.actionId===fundedLanding || resourcePolicy.retained'));
  const enable='    const quoteDeferredSector = resourcePlanning';
  edit(enable,'    const readyHeldTask=resourcePlanning&&movementPlanning&&realizationTies&&root.observation.publicState.roundNumber===4?port.readyHeldLaunchTask?.():null;\n'+enable);
  const price='      const priorForecast=Math.max(0,';
  edit(price,'      const heldTaskGain=readyHeldTask&&BOUNDARIES.has(node.status)?port.quoteReadyHeldLaunchTask(node,readyHeldTask):0;\n'+price.replace('0,','0,heldTaskGain,'));
 }else{
  const before='    function valueObservation(node) {';
  const quote=String.raw`
    function readyHeldLaunchTask() {
      const stored=nodes.get(openedRoot);
      if(!stored||openedRoot.status!=="stable"||stored.envelope.session)return null;
      const state=readPlanningState(stored),p=state.players.players.find(p=>p.id===seatId);
      if(state.turn.roundNumber!==4||p.mainActionCompleted||p.passCompletionPending||state.turn.passedPlayerIds.includes(seatId))return null;
      const known=knownCards(stored.envelope);
      const eligible=[];
      for(const card of p.hand){
        if(!known.has(card.id)||!card.cardId||card.hidden)continue;
        const model=cardEffects.getCardModel(card),play=model?.playEffects,tasks=model?.tasks;
        if(model?.cardType!==2||model.endGameScoring||model.triggers?.length||model.temporaryTasks?.length
          ||play?.length!==2||play[0].type!=="launch"||play[0].options?.skipCost!==true||play[1].type!=="gain_data"||tasks?.length!==1)continue;
        const task=tasks[0],cost=cardEffects.getCardPlayCost(card),reward=task.rewards?.[0],gain=reward?.options?.gain;
        if(task.condition?.type!=="planetOrbitOrLand"||!cardEffects.taskConditionMet(task,p,state)
          ||Object.keys(cost).length!==1||!Number.isSafeInteger(cost.credits)||cost.credits>p.resources.credits
          ||task.rewards.length!==1||reward.type!=="gain_resources"||!Number.isSafeInteger(gain?.score)||gain.score<=0
          ||Object.entries(gain).some(([k,v])=>!["score","publicity"].includes(k)||!Number.isSafeInteger(v)||v<0))continue;
        const value=gain.score-cost.credits*stateValue.DEFAULT_WEIGHTS.credits-stateValue.DEFAULT_WEIGHTS.handSize;
        if(value>0)eligible.push({cardId:card.id,cost:cost.credits,value});
      }
      return eligible.sort((a,b)=>b.value-a.value||a.cardId.localeCompare(b.cardId))[0]||null;
    }

    function quoteReadyHeldLaunchTask(node,source) {
      if(!["other-owner","turn-boundary","information-barrier"].includes(node.status))return 0;
      const stored=nodes.get(node);
      if(!stored||stored.envelope.session)return 0;
      const state=readPlanningState(stored),p=state.players.players.find(p=>p.id===seatId);
      if(state.turn.roundNumber!==4||state.turn.gameEnded||state.turn.passedPlayerIds.includes(seatId)
        ||p.passCompletionPending||p.resources.credits<source.cost||!p.hand.some(c=>c.id===source.cardId&&!c.hidden)
        ||state.pieces.rockets.some(r=>r.playerId===seatId&&(r.kind??"standard")==="standard")
        ||p.reservedCards.some(c=>cardEffects.hasMatchingTrigger({...p,reservedCards:[c]}, {type:"launch",playerId:seatId})))return 0;
      return resourceQuery(state).launchPossible?source.value:0;
    }

`;
  edit(before,quote+before);
  edit('return Object.freeze({ openRoot, expand, identity,','return Object.freeze({ openRoot, expand, identity, readyHeldLaunchTask, quoteReadyHeldLaunchTask,');
 }
 mod._compile(s,file);
};
