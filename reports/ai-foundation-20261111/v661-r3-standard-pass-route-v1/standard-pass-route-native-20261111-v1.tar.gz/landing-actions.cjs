'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [ref,fix,newFile,out]=process.argv.slice(2),refRow=readZ(ref)['only-redirect-the-two-public-scans'],fixRow=readZ(fix).find(r=>r.k==='start-only'&&r.label.endsWith('B111')),nextRow=readZ(newFile).results.find(r=>r.label==='standard / B111'),rows=[];
const id='player-white';
const planets=(m)=>Object.fromEntries(Object.entries(m.state().planets.planets).map(([k,v])=>[k,[v.orbitMarkers.filter(r=>r.playerId===id||r.playerColor==='white').length,v.landingMarkers.filter(r=>r.playerId===id||r.playerColor==='white').length]]));
for(const [label,start,list,end] of [['old',refRow.e,refRow.actions.map(x=>x.action||x.a||x),refRow.end],['direct-saturn',fixRow.root,fixRow.prefix.concat(fixRow.steps.map(x=>x.a)),fixRow.end],['task-quote-candidate',nextRow.start.e,nextRow.steps.map(x=>x.a),nextRow.end.e]]){
 const m=open(start),p=[],white=[];
 try{
  let last=planets(m);
  for(const a of list){
   m.apply(a);if(a.actorId!==id)continue;
   const f=short(m),pl=planets(m),changed=Object.keys(pl).filter(k=>pl[k].some((n,i)=>n!==last[k][i]));
   if(changed.length||a.family==='complete_task'||a.family==='card_corner'||a.family==='play_card'||a.family==='end_turn')
    white.push({a,changed,wallet:f.wallet,hand:f.hand,established:f.established});
   if(changed.length)p.push([a.summary,changed,f.wallet,f.hand]);last=pl;
  }
  assert.deepEqual(m.save(),end);
  const s=m.state(),total=s.match.finalScores.find(a=>a.playerId===id).totalScore;rows.push({label,total,planets:p,white});
  console.log(label,total,JSON.stringify(white.slice(0,12).map(x=>[x.a.summary,x.changed,x.wallet,x.hand])));
 }finally{m.dispose();}
}
writeZ(out,rows);
