'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ}=require('./controlled-r3');
const [p,out]=process.argv.slice(2),d=readZ(p),rows=[];
for(const row of d.filter(x=>x.k==='start-only')){
 const m=open(row.root);try{
  console.log('wallet shape',Object.keys(m.owner('player-white').publicState.players.find(p=>p.playerId==='player-white')));
  const u=m.automatic(),legal=m.menu(),c=u.roots.map(x=>({...x,summary:legal.find(a=>a.actionId===x.actionId)?.summary}));
  rows.push({label:row.label,root:row.root,legal,selected:u.a,complete:u.complete,n:u.n,ms:u.ms,value:u.value,roots:c});
  console.log(JSON.stringify([row.label,u.a?.summary,u.value,u.n,u.ms,u.complete,c.filter(x=>x.summary?.includes('向外')||x.summary?.includes('深空探测'))]));
 }finally{m.dispose();}
}
writeZ(out,rows);
