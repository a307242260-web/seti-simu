'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,open,short}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),root=i=>d.rows.find(x=>x.i===i).before,A='b_111.webp',B='b_32.webp';
const variants=[];
const fill=(m,log,t='computer')=>{
 log.push(m.act('place_data'));
 log.push(m.act('choose_target',a=>t==='computer'?a.target.target==='computer':a.target.target==='blueBonus'&&a.target.blueSlot===t));
};
const move=(m,log,text)=>{
 log.push(m.act('move',a=>a.summary.includes(text)));
 log.push(m.act('choose_payment',a=>a.payload.energyCost===1));
};
if(process.env.SETI_CARRY_SWAP||process.env.SETI_CARRY_INCLUDE_B111)variants.push(['standard / B111',258,A,()=>{}]);
variants.push(['standard / B32',258,B,()=>{}]);
for(const dir of ['向内','向外','顺时针','逆时针'])for(const keep of [A,B])variants.push(['move '+dir+' / '+keep,258,keep,(m,l)=>move(m,l,dir)]);
for(const keep of [A,B]){
 variants.push(['keep two cards / three computer / '+keep,247,keep,(m,l)=>{for(let i=0;i<3;i++)fill(m,l);l.push(m.act('end_turn'));}]);
 variants.push(['keep two cards / computer2 / blue2 / '+keep,247,keep,(m,l)=>{fill(m,l);fill(m,l);fill(m,l,1);l.push(m.act('end_turn'));}]);
 variants.push(['keep two cards / computer2 / pool1 / '+keep,247,keep,(m,l)=>{fill(m,l);fill(m,l);l.push(m.act('end_turn'));}]);
}
const selected=process.env.SETI_CARRY_LABEL?.split('|');
function snapshot(m){return {e:m.save(),p:short(m),f:m.facts()};}
function resume(m){
 const start=snapshot(m),steps=[],turns=[];
 let checkpoint,stop,checkpointTurn=false;
 for(let j=0;j<210;j++){
  if(m.state().turn.gameEnded){stop='terminal';break;}
  const a=m.menu()[0];assert(a);
  if(a.actorId!=='player-white'){
   const passive=[];m.advanceOpponents(passive);steps.push(...passive.map(a=>({a,passive:true})));continue;
  }
  if(checkpointTurn&&!m.save().session){turns.push({p:short(m),step:steps.length});checkpointTurn=false;}
  const u=m.automatic(checkpoint);
  if(!u.complete||!u.a||u.n>256||u.ms>600){stop={kind:'gate',n:u.n,ms:u.ms,action:u.a,complete:u.complete};break;}
  steps.push({a:m.apply(u.a),n:u.n,ms:u.ms,value:u.value});checkpoint=u.checkpoint;checkpointTurn=u.a.family==='end_turn';
 }
 assert(stop);
 const end=snapshot(m);
 if(stop==='terminal'){
  const s=m.state();
  assert(s.match.finalScoringSettled);assert.equal(s.match.finalScores.find(t=>t.playerId==='player-white').totalScore,end.p.established);
 }
 return {start,steps,turns,end,stop,peak:[Math.max(0,...steps.map(r=>r.n||0)),Math.max(0,...steps.map(r=>r.ms||0))]};
}
const results=[],failures=[];
for(const [label,index,keep,apply] of variants){
 if(selected&&!selected.includes(label))continue;
 let e=root(index);
 if(process.env.SETI_CARRY_SWAP){
  assert.equal(e.session,null);const s=JSON.parse(e.committedState),pile=s.cards.drawPileCardIds,a=s.aliens.amiba.cardDeck;
  const n=process.env.SETI_CARRY_SWAP_INDEX?Number(process.env.SETI_CARRY_SWAP_INDEX):1;
  assert(pile[n]);[pile[0],pile[n]]=[pile[n],pile[0]];
  if(process.env.SETI_CARRY_SWAP==='both')[a[0],a[1]]=[a[1],a[0]];
  e={...e,committedState:JSON.stringify(s)};
 }
 const m=open(e),inputs=[];
 try{
  try{apply(m,inputs);}
  catch(err){failures.push({label,index,keep,inputs,reason:err.message});console.log(JSON.stringify([label,'failed',err.message]));continue;}
  const r3=snapshot(m);
  inputs.push(m.act('pass'),m.act('choose_card',a=>a.target.cardId===keep||a.summary===keep));
  m.advanceOpponents(inputs);assert.equal(m.facts().round,4);
  const r=resume(m);
  m.restore(e);inputs.forEach(a=>m.apply(a));assert.deepEqual(m.save(),r.start.e);
  r.steps.forEach(x=>m.apply(x.a));assert.deepEqual(m.save(),r.end.e);
  results.push({label,index,keep,inputs,r3,...r});
  console.log(JSON.stringify([label,[r3.p.wallet,r3.p.established,r3.p.hand,r3.p.blue,r3.p.income],r.stop==='terminal'?r.end.p.established:[r.stop.n,r.stop.ms,r.stop.action?.summary],
   r.turns.slice(0,3).map(t=>[t.p.wallet,t.p.established,t.p.hand.length,t.p.probes]),r.peak,r.steps.filter(x=>!x.passive&&x.a.phase==='main').map(x=>x.a.summary)]));
 }finally{m.dispose();}
}
writeZ(out,{results,failures,swap:process.env.SETI_CARRY_SWAP||null});
