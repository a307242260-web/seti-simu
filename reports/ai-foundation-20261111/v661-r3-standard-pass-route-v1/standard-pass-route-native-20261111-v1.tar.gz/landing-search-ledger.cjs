'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,short}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port')),{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [file,out]=process.argv.slice(2),d=readZ(file),rows=[];
for(const r of d.filter(x=>x.k==='all-moves-and-land')){
 const m=open(r.root);
 try{
  const anchors=[['root',m.save()]];
  for(const [j,a] of r.prefix.entries()){m.apply(a);if(j%2===1||j+1===r.prefix.length)anchors.push([String(j+1),m.save()]);}
  for(const [name,e] of anchors){
   m.restore(e);const port=createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});
   try{
    const menus=m.menu(),q=createSearchAgent({seatId:'player-white',analysisPort:port}).decide({seatId:'player-white',legalActions:menus}).search;
    assert.deepEqual(m.save(),e);
    const a=q.lines[0],x=q.roots.filter(x=>x.value!==null).map(x=>[menus.find(a=>a.actionId===x.actionId)?.summary,x.value,x.target]);
    const planets=Object.entries(m.state().planets.planets).flatMap(([id,p])=>p.orbitMarkers.concat(p.landingMarkers||[]).filter(x=>x.playerId==='player-white'||x.playerColor==='white'||x.color==='white').map(a=>[id,a]));
    console.log(JSON.stringify([r.label,name,short(m),planets,q.value,menus.find(a=>a.actionId===q.actionId)?.summary,x,Object.keys(a||{})]));
    rows.push({label:r.label,name,e,q,menus,planets,summary:short(m)});
   }finally{port.close();}
  }
 }finally{m.dispose();}
}
writeZ(out,rows);
