'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{readZ,writeZ,open,short}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port')),native=require(path.resolve('randomizer/game/production-kernel')),flow=require(path.resolve('randomizer/game/turn-flow'));
const [src,reference,carry,out]=process.argv.slice(2),standard=readZ(src),d=readZ(carry),old=readZ(reference)['only-redirect-the-two-public-scans'];
const e=standard.rows.find(x=>x.i===258).before,m=open(e),entries={};
function audit(e){
 const p=open(e);try{
 const t=p.state().turn,core=p.state(),obs=p.owner('player-white'),wallet=p.facts().wallet;
 const candidates=native.getProbeRouteRequirements(core,'player-white').candidates
  .map(a=>({target:a.requirementId,cost:a.required,facts:a.endpointFacts,benefit:a.targetBenefit,path:a.path,planet:a.planetId}))
  .filter(a=>['saturn','jupiter','venus','neptune','uranus'].includes(a.planet));
 return {turn:t,rotation:core.solarSystem.rotation,probes:short(p).probes,wallet,hand:short(p).hand,knownTasks:obs.selfState.reservedCards?.map(c=>c.cardId),candidates};
 }finally{p.dispose();}
}
try{
 const p=createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});p.setMovementPlanning?.(true);p.setResourcePlanning(true);
 const a=p.openRoot(),s=m.automatic(),menu=m.menu();p.close();
 entries.R3={e,menu,roots:s.roots,decision:[s.a.summary,s.value,s.n,s.ms],facts:audit(e)};
 console.log('r3',JSON.stringify([entries.R3.decision,entries.R3.facts.turn.passedPlayerIds,entries.R3.facts.turn.currentPlayerId,s.roots.map(x=>[menu.find(a=>a.actionId===x.actionId)?.summary,x.completion,x.value,x.chosenGoal])]));
 const r0=open(old.e);try{for(const a of old.actions)r0.apply(a.action||a.a||a);assert.deepEqual(r0.save(),old.end);assert.equal(r0.facts().final,239);}finally{r0.dispose();}
 entries.reference={...audit(old.e)};
 for(const row of d.results.filter(x=>x.index===258&&x.keep==='b_111.webp'&&x.label.includes('move'))){
  const {label,inputs,steps,start,turns}=row;
  entries[label]=audit(start.e);
  console.log(label,JSON.stringify([entries[label].probes,entries[label].wallet,entries[label].candidates.map(c=>[c.target,c.cost.credits,c.cost.energy,c.cost.movementPoints]),steps.slice(0,25).filter(x=>!x.passive).map(x=>[x.a.summary,x.a.target])]));
 }
 console.log('reference',JSON.stringify([entries.reference.probes,entries.reference.wallet,entries.reference.candidates.map(c=>[c.target,c.cost.credits,c.cost.energy,c.cost.movementPoints]),old.actions.slice(0,27).map(a=>a.action?.summary||a.a?.summary||a.summary)]));
 writeZ(out,entries);
}finally{m.dispose();}
