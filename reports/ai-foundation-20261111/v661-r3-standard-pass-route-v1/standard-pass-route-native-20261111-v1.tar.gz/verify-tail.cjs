'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ}=require('./controlled-r3');
const [src,dir,out]=process.argv.slice(2),d=readZ(src),row=i=>d.rows.find(r=>r.i===i).before;
const official=readZ(dir+'/reference-r4.json.gz')['only-redirect-the-two-public-scans'],counts={};
const verify=(start,actions,end)=>{
 const m=open(start);try{
  actions.forEach(a=>m.apply(a));assert.deepEqual(m.save(),end);
  if(!m.state().turn.gameEnded)return null;
  const scores=m.state().match.finalScores;assert(m.state().match.finalScoringSettled);
  const value=scores.find(x=>x.playerId==='player-white').totalScore;
  assert.equal(m.facts().final,value);return value;
 }finally{m.dispose();}
};
const normalize=x=>x.action||x.a||x;
assert.equal(verify(official.e,official.actions.map(normalize),official.end),239);
const p=open(row(258));try{
 p.act('pass');p.act('choose_card',a=>a.summary==='b_111.webp');p.advanceOpponents([]);
 assert.deepEqual(p.save(),official.e);
}finally{p.dispose();}
for(const name of ['carry-full','carry-hidden-both','carry-hidden-salary12','carry-ready-held-task','carry-ready-held-task-salary12']){
 const q=readZ(dir+'/'+name+'-20261111-v1.json.gz');
 counts[name]={segments:0,inputs:0,results:[]};
 for(const x of q.results){
  let start=row(x.index);
  if(q.swap){
   const s=JSON.parse(start.committedState),pile=s.cards.drawPileCardIds,n=name.endsWith('salary12')?12:1,a=s.aliens.amiba.cardDeck;
   [pile[0],pile[n]]=[pile[n],pile[0]];
   if(q.swap==='both')[a[0],a[1]]=[a[1],a[0]];
   start={...start,committedState:JSON.stringify(s)};
  }
  assert.equal(verify(start,x.inputs,x.start.e),null);
  for(const s of x.steps)if(!s.passive)assert(s.n<=256&&s.ms<=600);
  const final=verify(x.start.e,x.steps.map(normalize),x.end.e);
  assert.equal(x.stop==='terminal',final!==null);
  counts[name].segments+=2;counts[name].inputs+=x.inputs.length+x.steps.length;
  counts[name].results.push([x.label,final,x.peak,x.start.p.hand,x.stop==='terminal'?null:[x.stop.n,x.stop.ms]]);
 }
}
const direct=readZ(dir+'/saturn-first-20261111-v1.json.gz');
counts.direct={segments:0,inputs:0,results:[]};
for(const x of direct){
 const v=verify(x.root,x.prefix.concat(x.steps.map(normalize)),x.end);
 assert(x.steps.every(s=>s.passive||s.n<=256&&s.ms<=600));assert.equal(x.stop==='terminal',v!==null);
 counts.direct.segments++;counts.direct.inputs+=x.prefix.length+x.steps.length;
 counts.direct.results.push([x.label,x.k,v,x.peak]);
}
for(const i of [172,203,235,239,242]){
 const q=readZ(dir+'/standard-tail-20261111-v1-'+i+'.json.gz');
 assert.deepEqual(q.root,row(i));
 counts[i]={segments:0,inputs:0,results:[]};
 for(const x of q.rows){
  assert(x.actions.every(s=>s.passive||s.n<=256&&s.ms<=600));
  assert.equal(verify(q.root,x.prefix.concat(x.actions.map(normalize)),x.end),null);
  counts[i].segments++;counts[i].inputs+=x.prefix.length+x.actions.length;
  counts[i].results.push([x.label,x.settled?.summary,x.stop]);
 }
}
console.log(JSON.stringify({segments:1+Object.values(counts).reduce((s,r)=>s+r.segments,0),inputs:official.actions.length+Object.values(counts).reduce((s,r)=>s+r.inputs,0)}));
writeZ(out,counts);
