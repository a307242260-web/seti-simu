'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),Module=require('node:module');
const {open,readZ,writeZ}=require('./controlled-r3'),prepare=require('./reuse-scan.cjs');
const [mode,input,out]=process.argv.slice(2),src=path.resolve('randomizer/game/ai/analysis-port.js');
const mod=new Module(src,module);mod.filename=src;mod.paths=Module._nodeModulePaths(path.dirname(src));
let code=prepare(fs.readFileSync(src,'utf8'),require(process.env.SETI_SCAN_PRIOR));
function sub(a,b){assert.equal(code.split(a).length,2,a);code=code.replace(a,b);}
if(mode.includes('test')){
 const anchor='a.actionId===deferredCappedTask?.actionId||scoredCorner&&a.family==="end_turn"';
 const pre='||state.turn.roundNumber===4&&!owner.mainActionCompleted&&a.family==="industry"&&a.target?.abilityId==="deepspace_swap_cards"';
 const condition=mode==='test-data'?'&&cardPick?.companySwap?.goal.kind==="data"':mode==='test-data-income'?'&&(cardPick?.companySwap?.goal.kind==="data"||cardPick?.companySwap?.goal.kind==="move"&&plans.some(p=>p.goal.kind==="income"))':'&&cardPick?.companySwap?.goal.kind==="move"&&plans.some(p=>p.goal.kind==="income")';
 sub(anchor,anchor+pre+condition);
}
if(mode.includes('blue')){
 const anchor='      const plans=[];\n      if(node===openedRoot&&state.turn.roundNumber===3){';
 sub(anchor,'      if(state.turn.roundNumber===4&&!state.players.players.find(p=>p.id===seatId).mainActionCompleted)goals=goals.filter(g=>g.kind!=="blue-data");\n'+anchor);
}
if(mode==='income'){
 const anchor='      const plans=[];\n      if(node===openedRoot&&state.turn.roundNumber===3){';
 sub(anchor,'      if(state.turn.roundNumber===4&&!state.players.players.find(p=>p.id===seatId).mainActionCompleted)goals=goals.filter(g=>g.kind!=="income");\n'+anchor);
}
mod._compile(code,src);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const data=readZ(input).rows.map(r=>({...r,root:r.state})),results=[];
const fields=['actionId','value','realization','preparationDebt','complete','roots','lines','unresolved','selectionPlan','candidates','sharedPrefixGraph'];
for(const r of data){
 const m=open(r.root),seatId='player-white',port=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
 try{
  const agent=createSearchAgent({seatId,analysisPort:port}),q=agent.decide({seatId,legalActions:m.menu()}).search,cp=agent.createCheckpoint();
  assert.deepEqual(m.save(),r.root);
  const actual=JSON.parse(JSON.stringify(q));
  
  console.log(JSON.stringify({mode,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,delta:r.q.diagnostics.nativeExecutions-q.diagnostics.nativeExecutions,complete:q.complete,nodes:q.diagnostics.nodes,roots:q.roots.length,value:q.value,details:q.planEvidence?.steps?.length,action:m.menu().find(a=>a.actionId===q.actionId).summary}));
  results.push({mode,root:r.root,q,cp});
 }finally{port.close();m.dispose();}
}
writeZ(out,results);
