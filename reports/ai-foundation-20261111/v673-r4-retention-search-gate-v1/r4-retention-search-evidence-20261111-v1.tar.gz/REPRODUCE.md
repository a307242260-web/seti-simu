使用 Production cbd73e00c98455dac868bd43be3e1759130088a7 的独立快照。以下命令从该快照的根目录执行；将 A 设为归档的解包目录。所有运行只读取正式棋盘，分析模块在进程内临时装入，不替换工作树文件。重放脚本要求输出文件事先不存在。

    SETI_SCAN_PRIOR="$A/prior.cjs" node "$A/prove-scan.cjs" "$A/profile2.json.gz" "$A/replayed-scan-proof.json.gz"
    SETI_SCAN_PRIOR="$A/prior.cjs" node "$A/diagnose-bind.cjs" bound "$A/profile2.json.gz" "$A/replayed-bound.json.gz"

第一条重建 350 个原生逐输入对照，生成完整的前后存档。第二条只检查「换数据牌后绑定分析」诊断，不作为策略验收。scan-compare.json.gz 含扫描候选的搜索图；profile2.json.gz 含同根 Production 图、原生输入与起点；prefix-reference / prefix-swap 含获胜路线证书（前者仅复用扫描，后者禁掉主行动前换牌，用于对照）。机器耗时不要求逐次相同。
