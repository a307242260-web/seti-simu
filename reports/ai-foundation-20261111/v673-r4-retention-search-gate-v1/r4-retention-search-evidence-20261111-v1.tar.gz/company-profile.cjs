'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),Module=require('node:module');
const {open,readZ,writeZ}=require('./controlled-r3'),prepare=require('./reuse-scan.cjs');
const [mode,input,out]=process.argv.slice(2),src=path.resolve('randomizer/game/ai/analysis-port.js');
const mod=new Module(src,module);mod.filename=src;mod.paths=Module._nodeModulePaths(path.dirname(src));
let code=prepare(fs.readFileSync(src,'utf8'),require(process.env.SETI_SCAN_PRIOR));
function sub(a,b){assert.equal(code.split(a).length,2,a);code=code.replace(a,b);}
if(mode.includes('swap')){
 const anchor='a.actionId===deferredCappedTask?.actionId||scoredCorner&&a.family==="end_turn"';
 sub(anchor,anchor+'||state.turn.roundNumber===4&&!owner.mainActionCompleted&&a.family==="industry"&&a.target?.abilityId==="deepspace_swap_cards"');
}
if(mode.includes('blue')){
 const anchor='      const plans=[];\n      if(node===openedRoot&&state.turn.roundNumber===3){';
 sub(anchor,'      if(state.turn.roundNumber===4&&!state.players.players.find(p=>p.id===seatId).mainActionCompleted)goals=goals.filter(g=>g.kind!=="blue-data");\n'+anchor);
}
if(mode.includes('income')){
 const anchor='      const plans=[];\n      if(node===openedRoot&&state.turn.roundNumber===3){';
 sub(anchor,'      if(state.turn.roundNumber===4&&!state.players.players.find(p=>p.id===seatId).mainActionCompleted)goals=goals.filter(g=>g.kind!=="income");\n'+anchor);
}
sub('      const company=industryCatalog.getPlayerIndustryDefinition(owner),bluePlan=',`      if(node.status==="stable"&&state.turn.roundNumber===4&&!owner.mainActionCompleted&&cardPick?.companySwap)
        globalThis.companyQuotes.push({hand:owner.hand.map(c=>c.cardId),resources:owner.resources,income:owner.income,
          computer:data.listComputerPlacedTokens(owner).length,blue:owner.dataState.placedTokens.filter(t=>t.placementKind==="blueBonus").map(t=>t.placementSlot),
          swap:cardPick.companySwap,route:plans.filter(p=>p.goal.kind==="route").map(p=>({id:p.id,required:p.goal.required}))});
      const company=industryCatalog.getPlayerIndustryDefinition(owner),bluePlan=`);
mod._compile(code,src);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const data=readZ(input).rows.map(r=>({...r,root:r.state})),results=[];
const fields=['actionId','value','realization','preparationDebt','complete','roots','lines','unresolved','selectionPlan','candidates','sharedPrefixGraph'];
for(const r of data){
 const m=open(r.root),seatId='player-white',port=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
 try{
  globalThis.companyQuotes=[];
  const agent=createSearchAgent({seatId,analysisPort:port}),q=agent.decide({seatId,legalActions:m.menu()}).search,cp=agent.createCheckpoint();
  assert.deepEqual(m.save(),r.root);
  const actual=JSON.parse(JSON.stringify(q));
  
  console.log(JSON.stringify({mode,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,delta:r.q.diagnostics.nativeExecutions-q.diagnostics.nativeExecutions,complete:q.complete,nodes:q.diagnostics.nodes,roots:q.roots.length,value:q.value,details:q.planEvidence?.steps?.length,action:m.menu().find(a=>a.actionId===q.actionId).summary}));
  results.push({mode,root:r.root,q,cp,quotes:globalThis.companyQuotes});
 }finally{port.close();m.dispose();}
}
writeZ(out,results);
