'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ}=require('./controlled-r3'),
 {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port')),{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const d=readZ(process.argv[2]),before=d.rows.find(r=>r.label==='after preparing cash, normal policy').start,
 after=d.rows.find(r=>r.label==='dlc_17.png / repeat-first / autonomous'),m=open(d.root),rows=[];
let swapRoot;
try{
 for(const a of after.prefix){
  if(a.family==='play_card'&&a.summary==='dlc_20.png'){swapRoot=m.save();break;}
  m.apply(a);
 }
 for(const [mode,root] of [['cash-before-swap',before],['cash-after-swap',swapRoot]]){
  m.restore(root);
  const seatId='player-white',legal=m.menu(),port=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
  try{
   const q=createSearchAgent({seatId,analysisPort:port}).decide({seatId,legalActions:legal}).search;
   assert.deepEqual(m.save(),root);assert(q.complete&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600);
   const picks=legal.filter(a=>['industry','play_card','analyze','pass'].includes(a.family)).map(a=>[a.summary,q.roots.find(x=>x.actionId===a.actionId)]);
   console.log(JSON.stringify({mode,choice:legal.find(a=>a.actionId===q.actionId).summary,picks:picks.map(([a,b])=>[a,b?.value,b?.completion]),ms:q.rootAndSearchMilliseconds,n:q.diagnostics.nativeExecutions}));
   rows.push({mode,root,picks,q});
  }finally{port.close();}
 }
}finally{m.dispose();}
writeZ(process.argv[3],{rows});
