'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [input,out]=process.argv.slice(2),d=readZ(input),root=d.rows.find(r=>r.label==='dlc_17.png / repeat-first / autonomous').settled.state,rows=[];
const m=open(root);
try{
 for(const name of ['data-pool','data-computer']){
  m.restore(root);const prefix=[m.corner('amiba_2.webp')];
  assert.equal(m.facts().wallet.availableData,1);
  if(name==='data-computer'){
   prefix.push(m.act('place_data'));prefix.push(m.act('choose_target',a=>a.target.target==='computer'));
   assert.equal(m.facts().computer.length,5);
  }
  const state=m.save(),summary=short(m);
  m.restore(root);prefix.forEach(m.apply);assert.deepEqual(m.save(),state);
  rows.push({label:name,settled:{state,summary},prefix});
  console.log(JSON.stringify({name,summary}));
 }
 writeZ(out,{root,rows});
}finally{m.dispose();}
