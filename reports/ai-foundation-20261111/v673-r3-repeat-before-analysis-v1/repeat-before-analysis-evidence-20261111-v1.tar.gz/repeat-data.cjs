'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [ledgerFile,out]=process.argv.slice(2),d=readZ(ledgerFile),root=d.rows.find(r=>r.k===221).root;
const cases=[],controls=[];
function end(c){
 c.act('end_turn');
 const others=[];c.m.advanceOpponents(others);c.take(...others);
}
function prepare(c){
 end(c);c.take(c.m.corner('b_16.webp'),c.m.corner('amiba_9.webp'));
 c.act('research_tech');c.act('choose_target',a=>a.target.tileId==='blue1'&&a.target.blueSlot===3);
 for(const slot of [null,null,3]){
  c.act('place_data');
  c.act('choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');
 }
 c.cut('cash-and-six-tech');
 end(c);
}
function analyze(c,choice){
 c.act('analyze');c.act('choose_target',a=>a.target.choiceId===choice);
 if(choice.endsWith(':3'))c.act('choose_card',a=>a.target.source==='display'&&a.target.cardIndex===2);
 c.cut('after-analysis');
}
function repeat(c,id){
 const before=c.m.facts(),credits=before.wallet.credits,data=before.wallet.availableData;
 assert(credits>=1);
 c.take(c.m.play('dlc_20.png'));
 const opts=c.m.menu().map(a=>[a.summary,a.target]);
 controls.push({id,opts});
 const cardId=c.m.player().hand.find(a=>a.cardId===id)?.id;
 c.act('choose_card',a=>a.target.cardInstanceId===cardId||a.summary.includes(id));
 assert.equal(c.m.facts().wallet.credits,credits-1);
 assert.equal(c.m.facts().wallet.availableData,data+3);
 c.cut('after-repeat');
}
function slot(c){
 assert(c.m.facts().wallet.availableData>=4);
 for(let i=0;i<4;i++){
  c.act('place_data');c.act('choose_target',a=>a.target.target==='computer');
 }
 c.act('choose_card',a=>a.summary.includes('dlc_25.png'));
 c.cut('inserted-electricity');
}
for(const id of ['dlc_17.png','dlc_15.png'])for(const order of ['repeat-first','analysis-first']){
 const prefix=(c)=>{
  prepare(c);
  c.take(...c.m.swap('amiba_5.webp',id));
  const a='trace:1:blue:amiba:3';
  if(order==='repeat-first'){repeat(c,id);end(c);analyze(c,a);}
  else{analyze(c,a);end(c);repeat(c,id);}
  c.cut('four-data');
 };
 cases.push([id+' / '+order+' / autonomous',prefix]);
 cases.push([id+' / '+order+' / earmark income',c=>{prefix(c);slot(c);}]);
}
cases.push(['after preparing cash, normal policy',prepare]);
const result=runCases(root,cases);
writeZ(out,{root,controls,...result});
