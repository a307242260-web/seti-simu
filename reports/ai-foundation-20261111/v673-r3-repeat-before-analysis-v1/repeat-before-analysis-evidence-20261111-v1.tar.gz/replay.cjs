'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
const [r3file,r4file,stockfile,stock4file,out]=process.argv.slice(2),p=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(p,module);
mod.filename=p;mod.paths=Module._nodeModulePaths(path.dirname(p));
const text=fs.readFileSync(p,'utf8'),needle='  return Object.freeze({ createAnalysisPort });';
assert.equal(text.split(needle).length,2);
mod._compile(text.replace(needle,'  return Object.freeze({ createAnalysisPort, forwardIdentity });'),p);mod.loaded=true;require.cache[p]=mod;
const {forwardIdentity}=mod.exports,{open,readZ,writeZ}=require('./controlled-r3');
const third=readZ(r3file),fourth=readZ(r4file),stock=readZ(stockfile),stock4=readZ(stock4file),stats={thirdInputs:0,fourthInputs:0,equivalentInputs:0,stockInputs:0,rows:[]};
function replay(e,a,finish,key){
 const m=open(e);
 try{
  a.forEach(x=>{assert.deepEqual(m.apply(x),x);stats[key]++;});
  assert.deepEqual(m.save(),finish);
 }finally{m.dispose();}
}
for(const r of third.rows)replay(third.root,[...r.prefix,...r.actions.map(a=>a.action)],r.end,'thirdInputs');
for(const r of stock.rows)replay(stock.root,r.prefix,r.settled.state,'stockInputs');
for(const r of [...fourth.results,...stock4.results]){
 assert.equal(r.stop,'terminal');
 replay(r.root,r.actions.map(a=>a.action),r.end,'fourthInputs');
}
for(const r of fourth.results){
 const alt=third.rows.find(a=>a.label===r.name.replace('repeat-first','analysis-first'));
 const a=open(r.root),b=open(alt.settled.state);
 try{
  assert.notDeepEqual(a.save(),b.save());
  for(const x of r.actions){
   assert.equal(forwardIdentity(a.save(),'stable',null),forwardIdentity(b.save(),'stable',null));
   assert.deepEqual(a.menu(),b.menu());
   assert.deepEqual(a.apply(x.action),b.apply(x.action));
   stats.equivalentInputs++;
  }
  assert.equal(forwardIdentity(a.save(),'stable',null),forwardIdentity(b.save(),'stable',null));
  assert.deepEqual(a.state().match.finalScores,b.state().match.finalScores);
  assert.deepEqual(a.save(),r.end);
  stats.rows.push({name:r.name,card:r.card,replayedOtherOrder:r.actions.length,score:r.terminal.totalScore});
 }finally{a.dispose();b.dispose();}
}
console.log(JSON.stringify(stats));writeZ(out,stats);
