'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,short,writeZ}=require('./controlled-r3');
const [input,ledger,out]=process.argv.slice(2),a=readZ(input),historical=readZ(ledger);
const alt=a.rows.find(r=>r.label==='blue-pick-before-electricity');
const official=historical.rows.filter(r=>r.i>=204&&r.i<=209);
const m=open(a.source),seatId='player-white';
const Module=require('node:module'),file=path.resolve('randomizer/game/ai/analysis-port.js');
const code=fs.readFileSync(file,'utf8'),needle='return Object.freeze({ createAnalysisPort });';
assert.equal(code.split(needle).length,2);
const moduleSource=new Module(file,module);moduleSource.filename=file;moduleSource.paths=Module._nodeModulePaths(path.dirname(file));
moduleSource._compile(code.replace(needle,'return Object.freeze({ createAnalysisPort, forwardIdentity });'),file);
const {createAnalysisPort,forwardIdentity}=moduleSource.exports;
const result={};
const diff=(a,b,path=[])=>{
 if(a===b)return[];
 if(!a||!b||typeof a!=='object'||typeof b!=='object')return [{path:path.join('.'),old:a,new:b}];
 return [...new Set([...Object.keys(a),...Object.keys(b)])].flatMap(k=>diff(a[k],b[k],[...path,k]));
};
try{
 const [one,two]=[official.map(r=>r.a),alt.prefix].map(actions=>{
  m.restore(a.source);actions.forEach(m.apply);
  const state=m.save(),menu=m.menu();return{state,menu,identity:forwardIdentity(state,'stable',null)};
 });
 assert.deepEqual(one.menu,two.menu);
 const changes=diff(JSON.parse(one.state.committedState),JSON.parse(two.state.committedState));
 assert(changes.every(d=>d.path.startsWith('players.players.3.dataState.placedTokens.')));
 assert.equal(one.identity,two.identity);
 result.blueOrder={menuExact:true,searchIdentitySame:one.identity===two.identity,changes,standard:one.state,alternative:two.state};
 for(const label of ['swap-b16-keep-amiba7','swap-amiba9-keep-amiba7','use-publicity-keep-amiba7']){
  const row=a.rows.find(x=>x.label===label);m.restore(row.start);
  const p=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
  try{
   p.setResourcePlanning(true);p.setCardPickPlanning(true);p.setDecisionPlanning({scanPlanning:true,finalMarkPlanning:true});
   const n=p.openRoot(),policy=p.resourceSpec(n),chosen=row.actions[0];
   result[label]={initial:short(m),chosen:chosen.action.summary,goal:policy?.plans.filter(g=>g.firstActionId===chosen.action.actionId).map(g=>g.goal),
    first:row.actions.slice(0,9).map(r=>r.action.summary)};
  }finally{p.close();}
 }
}finally{m.dispose();}
writeZ(out,result);
for(const[k,r]of Object.entries(result))console.log(JSON.stringify([k,r.initial??null,r.chosen??null,r.goal??null,r.first??null,r.searchIdentitySame??null,r.changes??null]));
