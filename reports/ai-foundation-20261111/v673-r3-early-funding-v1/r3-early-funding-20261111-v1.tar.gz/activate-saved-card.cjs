'use strict';
const assert=require('node:assert/strict');
const {open,readZ,runCases,writeZ}=require('./controlled-r3');
const [input,out]=process.argv.slice(2),prior=readZ(input);
const labels=['swap-b16-keep-amiba7','use-publicity-keep-amiba7'],results=[];
for(const label of labels){
 const root=prior.rows.find(r=>r.label===label).start,m=open(root),caseInputs=[];
 try{
  const base=[m.act('end_turn')];m.advanceOpponents(base);base.push(m.play('amiba_7.webp'));
  const offers=m.menu().filter(a=>a.family==='choose_card'&&a.target?.source==='public');
  const after=m.save();
  for(const offer of offers){
   m.restore(after);m.apply(offer);
   const bonus=m.menu().filter(a=>a.family==='choose_target'&&a.target?.choiceId?.startsWith('symbol:'));
   if(!bonus.length)caseInputs.push([offer.summary,[...base,offer]]);
   else for(const b of bonus)caseInputs.push([offer.summary+' / '+b.summary,[...base,offer,b]]);
  }
 }finally{m.dispose();}
 assert(caseInputs.length>0);
 const rows=runCases(root,caseInputs.map(([name,actions])=>[label+' / '+name,({m,take})=>take(...actions.map(m.apply))]));
 results.push({label,root,...rows});
}
writeZ(out,results);
