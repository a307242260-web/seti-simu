'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{readZ,open}=require('./controlled-r3');
const [reference,...inputs]=process.argv.slice(2);
const fields=['actionId','value','realization','preparationDebt','complete','roots','lines','unresolved','selectionPlan','candidates','sharedPrefixGraph'];
function normalized(e){
 const c=structuredClone(e);c.committedState=JSON.parse(c.committedState);
 const id=c.session?.session.sessionId;
 if(id){
  c.session.session.undoFrames=[];
  c.session=JSON.parse(JSON.stringify(c.session).replaceAll(id,'@session'));
 }
 return c;
}
for(const input of inputs){
 const [{root,q,cp,regionProof}]=readZ(input),board=path.basename(input).match(/b_(111|32)\.webp/)[0];
 const [before]=readZ(path.join(reference,'closed-r4-income-'+board+'.json.gz'));
 for(const k of fields)assert.deepEqual(q[k],before.q[k],k);
 assert.deepEqual(cp,before.cp);
 assert.equal(regionProof.length,before.q.diagnostics.nativeExecutions-q.diagnostics.nativeExecutions);
 for(const {source,action,target,choices,barrier} of regionProof){
  const m=open(source);
  try{
   m.apply(action);assert.deepEqual(normalized(m.save()),normalized(target));
   assert.deepEqual(m.menu(),choices);
   assert.deepEqual(m.save().session.session.irreversibleBarrier,barrier);
   assert.deepEqual(source.session.session.workingState.meta.rngState,m.save().session.session.workingState.meta.rngState);
  }finally{m.dispose();}
 }
 console.log(JSON.stringify({board,witnesses:regionProof.length,searchGraphExact:true,nativeMenuExact:true,fullEnvelopeAndRngExact:true,changedDisplayStillHidden:true}));
}
