'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
function edit(s,a,b){assert.equal(s.split(a).length,2,a);return s.replace(a,b);}
function load(name,transform){
 const src=path.resolve('randomizer/game',name+'.js'),mod=new Module(src,module);
 mod.filename=src;mod.paths=Module._nodeModulePaths(path.dirname(src));
 assert(!require.cache[src],name);mod._compile(transform(fs.readFileSync(src,'utf8')),src);mod.loaded=true;require.cache[src]=mod;
}
module.exports=mode=>{
 if(mode.includes('scan-quote')){
  load('data/nebula-state',s=>{s=edit(s,`  function getNextReplaceableNebulaToken(state, nebulaId) {
    return listNebulaTokens(state, nebulaId)
      .filter((token) => !getTokenOwnerColor(token))`,`  function getNextReplaceableNebulaToken(state, nebulaId, excluded = null) {
    return listNebulaTokens(state, nebulaId)
      .filter((token) => !getTokenOwnerColor(token) && (!excluded || !excluded.has(token.id)))`);
   if(mode.includes('token-min'))s=edit(s,`    return listNebulaTokens(state, nebulaId)
      .filter((token) => !getTokenOwnerColor(token) && (!excluded || !excluded.has(token.id)))
      .sort((a, b) => a.slotIndex - b.slotIndex || a.index - b.index)[0] || null;`,`    const source=state?.nebulae?.[nebulaId]?.tokens;
    if(!Array.isArray(source))return listNebulaTokens(state,nebulaId)[0]||null;
    let best=null;
    for(const token of source){
      if(getTokenOwnerColor(token)||excluded?.has(token.id))continue;
      if(!Number.isFinite(token?.slotIndex)||!Number.isFinite(token?.index)){
        return listNebulaTokens(state,nebulaId).filter(t=>!getTokenOwnerColor(t)&&(!excluded||!excluded.has(t.id)))
          .sort((a,b)=>a.slotIndex-b.slotIndex||a.index-b.index)[0]||null;
      }
      if(!best||token.slotIndex<best.slotIndex||token.slotIndex===best.slotIndex&&token.index<best.index)best=token;
    }
    return best;`);
   return s;
  });
  load('effects/science-session',s=>edit(s,`      const next = data.getNextReplaceableNebulaToken(nebulaState, nebulaId);
      const tokens = data.listNebulaTokens(nebulaState, nebulaId);
      return next || tokens.length`,`      return data.listNebulaTokens(nebulaState, nebulaId).length`));
  load('ai/probe-capital',s=>{
   s=edit(s,`            const id = action.target.nebulaId, bucket = root.data.nebulae[id];
            const available = { ...root.data, nebulae: { ...root.data.nebulae,
              [id]: { ...bucket, tokens: bucket.tokens.filter(t => !usedTokens.has(t.id)) } } };
            const token = data.getNextReplaceableNebulaToken(available, id);`,`            const id = action.target.nebulaId;
            const token = data.getNextReplaceableNebulaToken(root.data, id, usedTokens);`);
   s=edit(s,`      const id=a.target.nebulaId,bucket=root.data.nebulae[id];
      const available={...root.data,nebulae:{...root.data.nebulae,[id]:{...bucket,tokens:bucket.tokens.filter(t=>!usedTokens.has(t.id))}}};
      return !!data.getNextReplaceableNebulaToken(available,id);`,`      return !!data.getNextReplaceableNebulaToken(root.data,a.target.nebulaId,usedTokens);`);
   if(mode.includes('funding-min')){
    const i=s.indexOf('  function funding('),j=s.indexOf('  function pendingFinalMarkOption(',i);assert(i>=0&&j>i);
    let f=s.slice(i,j);
    f=edit(f,'    const choices = [];','    let best = null;');
    f=edit(f,`      choices.push({ spend, energyPurchases: y, creditPurchases: x,
        value: spend.credits * weights.credits + spend.energy * weights.energy });`,`      const value=spend.credits*weights.credits+spend.energy*weights.energy;
      if(!best||value<best.value||value===best.value&&y+x<best.energyPurchases+best.creditPurchases)
        best={spend,energyPurchases:y,creditPurchases:x,value};`);
    f=edit(f,`    choices.sort((a, b) => a.value - b.value || a.energyPurchases + a.creditPurchases - b.energyPurchases - b.creditPurchases);
    return choices[0] || null;`,`    return best;`);
    s=s.slice(0,i)+f+s.slice(j);
   }
   return s;
  });
 }
 if(mode.includes('card-print')){
  load('ai/card-pick-planning',s=>{
   const a='  function facts(card){';
   s=edit(s,a,`  const printedFacts=new WeakMap(),immutableCardFacts=new WeakMap();
  function facts(card){
    const frozen=Object.isFrozen(card)&&demand.immutableCapitalInput(card);
    if(frozen&&immutableCardFacts.has(card))return immutableCardFacts.get(card);`);
   s=edit(s,`    let score=0,hasPlay=false,certain=true,preparesIncome=false;
    for(const effect of model?.playEffects||[]){`,`    let printed=model&&printedFacts.get(model);
    if(!printed){
      let score=0,hasPlay=false,certain=true,preparesIncome=false;
      for(const effect of model?.playEffects||[]){`);
   s=edit(s,`    const net=hasPlay&&certain?score-Object.values(cost).reduce((n,v)=>n+v,0)-1:0;
    return{id:card.id,cardId:card.cardId,price:card.price,income:cards.getIncomeCodeForCard(card),
      move:move?.movementPoints||0,data:corner?.dataCount||0,net,cost,model,hasPlay,preparesIncome};`,`      printed={score,hasPlay,certain,preparesIncome};
      if(model)printedFacts.set(model,printed);
    }
    const {score,hasPlay,certain,preparesIncome}=printed;
    const net=hasPlay&&certain?score-Object.values(cost).reduce((n,v)=>n+v,0)-1:0;
    const value={id:card.id,cardId:card.cardId,price:card.price,income:cards.getIncomeCodeForCard(card),
      move:move?.movementPoints||0,data:corner?.dataCount||0,net,cost,model,hasPlay,preparesIncome};
    if(frozen)immutableCardFacts.set(card,value);
    return value;`);
   return edit(s,`      const p=state.players.players.find(p=>p.id===seatId),offers=state.cards.publicCards.filter(Boolean);
      for(const goal of goals(state,seatId,endpoints)){`,`      const p=state.players.players.find(p=>p.id===seatId),offers=state.cards.publicCards.filter(Boolean);
      if(!offers.length)return null;
      const hand=p.hand.map(facts);
      for(const goal of goals(state,seatId,endpoints)){`).replaceAll('const choices=p.hand.map(facts).filter(c=>c.id&&c.id!==goal.protectedCardId)','const choices=hand.filter(c=>c.id&&c.id!==goal.protectedCardId)').replaceAll('remaining=p.hand.map(facts).filter(c=>!discarded.some(d=>d.id===c.id))','remaining=hand.filter(c=>!discarded.some(d=>d.id===c.id))');
  });
 }
};
