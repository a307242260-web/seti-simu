'use strict';
const fs=require('node:fs'),z=require('node:zlib'),c=require('node:crypto');
const fields=['schemaVersion','complete','actionId','selectionPlan','planEvidence','value','realization','preparationDebt','stopReason','scope','roots','lines','unresolved','sharedPrefixGraph','candidates'];
const count=(items,key)=>Object.fromEntries([...items.reduce((a,b)=>{const k=key(b);a.set(k,(a.get(k)||0)+1);return a;},new Map())].sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0])));
for(const file of process.argv.slice(2)){
 const {q,cp}=JSON.parse(z.gunzipSync(fs.readFileSync(file)))[0],edges=q.lines.flatMap(line=>line.edges);
 console.log(JSON.stringify({file,native:q.diagnostics.nativeExecutions,logical:q.diagnostics.logicalResourceInputs,
  fixedTails:q.diagnostics.turnTailProofs,provedTailInputs:q.diagnostics.provedTurnTailInputs,
  resourceQueries:q.analysis.resourceQueryMisses,resourceCatalogs:q.analysis.goalCatalogMisses,
  valueQuotes:q.diagnostics.valueEvaluations,rankingHits:q.analysis.cardPick.rankingCacheHitsThisRoot,
  fixedGraph:count(q.sharedPrefixGraph.edges,e=>e.actionId.split(':')[0]),
  mainGraph:count(edges,e=>e.actionId.split(':')[0]),
  digest:c.createHash('sha256').update(JSON.stringify([fields.map(k=>q[k]),cp])).digest('hex')}));
}
