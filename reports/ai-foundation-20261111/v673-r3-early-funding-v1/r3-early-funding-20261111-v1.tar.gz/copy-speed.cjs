'use strict';
const assert=require('node:assert/strict');
function edit(s,a,b){assert.equal(s.split(a).length,2,a);return s.replace(a,b);}
exports.runtime=(s,mode)=>{
 if(mode.includes('menu-copy')){
  s=edit(s,'      snapshot.choices = clone(choices);','      snapshot.choices = trustedIsolatedOwnership ? cloneTrustedCheckpoint(choices) : clone(choices);');
 }
 return s;
};
exports.demand=(s,mode)=>{
 if(mode.includes('freeze-loop')){
  s=edit(s,'    if(!Object.values(value).every(immutableCapitalInput))return false;',
    '    for(const key of Object.keys(value))if(!immutableCapitalInput(value[key]))return false;');
 }
 if(mode.includes('project-copy')){
  s=edit(s,'    const q=structuredClone(p);','    const q=copyForkData(p);');
 }
 return s;
};
exports.local=(s,mode)=>{
 if(mode.includes('quote-copy')){
  const a=' function dataPreviewPlayer(p){return{...p,resources:{...p.resources},income:{...p.income},hand:[...p.hand],dataState:structuredClone(p.dataState)};}';
  s=edit(s,a,a.replace('structuredClone(p.dataState)','{...p.dataState,poolTokens:[...p.dataState.poolTokens],placedTokens:[...p.dataState.placedTokens]}'));
 }
 return s;
};
const demandBefore=exports.demand;
exports.demand=(s,mode)=>{
 s=demandBefore(s,mode);
 if(!mode.includes('no-deficit-payment'))return s;
 return edit(s,`    for(const action of actions.filter(isPreparation)){
      if(action.family==='place_data'||action.family==='card_corner'&&(action.payload.kind!=='resource'||protectedCard({id:action.target.cardInstanceId},goal)))continue;
      const discarded=`,`    const actor=owner(state,seatId);
    for(const action of actions.filter(isPreparation)){
      if(action.family==='place_data'||action.family==='card_corner'&&(action.payload.kind!=='resource'||protectedCard({id:action.target.cardInstanceId},goal)))continue;
      // The preparation must strictly shrink a current deficit. Discarding
      // cards cannot add movement points and these pure previews do not
      // move a probe, fire an observer, or advance a computer/blue slot.
      if(action.family==='card_corner'){
        const card=actor.hand.find(c=>c.id===action.target.cardInstanceId),reward=card&&cards.getDiscardActionRewardForCard(card);
        const multiplier=action.payload.multiplier||1;
        if(reward&&multiplier>0&&!((before.credits&&reward.gain.credits>0)
          ||(before.energy&&reward.gain.energy>0)||(before.publicity&&reward.gain.publicity>0)
          ||(before.data&&(reward.dataCount>0||reward.gain.availableData>0))))continue;
      }else{
        const {cost,gain}=action.payload;
        if(cost&&gain&&Object.values(cost).every(v=>v>=0)
          &&!((before.credits&&gain.credits>0)||(before.energy&&gain.energy>0)
            ||(before.publicity&&gain.publicity>0)||(before.data&&gain.availableData>0)))continue;
      }
      const discarded=`);
};
