'use strict';
const assert=require('node:assert/strict');
const {readZ,writeZ,short,runCases,open}=require('./controlled-r3');
const [input,output]=process.argv.slice(2),x=readZ(input);
const root=x.rows.find(r=>r.i===243).before,m=open(root),cases=[];
try{
 const score=m.automatic();console.log(JSON.stringify({root:{actual:score.a.summary,n:score.n,ms:score.ms,complete:score.complete,roots:score.roots}}));
 assert(score.complete&&score.n<=256&&score.ms<=600);
 for(const a of m.menu()){
  m.restore(root);m.apply(a);
  const follow=m.menu().filter(b=>b.family==='choose_card'&&b.target?.kind==='residual-domain');
  if(follow.length)for(const b of follow)cases.push([a.summary+' / '+b.summary,({m,take})=>take(m.apply(a),m.apply(b))]);
  else cases.push([a.summary,({m,take})=>take(m.apply(a))]);
  m.restore(root);
 }
}finally{m.dispose();}
const result=runCases(root,cases);assert.equal(result.failures.length,0);
writeZ(output,{root,source:'existing standard decision #243; fixed only the public trace or its explicit card choice; remaining decisions bound by 256/600',...result});
