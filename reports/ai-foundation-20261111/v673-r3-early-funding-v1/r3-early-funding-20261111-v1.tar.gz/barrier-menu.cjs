'use strict';
const assert=require('node:assert/strict');
module.exports=(s,mode)=>{
 if(!mode.includes('barrier-menu'))return s;
 function sub(a,b){assert.equal(s.split(a).length,2,a);s=s.replace(a,b);}
 sub(`        if (prepared) restoreEnvelope(envelope);
        const knownTail=knownPostdrawTailView`,`        // Pending views use the exact decision menu already carried by
        // the proof. Only an idle view enumerates against the loaded fork.
        if (prepared&&inspection.phase==="idle") restoreEnvelope(envelope);
        const knownTail=knownPostdrawTailView`);
 const start=s.indexOf('    function knownPostdrawDataView('),end=s.indexOf('    function knownPostdrawTailView(',start);
 assert(start>=0&&end>start);
 let span=s.slice(start,end);
 const a=`      const actions=knownPostMainActions(envelope,legalActions(fork.composition||fork,inspection),true);
      if(!actions.length)return null;
      const pending=envelope.session?.session;
      if(pending){
        if(inspection.phase!=="awaiting_input"||pending.queue.length!==1
          ||pending.queue[0].type!==scienceSession.EFFECT_TYPES.PLACE_DATA
          ||pending.journal?.actions?.[0]?.action?.family!=="place_data"
          ||!actions.every(a=>a.family==="choose_target"&&["computer","blueBonus"].includes(a.target?.target)))return null;
        return createNode(envelope,null,actions,"decision",barrier);
      }
      if(inspection.phase!=="idle")return null;`;
 const b=`      const pending=envelope.session?.session;
      if(pending?inspection.phase!=="awaiting_input"||pending.queue.length!==1
        ||pending.queue[0].type!==scienceSession.EFFECT_TYPES.PLACE_DATA
        ||pending.journal?.actions?.[0]?.action?.family!=="place_data":inspection.phase!=="idle")return null;
      const actions=knownPostMainActions(envelope,legalActions(fork.composition||fork,inspection),true);
      if(!actions.length)return null;
      if(pending){
        if(!actions.every(a=>a.family==="choose_target"&&["computer","blueBonus"].includes(a.target?.target)))return null;
        return createNode(envelope,null,actions,"decision",barrier);
      }`;
 assert.equal(span.split(a).length,2);span=span.replace(a,b);
 return s.slice(0,start)+span+s.slice(end);
};
