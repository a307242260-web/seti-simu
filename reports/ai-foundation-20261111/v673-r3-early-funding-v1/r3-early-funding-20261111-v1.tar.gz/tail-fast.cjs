'use strict';
const assert=require('node:assert/strict');
module.exports=(s,mode)=>{
 function sub(a,b){assert.equal(s.split(a).length,2,a);s=s.replace(a,b);}
 if(mode.includes('turn-copy'))sub(
  '    function previewTurn(state, options = {}) {\n      return turnFlow.advanceTurnAfterPlayerAction({ ...state, turn: structuredClone(state.turn) }, seatId, options);\n    }',
  `    const normalTurnPreview=new WeakMap();
    function previewTurn(state, options) {
      const t=state.turn,reusable=options===undefined&&Object.isFrozen(t)&&resourceDemand.immutableCapitalInput(t);
      if(reusable&&normalTurnPreview.has(t))return normalTurnPreview.get(t);
      const turn=Array.isArray(t.passedPlayerIds)&&Array.isArray(t.completedTurnPlayerIds)&&t.visitedPlanetsByPlayerId
        ?{...t,passedPlayerIds:[...t.passedPlayerIds],completedTurnPlayerIds:[...t.completedTurnPlayerIds],
          visitedPlanetsByPlayerId:{...t.visitedPlanetsByPlayerId}}:structuredClone(t);
      const result=turnFlow.advanceTurnAfterPlayerAction({...state,turn},seatId,options);
      if(reusable)normalTurnPreview.set(t,freeze(result));
      return result;
    }`);
 if(mode.includes('card-screen'))sub('      if (envelopeCardSpecs.has(envelope)) return envelopeCardSpecs.get(envelope);\n      const state=readPlanningState({envelope,informationBarrier:barrier});\n      const session=envelope.session?.session;\n      const policySession=',
  `      if (envelopeCardSpecs.has(envelope)) return envelopeCardSpecs.get(envelope);
      const session=envelope.session?.session, kind=session?.queue?.[0]?.type;
      const kinds=scienceSession.EFFECT_TYPES;
      if(status==="stable"&&!actions.some(a=>cardPickPlanningApi.isTrade(a)||a.family==="industry"&&a.target?.abilityId==="deepspace_swap_cards")
        ||status==="decision"&&(kind===kinds.ALIEN_TRACE||kind===kinds.PLACE_DATA||kind===kinds.SCAN_STEP||kind===kinds.SCAN_ACTION_4
          ||kind===probeTurnSession.EFFECT_TYPES.MOVE_PAYMENT)&&actions.every(a=>!cardPickPlanningApi.isOffer(a))){
        envelopeCardSpecs.set(envelope,null);return null;
      }
      const state=readPlanningState({envelope,informationBarrier:barrier});
      const policySession=`);
 if(mode.includes('data-screen'))sub(
  '      const requirements=owner?.mainActionCompleted?{bluePlacements:data.listBluePlacementRequirements(owner)}:resourceQuery(state);\n      const result = freeze(resourceDemand.catalog({state,seatId,requirements,actions}));',
  `      const noData=owner?.mainActionCompleted&&state.turn.roundNumber===4&&owner.resources.availableData===0
        &&owner.hand.every(c=>!(cards.getDiscardActionRewardForCard(c)?.dataCount>0))
        &&!actions.some(a=>a.family==="industry"&&a.target?.abilityId==="mission_publicity_pick_income");
      const requirements=noData?null:owner?.mainActionCompleted?{bluePlacements:data.listBluePlacementRequirements(owner)}:resourceQuery(state);
      const result = freeze(noData?[]:resourceDemand.catalog({state,seatId,requirements,actions}));`);
 return s;
};
