'use strict';
const assert=require('node:assert/strict'),{runCases,readZ,writeZ}=require('./controlled-r3');
const [input,out]=process.argv.slice(2),prior=readZ(input),results=[];
for(const label of ['swap-b16-keep-amiba7','swap-amiba9-keep-amiba7']){
 const root=prior.rows.find(r=>r.label===label).start;
 function prep({m,take,act}){
  take(m.corner('amiba_7.webp'));act('place_data');act('choose_target',a=>a.target.blueSlot===2);take(m.pick('dlc_20.png'));
  act('end_turn');const a=[];m.advanceOpponents(a);take(...a);
 }
 const scan=(c,pink)=>{
  c.act('scan');c.act('choose_target',a=>a.target.nebulaId==='sector-3-a');
  c.act('choose_card',a=>a.target.nebulaId==='sector-3-a'&&a.summary.includes('dlc_24'));
  if(pink){c.act('choose_target',a=>a.target.choiceId==='trace:1:pink:amiba:3');c.act('choose_card',a=>a.target.source==='display');}
 };
 const controls=runCases(root,[
  [label+' / keep DLC24 for scanning',prep],
  [label+' / same scan location',c=>{prep(c);scan(c,false);}],
  [label+' / same scan location and pink trace',c=>{prep(c);scan(c,true);}],
 ]);
 results.push({root,label,...controls});
}
writeZ(out,results);
