'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
const transform=s=>{
 const a='  const scoringBoard = copyValueSlice(state.finalScoring);';
 assert.equal(s.split(a).length,2,a);
 return s.replace(a,`  const board = state.finalScoring;
  // Native scoring normalizes tileVariants in place. On the canonical
  // four-tile board it reads the existing marks and thresholds unchanged.
  // Keep a private variant map; the public observation still copies marks.
  const canonical = valueOnly && Array.isArray(board?.thresholds) && board.tileVariants
    && Object.keys(board.tiles || {}).length === 4 && ["a", "b", "c", "d"].every((id) =>
      board.tiles[id]?.id === id && Array.isArray(board.tiles[id].marks)
      && [1, 2].includes(board.tileVariants[id]));
  const scoringBoard = canonical ? { ...board, tileVariants: { ...board.tileVariants } } : copyValueSlice(board);`);
};
module.exports=mode=>{
 if(!mode.includes('score-slice'))return;
 const file=path.resolve('randomizer/app/rule-observation.js'),m=new Module(file,module);m.filename=file;m.paths=Module._nodeModulePaths(path.dirname(file));
 assert(!require.cache[file]);m._compile(transform(fs.readFileSync(file,'utf8')),file);m.loaded=true;require.cache[file]=m;
};
module.exports.transform=transform;
