'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const [dir,prev]=process.argv.slice(2);
const read=file=>JSON.parse(z.gunzipSync(fs.readFileSync(file)))[0];
const fields=['schemaVersion','actionId','value','realization','preparationDebt','complete','roots','lines','unresolved','selectionPlan','candidates','sharedPrefixGraph'];
for(const b of ['b_111.webp','b_32.webp']){
 const base=read(path.join(prev,'closed-r4-income-'+b+'.json.gz'));
 const rows=[];
 for(const variant of ['admit','cards-base','cards-region-draw','aliens-base','aliens-region-draw','barrier-menu','region-draw-barrier-menu']){
  const x=read(path.join(dir,variant+'-'+b+'.json.gz'));
  for(const k of fields)assert.deepEqual(x.q[k],base.q[k],variant+': '+k);
  const sameWorld=variant.includes('-region-draw')&&!variant.includes('barrier-menu')
   ?read(path.join(dir,variant.replace('-region-draw','-base')+'-'+b+'.json.gz'))
   :variant.endsWith('-base')?x:base;
  assert.equal(crypto.createHash('sha256').update(JSON.stringify(x.cp)).digest('hex'),
   crypto.createHash('sha256').update(JSON.stringify(sameWorld.cp)).digest('hex'),variant+' exact native certificate in its own world');
  const publicPlan=cp=>cp.plan.rows.map(({key,...row})=>row);
  assert.deepEqual(publicPlan(x.cp),publicPlan(base.cp),variant+' public plan/action descriptors across worlds');
  const selected=variant==='admit'||variant.includes('region-draw');
  assert.equal(x.q.diagnostics.nativeExecutions,base.q.diagnostics.nativeExecutions-(selected?(b.includes('111')?14:16):0));
  rows.push({variant,elapsed:x.q.rootAndSearchMilliseconds,n:x.q.diagnostics.nativeExecutions,
   digest:crypto.createHash('sha256').update(JSON.stringify([fields.map(k=>x.q[k]),publicPlan(x.cp)])).digest('hex')});
 }
 console.log(JSON.stringify({board:b,rows}));
}
