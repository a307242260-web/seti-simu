'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
function edit(s,a,b){assert.equal(s.split(a).length,2,a);return s.replace(a,b);}
function load(name,transform){
 const file=path.resolve('randomizer/game',name+'.js'),mod=new Module(file,module);
 mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
 assert(!require.cache[file],name);mod._compile(transform(fs.readFileSync(file,'utf8')),file);mod.loaded=true;require.cache[file]=mod;
}
module.exports=mode=>{
 if(!mode.includes('lazy-pick')&&!mode.includes('goal-booleans')&&!mode.includes('ready-last')&&!mode.includes('facts-print'))return;
 load('ai/card-pick-planning',s=>{
   if(mode.includes('lazy-pick'))s=edit(s,`      const availableGoals=!tradePending?goals(purposeState,seatId,()=>endpoints(purposeState)):[];
      const companyIntent=companySwap?swapIntent(state,seatId,endpoints,outgoing,true):null;
      const inferred=availableGoals.find(g=>g.kind==='income'||g.kind==='move'&&state.cards.publicCards.some(c=>c&&facts(c).move>=g.amount)||g.kind==='data'&&state.cards.publicCards.some(c=>c&&facts(c).data>=g.amount)||g.kind==='exceptional-card');
      const goal=committed?.goal||companyIntent?.goal||(!tradePending&&!companySwap&&(queuedIncomeGoal(session,seatId,state)||readyIncomeGoal(state,seatId)))||inferred||{kind:tradePending?'committed-pick':'free-reward',id:tradePending?\`committed:\${pending.tradeId}\`:'free-card-reward'};`,
`      const companyIntent=companySwap?swapIntent(state,seatId,endpoints,outgoing,true):null;
      // An explicit Native payment or income purpose takes precedence over
      // inference; do not enumerate unrelated move or card purposes.
      const goal=committed?.goal||companyIntent?.goal
        ||(!tradePending&&!companySwap&&(queuedIncomeGoal(session,seatId,state)||readyIncomeGoal(state,seatId)))
        ||(!tradePending&&goals(purposeState,seatId,()=>endpoints(purposeState)).find(g=>g.kind==='income'
          ||g.kind==='move'&&state.cards.publicCards.some(c=>c&&facts(c).move>=g.amount)
          ||g.kind==='data'&&state.cards.publicCards.some(c=>c&&facts(c).data>=g.amount)||g.kind==='exceptional-card'))
        ||{kind:tradePending?'committed-pick':'free-reward',id:tradePending?\`committed:\${pending.tradeId}\`:'free-card-reward'};`);
   if(mode.includes('goal-booleans'))s=edit(s,`      if(!tech.listTakeableTiles(state.tech,p.techState).length&&!publicityScoring&&p.hand.length<4)`,`      if(!publicityScoring&&p.hand.length<4&&!tech.listTakeableTiles(state.tech,p.techState).length)`);
   if(mode.includes('ready-last')){
    s=edit(s,"      if(!card||placed>=4||p.resources.availableData<4-placed||demand.cardOpportunityCost(state,seatId,card)<=0)return null;",
      "      if(!card||placed>=4||p.resources.availableData<4-placed)return null;");
    s=edit(s,"      }))return null;\n      return{kind:'ready-income'", "      })||demand.cardOpportunityCost(state,seatId,card)<=0)return null;\n      return{kind:'ready-income'");
   }
   if(mode.includes('facts-print')){
    s=edit(s,'  function facts(card){',`  const printedValues=new WeakMap();
  function facts(card){`);
    s=edit(s,`    let score=0,hasPlay=false,certain=true,preparesIncome=false;
    for(const effect of model?.playEffects||[]){`,`    let print=model&&printedValues.get(model);
    if(!print){
      let score=0,hasPlay=false,certain=true,preparesIncome=false;
      for(const effect of model?.playEffects||[]){`);
    s=edit(s,`    const net=hasPlay&&certain?score-Object.values(cost).reduce((n,v)=>n+v,0)-1:0;`,`      print={score,hasPlay,certain,preparesIncome};
      if(model)printedValues.set(model,print);
    }
    const {score,hasPlay,certain,preparesIncome}=print;
    const net=hasPlay&&certain?score-Object.values(cost).reduce((n,v)=>n+v,0)-1:0;`);
   }
   return s;
 });
};
