'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
module.exports=mode=>{
 if(!mode.includes('shared-projection'))return;
 const src=path.resolve('randomizer/app/rule-observation.js'),m=new Module(src,module);m.filename=src;m.paths=Module._nodeModulePaths(path.dirname(src));
 assert(!require.cache[src]);
 let s=fs.readFileSync(src,'utf8');
 const sub=(a,b)=>{assert.equal(s.split(a).length,2,a);s=s.replace(a,b);};
 sub('function buildRuleObservation(state, seed, viewerPlayerId, legalActions = [], options = {}) {',`const valueGeometryOwned = new WeakSet();
function immutableValueGeometry(node, visiting) {
  if(node===null||typeof node!=="object")return node===null||["boolean","number","string","undefined"].includes(typeof node);
  if(valueGeometryOwned.has(node))return true;
  if(!Object.isFrozen(node)||visiting?.has(node))return false;
  const array=Array.isArray(node),prototype=Object.getPrototypeOf(node);
  if(array?prototype!==Array.prototype:prototype!==Object.prototype&&prototype!==null)return false;
  visiting??=new Set();visiting.add(node);
  for(const key of Reflect.ownKeys(node)){
    const descriptor=Object.getOwnPropertyDescriptor(node,key);
    if(typeof key!=="string"||!Object.hasOwn(descriptor,"value")||!immutableValueGeometry(descriptor.value,visiting)){
      visiting.delete(node);return false;
    }
  }
  visiting.delete(node);valueGeometryOwned.add(node);return true;
}
function buildRuleObservation(state, seed, viewerPlayerId, legalActions = [], options = {}) {`);
 sub('  const scoringBoard = copyValueSlice(state.finalScoring);',`  const scoringBoard = copyValueSlice(state.finalScoring);
  // Value projection is read-only. Share only fully immutable ordinary
  // public geometry; the score normalizer above still gets a private copy.
  const geometry=value=>valueOnly&&immutableValueGeometry(value)?value:copyValueSlice(value);`);
 sub('rockets: copyValueSlice(state.pieces?.rockets || []),','rockets: geometry(state.pieces?.rockets || []),');
 for(const k of ['planets','data','solarSystem'])sub(k+': copyValueSlice(state.'+k+' || {}),',k+': geometry(state.'+k+' || {}),');
 m._compile(s,src);m.loaded=true;require.cache[src]=m;
};
