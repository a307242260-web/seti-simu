'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
function sub(s,a,b){assert.equal(s.split(a).length,2,a);return s.replace(a,b);}
function load(name,edit){
 const src=path.resolve('randomizer/game',name+'.js'),mod=new Module(src,module);mod.filename=src;mod.paths=Module._nodeModulePaths(path.dirname(src));
 assert(!require.cache[src],name);mod._compile(edit(fs.readFileSync(src,'utf8')),src);mod.loaded=true;require.cache[src]=mod;
}
module.exports=function(mode){
 if(mode.includes('move-geometry')){
  load('abilities/rocket',s=>{
   const begin=s.indexOf('  function listMoveRequirements('),end=s.indexOf('  function resolveProvidedMovePoints(',begin);
   assert(begin>=0&&end>begin);
   return s.slice(0,begin)+`  function listMoveRequirements(context, player, rocketId, options = {}) {
    const allowed = MOVE_DIRECTIONS.filter(direction=>rockets.canMoveRocket?.(context.pieces,
      rocketId,direction.deltaX,direction.deltaY)?.ok);
    if(!allowed.length)return [];
    const rocket=context.pieces.rockets.find(item=>item.id===rocketId);
    // The cost is to leave this rocket's current cell; the destination
    // determines legality but never the fee for this particular step.
    const requiredMovePoints=getRequiredMovePointsFromCoordinate(context,player,rockets.getRocketSectorCoordinate(rocket),options);
    return allowed.map(direction=>({...direction,requiredMovePoints}));
  }

`+s.slice(end);
  });
 }
 if(mode.includes('mission-memo')){
  load('ai/resource-demand',s=>{
   const anchor='  function planningCapital(state,p){';
   s=sub(s,anchor,`  const finalMissions=new WeakMap();
  function finalRoundMission(state,p){
    const cacheable=Object.isFrozen(state)&&Object.isFrozen(p)&&immutableCapitalInput(state)&&immutableCapitalInput(p);
    let entries=cacheable?finalMissions.get(state):null;
    if(entries?.has(p))return entries.get(p);
    const quote=probeCapital.prepareFinalRoundSwapMission(state,p);
    let ready=false,value;
    const entry={...quote,value(){if(!ready){value=quote.quote(p.hand,state.cards.publicCards);ready=true;}return value;}};
    if(cacheable){
      if(!entries){entries=new WeakMap();finalMissions.set(state,entries);}
      entries.set(p,entry);
    }
    return entry;
  }
`+anchor);
   s=s.replaceAll('const mission=probeCapital.prepareFinalRoundSwapMission(state,p);','const mission=finalRoundMission(state,p);');
   s=sub(s,'      return mission.quote(p.hand,state.cards.publicCards);','      return mission.value();');
   s=sub(s,'const before=knownSourceCapital??mission.quote(p.hand,publicCards);','const before=knownSourceCapital??mission.value();');
   if(mode.includes('wallet-memo')){
    s=sub(s,'  function planningCapital(state,p){',`  const finalWallets=new WeakMap();
  function finalWalletQuote(state,p){
    if(!Object.isFrozen(state)||!immutableCapitalInput(state)||Object.isFrozen(p))return finalRoundMission(state,p).value();
    let entries=finalWallets.get(state);
    // The formal round-four mission reads exactly these actor fields; the
    // state reference covers the public route and all other inputs. A quote
    // never reuses an unfinished plan or a Native successor.
    const key=JSON.stringify([p.id,p.color,p.passCompletionPending,p.resources,p.income,p.techState,p.reservedCards,p.hand]);
    if(entries?.has(key))return entries.get(key);
    const value=finalRoundMission(state,p).value();
    if(!entries){entries=new Map();finalWallets.set(state,entries);}
    if(entries.size>=32)entries.delete(entries.keys().next().value);
    entries.set(key,value);
    return value;
  }
  function planningCapital(state,p){`);
    s=sub(s,'      const mission=finalRoundMission(state,p);\n      return mission.value();','      return finalWalletQuote(state,p);');
   }
   s=require('./copy-speed.cjs').demand(s,mode);
   s=require('./closed-income.cjs')(s,mode);
   if(mode.includes('count-prep-projections'))s=sub(s,'      if(!discarded)continue;const after=project(state,seatId,action,discarded);',
      '      if(!discarded)continue;globalThis.preparationProjections=(globalThis.preparationProjections||0)+1;const after=project(state,seatId,action,discarded);');
   return s;
  });
 }
 if(mode.includes('runtime-copy')){
  load('effects/session-runtime',s=>{
   // Non-trusted runtimes keep the existing generic structured clone.
   const a='  function normalizeResultArray(result, key, effect) {';
   s=sub(s,a,'  function normalizeResultArray(result, key, effect, session) {');
   s=sub(s,'    return clone(result[key]);','    return (sessionCopies.get(session)||clone)(result[key]);');
   s=sub(s,'  function normalizeEffect(rawEffect, session, group, index) {','  const sessionCopies=new WeakMap();\n  function normalizeEffect(rawEffect, session, group, index) {');
   s=sub(s,'      payload: clone(rawEffect.payload || {}),\n      source: clone(rawEffect.source || null),','      payload: (sessionCopies.get(session)||clone)(rawEffect.payload || {}),\n      source: (sessionCopies.get(session)||clone)(rawEffect.source || null),');
   for(const a of ['events','history','rng','logs']){
    const exp=new RegExp('normalizeResultArray\\(result, "'+a+'", effect\\)','g');s=s.replace(exp,'normalizeResultArray(result, "'+a+'", effect, session)');
   }
   s=sub(s,'      return {\n        schemaVersion: SCHEMA_VERSION,\n        sessionId,','      const session={\n        schemaVersion: SCHEMA_VERSION,\n        sessionId,');
   s=sub(s,'        commitResult: null,\n      };','        commitResult: null,\n      };\n      if(trustedIsolatedOwnership)sessionCopies.set(session,cloneTrustedCheckpoint);\n      return session;');
   s=sub(s,'      return { ok: true, session: restored };','      if(trustedIsolatedOwnership)sessionCopies.set(restored,cloneTrustedCheckpoint);\n      return { ok: true, session: restored };');
   return require('./copy-speed.cjs').runtime(s,mode);
  });
 }
 if(mode.includes('move-menu')){
  load('effects/probe-turn-session',s=>{
   s=sub(s,'        const directionOrder = new Map(', '        const budget=Number(player.resources?.energy || 0)+(player.hand || []).filter(isMovePaymentCard).length;\n        const directionOrder = new Map(');
   s=sub(s,'String(left.rocketId).localeCompare(String(right.rocketId), undefined, { numeric: true })', '(left.rocketId===right.rocketId?0:String(left.rocketId).localeCompare(String(right.rocketId), undefined, { numeric: true }))');
   s=sub(s,'Number(player.resources?.energy || 0)\n            + (player.hand || []).filter(isMovePaymentCard).length\n            >= move.requiredMovePoints','budget >= move.requiredMovePoints');
   return s;
  });
 }
 if(mode.includes('composition-copy')){
  load('rule-composition',s=>{
   s=sub(s,'    function executeRegisteredAction(',`    const copyInput=options.allowTrustedForkLifecycle===true?stateStoreApi.copyForkData:clone;
    function executeRegisteredAction(`);
   s=sub(s,'() => actionRegistry.execute(workingContext, clone(action)),','() => actionRegistry.execute(workingContext, copyInput(action)),');
   s=sub(s,'      const clonedResult = clone(result);','      const clonedResult = copyInput(result);');
   s=sub(s,'runtime.resolveDecision(activeSession, clone(submission))','runtime.resolveDecision(activeSession, copyInput(submission))');
   if(mode.includes('mask-copy'))s=require('./mask-copy.cjs').composition(s);
   s=sub(s,'() => actionRegistry.enumerate(workingContext, clone(request)),','() => actionRegistry.enumerate(workingContext, copyInput(request)),');
   return s;
  });
 }
};
