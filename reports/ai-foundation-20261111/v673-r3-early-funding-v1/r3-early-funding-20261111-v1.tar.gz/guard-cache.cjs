'use strict';
const assert=require('node:assert/strict');
module.exports=(s,mode)=>{
 if(!mode.includes('inert-card-cache'))return s;
 const start=s.indexOf('    function checkTradeInertReservations('),end=s.indexOf('    function hasPostMainInertReservations(',start);
 assert(start>=0&&end>start);
 let block=s.slice(start,end);
 const sub=(a,b)=>{assert.equal(block.split(a).length,2,a);block=block.replace(a,b);};
 sub('    function checkTradeInertReservations(state, allowAmiba) {',`    const inertTradeCards=new WeakMap();
    function checkTradeInertReservations(state, allowAmiba) {`);
 sub(`      return state.players.players.every(player => player.reservedCards.every(card => {
        const model = cardEffects.getCardModel(card);`,`      return state.players.players.every(player => {
        const own=player.id===seatId,key=Number(allowAmiba)+2*Number(own);
        return player.reservedCards.every(card=>{
          const memoizable=Object.isFrozen(card)&&resourceDemand.immutableCapitalInput(card);
          let answers=memoizable?inertTradeCards.get(card):null;
          if(answers?.[key]!==undefined)return answers[key];
          const answer=checkTradeCard(card,own,allowAmiba,fields);
          if(memoizable){
            if(!answers){answers=[];inertTradeCards.set(card,answers);}
            answers[key]=answer;
          }
          return answer;
        });
      });
    }
    function checkTradeCard(card,own,allowAmiba,fields){
        const model = cardEffects.getCardModel(card);`);
 sub('        if (player.id !== seatId) return true;','        if (!own) return true;');
 sub('      }));\n    }','    }');
 return s.slice(0,start)+block+s.slice(end);
};
