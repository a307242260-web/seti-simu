'use strict';
const assert=require('node:assert/strict'),{open,readZ}=require('./controlled-r3');
let complete=0,infeasible=0,replayed=0,maxInputs=0,maxTime=0;
for(const file of process.argv.slice(2)){
 const source=readZ(file);
 for(const group of Array.isArray(source)?source:[source]){
  const root=group.source??group.root,m=open(root);
  try{
   for(const row of group.rows){
    assert.equal(row.stop,'r4-first-white-main');
    assert(row.settled?.state);
    m.restore(root);
    row.prefix.forEach(m.apply);
    assert.deepEqual(m.save(),row.start);
    for(const r of row.actions){
     if(r.n!==undefined){assert(r.n<=256&&r.ms<=600);maxInputs=Math.max(maxInputs,r.n);maxTime=Math.max(maxTime,r.ms);}
     if(!r.passive&&r.action.family==='pass'&&m.facts().round===3)assert.deepEqual(m.save(),row.settled.state);
     if(r.action.actorId!=='player-white')assert(r.action.family==='pass'||m.c.inspect().session?.decision);
     m.apply(r.action);
    }
    assert.deepEqual(m.save(),row.end);
    assert.equal(m.facts().round,4);
    replayed+=row.prefix.length+row.actions.length;complete++;
   }
   infeasible+=group.failures.length;
  }finally{m.dispose();}
 }
}
console.log(JSON.stringify({complete,infeasible,replayed,maxInputs,maxTime,exactNativeRoundEndsAndRng:true}));
