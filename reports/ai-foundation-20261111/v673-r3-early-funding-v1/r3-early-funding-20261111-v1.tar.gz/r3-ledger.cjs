'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open}=require('./native-late-r3'),dir=process.argv[2];
const read=f=>JSON.parse(fs.readFileSync(path.join(dir,f)));
const envelope=x=>x.coreState?.compositionEnvelope||{schemaVersion:teacher.origin.schemaVersion,committedState:x.committedState,session:x.session};
const teacher=JSON.parse(z.gunzipSync(fs.readFileSync(path.join(dir,'teacher-20261111-v1.json.gz'))));
const standardEnd=read('d3183131.cbd73e00.quick-400.json.round-end-3.checkpoint.json');
const standardStart=read('d3183131.cbd73e00.quick-400.json.round-end-2.checkpoint.json');
const previous=read('v189-r3-resume-20261105.json'),v189End=read('db594a2e.1609bf50.full.json.round-end-3.checkpoint.json');
const data=require(path.resolve('randomizer/game/data')),seat='player-white';
const state=e=>e.session?.session?.workingState||JSON.parse(e.committedState);
const id=c=>c?.cardId??null;
function summarize(e){
 const s=state(e),p=s.players.players.find(p=>p.id===seat),color=p.color;
 const {roundNumber,turnNumber,currentPlayerId}=s.turn;
 return {roundNumber,turnNumber,currentPlayerId,score:p.resources.score,resources:p.resources,income:p.income,
  technology:{owned:p.techState.ownedTiles,blueSlots:p.techState.blueBoardSlots,disabled:p.techState.disabledTiles},
  hand:p.hand.map(id),reserved:p.reservedCards.map(id),computer:data.listComputerPlacedTokens(p).map(x=>x.placementSlot),
  blue:data.listBlueBonusPlacedTokens(p).map(x=>x.blueSlot),probes:s.pieces.rockets.filter(r=>r.playerId===seat),
  signals:Object.fromEntries(Object.entries(s.data.nebulae).flatMap(([k,v])=>{const owned=v.tokens.filter(t=>t.replacedByPlayerColor===color||t.playerColor===color);return owned.length?[[k,{count:owned.length,capacity:data.getNebulaCapacity(k)}]]:[];})),
  sectorWins:s.data.sectorSettlements,aliens:s.aliens.aliens,finalMarks:Object.entries(s.finalScoring.tiles).flatMap(([k,t])=>t.marks.filter(m=>m.playerId===seat).map(m=>({tile:k,...m}))),
  market:s.cards.publicCards.map(id),discardCount:s.cards.discardPile.length,deckCount:s.cards.drawPileCardIds.length,rng:s.meta.rngState};
}
const m=open(envelope(standardStart)),r3opening=[];
let newStart;
try{
 for(const r of standardEnd.replaySteps.slice(standardStart.replayCursor.stepIndex)){
  if(state(m.save()).turn.roundNumber===3&&!m.c.inspect().session)break;
  r3opening.push(m.apply(r.action));
 }
 newStart=m.save();assert.equal(state(newStart).turn.roundNumber,3);
 assert.equal(state(newStart).players.players.find(p=>p.id===seat).resources.score,48);
}finally{m.dispose();}
const v189=envelope(previous);
assert.equal(state(v189).turn.roundNumber,3);
const boundary={teacher:[teacher.origin,teacher.current],v189:[v189,envelope(v189End)],v673:[newStart,envelope(standardEnd)]};
const result={v673OpeningReplayedInputs:r3opening.length,source:'Native checkpoints and recorded standard actions only; no policy searches',
 phases:{opening:'after R2 PASS and R3 income, before any white R3 main action',
  settled:'after R3 white rewards and before PASS choice and R4 income'},
 series:Object.fromEntries(Object.entries(boundary).map(([k,rows])=>[k,rows.map(summarize)]))};
assert.deepEqual(Object.values(result.series).map(r=>r.map(s=>s.score)),[[34,105],[50,77],[48,118]]);
fs.writeFileSync(path.join(dir,'r3-ledger-20261111-v1.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
for(const[k,r]of Object.entries(result.series))console.log(k,JSON.stringify(r.map(s=>({
 score:s.score,wallet:[s.resources.credits,s.resources.energy,s.resources.publicity,s.resources.availableData],
 income:[s.income.credits,s.income.energy,s.income.handSize,s.income.publicity,s.income.availableData,s.income.additionalPublicScan],
 tech:Object.keys(s.technology.owned).length,hand:s.hand,computer:s.computer,blue:s.blue,
 probes:s.probes.map(p=>[p.sectorX,p.sectorY,p.fossilId||null]),market:s.market,deck:s.deckCount,discard:s.discardCount}))));
