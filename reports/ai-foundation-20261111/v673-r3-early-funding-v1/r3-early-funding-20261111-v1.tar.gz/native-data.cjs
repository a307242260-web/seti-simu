'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
const transform=(s,mode)=>{
 const sub=(a,b)=>{assert.equal(s.split(a).length,2,a);s=s.replace(a,b);};
 for(const [method,kind] of [['listComputerPlacedTokens','COMPUTER'],['listBlueBonusPlacedTokens','BLUE_BONUS']]){
   sub(`  function ${method}(player) {
    return listPlacedTokens(player).filter((token) => getPlacementKind(token) === PLACEMENT_KIND_${kind});
  }`,`  function ${method}(player) {
    return readPlayerDataState(player).placedTokens.filter((token) => getPlacementKind(token) === PLACEMENT_KIND_${kind});
  }`);
 }
 sub(`  function isComputerSlotOccupied(player, placementSlot) {
    return listComputerPlacedTokens(player).some((token) => token.placementSlot === Number(placementSlot));
  }

  function isBlueBonusSlotOccupied(player, blueSlot) {
    return listBlueBonusPlacedTokens(player).some((token) => token.blueSlot === Number(blueSlot));
  }`,`  function isComputerSlotOccupied(player, placementSlot) {
    return readPlayerDataState(player).placedTokens.some((token) =>
      getPlacementKind(token) === PLACEMENT_KIND_COMPUTER && token.placementSlot === Number(placementSlot));
  }

  function isBlueBonusSlotOccupied(player, blueSlot) {
    return readPlayerDataState(player).placedTokens.some((token) =>
      getPlacementKind(token) === PLACEMENT_KIND_BLUE_BONUS && token.blueSlot === Number(blueSlot));
  }`);
 if(mode.includes('native-mask'))sub(`    const occupied = new Set(listComputerPlacedTokens(player).map((token) => token.placementSlot));
    for (const slot of placement.COMPUTER_DATA_SLOT_IDS) {
      if (!occupied.has(slot)) return slot;
    }`,`    let occupied = 0;
    for (const token of readPlayerDataState(player).placedTokens) {
      if (getPlacementKind(token) !== PLACEMENT_KIND_COMPUTER) continue;
      const slot = token.placementSlot;
      if (Number.isInteger(slot) && slot >= 1 && slot <= 6) occupied |= 1 << slot;
    }
    for (const slot of placement.COMPUTER_DATA_SLOT_IDS) {
      if (!(occupied & (1 << slot))) return slot;
    }`);
 if(mode.includes('native-pool-min'))sub(`    return [...dataState.poolTokens].sort((a, b) => a.slotIndex - b.slotIndex)[0] || null;`,
 `    let leftmost = null;
    for (const token of dataState.poolTokens) {
      if (!Number.isFinite(token?.slotIndex)) {
        return [...dataState.poolTokens].sort((a, b) => a.slotIndex - b.slotIndex)[0] || null;
      }
      if (!leftmost || token.slotIndex < leftmost.slotIndex) leftmost = token;
    }
    return leftmost;`);
 return s;
};
module.exports=mode=>{
 if(!mode.includes('native-data'))return;
 const file=path.resolve('randomizer/game/data/state.js'),m=new Module(file,module);
 m.filename=file;m.paths=Module._nodeModulePaths(path.dirname(file));
 assert(!require.cache[file]);m._compile(transform(fs.readFileSync(file,'utf8'),mode),file);m.loaded=true;require.cache[file]=m;
};
module.exports.transform=transform;
