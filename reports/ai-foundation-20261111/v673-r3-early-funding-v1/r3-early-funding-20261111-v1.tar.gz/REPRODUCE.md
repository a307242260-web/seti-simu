本次只登记实验数据。规则源码为 433765e936e26b6a25c8b599f580792471e3445b，报告提交 327dda568fe2d7b574164e28c0fdb71f058dd8e7 的源码相同。A 指向解包目录，在规则源码目录运行（复现输出用新文件名）：

    node "$A/preserve-funding.cjs" "$A/native-204-209-20261111-v1.json.gz" "$A/replay-prep-20261111-v1.json.gz"
    node "$A/audit-equivalence.cjs" "$A/r3-prep-204-20261111-v1.json.gz" "$A/native-204-209-20261111-v1.json.gz" "$A/replay-equivalence-20261111-v1.json.gz"
    node "$A/verify-r3-prep.cjs" "$A/r3-prep-204-20261111-v1.json.gz" "$A/r3-prep-swap-20261111-v1.json.gz" "$A/r3-prep-amiba7-play-20261111-v1.json.gz" "$A/r3-prep-dlc20-20261111-v1.json.gz"

第二项仅为读取现行向前规则键向隔离模块加导出，不参与决策。交换蓝槽先后，只交换原生存档中两枚同质数据标记对应的蓝槽编号；合法菜单、RNG 和现行向前规则身份一致，最终都为118/164、6科技、7钱4电、空手。第204步的公司交换和宣传取牌是合法菜单，但被当前取牌政策以没有目的排除；不是估值比输。逐笔受控验证说明，提前买牌花掉研究所需宣传；提前交换后，贪心蓝3仍花掉阿米巴7来拿第二张公开牌。保留扫描源、固定同样粉痕迹也未得到比标准更多库存；有六科技及7钱4电的最好新交换路线为116/162，空手无池数据和蓝槽留存。保留阿米巴7并用作下一次主行动的六条已公开组合均止于7钱3电，最多117/169。共22条闭合、1条非法，1076个输入逐笔原生再提交，已提交自主峰值225次/285.194ms。轮末取PASS选牌及下轮收入前。

第四轮读取估值与公开牌遮蔽的隔离试验均保持整图及获胜证书。copy+compact 的独立冷测为149次/598.872ms、159次/608.199ms，B32仍不合格；无新整局，无新标准前三轮，无源码改动、V2成绩或V41基线变更。复现隔离冷根：

    OPT="$(cat "$A/mode")-turn-copy-card-screen-data-screen-mask-copy-compact-observation"
    SETI_SCAN_PRIOR="$A/prior.cjs" node "$A/cold-root.cjs" "$OPT" "$A/root-b_32.webp.gz" "$A/replay-b_32.webp.json.gz"
    node "$A/compare.cjs" "$A" "$A"
