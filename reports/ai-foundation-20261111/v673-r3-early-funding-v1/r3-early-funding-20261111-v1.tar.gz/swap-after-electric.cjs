'use strict';
const assert=require('node:assert/strict'),{runCases,readZ,writeZ}=require('./controlled-r3');
const [input,out]=process.argv.slice(2),prior=readZ(input);
const base=prior.rows.find(r=>r.label==='swap-b16-keep-amiba7').start;
const right=({m,take,act})=>{
 act('end_turn');const a=[];m.advanceOpponents(a);take(...a);
};
function scan(c,pink){
 c.act('scan');
 c.act('choose_target',a=>a.target.nebulaId==='sector-3-a');
 c.act('choose_card',a=>a.target.nebulaId==='sector-3-a'&&a.summary.includes('dlc_24'));
 if(pink){
  c.act('choose_target',a=>a.target.choiceId==='trace:1:pink:amiba:3');
  c.act('choose_card',a=>a.target.source==='display');
 }
}
const cases=[
 ['save-amiba7-end-first',right],
 ['save-amiba7-fix-scan-only',c=>{right(c);scan(c,false);}],
 ['save-amiba7-fix-scan-and-pink',c=>{right(c);scan(c,true);}],
 ['save-amiba7-play-amiba9',c=>{right(c);c.take(c.m.play('amiba_9.webp'));}],
];
const result=runCases(base,cases);
writeZ(out,{root:base,...result});
