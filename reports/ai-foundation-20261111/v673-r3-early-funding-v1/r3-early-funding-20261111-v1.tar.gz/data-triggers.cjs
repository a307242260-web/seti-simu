'use strict';
const assert=require('node:assert/strict');
module.exports=(s,mode)=>{
 if(!mode.includes('data-trigger-copy')&&!mode.includes('known-menu-ids'))return s;
 const edit=(a,b)=>{assert.equal(s.split(a).length,2,a);s=s.replace(a,b);};
 if(mode.includes('data-trigger-copy')){
  const start=s.indexOf('    function previewDataRewardMenu('),end=s.indexOf('    function rememberQuietEndPrelude(',start);
  assert(start>=0&&end>start);
  let span=s.slice(start,end);
  assert.equal((span.match(/structuredClone\(owner.reservedCards\)/g)||[]).length,2);
  span=span.replaceAll('structuredClone(owner.reservedCards)','quietPlacementCards(owner.reservedCards)');
  assert.equal((span.match(/structuredClone\(p.reservedCards\)/g)||[]).length,1);
  span=span.replace('structuredClone(p.reservedCards)','quietPlacementCards(p.reservedCards)');
  s=s.slice(0,start)+`    const quietPlacementCardLists=new WeakMap();
    function quietPlacementCards(list){
      // Native matching only initializes these two arrays for trigger cards.
      // Lists with missing or older effect state retain the original copy.
      if(!Object.isFrozen(list)||!resourceDemand.immutableCapitalInput(list))return structuredClone(list);
      let quiet=quietPlacementCardLists.get(list);
      if(quiet===undefined){
        quiet=list.every(card=>{
          if(!cardEffects.getCardModel(card)?.triggers?.length)return true;
          const id=card.cardId||(Number.isInteger(card.cardIndex)?\`b_\${card.cardIndex}.webp\`:null),effect=card.cardEffectState;
          return effect?.modelCardId===id&&Array.isArray(effect.consumedTriggerIds)&&Array.isArray(effect.completedTaskIds);
        });
        quietPlacementCardLists.set(list,quiet);
      }
      return quiet?list:structuredClone(list);
    }
`+span+s.slice(end);
 }
 if(mode.includes('known-menu-ids')){
  const start=s.indexOf('    function knownPostMainActions('),end=s.indexOf('    function finishChild(',start);
  assert(start>=0&&end>start);
  let span=s.slice(start,end).replaceAll('knownCards(envelope).has(','knownIds.has(');
  span=span.replace('      if(!resourcePlanning','      const knownIds=knownCards(envelope);\n      if(!resourcePlanning');
  s=s.slice(0,start)+span+s.slice(end);
 }
 return s;
};
