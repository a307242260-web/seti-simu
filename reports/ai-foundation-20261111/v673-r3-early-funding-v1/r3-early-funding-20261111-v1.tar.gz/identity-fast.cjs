'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
const transform=s=>{
 const a='    for(const key of Object.keys(value).sort()){if(!first)out+=",";first=false;out+=literal(key)+":"+stableSerialize(value[key]);}';
 assert.equal(s.split(a).length,2,a);
 return s.replace(a,`    const keys=Object.keys(value);
    if(keys.length===4 && Object.prototype.propertyIsEnumerable.call(value,"actorId")
      && Object.prototype.propertyIsEnumerable.call(value,"family")
      && Object.prototype.propertyIsEnumerable.call(value,"payload")
      && Object.prototype.propertyIsEnumerable.call(value,"target")){
      return '{"actorId":'+stableSerialize(value.actorId)+',"family":'+stableSerialize(value.family)
        +',"payload":'+stableSerialize(value.payload)+',"target":'+stableSerialize(value.target)+'}';
    }
    for(const key of keys.sort()){if(!first)out+=",";first=false;out+=literal(key)+":"+stableSerialize(value[key]);}`);
};
module.exports=mode=>{
 if(!mode.includes('identity-fast'))return;
 const file=path.resolve('randomizer/game/actions/standard-action.js'),m=new Module(file,module);m.filename=file;m.paths=Module._nodeModulePaths(path.dirname(file));
 assert(!require.cache[file]);m._compile(transform(fs.readFileSync(file,'utf8')),file);m.loaded=true;require.cache[file]=m;
};
module.exports.transform=transform;
