'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs');
const {open,readZ,writeZ}=require('./controlled-r3');
const out=process.argv[2],rows=[];
for(const f of process.argv.slice(3)){
 const [{root,cp}]=readZ(f),m=open(root);
 try{
  for(const r of cp.plan.rows){
   const action=m.menu().find(a=>a.actionId===r.actionId);assert(action);
   if(!m.c.inspect().session)rows.push(m.save());
   m.apply(action);
  }
  m.restore(root);assert.deepEqual(m.save(),root);
 }finally{m.dispose();}
}
writeZ(out,rows);
