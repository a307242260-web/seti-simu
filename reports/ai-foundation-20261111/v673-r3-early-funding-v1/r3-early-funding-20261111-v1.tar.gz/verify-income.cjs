'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),z=require('node:zlib'),path=require('node:path');
const [base,next,...files]=process.argv.slice(2);
const load=root=>require(path.join(root,'randomizer/game/ai/resource-demand'));
const a=load(base),b=load(next),seatId='player-white';
const snapshots=files.flatMap(file=>{
 const x=JSON.parse(z.gunzipSync(fs.readFileSync(file)));return Array.isArray(x)?x:[x.state??x.current];
});
let compared=0,r3=0,r4=0,available=0,availableR4=0;
for(const envelope of snapshots){
 const saved=JSON.parse(envelope.committedState);
 for(const credits of [0,1,2,4,7])for(const energy of [0,1,2,3,6])for(const publicity of [0,2,5]){
  const state=structuredClone(saved),p=state.players.players.find(x=>x.id===seatId);
  Object.assign(p.resources,{credits,energy,publicity});
  for(const card of p.hand){
   const goal={incomeCardId:card.id};
   assert.deepEqual(b.computerIncomeValue(state,seatId,card),a.computerIncomeValue(state,seatId,card));
   const current=b.incomeTailCapital({state,seatId,goal});
   assert.deepEqual(current,a.incomeTailCapital({state,seatId,goal}));
   available+=Number(current.available);
   if(state.turn.roundNumber===4&&current.available)availableR4++;
   compared++;if(state.turn.roundNumber===3)r3++;else if(state.turn.roundNumber===4)r4++;
  }
 }
 assert.deepEqual(JSON.parse(envelope.committedState),saved);
}
assert(r3>0&&r4>0&&available>0&&availableR4>0);
console.log(JSON.stringify({compared,r3,r4,available,availableR4,exactNativeRootsUnchanged:true}));
