'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
const transform=s=>{
 const a='  return Object.fromEntries(Object.entries(value).filter(([, item]) => item != null));';
 assert.equal(s.split(a).length,2,a);
 return s.replace(a,`  // All callers pass new projection literals with fixed own keys.
  const compact = {};
  for (const key of Object.keys(value)) {
    const item = value[key];
    if (item != null) compact[key] = item;
  }
  return compact;`);
};
module.exports=mode=>{
 if(!mode.includes('compact-observation'))return;
 const file=path.resolve('randomizer/app/simulation-contract.js'),m=new Module(file,module);m.filename=file;m.paths=Module._nodeModulePaths(path.dirname(file));
 assert(!require.cache[file]);m._compile(transform(fs.readFileSync(file,'utf8')),file);m.loaded=true;require.cache[file]=m;
};
module.exports.transform=transform;
