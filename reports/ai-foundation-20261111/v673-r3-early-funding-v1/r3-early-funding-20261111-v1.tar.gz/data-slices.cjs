'use strict';
const assert=require('node:assert/strict');
module.exports=(s,mode)=>{
 if(!mode.includes('data-slice'))return s;
 const edit=(a,b)=>{assert.equal(s.split(a).length,2,a);s=s.replace(a,b);};
 edit('    function previewDataRewardMenu(stored, action) {',`    const quietDataSlices=new WeakMap();
    function quietDataSlice(owner){
      const d=owner.dataState,t=owner.techState;
      if(!Object.isFrozen(d)||!Object.isFrozen(t)
        ||!resourceDemand.immutableCapitalInput(d)||!resourceDemand.immutableCapitalInput(t)
        ||!Array.isArray(d?.poolTokens)||!Array.isArray(d?.placedTokens))return null;
      let techs=quietDataSlices.get(d);
      if(!techs){techs=new WeakMap();quietDataSlices.set(d,techs);}
      let entry=techs.get(t);
      if(!entry){entry={moves:new Map()};techs.set(t,entry);}
      return entry;
    }
    function quietDataChoices(state){
      const owner=state.players.players.find(p=>p.id===seatId),entry=quietDataSlice(owner);
      if(entry?.choices){
        globalThis.sliceCounts.menuHit++;
        const stateVersion=state.meta?.stateVersion??0,decisionVersion=state.match?.decisionVersion??0;
        return entry.choices.map(a=>a.stateVersion===stateVersion&&a.decisionVersion===decisionVersion?a:{...a,stateVersion,decisionVersion});
      }
      globalThis.sliceCounts.menuMiss++;
      const choices=scienceSession.formalizeChoices(state,seatId,scienceSession.listPlaceDataChoices(state,seatId));
      if(entry)entry.choices=freeze(choices);
      return choices;
    }
    function placeQuietPreview(player,owner,options){
      const entry=quietDataSlice(owner),key=options?.blueSlot??0;
      const previous=entry?.moves.get(key);
      if(previous){
        globalThis.sliceCounts.moveHit++;
        player.dataState=previous.dataState;player.resources.availableData=previous.availableData;
        return previous.result;
      }
      globalThis.sliceCounts.moveMiss++;
      const d=owner.dataState;
      player.dataState=entry?{...d,poolTokens:[...d.poolTokens],placedTokens:[...d.placedTokens]}:structuredClone(d);
      const result=data.placeDataToComputer(player,options);
      if(entry&&result.ok)entry.moves.set(key,freeze({result,dataState:player.dataState,availableData:player.resources.availableData}));
      return result;
    }

    function previewDataRewardMenu(stored, action) {`);
 if(mode.includes('slice-menu'))
  edit('const choices = scienceSession.formalizeChoices(quietSource, seatId, scienceSession.listPlaceDataChoices(quietSource, seatId));','const choices = quietDataChoices(quietSource);');
 if(mode.includes('slice-placement')){
  edit(`const player = {...owner, resources:{...owner.resources}, dataState:structuredClone(owner.dataState),
        reservedCards:structuredClone(owner.reservedCards)};
      const placed = data.placeDataToComputer(player, blue?{target:"blueBonus",blueSlot:2}:undefined);`,
  `const player = {...owner, resources:{...owner.resources},reservedCards:structuredClone(owner.reservedCards)};
      const placed = placeQuietPreview(player,owner,blue?{target:"blueBonus",blueSlot:2}:undefined);`);
  edit(`const player = {...owner, resources:{...owner.resources}, dataState:structuredClone(owner.dataState),
        reservedCards:structuredClone(owner.reservedCards), scoreSources:{...owner.scoreSources}};
      const placement = data.placeDataToComputer(player, blueSlot ? {target:"blueBonus", blueSlot} : undefined);`,
  `const player = {...owner, resources:{...owner.resources},reservedCards:structuredClone(owner.reservedCards), scoreSources:{...owner.scoreSources}};
      const placement = placeQuietPreview(player,owner,blueSlot ? {target:"blueBonus", blueSlot} : undefined);`);
 }
 if(mode.includes('slice-content')){
  edit('    const quietDataSlices=new WeakMap();',`    const quietDataSlices=new WeakMap(), quietPlacementShapes=new Map(),quietSliceKeys=new WeakMap();
    function sliceBytes(value){
      if(quietSliceKeys.has(value))return quietSliceKeys.get(value);
      const key=JSON.stringify(value);quietSliceKeys.set(value,key);return key;
    }
    function quietMenuShape(owner){
      const d=owner.dataState,t=owner.techState;
      if(!d.poolTokens.every(token=>Number.isSafeInteger(token?.slotIndex))
        ||d.placedTokens.some(token=>token?.placementKind==="blueBonus"
          ?!Number.isSafeInteger(token.blueSlot):!Number.isSafeInteger(token?.placementSlot)))return null;
      let computer=0,blue=0;
      for(const token of d.placedTokens){
        if(token.placementKind==="blueBonus")blue|=1<<token.blueSlot;
        else computer|=1<<token.placementSlot;
      }
      return JSON.stringify([Boolean(d.poolTokens.length),computer,blue,sliceBytes(t)]);
    }`);
  edit(`      let entry=techs.get(t);
      if(!entry){entry={moves:new Map()};techs.set(t,entry);}
      return entry;`,`      let entry=techs.get(t);
      if(entry)return entry;
      const topology=quietMenuShape(owner),moveShape=sliceBytes(d)+":"+sliceBytes(t);
      function shape(prefix,key,defaults){
        if(key===null)return defaults;
        const id=prefix+key;
        if(quietPlacementShapes.has(id))return quietPlacementShapes.get(id);
        if(quietPlacementShapes.size>=512)quietPlacementShapes.delete(quietPlacementShapes.keys().next().value);
        quietPlacementShapes.set(id,defaults);return defaults;
      }
      const menu=shape("menu:",topology,{}),move=shape("move:",moveShape,new Map());
      entry={get choices(){return menu.value;},set choices(value){menu.value=value;},moves:move};
      techs.set(t,entry);return entry;`);
 }
 return s;
};
