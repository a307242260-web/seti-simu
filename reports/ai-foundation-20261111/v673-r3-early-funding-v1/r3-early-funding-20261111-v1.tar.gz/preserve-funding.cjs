'use strict';
const assert=require('node:assert/strict');
const {open,readZ,runCases,writeZ}=require('./controlled-r3');
const [input,output]=process.argv.slice(2),x=readZ(input),source=x.root??x.rows.find(r=>r.i===204).before;
const slot=({act},n)=>{act('place_data');act('choose_target',a=>a.target.blueSlot===n);};
const finish=({m,act,take})=>{act('end_turn');const a=[];m.advanceOpponents(a);take(...a);};
const buy=({m,act,take})=>{act('quick_trade',a=>a.target.tradeId==='publicity-for-card');take(m.pick('dlc_25.png'));};
const energyThen=(c,fn)=>{slot(c,1);fn(c);};
const swap=(c,id)=>c.take(...c.m.swap(id,'dlc_25.png'));
const cases=[
 ['use-publicity-keep-amiba7',c=>energyThen(c,buy)],
 ['use-publicity-keep-amiba7-commit-next',c=>{energyThen(c,buy);finish(c);}],
 ['swap-b16-keep-amiba7',c=>energyThen(c,x=>swap(x,'b_16.webp'))],
 ['swap-amiba9-keep-amiba7',c=>energyThen(c,x=>swap(x,'amiba_9.webp'))],
 ['blue-pick-before-electricity',c=>{slot(c,2);c.take(c.m.pick('dlc_25.png'),c.m.corner('amiba_7.webp'));slot(c,1);}],
 ['use-publicity-keep-amiba7-then-b16',c=>{energyThen(c,buy);finish(c);c.take(c.m.play('b_16.webp'));}],
 ['use-publicity-purchase-then-original-scan',c=>{energyThen(c,buy);finish(c);c.act('scan');
  c.act('choose_target',a=>a.target.nebulaId==='sector-3-a');
  c.act('choose_card',a=>a.target.nebulaId==='sector-3-a'&&a.summary.includes('dlc_24'));}],
];
const baseline=open(source);
let query;
try{
 const q=baseline.automatic();assert(q.complete&&q.n<=256&&q.ms<=600);
 query={action:q.a,value:q.value,n:q.n,ms:q.ms,roots:q.roots};
 console.log(JSON.stringify({root:query}));
}finally{baseline.dispose();}
const result=runCases(source,cases);writeZ(output,{source,query,...result});
