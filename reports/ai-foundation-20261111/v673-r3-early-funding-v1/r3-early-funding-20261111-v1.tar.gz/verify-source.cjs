'use strict';
const fs=require('node:fs'),z=require('node:zlib'),assert=require('node:assert/strict'),path=require('node:path');
const [base,other,...files]=process.argv.slice(2),load=(d,f)=>require(path.join(d,'randomizer/game',f));
const old=load(base,'data/nebula-state'),now=load(other,'data/nebula-state');
const before=load(base,'effects/science-session'),after=load(other,'effects/science-session');
const oldProbe=load(base,'ai/probe-capital'),newProbe=load(other,'ai/probe-capital'),weights=load(base,'ai/state-value').DEFAULT_WEIGHTS;
let tokenQueries=0,menus=0,missionQuotes=0;
for(const file of files){
 const item=JSON.parse(z.gunzipSync(fs.readFileSync(file))),root=JSON.parse(item.state.committedState),saved=JSON.stringify(root);
 const actor=root.players.players.find(p=>p.id==='player-white');
 for(const [id,bucket] of Object.entries(root.data.nebulae)){
  assert(bucket.tokens.length<=15);
  for(let bits=0;bits<1<<bucket.tokens.length;bits++){
   const excluded=new Set(bucket.tokens.filter((_t,i)=>bits&(1<<i)).map(t=>t.id));
   const detached={...root.data,nebulae:{...root.data.nebulae,[id]:{...bucket,tokens:bucket.tokens.filter(t=>!excluded.has(t.id))}}};
   assert.deepEqual(now.getNextReplaceableNebulaToken(root.data,id,excluded),old.getNextReplaceableNebulaToken(detached,id));
   tokenQueries++;
  }
 }
 const opts=[{mode:'any'},{mode:'public',selected:1},{mode:'hand'},...['specified','color','planet'].flatMap(mode=>{
   if(mode==='specified')return [{mode,nebulaIds:Object.keys(root.data.nebulae)}, {mode,nebulaIds:[]}];
   if(mode==='color')return ['blue','black','red','yellow'].map(color=>({mode,color}));
   return ['earth','mars','mercury','venus','jupiter','saturn'].map(planetId=>({mode,planetId}));
 })];
 for(const o of opts){
  assert.deepEqual(before.listScanStepChoices(root,actor,o),after.listScanStepChoices(root,actor,o));
  menus++;
 }
 for(const credits of [1,4,8])for(const energy of [0,3,7])for(const availableData of [0,3,6]){
  const facts=fn=>{const f=fn.factsFromState(root,actor);return {...f,player:{...f.player,credits,energy,availableData},investment:()=>0};};
  assert.deepEqual(oldProbe.quote(facts(oldProbe),weights),newProbe.quote(facts(newProbe),weights));missionQuotes++;
 }
 assert.equal(JSON.stringify(root),saved);
}
console.log(JSON.stringify({tokenQueries,menus,missionQuotes,sourceUnchanged:true}));
