'use strict';
const assert=require('node:assert/strict');
module.exports=(s,mode)=>{
 function sub(a,b){assert.equal(s.split(a).length,2,a);s=s.replace(a,b);}
 if(mode.includes('closed-r4-income'))sub(
  '    const current=knownCapital??planningCapital(state,p);\n    if(!Object.entries(p.techState.blueBoardSlots)',
  '    const current=knownCapital??planningCapital(state,p);\n    // Both future income preparation and its scan bridge are closed in R4.\n    if(state.turn.roundNumber===4)return current;\n    if(!Object.entries(p.techState.blueBoardSlots)');
 if(mode.includes('income-prefix-copy'))sub(
  '    const p={...original,resources:{...original.resources},dataState:structuredClone(original.dataState)};',
  `    const d=original.dataState;
    const dataState=Object.isFrozen(d)&&immutableCapitalInput(d)&&Array.isArray(d?.poolTokens)&&Array.isArray(d?.placedTokens)
      ?{...d,poolTokens:[...d.poolTokens],placedTokens:[...d.placedTokens]}:structuredClone(d);
    const p={...original,resources:{...original.resources},dataState};`);
 return s;
};
