'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
const transform=s=>{
 const a=`      capital=purposeCapital(facts,weights);
    }
    const components = Object.freeze`;
 assert.equal(s.split(a).length,2);
 return s.replace(a,`      if(round===4){
        // Only the current probe mission and an earned final mark survive
        // the last-round window. Keep their existing value functions.
        const last=basePurposeCapital(facts,weights);
        capital={...last,analysisPotential:0,researchIncomePotential:0,dataPotential:0,toolPlan:{value:0}};
      }else capital=purposeCapital(facts,weights);
    }
    const components = Object.freeze`);
};
module.exports=mode=>{
 if(!mode.includes('r4-value-only'))return;
 const file=path.resolve('randomizer/game/ai/state-value.js'),m=new Module(file,module);m.filename=file;m.paths=Module._nodeModulePaths(path.dirname(file));
 assert(!require.cache[file]);m._compile(transform(fs.readFileSync(file,'utf8')),file);m.loaded=true;require.cache[file]=m;
};
module.exports.transform=transform;
