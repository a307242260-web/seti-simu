'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
function edit(s,a,b){assert.equal(s.split(a).length,2,a);return s.replace(a,b);}
function load(name,fn){
 const file=path.resolve('randomizer/app',name+'.js'),m=new Module(file,module);m.filename=file;m.paths=Module._nodeModulePaths(path.dirname(file));
 assert(!require.cache[file]);m._compile(fn(fs.readFileSync(file,'utf8')),file);m.loaded=true;require.cache[file]=m;
}
module.exports=mode=>{
 if(!mode.includes('value-card-projection'))return;
 load('simulation-contract',s=>{
   if(mode.includes('compact-observation'))s=require('./compact-observation.cjs').transform(s);
   s=edit(s,'function sanitizePublicPlayer(player, finalScoreSummary) {',`const valueCards = new WeakMap();
function valueCard(card) {
  if(!card||!Object.isFrozen(card))return sanitizeCard(card);
  if(valueCards.has(card))return valueCards.get(card);
  const primitive=(v)=>v==null||["string","number","boolean"].includes(typeof v);
  const ordinary=(v)=>Object.getPrototypeOf(v)===Object.prototype||Object.getPrototypeOf(v)===null;
  const effect=Object.getOwnPropertyDescriptor(card,"cardEffectState");
  if(!ordinary(card)||effect&&!Object.hasOwn(effect,"value"))return sanitizeCard(card);
  const state=effect?.value;
  if(state&&(!Object.isFrozen(state)||!ordinary(state)||Object.values(Object.getOwnPropertyDescriptors(state)).some(d=>!Object.hasOwn(d,"value"))
    ||!primitive(state.modelCardId)||[state.consumedTriggerIds,state.completedTaskIds].some(ids=>ids!=null
      &&(!Array.isArray(ids)||!Object.isFrozen(ids)||Object.values(Object.getOwnPropertyDescriptors(ids)).some(d=>!Object.hasOwn(d,"value")||!primitive(d.value))))))return sanitizeCard(card);
  const fields=["id","cardId","set","cardName","price","cardTypeCode","discardActionCode","scanActionCode","incomeCode","faceUp","blueBonusOwnerId"];
  if(fields.some(key=>{const d=Object.getOwnPropertyDescriptor(card,key);return d?!Object.hasOwn(d,"value")||!primitive(d.value):card[key]!==undefined;}))return sanitizeCard(card);
  const result=sanitizeCard(card),e=result.cardEffectState;
  if(e){Object.freeze(e.consumedTriggerIds);Object.freeze(e.completedTaskIds);Object.freeze(e);}
  Object.freeze(result);valueCards.set(card,result);return result;
}
function sanitizePublicPlayer(player, finalScoreSummary) {`);
   s=edit(s,'function sanitizeSelfPlayer(player, turn = {}, pendingEffectOwnerIds = []) {','function sanitizeSelfPlayer(player, turn = {}, pendingEffectOwnerIds = [], valueOnly = false) {');
   s=edit(s,'  return compactObject({\n    playerId: player.id,\n    hand: (player.hand || []).map(sanitizeCard),\n    reservedCards: (player.reservedCards || []).map(sanitizeCard),',
   '  const projectCard=valueOnly?valueCard:sanitizeCard;\n  return compactObject({\n    playerId: player.id,\n    hand: (player.hand || []).map(projectCard),\n    reservedCards: (player.reservedCards || []).map(projectCard),');
   return edit(s,'  sanitizeCard,\n  sanitizePublicPlayer,','  sanitizeCard,\n  valueCard,\n  sanitizePublicPlayer,');
 });
 load('rule-observation',s=>{
   s=edit(s,'  sanitizeCard,\n  sanitizePublicPlayer,','  sanitizeCard,\n  valueCard,\n  sanitizePublicPlayer,');
   s=edit(s,'  const selfState=sanitizeSelfPlayer(selfPlayer,turn,state.pendingEffectOwnerIds||[]);',
     '  const selfState=sanitizeSelfPlayer(selfPlayer,turn,state.pendingEffectOwnerIds||[],valueOnly);');
   return edit(s,'publicCards: (state.cards?.publicCards || []).map(sanitizeCard),','publicCards: (state.cards?.publicCards || []).map(valueOnly?valueCard:sanitizeCard),');
 });
};
