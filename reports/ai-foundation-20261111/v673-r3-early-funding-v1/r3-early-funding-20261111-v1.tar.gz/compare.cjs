'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),assert=require('node:assert/strict');
const dir=process.argv[2],old=process.argv[3];
const read=file=>JSON.parse(z.gunzipSync(fs.readFileSync(file)))[0];
const fields=['schemaVersion','complete','actionId','selectionPlan','planEvidence','value','realization','preparationDebt','stopReason','scope','roots','lines','unresolved','sharedPrefixGraph','candidates'];
for(const board of ['b_111.webp','b_32.webp']){
 const base=read(path.join(old,'quote-'+board+'.json.gz'));
 for(const file of fs.readdirSync(dir).filter(f=>f.endsWith('-'+board+'.json.gz'))){
  const x=read(path.join(dir,file));
  assert.deepEqual(x.root,base.root,file);
  for(const k of fields)assert.deepEqual(x.q[k],base.q[k],file+': '+k);
  assert.deepEqual(x.cp,base.cp,file+': checkpoint');
  assert.equal(x.q.diagnostics.nativeExecutions,base.q.diagnostics.nativeExecutions-(x.mode.includes("region-draw")?(board.includes("111")?14:16):0),file);
  assert.equal(x.q.diagnostics.nodes,base.q.diagnostics.nodes,file);
  console.log(JSON.stringify({variant:file.slice(0,-board.length-9),board,n:x.q.diagnostics.nativeExecutions,ms:x.q.rootAndSearchMilliseconds,complete:x.q.complete,certificate:x.cp.plan?.rows?.length??x.q.selectionPlan?.inputCount??null}));
 }
}
