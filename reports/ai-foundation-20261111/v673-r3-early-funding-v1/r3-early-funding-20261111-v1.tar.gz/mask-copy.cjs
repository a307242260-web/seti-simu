'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
function edit(s,a,b){assert.equal(s.split(a).length,2,a);return s.replace(a,b);}
exports.composition=s=>{
 s=edit(s,'  function maskUnknownCards(cards, knownIds) {','  function maskUnknownCards(cards, knownIds, copyCard = clone) {');
 s=edit(s,'        ? clone(card)\n        : { hidden: true, faceUp: false };','        ? copyCard(card)\n        : { hidden: true, faceUp: false };');
 s=edit(s,'function sanitizeHiddenInformationObservation(rootObservation, leafObservation, barrier, visibleRootCardIds = []) {','function sanitizeHiddenInformationObservation(rootObservation, leafObservation, barrier, visibleRootCardIds = [], copyCard) {');
 for(const name of ['board.publicCards','self.hand','self.reservedCards','self.privateAlienCards'])
  s=edit(s,`maskUnknownCards(${name}, knownCardIds)`,`maskUnknownCards(${name}, knownCardIds, copyCard)`);
 return s;
};
exports.port=(s,mode)=>{
 if(!mode.includes('mask-copy'))return s;
 return edit(s,'? ruleComposition.sanitizeHiddenInformationObservation(rootObservation, observation, barrier, knownCards(envelope))',
  '? ruleComposition.sanitizeHiddenInformationObservation(rootObservation, observation, barrier, knownCards(envelope), valueOnly ? copyForkData : undefined)');
};
exports.load=mode=>{
 if(!mode.includes('mask-copy'))return;
 const file=path.resolve('randomizer/game/rule-composition.js'),m=new Module(file,module);m.filename=file;m.paths=Module._nodeModulePaths(path.dirname(file));
 assert(!require.cache[file]);m._compile(exports.composition(fs.readFileSync(file,'utf8')),file);m.loaded=true;require.cache[file]=m;
};
