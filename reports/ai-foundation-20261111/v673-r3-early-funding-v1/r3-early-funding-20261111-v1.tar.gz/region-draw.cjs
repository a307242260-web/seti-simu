'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
function replace(s,a,b){assert.equal(s.split(a).length,2,a);return s.replace(a,b);}
exports.residual=s=>{
 s=replace(s,'  function previewQuietAmibaRegion(root, effect) {','  function previewQuietAmibaRegion(root, effect, allowSingleBlindDraw = false) {');
 s=replace(s,`    if(symbols.some(({reward})=>!reward
      ||Object.keys(reward).some(k=>k!=="gain"&&reward[k])`,`    const draw=allowSingleBlindDraw&&symbols.filter(({reward})=>reward?.drawCards===1).length===1;
    if(allowSingleBlindDraw&&!draw)return false;
    if(symbols.some(({reward})=>!reward
      ||Object.keys(reward).some(k=>k!=="gain"&&reward[k]&&!(draw&&k==="drawCards"&&reward[k]===1))`);
 s=replace(s,'    if(!result.ok||result.irreversible)return false;','    if(!result.ok||(draw?result.irreversible?.code!=="hidden_card_draw":result.irreversible))return false;');
 return replace(s,'    return {events:settled.events,history:{type:"card_effect",effectId:card.id||null,','    return {events:settled.events,...(draw?{irreversible:result.irreversible}:{}),history:{type:"card_effect",effectId:card.id||null,');
};
exports.load=mode=>{
 if(!mode.includes('region-draw'))return;
 const file=path.resolve('randomizer/game/effects/residual-domain-session.js'),m=new Module(file,module);m.filename=file;m.paths=Module._nodeModulePaths(path.dirname(file));
 assert(!require.cache[file]);m._compile(exports.residual(fs.readFileSync(file,'utf8')),file);m.loaded=true;require.cache[file]=m;
};
exports.port=(s,mode)=>{
 if(!mode.includes('region-draw'))return s;
 const start=s.indexOf('    function previewQuietAlienDisplay('),end=s.indexOf('    function provedCommittedEnvelope(',start);
 assert(start>=0&&end>start);let span=s.slice(start,end);
 const sub=(a,b)=>{span=replace(span,a,b);};
 sub('      const nextRefill=trace&&s.queue[refillIndex+1];',`      const trigger=region&&tail?.type==="residual_card_decision"&&tail.kind==="decision"
        &&tail.ownerId===seatId&&!tail.allowQuickActions&&tail.payload?.kind==="trigger"
        &&tail.payload?.event?.type==="alienTrace"&&s.queue.length===3
        &&s.workingState.turn.roundNumber===4&&s.journal.actions[0]?.action?.family!=="research_tech";
      const nextRefill=trace&&s.queue[refillIndex+1];`);
 sub('||tail&&!fossil&&!trace&&(', '||tail&&!fossil&&!trace&&!trigger&&(');
 sub('      const meta=fossil||trace||pairedTrigger?state.meta:quietSavedMeta(state.meta,s.baseVersion+1);',
     '      const meta=fossil||trace||pairedTrigger||trigger?state.meta:quietSavedMeta(state.meta,s.baseVersion+1);');
 sub('        aliens:{...state.aliens,[species]:region?structuredClone(deck):{...deck,cardDeck:[...deck.cardDeck]}}};',
 `        aliens:{...state.aliens,[species]:region?structuredClone(deck):{...deck,cardDeck:[...deck.cardDeck]}},
        ...(trigger?{cards:{...state.cards,drawPileCardIds:[...state.cards.drawPileCardIds]}}:{})};
      if(trigger)next.meta.rngState={...state.meta.rngState};`);
 sub('      const regionResult=region&&residualSession.previewQuietAmibaRegion(next,region);','      const regionResult=region&&residualSession.previewQuietAmibaRegion(next,region,Boolean(trigger));');
 sub('      if(fossil){',`      if(trigger){
        if(JSON.stringify(next.meta.rngState)!==JSON.stringify(state.meta.rngState))return null;
        const choices=localPlans.residualCardChoices(next,tail);
        if(!choices.length)return null;
        const drawn={effectId:region.effectId,revision:s.revision+2,...regionResult.irreversible};
        const prepared=prepareQuietTailMenu(stored,action,{state:next,barrier:drawn,drained:2,
          choices,events:[...augmented.events,...regionResult.events],histories:[regionResult.history]});
        ${mode.includes('draw-proof')?'globalThis.regionProof.push({source:stored.envelope,action,target:prepared.envelope,choices,barrier:prepared.barrier});':''}
        return prepared;
      }
      if(fossil){`);
 return s.slice(0,start)+span+s.slice(end);
};
