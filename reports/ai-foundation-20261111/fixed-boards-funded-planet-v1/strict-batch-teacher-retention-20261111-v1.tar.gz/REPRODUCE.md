# 复查固定盘和教学盘证据
Node 22，从 SETI 仓库根目录执行。将压缩包解到 CASE_DIR，然后在该目录运行 `shasum -a 256 -c SHA256SUMS`。

固定盘 20 个自然终局均来自 463fc4423。run-strict-batch.py 保存的是执行方法和 17 个新盘的注册方式；不要为复查而重跑已登记的盘。复查时用原生输入复放：

```sh
node "$CASE_DIR/compare-batch.cjs" reports/iteration/free-analyze-random20-pass-opportunity-20261111/summary-39f19bec-20261111.json reports/iteration/free-analyze-random20-funded-planet-20261111/summary-463fc442-20261111.json "$CASE_DIR/replay-check.json"
```

第三轮末收尾对照先使用上次化石选择证据包中的 cargo-choice-ac4401cf-20261111-v1.json.gz，再执行：

```sh
node "$CASE_DIR/teacher-fossil-07-retention.cjs" "$CASE_DIR/cargo-choice-ac4401cf-20261111-v1.json.gz" "$CASE_DIR/third-round-check.json.gz"
node "$CASE_DIR/teacher-retention-tail.cjs" "$CASE_DIR/third-round-check.json.gz" "$CASE_DIR/fourth-round-check.json.gz"
```

现存同名证据不能被覆盖；源代码与单点门槛见报告。耗时随机器负载变化。
