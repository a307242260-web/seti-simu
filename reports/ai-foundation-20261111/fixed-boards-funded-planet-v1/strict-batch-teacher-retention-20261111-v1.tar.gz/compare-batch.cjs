'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const path=require('node:path');
const scenario=require(path.resolve('tools/research-free-analyze-random20'));
function differences(a,b,trail='',out=[]){
 if(a===b||out.length>=20)return out;
 if(a===null||b===null||typeof a!=='object'||typeof b!=='object'){
  out.push({path:trail,left:typeof a==='object'?null:a,right:typeof b==='object'?null:b});return out;
 }
 for(const k of new Set([...Object.keys(a),...Object.keys(b)]))differences(a[k],b[k],trail+'/'+k,out);
 return out;
}
const [oldPath,newPath,out]=process.argv.slice(2);
const read=p=>JSON.parse(fs.readFileSync(p)),old=read(oldPath),current=read(newPath),rows=[];
assert(old.complete&&current.complete);
for(const r of current.rows){
 const previous=old.rows.find(p=>p.board===r.board);
 const readRecord=f=>read('reports/research/'+f);
 const a=readRecord(previous.f),b=readRecord(r.f),sa=read(a.savePath),sb=read(b.savePath);
 const ma=sa.replaySteps.map(x=>x.action),mb=sb.replaySteps.map(x=>x.action);
 assert.equal(ma.length,a.steps);assert.equal(mb.length,b.steps);
 const cuts=b.roundEnds.slice(0,3).map((cut,i)=>{
  const c=read(cut.checkpointPath),x=read(a.roundEnds[i].checkpointPath);
  assert.deepEqual(c.coreState.compositionEnvelope,x.coreState.compositionEnvelope,'board '+r.board+' round '+cut.round);
  assert.equal(c.replayCursor.stepIndex,x.replayCursor.stepIndex);return c;
 });
 const cursor=cuts[2].replayCursor.stepIndex;
 const config={seed:b.seed,activePlayerCount:b.activePlayerCount,aiDifficulty:b.aiDifficulty,agentType:b.agentType,compactReplay:true};
 const env=scenario.createEnvironment(config,b.scenario);
 try{
  const opening=scenario.initialize(env,config,b.scenario);
  assert.deepEqual(opening.map(x=>x.action),mb.slice(0,opening.length));
  const targets=new Map(cuts.map(c=>[c.replayCursor.stepIndex,c.coreState.compositionEnvelope]));
  for(let i=opening.length;i<mb.length;i++){
   if(targets.has(i))assert.deepEqual(env.createCheckpoint().coreState.compositionEnvelope,targets.get(i));
   const a=mb[i],legal=env.legalActions().find(x=>x.actionId===a.actionId&&x.actorId===a.actorId);
   assert(legal);assert.deepEqual(JSON.parse(JSON.stringify(legal)),a,'board '+r.board+' input '+i);
   const result=env.step(legal);assert(result.ok,result.error);
  }
  const final=env.createCheckpoint().coreState.compositionEnvelope;
  const delta=differences(JSON.parse(final.committedState),JSON.parse(sb.committedState));
  assert(!delta.length,JSON.stringify({board:r.board,delta}));assert.equal(final.session,null);
  assert.equal(JSON.parse(final.committedState).match.finalScores.find(x=>x.playerId==='player-white').totalScore,r.score);
 }finally{env.dispose();}
 const diff=mb.findIndex((x,i)=>JSON.stringify(x)!==JSON.stringify(ma[i]));
 if(diff<0)assert.equal(ma.length,mb.length);
 else assert(diff>=cursor);
 rows.push({board:r.board,before:previous.score,after:r.score,delta:r.score-previous.score,rounds1to3NativeEqual:true,
  independentlyReplayedInputs:mb.length,terminalStateSessionRngExact:true,
  firstChange:diff>=0?{input:diff+1,old:ma[diff]?.summary,new:mb[diff].summary}:null});
}
const deltas=rows.filter(r=>r.delta),changed=rows.filter(r=>r.firstChange);
const result={before:old.head,after:current.head,meanBefore:old.all20Average,meanAfter:current.all20Average,
  improved:deltas.filter(r=>r.delta>0).length,worse:deltas.filter(r=>r.delta<0).length,
  actionsChanged:changed.length,rounds1to3NativeEqual:rows.length,
  independentlyReplayedInputs:rows.reduce((sum,r)=>sum+r.independentlyReplayedInputs,0),rows};
assert.equal(rows.length,20);
fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({...result,rows:changed}));
