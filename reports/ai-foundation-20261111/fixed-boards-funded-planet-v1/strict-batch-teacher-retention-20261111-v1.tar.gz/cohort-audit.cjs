'use strict';
const fs=require('node:fs'),path=require('node:path'),a=require('node:assert/strict');
const [repo,head,out]=process.argv.slice(2),p=path.join(repo,'reports/research'),read=f=>JSON.parse(fs.readFileSync(f)),rows=[];
const catalog=read(path.join(repo,'reports/fixed-boards/free-analyze-random20-20261104-v1.json')).boards;
for(const f of fs.readdirSync(p).filter(s=>s.endsWith('.'+head.slice(0,8)+'.full.json'))){
 const r=read(path.join(p,f));if(r.scenario?.id!=='free-analyze-random20-guarded-v1')continue;
 const n=r.scenario.boardNumber,board=catalog.find(b=>b.number===n);
 a(board&&r.seed===board.seed);a(!rows.some(x=>x.board===n));a.equal(r.gitCommit.slice(0,8),head.slice(0,8));
 if(!r.terminal){rows.push({board:n,f,terminal:false,steps:r.steps,failure:r.failure});continue;}
 a(!r.resumedFrom&&!r.resumeStep);a(Number.isFinite(r.wallMs)&&r.wallMs<180000);
 a.deepEqual(r.scenario.decisionGate,{nativeInputs:256,milliseconds:600,enforcement:'reject-before-input'});
 a(Number.isFinite(r.summary.scores['player-white']));
 const decisionLines=fs.readFileSync(path.join(p,f+'.decisions.jsonl'),'utf8').trim().split('\n');
 let peakInputs=0,peakMs=0,white=0;
 for(const line of decisionLines){const x=JSON.parse(line);if(x.context?.seatId!=='player-white')continue;
  white++;
  const q=x.search;if(!q)continue;
  a(q.complete);a(Number.isFinite(q.diagnostics.nativeExecutions)&&q.diagnostics.nativeExecutions<=256);
  a(Number.isFinite(q.rootAndSearchMilliseconds)&&q.rootAndSearchMilliseconds<=600);
  peakInputs=Math.max(peakInputs,q.diagnostics.nativeExecutions);peakMs=Math.max(peakMs,q.rootAndSearchMilliseconds);
 }
 a(white>0&&peakInputs>0);
 rows.push({board:n,f,terminal:true,score:r.summary.scores['player-white'],wallMs:r.wallMs,steps:r.steps,peakInputs,peakMs,
  rounds:r.roundEnds.map(x=>({r:x.round,score:x.score,projected:x.projectedFinalScore,tech:Object.keys(x.technology.ownedTiles||{}),
   resources:x.resources,income:x.income,hand:Array.isArray(x.hand)?x.hand.length:x.hand.count}))});
}
rows.sort((x,y)=>x.board-y.board);
const finished=rows.filter(x=>x.terminal),sorted=finished.map(x=>x.score).sort((x,y)=>x-y);
const average=xs=>xs.length?xs.reduce((a,b)=>a+b,0)/xs.length:null;
const complete=rows.length===catalog.length&&finished.length===catalog.length;
const result={head,attempted:rows.length,finished:finished.length,complete,
 all20Average:complete?average(sorted):null,partialAverage:!complete?average(sorted):null,
 min:sorted[0],max:sorted.at(-1),median:average(sorted.slice((sorted.length-1)>>1,(sorted.length>>1)+1)),
 maxGameMs:Math.max(0,...finished.map(x=>x.wallMs)),maxInputs:Math.max(0,...finished.map(x=>x.peakInputs)),maxMs:Math.max(0,...finished.map(x=>x.peakMs)),
 rows};
if(out)fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({...result,rows:rows.map(x=>x.terminal?[x.board,x.score,Math.round(x.wallMs/100)/10]:[x.board,'failed',x.steps])}));
