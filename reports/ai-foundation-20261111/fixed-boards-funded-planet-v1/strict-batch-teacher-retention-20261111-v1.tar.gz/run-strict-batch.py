from pathlib import Path
import json, re, subprocess, sys, time
out=Path(sys.argv[1]); manifest=out/'batch-checkpoint-463fc442-20261111-v1.json'
src='463fc4423'; catalog=Path('reports/fixed-boards/free-analyze-random20-20261104-v1.json')
boards={row['number']:row['seed'] for row in json.loads(catalog.read_text())['boards']}
initial=json.loads((out/'initial-records-20261111-v1.json').read_text())
def write(rows):
 tmp=manifest.with_suffix('.tmp')
 tmp.write_text(json.dumps({'source':src,'rows':sorted(rows,key=lambda r:r['board'])},ensure_ascii=False,indent=2)+'\n')
 tmp.replace(manifest)
rows=[]
def resolve(n,name,file,reused=False):
 p=Path('reports/research')/file
 d=json.loads(p.read_text())
 assert d['gitCommit']==src and d['seed']==boards[n] and d['scenario']['boardNumber']==n
 assert d['scenario']['id']=='free-analyze-random20-guarded-v1'
 score=d['summary']['scores']['player-white'] if d['terminal'] else None
 searches=d.get('metrics',{}).get('searches',[])
 r={'board':n,'id':name,'record':file,'reused':reused,'terminal':d['terminal'],'score':score,'wallMs':d['wallMs'],
  'rounds':[x['score'] for x in d['roundEnds']], 'peak':[max((s['diagnostics']['nativeExecutions'] for s in searches),default=0),
   max((s['rootAndSearchMilliseconds'] for s in searches),default=0)],'steps':d['steps']}
 if d.get('failure'):r['failure']=d['failure']
 if d['terminal']:
  assert d['wallMs']<180000 and all(s['complete'] and not s['unresolved'] and s['diagnostics']['nativeExecutions']<=256
   and s['rootAndSearchMilliseconds']<=600 for s in searches)
  assert Path(d['savePath']).is_file() and len(r['rounds'])==4
 return r
for item in initial:
 if item['board']:rows.append(resolve(item['board'],item['id'],item['record'],True))
write(rows)
for n,seed in sorted(boards.items()):
 if any(x['board']==n for x in rows):continue
 name=f'free-analyze-funded-planet-20261111-{n:02d}'
 baseline=f'free-analyze-random20-pass-opportunity-20261111-{n:02d}'
 cmd=['node','tools/robot_iterate.js','run','--name',name,'--baseline',baseline,'--summary','固定20盘同策略严格验收：仅白席行动',
      '--config','agentType=search,scenario=free-analyze-random20-guarded-v1,compactReplay=true','--full','--seed',seed]
 log=out/(name+'.log'); filename=None; report_ready=False
 print(json.dumps({'started':n,'name':name}),flush=True)
 with log.open('x') as output:
  with subprocess.Popen(cmd,stdout=output,stderr=subprocess.STDOUT,start_new_session=True) as p:
   while True:
    s=log.read_text(errors='replace')
    m=re.search(r'\[登记\][^\n]*\n\s+记录: reports/research/([^\s]+\.json)',s)
    if m:
     filename=m[1]
     html=Path('reports/iteration')/name/(filename[:-5]+'.action-log.html')
     if html.is_file() and '</html>' in html.read_text(errors='replace')[-200:]:
      if p.poll() is None:p.terminate()
      report_ready=True
      break
    if p.poll() is not None:break
    time.sleep(.4)
 if not report_ready and not filename:
  failed=[x for x in Path('reports/research').glob(f'*.{src[:8]}.full.json') if json.loads(x.read_text()).get('name')==name]
  assert len(failed)<=1
  if failed:filename=failed[0].name
 if filename:
  row=resolve(n,name,filename);rows.append(row);write(rows)
  print(json.dumps(row,ensure_ascii=False),flush=True)
 if not report_ready or not rows[-1]['terminal']:
  print(s[-3300:],flush=True)
  sys.exit(1)
