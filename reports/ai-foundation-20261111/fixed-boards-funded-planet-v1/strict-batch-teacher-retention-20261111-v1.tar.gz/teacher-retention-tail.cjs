'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [input,out]=process.argv.slice(2),rows=[],roots=[];
const pass=q=>q.complete&&q.a&&q.n<=256&&q.ms<=600;
const score=m=>m.state().turn.gameEnded?m.state().match.finalScores.find(p=>p.playerId==='player-white'):null;
for(const c of readZ(input).rows.filter(c=>['hold','blue4-income'].includes(c.label))){
 for(const card of ['b_111.webp','b_32.webp']){
  const m=open(c.end),setup=[];
  try{
   setup.push(m.act('pass'),m.act('choose_card',a=>a.summary===card));
   if(m.menu()[0].actorId!=='player-white')m.advanceOpponents(setup);
   const start=m.save(),q=m.automatic();
   const first={n:q.n,ms:q.ms,a:q.a?.summary,complete:q.complete};
   roots.push({label:c.label,card,root:c.end,setup,start,first,q});
   console.log(JSON.stringify([c.label,card,'first',first]));
  }finally{m.dispose();}
 }
}
if(roots.every(r=>pass(r.q)))for(const r of roots){
 const m=open(r.start),accepted=[],roundActions=[];
 try{
  let stop,cp;
  for(let i=0;i<170;i++){
   if(score(m)){stop='terminal';break;}
   if(m.menu()[0].actorId!=='player-white'){
    const extras=[];m.advanceOpponents(extras);accepted.push(...extras.map(action=>({action})));continue;
   }
   const q=i===0?r.q:m.automatic(cp);
   if(!pass(q)){stop={n:q.n,ms:q.ms,a:q.a?.summary,complete:q.complete};break;}
   if(q.a.phase==='main'||q.a.family==='pass')roundActions.push({a:q.a.summary,before:short(m)});
   cp=q.checkpoint;accepted.push({action:m.apply(q.a),n:q.n,ms:q.ms});
  }
  assert(stop);const end=m.save(),terminal=score(m),assets=short(m);
  m.restore(r.root);r.setup.forEach(m.apply);accepted.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),end);
  const peak=[Math.max(0,...accepted.map(x=>x.n||0)),Math.max(0,...accepted.map(x=>x.ms||0))];
  rows.push({label:r.label,card:r.card,roundActions,accepted,end,terminal,assets,stop,peak});
  console.log(JSON.stringify({label:r.label,card:r.card,score:terminal?.totalScore,stop,peak,actions:accepted.length}));
 }finally{m.dispose();}
}
writeZ(out,{roots,rows});
