'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [source,out]=process.argv.slice(2), r=readZ(source).rows.find(x=>x.label==='07 / leave-on-board');
const m=open(r.state), rows=[];
const cases=[['hold',null],['blue4-hold','trace:1:blue:amiba:4'],['blue4-income','trace:1:blue:amiba:4'],
 ['blue7-blind-hold','trace:2:blue:chong:7'],['blue8-visible-hold','trace:2:blue:chong:8']];
try{
 for(const [label,trace] of cases){
  const inputs=[],cut=m.save();
  const act=(...a)=>inputs.push(m.act(...a)),place=i=>{act('place_data');act('choose_target',a=>a.summary==='第一排放置位 '+i);};
  if(trace){
   place(6);act('analyze');act('choose_target',a=>a.target.choiceId===trace);
   if(m.menu()[0].family==='choose_card')act('choose_card',a=>a.target.choiceId.includes(':display:'));
   if(label==='blue4-income'){
    inputs.push(m.corner('chong_8.webp'));
    act('quick_trade',a=>a.summary==='3宣传 → 精选1张牌');
    inputs.push(m.pick('dlc_15.png'),m.corner('dlc_15.png'));
    for(const i of [1,2,3,4])place(i);
    act('choose_card',a=>a.summary==='收入 amiba_9.webp');
   }
   act('end_turn');const extra=[];m.advanceOpponents(extra);inputs.push(...extra);
  }
  const menu=m.menu();assert(menu.some(a=>a.family==='pass')&&m.facts().round===3);
  const end=m.save(),assets=short(m);
  assert(assets.probes.some(x=>x[2]==='fossil_07'));
  m.restore(cut);inputs.forEach(m.apply);assert.deepEqual(m.save(),end);m.restore(cut);
  rows.push({label,root:cut,inputs,end,assets});
  console.log(JSON.stringify({label,steps:inputs.length,assets}));
 }
}finally{m.dispose();}
writeZ(out,{rows});
