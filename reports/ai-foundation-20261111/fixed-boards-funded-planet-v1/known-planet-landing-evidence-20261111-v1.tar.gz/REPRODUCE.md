# 复核末轮普通行星登陆
在包含 V68 的仓库根目录用 Node 22 执行。将本包解到 CASE_DIR，执行 `shasum -a 256 -c SHA256SUMS`，再运行：

```sh
node "$CASE_DIR/verify-funded-planet.cjs" "$CASE_DIR/trial-c972265c-20261111-v1.json.gz" "$CASE_DIR/verify-new.json.gz"
```

包内有九个原生存档、同根首选、已完成的后续及正式复核。运行脚本不会访问旧全局记录。计时随负载变化。
