'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,writeZ}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const probe=require(path.resolve('randomizer/game/ai/probe-capital'));
const cards=require(path.resolve('randomizer/game/cards/deck'));
const values=require(path.resolve('randomizer/game/ai/state-value'));
const [input,out]=process.argv.slice(2), seat='player-white', weights=values.DEFAULT_WEIGHTS;
const rows=[];
const snapshot=(m)=>m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore;
for(const expected of readZ(input).rows){
 const m=open(expected.root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 const agent=createSearchAgent({analysisPort:port,seatId:seat}),checks=[],accepted=[];
 try{
  let checkpoint,quote,control=null,controlledEnd,graphPolicyDifferences=0;
  for(let i=0;i<(expected.accepted?80:1);i++){
   if(snapshot(m)!==undefined)break;
   if(m.menu()[0].actorId!==seat){m.advanceOpponents(accepted);continue;}
   const before=m.save(),menu=m.menu();agent.loadCheckpoint(checkpoint);
   const q=agent.decide({seatId:seat,legalActions:menu}).search;
   assert.deepEqual(m.save(),before);
   assert(q.complete&&!q.unresolved.length&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600);
   checks.push({inputs:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,actionId:q.actionId});
   if(!quote){
    quote=q;
    assert.equal(q.actionId,expected.new[0]);assert.equal(q.value,expected.new[1]);assert.equal(q.diagnostics.nativeExecutions,expected.new[2]);
    const actual=JSON.parse(JSON.stringify(q.lines));
    graphPolicyDifferences=actual.filter((line,j)=>JSON.stringify(line)!==JSON.stringify(expected.graph[j])).length;
    const outcomes=list=>list.map(n=>[n.node,n.status,n.value,n.realization,n.edges.map(e=>[e.actionId,e.target,e.steps])]);
    assert.deepEqual(outcomes(actual),outcomes(expected.graph));
   }
   if(!expected.accepted)break;
   checkpoint=agent.createCheckpoint();
   const a=menu.find(x=>x.actionId===q.actionId);assert(a);
   if(a.family==='end_turn'&&!control){
    const s=m.state(),p=m.player(),facts=probe.factsFromState(s,p),publicFacts=probe.factsFromObservation(m.owner(seat),seat);
    const full=probe.quote({...facts,investment:()=>0,initialInvestmentCapital:0},weights);
    const selected=full.selected;
    assert.equal(selected.planet,'mercury');assert.equal(selected.value,12);assert.deepEqual(selected.payment.spend,{credits:0,energy:1});
    const ids=selected.payment.cornerCardIds;assert.equal(ids.length,2);
    assert.equal(probe.quoteFinalRoundValue(facts,weights),12);
    assert.equal(probe.quoteFinalRoundValue(publicFacts,weights),12);
    assert.equal(values.evaluateStateValue(m.owner(seat),seat).components.probePotential,12);
    const swap=probe.prepareFinalRoundSwapMission(s,p);assert.equal(swap.quote(p.hand,s.cards.publicCards),12);
    const moveIds=p.hand.filter(c=>cards.getDiscardActionMoveRewardForCard(c)?.movementPoints===1).map(c=>c.id);
    assert(moveIds.length>=2);
    const negative=[];
    for(const remaining of moveIds){
     const absent=moveIds.filter(id=>id!==remaining);
     const hand=p.hand.filter(c=>!absent.includes(c.id));
     const weak=probe.factsFromState(s,{...p,hand}), without=probe.quoteFinalRoundValue(weak,weights);
     assert(without<12);assert.equal(swap.quote(hand,s.cards.publicCards),without);
     const hidden=facts.hand.map(c=>absent.includes(c.id)?{...c,hidden:true}:c);
     const obscured=probe.quoteFinalRoundValue({...facts,hand:hidden},weights);
     assert(obscured<12);assert.equal(swap.quote(hidden,s.cards.publicCards),obscured);
     negative.push({remaining,without,hidden:obscured});
    }
    const notFunded={...facts,player:{...facts.player,energy:0,credits:0}};
    assert.equal(probe.quoteFinalRoundValue(notFunded,weights),0);
    control={selected,negative,sourceUnchanged:true};assert.deepEqual(m.save(),before);
   }
   accepted.push(m.apply(a));
  }
  if(expected.accepted){
   controlledEnd=m.save();assert.equal(snapshot(m),expected.score);assert.deepEqual(accepted,expected.accepted);assert.deepEqual(controlledEnd,expected.end);
   m.restore(expected.root);accepted.forEach(m.apply);assert.deepEqual(m.save(),controlledEnd);
  }
  rows.push({key:expected.key,first:quote.actionId,value:quote.value,checks,accepted,score:snapshot(m),control,controlledEnd,graphPolicyDifferences});
  console.log(JSON.stringify({key:expected.key,first:quote.actionId,value:quote.value,inputs:checks.length,
   graphPolicyDifferences,peak:[Math.max(...checks.map(x=>x.inputs)),Math.round(Math.max(...checks.map(x=>x.ms)))],score:snapshot(m)}));
 }finally{port.close();m.dispose();}
}
assert.equal(rows.length,9);assert.equal(rows[0].score,121);writeZ(out,{rows});
