'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [retain,early,out]=process.argv.slice(2),prior=readZ(early).results.filter(r=>r.name==='A5-first/4分/swap-B16');
const rows=[];
for(const [ix,row] of readZ(retain).entries()){
 const baseline=prior[ix],kept=open(row.root),spent=open(baseline.root);
 const sequence=[],recorded=[];let stop=null,cp=row.cp;
 try{
  const first=kept.facts().turn,root=short(kept),cert=cp.plan.rows;
  for(let i=0;i<70;i++){
   const m=kept.menu(),f=kept.facts();
   if(f.turn!==first&&!kept.save().session){if(m[0].actorId!=='player-white'){const a=[];kept.advanceOpponents(a);sequence.push(...a.map(action=>({action,passive:true})));}break;}
   const expected=cert[i]?.actionId;
   if(i===0){sequence.push({fixed:true,action:kept.apply(m.find(a=>a.actionId===expected))});continue;}
   const q=kept.automatic(cp);
   if(!q.complete||q.n>256||q.ms>600||expected&&q.a.actionId!==expected){
    stop={i,expected,got:q.a?.actionId,n:q.n,ms:q.ms};break;
   }
   cp=q.checkpoint;sequence.push({action:kept.apply(q.a),n:q.n,ms:q.ms,value:q.value});
  }
  const after=kept.save(),assets=short(kept),detail=kept.facts();
  let start;
  for(const {action} of baseline.actions){
   const m=spent.menu();
   if(!start&&action.family==='card_corner'&&m[0].actorId==='player-white'&&spent.facts().round===4){start=spent.save();assert.equal(spent.facts().turn,first);}
   if(start&&spent.facts().turn!==first&&!spent.save().session&&m[0].actorId==='player-white')break;
   spent.apply(action);recorded.push(action);
  }
  assert(start);
  const baseAfter=spent.save(),baseAssets=short(spent),baseDetail=spent.facts();
  kept.restore(row.root);sequence.forEach(y=>kept.apply(y.action));assert.deepEqual(kept.save(),after);
  spent.restore(baseline.root);recorded.forEach(a=>spent.apply(a));assert.deepEqual(spent.save(),baseAfter);
  console.log(JSON.stringify({card:baseline.card,stop,root,assets,baseAssets,n:sequence.length,baseInputs:recorded.length,
   peak:[Math.max(...sequence.map(a=>a.n||0)),Math.max(...sequence.map(a=>a.ms||0))]}));
  rows.push({card:baseline.card,stop,root:row.root,baseRoot:start,sequence,recorded,after,baseAfter,assets,baseAssets,detail,baseDetail});
 }finally{kept.dispose();spent.dispose();}
}
writeZ(out,rows);
