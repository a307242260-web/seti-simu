从 Production cbd73e00c98455dac868bd43be3e1759130088a7 的独立快照根目录运行。A 为本归档解包绝对目录。输出文件事先不能存在。不改变工作树源代码。

    node "$A/first-turn.cjs" "$A/predecessor.json.gz" "$A/prior-fourth.json.gz" "$A/replayed-first-turn.json.gz"
    SETI_SCAN_PRIOR="$A/prior.cjs" node "$A/prove-trade.cjs" bound-move-join-route-yellow-copy-income-skip-restore-copy-scan-fixed-cash "$A/predecessor.json.gz" "$A/replayed-trade-witnesses.json.gz"

第一条是受控的第四轮首回合对照：留牌线固定超限的第一个角标，之后每次用正式策略导入可恢复计划；先插电线只原生重放旧记录到相同轮内边界。第二条从每条独立前态验证所有固定钱换电输入，保留原始候选图和计划证书。

独立进程冷启动时分别指定 SETI_R4_CARD=b_111.webp 和 b_32.webp：

    SETI_R4_CARD=b_111.webp SETI_SCAN_PRIOR="$A/prior.cjs" node "$A/bind-trade.cjs" bound-move-join-route-yellow-copy-income-skip-restore-copy-scan-fixed-cash "$A/profile2.json.gz" "$A/replayed-b111-cold.json.gz"

B32 使用同命令换卡和输出路径。运行耗时不要求逐次相等。trade.log 仅为候选分根实测；proof-cash.log 含采样和逐项验证开销，不能作冷启动速度验收。
