'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),Module=require('node:module');
require('./perf.cjs').setup(process.argv[2]);
const {open,readZ,writeZ}=require('./controlled-r3'),prepare=require('./reuse-scan.cjs');
const [mode,input,out]=process.argv.slice(2),src=path.resolve('randomizer/game/ai/analysis-port.js');
const mod=new Module(src,module);mod.filename=src;mod.paths=Module._nodeModulePaths(path.dirname(src));
let code=prepare(fs.readFileSync(src,'utf8'),require(process.env.SETI_SCAN_PRIOR));
function sub(a,b){assert.equal(code.split(a).length,2,a);code=code.replace(a,b);}
if(mode.includes('test')){
 const anchor='a.actionId===deferredCappedTask?.actionId||scoredCorner&&a.family==="end_turn"';
 const pre='||state.turn.roundNumber===4&&!owner.mainActionCompleted&&a.family==="industry"&&a.target?.abilityId==="deepspace_swap_cards"';
 const condition=mode==='test-data'?'&&cardPick?.companySwap?.goal.kind==="data"':mode==='test-data-income'?'&&(cardPick?.companySwap?.goal.kind==="data"||cardPick?.companySwap?.goal.kind==="move"&&plans.some(p=>p.goal.kind==="income"))':'&&cardPick?.companySwap?.goal.kind==="move"&&plans.some(p=>p.goal.kind==="income")';
 sub(anchor,anchor+pre+condition);
}
if(mode.includes('blue')){
 const anchor='      const plans=[];\n      if(node===openedRoot&&state.turn.roundNumber===3){';
 sub(anchor,'      if(state.turn.roundNumber===4&&!state.players.players.find(p=>p.id===seatId).mainActionCompleted)goals=goals.filter(g=>g.kind!=="blue-data");\n'+anchor);
}
if(mode==='income'){
 const anchor='      const plans=[];\n      if(node===openedRoot&&state.turn.roundNumber===3){';
 sub(anchor,'      if(state.turn.roundNumber===4&&!state.players.players.find(p=>p.id===seatId).mainActionCompleted)goals=goals.filter(g=>g.kind!=="income");\n'+anchor);
}
if(mode.includes('bound')){
 const end='      return{complete:true,node:current,submissions:prefixes.length,prefixes,fixedChoices};';
 sub(end,`      const intent=cardPickSpec(node)?.companySwap,begin=prefixes[0]?.action;
      if(begin?.family==="industry"&&begin.target?.abilityId==="deepspace_swap_cards"
        &&intent?.reason==="current-purpose-company-swap"&&["data","move"].includes(intent.goal.kind)&&current.status==="stable"
        &&readPlanningState(nodes.get(node)).turn.roundNumber===4){
        const after=resourceSpec(current),selected=nodes.get(current),state=readPlanningState(selected),
          actor=state.players.players.find(p=>p.id===seatId),incoming=actor.hand.find(c=>c.id===intent.selection.cardId);
        const funded=after?.plans.filter(p=>intent.goal.kind==="data"
          ?p.goal.kind==="analyze"&&p.goal.id===intent.goal.id
          :${mode.includes("move")}&&p.goal.kind==="route"&&p.goal.movementPoints+p.goal.endpointCost.energy>actor.resources.energy
            &&cards.getDiscardActionMoveRewardForCard(incoming)?.movementPoints>0);
        const additional=intent.goal.kind==="data"
          ?after?.plans.filter(p=>${mode.includes("research")}&&p.goal.kind==="effect-purpose"&&p.goal.cardId===incoming?.id
            ||p.goal.kind==="blue-data"&&p.goal.blueSlot===1&&after.plans.some(x=>x.goal.kind==="income")):[];
        globalThis.boundStats.push([intent.goal.id,after?.plans.map(p=>p.id),funded?.length]);
        if(funded?.length===1){
          if(additional.length)resourceSpecs.set(current,freeze({...after,plans:[funded[0],...additional.map(p=>({...p,goal:{...p.goal,companyIncomeFrom:intent.selection.cardId}}))],retainedActionIds:[],
            excludedActionIds:current.legalActions.map(a=>a.actionId)}));
          else current=resourceView(current,{goal:funded[0].goal,operation:funded[0].operation});
        }
      }
`+end);
}
if(mode.includes('join')){
 const anchor='      const finish=(extra={})=>({complete:true,node:current,submissions:prefixes.length,prefixes,contexts,preparations,goal:plan.goal,sharedPath,sharedStates,newSubmissions,...extra});';
 sub(anchor,`      function finish(extra={}){
        if(plan.goal.companyIncomeFrom&&extra.goalStatus==="completed"&&current.status==="stable"){
          const meta=plan.goal.companyIncomeFrom,after=resourceSpec(current);
          const candidate=plan.goal.kind==="blue-data"
            ?after?.plans.find(p=>p.goal.kind==="income"&&current.legalActions.some(a=>a.actionId===p.firstActionId
              &&a.family==="card_corner"&&a.target.cardInstanceId===meta))
            :${mode.includes("route")}?after?.plans.find(p=>p.goal.kind==="route"):null;
          if(candidate){
            const blocked=hasCapacity(prefixes.length,contexts+1,false,work({additionalStates:1}));
            if(blocked)return{complete:false,stopReason:blocked,node:current,submissions:prefixes.length,prefixes,contexts,preparations,goal:plan.goal,sharedPath,sharedStates,newSubmissions};
            current=resourceView(current,{goal:{...candidate.goal,...(plan.goal.kind==="blue-data"?{companyIncomeFrom:meta}:{})},operation:candidate.operation});
            sharedStates.push(current);contexts++;
          }
        }
        return {complete:true,node:current,submissions:prefixes.length,prefixes,contexts,preparations,goal:plan.goal,sharedPath,sharedStates,newSubmissions,...extra};
      }`);
}
if(mode.includes('yellow'))code=require('./reuse-yellow2.cjs')(code);
if(mode.includes('fixed-cash'))code=require('./quiet-trade.cjs')(code,true);
mod._compile(require('./perf.cjs').port(code,mode),src);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const data=readZ(input),results=[];
let proof=[];
globalThis.captureTrade=(s,a,t,c)=>proof.push({source:s.envelope,action:a,target:t.envelope,
  legal:c.legalActions.map(a=>[a.actionId,a.family,a.target]),status:c.status,boundary:c.boundary});
const fields=['actionId','value','realization','preparationDebt','complete','roots','lines','unresolved','selectionPlan','candidates','sharedPrefixGraph'];
for(const r of data){
 const m=open(r.root),seatId='player-white',port=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
 try{
  globalThis.boundStats=[];proof=[];
  const agent=createSearchAgent({seatId,analysisPort:port}),q=agent.decide({seatId,legalActions:m.menu()}).search,cp=agent.createCheckpoint();
  assert.deepEqual(m.save(),r.root);
  const actual=JSON.parse(JSON.stringify(q));
  
  for(const key of fields)assert.deepEqual(actual[key],r.q[key],key);
  assert.deepEqual(cp.plan.rows,r.cp.plan.rows);
  assert.equal(proof.length,r.q.diagnostics.nativeExecutions-q.diagnostics.nativeExecutions);
  for(const w of proof){
   assert.equal(w.source.session,null);assert.equal(w.target.session,null);
   assert(m.c.lifecycle.restore(w.source).ok);
   assert.deepEqual(JSON.parse(m.save().committedState),JSON.parse(w.source.committedState));m.apply(w.action);
   const n=m.save();assert.deepEqual(JSON.parse(n.committedState),JSON.parse(w.target.committedState));
   assert.equal(n.session,null);
   const legal=m.menu().map(a=>[a.actionId,a.family,a.target]);
   assert(w.legal.every(a=>legal.some(b=>JSON.stringify(a)===JSON.stringify(b))));
   if(!w.boundary)assert.deepEqual(w.legal,legal);
  }
  m.restore(r.root);
  console.log(JSON.stringify({proof:proof.length,mode,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,delta:r.q.diagnostics.nativeExecutions-q.diagnostics.nativeExecutions,complete:q.complete,nodes:q.diagnostics.nodes,roots:q.roots.length,value:q.value,details:globalThis.boundStats.map(a=>[a[0],a[2]]),action:m.menu().find(a=>a.actionId===q.actionId).summary}));
  results.push({mode,root:r.root,q,cp,proof});
 }finally{port.close();m.dispose();}
}
writeZ(out,results);
