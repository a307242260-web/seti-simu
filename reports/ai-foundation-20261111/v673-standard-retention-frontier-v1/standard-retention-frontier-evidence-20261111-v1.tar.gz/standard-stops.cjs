'use strict';
const path=require('node:path'),assert=require('node:assert/strict'),{open,writeZ,short}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),read=f=>require(path.resolve(dir,f));
const record=read('reports/research/d3183131.cbd73e00.quick-400.json'),saved=read(record.savePath);
const second=record.roundEnds[1],m=open(read(second.checkpointPath).coreState.compositionEnvelope),rows=[];
const cuts=new Map([[235,'hold-before-amiba5'],[242,'hold-before-analysis'],[245,'hold-after-analysis'],[247,'hold-one-data-corner'],[254,'hold-before-income-slot'],[258,'standard']]);
try{
 for(let i=second.beforeInput;i<=258;i++){
  if(cuts.has(i)){
   const parent=m.save(),actions=[];
   if(!m.menu().some(a=>a.family==='pass'))actions.push(m.act('end_turn'));
   assert(m.menu().some(a=>a.family==='pass'));
   const settled={state:m.save(),summary:short(m)},options=[];
   m.act('pass');options.push(...m.menu().filter(a=>a.family==='choose_card').map(a=>a.summary));
   m.restore(parent);actions.forEach(m.apply);assert.deepEqual(m.save(),settled.state);m.restore(parent);
   console.log(JSON.stringify([cuts.get(i),settled.summary,options]));rows.push({label:cuts.get(i),parent,actions,settled,options});
  }
  m.apply(saved.replaySteps[i-1].action);
 }
}finally{m.dispose();}
writeZ(out,{rows});
