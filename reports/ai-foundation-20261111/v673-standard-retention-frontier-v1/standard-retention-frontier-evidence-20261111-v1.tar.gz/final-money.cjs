'use strict';
const path=require('node:path');
const {open,runCases,writeZ,short}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),read=f=>require(path.resolve(dir,f));
const record=read('reports/research/d3183131.cbd73e00.quick-400.json'),saved=read(record.savePath);
const second=record.roundEnds[1],m=open(read(second.checkpointPath).coreState.compositionEnvelope);
for(let i=second.beforeInput;i<245;i++)m.apply(saved.replaySteps[i-1].action);
const root=m.save(),facts=short(m);m.dispose();
const cards=['dlc_15.png','dlc_25.png','dlc_17.png','amiba_2.webp'];
const cases=[];
for(const card of ['amiba_2.webp','dlc_17.png','dlc_25.png']){
 const others=cards.filter(c=>c!==card);
 for(let i=0;i<others.length;i++)for(let j=i+1;j<others.length;j++){
  const pair=[others[i],others[j]];
  cases.push([card+'/'+pair.join('+'),h=>{
    h.act('quick_trade',a=>a.target.tradeId==='cards-for-credit');
    for(const id of pair)h.act('choose_payment',a=>a.summary===id);
    h.act('choose_payment',a=>a.summary.startsWith('确认'));h.act('end_turn');
    h.take(h.m.play(card));
  }]);
 }
}
writeZ(out,{root,facts,...runCases(root,cases)});
