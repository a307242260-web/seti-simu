Use Node 22 from the V673 repository root (source cbd73e00c; the final registration also contains the official inputs). Extract these files together. Existing outputs are rejected. Gated autonomous paths do not submit the over-budget action. The B9 preview instruments a private module and never changes the repository source.

```sh
proof=/path/to/this/archive
base=$PWD
r3=reports/research/d3183131.cbd73e00.quick-400.json.round-end-3.checkpoint.json
node "$proof/visible-handoffs.cjs" "$base" /tmp/v673-visible-handoffs.json.gz
node "$proof/early-main.cjs" "$base" /tmp/v673-early-main.json.gz
node "$proof/first-scan-wallet.cjs" "$base" /tmp/v673-first-scan-wallet.json.gz
node "$proof/final-money.cjs" "$base" /tmp/v673-final-money.json.gz
node "$proof/next-fourth.cjs" /tmp/v673-visible-handoffs.json.gz "$r3" /tmp/v673-visible-fourth.json.gz
node "$proof/standard-stops.cjs" "$base" /tmp/v673-stops.json.gz
node "$proof/stops-fourth.cjs" /tmp/v673-stops.json.gz "$r3" /tmp/v673-stops-fourth.json.gz
node "$proof/first-decision-profile.cjs" /tmp/v673-stops-fourth.json.gz /tmp/v673-stop-profile.json.gz
node "$proof/try-b9.cjs" /tmp/v673-stop-profile.json.gz /tmp/v673-stop-b9.json.gz
```

Runs are serial per script. For comparable watchdog timings do not run unrelated workloads. The duplicate B16/no-swap row is a control, not an independent state. Infeasible forced preparations are retained separately from gate stops and natural results.
