'use strict';
const path=require('node:path');
const {open,runCases,writeZ,short}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),read=f=>require(path.resolve(dir,f));
const record=read('reports/research/d3183131.cbd73e00.quick-400.json'),saved=read(record.savePath);
const second=record.roundEnds[1],m=open(read(second.checkpointPath).coreState.compositionEnvelope);
for(let i=second.beforeInput;i<223;i++)m.apply(saved.replaySteps[i-1].action);
const root=m.save(),facts=short(m);m.dispose();
const cases=[];
const families={
 'b_16.webp':[['dlc_20.png','dlc_25.png'],['dlc_20.png','amiba_9.webp'],['amiba_5.webp','dlc_20.png'],['amiba_9.webp','dlc_25.png']],
 'amiba_5.webp':[['b_16.webp','dlc_20.png'],['b_16.webp','dlc_25.png'],['dlc_20.png','amiba_9.webp'],['dlc_20.png','dlc_25.png']],
 'dlc_20.png':[['amiba_9.webp','amiba_5.webp'],['b_16.webp','amiba_9.webp'],['b_16.webp','dlc_25.png'],['amiba_9.webp','dlc_25.png']],
};
for(const [card,pairs] of Object.entries(families))for(const pair of pairs)
cases.push([card+' / '+pair.join('+'),h=>{
 h.act('quick_trade',a=>a.target.tradeId==='cards-for-credit');
 for(const discard of pair)h.act('choose_payment',a=>a.summary===discard);
 h.act('choose_payment',a=>a.summary.startsWith('确认'));
 h.take(h.m.play(card));
}]);
writeZ(out,{root,facts,...runCases(root,cases)});
