'use strict';
const path=require('node:path'),assert=require('node:assert/strict');
const {open,runCases,writeZ,short}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),read=f=>require(path.resolve(dir,f));
const record=read('reports/research/d3183131.cbd73e00.quick-400.json'),saved=read(record.savePath);
const action=n=>saved.replaySteps[n-1].action;
const second=record.roundEnds[1],m=open(read(second.checkpointPath).coreState.compositionEnvelope);
for(let i=second.beforeInput;i<221;i++)m.apply(action(i));
const root=m.save(),facts=short(m),choices=m.menu(),baseline=read(record.roundEnds[2].checkpointPath).coreState.compositionEnvelope;
m.dispose();
const cases=[];
const standard=(h,i)=>h.take(h.m.apply(action(i)));
function prep(h,card,payer){
 h.take(h.m.pick(card));h.act('end_turn');
 if(payer==='move'){
  h.act('move',a=>a.target.deltaY===1);h.act('choose_payment',a=>a.target.cardIds?.[0]===h.m.player().hand.find(c=>c.cardId===card)?.id);
 }else h.take(h.m.corner('b_16.webp'));
 h.take(h.m.corner('amiba_9.webp'));
 h.act('research_tech');h.act('choose_target',a=>a.target.tileId==='blue1'&&a.target.blueSlot===3);
}
for(const card of ['dlc_16.png','dlc_17.png','dlc_20.png']){
 cases.push([card+'/pick only',h=>h.take(h.m.pick(card))]);
 for(const payer of card==='dlc_17.png'?['corner']:['move','corner']){
  cases.push([card+'/'+payer+'/after-tech',h=>prep(h,card,payer)]);
  for(const next of ['dlc_15.png','dlc_17.png','dlc_20.png','dlc_14.png']){
   cases.push([card+'/'+payer+'/'+next,h=>{
    prep(h,card,payer);
    for(let i=228;i<=234;i++)standard(h,i);
    h.take(h.m.play('amiba_5.webp'));
    h.take(h.m.pick(next));
   }]);
  }
 }
}
const result=runCases(root,cases);
writeZ(out,{root,choices,facts,baseline,...result});
