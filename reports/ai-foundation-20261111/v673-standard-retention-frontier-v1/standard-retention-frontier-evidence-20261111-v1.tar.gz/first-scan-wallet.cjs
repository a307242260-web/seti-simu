'use strict';
const path=require('node:path'),assert=require('node:assert/strict'),{open,runCases,writeZ,short}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),read=f=>require(path.resolve(dir,f));
const record=read('reports/research/d3183131.cbd73e00.quick-400.json'),saved=read(record.savePath);
const second=record.roundEnds[1],m=open(read(second.checkpointPath).coreState.compositionEnvelope);
for(let i=second.beforeInput;i<211;i++)m.apply(saved.replaySteps[i-1].action);
const root=m.save(),facts=short(m);m.dispose();
const prep=(h,c)=>h.take(h.m.play(c));
const stock=(h,mode)=>{
 if(mode==='none')return;
 h.take(...h.m.swap('dlc_25.png','dlc_17.png'));
 if(mode==='corner')h.take(h.m.corner('dlc_17.png'));
};
const cases=[
 ['B16 / before sector',h=>prep(h,'b_16.webp')],
 ['DLC25 / preserve energy',h=>prep(h,'dlc_25.png')],
 ['amiba9 / sell two',h=>{
  h.act('quick_trade',a=>a.target.tradeId==='cards-for-credit');
  for(const id of ['b_16.webp','dlc_25.png'])h.act('choose_payment',a=>a.summary===id);
  h.act('choose_payment',a=>a.summary.startsWith('确认'));
  prep(h,'amiba_9.webp');
 }],
 ...['none','swap','corner'].flatMap(mode=>['B16','DLC17'].map(plan=>[plan+'/'+mode,h=>{
  stock(h,mode);
  if(plan==='B16')prep(h,'b_16.webp');
  else if(mode==='none'){
   h.take(...h.m.swap('b_16.webp','dlc_17.png'));prep(h,'dlc_17.png');
  }else prep(h,'dlc_17.png');
 }])),
];
writeZ(out,{root,facts,...runCases(root,cases)});
