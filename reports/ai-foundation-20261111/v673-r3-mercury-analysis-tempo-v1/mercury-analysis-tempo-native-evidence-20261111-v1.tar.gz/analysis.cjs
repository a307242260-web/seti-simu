'use strict';
const assert=require('node:assert/strict');
const {open,short,readZ,writeZ}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),src=readZ(dir+'/placement-stable-20261111-v1.json.gz'),result=[];
for(const x of src.rows.filter(r=>r.canAnalyze)){
 const m=open(x.end),actions=[];
 try{
  const before=short(m);assert.equal(m.facts().computer.length,6);
  const e=m.facts().wallet.energy;
  actions.push(m.act('analyze'));
  actions.push(m.act('choose_target',a=>a.target?.stateExtra&&a.target.alienSlotId===1&&a.target.traceType==='blue'));
  const after=short(m),end=m.save();
  assert.equal(after.wallet[0],before.wallet[0]+3);
  assert.equal(after.wallet[2],e);
  m.restore(x.end);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  result.push({root:x.end,payer:x.payer,actions,before,after,end});
  console.log(JSON.stringify([x.payer,before.wallet[0],after.wallet[0],e,after.wallet[2]]));
 }finally{m.dispose();}
}
assert.equal(result.length,3);writeZ(out,{result});
