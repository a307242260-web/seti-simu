# V673 Mercury analysis timing

Run from a clean Production checkout at cbd73e00c98455dac868bd43be3e1759130088a7.
Let p be the absolute path of the extracted archive. The reproduction scripts
use the archived source envelopes. Use fresh names for every output.

```sh
(cd "$p" && shasum -a 256 -c SHA256SUMS)
node "$p/verify.cjs" "$p"
node "$p/try.cjs" "$p" "$p/replay-quote.json.gz"
node "$p/pilot.cjs" "$p" "$p/replay-pilot.json.gz"
node "$p/placement.cjs" "$p" "$p/replay-placement.json.gz"
node "$p/analysis.cjs" "$p" "$p/replay-analysis.json.gz"
node "$p/catchup.cjs" "$p" "$p/replay-catchup.json.gz"
node "$p/catchup-analysis.cjs" "$p" "$p/replay-catchup-analysis.json.gz"
```

The timing gate is wall clock. The independent verifier does not re-run search.
