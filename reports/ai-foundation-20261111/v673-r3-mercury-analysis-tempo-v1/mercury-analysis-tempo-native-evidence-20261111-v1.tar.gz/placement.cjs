'use strict';
const assert=require('node:assert/strict');
const {open,short,readZ,writeZ}=require('./controlled-r3');
const [d,out]=process.argv.slice(2),f=readZ(d+'/funding-20261111-v1.json.gz'),rows=[];
const cases=f.result.filter(x=>x.end&&(x.name.startsWith('顺时针')&&x.planet==='mercury'||x.name.startsWith('向外')&&x.planet==='saturn'||x.name==='留B16'&&x.planet==='mercury'));
for(const row of cases)for(const payer of ['b_111.webp','b_9.webp','b_60.webp']){
 const m=open(row.end),actions=[];
 try{
  const a0=short(m),initial=a0.computer.length;
  actions.push(m.act('choose_target',a=>a.target?.stateExtra&&a.target.alienSlotId===1&&a.target.traceType==='yellow'));
  actions.push(m.act('accept_optional_effect',a=>a.summary.includes('amiba_0.webp')));
  const afterTrace=short(m),want=Math.min(6,initial+afterTrace.wallet[4]);
  while(m.facts().computer.length<want){
   actions.push(m.act('place_data'),m.act('choose_target',a=>a.target.target==='computer'));
   if(m.menu().some(a=>a.family==='choose_card'&&a.summary.startsWith('收入 ')))
    actions.push(m.act('choose_card',a=>a.summary==='收入 '+payer));
  }
  const filled=short(m);assert.equal(filled.computer.length,want);
  actions.push(m.act('end_turn'));
  for(let i=0;i<8&&m.c.inspect().session&&m.menu()[0]?.actorId==='player-white';i++){
   const skip=m.menu().find(a=>a.family==='accept_optional_effect'&&a.target.choiceId?.startsWith('skip'));
   if(!skip)throw Error(JSON.stringify(m.menu()));
   actions.push(m.apply(skip));
  }
  assert(!m.c.inspect().session||m.menu()[0]?.actorId!=='player-white');
  if(m.menu()[0].actorId!=='player-white')m.advanceOpponents(actions);
  assert.equal(m.facts().round,4);
  const canAnalyze=m.menu().some(a=>a.family==='analyze');
  const end=m.save(), actor=m.menu()[0]?.actorId, families=m.menu().map(x=>x.family), next=short(m);
  m.restore(row.end);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  console.log(JSON.stringify([row.name,payer,initial,afterTrace.wallet[4],filled.computer.length,filled.wallet[0]-afterTrace.wallet[0],canAnalyze,actor,next.wallet,families]));
  rows.push({name:row.name,payer,root:row.end,actions,end,initial,afterTrace,filled,canAnalyze,actor,next,families});
 }finally{m.dispose();}
}
assert.equal(rows.length,9);

writeZ(out,{rows});
