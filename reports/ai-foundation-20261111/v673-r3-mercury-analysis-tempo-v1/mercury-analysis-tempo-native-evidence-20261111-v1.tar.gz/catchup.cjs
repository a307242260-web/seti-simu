'use strict';
const path=require('node:path'),assert=require('node:assert/strict');
const {getStandardScanCost}=require(path.resolve('randomizer/game/actions/scan-effects'));
const {open,short,readZ,writeZ}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),p=readZ(dir+'/placement-stable-20261111-v1.json.gz'),rows=[];
const targets=['sector-1-a','sector-2-a'];
for(const x of p.rows.filter(x=>!x.canAnalyze)){
 const kind=x.name.startsWith('向外')?'saturn-scan':'held-B16';
 for(const target of targets){
  const m=open(x.end),actions=[],act=(f,k)=>{const a=m.act(f,k);actions.push(a);return a;};
  try{
   const before=short(m);
   if(kind==='held-B16'){
    actions.push(m.play('b_16.webp'));
    act('choose_target',a=>a.target.skip===true);
    act('choose_target',a=>a.target.nebulaId===target);
   }else{
    const cost=getStandardScanCost(m.player());assert.deepEqual(cost,{credits:1,energy:2});
    while(m.facts().wallet.energy<cost.energy)act('quick_trade',a=>a.target.tradeId==='credits-for-energy');
    act('scan');act('choose_target',a=>a.target.nebulaId==='sector-2-b');
    act('choose_card',a=>a.summary.startsWith('dlc_16.png')&&a.target.nebulaId===target);
   }
   for(let i=0;i<12&&m.c.inspect().session;i++){
    const choices=m.menu(),a=choices.find(y=>y.target.skip||y.target.done||y.target.choiceId?.startsWith('skip'))
      ||choices.find(y=>y.target.stateExtra===true&&y.target.alienSlotId===1);
    if(!a)throw Error(JSON.stringify(choices.map(a=>[a.family,a.summary,a.target])));
    actions.push(m.apply(a));
   }
   const after=short(m);assert(!m.c.inspect().session);
   if(after.wallet[4]){
    act('place_data');act('choose_target',a=>a.target.target==='computer');
   }
   const filled=short(m);
   act('end_turn');
   for(let i=0;i<8&&m.c.inspect().session&&m.menu()[0]?.actorId==='player-white';i++)
    act('accept_optional_effect',a=>a.target.choiceId?.startsWith('skip'));
   if(m.menu()[0]?.actorId!=='player-white')m.advanceOpponents(actions);
   assert(!m.c.inspect().session);
   const canAnalyze=m.menu().some(a=>a.family==='analyze'),end=m.save();
   m.restore(x.end);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
   rows.push({name:x.name,payer:x.payer,kind,target,root:x.end,end,actions,before,after,filled,canAnalyze});
   console.log(JSON.stringify([kind,x.payer,target,before.wallet,after.wallet,filled.wallet,canAnalyze]));
  }finally{m.dispose();}
 }
}
writeZ(out,{rows});
