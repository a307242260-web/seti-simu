'use strict';
const assert=require('node:assert/strict');
const {open,readZ,writeZ,runCases}=require('./controlled-r3');
const {quote}=require('./quote.cjs');
const [d,out]=process.argv.slice(2),r=n=>readZ(d+'/'+n+'-20261111-v1.json.gz');
const roots=r('quote').rows,reference=r('direction').results.find(x=>x.mode==='baseline').q;
const rows=[];
for(const {name,root} of roots){
 const m=open(root);
 try{
  const q0=quote(m);
  if(!q0.action){rows.push({name,root,skip:q0.reason});continue;}
  const start=performance.now();
  const q=name==='original'?{a:m.menu().find(a=>a.actionId===reference.actionId),roots:reference.roots,complete:reference.complete,
   value:reference.value,n:reference.diagnostics.nativeExecutions,ms:reference.rootAndSearchMilliseconds}:m.automatic();
  const v=quote(m),ms=q.ms+(performance.now()-start-(name==='original'?0:q.ms));
  assert.deepEqual(m.save(),root);
  assert(q.complete&&q.n<=256&&ms<=600);
  const raw=v.action&&q.roots.find(a=>a.actionId===v.action.actionId);
  const dir=r=>r&&[r.direction.dx,r.direction.dy].join(',');
  const same=v.sameTarget,amount=same?same.wait.credits-same.move.credits:0;
  const projection=raw?.value==null||!same?null:raw.value+amount;
  const promote=q.a.family==='pass'&&projection!==null&&projection>q.value;
  const strict=promote&&v.bestWait?.planet===same.planet&&v.bestLand?.planet===same.planet&&dir(v.bestLand)===dir(same);
  const evidence={name,root,q:{a:q.a,raw:raw?.value??null,value:q.value,n:q.n,ms,complete:q.complete},same,projection,promote,strict,policyAction:strict?v.action:q.a};
  console.log(JSON.stringify([name,q.a.summary,q.value,raw?.value,amount,projection,promote,strict,evidence.policyAction.summary,q.n,ms]));
  rows.push(evidence);
 }finally{m.dispose();}
}
const original=rows.find(x=>x.name==='original');
assert(original.promote&&!original.strict&&original.projection===190.5);
const m=open(original.root),confirmed=quote(m);m.dispose();
const result=runCases(original.root,[['conditional-Mercury-pilot',h=>{
 const pick=quote(h.m).sameTarget;assert.deepEqual(pick,original.same);
 h.take(h.m.apply(confirmed.action));h.cut('cold-after-play');
 h.act('choose_target',a=>a.target.rocketId===pick.direction.rocketId&&a.target.deltaX===pick.direction.dx&&a.target.deltaY===pick.direction.dy);
 h.cut('release-to-normal-scan');
}]]);
writeZ(out,{rows,result});
