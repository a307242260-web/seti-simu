'use strict';
const assert=require('node:assert/strict');
const {open,readZ}=require('./controlled-r3');
const dir=process.argv[2],r=n=>readZ(dir+'/'+n+'-20261111-v1.json.gz');let count=0;
function replay(root,actions,end){
 const m=open(root);
 try{
  for(const row of actions){if(row.n!==undefined)assert(row.n<=256&&row.ms<=600);m.apply(row.action||row);count++;}
  assert.deepEqual(m.save(),end);
 }finally{m.dispose();}
}
const {rows:tests,result:pilot}=r('pilot');
for(const a of tests){
 if(a.q)assert(a.q.complete&&a.q.n<=256&&a.q.ms<=600);
 assert.equal(Boolean(a.strict),a.name==='only-one-extra-energy-needed');
}
assert.equal(pilot.rows.length,1);
const [run]=pilot.rows;
replay(r('geometry').before,run.prefix,run.start);replay(run.start,run.actions,run.end);
const earlier=r('extra').rows.find(x=>x.label==='顺时针/天狼星A');
assert.deepEqual(run.settled.state,earlier.settled.state);assert.deepEqual(run.end,earlier.end);
assert.deepEqual(r('fourth-controls').results.filter(x=>x.name==='同位置改扫天狼星A').map(x=>x.terminal.totalScore),[242,246]);
const {rows:placements}=r('placement-stable'),{result:immediate}=r('analysis'),
 {rows:catchup}=r('catchup'),{rows:late}=r('catchup-analysis');
assert.deepEqual([placements.length,immediate.length,catchup.length,late.length],[9,3,12,12]);
for(const a of placements){
 replay(a.root,a.actions,a.end);
 assert.equal(a.canAnalyze,a.name.startsWith('顺时针'));
 assert.equal(a.filled.computer.length,a.canAnalyze?6:5);
}
for(const a of [...catchup,...immediate,...late])replay(a.root,a.actions,a.end);
assert(catchup.every(a=>a.canAnalyze&&a.filled.computer.length===6));
for(const a of [...immediate,...late]){
 assert.equal(a.after.wallet[0]-a.before.wallet[0],3);assert.equal(a.after.wallet[2],a.before.wallet[2]);
}
assert(late.every(a=>a.before.turn===immediate[0].before.turn+1));
console.log(JSON.stringify({nativeReplayInputs:count,modelControls:tests.length,placement:placements.length,catchup:catchup.length,analysis:immediate.length+late.length}));
