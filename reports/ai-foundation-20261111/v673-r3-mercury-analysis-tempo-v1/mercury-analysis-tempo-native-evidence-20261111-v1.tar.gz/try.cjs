'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,writeZ,short}=require('./controlled-r3'),{quote}=require('./quote.cjs');
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const [dir,out]=process.argv.slice(2),g=readZ(dir+'/geometry-20261111-v1.json.gz'),original=g.before;
function withIncome(income,variant){
 const root=structuredClone(original),s=JSON.parse(root.committedState),owner=s.players.players.find(p=>p.id==='player-white');
 Object.assign(owner.income,income);
 if(variant==='opponent-active'){
  const other=s.turn.activePlayerIds.find(x=>x!=='player-white');assert(other);
  s.turn.passedPlayerIds=s.turn.passedPlayerIds.filter(x=>x!==other);
 }
 root.committedState=createStateStore(s).serialize().serialized;
 return root;
}
const cases=[['original',original],['cash-insufficient',withIncome({credits:4})],['only-one-extra-energy-needed',withIncome({energy:5})],
 ['no-funding-difference',withIncome({energy:7})],['opponent-active',withIncome({},'opponent-active')]];
const rows=[];
for(const [name,root] of cases){
 const m=open(root);
 try{
  const v=quote(m);assert.deepEqual(m.save(),root);
  console.log(JSON.stringify([name,v.reason,v.next,v.sameTarget&&[v.sameTarget.direction,v.sameTarget.wait,v.sameTarget.move],v.bestLand&&[v.bestLand.planet,v.bestLand.direction,v.bestLand.move.value],v.bestWait&&[v.bestWait.planet,v.bestWait.wait.value]]));
  rows.push({name,root,v});
 }finally{m.dispose();}
}
writeZ(out,{rows});
