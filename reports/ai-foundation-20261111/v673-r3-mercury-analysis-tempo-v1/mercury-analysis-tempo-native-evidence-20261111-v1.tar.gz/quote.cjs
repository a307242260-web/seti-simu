'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {getProbeRouteRequirements,createPlannedMovementTimingQuery}=require(path.resolve('randomizer/game/production-kernel'));
const {listPlayerMoveChoices}=require(path.resolve('randomizer/game/abilities/rocket'));
const {DEFAULT_WEIGHTS}=require(path.resolve('randomizer/game/ai/state-value'));
const {getCardPlayCost}=require(path.resolve('randomizer/game/cards/effects'));
const seat='player-white';
function quote(m){
 const s=m.state(),t=s.turn,p=m.player(),menu=m.menu(),card=p.hand.find(c=>c.cardId==='b_16.webp');
 const boundary=t.roundNumber===3&&t.currentPlayerId===seat&&t.activePlayerIds.every(x=>x===seat||t.passedPlayerIds.includes(x));
 if(!boundary||m.c.inspect().session||!card||!menu.some(a=>a.family==='pass')
   ||menu.filter(a=>a.phase==='main').some(a=>a.family!=='pass'&&(a.family!=='play_card'||a.target.cardInstanceId!==card.id)))
  return {reason:'out-of-domain'};
 const action=menu.find(a=>a.family==='play_card'&&a.target.cardInstanceId===card.id);
 if(!action)return {reason:'no-card-action'};
 const cost=getCardPlayCost(card);assert.deepEqual(cost,{credits:1});
 const rockets=m.facts().probes.filter(a=>a.surface==='solar-board'&&!a.fossilId);
 if(rockets.length!==1)return {reason:'ambiguous-probe'};
 const [probe]=rockets,directions=listPlayerMoveChoices(s,p,{maxPoints:1})
  .filter(a=>a.rocketId===probe.id&&a.requiredMovePoints===1);
 const requirements=getProbeRouteRequirements(s,seat)?.candidates.filter(a=>a.rocketId===probe.id
  &&a.endpointFamily==='land'&&a.endpointTarget.type==='planet'&&a.targetBenefit.score>=0&&a.targetBenefit.dataCount>=0)||[];
 const query=createPlannedMovementTimingQuery(s,seat);
 const next={credits:p.resources.credits+p.income.credits,energy:p.resources.energy+p.income.energy};
 const costs=(g,movePoints,spent)=>{
  const energy=movePoints+(g.endpointFacts.cost.energy||0),credits=(g.endpointFacts.cost.credits||0)+Math.max(0,energy-next.energy)*2;
  const usedEnergy=Math.min(energy,next.energy),funded=credits<=next.credits-spent;
  return {energy,credits,usedEnergy,funded,
   value:funded?g.targetBenefit.score+DEFAULT_WEIGHTS.availableData*g.targetBenefit.dataCount
    -DEFAULT_WEIGHTS.credits*credits-DEFAULT_WEIGHTS.energy*usedEnergy:null};
 };
 const rows=[];
 for(const g of requirements){
  if(!Number.isSafeInteger(g.endpointFacts.cost.energy||0)||!Number.isSafeInteger(g.endpointFacts.cost.credits||0))continue;
  for(const d of directions){
   const q=query(g.requirementId,[{...d,requiredMovePoints:1}],1);
   if(!q.comparable||q.alternatives.length!==2)continue;
   rows.push({planet:g.planetId,reward:[g.targetBenefit.score,g.targetBenefit.dataCount],direction:{rocketId:d.rocketId,dx:d.deltaX,dy:d.deltaY},wait:costs(g,q.waitPaidPoints,0),
    move:costs(g,q.alternatives[1].remainingPaidPoints,cost.credits)});
  }
 }
 const directionKey=r=>[r.direction.dx,r.direction.dy].join(',');
 const order=(a,b)=>b.move.value-a.move.value||a.move.credits-b.move.credits||a.planet.localeCompare(b.planet)||directionKey(a).localeCompare(directionKey(b));
 const known=rows.filter(r=>r.wait.funded&&r.move.funded&&r.move.credits<r.wait.credits&&r.move.usedEnergy<=r.wait.usedEnergy).sort(order);
 const bestLand=rows.filter(r=>r.move.funded).sort(order)[0];
 const bestWait=rows.filter(r=>r.wait.funded).sort((a,b)=>b.wait.value-a.wait.value)[0];
 const sameTarget=known.filter(r=>r.planet==='mercury')[0];
 return {action,rows,next,sameTarget,bestLand,bestWait};
}
module.exports={quote};
