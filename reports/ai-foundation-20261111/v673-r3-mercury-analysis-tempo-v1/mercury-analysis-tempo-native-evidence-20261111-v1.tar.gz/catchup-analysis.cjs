'use strict';
const assert=require('node:assert/strict');
const {open,short,readZ,writeZ}=require('./controlled-r3');
const [d,out]=process.argv.slice(2),src=readZ(d+'/catchup-20261111-v1.json.gz'),rows=[];
for(const x of src.rows){
 assert(x.canAnalyze);
 const m=open(x.end),actions=[];
 try{
  const before=short(m);
  actions.push(m.act('analyze'),m.act('choose_target',a=>a.target?.stateExtra&&a.target.alienSlotId===1&&a.target.traceType==='blue'));
  const after=short(m),end=m.save();
  assert.equal(after.wallet[0]-before.wallet[0],3);assert.equal(after.wallet[2],before.wallet[2]);
  m.restore(x.end);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  rows.push({kind:x.kind,target:x.target,payer:x.payer,root:x.end,actions,end,before,after});
  console.log(JSON.stringify([x.kind,x.payer,x.target,before.turn,after.wallet]));
 }finally{m.dispose();}
}
assert.equal(rows.length,12);writeZ(out,{rows});
