'use strict';
const assert=require('node:assert/strict');
const {open,readZ,writeZ,short}=require('./controlled-r3');
const [input,out]=process.argv.slice(2),d=readZ(input),rows=[];
for(const row of d.filter(r=>r.stop?.kind==='gate')){
 const m=open(row.end),actions=[];
 try{
  let cp,stop;
  for(let i=0;i<160;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!=='player-white'){
    const a=[];m.advanceOpponents(a);actions.push(...a.map(action=>({action,passive:true})));continue;
   }
   const q=m.automatic(cp);
   if(!q.a||!q.complete||q.n>256||q.ms>600){stop={kind:'gate',n:q.n,ms:q.ms,a:q.a?.summary};break;}
   cp=q.checkpoint;actions.push({action:m.apply(q.a),n:q.n,ms:q.ms,value:q.value});
  }
  assert(stop);
  const end=m.save(),peak=[Math.max(...actions.map(a=>a.n||0)),Math.max(...actions.map(a=>a.ms||0))];
  const terminal=stop==='terminal'?m.state().match.finalScores.find(x=>x.playerId==='player-white'):null;
  m.restore(row.end);actions.forEach(a=>m.apply(a.action));assert.deepEqual(m.save(),end);
  console.log(JSON.stringify([row.mode,stop,terminal?.totalScore,peak,actions[0]?.action.summary]));
  rows.push({label:row.mode,root:row.end,actions,end,stop,terminal,peak});
 }finally{m.dispose();}
}
writeZ(out,rows);
