'use strict';
const path=require('node:path'),{open,readZ,writeZ,short}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [src,out]=process.argv.slice(2),d=readZ(src),rows=[];
for(const row of d.filter(r=>r.stop?.kind==='gate')){
 const m=open(row.end),start=m.save(),legal=m.menu(),port=createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});
 try {
  const q=createSearchAgent({seatId:'player-white',analysisPort:port}).decide({seatId:'player-white',legalActions:legal}).search;
  const active=q.analysis;
  const counts=Object.fromEntries(Object.entries(active).filter(([k,v])=>typeof v==='number'&&v));
  console.log(row.mode,JSON.stringify([short(m),q.complete,q.value,q.diagnostics.nativeExecutions,q.rootAndSearchMilliseconds,counts,Object.keys(active)]));
  rows.push({label:row.mode,root:start,legal,q});
 }finally{port.close();m.dispose();}
}
writeZ(out,rows);
