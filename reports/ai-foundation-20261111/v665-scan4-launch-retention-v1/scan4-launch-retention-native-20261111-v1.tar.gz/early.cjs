'use strict';
const assert=require('node:assert/strict');
const {open,readZ,writeZ,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),row=i=>d.rows.find(r=>r.i===i);
const results={};
const pub=a=>a.family==='choose_card'&&a.target?.nebulaId;
{
 const root=row(138).before,m=open(root),prefixes=[],equiv=[],seen=new Map();
 try{
  for(const first of m.menu().filter(pub)){
   m.restore(root);m.apply(first);
   for(const second of m.menu().filter(pub)){
    m.restore(root);m.apply(first);m.apply(second);
    const label=first.summary+' / '+second.summary;
    const end=JSON.stringify(m.save());
    if(seen.has(end)){equiv.push([label,seen.get(end)]);continue;}
    seen.set(end,label);
    if(first.actionId===row(138).a.actionId&&second.actionId===row(139).a.actionId)continue;
    prefixes.push([label,h=>{h.take(h.m.apply(first));h.take(h.m.apply(second));}]);
   }
  }
 }finally{m.dispose();}
 results.public={root,equiv,...runCases(root,prefixes)};
}
{
 const root=row(172).before,m=open(root),prefixes=[],equiv=[],seen=new Map();
 const routes=['sector-3-a','sector-1-a','sector-4-b','sector-1-b'];
 try{
  m.play('dlc_19.png');
  const match=(a,id)=>a.family==='choose_target'&&a.target?.nebulaId===id;
  const play=m.save();
  for(const first of routes){
   m.restore(play);m.act('choose_target',a=>match(a,first));
   for(const second of routes){
    if(first==='sector-1-b'&&second==='sector-1-b'||first==='sector-3-a'&&second==='sector-3-a')continue;
    m.restore(play);const a=m.act('choose_target',a=>match(a,first));
    const b=m.act('choose_target',a=>match(a,second));
    const label=a.summary+' / '+b.summary,end=JSON.stringify(m.save());
    if(seen.has(end)){equiv.push([label,seen.get(end)]);continue;}
    seen.set(end,label);
    prefixes.push([label,h=>{h.take(h.m.play('dlc_19.png'));h.take(h.m.apply(a));h.take(h.m.apply(b));}]);
   }
  }
 }finally{m.dispose();}
 results.dlc19={root,equiv,...runCases(root,prefixes)};
}
writeZ(out,results);
