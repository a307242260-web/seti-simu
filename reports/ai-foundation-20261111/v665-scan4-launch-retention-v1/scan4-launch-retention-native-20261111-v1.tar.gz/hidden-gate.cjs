'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,writeZ}=require('./controlled-r3');
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const [input,out]=process.argv.slice(2),rows=[];
for(const {label,root} of readZ(input)){
 const m=open(root);
 try{
  const collect=()=>{
   const q=m.automatic();
   assert(q.complete&&q.n<=256&&q.ms<=600);
   return {observation:m.owner('player-white'),menu:m.menu(),choice:q.a,value:q.value,roots:q.roots,n:q.n};
  };
  const original=collect(),state=JSON.parse(root.committedState),deck=state.cards.drawPileCardIds;
  [deck[0],deck[1]]=[deck[1],deck[0]];
  const changed=createStateStore(state).serialize(state);
  assert(changed.ok);
  m.restore({...root,committedState:changed.serialized});
  const alternate=collect();assert.deepEqual(alternate,original);
  console.log(label,original.n);
  rows.push({label,original,alternate});
 }finally{m.dispose();}
}
writeZ(out,rows);
