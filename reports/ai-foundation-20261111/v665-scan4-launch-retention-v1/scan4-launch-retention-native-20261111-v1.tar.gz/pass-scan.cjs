'use strict';
const assert=require('node:assert/strict');
const {open,readZ,writeZ,short}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),cases=[];
for(const [step,mode] of [[235,'B16-scan-after-move'],[235,'B16-scan-no-move'],[258,'standard-B32']]){
 const root=d.rows.find(r=>r.i===step).before;
 const m=open(root),fixed=[];
 try{
  if(mode.startsWith('B16')){
   fixed.push(m.play('b_16.webp'));
   fixed.push(m.act('choose_target',a=>mode==='B16-scan-no-move'?a.target.skip:a.target.deltaX===1));
   fixed.push(m.act('choose_target',a=>a.target.nebulaId==='sector-1-a'));
  }
  if(m.player().mainActionCompleted)fixed.push(m.act('end_turn'));
  m.advanceOpponents(fixed);
  for(const card of (step===258?['b_32.webp']:['b_111.webp','b_32.webp']))cases.push({step,mode,root,beforePass:m.save(),fixed,card});
 }finally{m.dispose();}
}
const rows=[];
for(const {step,mode,root,beforePass,fixed,card} of cases){
 const m=open(root),actions=[],turns=[];
 let checkpoint,stop;
 try{
  fixed.forEach(m.apply);assert.deepEqual(m.save(),beforePass);
  const assets=m.facts(),r3=short(m);
  actions.push({action:m.act('pass')});
  actions.push({action:m.act('choose_card',a=>a.summary===card)});
  for(let i=0;i<160;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!=='player-white'){
    const more=[];m.advanceOpponents(more);actions.push(...more.map(action=>({action,passive:true})));continue;
   }
   const r=m.automatic(checkpoint);
   if(!r.complete||r.n>256||r.ms>600){stop={kind:'gate',n:r.n,ms:r.ms,action:r.a?.summary};break;}
   checkpoint=r.checkpoint;actions.push({action:m.apply(r.a),n:r.n,ms:r.ms,value:r.value});
   if(r.a.family==='end_turn')turns.push(short(m));
  }
  assert(stop);
  const end=m.save(),terminal=stop==='terminal'?m.state().match.finalScores.find(x=>x.playerId==='player-white'):null;
  m.restore(root);fixed.forEach(m.apply);actions.forEach(a=>m.apply(a.action));assert.deepEqual(m.save(),end);
  const peak=[Math.max(...actions.map(a=>a.n||0)),Math.max(...actions.map(a=>a.ms||0))];
  console.log(JSON.stringify([step,mode,card,stop,terminal?.totalScore,r3.wallet,r3.income,r3.hand,turns.slice(0,2).map(x=>[x.wallet,x.established]),peak]));
  rows.push({step,mode,root,beforePass,fixed,card,r3,assets,actions,turns,stop,peak,terminal,end});
 }finally{m.dispose();}
}
writeZ(out,rows);
