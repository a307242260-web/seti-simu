'use strict';
const {open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),row=i=>d.rows.find(x=>x.i===i);
const end=h=>{h.act('end_turn');const actions=[];h.m.advanceOpponents(actions);h.take(...actions);};
const scan=h=>{
 h.act('scan');
 h.act('choose_target',a=>a.target.nebulaId==='sector-3-a');
 h.act('choose_card',a=>a.summary==='b_14.webp → 南河三');
 h.act('choose_card',a=>a.summary==='dlc_30.png → 南河三');
 h.act('choose_target',a=>a.summary==='发射探测器');
 h.cut('first-scan-launch');
};
const root=row(136).before;
const results=runCases(root,[
 ['play-B10',h=>h.take(h.m.play('b_10.webp'))],
 ['play-B10-then-same-scan',h=>{h.take(h.m.play('b_10.webp'));end(h);scan(h);}],
 ['play-B101-orange1',h=>{h.take(h.m.play('b_101.webp'));h.act('choose_target',a=>a.target.tileId==='orange1');}],
 ['standard-launch-first',h=>h.act('launch')],
 ['swap-B10-for-public-B14',h=>h.take(...h.m.swap('b_10.webp','b_14.webp'))],
]);
writeZ(out,{root,...results});
