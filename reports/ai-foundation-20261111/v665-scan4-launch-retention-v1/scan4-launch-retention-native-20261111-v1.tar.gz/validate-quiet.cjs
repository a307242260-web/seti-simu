'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {open,readZ,writeZ}=require('./controlled-r3');
const [beforeFile,afterFile,out]=process.argv.slice(2);
const before=readZ(beforeFile),after=readZ(afterFile),file=path.resolve('randomizer/game/ai/analysis-port.js');
const mod=new Module(file,module);mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const anchor='        else provedScan4QuietLaunchSkips++;';
const code=fs.readFileSync(file,'utf8');assert.equal(code.split(anchor).length,2);
const witnesses=[];
globalThis.recordScanProof=(source,action,target,child,barrier)=>witnesses.push({source:source.envelope,action,target:target.envelope,
  legal:child.legalActions.map(a=>[a.actionId,a.family,a.target]),barrier});
mod._compile(code.replace(anchor,'        else {provedScan4QuietLaunchSkips++;globalThis.recordScanProof(stored,requested,nodes.get(child),child,scanAction.barrier);}'),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
function normalized(envelope){
 const e=structuredClone(envelope);
 e.committedState=JSON.parse(e.committedState);
 const session=e.session?.session;
 if(!session)return e;
 session.undoFrames=[];
 const visit=x=>{
  if(typeof x==='string')return x.replaceAll(session.sessionId,'@session');
  if(Array.isArray(x))return x.map(visit);
  if(x&&typeof x==='object')return Object.fromEntries(Object.entries(x).map(([k,v])=>[k,visit(v)]));
  return x;
 };
 e.session=visit(e.session);
 return e;
}
const rows=[];
for(const [index,a] of before.entries()){
 const b=after[index];assert.equal(a.label,b.label);
 const compare=q=>[q.actionId,q.value,q.realization,q.preparationDebt,q.complete,q.roots,q.lines,q.unresolved,q.selectionPlan,q.candidates];
 assert.deepEqual(compare(a.q),compare(b.q));
 const m=open(a.root);
 try{
  witnesses.length=0;
  const port=createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});
  const q=createSearchAgent({seatId:'player-white',analysisPort:port}).decide({seatId:'player-white',legalActions:m.menu()}).search;
  assert.deepEqual(m.save(),a.root);
  assert.equal(witnesses.length,b.q.analysis.provedScan4QuietLaunchSkips);
  const types={};
  for(const [i,w] of witnesses.entries()){
   assert(m.c.lifecycle.restore(w.source).ok);
   assert.deepEqual(normalized(m.save()),normalized(w.source));
   const choice=m.menu().find(a=>a.actionId===w.action.actionId),d=m.c.inspect().session?.decision;
   assert(choice&&d);assert.deepEqual(choice.target,w.action.target);
   const r=m.c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice});
   assert(r.ok);assert.deepEqual(r.irreversibleBarrier,w.barrier);
   try{assert.deepEqual(normalized(m.save()),normalized(w.target));}
   catch(error){console.error(a.label,i,w.action.target,error.message.slice(0,3500));throw error;}
   const menu=new Set(m.menu().map(a=>JSON.stringify([a.actionId,a.family,a.target])));
   assert(w.legal.every(x=>menu.has(JSON.stringify(x))));
   const key=[w.source.session.session.journal.actions[0].action.family,w.action.target.mode,w.target.session?.session?.queue[0]?.type??'committed'].join('/');
   types[key]=(types[key]??0)+1;
  }
  console.log(JSON.stringify([a.label,witnesses.length,types,q.diagnostics.nativeExecutions]));
  rows.push({label:a.label,witnesses:[...witnesses],types});
 }finally{m.dispose();}
}
writeZ(out,rows);
