'use strict';
const path=require('node:path'),assert=require('node:assert/strict'),fs=require('node:fs'),Module=require('node:module');
const prepare=require('./prepare.cjs');
const [input,out]=process.argv.slice(2),src=path.resolve('randomizer/game/ai/analysis-port.js');
const mod=new Module(src,module);mod.filename=src;mod.paths=Module._nodeModulePaths(path.dirname(src));Module._cache[src]=mod;
mod._compile(prepare(fs.readFileSync(src,'utf8'),'comet-b9'),src);mod.loaded=true;
const {open,readZ,writeZ}=require('./controlled-r3');
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const [first]=readZ(input),rows=[];
for(const [label,swap] of [['ordinary',['ordinary']],['amiba',['amiba']],['both',['ordinary','amiba']]]){
 const e=structuredClone(first.root),state=JSON.parse(e.committedState);
 for(const name of swap){
  const deck=name==='ordinary'?state.cards.drawPileCardIds:state.aliens.amiba.cardDeck;
  assert(deck.length>=2);[deck[0],deck[1]]=[deck[1],deck[0]];
 }
 e.committedState=createStateStore(state).serialize().serialized;
 const old=open(first.root),m=open(e);
 try{
  assert.deepEqual(m.owner('player-white'),old.owner('player-white'));assert.deepEqual(m.menu(),old.menu());
  assert.deepEqual(m.facts().rng,old.facts().rng);
  const q=m.automatic();assert.deepEqual(m.save(),e);
  assert.deepEqual([q.a.actionId,q.value,q.n,q.complete,JSON.parse(JSON.stringify(q.roots))],[first.q.actionId,first.q.value,first.q.diagnostics.nativeExecutions,true,first.q.roots]);
  rows.push({label,e,q:{...q,checkpoint:null}});
  console.log(label,q.a.summary,q.value,q.n);
 }finally{old.dispose();m.dispose();}
}
writeZ(out,{rows});
