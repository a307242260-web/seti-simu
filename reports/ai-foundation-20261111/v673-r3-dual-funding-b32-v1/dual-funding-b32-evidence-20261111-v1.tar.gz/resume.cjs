'use strict';
const path=require('node:path'),assert=require('node:assert/strict'),fs=require('node:fs'),Module=require('node:module');
const prepare=require('./prepare.cjs');
const [folder,out]=process.argv.slice(2),src=path.resolve('randomizer/game/ai/analysis-port.js');
const mod=new Module(src,module);mod.filename=src;mod.paths=Module._nodeModulePaths(path.dirname(src));Module._cache[src]=mod;
mod._compile(prepare(fs.readFileSync(src,'utf8'),'comet-b9'),src);mod.loaded=true;
const {open,readZ,writeZ,short}=require('./controlled-r3');
const read=name=>readZ(path.join(folder,name+'-20261111-v1.json.gz'));
const [first]=read('comet-b9'),[proof]=read('proof').results;
assert.deepEqual(first.root,proof.root);
assert.equal(first.q.actionId,proof.actionId);
assert(first.q.complete&&first.q.diagnostics.nativeExecutions<=256&&first.q.rootAndSearchMilliseconds<=600);
const root=first.root,m=open(root),seat='player-white',trace=[],turns=[];let checkpoint=proof.checkpoint,stop;
try{
 const initial=m.menu().find(a=>a.actionId===first.q.actionId);
 trace.push({action:m.apply(initial),n:first.q.diagnostics.nativeExecutions,ms:first.q.rootAndSearchMilliseconds,value:first.q.value});
 for(let i=0;i<190;i++){
  if(m.state().turn.gameEnded){stop='terminal';break;}
  if(m.menu()[0].actorId!==seat){const passive=[];m.advanceOpponents(passive);trace.push(...passive.map(action=>({action,passive:true})));continue;}
  const q=m.automatic(checkpoint);
  if(!q.a||!q.complete||q.n>256||q.ms>600){stop={kind:'gate',n:q.n,ms:q.ms,action:q.a?.summary,turn:m.facts().turn};break;}
  if(!checkpoint||q.a.phase==='main'||q.a.family==='pass')turns.push({choice:q.a,n:q.n,ms:q.ms,assets:short(m)});
  checkpoint=q.checkpoint;trace.push({action:m.apply(q.a),n:q.n,ms:q.ms,value:q.value});
 }
 assert(stop);
 const end=m.save(),terminal=stop==='terminal'?m.state().match.finalScores.find(p=>p.playerId===seat):null;
 const peak=[Math.max(...trace.map(a=>a.n||0)),Math.max(...trace.map(a=>a.ms||0))];
 m.restore(root);trace.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),end);
 console.log(JSON.stringify({stop,terminal,peak,inputs:trace.length,turns:turns.map(t=>[t.choice.summary,t.assets.wallet[0]])}));
 writeZ(out,{root,end,trace,turns,stop,terminal,peak});
}finally{m.dispose();}
