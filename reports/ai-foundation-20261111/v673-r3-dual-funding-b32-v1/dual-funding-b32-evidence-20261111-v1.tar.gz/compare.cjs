'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),Module=require('node:module');
const {open,readZ,writeZ}=require('./controlled-r3'),prepare=require('./prepare.cjs');
const [mode,input,out]=process.argv.slice(2),src=path.resolve('randomizer/game/ai/analysis-port.js');
const mod=new Module(src,module);mod.filename=src;mod.paths=Module._nodeModulePaths(path.dirname(src));
mod._compile(prepare(fs.readFileSync(src,'utf8'),mode),src);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const data=readZ(input),results=[];
const fields=['actionId','value','realization','preparationDebt','complete','roots','lines','unresolved','selectionPlan','candidates','sharedPrefixGraph'];
for(const r of data){
 const m=open(r.root),seatId='player-white',port=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
 try{
  const q=createSearchAgent({seatId,analysisPort:port}).decide({seatId,legalActions:m.menu()}).search;
  assert.deepEqual(m.save(),r.root);
  const actual=JSON.parse(JSON.stringify(q));
  for(const field of fields)assert.deepEqual(actual[field],r.q[field],field);
  console.log(JSON.stringify({mode,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,delta:r.q.diagnostics.nativeExecutions-q.diagnostics.nativeExecutions,complete:q.complete,value:q.value,action:m.menu().find(a=>a.actionId===q.actionId).summary}));
  results.push({mode,root:r.root,q});
 }finally{port.close();m.dispose();}
}
writeZ(out,results);
