# V673 dual-funding B32 follow-up
Run from clean Production source cbd73e00c. p is the absolute archive path.
The earlier dual-funding report provides the archived audit and dual-funding
JSON files for pass-quote.cjs; all other inputs are included here.
```sh
node "$p/geometry.cjs" "$p/profile-20261111-v1.json.gz" "$p/replay-geometry.json.gz"
node "$p/compare.cjs" comet-b9 "$p/profile-20261111-v1.json.gz" "$p/replay-comparison.json.gz"
node "$p/prove.cjs" "$p/profile-20261111-v1.json.gz" "$p/replay-proof.json.gz"
node "$p/hidden.cjs" "$p/comet-b9-20261111-v1.json.gz" "$p/replay-hidden.json.gz"
node "$p/resume.cjs" "$p" "$p/replay-resume.json.gz"
node "$p/pass-quote.cjs" "$prior" "$p/replay-pass.json.gz"
```
The recorded first decision from the uninstrumented admitted sample is reused
exactly for the continuation, with its validated search plan checkpoint.
Subsequent decisions are individually gated. New hardware timing can vary.
No production source or search limits are modified.
