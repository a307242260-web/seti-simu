'use strict';
const path=require('node:path'),assert=require('node:assert/strict'),fs=require('node:fs'),Module=require('node:module');
const {readZ,writeZ,open}=require('./controlled-r3');
const src=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(src,module);
mod.filename=src;mod.paths=Module._nodeModulePaths(path.dirname(src));
const text=fs.readFileSync(src,'utf8'),anchor='      submissionCount += 1;\n      return { before, result };';
assert.equal(text.split(anchor).length,2);
mod._compile(text.replace(anchor,`      submissionCount += 1;
      if(head?.type===scienceSession.EFFECT_TYPES.SCAN_ACTION_4&&current.target?.mode==="move"){
        const state=structuredClone(session.workingState),player=state.players.players.find(p=>p.id===seatId);
        const move=rocketAbilities.moveProbe(scienceSession.createActionContext(state,seatId),{
          ...current.target,cost:{},skipCost:true,movementPoints:scanEffects.SCAN_ACTION_4_MOVE_POINTS,
        });
        globalThis.inspectMove({
          action:current.summary,source:session.journal.actions[0].action.summary, events:move.events,
          bonuses:session.workingState.turn.cardTurnEventBonuses,type1:session.workingState.turn.type1TriggerEvents,
          pending:session.workingState.aliens.chong?.transportTasksByRocketId,reserve:player.reservedCards.map(c=>c.cardId),
          ready:data.NEBULA_IDS.filter(id=>data.isSectorReadyToSettle(state.data,id)),
          queue:session.queue.map(e=>e.type),missing:state.cards.publicCards.filter(c=>!c).length,
          resultKeys:Object.keys(result), state:session.workingState, actionDescriptor:current,
        });
      }
      return { before, result };`),src);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const data=readZ(process.argv[2]),rows=[];
globalThis.inspectMove=x=>rows.push(x);
for(const r of data){
 const m=open(r.root),seatId='player-white',port=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
 try{
  const q=createSearchAgent({seatId,analysisPort:port}).decide({seatId,legalActions:m.menu()}).search;
  assert.deepEqual(m.save(),r.root);
  console.log(q.diagnostics.nativeExecutions,rows.length);
 }finally{port.close();m.dispose();}
}
const reduced={}; for(const row of rows){const k=JSON.stringify([row.action,row.source,row.events.map(e=>e.type),row.ready,row.missing,row.bonuses.length,row.type1?.length,Object.keys(row.pending||{}).length]);reduced[k]=(reduced[k]||0)+1;}
console.log(reduced);writeZ(process.argv[3],rows);
