'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path');
const {readZ,open,writeZ,short}=require('./controlled-r3');
const [prior,out]=process.argv.slice(2),d=readZ(path.join(prior,'dual-20261111-v1.json.gz')),
 a=readZ(path.join(prior,'audit-20261111-v1.json.gz'));
const r=d.rows.find(r=>r.label==='publicity/dlc_17.png/no-swap');
const rows=[];
for(const [name,origin] of [['standard',a.roots[258]],['dual-funded',r.settled.state]]){
 const m=open(origin);
 try{
  const pass=m.act('pass'),offer=m.menu().map(x=>[x.summary,x.actionId]),q=m.automatic();
  assert(q.complete&&q.n<=256&&q.ms<=600);
  const row={name,origin,pass,offer,q};rows.push(row);
  console.log(JSON.stringify([name,q.a.summary,q.value,q.n,q.ms,q.roots.map(x=>[offer.find(a=>a[1]===x.actionId)?.[0],x.value])]));
 }finally{m.dispose();}
}
writeZ(out,rows);
