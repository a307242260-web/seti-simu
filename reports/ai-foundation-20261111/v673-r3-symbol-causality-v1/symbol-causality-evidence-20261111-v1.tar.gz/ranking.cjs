'use strict';
const {readZ,writeZ,open,short,runCases}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),d=readZ(dir+'/audit-20261111-v1.json.gz'),m=open(d.roots[179]);
const quote=m=>{
 const q=m.automatic(),menu=Object.fromEntries(m.menu().map(a=>[a.actionId,a.summary]));
 return {choice:q.a.summary,value:q.value,complete:q.complete,n:q.n,ms:q.ms,options:q.roots.map(r=>[menu[r.actionId],r.value,r.completion||null])};
};
const at179=quote(m);m.play('amiba_0.webp');
const root=m.save(),at180=quote(m);m.dispose();
console.log(JSON.stringify({at179,at180}));
const alt=runCases(root,[['Only change step 180, then autonomous',h=>h.act('choose_target',a=>a.target.slotId==='blue_3')]]);
writeZ(out,{root,at179,at180,alt});
