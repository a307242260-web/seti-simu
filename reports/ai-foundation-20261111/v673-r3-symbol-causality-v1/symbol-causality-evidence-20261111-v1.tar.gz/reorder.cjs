'use strict';
const {readZ,writeZ,open,short,runCases}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),d=readZ(dir+'/audit-20261111-v1.json.gz'),records=new Map(d.ledger.map(x=>[x.i,x.input]));
const root=d.roots[179],fixed=(h,i)=>h.take(h.m.apply(records.get(i)));
const target=(h,text)=>h.act('choose_target',a=>a.summary.includes(text));
const slot=(h,kind,n)=>h.act('choose_target',a=>a.target.speciesId==='amiba'&&a.target.traceType===kind&&a.target.position===n);
const pick=(h,text)=>h.act('choose_card',a=>a.summary.includes(text));
const end=h=>h.act('end_turn');
const a3=h=>{h.take(h.m.play('amiba_3.webp'));target(h,'黄色痕迹 1号位');h.cut('A3');end(h);};
const analyze=(h,blue)=>{h.act('analyze');slot(h,'blue',blue);pick(h,'基因组表征');h.cut('first-analysis');end(h);};
const pool=(h,i)=>{h.act('place_data');target(h,'第一排放置位 '+i);};
const prelude=(h,order,initial,blue)=>{
 if(order==='A3 first')a3(h);
 h.take(h.m.play('amiba_0.webp'));target(h,initial);
 h.cut('A0');
 pool(h,5);pool(h,6);end(h);
 if(order==='A3 last'){analyze(h,blue);a3(h);}
 else{
  if(order!=='A3 first')a3(h);
  analyze(h,blue);
 }
};
const replay=(h,i)=>{const a=records.get(i);
 const exact=h.m.menu().find(x=>x.actionId===a.actionId);
 if(exact)return h.take(h.m.apply(a));
 // Reissued IDs after a different turn order are admissible only for the same native option.
 h.act(a.family,x=>x.summary===a.summary&&JSON.stringify(x.target)===JSON.stringify(a.target));};
const settle=(h,blue,red,finance)=>{
 for(let i=193;i<=235;i++){
  replay(h,i);
  if([203,215,233].includes(i))h.cut('i'+i);
 }
 h.take(h.m.pick('dlc_17.png'));target(h,red);h.cut('red');end(h);
 h.act('analyze');slot(h,'blue',blue===3?4:3);pick(h,'科学论文');h.cut('last-analysis');
 if(finance==='release')return;
 h.act('quick_trade',a=>a.target.tradeId==='cards-for-credit');
 for(const id of ['amiba_2.webp','dlc_17.png'])h.act('choose_payment',a=>a.summary===id);
 h.act('choose_payment',a=>a.summary.startsWith('确认弃牌'));end(h);
 h.take(h.m.play('b_16.webp'));target(h,'顺时针');h.act('choose_target',a=>a.target.nebulaId==='sector-1-a');h.cut('scan');
};
const cases=[];
for(const order of ['A3 first','A3 last'])for(const initial of ['4分','1宣传','1数据'])for(const red of ['4分','1数据']){
 cases.push([[order,initial,red].join('/'),h=>{prelude(h,order,initial,4);settle(h,4,red,'dual');}]);
}
for(const order of ['A3 first','A3 last'])for(const initial of ['4分','1宣传','1数据']){
 cases.push([[order,initial,'release'].join('/'),h=>prelude(h,order,initial,4)]);
}
writeZ(out,runCases(root,cases));
