# V673 third-round Amiba symbol causality
Run from clean Production cbd73e00c. Set p to the absolute path of the extracted
archive. All experiment inputs below are included in the archive; new outputs
do not overwrite them. Each accepted suffix is replayed through the native port.
```sh
node "$p/slots.cjs" "$p" "$p/replay-slots.json.gz"
node "$p/ledger.cjs" "$p" "$p/replay-ledger.json.gz"
node "$p/reorder.cjs" "$p" "$p/replay-reorder.json.gz"
node "$p/reorder-repay.cjs" "$p" "$p/replay-repay.json.gz"
node "$p/ranking.cjs" "$p" "$p/replay-ranking.json.gz"
node "$p/fourth.cjs" "$p" "$p/replay-fourth.json.gz"
node "$p/base.cjs" "$p/fourth-20261111-v1.json.gz" "$p/replay-base.json.gz"
node "$p/compare.cjs" comet-b9 "$p/base-20261111-v1.json.gz" "$p/replay-comparison.json.gz"
node "$p/prove.cjs" "$p/base-20261111-v1.json.gz" "$p/replay-proof.json.gz"
node "$p/resume.cjs" "$p" "$p/replay-resume.json.gz"
```
The two early-A3 B32 branches converge to the exact same first-decision
envelope. Only one continuation is run. Its first decision reuses the
archived admitted timing and independently verified checkpoint. Timing varies.
