'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,open,short}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),d=readZ(dir+'/audit-20261111-v1.json.gz'),a=readZ(dir+'/slots-20261111-v1.json.gz');
const record=d.ledger.filter(r=>r.i>=179&&r.i<=237);
const r=a.rows.find(x=>x.label==='4/4/publicity/data'),first=r.prefix.findIndex(x=>x.summary==='amiba_0.webp');
const prefix=r.prefix.slice(first,first+record.length),rows=[];
assert.equal(prefix.length,record.length);
for(const [label,inputs] of [['points',record.map(x=>x.input)],['publicity',prefix]]){
 const m=open(d.roots[179]),history=[];
 try{
  for(let j=0;j<inputs.length;j++){
   const action=inputs[j],state=m.state();
   const before=short(m).wallet,slots=state.aliens.amiba.symbolSlots;
   m.apply(action);
   const after=short(m).wallet;
   history.push({i:j+179,action:action.summary,before,after,gain:after.map((v,k)=>v-before[k]),slots,next:m.state().aliens.amiba.symbolSlots});
  }
 }finally{m.dispose();}
 rows.push({label,history});
}
for(const n of [180,215,237])console.log(n,rows.map(x=>[x.label,x.history.find(r=>r.i===n).gain]));
writeZ(out,rows);
