'use strict';
const {readZ,writeZ,open,short,runCases}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),d=readZ(dir+'/audit-20261111-v1.json.gz'),records=new Map(d.ledger.map(x=>[x.i,x.input]));
const m=open(d.roots[172]);for(let i=172;i<175;i++)m.apply(records.get(i));const root=m.save();m.dispose();
const fixed=(h,i)=>h.take(h.m.apply(records.get(i)));
const slot=(h,kind,n)=>h.act('choose_target',a=>a.target.speciesId==='amiba'&&a.target.traceType===kind&&a.target.position===n);
const pick=(h,text)=>h.act('choose_card',a=>a.summary.includes(text));
const cases=[];
for(const pink of [3,4])for(const blue of [3,4])for(const initial of ['points','publicity'])for(const red of ['points','data']){
 const name=[pink,blue,initial,red].join('/');
 cases.push([name,h=>{
  slot(h,'pink',pink);pick(h,'低重力研究');
  for(let i=177;i<=235;i++){
   if(i===180)h.act('choose_target',a=>a.target.slotId===(initial==='points'?'blue_1':'blue_3'));
   else if(i===190)slot(h,'blue',blue);
   else if(i===191)pick(h,'基因组表征');
   else if(i===214)slot(h,'pink',pink===3?4:3);
   else if(i===215)pick(h,'生物特征筛选');
   else fixed(h,i);
   if([180,187,191,215,233].includes(i))h.cut('i'+i);
  }
  h.take(h.m.pick('dlc_17.png'));
  h.act('choose_target',a=>a.summary.includes(red==='points'?'4分':'1数据'));
  h.cut('red');
  h.act('end_turn');h.act('analyze');slot(h,'blue',blue===3?4:3);pick(h,'科学论文');h.cut('analysis');
  h.act('quick_trade',a=>a.target.tradeId==='cards-for-credit');
  for(const x of ['amiba_2.webp','dlc_17.png'])h.act('choose_payment',a=>a.summary===x);
  h.act('choose_payment',a=>a.summary.startsWith('确认弃牌'));
  h.act('end_turn');h.take(h.m.play('b_16.webp'));
  h.act('choose_target',a=>a.summary.endsWith('顺时针'));
  h.act('choose_target',a=>a.target.nebulaId==='sector-1-a');h.cut('extra-scan');
 }]);
}
writeZ(out,runCases(root,cases));
