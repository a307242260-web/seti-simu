'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,writeZ}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port')),{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const d=readZ(process.argv[2]),rows=d.results.filter(x=>x.card==='b_32.webp'&&x.name.startsWith('A3'));
assert.equal(rows.length,2);
assert.deepEqual(rows[0].end,rows[1].end);
const root=rows[0].end,m=open(root),seatId='player-white',port=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId,analysisPort:port}).decide({seatId,legalActions:m.menu()}).search;
 assert.deepEqual(m.save(),root);assert.equal(q.diagnostics.nativeExecutions,259);
 writeZ(process.argv[3],[{root,q}]);
 console.log(q.diagnostics.nativeExecutions,q.value);
}finally{port.close();m.dispose();}
