'use strict';
const assert=require('node:assert/strict');
const {open,readZ,writeZ,runCases}=require('./controlled-r3');
const [d,out]=process.argv.slice(2),x=readZ(d+'/amiba7-20261111-v1.json.gz'),root=x.root;
const a2='amiba_2.webp',a5='amiba_5.webp',a7='amiba_7.webp',b16='b_16.webp',d25='dlc_25.png',d17='dlc_17.png',d15='dlc_15.png';
const end=h=>h.act('end_turn');
const data=(h,label)=>{h.act('place_data');h.act('choose_target',a=>a.summary===label);};
const analysis=h=>{h.act('analyze');h.act('choose_target',a=>a.target.speciesId==='amiba'&&a.target.traceType==='blue'&&a.target.position===3);h.act('choose_card',a=>a.summary.includes('科学论文'));h.cut('analysis');};
const card=(h,id,pick,bonus)=>{h.take(h.m.play(id));h.take(h.m.pick(pick));const a=h.m.menu().find(q=>q.summary.includes(bonus));if(a)h.take(h.m.apply(a));else if(h.m.c.inspect().session)h.take(h.m.apply(h.m.menu()[0]));h.cut(id);};
const cases=[];
for(const order of ['A7 first','analysis first'])for(const first of [d25,d17])for(const payer of ['blue1','trade']){
 const second=first===d25?d17:d25;
 for(const mode of ['A5','B16']){
  if(mode==='B16'&&payer==='trade')continue;
  cases.push([[order,first,payer,mode].join(' / '),h=>{
   if(order==='analysis first'){analysis(h);end(h);}
   card(h,a7,first,'1数据');end(h);
   if(order==='A7 first')analysis(h);
   if(payer==='blue1')data(h,'blue1 下方');
   else{
    h.act('quick_trade',a=>a.target.tradeId==='cards-for-credit');
    for(const id of [b16,a2])h.act('choose_payment',a=>a.summary===id);
    h.act('choose_payment',a=>a.summary.startsWith('确认弃牌'));
   }
   if(h.m.facts().main)end(h);
   if(mode==='A5')card(h,a5,second,'1数据');
   else{
    h.take(h.m.play(b16));h.act('choose_target',a=>a.summary.endsWith('顺时针'));
    h.act('choose_target',a=>a.target.nebulaId==='sector-1-a');h.cut('B16');
   }
   h.cut('payment-tail');
  }]);
 }
}
writeZ(out,{root,...runCases(root,cases)});
