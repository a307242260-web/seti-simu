'use strict';
const {open,readZ,short}=require('./controlled-r3');
const d=readZ(process.argv[2]),m=open(d.roots[179]);
const fs=require('node:fs'),path=require('node:path'),cards=require(path.resolve('randomizer/game/cards/deck'));
const watch=new Set([194,200,202,203,206,208,210,212,215,219,221,223,228,235,237,242,245,247,253,258]);
function brief(a){return [a.family,a.summary,a.target];}
for(const x of d.ledger.filter(r=>r.i>=179&&r.i<=258)){
 const a=m.apply(x.input),f=short(m);
 console.log(JSON.stringify({i:x.i,a:a.summary,w:f.wallet,d:[f.computer.length,f.blue.length],income:f.income.slice(0,2),hand:f.hand,market:f.market}));
 if(watch.has(x.i))fs.appendFileSync(process.argv[3],JSON.stringify({i:x.i,f,menu:m.menu().filter(a=>['card_corner','play_card','scan','research_tech','choose_target','choose_card','choose_payment','move','industry','quick_trade','accept_optional_effect','complete_task'].includes(a.family)).map(brief)})+'\n');
}
m.dispose();
