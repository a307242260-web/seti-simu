# V673 third-round funding while retaining the first four-point reward

Use Production at cbd73e00c98455dac868bd43be3e1759130088a7 as the working
directory. Set p to the absolute archive directory. The scripts use immutable
included checkpoints; use fresh output names. The original standard ledger
and checkpoints are the same archived evidence referenced in
docs/human405-v673-r3-symbol-causality-20261111.md.

```sh
(cd "$p" && shasum -a 256 -c SHA256SUMS)
node "$p/verify.cjs" "$p"
node "$p/ledger.cjs" "$p/audit-20261111-v1.json.gz" "$p/replay-menus.jsonl" > "$p/replay-ledger.jsonl"
node "$p/income-move.cjs" "$p" "$p/replay-income-move.json.gz"
node "$p/amiba7.cjs" "$p" "$p/replay-amiba7.json.gz"
node "$p/recycle.cjs" "$p" "$p/replay-recycle.json.gz"
node "$p/orange-trigger.cjs" "$p" "$p/replay-orange-trigger.json.gz"
node "$p/move-corner.cjs" "$p" "$p/replay-move-corner.json.gz"
node "$p/fourth.cjs" "$p" "$p/replay-fourth.json.gz"
```

The verification command replays archived formal inputs without searching or
re-running the timing benchmarks. Search reruns use the same gates, but
wall-clock timings vary.
