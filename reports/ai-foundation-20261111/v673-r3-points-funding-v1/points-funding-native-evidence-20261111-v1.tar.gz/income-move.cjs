'use strict';
const assert=require('node:assert/strict');
const {open,readZ,writeZ,runCases}=require('./controlled-r3');
const [d,out]=process.argv.slice(2),b=readZ(d+'/audit-20261111-v1.json.gz');
const R=new Map(b.ledger.map(x=>[x.i,x.input])),a1='amiba_1.webp',a5='amiba_5.webp',a7='amiba_7.webp',a9='amiba_9.webp',b16='b_16.webp',d25='dlc_25.png',d17='dlc_17.png';
const name=(h,f,s)=>h.act(f,a=>a.summary===s), end=h=>h.act('end_turn');
function old(h,i){const a=R.get(i);return h.act(a.family,x=>x.summary===a.summary&&JSON.stringify(x.target)===JSON.stringify(a.target));}
const data=(h,s)=>{h.act('place_data');name(h,'choose_target',s);};
const comp=(h,...ns)=>ns.forEach(n=>data(h,'第一排放置位 '+n));
const tech=(h,t)=>{h.act('research_tech');h.act('choose_target',a=>a.target.tileId===t&&(t!=='blue1'||a.target.blueSlot===3));};
const pick=(h,id)=>h.take(h.m.pick(id));
const hand=(h,id)=>h.m.facts().hand.some(x=>x[1]===id);
function scan(h){h.act('scan');name(h,'choose_target','扫描 开普勒22');name(h,'choose_card','dlc_24.png → 开普勒22');h.act('choose_target',a=>a.target.speciesId==='amiba'&&a.target.traceType==='pink'&&a.target.position===3);h.act('choose_card',a=>a.summary.includes('生物特征筛选'));h.act('accept_optional_effect',a=>a.summary.includes('amiba_0'));h.act('complete_task',a=>a.summary.includes('dlc_9'));end(h);}
function movement(h,id){h.act('move',a=>a.summary.endsWith('向外'));name(h,'choose_payment','弃 1 张移动牌');if(h.m.menu()[0].family==='choose_card')name(h,'choose_card',id);}
function analysis(h){h.act('analyze');h.act('choose_target',a=>a.target.speciesId==='amiba'&&a.target.traceType==='blue'&&a.target.position===3);h.act('choose_card',a=>a.summary.includes('科学论文'));}
const options=[
 ['A7 money; A1 move; orange DLC25',a7,'skip',d25,a1],
 ['A7 money; A1 move; orange DLC20',a7,'skip','dlc_20.png',a1],
 ['A7 money; swap A1 to DLC25; DLC20 move',a7,'swap','dlc_20.png','dlc_20.png'],
 ['A1 money; A7 retained; Orange DLC20',a1,'skip','dlc_20.png','dlc_20.png'],
 ['A1 money; A7 retained; buy DLC25',a1,'buy','dlc_20.png','dlc_20.png'],
];
const m=open(b.roots[179]);
for(let i=179;i<=202;i++)m.apply(R.get(i));
const root=m.save();m.dispose();
const cases=[];
for(const [label,ic,market,orange,mover] of options)for(const tail of ['auto after scan','auto after blue1','A5 red points','A5 red points to analysis','after cash B16']){
 cases.push([label+' / '+tail,h=>{
   name(h,'choose_card','收入 '+ic);data(h,'blue2 下方');
   if(market==='swap')h.take(...h.m.swap(a1,d25));
   if(market==='buy'){h.act('quick_trade',a=>a.target.tradeId==='publicity-for-card');pick(h,d25);}
   h.cut('scan-wallet');end(h);scan(h);h.cut('after-scan');
   if(tail==='auto after scan')return;
   tech(h,'orange1');pick(h,orange);end(h);
   movement(h,mover);
   if(h.m.facts().wallet.publicity<6)h.take(h.m.corner(a9));
   tech(h,'blue1');comp(h,5,6);data(h,'blue1 下方');end(h);h.cut('after-blue1');
   if(tail==='auto after blue1')return;
   h.take(h.m.play(a5));
   const wanted=hand(h,d25)?d17:d25;
   pick(h,h.m.state().cards.publicCards.some(c=>c?.cardId===wanted)?wanted:'dlc_15.png');
   h.act('choose_target',a=>a.summary.includes('4分'));end(h);h.cut('after-A5');
   if(tail==='A5 red points')return;
   analysis(h);h.cut('after-analysis');
   if(tail==='A5 red points to analysis')return;
   // This is a feasibility witness, not search: fixed corner preference only to pay
   // the four-slot cash income. Protect B16, the chosen money card and DLC25.
   const cash=h.m.facts().hand.map(x=>x[1]).find(x=>[d17,'dlc_15.png','amiba_2.webp'].includes(x));
   assert(cash,'no known cash income');
   for(const id of [a7,'dlc_15.png',d17,'amiba_2.webp','dlc_14.png'])if(id!==cash&&hand(h,id)&&h.m.facts().wallet.availableData<4)h.take(h.m.corner(id));
   comp(h,1,2,3,4);name(h,'choose_card','收入 '+cash);end(h);
   h.take(h.m.play(b16));h.act('choose_target',a=>a.summary.endsWith('顺时针'));h.act('choose_target',a=>a.target.nebulaId==='sector-1-a');h.cut('extra-scan');
 }]);
}
writeZ(out,{root,...runCases(root,cases)});
