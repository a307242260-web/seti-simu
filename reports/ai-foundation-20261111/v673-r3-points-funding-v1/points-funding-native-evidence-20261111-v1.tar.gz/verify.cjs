'use strict';
const assert=require('node:assert/strict');
const {open,readZ}=require('./controlled-r3');
const dir=process.argv[2],r=n=>readZ(dir+'/'+n+'-20261111-v1.json.gz');
let n=0,third=0,bad=0,finished=0,gates=0;
function replay(root,trace,end){
 const m=open(root);
 try{
  for(const x of trace){if(x.n!==undefined)assert(x.n<=256&&x.ms<=600);
   if(x.passive)assert.notEqual(x.action.actorId,'player-white');
   m.apply(x.action||x);n++;
  }
  assert.deepEqual(m.save(),end);
  return {round:m.facts().round,score:m.state().match.finalScores?.find(x=>x.playerId==='player-white'),terminal:m.state().turn.gameEnded,menu:m.menu()};
 }finally{m.dispose();}
}
const a=r('audit'),b=r('income-move');
replay(a.roots[179],a.ledger.filter(x=>x.i>=179&&x.i<=202).map(x=>x.input),b.root);
for(const d of [b,r('amiba7'),r('recycle'),r('orange-trigger')]){
 for(const x of d.rows){replay(d.root,x.prefix,x.start);assert.equal(replay(x.start,x.actions,x.end).round,4);third++;}
 for(const x of d.failures){assert.deepEqual(JSON.parse(JSON.stringify(replay(d.root,x.prefix,x.checkpoint).menu)),x.menu);bad++;}
}
for(const x of r('orange-trigger').rows.filter(y=>y.label.endsWith('/ accept and analyze'))){
 const m=open(x.checkpoints['orange-menu'].state);
 try{assert.deepEqual(m.menu().map(a=>a.summary),['orange_1（2分）','orange_2（1盲抽）','orange_3（1宣传）']);}finally{m.dispose();}
}
const move=r('move-corner');
replay(move.source,move.lead,move.root);
for(const x of move.trials)replay(move.root,x.inputs,x.end);
const cand=move.choices.find(a=>a.family==='card_corner'&&a.summary.startsWith('amiba_1'));
assert.equal(move.result.roots.find(x=>x.actionId===cand.actionId).value,null);
for(const x of r('fourth').results){
 const got=replay(x.root,x.actions,x.end);
 if(x.stop==='terminal'){assert(got.terminal);assert.deepEqual(got.score,x.terminal);finished++;}
 else {assert(!got.terminal&&(x.stop.n>256||x.stop.ms>600)&&x.actions.slice(2).every(a=>a.passive&&a.n===undefined));gates++;}
}
assert.deepEqual([third,bad,finished,gates],[33,19,4,2]);
console.log(JSON.stringify({nativeReplayInputs:n,third,bad,finished,gates}));
