'use strict';
const assert=require('node:assert/strict');
const {open,readZ,writeZ,runCases}=require('./controlled-r3');
const [d,out]=process.argv.slice(2),b=readZ(d+'/income-move-20261111-v1.json.gz');
const root=b.rows.find(x=>x.label==='A1 money; A7 retained; Orange DLC20 / auto after blue1').start;
const a2='amiba_2.webp',a5='amiba_5.webp',a7='amiba_7.webp',b16='b_16.webp',d25='dlc_25.png',d17='dlc_17.png';
const data=(h,n)=>{h.act('place_data');h.act('choose_target',a=>a.summary==='第一排放置位 '+n);};
const ids=[d25,d17,'dlc_16.png'];
const m=open(root),menu=[];
try{
 for(const id of ids){
  m.restore(root);m.play(a7);m.pick(id);
  menu.push([id,m.menu().filter(x=>x.family==='choose_target').map(x=>[x.summary,x.target])]);
 }
}finally{m.dispose();}
console.log('menu',JSON.stringify(menu));
const cases=[];
for(const [id,choices] of menu)for(const [tag,t] of choices){
 if(!tag.includes('1数据')&&!tag.includes('4分'))continue;
 for(const mode of ['auto','retain B16']){
  cases.push([[id,tag,mode].join(' / '),h=>{
   h.take(h.m.play(a7));h.take(h.m.pick(id));h.act('choose_target',x=>x.target.slotId===t.slotId);h.cut('A7');h.act('end_turn');
   h.act('analyze');h.act('choose_target',a=>a.target.speciesId==='amiba'&&a.target.traceType==='blue'&&a.target.position===3);
   h.act('choose_card',a=>a.summary.includes('科学论文'));h.cut('analysis');
   if(mode==='auto')return;
   const known=k=>h.m.facts().hand.some(x=>x[1]===k);
   const e=known(d25)?d25:a5;
   // Use a data corner only when needed for the four-slot income.
   for(const k of [d17,a5,a2])if(k!==e&&known(k)&&h.m.facts().wallet.availableData<4)h.take(h.m.corner(k));
   for(let i=1;i<=4;i++)data(h,i);
   h.act('choose_card',a=>a.summary==='收入 '+e);h.cut('income');
  }]);
 }
}
writeZ(out,{root,menu,...runCases(root,cases)});
