'use strict';
const {open,readZ,writeZ,runCases}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),d=readZ(dir+'/income-move-20261111-v1.json.gz');
const root=d.rows.find(x=>x.label==='A7 money; A1 move; orange DLC25 / auto after scan').checkpoints['after-scan'].state;
const a1='amiba_1.webp',a9='amiba_9.webp';
const data=(h,s)=>{h.act('place_data');h.act('choose_target',a=>a.summary===s);};
const end=h=>h.act('end_turn');
const tech=(h,t)=>{h.act('research_tech');h.act('choose_target',a=>a.target.tileId===t&&(t!=='blue1'||a.target.blueSlot===3));};
function prep(h){
 tech(h,'blue1');for(const s of ['第一排放置位 5','第一排放置位 6','blue1 下方'])data(h,s);end(h);
 h.take(h.m.play(a1));end(h);h.take(h.m.corner(a9));h.cut('wallet');tech(h,'orange1');
}
const m=open(root);
const h={m,act:m.act,take:x=>x,cut:()=>{}};
let offers;
try{prep(h);offers=m.menu().map(x=>[x.family,x.summary,x.target]);}finally{m.dispose();}
console.log('offers',JSON.stringify(offers));
const cases=[];
for(const reward of offers.filter(x=>x[0]==='choose_card'&&['dlc_25.png','dlc_20.png','dlc_17.png'].includes(x[1])).map(x=>x[1])){
 for(const tail of ['auto','accept trigger','accept and analyze']){
  cases.push([reward+' / '+tail,h=>{
   prep(h);h.take(h.m.pick(reward));h.cut('offer');
   if(tail==='auto')return;
   h.act('accept_optional_effect',a=>a.summary.includes(a1));h.cut('orange-menu');
   const choice=h.m.menu().find(a=>a.family==='choose_target'&&a.summary.includes('1数据'))
    ||h.m.menu().find(a=>a.family==='choose_target'&&a.target.slotId);
   if(choice)h.take(h.m.apply(choice));
   h.cut('orange-reward');end(h);
   if(tail==='accept and analyze'){
    h.act('analyze');h.act('choose_target',a=>a.target.speciesId==='amiba'&&a.target.traceType==='blue'&&a.target.position===3);
    h.act('choose_card',a=>a.summary.includes('科学论文'));h.cut('after-analysis');
   }
  }]);
 }
}
if(!cases.length)throw Error(JSON.stringify(offers));
writeZ(out,{root,offers,...runCases(root,cases)});
