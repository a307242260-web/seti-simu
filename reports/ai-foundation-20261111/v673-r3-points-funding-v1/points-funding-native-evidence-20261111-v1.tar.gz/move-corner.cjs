'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {readZ,open,short,writeZ}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),b=readZ(dir+'/income-move-20261111-v1.json.gz');
const row=b.rows.find(x=>x.label==='A7 money; A1 move; orange DLC25 / auto after blue1');
const m=open(b.root),lead=[],trials=[];
try{
 for(const a of row.prefix){if(a.family==='move')break;lead.push(m.apply(a));}
 const root=m.save(),assets=short(m),choices=m.menu(),result=m.automatic();
 assert.deepEqual(m.save(),root);
 for(const mode of ['payment','corner']){
  m.restore(root);
  const inputs=mode==='payment'?[m.act('move',a=>a.summary.endsWith('向外')),m.act('choose_payment',a=>a.summary==='弃 1 张移动牌')]:
   [m.act('card_corner',a=>a.summary.startsWith('amiba_1.webp')&&a.payload.kind==='move'),m.act('choose_target',a=>a.summary.endsWith('向外'))];
  const end=m.save(),facts=short(m),rng=m.facts().rng;
  m.restore(root);inputs.forEach(m.apply);assert.deepEqual(m.save(),end);
  trials.push({mode,inputs,end,facts,rng});
 }
 assert.deepEqual(trials[0].rng,trials[1].rng);
 assert.deepEqual(trials[0].facts.probes,trials[1].facts.probes);
 assert.equal(trials[1].facts.wallet[0],trials[0].facts.wallet[0]+1);
 const {a,complete,n,ms,roots,value}=result;
 console.log(JSON.stringify({scoreBefore:assets.wallet[0],scores:trials.map(t=>t.facts.wallet[0]),complete,n,ms,value,selected:a?.summary,
 rootCount:roots?.length,rootFields:roots?.[0]&&Object.keys(roots[0]),roots:roots?.map(x=>({actionId:x.actionId,kind:x.kind,action:x.action?.summary,value:x.value})).slice(0,18)}));
 writeZ(out,{source:b.root,root,lead,assets,choices,trials,result:{a,complete,n,ms,roots,value}});
}finally{m.dispose();}
