'use strict';

const assert=require('node:assert/strict');
const path=require('node:path');
const {readZ,writeZ,runCases}=require('./controlled-r3');
const cards=require(path.resolve('randomizer/game/cards/deck'));
const {getProbeRouteRequirements}=require(path.resolve('randomizer/game/production-kernel'));
const [source,out]=process.argv.slice(2);
const dataset=readZ(source);
const sample=dataset.rows.find(row=>row.label==='9→0 / symbol:blue_3 / fixed yellow removal and analysis');
const root=sample.start;
function place(h,slot,id){
 h.act('place_data');h.act('choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');
 if(id&&slot)h.take(h.m.pick(id));
 if(id&&!slot)h.act('choose_card',a=>a.summary===`收入 ${id}`);
}
function end(h){h.act('end_turn');const passive=[];h.m.advanceOpponents(passive);h.take(...passive);}
function trade(h,kind,ids){
 h.act('quick_trade',a=>a.target.tradeId===kind);
 ids.forEach(id=>h.act('choose_payment',a=>a.target.select&&a.summary===id));
 h.act('choose_payment',a=>a.target.confirm);
}
function research(h,id,slot){h.act('research_tech');h.act('choose_target',a=>a.target.tileId===id&&(!slot||a.target.blueSlot===slot));}
function known(h){
 for(let i=0;i<12&&h.m.save().session;i++){
  const next=h.m.menu().find(a=>a.target?.source==='display'||a.target?.choiceId?.startsWith('confirm:trigger:'));
  if(!next)return;
  h.take(h.m.apply(next));
 }
}
function setup(h,energyIncome,scanCard,trace,payer,moveDir){
 research(h,'purple1');
 place(h);place(h);place(h);place(h,2,'dlc_25.png');
 place(h,null,energyIncome?'dlc_25.png':'amiba_1.webp');place(h,1);
 trade(h,energyIncome?'cards-for-credit':'cards-for-energy',payer);
 h.cut('scan-wallet');end(h);
 h.act('scan');h.act('choose_target',a=>a.target.nebulaId==='sector-3-a');
 h.act('choose_card',a=>a.summary===`${scanCard} → 开普勒22`);
 h.act('choose_target',a=>a.target.choiceId===`scan4:move:6:${moveDir}`);
 h.act('choose_target',a=>a.target.choiceId===(trace==='reveal'?'trace:2:pink':'trace:1:pink:amiba:3'));
 known(h);
 h.act('complete_task',a=>a.summary.includes('dlc_9.png'));end(h);
 h.cut('after-scan');
}
function move(h,step,card){
 h.act('move',a=>a.target.deltaX===step.deltaX&&a.target.deltaY===step.deltaY);
 h.act('choose_payment',a=>card?a.target.cardIds?.some(id=>h.m.player().hand.some(c=>c.id===id&&c.cardId===card)):a.summary==='消耗 1 能量');
}
function cargo(h){
 research(h,'blue1',3);
 place(h);place(h,3);place(h);end(h);
 h.act('analyze');h.act('choose_target',a=>a.target.choiceId==='trace:2:blue:chong:9');known(h);
 h.cut('analysis-ready');end(h);
 const goal=getProbeRouteRequirements(h.m.state(),'player-white').candidates.find(a=>a.planetId==='saturn'&&a.endpointFamily==='land'&&!a.endpointTarget?.satelliteId);
 assert(goal);
 const player=h.m.player(), usable=player.hand.filter(c=>c.cardId!=='chong_9.webp');
 const energy=Math.min(player.resources.energy,goal.path.length), remaining=goal.path.length-energy;
 const moveCards=usable.filter(c=>cards.getDiscardActionMoveRewardForCard(c)).slice(0,remaining);
 const moneyCards=usable.filter(c=>!moveCards.includes(c)).slice(0,2);
 assert(moveCards.length===remaining&&(player.resources.credits>=2||moneyCards.length===2),
  `paid route ${goal.path.length} moves needs ${remaining} card moves + 2 cards for credit; ${usable.map(x=>x.cardId).join(',')}`);
 if(player.resources.credits<2)trade(h,'cards-for-credit',moneyCards.map(c=>c.cardId));
 goal.path.forEach((step,i)=>move(h,step,moveCards[i]?.cardId));
 h.take(h.m.play('chong_9.webp'));
 h.act('choose_target',a=>a.target.planetId==='saturn'&&!a.target.landTarget?.satelliteId);
 h.cut('cargo-menu');
 h.act('choose_target',a=>a.target.choiceId==='trace:1:yellow:amiba:4');known(h);
 h.act('choose_target',a=>a.target.fossilId==='fossil_01');
 h.cut('loaded');
}
const cases=[];
for(const mode of ['cash','electricity'])for(const scan of ['dlc_24.png','dlc_17.png']){
 const power=mode==='electricity';
 for(const trace of ['amiba','reveal'])for(const dir of ['out','ccw']){
  cases.push([`${mode} / ${scan} / ${trace} / ${dir} / autonomous`,h=>setup(h,power,scan,trace,['dlc_32.png','b_16.webp'],dir)]);
 }
 if(power)for(const dir of ['out','ccw','cw'])for(const payer of ['b_16.webp','amiba_7.webp']){
  cases.push([`${mode} / ${scan} / ${payer} / ${dir} / fixed cargo`,h=>{
   setup(h,power,scan,'reveal',['dlc_32.png',payer],dir);cargo(h);
  }]);
 }
}
writeZ(out,{root,parent:{root:dataset.root,prefix:sample.prefix},...runCases(root,cases)});
