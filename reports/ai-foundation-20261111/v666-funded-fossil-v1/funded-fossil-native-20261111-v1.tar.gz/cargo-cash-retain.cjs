'use strict';

const assert=require('node:assert/strict');
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [file,out]=process.argv.slice(2), input=readZ(file);
function place(h){h.act('place_data');h.act('choose_target',a=>a.target.target==='computer');}
function cash(h,market,mode){
 if(mode==='buy'){
  h.act('quick_trade',a=>a.target.tradeId==='publicity-for-card');h.take(h.m.pick(market));
 }else h.take(...h.m.swap(mode,market));
 place(h);place(h);place(h);
 h.act('choose_card',a=>a.summary===`收入 ${market}`);
 h.act('complete_task',a=>a.target.ruleId==='b117-orbit-land-count-task');
 assert.equal(h.m.player().income.credits,7);assert.equal(h.m.player().income.energy,4);
 h.cut('seventh-credit');
}
function end(h){h.act('end_turn');const passive=[];h.m.advanceOpponents(passive);h.take(...passive);}
function orange(h){
 if(h.m.player().resources.publicity<6)h.take(h.m.corner('b_9.webp'));
 h.act('research_tech');h.act('choose_target',a=>a.target.tileId==='orange1');
 const known=h.m.facts().market;
 const card=known.find(c=>c?.[1]==='dlc_15.png');
 if(card)h.take(h.m.pick(card[1]));
 h.cut('orange1');
}
const groups=[];
for(const branch of input.rows){
 const loaded=branch.checkpoints.loaded;
 if(!loaded)continue;
 const market=loaded.summary.market.find(c=>c==='dlc_17.png'||c==='dlc_15.png');
 const cases=[];
 for(const mode of ['buy','amiba_5.webp','b_9.webp']){
  cases.push([`${market} / ${mode} / autonomous`,h=>cash(h,market,mode)]);
  if(mode==='amiba_5.webp')cases.push([`${market} / ${mode} / orange1`,h=>{cash(h,market,mode);end(h);orange(h);}]);
 }
 groups.push({label:branch.label,root:loaded.state,...runCases(loaded.state,cases)});
}
writeZ(out,{groups});
