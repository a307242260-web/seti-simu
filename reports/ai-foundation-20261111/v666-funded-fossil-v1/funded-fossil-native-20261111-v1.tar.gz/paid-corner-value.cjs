'use strict';

const assert=require('node:assert/strict');
const {open,readZ,writeZ,short}=require('./controlled-r3');
const [source,out,mode]=process.argv.slice(2);
const src=readZ(source);
const seedRoot=src.source;
const seat='player-white';
function applyVariant(root,variant){
 const e=structuredClone(root),s=JSON.parse(e.committedState);
 if(variant.includes('ordinary'))[s.cards.drawPileCardIds[0],s.cards.drawPileCardIds[1]]=[s.cards.drawPileCardIds[1],s.cards.drawPileCardIds[0]];
 if(variant.includes('amiba'))[s.aliens.amiba.cardDeck[0],s.aliens.amiba.cardDeck[1]]=[s.aliens.amiba.cardDeck[1],s.aliens.amiba.cardDeck[0]];
 e.committedState=JSON.stringify(s);return e;
}
const results=[];
let reference;
for(const variant of ['original','ordinary','amiba','ordinary and amiba']){
 const landed=applyVariant(seedRoot,variant),m=open(landed),prefix=[];
 const act=(family,predicate)=>prefix.push(m.act(family,predicate));
 function place(slot){act('place_data');act('choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');}
 try{
  for(let i=0;i<3;i++)place();
  act('complete_task',a=>a.target.ruleId==='b117-orbit-land-count-task');
  const root=m.save(),base=m.automatic();
  const known={observation:m.owner(seat),menu:m.menu(),v:base.value,n:base.n,chosen:base.a.actionId,roots:base.roots};
  if(reference)assert.deepEqual(known,reference);else reference=known;
  console.log('ROOT',variant,JSON.stringify({base:base.a.summary,n:base.n,v:base.value,roots:base.roots.map(r=>[known.menu.find(a=>a.actionId===r.actionId)?.summary,r.value])}));
  for(const plan of ['production','dlc_15.png','dlc_17.png']){
   m.restore(root); const fixed=[];prefix.length=0;
   if(plan!=='production'){
    act('quick_trade',a=>a.target.tradeId==='publicity-for-card');prefix.push(m.pick(plan),m.corner(plan));
    place();act('choose_card',a=>a.summary==='收入 dlc_14.png');act('end_turn');
    fixed.push(...prefix);
   }
   let cp,stop;
   const auto=[];
   for(let i=0;i<40;i++){
    if(mode==='retain'&&plan!=='production'&&m.menu().some(a=>a.family==='pass')){stop='pre-pass';break;}
    const q=m.automatic(cp);
    if(!q.a||!q.complete||q.n>256||q.ms>600){stop={gate:q.n,ms:q.ms,action:q.a?.summary};break;}
    if(q.a.family==='pass'){stop='pre-pass';break;}
    cp=q.checkpoint;auto.push({a:m.apply(q.a),n:q.n,ms:q.ms});
   }
   assert(stop); const prePass=m.save(),r3=short(m);
   m.restore(root);fixed.forEach(m.apply);auto.forEach(x=>m.apply(x.a));assert.deepEqual(m.save(),prePass);
   if(stop!=='pre-pass'){results.push({variant,plan,root,fixed,auto,prePass,stop});continue;}
   for(const reserve of ['b_111.webp','b_32.webp']){
    m.restore(prePass);
    const actions=[{a:m.act('pass')},{a:m.act('choose_card',a=>a.summary===reserve)}];
    let stop4, checkpoint;
    for(let i=0;i<180;i++){
     if(m.state().turn.gameEnded){stop4='terminal';break;}
     if(m.menu()[0].actorId!==seat){const passive=[];m.advanceOpponents(passive);actions.push(...passive.map(a=>({a})));continue;}
     const q=m.automatic(checkpoint);
     if(!q.a||!q.complete||q.n>256||q.ms>600){stop4={gate:q.n,ms:q.ms,action:q.a?.summary};break;}
     checkpoint=q.checkpoint;actions.push({a:m.apply(q.a),n:q.n,ms:q.ms});
    }
    assert(stop4); const end=m.save(),terminal=stop4==='terminal'?m.state().match.finalScores.find(p=>p.playerId===seat):null;
    m.restore(prePass);actions.forEach(x=>m.apply(x.a));assert.deepEqual(m.save(),end);
    const peak=[Math.max(0,...actions.map(a=>a.n||0)),Math.max(0,...actions.map(a=>a.ms||0))];
    results.push({variant,plan,reserve,root,fixed,auto,prePass,r3,actions,stop4,end,terminal,peak});
    console.log(JSON.stringify([variant,plan,reserve,r3.wallet,r3.income,r3.hand,stop4,terminal?.totalScore,peak]));
   }
  }
 }finally{m.dispose();}
}
writeZ(out,{seedRoot,reference,results});
