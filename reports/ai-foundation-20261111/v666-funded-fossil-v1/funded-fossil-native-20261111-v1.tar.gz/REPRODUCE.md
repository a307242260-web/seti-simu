# V666 火星筹资、预先插电和化石返程复放

在 `c30b18dd1` 的 Production 源码根运行 `node /解压目录/verify.cjs`。源码目录须带有 `26a0e5d91` 登记的 V666 正式报告、两个轮末检查点与动作记录。验证器复放标准第二轮末到第三轮结束，核对第 145、180 步。第三轮固定输入在 `prefix`，其后白席自主输入在 `actions`。`settled` 在白席第三轮提交 PASS 之前。第四轮结果固定保留 B111 或 B32，`return-cargo` 另固定最短返程和领取任务。上游已复放的土星登陆存档来自 `previous-retained-income-20261111-v1.json.gz`，公开来源见同批报告的链接。

归档另含各对照的生成脚本。前三个脚本接受 V666 标准的 `{ rows: [{ i, a, before }] }` 轨迹，由正式第二轮检查点逐输入重放取得。`early-electric-cargo`、`early-electric-route` 接收 `mars-dual-amiba` 的归档结果，`cargo-cash-retain` 接收 `early-electric-route`。`early-fourth` 和 `cash-fourth` 的前两个输入分别是 `early-electric-cargo`、`early-electric-route` 的结果。`cash-fourth` 还接受第四个参数 `cargo-cash-retain` 结果。`return-cargo` 接受 `cash-fourth` 的结果。`paid-corner-value` 使用上游 `previous-retained-income` 作为输入，第三个参数 `retain` 表示固定在插电后的回合收尾 PASS。输出位置使用新路径。

`verification-20261111-v1.json` 记录已提交输入、完整终局和未提交的门槛超限。耗时是各次实际测量，复放器校验动作、信封、轮末与终局，无需重新搜索。
