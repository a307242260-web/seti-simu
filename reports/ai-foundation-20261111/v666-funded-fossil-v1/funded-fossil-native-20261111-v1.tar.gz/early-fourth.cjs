'use strict';

const assert=require('node:assert/strict');
const {open,readZ,writeZ,short}=require('./controlled-r3');
const [early,route,out]=process.argv.slice(2);
const controls=readZ(early).rows.filter(x=>x.settled&&x.settled.summary.wallet[0]>=120&&x.settled.summary.income[1]===4);
const candidate=readZ(route).rows.filter(x=>x.settled?.summary.probes.some(r=>r[2]));
const cases=controls.concat(candidate).map(x=>[x.label,x.settled.state]);
const results=[];
for(const [name,root] of cases)for(const card of ['b_111.webp','b_32.webp']){
 const m=open(root),actions=[];
 try{
  actions.push({action:m.act('pass')});
  const reserve=m.menu().find(a=>a.summary===card);
  assert(reserve);
  actions.push({action:m.apply(reserve)});
  let cp,stop;
  for(let i=0;i<200;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!=='player-white'){
    const passive=[];m.advanceOpponents(passive);actions.push(...passive.map(action=>({action,passive:true})));continue;
   }
   const q=m.automatic(cp);
   if(!q.a||!q.complete||q.n>256||q.ms>600){stop={kind:'gate',n:q.n,ms:q.ms,action:q.a?.summary,turn:m.facts().turn};break;}
   cp=q.checkpoint;actions.push({action:m.apply(q.a),n:q.n,ms:q.ms,value:q.value});
  }
  assert(stop);
  const end=m.save(), terminal=stop==='terminal'?m.state().match.finalScores.find(p=>p.playerId==='player-white'):null;
  const peak=[Math.max(0,...actions.map(x=>x.n||0)),Math.max(0,...actions.map(x=>x.ms||0))];
  console.log(JSON.stringify([name,card,stop,terminal?.totalScore,peak,short(m)]));
  m.restore(root);actions.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),end);
  results.push({name,card,root,actions,stop,terminal,peak,end});
 }finally{m.dispose();}
}
writeZ(out,{results});
