'use strict';

const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {open,readZ,short}=require('./controlled-r3');
const read=name=>readZ(path.join(__dirname,name));
const report=JSON.parse(fs.readFileSync('reports/research/31f6eb84.c30b18dd.quick-400.json'));
const save=JSON.parse(fs.readFileSync(report.savePath));
const checkpoint=JSON.parse(fs.readFileSync(report.roundEnds[1].checkpointPath)).coreState.compositionEnvelope;
const m=open(checkpoint),roots=new Map();
let formalInputs=0;
try{
 for(let i=report.roundEnds[1].beforeInput;i<=save.replaySteps.length;i++){
  if([145,180].includes(i))roots.set(i,m.save());
  m.apply(save.replaySteps[i-1].action);formalInputs++;
 }
 assert.equal(m.save().committedState,save.committedState);assert.deepEqual(m.save().session,save.session);
}finally{m.dispose();}
const files={
 before:read('funding-before-reveal-20261111-v1.json.gz'),
 mars:read('mars-credit-20261111-v2.json.gz'),
 dual:read('mars-dual-amiba-20261111-v1.json.gz'),
 early:read('early-electric-cargo-20261111-v2.json.gz'),
 route:read('early-electric-route-20261111-v1.json.gz'),
 cash:read('cargo-cash-retain-20261111-v1.json.gz'),
};
assert.deepEqual(files.before.root,roots.get(180));
assert.deepEqual(files.mars.root,roots.get(145));
assert.deepEqual(files.dual.root,roots.get(145));
for(const branch of [files.early,files.route]){
 assert.deepEqual(branch.parent.root,roots.get(145));
 const m=open(branch.parent.root);
 try{branch.parent.prefix.forEach(m.apply);assert.deepEqual(m.save(),branch.root);}finally{m.dispose();}
}
for(const group of files.cash.groups)assert(files.route.rows.some(r=>JSON.stringify(r.checkpoints.loaded.state)===JSON.stringify(group.root)));
const stats={formalInputs,thirdBranches:0,failedPrefixes:0,terminal:0,nativeInputs:0,maxNative:0,maxMilliseconds:0,gates:[]};
const checkpointStates=new Set();
function actions(m,rows,settled){
 for(const x of rows){
  const a=x.action||x.a||x;
  if(settled&&a.family==='pass'&&a.actorId==='player-white'&&m.facts().round===3)assert.deepEqual(m.save(),settled.state);
  if(x.n!==undefined){assert(x.n<=256&&x.ms<=600);stats.maxNative=Math.max(stats.maxNative,x.n);stats.maxMilliseconds=Math.max(stats.maxMilliseconds,x.ms);}
  m.apply(a);stats.nativeInputs++;
 }
}
function group(root,result){
 const m=open(root);
 try{
  for(const row of result.rows){
   m.restore(root);actions(m,row.prefix);assert.deepEqual(m.save(),row.start);
   actions(m,row.actions,row.settled);assert.deepEqual(m.save(),row.end);
   stats.thirdBranches++;
   if(row.settled){
    checkpointStates.add(JSON.stringify(row.settled.state));
    const after=m.save();m.restore(row.settled.state);
    assert.deepEqual(JSON.parse(JSON.stringify(short(m))),row.settled.summary);m.restore(after);
   }
   if(row.stop?.kind==='gate')stats.gates.push({label:row.label,...row.stop});
  }
  for(const row of result.failures){m.restore(root);actions(m,row.prefix);assert.deepEqual(m.save(),row.checkpoint);stats.failedPrefixes++;}
 }finally{m.dispose();}
}
for(const item of [files.before,files.mars,files.dual,files.early,files.route])group(item.root,item);
files.cash.groups.forEach(g=>group(g.root,g));
for(const name of ['early-fourth','cash-fourth']){
 for(const row of read(`${name}-20261111-v1.json.gz`).results){
  assert(checkpointStates.has(JSON.stringify(row.root)));
  const m=open(row.root);
  try{actions(m,row.actions);assert.deepEqual(m.save(),row.end);assert(m.state().turn.gameEnded);assert.deepEqual(m.state().match.finalScores.find(x=>x.playerId==='player-white'),row.terminal);stats.terminal++;}finally{m.dispose();}
 }
}
for(const row of read('return-cargo-20261111-v1.json.gz').results){
 assert(checkpointStates.has(JSON.stringify(row.root)));
 const m=open(row.root);
 try{
  actions(m,row.before);assert.deepEqual(m.save(),row.entry);
  actions(m,row.fixed);assert.deepEqual(m.save(),row.afterFixed);
  assert.deepEqual(JSON.parse(JSON.stringify(short(m))),row.delivered);
  actions(m,row.auto);assert.deepEqual(m.save(),row.end);assert(m.state().turn.gameEnded);
  assert.deepEqual(m.state().match.finalScores.find(x=>x.playerId==='player-white'),row.terminal);stats.terminal++;
 }finally{m.dispose();}
}
const prior=read('previous-retained-income-20261111-v1.json.gz');
for(const name of ['paid-corner-value','paid-corner-value-retain']){
 const data=read(`${name}-20261111-v1.json.gz`);assert.deepEqual(data.seedRoot,prior.source);
 for(const row of data.results){
  const m=open(row.root);
  try{
   actions(m,row.fixed);actions(m,row.auto);assert.deepEqual(m.save(),row.prePass);
   actions(m,row.actions);assert.deepEqual(m.save(),row.end);
   assert(m.state().turn.gameEnded);assert.deepEqual(m.state().match.finalScores.find(x=>x.playerId==='player-white'),row.terminal);stats.terminal++;
  }finally{m.dispose();}
 }
}
console.log(JSON.stringify(stats));
