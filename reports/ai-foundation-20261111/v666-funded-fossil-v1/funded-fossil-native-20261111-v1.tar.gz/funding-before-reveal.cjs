'use strict';

const assert=require('node:assert/strict');
const path=require('node:path');
const {open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const cards=require(path.resolve('randomizer/game/cards/deck'));
const {getProbeRouteRequirements}=require(path.resolve('randomizer/game/production-kernel'));
const [source,out]=process.argv.slice(2), rows=readZ(source).rows;
const root=rows.find(r=>r.i===180).before;
const choose=(h,id)=>h.act('choose_target',a=>a.target.choiceId===id);
function end(h){ h.act('end_turn'); const a=[]; h.m.advanceOpponents(a);h.take(...a); }
function place(h,slot,pick){
 h.act('place_data');h.act('choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');
 if(pick) h.take(h.m.pick(pick));
}
function buy(h,id){h.act('quick_trade',a=>a.target.tradeId==='publicity-for-card');h.take(h.m.pick(id));}
function pay(h,trade,pair){
 h.act('quick_trade',a=>a.target.tradeId===trade);
 for(const id of pair)h.act('choose_payment',a=>a.summary===id&&a.target.select);
 h.act('choose_payment',a=>a.target.confirm);
}
function early(h,kind,extra,scan,trace){
 choose(h,extra?'symbol:blue_3':'symbol:blue_1');
 rows.filter(r=>r.i>=181&&r.i<=205).forEach(r=>h.take(h.m.apply(r.a)));
 assert.equal(h.m.player().resources.energy,2);
 h.cut('before-card-supply');
 if(kind==='normal') {h.take(h.m.corner('amiba_7.webp'));place(h,2,'dlc_25.png');}
 if(kind==='publicity') buy(h,'dlc_25.png');
 end(h);
 h.act('scan'); h.act('choose_target',a=>a.target.nebulaId==='sector-3-a');
 h.act('choose_card',a=>a.summary===`${scan} → 开普勒22`);
 h.cut('before-trace');
 choose(h,trace==='reveal'?'trace:2:pink':'trace:1:pink:amiba:3');
 if(trace!=='reveal') h.act('choose_card',a=>a.target.source==='display');
 h.act('accept_optional_effect',a=>a.target.choiceId?.includes('amiba0')&&a.target.choiceId.startsWith('confirm:'));
 h.act('complete_task',a=>a.summary.includes('dlc_9.png'));
 end(h);h.cut('after-trace');
}
function research(h,id,slot){
 h.act('research_tech');h.act('choose_target',a=>a.target.tileId===id&&(!slot||a.target.blueSlot===slot));
}
function movement(h,step,payer){
 h.act('move',a=>a.target.deltaX===step.deltaX&&a.target.deltaY===step.deltaY);
 h.act('choose_payment',a=>payer?a.target.cardIds?.some(id=>h.m.player().hand.some(c=>c.id===id&&c.cardId===payer)):a.summary==='消耗 1 能量');
}
function publicity(h){
 const pub=()=>h.m.player().resources.publicity;
 for(const id of ['amiba_9.webp','b_16.webp'])if(pub()<6&&h.m.facts().hand.some(c=>c[1]===id))h.take(h.m.corner(id));
 assert(pub()>=6,`only ${pub()} publicity after funded corners`);
}
function prepareCargo(h,{preMove=true,optionalBuy=false,extraCard=null}){
 if(optionalBuy) buy(h,optionalBuy);
 if(!h.m.facts().hand.some(c=>c[1]==='dlc_25.png'))place(h,2,'dlc_25.png');
 research(h,'orange1');
 const available=h.m.facts().market;
 const gift=['dlc_20.png','dlc_16.png'].find(id=>available.some(c=>c?.[1]===id));
 assert(gift,'no visible mover for launch'); h.take(h.m.pick(gift)); end(h);
 if(preMove)movement(h,{deltaX:0,deltaY:1},gift);
 publicity(h);
 research(h,'blue1',3);
 // The known blue 1 cash slot needs the fifth computer cell, and a sixth cell gives free analysis.
 const reserve=()=>h.m.player().resources.availableData;
 if(reserve()<3){h.take(h.m.corner('amiba_7.webp'));}
 assert(reserve()>=3);
 place(h);place(h,3);place(h);end(h);
 h.act('analyze');choose(h,'trace:2:blue:chong:9');
 h.act('choose_card',a=>a.target.source==='display'&&a.target.cardIndex===9);
 if(extraCard)buy(h,extraCard);
 end(h);h.cut('before-cargo-payment');
 const goal=getProbeRouteRequirements(h.m.state(),'player-white').candidates.find(a=>a.planetId==='saturn'&&a.endpointFamily==='land'&&!a.endpointTarget?.satelliteId);
 assert(goal);
 const hand=h.m.player().hand.filter(c=>!['dlc_25.png','chong_9.webp'].includes(c.cardId));
 const movers=hand.filter(c=>cards.getDiscardActionMoveRewardForCard(c)).slice(0,goal.path.length);
 const others=hand.filter(c=>!movers.includes(c)).slice(0,2);
 assert(movers.length===goal.path.length&&others.length===2,
  `requires ${goal.path.length} move cards and 2 trade cards; disposable ${hand.map(c=>c.cardId).join(',')}`);
 pay(h,'cards-for-credit',others.map(c=>c.cardId));
 goal.path.forEach((step,i)=>movement(h,step,movers[i].cardId));
 h.take(h.m.play('chong_9.webp'));
 h.act('choose_target',a=>a.target.planetId==='saturn'&&!a.target.landTarget?.satelliteId);
 h.cut('landing');
}
const cases=[];
for(const extra of [false,true])for(const kind of ['normal','late','publicity'])for(const trace of ['reveal','amiba']){
 cases.push([`${extra?'blue press':'blue points'} / ${kind} / ${trace} / autonomous`,h=>early(h,kind,extra,'dlc_24.png',trace)]);
 if(trace==='reveal')for(const preMove of [true,false]){
  cases.push([`${extra?'blue press':'blue points'} / ${kind} / reveal / fund / preMove ${preMove}`,h=>{
   early(h,kind,extra,'dlc_24.png',trace);prepareCargo(h,{preMove});
  }]);
 }
}
writeZ(out,{root,...runCases(root,cases)});
