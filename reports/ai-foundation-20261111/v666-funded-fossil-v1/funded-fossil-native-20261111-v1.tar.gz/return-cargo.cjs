'use strict';

const assert=require('node:assert/strict');
const {open,readZ,writeZ,short}=require('./controlled-r3');
const {pathToEarth}=require('./shortest-return-20261110-v1.cjs');
const [input,out]=process.argv.slice(2);
const results=[];
for(const source of readZ(input).results){
 const m=open(source.root),before=[],fixed=[],auto=[];
 try{
  for(const x of source.actions){
   if(m.facts().round===4&&x.action.actorId==='player-white')break;
   before.push(m.apply(x.action));
  }
  assert.equal(m.facts().round,4);assert.equal(m.menu()[0].actorId,'player-white');
  const entry=m.save(),root=short(m),route=pathToEarth(m,'fossil_06');
  if(root.wallet[2]<route.cost){console.log('not-funded',source.name,source.card,root.wallet[2],route.cost);continue;}
  for(const step of route.path){
   fixed.push(m.act('move',a=>a.target.rocketId===route.rocketId&&a.target.deltaX===step.deltaX&&a.target.deltaY===step.deltaY));
   fixed.push(m.act('choose_payment',a=>a.summary===`消耗 ${step.cost} 能量`));
  }
  const arrival=m.facts(),action=m.menu().find(a=>a.family==='complete_task'&&a.target.ruleId==='transport');
  assert(action);fixed.push(m.apply(action));
  const delivered=short(m),afterFixed=m.save();
  assert.equal(m.facts().probes.some(r=>r.fossilId==='fossil_06'),false);
  let stop,cp;
  for(let i=0;i<180;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!=='player-white'){const a=[];m.advanceOpponents(a);auto.push(...a.map(action=>({action})));continue;}
   const q=m.automatic(cp);
   if(!q.a||!q.complete||q.n>256||q.ms>600){stop={gate:q.n,ms:q.ms,action:q.a?.summary};break;}
   cp=q.checkpoint;auto.push({action:m.apply(q.a),n:q.n,ms:q.ms});
  }
  assert(stop);
  const end=m.save(),terminal=stop==='terminal'?m.state().match.finalScores.find(p=>p.playerId==='player-white'):null;
  const peak=[Math.max(0,...auto.map(x=>x.n||0)),Math.max(0,...auto.map(x=>x.ms||0))];
  console.log(JSON.stringify([source.name,source.card,route.cost,root.wallet,delivered.wallet,source.terminal.totalScore,stop,terminal?.totalScore,peak]));
  m.restore(source.root);before.forEach(m.apply);assert.deepEqual(m.save(),entry);fixed.forEach(m.apply);
  assert.deepEqual(m.save(),afterFixed);auto.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),end);
  results.push({name:source.name,card:source.card,root:source.root,before,entry,route,fixed,arrival,delivered,afterFixed,auto,end,terminal,peak,stop});
 }finally{m.dispose();}
}
writeZ(out,{results});
