'use strict';

const assert=require('node:assert/strict');
const {open,readZ,writeZ,runCases}=require('./controlled-r3');
const [source,out]=process.argv.slice(2);
const root=readZ(source).rows.find(r=>r.i===145).before;
function place(h,slot){h.act('place_data');h.act('choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');}
function end(h){
 h.act('end_turn');
 for(const id of ['final:a','final:b','final:d'])if(h.m.menu().some(a=>a.target?.choiceId===id))h.act('choose_target',a=>a.target?.choiceId===id);
 const passive=[];h.m.advanceOpponents(passive);h.take(...passive);
}
function buy(h,via,id){
 h.act('quick_trade',a=>a.target.tradeId===via);
 if(via==='credits-for-card'){
  const shown=h.m.menu().find(a=>a.summary===id);
  if(shown)h.take(h.m.apply(shown));else h.take(h.m.menu().length===1?h.m.apply(h.m.menu()[0]):h.m.pick(id));
 }else h.take(h.m.pick(id));
}
function land(h,kind){
 if(kind==='company')h.take(...h.m.swap('dlc_32.png','dlc_31.png'));
 place(h);place(h);place(h,1);
 if(kind==='publicity')buy(h,'publicity-for-card','dlc_31.png');
 if(kind==='blue3'){
  h.take(h.m.corner('dlc_32.png'));
  place(h);
 }
 if(kind==='blue3')return;
 end(h);
 h.act('move',a=>a.target.deltaX===0&&a.target.deltaY===1);
 h.act('choose_payment',a=>a.summary==='消耗 1 能量');
 h.take(h.m.play('dlc_31.png'));
 h.act('choose_target',a=>a.target.planetId==='mars'&&!a.target.landTarget?.satelliteId);
 h.act('choose_target',a=>a.target.alienSlotId===1&&a.target.traceType==='yellow');
 place(h);place(h);
 h.act('choose_card',a=>a.summary==='收入 b_101.webp');
 h.cut('after-income');
 end(h); h.cut('after-reveal');
}
function amiba(h,action){
 h.take(h.m.play(action));
 h.cut('card-played');
 const menu=h.m.menu().find(a=>a.target?.choiceId==='symbol:blue_1'||a.target?.choiceId==='symbol:orange_2');
 if(menu)h.take(h.m.apply(menu));
 if(!h.m.save().session)end(h);
}
function winFirstPink(h){
 h.take(h.m.play('dlc_19.png'));
 h.act('choose_target',a=>a.target.nebulaId==='sector-1-b');
 h.act('choose_target',a=>a.target.nebulaId==='sector-1-b');
 h.act('choose_target',a=>a.target.choiceId==='trace:1:pink:amiba:4');
 h.act('choose_card',a=>a.target.source==='display');end(h);
}
function prep(h,order,area){
 land(h,'publicity');winFirstPink(h);
 h.cut('first-pink');
 for(const id of order){
  h.take(h.m.play(`amiba_${id}.webp`));
  if(h.m.save().session)h.act('choose_target',a=>id===9?a.summary.includes('数据'):a.target.choiceId===area);
  end(h);h.cut(`after-amiba${id}`);
 }
}
const cases=[];
for(const order of [[9,0],[0,9]])for(const area of ['symbol:blue_1','symbol:blue_3']){
 cases.push([`${order.join('→')} / ${area} / autonomous`,h=>prep(h,order,area)]);
 cases.push([`${order.join('→')} / ${area} / fixed yellow removal and analysis`,h=>{
  prep(h,order,area);
  place(h);place(h);
  h.take(h.m.play('amiba_3.webp'));
  h.act('choose_target',a=>a.target.choiceId==='trace:yellow:1');end(h);
  h.act('analyze');h.act('choose_target',a=>a.target.choiceId==='trace:1:blue:amiba:4');
  h.act('choose_card',a=>a.target.source==='display');
  for(let i=0;i<4&&h.m.save().session;i++){
   const action=h.m.menu().find(a=>a.target.choiceId?.startsWith('confirm:'));
   if(!action)break;h.take(h.m.apply(action));
  }
  end(h);h.cut('analysis');
 }]);
}
writeZ(out,{root,...runCases(root,cases)});
