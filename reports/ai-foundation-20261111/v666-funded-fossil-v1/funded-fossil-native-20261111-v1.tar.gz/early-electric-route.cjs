'use strict';

const assert=require('node:assert/strict');
const path=require('node:path');
const {readZ,writeZ,runCases}=require('./controlled-r3');
const cards=require(path.resolve('randomizer/game/cards/deck'));
const {getProbeRouteRequirements}=require(path.resolve('randomizer/game/production-kernel'));
const [source,out]=process.argv.slice(2);
const dataset=readZ(source);
const sample=dataset.rows.find(row=>row.label==='9→0 / symbol:blue_3 / fixed yellow removal and analysis');
const root=sample.start;
function place(h,slot,id){
 h.act('place_data');h.act('choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');
 if(id&&slot)h.take(h.m.pick(id));
 if(id&&!slot)h.act('choose_card',a=>a.summary===`收入 ${id}`);
}
function end(h){h.act('end_turn');const passive=[];h.m.advanceOpponents(passive);h.take(...passive);}
function trade(h,kind,ids){
 h.act('quick_trade',a=>a.target.tradeId===kind);
 ids.forEach(id=>h.act('choose_payment',a=>a.target.select&&a.summary===id));
 h.act('choose_payment',a=>a.target.confirm);
}
function research(h,id,slot){h.act('research_tech');h.act('choose_target',a=>a.target.tileId===id&&(!slot||a.target.blueSlot===slot));}
function known(h){
 for(let i=0;i<12&&h.m.save().session;i++){
  const next=h.m.menu().find(a=>a.target?.source==='display'||a.target?.choiceId?.startsWith('confirm:trigger:'));
  if(!next)return;
  h.take(h.m.apply(next));
 }
}
function setup(h,energyIncome,scanCard,trace,payer,moveDir){
 research(h,'purple1');
 place(h);place(h);place(h);place(h,2,'dlc_25.png');
 place(h,null,energyIncome?'dlc_25.png':'amiba_1.webp');place(h,1);
 trade(h,energyIncome?'cards-for-credit':'cards-for-energy',payer);
 h.cut('scan-wallet');end(h);
 h.act('scan');h.act('choose_target',a=>a.target.nebulaId==='sector-3-a');
 h.act('choose_card',a=>a.summary===`${scanCard} → 开普勒22`);
 h.act('choose_target',a=>a.target.choiceId===`scan4:move:6:${moveDir}`);
 h.act('choose_target',a=>a.target.choiceId===(trace==='reveal'?'trace:2:pink':'trace:1:pink:amiba:3'));
 known(h);
 h.act('complete_task',a=>a.summary.includes('dlc_9.png'));end(h);
 h.cut('after-scan');
}
function payMove(h,step,eligible){
 h.act('move',a=>a.target.deltaX===step.deltaX&&a.target.deltaY===step.deltaY);
 const menu=h.m.menu();
 const energy=menu.find(a=>a.summary.startsWith('消耗')&&a.summary.endsWith('能量'));
 const cards=menu.find(a=>a.target.cardIds?.length&&a.target.cardIds.every(id=>eligible.has(id)));
 const payment=energy||cards;
 assert(payment, `unfunded native step ${step.directionId}`);
 h.take(h.m.apply(payment));
 for(const id of payment.target.cardIds||[])eligible.delete(id);
}
function cargo(h,{tile,planet,reward}){
 if(tile){research(h,'blue1',3);place(h);place(h,3);place(h);end(h);}
 else {place(h);place(h);}
 h.act('analyze');h.act('choose_target',a=>a.target.choiceId==='trace:2:blue:chong:9');known(h);
 if(!tile){
  place(h);place(h,1);
  for(const id of ['dlc_20.png','dlc_16.png']){
   if(h.m.player().resources.publicity<3||!h.m.facts().market.some(c=>c?.[1]===id))continue;
   h.act('quick_trade',a=>a.target.tradeId==='publicity-for-card');h.take(h.m.pick(id));
  }
 }
 h.cut('analysis-ready');end(h);
 const goal=getProbeRouteRequirements(h.m.state(),'player-white').candidates.find(a=>a.planetId===planet&&a.endpointFamily==='land'&&!a.endpointTarget?.satelliteId);
 assert(goal);
 const player=h.m.player(), usable=player.hand.filter(c=>c.cardId!=='chong_9.webp');
 const needed=goal.required.paidMovementPoints, paid=Math.min(player.resources.energy,needed), remaining=needed-paid;
 const moveCards=usable.filter(c=>cards.getDiscardActionMoveRewardForCard(c)).slice(0,remaining);
 const requiredMoney=2*Math.max(0,2-player.resources.credits);
 const moneyCards=usable.filter(c=>!moveCards.includes(c)).slice(0,requiredMoney);
 assert(moveCards.length===remaining&&moneyCards.length===requiredMoney,
  `paid route ${goal.path.length} steps needs ${remaining} card movement points + ${requiredMoney} trade cards; ${usable.map(x=>x.cardId).join(',')}`);
 while(moneyCards.length)trade(h,'cards-for-credit',moneyCards.splice(0,2).map(c=>c.cardId));
 const eligible=new Set(moveCards.map(c=>c.id));
 goal.path.forEach(step=>payMove(h,step,eligible));
 h.take(h.m.play('chong_9.webp'));
 h.act('choose_target',a=>a.target.planetId===planet&&!a.target.landTarget?.satelliteId);
 h.cut('cargo-menu');
 h.act('choose_target',a=>a.target.choiceId===reward);known(h);
 h.act('choose_target',a=>a.target.fossilId);
 h.cut('loaded');
}
const cases=[];
for(const scan of ['dlc_24.png','dlc_17.png'])for(const dir of ['out','ccw'])for(const planet of ['jupiter','saturn'])for(const tile of [true,false]){
 cases.push([`${scan} / ${dir} / ${planet} / ${tile?'blue1':'defer tech'}`,h=>{
  setup(h,true,scan,'reveal',['dlc_32.png','b_16.webp'],dir);
  cargo(h,{tile,planet,reward:'trace:1:yellow:amiba:4'});
 }]);
}
writeZ(out,{root,parent:{root:dataset.root,prefix:sample.prefix},...runCases(root,cases)});
