Run from V667 source (93c471b0e). Extract this archive to a separate path and set `proof` to that path.
```sh
source="$proof/cargo-cash-retain-20261111-v1.json.gz"
node "$proof/r3-retained-amiba5.cjs" "$source" /tmp/r3-amiba5-probes.json.gz
node "$proof/r3-retained-amiba5-end-only.cjs" "$source" /tmp/r3-amiba5-end-only.json.gz
node "$proof/r3-retained-amiba5-diagnosis.cjs" "$source" /tmp/r3-amiba5-probes.json.gz /tmp/r3-amiba5-decisions.json.gz
node "$proof/r3-retained-amiba5-fourth.cjs" /tmp/r3-amiba5-probes.json.gz /tmp/r4-amiba5-replay.json.gz
node "$proof/r3-retained-amiba5-control.cjs" /tmp/r3-amiba5-probes.json.gz /tmp/r4-amiba5-control.json.gz
```
The DLC17 original-strategy fourth-round control is reused, not rerun. Its third-round checkpoint matches the `b_9.webp / autonomous` roots in the V667 direct-Earth-shipment evidence archive. With B111/B32 that evidence gives 219/227; the independent new comparison gives 223/257. In both conditional routes the retained-card third-round endpoint from the forced-main witness also matches the END-only, otherwise autonomous endpoint including RNG.
