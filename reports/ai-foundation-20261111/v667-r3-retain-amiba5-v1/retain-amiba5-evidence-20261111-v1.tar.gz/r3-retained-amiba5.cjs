'use strict';
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [source,out]=process.argv.slice(2);
function end(h){h.act('end_turn');const other=[];h.m.advanceOpponents(other);h.take(...other);}
const groups=[];
for(const g of readZ(source).groups.filter(g=>g.label.includes('saturn'))){
 const row=g.rows.find(x=>x.label.endsWith('b_9.webp / autonomous'));
 const root=row.checkpoints['seventh-credit'].state;
 const cases=[
   ['原策略',()=>{}],
   ['先把阿米巴5作为主行动',h=>{end(h);h.take(h.m.play('amiba_5.webp'));h.cut('played');}],
   ['先买公开DLC14并保留阿米巴5',h=>{
     h.act('quick_trade',a=>a.target.tradeId==='publicity-for-card');h.take(h.m.pick('dlc_14.png'));h.cut('bought');
   }],
   ['先PASS保留两钱、五宣传及阿米巴5',h=>{end(h);h.act('pass');h.cut('pass');}],
 ];
 groups.push({origin:g.label,...runCases(root,cases)});
}
writeZ(out,{groups});
