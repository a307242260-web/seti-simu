'use strict';
const assert=require('node:assert/strict');
const {readZ,writeZ,open,short}=require('./controlled-r3');
const [input,study,out]=process.argv.slice(2);
const controls=readZ(input).groups,groups=readZ(study).groups;
const diagnoses=[];
for(const g of groups){
 const source=controls.find(x=>x.label===g.origin).rows.find(x=>x.label.endsWith('b_9.webp / autonomous'));
 const replay=g.rows.find(x=>x.label==='先把阿米巴5作为主行动'),m=open(source.checkpoints['seventh-credit'].state);
 try{
  const funding=m.save(),nativePrefix=replay.prefix.slice(0,-1),fundingQ=m.automatic();
  assert.equal(m.state().turn.passedPlayerIds.length,3);
  assert.equal(fundingQ.a.family,'card_corner');
  const fundingDecision={action:fundingQ.a,value:fundingQ.value,n:fundingQ.n,ms:fundingQ.ms,roots:fundingQ.roots};
  for(const a of nativePrefix)m.apply(a);
  const before=m.save(),q=m.automatic(),pick=m.menu().find(a=>a.family==='play_card'&&a.summary==='amiba_5.webp');
  assert(pick&&q.complete&&q.n<=256&&q.ms<=600);
  const search={chosen:q.a,value:q.value,n:q.n,ms:q.ms,roots:q.roots};
  const facts=short(m);
  m.apply(pick);assert.deepEqual(m.save(),replay.start);
  const searchAlternative=q.roots.find(r=>r.actionId===pick.actionId);
  const actions=replay.actions.slice(0,10).map(x=>x.action.summary);
  console.log(JSON.stringify([g.origin,facts.wallet,q.a.summary,q.value,q.n,searchAlternative?.value??null,actions]));
  diagnoses.push({origin:g.origin,funding,fundingDecision,nativePrefix,before,pick,search,searchAlternative,actions});
 }finally{m.dispose();}
}
writeZ(out,{diagnoses});
