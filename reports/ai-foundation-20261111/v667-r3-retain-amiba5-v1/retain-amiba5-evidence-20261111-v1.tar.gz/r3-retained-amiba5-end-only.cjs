'use strict';
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [source,out]=process.argv.slice(2);
function end(h){h.act('end_turn');const other=[];h.m.advanceOpponents(other);h.take(...other);}
const groups=[];
for(const g of readZ(source).groups.filter(g=>g.label.includes('saturn'))){
 const row=g.rows.find(x=>x.label.endsWith('b_9.webp / autonomous'));
 const root=row.checkpoints['seventh-credit'].state;
 const cases=[
   ['只结束当前回合',h=>end(h)],
 ];
 groups.push({origin:g.label,...runCases(root,cases)});
}
writeZ(out,{groups});
