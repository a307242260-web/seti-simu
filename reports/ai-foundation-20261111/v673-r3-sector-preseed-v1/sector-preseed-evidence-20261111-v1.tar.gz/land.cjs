'use strict';
const path=require('node:path'),{open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),p=readZ(dir+'/preseed-20261111-v1.json.gz'),r=require(path.resolve('reports/research/d3183131.cbd73e00.quick-400.json')),v=require(path.resolve(r.savePath));
const c=(h,f,s)=>h.act(f,a=>a.summary===s),data=(h,t)=>{h.act('place_data');c(h,'choose_target',t)};
const offer=(h,id,t)=>c(h,'choose_card',id+' → '+t);
const of=(h,i)=>h.take(h.m.apply(v.replaySteps[i-1].action));
const advance=h=>{if(h.m.menu()[0].actorId!=='player-white'){const a=[];h.m.advanceOpponents(a);h.take(...a);}};
const cases=[];
for(const dest of ['开普勒22','室女座61'])for(const col of ['none','dlc_30.png','dlc_24.png','dlc_25.png'])cases.push([dest+' / land same Mars / '+col,h=>{
 offer(h,'b_14.webp','南河三');offer(h,'dlc_31.png',dest);
 for(let i=140;i<145;i++)of(h,i);
 data(h,'第一排放置位 1');data(h,'blue2 下方');data(h,'第一排放置位 2');
 h.take(h.m.corner('dlc_32.png'));data(h,'第一排放置位 3');h.act('end_turn');
 h.act('choose_target',a=>a.summary==='标记 A');advance(h);
 c(h,'quick_trade','2信用点 → 1能量');c(h,'quick_trade','2信用点 → 1能量');of(h,161);of(h,162);
 h.act('land');
 if(h.m.menu().some(a=>a.summary.startsWith('登陆火星')))h.act('choose_target',a=>a.summary.startsWith('登陆火星'));
 h.take(h.m.apply(h.m.menu().find(a=>a.summary.endsWith('外星人 1 黄色痕迹'))));
 data(h,'第一排放置位 4');c(h,'choose_card','收入 b_101.webp');h.cut('after-income');
 if(col!=='none'){data(h,'blue3 下方');h.take(h.m.pick(col));}
 h.act('end_turn');
}]);
const a=runCases(p.at[138],cases);writeZ(out,a);
