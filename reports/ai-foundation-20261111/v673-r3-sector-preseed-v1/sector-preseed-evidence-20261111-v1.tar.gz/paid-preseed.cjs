'use strict';
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),b=readZ(dir+'/preseed-20261111-v1.json.gz');
const a0='amiba_0.webp',a1='amiba_1.webp',a3='amiba_3.webp';
const q=(h,f,s)=>h.act(f,a=>a.summary===s);
const cases=[];
for(const split of [false,true])for(const keep of [a0,a1,a3])for(const withResearch of [false,true])cases.push([['blue first',split,keep,withResearch].join(' / '),h=>{
 h.take(h.m.play('dlc_19.png'));q(h,'choose_target','扫描 南河三');q(h,'choose_target','扫描 '+(split?'织女一':'南河三'));
 h.act('end_turn');
 if(h.m.menu()[0]?.family==='choose_target'&&h.m.menu()[0].summary==='标记 B')q(h,'choose_target','标记 B');
 if(withResearch){
  h.act('research_tech');h.act('choose_target',a=>a.target.tileId==='purple1');
  h.act('end_turn');
 }
 h.act('quick_trade',a=>a.target.tradeId==='cards-for-energy');
 for(const id of [a0,a1,a3].filter(x=>x!==keep))q(h,'choose_payment',id);
 h.act('choose_payment',a=>a.summary.startsWith('确认弃牌'));
 h.cut('funded');
 h.act('scan');q(h,'choose_target','扫描 '+(split?'织女一':'南河三'));
 h.cut('hit');
}]);
writeZ(out,runCases(b.at[172],cases));
