'use strict';
const {open,readZ,writeZ,runCases}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),p=readZ(dir+'/preseed-20261111-v1.json.gz');
const c=(h,f,s)=>h.act(f,a=>a.summary===s);
const cases=[];
for(const [card,t] of [['dlc_30.png','南河三'],['dlc_31.png','开普勒22']])for(const keep of ['auto','next scan','save after paid scan']){
 cases.push([card+' '+t+' / '+keep,h=>{
  c(h,'choose_card','b_14.webp → 南河三');c(h,'choose_card',card+' → '+t);
  h.act('choose_target',a=>a.target.choiceId==='scan4:skip');h.act('end_turn');
  if(h.m.menu()[0].actorId!=='player-white'){const a=[];h.m.advanceOpponents(a);h.take(...a);}
  if(h.m.menu()[0].family==='choose_target'&&h.m.menu()[0].summary.startsWith('标记'))c(h,'choose_target','标记 A');
  if(h.m.menu()[0].actorId!=='player-white'){const a=[];h.m.advanceOpponents(a);h.take(...a);}
  h.cut('two-energy');
  if(keep==='auto')return;
  h.act('scan');if(keep==='next scan')return;
  h.act('choose_target',a=>a.target.nebulaId==='sector-3-a');
  h.act('choose_card',a=>a.target.nebulaId==='sector-3-a');
 }]);
}
writeZ(out,runCases(p.at[138],cases));
