'use strict';
const path=require('node:path'),{open,short,runCases,writeZ}=require('./controlled-r3');
const r=require(path.resolve('reports/research/d3183131.cbd73e00.quick-400.json')),v=require(path.resolve(r.savePath)),o=require(path.resolve(r.roundEnds[1].checkpointPath)).coreState.compositionEnvelope;
const at={},m=open(o),of=i=>v.replaySteps[i-1].action;
const sectors=m=>Object.fromEntries(Object.entries(m.state().data.nebulae).map(([k,q])=>[k,q.tokens.map(t=>t.replacedByPlayerColor?.[0]||'.').join('')]));
for(let i=r.roundEnds[1].beforeInput;i<=258;i++){if([138,145,172,175,211,219,235].includes(i))at[i]=m.save();m.apply(of(i));}m.dispose();
const play=(h,id)=>h.take(h.m.play(id)),actSummary=(h,f,s)=>h.act(f,a=>a.summary===s);
const scan=(h,sector)=>actSummary(h,'choose_target','扫描 '+sector);
const pub=(h,id,s)=>actSummary(h,'choose_card',id+' → '+s);
const official=(h,i)=>h.take(h.m.apply(of(i)));
const data=(h,t)=>{h.act('place_data');actSummary(h,'choose_target',t);};
const group138=[];
for(const [id,rev] of [['b_14.webp',false],['dlc_30.png',false],['b_14.webp',true]])for(const t of ['开普勒22','室女座61']){
 const prepare=h=>{
  if(rev){pub(h,'dlc_31.png',t);pub(h,id,'南河三')}else{pub(h,id,'南河三');pub(h,'dlc_31.png',t)}
  h.cut('preseed');
 };
 group138.push([id+' then DLC31 '+t+' reverse='+rev,prepare]);
 group138.push([id+' plus DLC31 '+t+' fixed energy route reverse='+rev,h=>{
  prepare(h);for(let i=140;i<145;i++)official(h,i);
  data(h,'第一排放置位 1');data(h,'blue2 下方');data(h,'第一排放置位 2');
  h.take(h.m.corner('dlc_32.png'));data(h,'第一排放置位 3');
  h.cut('energy');h.act('end_turn');
 }]);
}
const group172=[];
for(const t of ['开普勒22','绘架座β','室女座61','南河三','天狼星A','比邻星']){
 for(const paired of ['both','one']){
  group172.push([t+' '+paired,h=>{
   official(h,172);scan(h,t);scan(h,paired==='both'?t:'织女一');h.cut('sector');
  }]);
 }
}
for(const mark of [2,3,4]){
 group172.push(['Kepler takes Vega role, mark '+mark+', keep official follow-up until scan',h=>{
  official(h,172);scan(h,'开普勒22');scan(h,'开普勒22');
  h.act('choose_target',a=>a.target.traceType==='pink'&&a.target.position===mark);
  if(h.m.menu()[0].family==='choose_card')h.take(h.m.apply(h.m.menu()[0]));
  h.cut('pink');
 }]);
}
const a=runCases(at[138],group138),b=runCases(at[172],group172);
writeZ(process.argv[2],{at,sectors:Object.fromEntries([138,145,172,211,219,235].map(i=>{const n=open(at[i]);const a=sectors(n);n.dispose();return [i,a]})),a,b});
