'use strict';
const {open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),p=readZ(dir+'/preseed-20261111-v1.json.gz');
const a9='amiba_9.webp',b16='b_16.webp',d25='dlc_25.png';
const cases=[];
for(const t of ['purple2','purple3'])for(const mode of ['auto','scan','save-procyon']){
 cases.push([t+' / DLC25 public token / '+mode,h=>{
  h.take(h.m.play(d25));h.act('end_turn');
  h.take(h.m.corner(t==='purple2'?a9:b16));h.act('research_tech');
  h.act('choose_target',a=>a.target.tileId===t);
  if(h.m.menu()[0]?.family==='accept_optional_effect')h.act('accept_optional_effect');
  if(t==='purple3'){
   h.take(h.m.pick('dlc_20.png'));
   if(h.m.menu()[0]?.family==='accept_optional_effect')h.act('accept_optional_effect');
   if(mode!=='auto'){
    h.act('quick_trade',a=>a.target.tradeId==='cards-for-credit');
    for(const id of [a9,'dlc_20.png'])h.act('choose_payment',a=>a.summary===id);
    h.act('choose_payment',a=>a.summary.startsWith('确认'));
   }
  }
  h.cut('token');h.act('end_turn');
  if(mode==='auto')return;
  h.act('scan');
  if(mode==='save-procyon')h.act('choose_target',a=>a.summary==='扫描 南河三');
 }]);
}
const a=runCases(p.at[211],cases);writeZ(out,a);
