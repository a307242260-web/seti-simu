# V673 standard third-round signal placement controls
Run from the clean V673 Production source (cbd73e00c) and its recorded research
JSON, second round-end checkpoint and replay save. Set p to the absolute archive
extraction directory. Scripts read archived predecessors and write new outputs,
so they can be checked independently. Output timing can vary.
```sh
node "$p/preseed.cjs" "$p/replay-preseed.json.gz"
node "$p/land.cjs" "$p" "$p/replay-land.json.gz"
node "$p/paid-preseed.cjs" "$p" "$p/replay-paid-preseed.json.gz"
node "$p/paired.cjs" "$p" "$p/replay-paired.json.gz"
node "$p/bonus.cjs" "$p" "$p/replay-bonus.json.gz"
node "$p/bonus-income.cjs" "$p" "$p/replay-bonus-income.json.gz"
node "$p/fourth.cjs" "$p" "$p/replay-fourth.json.gz"
```
