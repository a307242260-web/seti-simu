'use strict';
const {open,readZ,writeZ,runCases}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),b=readZ(dir+'/bonus-final-20261111-v1.json.gz');
const saved=b.rows.find(r=>r.label.includes('save-procyon'));
const m=open(saved.start);
const before=saved.actions.findIndex(x=>x.action.family==='card_corner');
saved.actions.slice(0,before).forEach(x=>m.apply(x.action));
const root=m.save();m.dispose();
const names=['amiba_2.webp','amiba_5.webp'];
const fixed=names.map((id,i)=>[id+' corner, keep other for income',h=>{
 h.take(h.m.corner(id));for(let k=1;k<=4;k++){h.act('place_data');h.act('choose_target',a=>a.summary==='第一排放置位 '+k);}
 h.act('choose_card',a=>a.summary==='收入 '+names[1-i]);
 h.cut('income');
}]);
writeZ(out,runCases(root,fixed));
