# 从原生根复核正式策略
使用 Node 22，在包含 seti-complete-decision-search-v452 的仓库根目录运行。将本包解到临时目录后，先用 `shasum -a 256 -c SHA256SUMS` 校验，然后执行：

```sh
node "$CASE_DIR/verify-production.cjs" "$CASE_DIR/scan-tie-ac4401cf-20261111-v1.json.gz"
```

原始对照根、旧搜索图、候选结果及第 18 盘终局都在 gzip 文件中，不需要重跑历史整局。last-round-launch.cjs 从同版本 39f19bec 批次的 round-end-3 检查点和完整行动存档生成反事实。check-scan-tie.cjs 从 ac4401cf7 生产文件和 scan-tie-section.js 生成只在内存存在的候选，两脚本的参数见开头，历史主机记录由原批次实验保存。当前版本的验收使用独立的正式入口脚本，不依赖这些历史主机文件。计时随负载变化。
