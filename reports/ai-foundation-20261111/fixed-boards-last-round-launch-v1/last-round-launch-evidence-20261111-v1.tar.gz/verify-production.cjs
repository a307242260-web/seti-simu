'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const seat='player-white',d=readZ(process.argv[2]),rows=[];
for(const {board,version,root,b,c,suffix} of d.rows){
 const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try {
  const agent=createSearchAgent({analysisPort:port,seatId:seat}),actions=[];
  let checkpoint=null,peakN=0,peakMs=0,first;
  for(let i=0;i<(suffix?70:1);i++){
   if(m.state().turn.gameEnded)break;
   const before=m.save(),menu=m.menu();
   if(menu[0].actorId!==seat){m.advanceOpponents(actions);continue;}
   agent.loadCheckpoint(checkpoint);
   const q=agent.decide({seatId:seat,legalActions:menu}).search;
   assert.deepEqual(m.save(),before);
   assert(q.complete&&!q.unresolved.length&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600);
   peakN=Math.max(peakN,q.diagnostics.nativeExecutions);peakMs=Math.max(peakMs,q.rootAndSearchMilliseconds);
   if(!first){
    first=q.actionId;
    assert.equal(first,c.q.actionId);
    assert.equal(q.value,b.q.value);
    assert.equal(q.diagnostics.nativeExecutions,b.q.diagnostics.nativeExecutions);
    assert.deepEqual(q.fundedScanOverBareLaunch,c.q.fundedScanOverBareLaunch);
    assert.deepEqual(JSON.parse(JSON.stringify(q.roots)),b.q.roots);
    const oldLines=structuredClone(b.q.lines);
    oldLines[0].distance=q.lines[0].distance;
    assert.deepEqual(JSON.parse(JSON.stringify(q.lines)),oldLines);
   }
   if(!suffix)break;
   checkpoint=agent.createCheckpoint();actions.push(m.apply(menu.find(a=>a.actionId===q.actionId)));
  }
  let terminal=null;
  if(suffix){
   terminal=m.state().match.finalScores.find(x=>x.playerId===seat).totalScore;
   assert.equal(terminal,suffix.terminal);
   assert.deepEqual(actions,suffix.actions);assert.deepEqual(m.save(),suffix.end);
   m.restore(root);actions.forEach(m.apply);assert.deepEqual(m.save(),suffix.end);
  }
  rows.push({board,version,first,terminal,inputs:actions.length,peakN,peakMs});
 }finally{port.close();m.dispose();}
}
assert.equal(rows.length,8);assert.equal(rows.filter(r=>r.terminal===122).length,1);
console.log(JSON.stringify(rows,null,2));
