'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path');
const {open,short,writeZ}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [input,out]=process.argv.slice(2), summary=JSON.parse(fs.readFileSync(input));
const seat='player-white', rows=[];
function decide(m,checkpoint) {
 const before=m.save(), port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try {
  const agent=createSearchAgent({analysisPort:port,seatId:seat});
  if(checkpoint)agent.loadCheckpoint(checkpoint);
  const result=agent.decide({seatId:seat,legalActions:m.menu()});
  assert.deepEqual(m.save(),before);
  return {q:result.search, checkpoint:agent.createCheckpoint()};
 }finally{port.close();}
}
function score(m){return m.state().turn.gameEnded?m.state().match.finalScores.find(x=>x.playerId===seat):null;}
const stats=q=>({n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,actionId:q.actionId,closed:q.complete&&!q.unresolved.length,value:q.value,realization:q.realization});
const admitted=t=>t.closed&&t.n<=256&&t.ms<=600;
for(const [board,version,mode] of [[9,71,'pass'],[9,73,'pass'],[18,85,'pass-scan'],[16,76,'launch'],[19,58,'control'],[8,72,'control']]){
 const recordPath='reports/research/'+summary.rows.find(r=>r.board===board).f;
 const read=f=>JSON.parse(fs.readFileSync(f,'utf8')), record=read(recordPath), oldFinal=read(record.savePath);
 const r3=read(recordPath+'.round-end-3.checkpoint.json'), moves=oldFinal.replaySteps.map(s=>s.action);
 const index=moves.findIndex((a,i)=>i>=r3.replayCursor.stepIndex&&a.actorId===seat&&a.phase==='main'&&a.stateVersion===version);
 assert(index>=0);
 const m=open(r3.coreState.compositionEnvelope);
 try{
  const before=m.save(), acceptedBefore=moves.slice(r3.replayCursor.stepIndex,index);
  acceptedBefore.forEach(m.apply);
  const root=m.save(), assets=short(m), branches=[];
  moves.slice(index).forEach(m.apply);
  assert.equal(m.save().committedState,oldFinal.committedState);
  assert.equal(score(m).totalScore,summary.rows.find(x=>x.board===board).score);
  const baseline={score:score(m),assets:short(m),actions:moves.slice(index)};
  m.restore(root);
  const cold=decide(m), quote=stats(cold.q), baselineAction=moves[index].actionId;
  assert(admitted(quote),JSON.stringify(quote));assert.equal(quote.actionId,baselineAction);
  const graph=cold.q.lines, rootLine=graph[0], lookup=new Map(graph.map(x=>[x.node,x]));
  const summarized=rootLine.edges.map(e=>({action:e.actionId,value:lookup.get(e.target)?.value,steps:e.steps,status:e.goalStatus}));
  const options=[];
  if(mode.includes('pass'))options.push(['pass',[m.menu().find(a=>a.family==='pass').actionId]]);
  if(mode.includes('scan')){
   const scan=rootLine.edges.filter(e=>e.goalStatus==='completed'&&e.resourcePlan?.goal?.kind==='scan-flow')
    .sort((a,b)=>(lookup.get(b.target)?.value??-Infinity)-(lookup.get(a.target)?.value??-Infinity))[0];
   assert(scan);options.push(['funded-scan',scan.steps]);
  }
  if(mode==='launch')options.push(['launch',[m.menu().find(a=>a.family==='launch').actionId]]);
  for(const [label,forced] of options){
   m.restore(root);
   const accepted=[], checks=[];
   const add=a=>{assert(a);accepted.push(m.apply(a));};
   forced.forEach(id=>add(m.menu().find(a=>a.actionId===id)));
   let stop=null,checkpoint;
   for(let i=0;i<100;i++){
    if(score(m)){stop='terminal';break;}
    const menu=m.menu();assert(menu.length);
    if(menu[0].actorId!==seat){m.advanceOpponents(accepted);continue;}
    const result=decide(m,checkpoint),t=stats(result.q);checks.push(t);
    if(!admitted(t)){stop=t;break;}
    checkpoint=result.checkpoint;add(menu.find(a=>a.actionId===t.actionId));
   }
   assert(stop);const end=m.save(),terminal=score(m),ending=short(m);
   m.restore(root);accepted.forEach(m.apply);assert.deepEqual(m.save(),end);
   branches.push({label,accepted,checks,end,terminal,ending,stop});
  }
  m.restore(before);acceptedBefore.forEach(m.apply);assert.deepEqual(m.save(),root);
  rows.push({board,version,index,mode,recordPath,root,assets,acceptedBefore,baseline,quote,graph,summarized,branches});
  console.log(JSON.stringify({board,version,index,quote,old:[baseline.score.totalScore,baseline.actions.length], branches:branches.map(b=>[b.label,b.terminal?.totalScore,b.accepted.length,b.stop,Math.max(0,...b.checks.map(x=>x.n)),Math.round(Math.max(0,...b.checks.map(x=>x.ms)))]),assets}));
 }finally{m.dispose();}
}
writeZ(out,{source:'ac4401cf717b4adb9f69375decf63a6568c6ab76',rows});
