'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path'),Module=require('node:module');
const {open,readZ,writeZ}=require('./controlled-r3');
const [input,source,summaryPath,out]=process.argv.slice(2),seat='player-white';
const file=path.resolve('randomizer/game/ai/decision-search.js'),base=fs.readFileSync(file,'utf8'),section=fs.readFileSync(source,'utf8');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createStateValueEvaluator}=require(path.resolve('randomizer/game/ai/state-value'));
const {OPTIONS,BUDGET}=require(path.resolve('randomizer/game/ai/search-agent'));
const baseline=require(file),patched=new Module(file,module);patched.filename=file;patched.paths=Module._nodeModulePaths(path.dirname(file));
const at='    // A shorter public sector is a useful tie-break';
assert(base.includes(at));patched._compile(base.replace(at,section+'\n'+at).replace('      ...(accepted&&publicBluePairChoice?', '      ...(accepted&&fundedScanOverBareLaunch?{fundedScanOverBareLaunch}:{}),\n      ...(accepted&&publicBluePairChoice?'),file);
function quote(m,variant,planContinuation){
 const before=m.save(),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0}),evaluate=createStateValueEvaluator(seat);
 try {
  const time=performance.now(),q=variant.searchDecision({port,root:port.openRoot(),evaluate,budget:BUDGET,...OPTIONS,
    modelKey:evaluate.modelKey,planContinuation:planContinuation?port.importPlan(planContinuation):null,scanOrbitBudget:{nativeInputs:256,deadline:time+600}});
  const ms=performance.now()-time;
  assert.deepEqual(m.save(),before);
  assert(q.complete&&!q.unresolved.length&&q.diagnostics.nativeExecutions<=256&&ms<=600,JSON.stringify([q.complete,q.diagnostics.nativeExecutions,ms,q.actionId]));
  return {q,ms,checkpoint:q.planContinuation?port.exportPlan(q.planContinuation):null};
 } finally {port.close();}
}
function score(m){return m.state().turn.gameEnded?m.state().match.finalScores.find(x=>x.playerId===seat)?.totalScore:null;}
const mRows=readZ(input).rows, summary=JSON.parse(fs.readFileSync(summaryPath)), rows=[];
for(const row of summary.rows){
 const recordPath='reports/research/'+row.f, d=JSON.parse(fs.readFileSync(recordPath));
 const launches=fs.readFileSync(recordPath+'.decisions.jsonl','utf8').trimEnd().split('\n').map(JSON.parse).filter(t=>t.context.observation.publicState?.roundNumber===4&&t.context.seatId===seat&&t.actionId?.startsWith('launch:'));
 for(const t of launches){
  const version=t.context.stateVersion,found=mRows.find(x=>x.board===row.board&&x.version===version);
  const old=JSON.parse(fs.readFileSync(d.savePath)),r3=JSON.parse(fs.readFileSync(recordPath+'.round-end-3.checkpoint.json'));
  const moves=old.replaySteps.map(s=>s.action),i=moves.findIndex((a,j)=>j>=r3.replayCursor.stepIndex&&a.actorId===seat&&a.phase==='main'&&a.stateVersion===version);
  assert(i>=0);
  const m=open(r3.coreState.compositionEnvelope);
  try{
   moves.slice(r3.replayCursor.stepIndex,i).forEach(m.apply);
   const root=m.save();if(found)assert.deepEqual(root,found.root);
   const b=quote(m,baseline), c=quote(m,patched.exports);
   assert.equal(b.q.actionId,moves[i].actionId);
   for(const key of ['roots','lines','unresolved','sharedPrefixGraph','value','realization'])assert.deepEqual(b.q[key],c.q[key],key);
   assert.equal(b.q.diagnostics.nativeExecutions,c.q.diagnostics.nativeExecutions);
   const current={board:row.board,version,root,b,c};
   rows.push(current);
   console.log(JSON.stringify([row.board,version,b.q.actionId,c.q.actionId,c.q.fundedScanOverBareLaunch,b.q.diagnostics.nativeExecutions,c.q.diagnostics.nativeExecutions,c.ms]));
   if(c.q.actionId===b.q.actionId)continue;
   let q=c, checkpoint, actions=[], checks=[], terminal;
   for(let j=0;j<70;j++){
    if(score(m)!==null){terminal=score(m);break;}
    if(m.menu()[0].actorId!==seat){m.advanceOpponents(actions);continue;}
    if(j)q=quote(m,patched.exports,checkpoint);
    actions.push(m.apply(m.menu().find(a=>a.actionId===q.q.actionId)));
    checks.push({n:q.q.diagnostics.nativeExecutions,ms:q.ms,actionId:q.q.actionId});checkpoint=q.checkpoint;
   }
   assert(terminal!==undefined);
   const end=m.save();m.restore(root);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
   current.suffix={terminal,actions,checks,end};console.log(JSON.stringify(['suffix',row.board,terminal,actions.map(a=>a.summary)]));
  }finally{m.dispose();}
 }
}
writeZ(out,{rows});
