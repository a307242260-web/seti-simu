'use strict';
const assert=require('node:assert/strict');
const {open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [fund,src,out]=process.argv.slice(2),d=readZ(fund),previous=readZ(src),results=[];
const starts=[];
for(const [name,entry] of Object.entries(d)){
 for(const row of entry.rows){
  if(row.label.includes('company-swap')||name==='revealed'||name==='ordinary-swapped'&&row.label==='known-public-corner-insert-amiba5')
   starts.push([name+' / '+row.label,row.settled.state,[]]);
  if(name==='ordinary-swapped'&&row.label==='known-public-corner-insert-amiba5'){
   const root=row.checkpoints['income-paid'].state,m=open(root),prefix=[];
   try {
    prefix.push(m.act('complete_task',a=>a.summary.includes('b_117.webp')));
    prefix.push(m.act('end_turn'));m.advanceOpponents(prefix);
    assert.equal(m.menu()[0].actorId,'player-white');
    starts.push([name+' / paid income then fixed PASS',m.save(),prefix]);
   }finally{m.dispose();}
  }
 }
}
const prior=previous.roots.revealed;
const controls=runCases(prior.state,['fossil_06','fossil_07'].map(id=>['chong-yellow4 / '+id,h=>{
 const a=h.m.menu().find(x=>x.target.choiceId==='trace:2:yellow:chong:4');
 h.take(h.m.apply(a));
 h.act('choose_card',x=>x.target.source==='display');
 h.act('accept_optional_effect',a=>a.target.choiceId.startsWith('confirm:'));
 h.act('choose_target',a=>a.target.fossilId===id);
}]));
for(const row of controls.rows)starts.push([row.label,row.settled.state,[]]);
for(const [label,root,prefix] of starts){
 const m=open(root),actions=[],turns=[];
 try{
  const r3=short(m);
  actions.push({action:m.act('pass')});
  const choice=m.menu().find(a=>a.summary==='b_111.webp');
  if(!choice){
   const stop={kind:'B111 unavailable',options:m.menu().map(a=>a.summary)};
   results.push({label,root,prefix,r3,stop});console.log(JSON.stringify([label,stop]));continue;
  }
  actions.push({action:m.apply(choice)});
  let cp,stop;
  for(let i=0;i<200;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!=='player-white'){const a=[];m.advanceOpponents(a);actions.push(...a.map(action=>({action,passive:true})));continue;}
   const q=m.automatic(cp);
   if(!q.a||!q.complete||q.n>256||q.ms>600){stop={kind:'gate',n:q.n,ms:q.ms,a:q.a?.summary,turn:m.facts().turn};break;}
   cp=q.checkpoint;
   actions.push({action:m.apply(q.a),n:q.n,ms:q.ms,value:q.value});
   if(q.a.family==='end_turn')turns.push(short(m));
  }
  assert(stop);
  const end=m.save(),peak=[Math.max(...actions.map(a=>a.n||0)),Math.max(...actions.map(a=>a.ms||0))];
  const terminal=stop==='terminal'?m.state().match.finalScores.find(x=>x.playerId==='player-white'):null;
  console.log(JSON.stringify([label,stop,terminal?.totalScore,peak,r3.wallet,r3.income,r3.computer,r3.blue,turns.slice(0,1)]));
  m.restore(root);actions.forEach(a=>m.apply(a.action));assert.deepEqual(m.save(),end);
  results.push({label,root,prefix,r3,actions,stop,end,peak,terminal,turns});
 }finally{m.dispose();}
}
writeZ(out,{controls,results});
