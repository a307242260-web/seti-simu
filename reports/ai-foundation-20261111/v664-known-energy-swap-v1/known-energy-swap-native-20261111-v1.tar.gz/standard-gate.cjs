'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {open,writeZ}=require('./controlled-r3');
const [root,openerPath,out,record='1ae1a75f.f595773c.quick-400.json']=process.argv.slice(2);
const read=p=>JSON.parse(fs.readFileSync(path.resolve(root,p)));
const opener=read(openerPath).roundStarts[1],quick=read('reports/research/'+record);
const full=read('reports/research/e871fddd.9f2cbc45.full.json');
const same=(a,b)=>{assert.deepEqual(JSON.parse(a.committedState),JSON.parse(b.committedState));assert.deepEqual(a.session,b.session);};
const result={};
for(const [name,record] of [['standard',quick],['registered-full',full]]){
 const standard=name==='standard',start=standard?opener:{beforeInput:record.roundEnds[2].beforeInput,envelope:read(record.roundEnds[2].checkpointPath).coreState.compositionEnvelope};
 const m=open(start.envelope),saved=read(record.savePath),rows=[],searches=new Map(record.metrics.searches.map(x=>[x.step,x]));
 const rounds=new Map(record.roundEnds.map(x=>[x.beforeInput,x]));
 try{
  let checkpoint;
  for(let i=start.beforeInput;i<=saved.replaySteps.length;i++){
   const round=rounds.get(i);if(round)same(m.save(),read(round.checkpointPath).coreState.compositionEnvelope);
   const a=saved.replaySteps[i-1].action,old=searches.get(i);
   if(standard&&old){
    const q=m.automatic(checkpoint);checkpoint=q.checkpoint;
    assert(q.complete&&q.n<=256&&q.ms<=600,JSON.stringify([i,q.n,q.ms,q.complete]));
    assert.deepEqual([q.a.actionId,q.value,q.n],[old.actionId,old.value,old.diagnostics.nativeExecutions],String(i));
    rows.push([i,q.n,q.ms,q.value]);
   }
   m.apply(a);
  }
  same(m.save(),saved);assert.equal(m.facts().final,standard?164:216);
  const resultRow={native:saved.replaySteps.length-start.beforeInput+1,searches:rows.length,score:m.facts().final,
   peaks:standard?[Math.max(...rows.map(a=>a[1])),Math.max(...rows.map(a=>a[2]))]:null};
  console.log(name,JSON.stringify(resultRow));result[name]={...resultRow,rows};
 }finally{m.dispose();}
}
writeZ(out,result);
