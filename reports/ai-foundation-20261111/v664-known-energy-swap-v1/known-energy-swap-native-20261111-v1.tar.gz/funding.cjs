'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,short,readZ,writeZ,runCases}=require('./controlled-r3');
const deck=require(path.resolve('randomizer/game/cards/deck'));
const d=readZ(process.argv[2]),out=process.argv[3],results={};
function begin(h,amiba,fossil){
 h.take(h.m.apply(amiba));
 h.act('choose_card',a=>a.target.source==='display');
 h.act('accept_optional_effect',a=>a.target.choiceId.startsWith('confirm:'));
 h.act('choose_target',a=>a.target.fossilId===fossil);
}
function put(h,n){
 for(let i=0;i<n;i++){
  h.act('place_data');
  h.act('choose_target',a=>a.target.target==='computer');
 }
}
function buy(h,id){
 const c=h.m.state().cards.publicCards.find(c=>c?.cardId===id);assert(c,id);
 h.act('quick_trade',a=>a.target.tradeId==='publicity-for-card');
 h.take(h.m.pick(id));
}
function income(h,energy,corner){
 const p=h.m.player();
 const c=p.hand.find(x=>x.cardId===energy);
 const payer=p.hand.find(x=>x.cardId===corner);
 assert(c&&payer&&c.id!==payer.id&&deck.getIncomeGainForCard(c)?.energy===1&&deck.getDiscardActionRewardForCard(payer)?.dataCount===1);
 h.take(h.m.corner(corner));
 put(h,1);
 h.act('choose_card',a=>a.target.cardInstanceId===c.id);
}
for(const [name,{state,amiba}] of Object.entries(d.roots)){
 const ordinary=name.includes('ordinary')||name==='both-swapped';
 const cases=[
  ['known-public-corner-insert-amiba5',h=>{
   begin(h,amiba,'fossil_01');put(h,3);h.cut('publicity-funded');
   buy(h,'dlc_17.png');income(h,'amiba_5.webp','dlc_17.png');h.cut('income-paid');
  }],
  ['buy-public-corner-only-then-auto',h=>{
   begin(h,amiba,'fossil_01');put(h,3);
   buy(h,'dlc_17.png');
  }],
 ];
 if(ordinary)cases.push(['known-public-dlc14-company-swap',h=>{
  begin(h,amiba,'fossil_01');put(h,3);
  h.take(...h.m.swap('dlc_15.png','dlc_14.png'));
  income(h,'dlc_14.png','amiba_5.webp');h.cut('income-paid');
 }]);
 for(const fossil of ['fossil_06','fossil_07'])cases.push([fossil+'-only-fixed',h=>begin(h,amiba,fossil)]);
 results[name]={root:state,...runCases(state,cases)};
}
writeZ(out,results);
