'use strict';
const path=require('node:path'),{open,short,readZ,writeZ}=require('./controlled-r3');
const demand=require(path.resolve('randomizer/game/ai/resource-demand'));
const {createCardPickPlanner}=require(path.resolve('randomizer/game/ai/card-pick-planning'));
const d=readZ(process.argv[2]),out=process.argv[3],result={};
for(const [name,entry] of Object.entries(d)){
 const swap=entry.rows.find(r=>r.label.includes('company-swap'));
 const normal=entry.rows.find(r=>r.label==='known-public-corner-insert-amiba5');
 const root=normal.checkpoints['publicity-funded'].state,m=open(root);
 try{
  const state=m.state(),player=m.player(),actions=m.menu(),r=m.automatic();
  const q=createCardPickPlanner().plan({state,seatId:'player-white',actions,status:'stable'});
  const info={root,assets:short(m),selected:r.a,roots:r.roots,n:r.n,ms:r.ms,
   incomeSwap:demand.incomeSwapPlan(state,player),cardPick:q,
   offers:player.hand.map(outgoing=>[outgoing.cardId,demand.knownSwapPortfolioQuotes({state,seatId:player.id,outgoing,offered:state.cards.publicCards}).map(x=>[x.card.cardId,x.gain])])};
  console.log(name,JSON.stringify([info.assets,info.selected?.summary,info.incomeSwap,q?.reason,q?.companySwap,info.offers,r.roots.map(x=>[x.actionId,x.value,x.kind,x.goal])]));
  result[name]=info;
 }finally{m.dispose();}
}
writeZ(out,result);
