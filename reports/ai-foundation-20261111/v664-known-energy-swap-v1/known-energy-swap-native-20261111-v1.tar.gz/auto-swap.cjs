'use strict';
const assert=require('node:assert/strict');
const {open,readZ,writeZ,runCases}=require('./controlled-r3');
const [src,roots,out]=process.argv.slice(2),d=readZ(src),cold=readZ(roots);
const results={};
for(const [name,{state,amiba}] of Object.entries(d.roots)){
 const m=open(cold[name].root);
 try {
  const q=m.automatic();
  assert(q.complete&&q.n<=256&&q.ms<=600);
  results[name]={cold:{a:q.a,n:q.n,ms:q.ms,value:q.value},
   ...runCases(state,[['yellow-only-fixed',h=>h.take(h.m.apply(amiba))]]),
   coldRoot:{root:cold[name].root,...runCases(cold[name].root,[['no-fixed-actions',()=>{}]])}};
 }finally{m.dispose();}
}
writeZ(out,results);
