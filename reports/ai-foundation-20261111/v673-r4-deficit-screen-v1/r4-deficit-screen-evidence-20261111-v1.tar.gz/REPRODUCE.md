基线为 2a04072e0fa5dedc5b885a24a129980e87b158b4 的规则源码；A 指向解包目录。
在该源码根目录，用独立 Node 进程执行以下命令。B32 仅替换根文件及输出名。当前候选的其他隔离改动由脚本注入，未并入正式策略。

    OPT="$(cat "$A/mode")-turn-copy-card-screen-data-screen-count-prep-projections"
    SETI_SCAN_PRIOR="$A/prior.cjs" node "$A/cold-root.cjs" "$OPT-base" "$A/root-b_111.webp.gz" "$A/replay-base-b_111.webp.json.gz"
    SETI_SCAN_PRIOR="$A/prior.cjs" node "$A/cold-root.cjs" "$OPT-no-deficit-payment" "$A/root-b_111.webp.gz" "$A/replay-new-b_111.webp.json.gz"
    node "$A/compare.cjs" "$A" "$A"

对比包含原始存档、完整候选与共享图、首选、估值、未完成列表及 29 输入续跑证书。试算次数为 preparations 内实际调用 project 的次数；这与原生输入计数分别记录，不能相加。带计数器的时间只用于定位，另外保留无计数器的冷测。定向回归与估值审计运行在相同基线加本提交的 resource-demand.js 文件上，缺少的历史夹具只从 Git 中恢复。

无计数器候选 149／627ms、159／628ms，带计数器从 1120／1136 次钱包试算降到 260／262 次。两根仍未通过 600ms，未运行新的整局或前三轮。direct-scan-unadopted.patch 等其他局部试验只用于定位。

定向回归 8 项通过；另 1 项 movement-tail 在改动前后同样是旧见证的原生输入计数断言 4 != 10，未改测试预期。V 输入审计全部通过。
