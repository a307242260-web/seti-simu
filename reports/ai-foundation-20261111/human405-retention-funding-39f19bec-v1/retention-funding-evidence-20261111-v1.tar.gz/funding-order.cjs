'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path'),Module=require('node:module');
const {open,readZ,writeZ}=require('./controlled-r3');
const [profile,paths,out]=process.argv.slice(2),src=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(src,module);
mod.filename=src;mod.paths=Module._nodeModulePaths(path.dirname(src));
const old=fs.readFileSync(src,'utf8'),anchor='return Object.freeze({ createAnalysisPort });';
assert.equal(old.split(anchor).length,2);
mod._compile(old.replace(anchor,'return Object.freeze({ createAnalysisPort,forwardIdentity });'),src);
const identity=m=>mod.exports.forwardIdentity(m.save(),'stable',null);
const rows=[];
const fixed=readZ(paths).rows.filter(x=>x.mode==='original'&&x.rootSummary==='深空探测 1x 行动');
const recorded=readZ(profile);
function apply(m,a){
 const current=m.menu().find(q=>q.actionId===a.actionId&&q.actorId===a.actorId);
 if(!current)return false;
 assert.deepEqual(current.target,a.target);
 m.apply(current);return true;
}
function menu(m){return m.menu().map(a=>[a.actionId,a.family,a.target,a.payload]);}
for(const r of fixed){
 const root=recorded.find(q=>q.name===r.name&&q.card===r.card).root,m=open(root);
 try{
  const firstMove=r.replayed.findIndex(a=>a.family==='move');
  assert(firstMove>3);
  const swap=r.replayed.slice(0,3),fund=r.replayed.slice(3,firstMove),tail=r.replayed.slice(firstMove);
  assert(swap.every(a=>apply(m,a)));
  const from=m.save(),groups=[];
  for(let i=0;i<fund.length;i++){
   const a=fund[i],group=[a];
   if(a.family==='place_data'){
    assert.equal(fund[i+1].family,'choose_target');
    group.push(fund[++i]);
    if(fund[i+1]?.target?.choiceId?.startsWith('income:'))group.push(fund[++i]);
   }else assert(['card_corner','quick_trade'].includes(a.family),a.summary);
   groups.push({label:group.map(x=>x.summary).join(' → '),actions:group});
  }
  const order=groups.map((_,i)=>i),attempts=[];
  for(const idx of [-1,...order.slice(0,-1)]){
   m.restore(from);
   const perm=order.slice();
   if(idx>=0)[perm[idx],perm[idx+1]]=[perm[idx+1],perm[idx]];
   let failed=null;
   for(const a of perm.flatMap(i=>groups[i].actions)){
    if(!apply(m,a)){failed={action:a,menu:menu(m)};break;}
   }
   if(idx<0)assert(!failed);
   if(failed){attempts.push({idx,perm,failed});continue;}
   const settled=m.save(),key=identity(m),q=menu(m);
   const previous=attempts[0];
   const eq=idx<0||key===previous.key;
   if(eq&&idx>=0){assert.deepEqual(q,previous.menu);assert.deepEqual(m.facts().rng,previous.rng);}
   const rng=m.facts().rng;
   for(const a of tail)assert(apply(m,a),a.summary);
   const tailState=m.save(),tailKey=identity(m);
   if(eq&&idx>=0)assert.equal(tailKey,previous.tailKey);
   attempts.push({idx,perm,settled,key,menu:q,rng,tailKey,tailState,eq});
  }
  const status=attempts.slice(1).map(a=>a.failed?'illegal':a.eq?'equivalent':'different');
  console.log(JSON.stringify({name:r.name,card:r.card,groups:groups.map(g=>g.label),status}));
  rows.push({name:r.name,card:r.card,root,swap,from,groups,tail,attempts});
 }finally{m.dispose();}
}
assert.equal(rows.length,6);
writeZ(out,{rows});
