'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const {open,readZ,writeZ,short}=require('./controlled-r3');
const [profile,paths,official,out]=process.argv.slice(2),cases=[],results=[];
const roots=readZ(profile),fixed=readZ(paths).rows.filter(r=>r.name==='hold-before-income-slot'
 &&r.mode==='original'&&r.rootSummary==='深空探测 1x 行动');
assert.equal(fixed.length,2);
const standard=JSON.parse(fs.readFileSync(official)).coreState.compositionEnvelope;
for(const {card,replayed} of fixed){
 const root=roots.find(r=>r.name==='hold-before-income-slot'&&r.card===card).root;
 assert.equal(replayed.length,27);
 cases.push({label:'retain',card,root,prefix:replayed});
 cases.push({label:'standard',card,root:standard,prefix:null});
}
for(const {label,card,root,prefix} of cases){
 const m=open(root),rows=[],turns=[];
 try{
  const add=a=>{rows.push({action:m.apply(a),controlled:true});};
  if(prefix)prefix.forEach(add);
  else{
   add(m.menu().find(a=>a.family==='pass'));
   add(m.menu().find(a=>a.family==='choose_card'&&a.summary===card));
  }
  const at=m.save(),opening=short(m);
  let stop,cp;
  for(let i=0;i<200;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!=='player-white'){
    const forced=[];m.advanceOpponents(forced);rows.push(...forced.map(action=>({action,passive:true})));continue;
   }
   const q=m.automatic(cp);
   if(!q.a||!q.complete||q.n>256||q.ms>600){
    stop={kind:'gate',action:q.a?.summary,n:q.n,ms:q.ms,complete:q.complete};break;
   }
   if(!cp||q.a.phase==='main'||q.a.family==='pass')turns.push({action:q.a,assets:short(m),n:q.n,ms:q.ms});
   cp=q.checkpoint;rows.push({action:m.apply(q.a),n:q.n,ms:q.ms});
  }
  assert(stop);
  const end=m.save(),endAssets=short(m),terminal=stop==='terminal'?m.state().match.finalScores.find(p=>p.playerId==='player-white'):null;
  const peak=[Math.max(0,...rows.map(r=>r.n||0)),Math.max(0,...rows.map(r=>r.ms||0))];
  m.restore(root);rows.forEach(r=>m.apply(r.action));assert.deepEqual(m.save(),end);
  console.log(JSON.stringify({label,card,stop,terminal:terminal?.totalScore,peak,controlled:rows.filter(r=>r.controlled).length,inputs:rows.length,assets:endAssets.wallet}));
  results.push({label,card,root,at,opening,stop,terminal,peak,end,endAssets,rows,turns});
 }finally{m.dispose();}
}
writeZ(out,{results});
