Run from the repository root at 8c8b39330 (AI source 39f19bec), with Node 22. The first archive contains the shared helpers, the isolated scan/yellow substitutions, and the original graph and path fixtures. The current archive adds the order proof, funding-binding diagnostic, and paired natural tails. Use fresh outputs. Do not overlap timed jobs.

```sh
proof=/path/to/this/archive
old=reports/ai-foundation-20261111/human405-retention-search-39f19bec-v1/retention-search-evidence-20261111-v1.tar.gz
tar -xzf "$old" -C "$proof"
out=$(mktemp -d)
profile="$proof/current-profile-39f19bec-20261111-v1.json.gz"
paths="$proof/winner-paths-exact-20261111-v1.json.gz"
node "$proof/funding-order.cjs" "$profile" "$paths" "$out/orders.json.gz"
node - "$proof" "$out" <<'NODE'
const [proof,out]=process.argv.slice(2),{readZ,writeZ}=require(proof+'/controlled-r3');
const rows=readZ(proof+'/current-profile-39f19bec-20261111-v1.json.gz').map(r=>({name:r.name,card:r.card,state:r.root,q:r.q}));
writeZ(out+'/probe-roots.json.gz',{rows});
NODE
SETI_SCAN_PRIOR="$proof/prior.cjs" node "$proof/bind-funding.cjs" bound-move-funding-join-route-yellow "$out/probe-roots.json.gz" "$out/diagnostic.json.gz"
node "$proof/funding-tail.cjs" "$profile" "$paths" reports/research/98e52daa.39f19bec.quick-400.json.round-end-3.checkpoint.json "$out/tails.json.gz"
```

The binding is an isolated comparison, not Production admission. The two retained branches have a fixed 27-input prefix derived from the baseline graph, and only their suffix is autonomous. The standard controls force PASS and the same keep-card as each pair; all other white decisions follow the unmodified production strategy and strict gates.
