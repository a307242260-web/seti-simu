'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [file,out]=process.argv.slice(2),initial=readZ(file),rows=[];
for(const row of initial.cases.filter(x=>x.r4.stop!=='terminal')){
 const start=row.r4.start.env,m=open(start),steps=[],turns=[];
 try{
  let checkpoint,stop,closeTurn=false;
  for(let i=0;i<220;i++){
   const active=m.menu()[0];if(m.state().turn.gameEnded){stop='terminal';break;}
   if(active?.actorId!=='player-white'){
    const passive=[];m.advanceOpponents(passive);steps.push(...passive.map(a=>({a,passive:true})));continue;
   }
   if(closeTurn&&!m.save().session){turns.push({summary:short(m),step:steps.length});closeTurn=false;}
   const q=m.automatic(checkpoint);
   if(!q.a||!q.complete||q.n>256||q.ms>600){stop={kind:'gate',n:q.n,ms:q.ms,a:q.a,complete:q.complete};break;}
   checkpoint=q.checkpoint;steps.push({a:m.apply(q.a),n:q.n,ms:q.ms,value:q.value});
   closeTurn=q.a.family==='end_turn';
  }
  assert(stop);const end=m.save(),summary=short(m),peak=[Math.max(0,...steps.map(x=>x.n||0)),Math.max(0,...steps.map(x=>x.ms||0))];
  m.restore(start);steps.forEach(x=>m.apply(x.a));assert.deepEqual(m.save(),end);
  rows.push({label:row.label,start,steps,turns,end,summary,stop,peak});
  console.log(JSON.stringify([row.label,stop==='terminal'?stop:[stop.n,stop.ms,stop.a?.summary],turns.map(t=>[t.summary.wallet,t.summary.established,t.summary.hand,t.summary.probes]),
   summary.wallet[0],summary.established,peak,steps.filter(x=>!x.passive&&x.a.phase==='main').map(x=>x.a.summary)]));
 }finally{m.dispose();}
}
writeZ(out,rows);
