'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const original=Module._extensions['.js'],target=path.resolve('randomizer/game/ai/analysis-port.js');
Module._extensions['.js']=function(mod,file){
 if(file!==target)return original(mod,file);
 const s=fs.readFileSync(file,'utf8'),mark='      submissionCount += 1;';
 assert.equal(s.split(mark).length,2);
 const patch=String.raw`      if(globalThis.setiEvidenceNative) {
        const starts=session?.journal?.actions?.[0]?.action;
        globalThis.setiEvidenceNative.push({family:current.family, summary:current.summary,target:current.target,
          head:head?.type,started:starts?.family,firstSummary:starts?.summary});
      }`;
 const m2='      const endMenu=endPrelude?.task';
 assert.equal(s.split(m2).length,2);
 const extra=String.raw`      if(globalThis.setiEndReasons&&requested.family==='end_turn'&&!endPrelude?.finished){
        const state=readIdentityState(stored.envelope),p=state.players.players.find(p=>p.id===seatId),
          known=knownCards(stored.envelope),sameSeat=state.turn.activePlayerIds.every(id=>id===seatId||state.turn.passedPlayerIds.includes(id));
        const raw=localPlans.previewFinalEndPrelude({state,seatId,action:requested,knownCards:known,allowSameSeat:true});
        const note=[node.status,Boolean(stored.resourceControl),Boolean(stored.intent),Boolean(stored.informationBarrier),
          p.reservedCards.filter(c=>!known.has(c.id)).map(c=>c.cardId).join('/'),
          (state.turn.cardTurnEventBonuses||[]).map(x=>x.id).join('/'),localPlans.hasPendingFossilArrival(state),
          p.resources.score,p.reservedCards.map(x=>x.cardId),raw?.task?.ruleId|| (raw?.finished?'handover':'unsupported'),sameSeat,
          Boolean(state.meta.rngState?.branch)];
        globalThis.setiEndReasons.push(note);
      }
 `;
 mod._compile(s.replace(mark,mark+'\n'+patch).replace(m2,extra+m2),file);
};
const {open,readZ,writeZ}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [input,out]=process.argv.slice(2),result=readZ(input),roots={};
for(const row of result.cases){
 if(row.r4.stop==='terminal'&&!row.label.includes('buy dlc_17.png / income + blue'))continue;
 const root=row.r4.stop==='terminal'?row.r4.start.env:row.r4.end.env,m=open(root);
 const port=createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});
 try{
  const before=m.save();globalThis.setiEvidenceNative=[];globalThis.setiEndReasons=[];
  const actions=m.menu(),r=createSearchAgent({seatId:'player-white',analysisPort:port}).decide({seatId:'player-white',legalActions:actions}).search;
  assert.deepEqual(m.save(),before);
  const used=globalThis.setiEvidenceNative,reasons=globalThis.setiEndReasons;
  const groups={};
  for(const n of reasons){const k=JSON.stringify(n.slice(0,7).concat(n[9],n[10],n[11]));(groups[k]??=[]).push([n[7],n[8]]);}
  console.log('REASONS',row.label,JSON.stringify(Object.entries(groups).map(([k,v])=>[k,v.length,v[0]])));
  assert.equal(used.length,r.diagnostics.nativeExecutions);
  const group=(f)=>Object.entries(used.reduce((a,x)=>{const key=f(x);a[key]=(a[key]||0)+1;return a;},{})).sort((a,b)=>b[1]-a[1]);
  roots[row.label]={root,used,reasons,search:r,native:port.getDiagnostics()};
  console.log(JSON.stringify([row.label,actions.find(a=>a.actionId===r.actionId)?.summary,r.value,r.diagnostics.nativeExecutions,
    group(x=>x.family+':'+(x.head||'-')).slice(0,13),group(x=>x.family+':'+x.summary).slice(0,13)]));
 }finally{port.close();m.dispose();}
}
writeZ(out,{roots});
