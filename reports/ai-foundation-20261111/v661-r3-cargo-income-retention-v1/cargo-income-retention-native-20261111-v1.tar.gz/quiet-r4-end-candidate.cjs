'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const original=Module._extensions['.js'],local=path.resolve('randomizer/game/ai/local-decision-plans.js'),port=path.resolve('randomizer/game/ai/analysis-port.js');
Module._extensions['.js']=function(mod,file){
 if(file!==local&&file!==port)return original(mod,file);
 let s=fs.readFileSync(file,'utf8');
 if(file===local){
  const mark='const preview=residual.previewQuietEndHandoffs(state,seatId,{stationaryCargo:sameSeat});';
  const replacement='const preview=residual.previewQuietEndHandoffs(state,seatId,{stationaryCargo:sameSeat||turn.roundNumber===4});';
  if(s.includes(mark)){assert.equal(s.split(mark).length,2);s=s.replace(mark,replacement);}
  else assert(s.includes(replacement));
 }else if(process.env.SETI_VERIFY_QUIET_END==='1'){
  const mark='        const child=finishProvedTurnBoundary(stored,requested,endPrelude.finished);';
  assert.equal(s.split(mark).length,2);
  s=s.replace(mark,mark+String.raw`
        if(globalThis.setiEndEvidence&&endPrelude.finished.turn.currentPlayerId!==seatId
          &&Object.values(endPrelude.finished.aliens.chong?.transportTasksByRocketId||{}).some(job=>!job.delivered))
          globalThis.setiEndEvidence.push({before:stored.envelope,action:requested,after:nodes.get(child).envelope,
            status:child.status,observation:child.observation});`);
 }
 mod._compile(s,file);
};
