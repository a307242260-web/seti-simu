'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ}=require('./controlled-r3'),fs=require('node:fs');
const [known,quickPath,fullPath,retainedPath,out]=process.argv.slice(2),read=p=>JSON.parse(fs.readFileSync(p));
const prior=read(known),quick=read(quickPath),full=read(fullPath),hold=readZ(retainedPath);
const opener=prior.roundStarts[1],reports={};
const same=(a,b)=>{assert.deepEqual(JSON.parse(a.committedState),JSON.parse(b.committedState));assert.deepEqual(a.session,b.session);};
for(const [label,r] of [['first3',quick],['registered-full',full]]){
 const saved=read(r.savePath),verify=label==='first3',start=verify?opener:{beforeInput:r.roundEnds[2].beforeInput,envelope:read(r.roundEnds[2].checkpointPath).coreState.compositionEnvelope};
 const m=open(start.envelope),roots=new Map(r.metrics.searches.map(x=>[x.step,x])),rounds=new Map(r.roundEnds.map(x=>[x.beforeInput,x]));
 const rows=[];let checkpoint;
 try{
  for(let i=start.beforeInput;i<=saved.replaySteps.length;i++){
   const e=rounds.get(i);if(e)same(m.save(),read(e.checkpointPath).coreState.compositionEnvelope);
   const a=saved.replaySteps[i-1].action,history=roots.get(i);
   if(verify&&history){
    const q=m.automatic(checkpoint);checkpoint=q.checkpoint;
    assert(q.complete&&q.n<=256&&q.ms<=600,JSON.stringify([i,q.n,q.ms,q.complete]));
    assert.equal(q.a.actionId,history.actionId,String(i));
    assert.equal(q.value,history.value,String(i));
    assert.equal(q.n,history.diagnostics.nativeExecutions,String(i));
    rows.push([i,q.n,q.ms,q.value]);
   }
   m.apply(a);
  }
  same(m.save(),saved);assert.equal(m.facts().final,verify?164:216);
  reports[label]={native:saved.replaySteps.length-start.beforeInput+1,rows,max:rows.length?[Math.max(...rows.map(r=>r[1])),Math.max(...rows.map(r=>r[2]))]:null,final:m.facts().final};
  console.log(label,JSON.stringify({...reports[label],rows:rows.length}));
 }finally{m.dispose();}
}
let moves=0;
for(const row of hold){
 const m=open(row.start);
 try{
  for(const step of row.steps){assert(!step.n||step.n<=256&&step.ms<=600);m.apply(step.a);moves++;}
  same(m.save(),row.end);
  if(row.stop==='terminal')assert.equal(m.state().turn.gameEnded,true);
 }finally{m.dispose();}
}
console.log('branches',hold.length,'replayedInputs',moves);
writeZ(out,{reports,replayedBranchInputs:moves});
