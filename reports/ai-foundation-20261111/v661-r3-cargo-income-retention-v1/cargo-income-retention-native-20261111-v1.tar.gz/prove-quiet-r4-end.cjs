'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ}=require('./controlled-r3');
const {isDeepStrictEqual}=require('node:util');
const [src,out]=process.argv.slice(2),d=readZ(src),rows=[];
for(const [label,row] of Object.entries(d.roots)){
 const m=open(row.root);
 try{
  globalThis.setiEndEvidence=[];const q=m.automatic();
  const changes=globalThis.setiEndEvidence;globalThis.setiEndEvidence=null;
  assert.equal(q.a?.actionId,row.search.actionId);assert.equal(q.value,row.search.value);
  assert.deepEqual(JSON.parse(JSON.stringify(q.roots)),row.search.roots);assert(q.complete);
  for(const [i,change] of changes.entries()){
   const restored=m.c.lifecycle.restore(change.before);assert(restored.ok,JSON.stringify(restored));
   assert.deepEqual(JSON.parse(m.save().committedState),JSON.parse(change.before.committedState));
   m.apply(change.action);
   const end=m.save(),after=JSON.parse(end.committedState),expected=JSON.parse(change.after.committedState);
   assert.deepEqual(end.session,null);
   assert.deepEqual(after,expected,label+' / '+i);
   assert.equal(change.status==='other-owner'||change.status==='information-barrier',true);
   if(change.observation?.publicState?.currentPlayerId)assert.equal(change.observation.publicState.currentPlayerId,after.turn.currentPlayerId);
  }
  console.log(JSON.stringify([label,row.search.diagnostics.nativeExecutions,q.n,q.ms,changes.length,q.a?.summary,q.value]));
  rows.push({label,roots:q.roots,value:q.value,previous:row.search.diagnostics.nativeExecutions,now:q.n,ms:q.ms,changes});
 }finally{m.dispose();}
}
assert(rows.some(x=>x.now<=256&&x.previous>256));
writeZ(out,rows);
