'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const original=Module._extensions['.js'],target=path.resolve('randomizer/game/ai/analysis-port.js');
Module._extensions['.js']=function(mod,file){
 if(file!==target)return original(mod,file);
 const s=fs.readFileSync(file,'utf8'),mark='      submissionCount += 1;';
 assert.equal(s.split(mark).length,2);
 const patch=String.raw`      if(globalThis.setiEvidenceNative) {
        const starts=session?.journal?.actions?.[0]?.action;
        globalThis.setiEvidenceNative.push({family:current.family, summary:current.summary,target:current.target,
          head:head?.type,started:starts?.family,firstSummary:starts?.summary});
      }`;
 mod._compile(s.replace(mark,mark+'\n'+patch),file);
};
const {open,readZ,writeZ}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [input,out]=process.argv.slice(2),result=readZ(input),roots={};
for(const row of result.cases){
 if(row.r4.stop==='terminal'&&!row.label.includes('buy dlc_17.png / income + blue'))continue;
 const root=row.r4.stop==='terminal'?row.r4.start.env:row.r4.end.env,m=open(root);
 const port=createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});
 try{
  const before=m.save();globalThis.setiEvidenceNative=[];
  const actions=m.menu(),r=createSearchAgent({seatId:'player-white',analysisPort:port}).decide({seatId:'player-white',legalActions:actions}).search;
  assert.deepEqual(m.save(),before);
  const used=globalThis.setiEvidenceNative;
  assert.equal(used.length,r.diagnostics.nativeExecutions);
  const group=(f)=>Object.entries(used.reduce((a,x)=>{const key=f(x);a[key]=(a[key]||0)+1;return a;},{})).sort((a,b)=>b[1]-a[1]);
  roots[row.label]={root,used,search:r,native:port.getDiagnostics()};
  console.log(JSON.stringify([row.label,actions.find(a=>a.actionId===r.actionId)?.summary,r.value,r.diagnostics.nativeExecutions,
    group(x=>x.family+':'+(x.head||'-')).slice(0,13),group(x=>x.family+':'+x.summary).slice(0,13)]));
 }finally{port.close();m.dispose();}
}
writeZ(out,{roots});
