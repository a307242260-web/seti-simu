'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,writeZ,short}=require('./controlled-r3');
const {getDiscardActionRewardForCard,getIncomeGainForCard}=require(path.resolve('randomizer/game/cards/deck'));
const [input,out]=process.argv.slice(2),A='amiba_5.webp',D='dlc_14.png',white='player-white';
const data=readZ(input),root=data.rows.find(r=>r.label.includes('外星人 1 黄4号位')).checkpoints['after-landing'].state;
const m=open(root),cases=[],checks={},gated=u=>!u.complete||!u.a||u.n>256||u.ms>600;
const telemetry=u=>({a:u.a,n:u.n,ms:u.ms,value:u.value});
function state(){return {summary:short(m),facts:m.facts(),env:m.save()};}
function inspect(name){
 const u=m.automatic(); checks[name]={...telemetry(u),roots:u.roots,complete:u.complete};
 assert(!gated(u),JSON.stringify([name,checks[name]]));
 console.log('root',name,JSON.stringify([u.a.summary,u.value,u.n,u.ms,u.roots?.map(r=>[r.label,r.value])]));
}
function playR4(passPrefix){
 const start=state(),inputs=[],turns=[];
 let stop,checkpoint,needTurn=false;
 for(let i=0;i<200;i++){
  const turn=m.state().turn,a=m.menu()[0];
  if(turn.gameEnded){stop='terminal';break;}
  if(!a) throw Error('empty native menu');
  if(a.actorId!==white){
   const passive=[];m.advanceOpponents(passive);
   inputs.push(...passive.map(a=>({a,passive:true})));continue;
  }
  if(needTurn&&!m.save().session){turns.push({...state(),step:inputs.length});needTurn=false;}
  const u=m.automatic(checkpoint);
  if(gated(u)){stop={type:'gate',...telemetry(u),complete:u.complete};break;}
  checkpoint=u.checkpoint;
  inputs.push({...telemetry(u),a:m.apply(u.a)});
  if(u.a.family==='end_turn')needTurn=true;
 }
 assert(stop);
 const end=state();
 m.restore(start.env);inputs.forEach(x=>m.apply(x.a));assert.deepEqual(m.save(),end.env);
 return {start,end,turns,inputs,stop,passPrefix};
}
function run(label,setup,how='ai'){
 m.restore(root);
 const prefix=[],auto=[];
 const act=(f,p)=>{const a=m.act(f,p);prefix.push(a);return a;};
 const place=kind=>{
   act('place_data');
   act('choose_target',a=>kind==='computer'?a.target.target==='computer':a.target.target==='blueBonus'&&a.target.blueSlot===1);
 };
 const task=()=>act('complete_task',a=>a.summary.includes('b_117.webp')||a.target.cardInstanceId===m.player().reservedCards.find(c=>c.cardId==='b_117.webp')?.id);
 const buy=id=>{
   const shown=m.state().cards.publicCards.find(c=>c?.cardId===id);assert(shown);assert.equal(getDiscardActionRewardForCard(shown)?.dataCount,1);
   act('quick_trade',a=>a.target.tradeId==='publicity-for-card');prefix.push(m.pick(id));
 };
 const corner=id=>{const c=m.player().hand.find(c=>c.cardId===id);assert(c);assert.equal(getDiscardActionRewardForCard(c)?.dataCount,1);prefix.push(m.corner(id));};
 const insert=id=>{
   const c=m.player().hand.find(c=>c.cardId===id);assert(c);assert.equal(getIncomeGainForCard(c)?.energy,1);
   place('computer');act('choose_card',a=>a.target.cardInstanceId===c.id);
 };
 const fill=()=>{for(let i=0;i<3;i++)place('computer');task();};
 try{setup({act,place,task,buy,corner,insert,fill});}catch(err){
  console.error(label,err.message,JSON.stringify(short(m)),JSON.stringify(m.menu().map(a=>[a.family,a.summary,a.target])));
  throw err;
 }
 const afterFixed=state();let checkpoint,pass;
 if(how==='fixed'){act('end_turn');const others=[];m.advanceOpponents(others);prefix.push(...others);pass=m.menu().find(a=>a.family==='pass');}
 else {
  for(let i=0;i<30;i++){
   if(m.menu()[0]?.actorId!==white){const others=[];m.advanceOpponents(others);auto.push(...others.map(a=>({a,passive:true})));continue;}
   const u=m.automatic(checkpoint);assert(!gated(u),JSON.stringify(telemetry(u)));
   if(u.a.family==='pass'){pass=u.a;break;}
   checkpoint=u.checkpoint;auto.push({...telemetry(u),a:m.apply(u.a)});
  }
 }
 assert(pass);
 const r3=state(),passPrefix=[m.apply(pass)];
 const b111=m.menu().find(a=>a.target.cardId==='b_111.webp'||a.summary==='b_111.webp');assert(b111,JSON.stringify(m.menu()));
 passPrefix.push(m.apply(b111));m.advanceOpponents(passPrefix);assert.equal(m.facts().round,4);
 const r4=playR4(passPrefix);
 m.restore(root);prefix.forEach(m.apply);auto.forEach(x=>m.apply(x.a));assert.deepEqual(m.save(),r3.env);
 passPrefix.forEach(m.apply);assert.deepEqual(m.save(),r4.start.env);
 const peak=list=>[Math.max(...list.map(x=>x.n||0)),Math.max(...list.map(x=>x.ms||0))];
 cases.push({label,prefix,auto,afterFixed,r3,r4,peaks:peak(auto.concat(r4.inputs))});
 console.log(JSON.stringify({label,r3:r3.summary,stop:r4.stop,turns:r4.turns.slice(0,3).map(x=>[x.summary.wallet,x.summary.established,x.summary.hand.length,x.summary.probes]),end:r4.end.summary,peaks:cases.at(-1).peaks,actions:r4.inputs.filter(x=>x.a.phase==='main').map(x=>x.a.summary)}));
}
try{
 inspect('after-landing');
 run('current',()=>{});
 run('no-buy / A5 pays / DLC14 income',h=>{h.fill();inspect('after-three-and-task');h.corner(A);h.insert(D);},'fixed');
 run('no-buy / DLC14 pays / A5 income',h=>{h.fill();h.corner(D);h.insert(A);},'fixed');
 run('buy DLC15 only / AI',h=>{h.fill();h.buy('dlc_15.png');inspect('after-buy');});
 for(const market of ['dlc_15.png','dlc_17.png']){
  for(const [pay,keep] of [[A,D],[D,A]]){
   run('buy '+market+' / income '+pay+' / keep '+keep,h=>{h.fill();h.buy(market);h.corner(market);h.insert(pay);},'fixed');
  }
  run('buy '+market+' / income + blue',h=>{h.fill();h.buy(market);h.corner(market);h.corner(A);h.insert(D);h.place('blue');},'fixed');
 }
 writeZ(out,{source:root,checks,cases});
}finally{m.dispose();}
