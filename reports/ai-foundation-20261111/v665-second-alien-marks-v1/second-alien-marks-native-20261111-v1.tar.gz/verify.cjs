'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,short}=require('./controlled-r3');
const repo=path.resolve(process.argv[2]||'.');
const record=require(path.join(repo,'reports/research/926c5bc2.9a1cafee.quick-400.json'));
const officialSave=require(path.join(repo,record.savePath));
const checkpoint=require(path.join(repo,record.roundEnds[1].checkpointPath));
const data=(name,version=1)=>readZ(path.join(__dirname,name+'-20261111-v'+version+'.json.gz'));
const roots={};
const totals={officialInputs:0,round3Branches:0,failedPrefixes:0,round4Terminals:0,round4Gates:0,replayedInputs:0,peakNative:0,peakMs:0};
function apply(m,item){
 if(item.n!==undefined){
  assert(item.n<=256&&item.ms<=600);
  totals.peakNative=Math.max(totals.peakNative,item.n);
  totals.peakMs=Math.max(totals.peakMs,item.ms);
 }
 m.apply(item.action||item.a||item);
 totals.replayedInputs+=1;
}
const official=open(checkpoint.coreState.compositionEnvelope);
try{
 for(const {stepIndex,action} of officialSave.replaySteps.slice(checkpoint.replayCursor.stepIndex)){
  const i=stepIndex+1;
  if([180,190,211,243].includes(i))roots[i]=official.save();
  official.apply(action);totals.officialInputs++;
 }
 assert.equal(official.save().committedState,officialSave.committedState);
 assert.deepEqual(official.save().session,officialSave.session);
}finally{official.dispose();}

const blue=data('blue-reveal'),retained=data('retained-blue-reveal',2),swap=data('procyon',2),procyon=data('procyon-buy'),launch=data('procyon-launch');
assert.deepEqual(blue[190].root,roots[190]);
assert.deepEqual(blue[243].root,roots[243]);
assert.deepEqual(retained.root,roots[180]);
for(const row of [swap,procyon])assert.deepEqual(row.root,roots[211]);
for(const [label,group] of Object.entries(launch))assert.deepEqual(group.root,procyon.rows.find(r=>r.label===label).start);
const round3Ends=[];
for(const group of [...Object.values(blue),retained,swap,procyon,...Object.values(launch)]){
 const m=open(group.root);
 try{
  for(const row of group.rows){
   m.restore(group.root);
   row.prefix.forEach(a=>apply(m,a));
   assert.deepEqual(m.save(),row.start);
   for(const x of row.actions){
    if(x.action.family==='pass'&&x.action.actorId==='player-white'){
     assert.deepEqual(m.save(),row.settled.state);
     assert.deepEqual(JSON.parse(JSON.stringify(short(m))),row.settled.summary);
     round3Ends.push(row.settled.state);
    }
    apply(m,x);
   }
   assert.deepEqual(m.save(),row.end);
   assert.equal(row.stop,'r4-first-white-main');
   totals.round3Branches++;
  }
  for(const row of group.failures){
   m.restore(group.root);row.prefix.forEach(a=>apply(m,a));
   assert.deepEqual(m.save(),row.checkpoint);
   totals.failedPrefixes++;
  }
 }finally{m.dispose();}
}
const handoffs=data('r4-handoffs'),endpoints=data('r4-terminal');
for(const row of [...handoffs.cases,...handoffs.failures]){
 assert(round3Ends.some(state=>state.committedState===row.root.committedState));
 const m=open(row.root);
 try{
  row.steps.forEach(a=>apply(m,a));
  assert.deepEqual(m.save(),row.r4?.start.env||row.end);
 }finally{m.dispose();}
}
const moved=data('r4-move-handoffs');
for(const row of moved.cases){
 assert.deepEqual(row.root,handoffs.cases.find(r=>row.label===r.label+' / outward').r4.start.env);
 const m=open(row.root);
 try{
  row.steps.forEach(a=>apply(m,a));
  assert.deepEqual(m.save(),row.r4.start.env);
 }finally{m.dispose();}
}
for(const row of [...endpoints,...data('r4-move-terminal'),...data('r4-resume-terminal')]){
 assert.deepEqual(row.start,[...handoffs.cases,...moved.cases].find(x=>x.label===row.label).r4.start.env);
 const m=open(row.start);
 try{
  row.steps.forEach(a=>apply(m,a));
  assert.deepEqual(m.save(),row.end);
  if(row.stop==='terminal'){assert(m.state().turn.gameEnded);totals.round4Terminals++;}
  else{assert(row.stop.kind==='gate'&&!m.state().turn.gameEnded);totals.round4Gates++;}
 }finally{m.dispose();}
}
console.log(JSON.stringify(totals,null,2));
