'use strict';
const assert=require('node:assert/strict');
const {open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const [source,out]=process.argv.slice(2);
const root=readZ(source).rows.find(r=>r.i===211).before;
const procyon='sector-1-a';
const cases=[];
function end(h){h.act('end_turn');const passive=[];h.m.advanceOpponents(passive);h.take(...passive);}
function cash(h,pair){
 h.act('quick_trade',a=>a.target.tradeId==='cards-for-credit');
 for(const name of pair)h.act('choose_payment',a=>a.target.select&&a.summary===name);
 h.act('choose_payment',a=>a.target.confirm);
}
function first(h,swapInto,when){
 if(when==='before')h.take(...h.m.swap('dlc_25.png',swapInto));
 h.take(h.m.play('b_16.webp'));
 const done=h.m.menu().find(a=>a.target?.done||a.summary==='结束移动');
 if(done)h.take(h.m.apply(done));
 const choice=h.m.menu().find(a=>a.target?.nebulaId===procyon);
 assert(choice,JSON.stringify(h.m.menu().map(a=>a.summary)));
 h.take(h.m.apply(choice));
 if(when==='after')h.take(...h.m.swap('dlc_25.png',swapInto));
 h.cut('after-first-signal');
 cash(h,['amiba_9.webp',swapInto]);
 end(h);
 h.cut('before-second-action');
 h.act('scan');
 h.act('choose_target',a=>a.target.nebulaId===procyon);
 h.cut('before-public-signal');
 h.act('choose_card',a=>a.target.nebulaId===procyon&&a.summary.startsWith('dlc_16.png'));
 h.cut('second-pink');
}
for(const card of ['dlc_17.png','dlc_20.png','dlc_24.png'])for(const when of ['before','after']){
 for(const reward of ['second species','known Amiba']){
  cases.push([card+' swap '+when+' / '+reward,h=>{
   first(h,card,when);
   h.act('choose_target',a=>reward==='second species'?a.target.alienSlotId===2:a.target.speciesId==='amiba'&&a.target.position===3);
   const visible=h.m.menu().find(a=>a.target.source==='display');
   if(visible)h.take(h.m.apply(visible));
  }]);
 }
}
writeZ(out,{root,...runCases(root,cases)});
