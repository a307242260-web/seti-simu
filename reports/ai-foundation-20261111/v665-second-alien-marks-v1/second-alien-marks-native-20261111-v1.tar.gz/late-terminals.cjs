'use strict';
const assert=require('node:assert/strict');
const {open,readZ,writeZ,short}=require('./controlled-r3');
const [blue,retained,procyon,launched,out]=process.argv.slice(2);
const cases=[],failures=[];
const finalists=[
 ['standard-late-blue',readZ(blue)[243].rows[0]],
 ...readZ(retained).rows.filter(r=>r.label.startsWith('dlc_15.png / ')).map(r=>[r.label,r]),
 ...readZ(procyon).rows.filter(r=>r.label.startsWith('dlc_17.png buy, trade dlc_25.png+dlc_17.png')).map(r=>[r.label,r]),
];
const launchedRoot='dlc_17.png buy, trade dlc_25.png+dlc_17.png / second species';
finalists.push(['Procyon, reveal, force Orange1/DLC20',readZ(launched)[launchedRoot].rows.find(r=>r.label==='dlc_20.png')]);
for(const [name,row] of finalists)for(const keep of ['b_111.webp','b_32.webp']){
 const root=row.settled.state,m=open(root),steps=[];
 try{
  steps.push(m.act('pass'));
  const option=m.menu().find(a=>a.target.cardId===keep);
  if(!option){
   failures.push({name,keep,root,steps,menu:m.menu(),end:m.save()});continue;
  }
  steps.push(m.apply(option));
  m.advanceOpponents(steps);
  assert.equal(m.facts().round,4);
  assert(!m.save().session);
  cases.push({label:name+' / '+keep,root,steps,r4:{start:{env:m.save(),summary:short(m)}}});
 }finally{m.dispose();}
}
writeZ(out,{cases,failures});
