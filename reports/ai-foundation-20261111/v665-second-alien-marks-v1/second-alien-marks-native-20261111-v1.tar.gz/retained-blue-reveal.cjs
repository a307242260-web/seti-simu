'use strict';

const assert=require('node:assert/strict');
const {open,readZ,writeZ,runCases}=require('./controlled-r3');
const [source,out]=process.argv.slice(2);
const steps=new Map(readZ(source).rows.map(row=>[row.i,row]));
const root=steps.get(180).before;
function setup(h,swapCard){
 h.act('choose_target',a=>a.target.slotId==='blue_3');
 for(let i=181;i<=236;i++)h.take(h.m.apply(steps.get(i).a));
 h.act('choose_target',a=>a.target.region==='red'&&a.summary.includes('1数据'));
 if(swapCard)h.take(...h.m.swap('b_16.webp',swapCard));
 h.act('end_turn');
 const passive=[];h.m.advanceOpponents(passive);h.take(...passive);
 h.act('analyze');
 h.cut('before-mark');
}
const cases=[];
for(const card of ['dlc_15.png',null]){
 for(const mark of ['second species','known Amiba']){
  cases.push([String(card)+' / '+mark,h=>{
   setup(h,card);
   h.act('choose_target',a=>mark==='second species'?a.target.alienSlotId===2:a.target.speciesId==='amiba'&&a.target.position===3);
   const offer=h.m.menu().find(a=>a.target.source==='display');
   if(offer)h.take(h.m.apply(offer));
   h.cut('after-mark');
  }]);
 }
}
cases.push(['second species / fund income with visible two corners',h=>{
 setup(h,'dlc_15.png');
 h.act('choose_target',a=>a.target.alienSlotId===2);
 h.cut('after-mark');
 for(const id of ['dlc_15.png','dlc_17.png'])h.take(h.m.corner(id));
 assert.equal(h.m.facts().wallet.availableData,4);
 for(let i=0;i<4;i++){
  h.act('place_data');
  h.act('choose_target',a=>a.target.target==='computer');
 }
 h.act('choose_card',a=>a.summary==='收入 dlc_25.png');
}]);
writeZ(out,{root,...runCases(root,cases)});
