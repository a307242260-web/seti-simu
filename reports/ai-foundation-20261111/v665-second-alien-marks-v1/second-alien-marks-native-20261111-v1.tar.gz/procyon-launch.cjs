'use strict';

const assert=require('node:assert/strict');
const {open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [source,out]=process.argv.slice(2);
const groups={};
const data=readZ(source);
function end(h){h.act('end_turn');const passive=[];h.m.advanceOpponents(passive);h.take(...passive);}
function orange(h){
 h.act('accept_optional_effect',a=>a.target.ruleId==='amiba0-pink-data');
 h.act('complete_task',a=>a.target.ruleId==='dlc9-three-sector-wins');
 end(h);h.cut('before-research');
 h.act('research_tech');
 h.act('choose_target',a=>a.target.tileId==='orange1');
}
for(const row of data.rows.filter(r=>r.label.startsWith('dlc_17.png buy, trade dlc_25.png+dlc_17.png')||r.label.startsWith('dlc_24.png buy, trade amiba_9.webp+dlc_25.png'))){
 const root=row.start,m=open(root);
 const cases=[];
 try{
  orange({m,act:(f,p)=>m.act(f,p),take:()=>{},cut:()=>{}});
  for(const card of m.menu()){
   cases.push([card.summary,h=>{orange(h);h.take(h.m.apply(card));}]);
  }
 }finally{m.dispose();}
 groups[row.label]={root,...runCases(root,cases)};
}
writeZ(out,groups);
