'use strict';
const assert=require('node:assert/strict');
const {open,readZ,writeZ,short}=require('./controlled-r3');
const [source,out]=process.argv.slice(2),cases=[];
for(const row of readZ(source).cases.filter(r=>r.label.startsWith('dlc_15.png / '))){
 const m=open(row.r4.start.env),steps=[];
 try{
  steps.push(m.act('move',a=>a.target.deltaX===0&&a.target.deltaY===1));
  steps.push(m.act('choose_payment',a=>a.summary==='消耗 1 能量'));
  const after=m.save();
  m.restore(row.r4.start.env);
  steps.forEach(m.apply);
  assert.deepEqual(m.save(),after);
  cases.push({label:row.label+' / outward',root:row.r4.start.env,steps,r4:{start:{env:after,summary:short(m)}}});
 }finally{m.dispose();}
}
writeZ(out,{cases});
