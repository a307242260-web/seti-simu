'use strict';

const {open,readZ,writeZ,runCases}=require('./controlled-r3');
const [source,out]=process.argv.slice(2);
const rows=new Map(readZ(source).rows.map(row=>[row.i,row]));
const results={};
function exact(h,a,b){for(let i=a;i<=b;i++)h.take(h.m.apply(rows.get(i).a));}
function end(h){h.act('end_turn');const passive=[];h.m.advanceOpponents(passive);h.take(...passive);}
function place(h,slot){
 h.act('place_data');
 h.act('choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');
}
function reveal(h){h.act('choose_target',a=>a.target.alienSlotId===2);h.cut('blue-reveal');}
function chooseAmiba(h,slot){h.act('choose_target',a=>a.target.speciesId==='amiba'&&a.target.position===slot);}
function analyze(h){h.act('analyze');}
function research(h,tile,slot){h.act('research_tech');h.act('choose_target',a=>a.target.tileId===tile&&(!slot||a.target.blueSlot===slot));}

const early=[
 ['blue reveal, rest auto',reveal],
 ['blue reveal, purple1 then tuck A1 and auto',h=>{
  reveal(h);end(h);research(h,'purple1');
  for(let i=0;i<4;i++)place(h);
  h.act('choose_card',a=>a.summary==='收入 amiba_1.webp');h.cut('tuck');
 }],
];
for(const payer of ['two-hand-to-energy','research-blue4','swap-and-use-DLC17']){
 early.push([payer,h=>{
  early[1][1](h);
  if(payer==='two-hand-to-energy'){
   h.act('quick_trade',a=>a.target.tradeId==='cards-for-energy');
   for(const card of ['amiba_9.webp','b_16.webp'])h.act('choose_payment',a=>a.target.select&&a.summary===card);
   h.act('choose_payment',a=>a.target.confirm);
  }else if(payer==='research-blue4'){
   h.take(h.m.corner('amiba_9.webp'));h.take(h.m.corner('b_16.webp'));end(h);research(h,'blue4',3);
  }else{
   h.act('quick_trade',a=>a.target.tradeId==='publicity-for-card');h.take(h.m.pick('dlc_25.png'));
   h.cut('DLC17 now public');
   h.take(...h.m.swap('dlc_25.png','dlc_17.png'));
   h.take(h.m.corner('dlc_17.png'));place(h,1);
  }
  end(h);h.cut('ready-scan');h.act('scan');
 }]);
}
const late=[['blue reveal after both pinks, rest auto',reveal]];
for(const finish of ['leave-data','use-DLC25-corner','tuck-DLC25']){
 late.push([finish,h=>{
  reveal(h);h.take(h.m.corner('dlc_15.png'));h.take(h.m.corner('dlc_17.png'));
  if(finish==='leave-data'){
   h.act('end_turn');h.act('pass');
  }else if(finish==='use-DLC25-corner'){
   h.take(h.m.corner('dlc_25.png'));for(let i=0;i<3;i++)place(h);
  }else{
   for(let i=0;i<4;i++)place(h);
   h.act('choose_card',a=>a.summary==='收入 dlc_25.png');
  }
 }]);
}
for(const [i,cases] of [[190,early],[243,late]]){
 const root=rows.get(i).before;
 results[i]={root,...runCases(root,cases)};
}
writeZ(out,results);
