Run from the V668 source checkout. Extract this archive to a fresh directory.
Then extract the three input fixtures from the earlier V667 archive into that same directory:
```sh
tar -xf reports/ai-foundation-20261111/v667-r3-retain-amiba5-v1/retain-amiba5-evidence-20261111-v1.tar.gz -C "$proof" \
  ./r3-retained-amiba5-diagnosis-20261111-v2.json.gz ./r3-retained-amiba5-end-only-20261111-v1.json.gz \
  ./cargo-cash-retain-20261111-v1.json.gz
node "$proof/admission.cjs" /tmp/v668-admission-fresh.json.gz
node "$proof/standard-gate.cjs" "$PWD" reports/ai-foundation-20261109/v660-public-transport-chain-v1/v660-first3-independent-replay-20261109-v1.checkpoint.json /tmp/v668-standard-fresh.json.gz 6fd85941.93c471b0.quick-400.json
node tools/run_node_tests.js --match stationary-cargo-income --match scan-income-after-free-move --match r4-company-tail
node tools/audit_v_state_inputs.js
node tools/run_browser_smokes.js --match production-resource-goal-plan --match production-search-agent-entry
```
Both same-seat proofs compare the already closed current-turn corner line, use the actual native menu for the public pick, and only use a symbol observed in the root. The tests exercise paid and unpaid card roots, an active opponent, unseen deck permutations, a witness input cap, save/restore, and the exact original R4 entry reached by autonomous R3.
