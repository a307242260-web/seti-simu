'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {readZ,writeZ,open,runCases}=require('./controlled-r3');
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const {createStateValueEvaluator}=require(path.resolve('randomizer/game/ai/state-value'));
const {searchDecision}=require(path.resolve('randomizer/game/ai/decision-search'));
const {BUDGET,OPTIONS}=require(path.resolve('randomizer/game/ai/search-agent'));
const [out]=process.argv.slice(2),seatId='player-white';
const data=readZ(path.join(__dirname,'r3-retained-amiba5-diagnosis-20261111-v2.json.gz'));
const controls=readZ(path.join(__dirname,'r3-retained-amiba5-end-only-20261111-v1.json.gz')).groups;
const funding=readZ(path.join(__dirname,'cargo-cash-retain-20261111-v1.json.gz')).groups;
const rows=[];
function check(e){
 const m=open(e),analysisPort=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
 try{
  const visible=m.owner(seatId),menu=m.menu(),q=createSearchAgent({analysisPort,seatId}).decide({seatId,legalActions:menu}).search;
  assert(q.complete&&!q.unresolved.length&&q.rootAndSearchMilliseconds<=600&&q.diagnostics.nativeExecutions<=256);
  assert.deepEqual(m.save(),e);
  return {visible,menu,choice:q.actionId,proof:q.retainRegionCard,roots:q.roots,value:q.value,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds};
 }finally{m.dispose();}
}
function variant(e,edit){
 const s=JSON.parse(e.committedState);edit(s);
 return {...e,committedState:createStateStore(s).serialize().serialized};
}
for(const [i,x] of data.diagnoses.entries()){
 const parent=funding.find(g=>g.label===x.origin),funded=parent.rows.find(r=>r.label.endsWith('b_9.webp / autonomous'));
 const m=open(parent.root);let warm;
 try{
  for(const a of funded.prefix)m.apply(a);
  assert.deepEqual(m.save(),x.funding);
  m.restore(parent.root);
  for(const a of funded.prefix.slice(0,-1))m.apply(a);
  const beforeClaim=m.save(),q=m.automatic(),last=funded.prefix.at(-1);
  assert.deepEqual(q.a,last);assert.equal(q.n,23);assert(q.ms<=600);
  m.apply(last);
  assert.deepEqual(m.save(),x.funding);
  const u=m.automatic(q.checkpoint);
  assert(u.a.family==='end_turn'&&u.n===10&&u.ms<=600);
  warm={beforeClaim,previous:q.a,actual:last,next:u.a,n:u.n,ms:u.ms,roots:u.roots};
 }finally{m.dispose();}
 const base=check(x.funding);
 assert(base.proof?.value===[186,187][i]&&base.n===10);
 const hidden=check(variant(x.funding,s=>{
   for(const pile of [s.cards.drawPileCardIds,s.aliens.amiba.cardDeck,s.aliens.chong.cardDeck]){
    assert(pile.length>=2);[pile[0],pile[1]]=[pile[1],pile[0]];
   }
 }));
 for(const k of ['visible','menu','choice','proof','roots','value','n']) assert.deepEqual(base[k],hidden[k],k);
 const capped=open(x.funding), port=createAnalysisPort({composition:capped.c,seatId,maxCacheEntries:0});
 let exhausted;
 try {
  const root=port.openRoot();
  const q=searchDecision({port,root,evaluate:createStateValueEvaluator(seatId),budget:BUDGET,...OPTIONS,
    scanOrbitBudget:{nativeInputs:8,deadline:performance.now()+600}});
  assert(q.complete&&q.actionId===base.proof.visibleActionId&&!q.retainRegionCard);
  assert.equal(q.diagnostics.nativeExecutions,8);
  assert.deepEqual(capped.save(),x.funding);
  exhausted={actionId:q.actionId,n:q.diagnostics.nativeExecutions};
 }finally{port.close();capped.dispose();}
 const active=check(variant(x.funding,s=>{
  s.turn.passedPlayerIds=s.turn.passedPlayerIds.filter(id=>id!=='player-green');
 }));
 assert.equal(active.proof,undefined);
 const autonomous=runCases(warm.beforeClaim,[['全自主',()=>{}]]).rows[0];
 const expected=controls[i].rows[0];
 assert.deepEqual(autonomous.actions.map(x=>x.action),[warm.actual,...expected.prefix,...expected.actions.map(x=>x.action)]);
 assert.deepEqual(autonomous.settled.state,expected.settled.state);
 assert.deepEqual(autonomous.end,expected.end);
 rows.push({origin:x.origin,base,hidden,active,warm,exhausted,autonomous});
 console.log(JSON.stringify([x.origin,base.proof,base.n,base.ms,hidden.ms,active.n,warm.previous.summary,warm.actual.summary,exhausted]));
}
writeZ(out,{rows});
