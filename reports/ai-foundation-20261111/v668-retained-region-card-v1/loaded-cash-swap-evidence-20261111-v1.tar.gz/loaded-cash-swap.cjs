'use strict';
const path=require('node:path');
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [out]=process.argv.slice(2),data=readZ(path.join(__dirname,'cargo-cash-retain-20261111-v1.json.gz'));
const groups=[];
for(const g of data.groups.filter(g=>g.label.includes('saturn'))){
 const market=g.rows.find(r=>r.label.endsWith('b_9.webp / autonomous')).label.split(' / ')[0];
 const result=runCases(g.root,[['当前全自主',()=>{}],['只固定公司换公开钱收入',h=>h.take(...h.m.swap('b_9.webp',market))]]);
 groups.push({origin:g.label,market,...result});
}
writeZ(out,{groups});
