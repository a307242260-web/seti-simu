Run from V668 source (6071c49f2). Extract the previous inputs
`cargo-cash-retain-20261111-v1.json.gz` and `r3-retained-amiba5-end-only-20261111-v1.json.gz` from the V667 retain-Amiba archive into this directory.
```sh
node "$proof/loaded-cash-swap.cjs" /tmp/v668-swap.json.gz
node "$proof/loaded-cash-choice.cjs" /tmp/v668-swap.json.gz /tmp/v668-cash-choice.json.gz
node "$proof/loaded-cash-fourth.cjs" /tmp/v668-cash-choice.json.gz /tmp/v668-loaded-control-terminal.json.gz
```
The prepared variants match the exact settled R3 states in the V667 retain-Amiba evidence. Their R4 results are reused under the same fixed retained card.
