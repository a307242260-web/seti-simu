'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [first,out]=process.argv.slice(2);
const sources=readZ(path.join(__dirname,'cargo-cash-retain-20261111-v1.json.gz')).groups;
const existing=readZ(first).groups;
for(const group of existing){
 const match=sources.find(g=>g.label===group.origin);
 const seen=group.rows.find(r=>r.label==='只固定公司换公开钱收入');
 const cut=seen.actions.findIndex(x=>x.action.family==='choose_card'&&x.action.summary.startsWith('收入 '));
 assert(cut>0);
 const one=runCases(match.root,[['固定换牌与钱收入，其余自主',h=>{
  h.take(...h.m.swap('b_9.webp',group.market));
  for(const {action} of seen.actions.slice(0,cut))h.take(h.m.apply(action));
  h.act('choose_card',a=>a.summary===`收入 ${group.market}`);
 }]]);
 const expected=readZ(path.join(__dirname,'r3-retained-amiba5-end-only-20261111-v1.json.gz')).groups.find(g=>g.origin===group.origin).rows[0];
 assert.deepEqual(one.rows[0].settled.state,expected.settled.state);
 group.rows.push(...one.rows);
}
writeZ(out,{groups:existing});
