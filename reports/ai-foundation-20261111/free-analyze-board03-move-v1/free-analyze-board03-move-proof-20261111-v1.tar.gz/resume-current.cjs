'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict'),z=require('node:zlib');
const [input,out]=process.argv.slice(2),fix=require('./r3-move.cjs');
function load(rel,change){
 const f=path.resolve(rel),mod=new Module(f,module);
 mod.filename=f;mod.paths=Module._nodeModulePaths(path.dirname(f));mod._compile(change(fs.readFileSync(f,'utf8')),f);
 mod.loaded=true;require.cache[f]=mod;
}
const scenario=require(path.resolve('tools/research-free-analyze-random20'));
const cp=JSON.parse(fs.readFileSync(input)),env=scenario.createEnvironment({},{id:'free-analyze-random20-guarded-v1'}),inputs=[];
const before=performance.now();let failure;
try{
 env.loadCheckpoint(cp);assert.deepEqual(env.createCheckpoint().coreState.compositionEnvelope,cp.coreState.compositionEnvelope);
 while(!env.isTerminal()&&performance.now()-before<177000){
  const at=env.createCheckpoint().coreState.compositionEnvelope;
  try{
   const x=env.runAgentDecision();
   inputs.push({action:x.agentTrace?.actionId,policy:x.policyDecision,n:x.searches?.[0]?.diagnostics.nativeExecutions||0,ms:x.searches?.[0]?.rootAndSearchMilliseconds||0});
  }catch(e){
   const q=e.cause?.search||e.search;
   failure={message:e.message,n:q?.diagnostics.nativeExecutions,ms:q?.rootAndSearchMilliseconds,choice:q?.actionId,q};
   assert.deepEqual(env.createCheckpoint().coreState.compositionEnvelope,at);
   break;
  }
 }
 const end=env.createCheckpoint(),state=JSON.parse(end.coreState.compositionEnvelope.committedState);
 const final=state.match.finalScores?.find(s=>s.playerId==='player-white'),summary={addedInputs:inputs.length,round:state.turn.roundNumber,turn:state.turn.turnNumber,
  terminal:env.isTerminal(),score:final?.totalScore,peak:[Math.max(0,...inputs.map(x=>x.n)),Math.max(0,...inputs.map(x=>x.ms))],
  failure:failure&&{...failure,q:undefined},elapsedMs:performance.now()-before};
 console.log(JSON.stringify(summary));
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({root:cp,end,inputs,summary,failure})),{flag:'wx'});
}finally{env.dispose();}
