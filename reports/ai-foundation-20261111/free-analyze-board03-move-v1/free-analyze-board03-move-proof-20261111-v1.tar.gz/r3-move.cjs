'use strict';
const assert=require('node:assert/strict');
function sub(s,a,b){assert.equal(s.split(a).length,2,a);return s.replace(a,b);}
exports.port=(s,witness)=>{
 const begin=s.indexOf('    function quietPaidMoveSource'),end=s.indexOf('    function rememberMoveMenu',begin);
 assert(begin>=0&&end>begin);
 let region=sub(s.slice(begin,end),'quietPaidMoveSource(stored,action){','quietPaidMoveSource(stored,action,allowQuietR3=false){');
 const start='      if(t.roundNumber!==4||t.currentPlayerId!==seatId||t.gameEnded||p.passCompletionPending';
 region=sub(region,start,`      const tasks=state.aliens.chong?.transportTasksByRocketId||{};
      // The same ordinary payment is quiet before either alien can reveal.
      const quietThirdRound=allowQuietR3&&isUnrevealedRoundThree(state)&&!Object.keys(tasks).length;
      if((t.roundNumber!==4&&!quietThirdRound)||t.currentPlayerId!==seatId||t.gameEnded||p.passCompletionPending`);
 region=sub(region,'      const tasks=state.aliens.chong?.transportTasksByRocketId||{};\n      const stationaryCargo=', '      const stationaryCargo=');
 s=s.slice(0,begin)+region+s.slice(end);
 s=sub(s,'const source=quietPaidMoveSource(stored,origin);','const source=quietPaidMoveSource(stored,origin,true);');
 if(witness)for(const k of ['provedMovePayments']){
  const at='        '+k+'++;';
  s=sub(s,at,`        if(readIdentityState(stored.envelope).turn.roundNumber===3)
          globalThis.moveWitnesses.push({kind:"${k}",source:stored.envelope,target:nodes.get(child).envelope,action:requested});\n`+at);
 }
 return s;
};
