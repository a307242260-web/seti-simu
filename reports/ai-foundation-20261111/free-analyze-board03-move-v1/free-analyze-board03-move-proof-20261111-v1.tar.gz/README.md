# 第 3 盘移动付款复用
在源码 bdab196e7 的隔离目录中运行本目录 profile-open.cjs 和 admit-r3-move.cjs。两者需要以项目根为 cwd。
输入依次为 canary03-failed-root-20261111-v1.json.gz 和 canary03-profile-20261111-v1.json.gz，第二个参数均指定新的 gzip 输出路径。
在采用新源码后，用 resume-current.cjs 从 fixtures 中的失败存档严格续跑；第二个参数为新输出文件。
原根、图、原生输入明细、原生付款结果和续跑均已随档保存。续跑用于诊断，不替代新源码的正式起盘。
