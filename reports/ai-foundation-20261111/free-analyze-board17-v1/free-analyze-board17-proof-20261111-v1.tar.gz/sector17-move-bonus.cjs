'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),a=require('node:assert/strict'),[input]=process.argv.slice(2);
const f=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(f,module);mod.filename=f;mod.paths=Module._nodeModulePaths(path.dirname(f));
const target='      const { before, result } = executeCurrent(requested);';
const s=fs.readFileSync(f,'utf8');
mod._compile(s.replace(target,`      const ss=stored.envelope.session?.session,h=ss?.queue[0];
      const st=readIdentityState(stored.envelope),p=st.players.players.find(q=>q.id===seatId);
      const a=h?.payload?.action||requested,ship=st.pieces.rockets.find(x=>x.id===a.target?.rocketId);
      if(requested.family==="move"||h?.type==="probe_turn_move_payment"){
        const key=JSON.stringify([requested.family,a.phase,ship?.kind,ship?.playerId,Boolean(quietPaidMoveSource(stored,a,true)),
          cardEffects.hasMatchingTrigger(p,{type:"move_payment_requested",playerId:seatId,rocketId:a.target?.rocketId}),
          st.turn.cardTurnEventBonuses?.map(b=>[b.id,b.eventType,b.event,b.usedKeys?.length,b.claimedKeys?.length]),ss?.irreversibleBarrier?.code,ss?.undoFrames.length,stored.informationBarrier?.code,
          Object.values(st.aliens.chong?.transportTasksByRocketId||{}).length]);
        globalThis.shapes[key]=(globalThis.shapes[key]||0)+1;
      }
`+target),f);mod.loaded=true;require.cache[f]=mod;
const {open,readZ}=require('./controlled-r3'),{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const row=readZ(input).rows[0],m=open(row.root),seatId='player-white',p=mod.exports.createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
globalThis.shapes={};
try{
 const q=createSearchAgent({seatId,analysisPort:p}).decide({seatId,legalActions:m.menu()}).search;
 a.deepEqual(m.save(),row.root);console.log(q.diagnostics.nativeExecutions);
 for(const [k,n] of Object.entries(globalThis.shapes).sort((a,b)=>b[1]-a[1]).slice(0,28))console.log(n,k);
}finally{p.close();m.dispose();}
