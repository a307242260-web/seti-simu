'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),a=require('node:assert/strict'),[input]=process.argv.slice(2);
const f=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(f,module);mod.filename=f;mod.paths=Module._nodeModulePaths(path.dirname(f));
const target='      const { before, result } = executeCurrent(requested);';
const s=fs.readFileSync(f,'utf8');
mod._compile(s.replace(target,`      const ss=stored.envelope.session?.session,h=ss?.queue[0],x=h?.payload?.options;
      const st=readIdentityState(stored.envelope),p=st.players.players.find(q=>q.id===seatId);
      const a=h?.payload?.action||requested;
      if(["move","place_data","end_turn"].includes(requested.family)||h?.type==="probe_turn_move_payment"||h?.type==="science_domain_place_data"){
        const key=JSON.stringify([requested.family,h?.type,stored.resourceControl?.goal?.kind,stored.informationBarrier?.code,
          isUnrevealedRoundThree(st),quietEarlySameSeatHandover(st),a.payload.requiredMovePoints,st.turn.type1TriggerEvents?.length||0,
          p.reservedCards.some(c=>!knownCards(stored.envelope).has(c.id))]);
        globalThis.shapes[key]=(globalThis.shapes[key]||0)+1;
      }
`+target),f);mod.loaded=true;require.cache[f]=mod;
const {open,readZ}=require('./controlled-r3'),{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const row=readZ(input).rows[0],m=open(row.root),seatId='player-white',p=mod.exports.createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
globalThis.shapes={};
try{
 const q=createSearchAgent({seatId,analysisPort:p}).decide({seatId,legalActions:m.menu()}).search;
 a.deepEqual(m.save(),row.root);console.log(q.diagnostics.nativeExecutions);
 for(const [k,n] of Object.entries(globalThis.shapes).sort((a,b)=>b[1]-a[1]).slice(0,28))console.log(n,k);
}finally{p.close();m.dispose();}
