'use strict';
const assert=require('node:assert/strict');
function sub(s,a,b){assert.equal(s.split(a).length,2,a);return s.replace(a,b);}
module.exports=(s,witness)=>{
 s=sub(s,'const moveSource=node.status==="stable"&&quietPaidMoveSource(stored,requested);',
 'const moveSource=node.status==="stable"&&quietPaidMoveSource(stored,requested,true);');
 if(witness)s=sub(s,'        provedMoveMenus++;',`        if(readIdentityState(stored.envelope).turn.roundNumber===3)
          globalThis.dataProof.push({kind:"move-menu",source:stored.envelope,target:moveMenu.envelope,action:requested,raw:moveMenu.inspection.session.decision.choices});
        provedMoveMenus++;`);
 return s;
};
