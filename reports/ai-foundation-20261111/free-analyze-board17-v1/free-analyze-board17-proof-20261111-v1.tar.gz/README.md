# 第 17 盘：只观察信号事件的回合奖励
在旧源码 f5d861d53 根目录执行本目录 admit-r3-signal-bonus.cjs，输入 sector17-profile 的 gzip，第二参数指定新的 gzip 输出。脚本在内存中叠加两个补丁，并逐笔独立提交原生输入。
在完整新源码中，resume-current.cjs 接受 fixtures 内的失败存档，第二参数为新 gzip 输出。跨版本结果是诊断，不能纳入正式二十盘均分。
