'use strict';
const assert=require('node:assert/strict');
function sub(s,a,b){assert.equal(s.split(a).length,2,a);return s.replace(a,b);}
module.exports=(s,witness)=>{
 const a=s.indexOf('    function quietPaidMoveSource'),b=s.indexOf('    function refillQuietScan4',a);
 assert(a>=0&&b>a);
 let region=s.slice(a,b);
 const helper=`    function quietSignalBonusesOnly(state){
      return state.turn.roundNumber===3&&(state.turn.cardTurnEventBonuses||[]).every(bonus=>
        bonus.eventType==="signalMarked"&&["b28-yellow-signal-bonus","b132-blue-signal-score"].includes(bonus.id));
    }

`;
 region=sub(region,'||t.cardTurnEventBonuses?.length||t.type1TriggerEvents?.length',
 '||t.cardTurnEventBonuses?.length&&!quietSignalBonusesOnly(state)||t.type1TriggerEvents?.length');
 region=sub(region,'||moved.events.some(event=>cardEffects.collectMatchingTriggers(player,event).length)',
 '||moved.events.some(event=>event.type==="signalMarked"||cardEffects.collectMatchingTriggers(player,event).length)');
 s=s.slice(0,a)+helper+region+s.slice(b);
 for(const name of ['quietDataMenuSource','previewQuietFinalDataPlacement']){
  const x=s.indexOf('    function '+name),y=s.indexOf('    function ',x+16);
  assert(x>=0&&y>x);const z=sub(s.slice(x,y),'|| t.cardTurnEventBonuses?.length','|| t.cardTurnEventBonuses?.length&&!quietSignalBonusesOnly(state)');
  s=s.slice(0,x)+z+s.slice(y);
 }
 if(witness){
  for(const [kind,at,target,raw] of [
   ['move-payment','        provedMovePayments++;','nodes.get(child).envelope','undefined'],
   ['data-menu','        provedFinalDataMenuInputs++;','menuPreview','choices'],
   ['data-placement','        const child = finishProvedCommittedState(node, stored, requested, state);','nodes.get(child).envelope','undefined'],
  ])s=sub(s,at,`        if(readIdentityState(stored.envelope).turn.roundNumber===3${kind==='data-placement'?'&&false':''})
          globalThis.dataProof.push({kind:"${kind}",source:stored.envelope,target:${target},action:requested,raw:${raw}});\n`+at);
  const wrong='        if(readIdentityState(stored.envelope).turn.roundNumber===3&&false)\n          globalThis.dataProof.push({kind:"data-placement",source:stored.envelope,target:nodes.get(child).envelope,action:requested,raw:undefined});\n';
  s=sub(s,wrong+'        const child = finishProvedCommittedState(node, stored, requested, state);',
    '        const child = finishProvedCommittedState(node, stored, requested, state);\n'+wrong.replace('&&false','').trimEnd());
 }
 return s;
};
