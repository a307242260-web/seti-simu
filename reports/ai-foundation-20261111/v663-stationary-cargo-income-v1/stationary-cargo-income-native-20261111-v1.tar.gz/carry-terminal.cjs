'use strict';
const assert=require('node:assert/strict'),{readZ,open,short,writeZ}=require('./controlled-r3');
const [src,b32,out]=process.argv.slice(2),d=readZ(src),b=readZ(b32),rows=[];
const roots=[
 ['income / B111',d.cases[1].r4.end.env,null,d.cases[1].r4.inputs],
 ['blue / B32',b[0].end,b[0].cp,b[0].steps],
 ['income / B32',b[1].end,b[1].cp,b[1].steps],
];
for(const [label,root,checkpoint,prefix] of roots){
 const m=open(root),actions=[];let stop,cp=checkpoint;
 try{
  for(let i=0;i<160;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0]?.actorId!=='player-white'){const a=[];m.advanceOpponents(a);actions.push(...a.map(a=>({a,passive:true})));continue;}
   const q=m.automatic(cp);if(!q.complete||!q.a||q.n>256||q.ms>600){stop={kind:'gate',n:q.n,ms:q.ms,a:q.a?.summary,round:m.facts().round,turn:m.facts().turn};break;}
   cp=q.checkpoint;actions.push({a:m.apply(q.a),n:q.n,ms:q.ms,value:q.value});
  }
  assert(stop);const end=m.save(),summary=short(m);
  const terminal=stop==='terminal'?m.state().match.finalScores.find(x=>x.playerId==='player-white'):null;
  m.restore(root);for(const {a} of actions)m.apply(a);assert.deepEqual(m.save(),end);
  const peak=[Math.max(0,...actions.map(x=>x.n||0)),Math.max(0,...actions.map(x=>x.ms||0))];
  console.log(JSON.stringify([label,stop,terminal,summary.wallet,summary.hand,peak,actions.filter(x=>x.a.phase==='main').map(x=>x.a.summary)]));
  rows.push({label,root,prefix,actions,end,summary,stop,terminal,peak});
 }finally{m.dispose();}
}
writeZ(out,rows);
