'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const original=Module._extensions['.js'],target=path.resolve('randomizer/game/ai/analysis-port.js');
Module._extensions['.js']=function(mod,file){
 if(file!==target)return original(mod,file);
 let s=fs.readFileSync(file,'utf8');
 if(process.env.SETI_CARGO_BASE_PORT)s=fs.readFileSync(process.env.SETI_CARGO_BASE_PORT,'utf8');
 else for(const [marker,label] of [['        provedPublicScanChoices++;','scan'],['        provedBluePickSettlements++;','blue']]){
  assert(s.split(marker).length===2);
  s=s.replace(marker,marker+`
        if(globalThis.setiCargoProof&&knownStationaryCargoForScan(taskSession.workingState))
          globalThis.setiCargoProof.push({kind:"${label}",before:stored.envelope,action:requested,after:nodes.get(child).envelope,
            status:child.status,menu:child.legalActions,observation:child.observation});`);
 }
 mod._compile(s,file);
};
const {open,readZ,writeZ}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),bench=readZ(src),rows=[];
for(const b of bench){
 const m=open(b.root);
 try{
  globalThis.setiCargoProof=[];const q=m.automatic();const proofs=globalThis.setiCargoProof;globalThis.setiCargoProof=null;
  const compareMenu=(a,b)=>assert.deepEqual(a.map(x=>[x.actionId,x.target]),b.map(x=>[x.actionId,x.target]));
  for(const x of proofs){
   const before=x.before, restored=m.c.lifecycle.restore(before);assert(restored.ok,JSON.stringify(restored));
   m.apply(x.action);
   const after=m.save();
   assert.deepEqual(JSON.parse(after.committedState),JSON.parse(x.after.committedState));
   // Search doesn't offer undo actions. UI-only undo frames must not leak
   // into the canonical analysis session or affect any playable successor.
   const analysisSession=e=>e?.session?{...e,session:{...e.session,undoFrames:[]}}:e;
   assert.deepEqual(analysisSession(after.session),x.after.session);
   if(x.status==='decision')compareMenu(m.menu(),x.menu);
   else if(['information-barrier','stable'].includes(x.status)){
    const legal=new Set(m.menu().map(a=>a.actionId));assert(x.menu.every(a=>legal.has(a.actionId)));
    assert.deepEqual(after.session,null);
   }else throw Error(x.status);
  }
  console.log(JSON.stringify([b.label,q.a?.actionId,q.value,q.n,q.ms,proofs.length]));
  rows.push({label:b.label,n:q.n,ms:q.ms,complete:q.complete,action:q.a?.actionId,value:q.value,roots:q.roots,proofs});
 }finally{m.dispose();}
}
writeZ(out,rows);
