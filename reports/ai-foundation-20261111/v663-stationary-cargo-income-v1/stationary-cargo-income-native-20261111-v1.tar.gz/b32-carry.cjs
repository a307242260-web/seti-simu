'use strict';
const assert=require('node:assert/strict'),{readZ,open,short,writeZ}=require('./controlled-r3');
const [file,newFile,out]=process.argv.slice(2),d=readZ(file),n=readZ(newFile),white='player-white';
const income='no-buy / A5 pays / DLC14 income',v=n[income].rows[0],expected=d.cases.find(x=>x.label===income);
assert.deepEqual(v.settled.state,expected.r3.env);assert.deepEqual(v.end,expected.r4.start.env);
const cases=[['blue / B32',d.cases.find(x=>x.label==='current').r3.env],['income / B32',v.settled.state]],rows=[];
for(const [label,origin] of cases){
 const m=open(origin),prefix=[],steps=[],turns=[];let cp,stop,ended=false;
 const passive=arr=>{if(m.menu()[0]?.actorId===white)return;const a=[];m.advanceOpponents(a);arr.push(...a.map(a=>({a,passive:true})));};
 try{
  prefix.push({a:m.act('pass')},{a:m.act('choose_card',a=>a.target.cardId==='b_32.webp')});passive(prefix);
  const start=m.save();
  for(let i=0;i<120;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   passive(steps);
   if(ended&&!m.save().session){turns.push({state:m.save(),summary:short(m),cp});ended=false;if(turns.length===3){stop='three-turns';break;}}
   const q=m.automatic(cp);
   if(!q.complete||!q.a||q.n>256||q.ms>600){stop={type:'gate',n:q.n,ms:q.ms,a:q.a?.summary,round:m.facts().round,turn:m.facts().turn};break;}
   cp=q.checkpoint;steps.push({a:m.apply(q.a),n:q.n,ms:q.ms,value:q.value});ended=q.a.family==='end_turn';
  }
  assert(stop);const end=m.save(),summary=short(m);
  m.restore(origin);for(const {a} of [...prefix,...steps])m.apply(a);assert.deepEqual(m.save(),end);
  const peak=[Math.max(0,...steps.map(x=>x.n||0)),Math.max(0,...steps.map(x=>x.ms||0))];
  rows.push({label,origin,prefix,start,steps,turns,end,summary,cp,stop,peak});
  console.log(JSON.stringify([label,stop,turns.map(x=>[x.summary.wallet,x.summary.established,x.summary.income,x.summary.probes,x.summary.hand]),peak]));
 }finally{m.dispose();}
}
writeZ(out,rows);
