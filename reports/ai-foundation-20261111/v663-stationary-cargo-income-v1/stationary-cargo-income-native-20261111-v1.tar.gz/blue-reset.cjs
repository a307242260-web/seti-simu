'use strict';
const {runCases,readZ,writeZ}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),root=d.root,cases=[];
const play=(h,id)=>h.take(h.m.play(id));
function white(h){h.act('end_turn');const a=[];h.m.advanceOpponents(a);h.take(...a);}
function place(h,t='computer'){h.act('place_data');h.act('choose_target',a=>t==='computer'?a.target.target==='computer':a.target.target==='blueBonus'&&a.target.blueSlot===t);}
for(const symbol of ['orange_1','orange_2']){
 for(const after of ['analysis','purple1','income-A1','income-A7']){
 cases.push([symbol+' / A3 reset blue / '+after,h=>{
  play(h,'amiba_9.webp');h.act('choose_target',a=>a.target.slotId===symbol);white(h);
  play(h,'amiba_3.webp');h.act('choose_target',a=>a.target.traceType==='blue'&&a.target.position===1);
  while(h.m.facts().computer.length<6)place(h);white(h);
  h.act('analyze');h.act('choose_target',a=>a.target.alienSlotId===1&&a.target.position===4);h.act('choose_card',a=>a.target.source==='display');
  for(let j=0;j<5&&h.m.c.inspect().session;j++)h.act('accept_optional_effect',a=>a.target.choiceId.startsWith('confirm:'));
  h.cut('analysis');if(after==='analysis')return;
  white(h);h.act('research_tech');h.act('choose_target',a=>a.target.tileId==='purple1');h.cut('purple1');
  if(after==='purple1')return;
  for(let i=0;i<4;i++)place(h);
  const card=h.m.player().hand.find(c=>c.cardId===(after==='income-A1'?'amiba_1.webp':'amiba_7.webp'));
  h.act('choose_card',a=>a.target.cardInstanceId===card?.id);h.cut('income');
 }]);
 }
}
writeZ(out,{root,...runCases(root,cases)});
