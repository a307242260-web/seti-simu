'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{readZ,open,short,runCases,writeZ}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const [src,out]=process.argv.slice(2),d=readZ(src),outcomes={};
for(const row of [d.cases.find(x=>x.label==='no-buy / A5 pays / DLC14 income'),d.cases.find(x=>x.label==='buy dlc_15.png / income dlc_14.png / keep amiba_5.webp'),d.cases.find(x=>x.label==='buy dlc_17.png / income dlc_14.png / keep amiba_5.webp')]){
 const m=open(d.source),prefix=[];
 try{
  for(const a of row.prefix){if(a.family==='card_corner')break;prefix.push(m.apply(a));}
  const start=m.save(),port=createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});
  port.setMovementPlanning(true);port.setResourcePlanning(true);port.setCardPickPlanning(true);
  let spec;try{spec=port.resourceSpec(port.openRoot());}finally{port.close();}
  const q=m.automatic();
  console.log(JSON.stringify([row.label,q.a?.summary,q.value,q.n,q.ms,spec.sharedDataFunding,spec.plans.map(p=>p.goal.kind)]));
  const result=runCases(start,[['cold autonomous from ready fourth income',()=>{}]]);
  outcomes[row.label]={start,prefix,spec,q,...result};
 }finally{m.dispose();}
}
writeZ(out,outcomes);
