'use strict';
const {open,readZ,writeZ,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),origin=d.root,cases=[];
function white(h){h.act('end_turn');const a=[];h.m.advanceOpponents(a);h.take(...a);}
function place(h){h.act('place_data');h.act('choose_target',a=>a.target.target==='computer');}
for(const reward of ['orange_1','orange_2'])for(const after of ['purple1','orange1']){
 cases.push([reward+' / '+after+' before analysis',h=>{
  h.take(h.m.play('amiba_9.webp'));h.act('choose_target',a=>a.target.slotId===reward);white(h);
  h.act('research_tech');h.act('choose_target',a=>a.target.tileId===after);h.cut('early-tech');
  if(h.m.c.inspect().session)throw Error('inspect tech reward');
  if(after==='orange1')return;
  while(h.m.facts().computer.length<6)place(h);white(h);
  h.act('analyze');h.act('choose_target',a=>a.target.position===4&&a.target.alienSlotId===1);
  h.act('choose_card',a=>a.target.source==='display');
  for(let j=0;j<5&&h.m.c.inspect().session;j++)h.act('accept_optional_effect',a=>a.target.choiceId.startsWith('confirm:'));
  h.cut('first-analysis');
 }]);
}
writeZ(out,{origin,...runCases(origin,cases)});
