'use strict';
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src),root=d.rows.find(r=>r.i===179).before;
function white(h){h.act('end_turn');const a=[];h.m.advanceOpponents(a);h.take(...a);}
function place(h){h.act('place_data');h.act('choose_target',a=>a.target.target==='computer');}
const cases=[];
for(const symbol of ['orange_1','orange_2']){
 cases.push([symbol+' / A9 then autonomous',h=>{h.take(h.m.play('amiba_9.webp'));h.act('choose_target',a=>a.target.slotId===symbol);h.cut('A9');}]);
 cases.push([symbol+' / A9,A3,analysis then autonomous',h=>{
 h.take(h.m.play('amiba_9.webp'));h.act('choose_target',a=>a.target.slotId===symbol);h.cut('A9');white(h);
 h.take(h.m.play('amiba_3.webp'));h.act('choose_target',a=>a.target.traceType==='yellow'&&a.target.position===1);h.cut('A3');
 if(h.m.c.inspect().session)throw Error('inspect pending menu');
 while(h.m.facts().computer.length<6)place(h);white(h);
 h.act('analyze');h.act('choose_target',a=>a.target.alienSlotId===1&&a.target.position===4);
 if(h.m.c.inspect().session)h.act('choose_card',a=>a.target.source==='display');h.cut('first-analysis');
 }]);
}
writeZ(out,{root,...runCases(root,cases)});
