'use strict';
const {readZ,open,writeZ}=require('./controlled-r3'),assert=require('node:assert/strict'),path=require('node:path');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port')),{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [src,b32,out]=process.argv.slice(2),d=readZ(src),a=readZ(b32),rows=[];
for(const [label,root] of [['B111 second',d.cases[1].r4.end.env],['B32 second',a[1].end],['B111 first',d.cases[1].r4.start.env],['B32 first',a[1].start],['B32 old R4 start',a[0].start]]){
 const m=open(root),port=createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});
 try{
  const actions=m.menu(),q=createSearchAgent({seatId:'player-white',analysisPort:port}).decide({seatId:'player-white',legalActions:actions}).search,stats=port.getDiagnostics();
  assert.deepEqual(m.save(),root);
  rows.push({label,root,search:q,stats});
  console.log(JSON.stringify([label,actions.find(x=>x.actionId===q.actionId)?.summary,q.value,q.complete,q.diagnostics.nativeExecutions,q.rootAndSearchMilliseconds,stats.provedPublicScanChoices,stats.provedScan4QuietMoves,stats.provedBluePickSettlements]));
 }finally{port.close();m.dispose();}
}
writeZ(out,rows);
