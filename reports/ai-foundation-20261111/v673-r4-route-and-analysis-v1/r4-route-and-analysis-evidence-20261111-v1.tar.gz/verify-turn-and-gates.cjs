'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ}=require('./controlled-r3');
const [retention,old,turns,proofDir,out]=process.argv.slice(2),first=readZ(retention),second=readZ(turns),base=readZ(old).results.filter(r=>r.name==='A5-first/4分/swap-B16'),proof=readZ(proofDir+'/proof-route.json.gz');
const answers=[];
for(let i=0;i<first.length;i++){
 const a=first[i],record=base[i],slow=proof[i];
 const [ret,ins]=second.filter(x=>x.card===a.card);
 assert.equal(ret.kind,'retain');assert.equal(ins.kind,'insert');
 assert.deepEqual(ret.root,a.after);assert.deepEqual(ins.root,a.baseAfter);
 const cold=readZ(proofDir+'/fixed-menu-'+a.card+'.json.gz')[0];
 assert.deepEqual(cold.root,slow.root);
 for(const k of ['actionId','value','realization','preparationDebt','complete','roots','lines','unresolved','selectionPlan','candidates','sharedPrefixGraph'])
   assert.deepEqual(cold.q[k],slow.q[k],k);
 assert.deepEqual(cold.cp.plan.rows,slow.cp.plan.rows);
 assert.equal(slow.proof.length,24);
 const m=open(ins.root),r=open(ret.root);
 try{
  const from=m.facts().turn;
  const replay=[];
  for(const {action} of record.actions.slice(a.recorded.length)){
   if(m.facts().turn!==from&&!m.save().session)break;
   replay.push(m.apply(action));
  }
  assert.deepEqual(m.save(),ins.end);
  assert.deepEqual(replay.map(x=>x.actionId),ins.sequence.map(x=>x.action.actionId));
  assert.equal(ret.stop,'next-turn');
  ret.sequence.forEach(({action,n,ms})=>{assert(n<=256&&ms<=600);r.apply(action);});
  assert.deepEqual(r.save(),ret.end);
  assert.equal(r.facts().wallet.score,143);
  assert.equal(m.facts().wallet.score,143);
  for(const k of ['tech','income','traces','wins','rng','final'])assert.deepEqual(m.facts()[k],r.facts()[k],k);
  assert.equal(m.facts().wallet.credits-r.facts().wallet.credits,2);
  const row={card:a.card,retainedReplay:ret.sequence.length,insertReplay:replay.length,
   inputs:cold.q.diagnostics.nativeExecutions,ms:cold.q.rootAndSearchMilliseconds,score:143,value:cold.q.value};
  answers.push(row);console.log(JSON.stringify(row));
 }finally{m.dispose();r.dispose();}
}
writeZ(out,answers);
