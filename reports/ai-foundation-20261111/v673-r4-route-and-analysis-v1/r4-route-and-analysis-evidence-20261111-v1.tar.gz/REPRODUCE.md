从 Production cbd73e00c98455dac868bd43be3e1759130088a7 的隔离快照根目录运行。A 是解包的绝对目录。输出文件事先不能存在。

    OPT=bound-move-join-route-yellow-copy-income-skip-restore-copy-scan-fixed-cash-route-reuse-composition-copy-runtime-copy-move-menu-mission-memo
    SETI_SCAN_PRIOR="$A/prior.cjs" node "$A/prove-route.cjs" "$OPT" "$A/proof-cash.json.gz" "$A/proof-route.json.gz"
    node "$A/verify-turn-and-gates.cjs" "$A/first-turn.json.gz" "$A/prior-fourth.json.gz" "$A/second-turn.json.gz" "$A" "$A/replayed-verified.json.gz"

第一条重建 48 个逐输入的原生移动对照。第二条对比含固定菜单优化的完整搜索图和证书，并用已有先插电记录复放两条第二回合。两种留牌也从确切存档独立复放到第二回合结束。独立冷测命令如下；对 B32 更换盘面和输出名。毫秒不要求逐次相同。

    SETI_SCAN_PRIOR="$A/prior.cjs" node "$A/cold-root.cjs" "$OPT-fixed-menu" "$A/root-b_111.webp.gz" "$A/replayed-b111-cold.json.gz"

所有候选在临时进程中加载；没有写入正式策略，也没有执行超限首步的自主决定。
