'use strict';
const assert=require('node:assert/strict');
module.exports=(s,notify=false)=>{
 function sub(a,b){assert.equal(s.split(a).length,2,a);s=s.replace(a,b);}
 sub('if(!resourcePlanning||!movementPlanning||stored.resourceControl\n        ||barrier&&!["hidden_card_reveal","tech_bonus_reveal"].includes(barrier.code)',
  'if(!resourcePlanning||!movementPlanning||stored.resourceControl&&stored.resourceControl.goal.kind!=="route"\n        ||barrier&&!["hidden_card_reveal","tech_bonus_reveal"].includes(barrier.code)');
 sub('      const moveSource=node.status==="stable"&&quietPaidMoveSource(stored,requested);',`      const moveSource=node.status==="stable"&&quietPaidMoveSource(stored,requested);
      const moveControl=()=>stored.resourceControl&&resourceStep(node,stored.resourceControl.goal,stored.resourceControl.operation).kind!=="complete"
        ?stored.resourceControl:null;`);
 sub('        const child=finishChild({session:null},{},nextMovementIntent(node,requested),null,stored.informationBarrier,requested,stored,moveMenu);\n        provedMoveMenus++;',
  `        const child=finishChild({session:null},{},nextMovementIntent(node,requested),moveControl(),stored.informationBarrier,requested,stored,moveMenu);
        provedMoveMenus++;
        ${notify?'if(stored.resourceControl)globalThis.captureRoute("menu",stored,requested,nodes.get(child),child,moveMenu.inspection.session.decision.choices);':''}`);
 sub('        const child=finishChild({session:null},{},nextMovementIntent(node,requested),null,stored.informationBarrier,requested,stored,\n          {envelope,inspection:{phase:"idle",session:null}});\n        provedMovePayments++;',
  `        const child=finishChild({session:null},{},nextMovementIntent(node,requested),moveControl(),stored.informationBarrier,requested,stored,
          {envelope,inspection:{phase:"idle",session:null}});
        provedMovePayments++;
        ${notify?'if(stored.resourceControl)globalThis.captureRoute("payment",stored,requested,nodes.get(child),child);':''}`);
 return s;
};
