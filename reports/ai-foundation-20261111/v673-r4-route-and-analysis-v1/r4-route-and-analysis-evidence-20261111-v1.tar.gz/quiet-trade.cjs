'use strict';
const assert=require('node:assert/strict');
module.exports=(source,notify=false)=>{
 const anchor='      const resourceCorner=resourcePlanning&&node.status==="stable"&&!stored.resourceControl';
 assert.equal(source.split(anchor).length,2);
 return source.replace(anchor,`      if(resourcePlanning&&node.status==="stable"&&!stored.resourceControl&&!stored.envelope.session
        &&requested.family==="quick_trade"&&requested.target?.tradeId==="credits-for-energy"){
        const state=readIdentityState(stored.envelope),t=state.turn,p=state.players.players.find(q=>q.id===seatId);
        const trade=quickTrades.getTradeAction(requested.target.tradeId);
        if(t.roundNumber===4&&t.currentPlayerId===seatId&&!t.gameEnded&&!p.passCompletionPending
          &&!t.passedPlayerIds.includes(seatId)&&!state.match.initialSetup&&!t.cardTurnEventBonuses?.length
          &&!localPlans.hasPendingFossilArrival(state)&&p.reservedCards.every(c=>knownCards(stored.envelope).has(c.id))
          &&trade.cost.credits===2&&trade.gain.energy===1&&!trade.moveStep
          &&Object.keys(trade.cost).length===1&&Object.keys(trade.gain).length===1){
          const player={...p,resources:{...p.resources},reservedCards:copyForkData(p.reservedCards)};
          const next={...state,players:{...state.players,players:state.players.players.map(q=>q===p?player:q)},
            meta:quietSavedMeta(state.meta,state.meta.stateVersion+1),
            match:{...state.match,decisionVersion:(Number(state.match.decisionVersion)||0)+1}};
          const result=quickTrades.executeTrade(trade.id,{players:next.players,turn:t});
          if(!result.ok)throw Error("ANALYSIS_FIXED_TRADE_STALE");
          const event={type:"quick_trade",tradeId:trade.id,playerId:seatId,executorId:"seti-production-domain-pack-v1:quick_trade:executor"};
          const augmented=residualSession.augmentEffectResult(next,{ok:true,events:[event]},null);
          if(!augmented.spawnedEffects.length&&augmented.events.length===1){
            const child=finishProvedCommittedState(node,stored,requested,next);
            ${notify?'globalThis.captureTrade(stored,requested,nodes.get(child),child);':''}
            return rememberPrefix(key,node,actionId,remember(key,child));
          }
        }
      }
`+anchor);
};
