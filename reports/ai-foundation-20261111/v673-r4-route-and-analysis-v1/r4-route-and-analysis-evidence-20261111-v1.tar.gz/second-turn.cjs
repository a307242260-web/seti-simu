'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [input,out]=process.argv.slice(2),results=[];
for(const row of readZ(input))for(const kind of ['retain','insert']){
 const root=kind==='retain'?row.after:row.baseAfter,m=open(root),turn=m.facts().turn,sequence=[];
 let cp=null,stop;
 try{
  for(let i=0;i<60;i++){
   const facts=m.facts(),current=m.menu();
   if(facts.turn!==turn&&!m.save().session){stop='next-turn';break;}
   if(current[0].actorId!=='player-white'){
    const seen=[];m.advanceOpponents(seen);sequence.push(...seen.map(action=>({action,passive:true})));continue;
   }
   const q=m.automatic(cp);
   if(!q.complete||q.n>256||q.ms>600){stop={kind:'gate',n:q.n,ms:q.ms};break;}
   cp=q.checkpoint;sequence.push({action:m.apply(q.a),n:q.n,ms:q.ms,v:q.value});
  }
  assert(stop);
  const end=m.save(),assets=short(m),f=m.facts(),before=short(openTemporarily(root));
  m.restore(root);sequence.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),end);
  console.log(JSON.stringify({card:row.card,kind,stop,before,assets,main:sequence.find(a=>a.action.phase==='main')?.action.summary,
   values:sequence.map(a=>[a.action.summary,a.v]),peak:[Math.max(...sequence.map(a=>a.n||0)),Math.max(...sequence.map(a=>a.ms||0))]}));
  results.push({card:row.card,kind,stop,root,end,sequence,before,assets,f});
 }finally{m.dispose();}
}
function openTemporarily(root){
 // Compute root facts in a scoped instance; the helper object cannot mutate.
 const m=open(root);
 try{const f=m.facts(),obs=m.owner('player-white');return {facts:()=>f,owner:()=>obs};}finally{m.dispose();}
}
writeZ(out,results);
