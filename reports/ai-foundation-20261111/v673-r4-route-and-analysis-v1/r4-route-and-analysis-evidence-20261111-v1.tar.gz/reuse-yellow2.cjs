'use strict';
const assert=require('node:assert/strict');
module.exports=function(s,notify=false){
 function sub(a,b){assert.equal(s.split(a).length,2,a);s=s.replace(a,b);}
 const anchor='    function previewQuietSpecifiedScan(node,stored,action){';
 sub(anchor,`    function previewQuietYellowLanding(node,stored,action){
      if(!resourcePlanning||node.status!=="decision"||action.family!=="choose_target"||action.target?.traceType!=="yellow"
        ||stored.resourceControl||stored.informationBarrier)return null;
      const s=stored.envelope.session?.session,head=s?.queue[0],base=s?.workingState,turn=base?.turn;
      if(s?.phase!=="awaiting_input"||s.failure||s.interruptContext||s.undoFrames.length||s.irreversibleBarrier
        ||s.queue.length!==1||head.type!==scienceSession.EFFECT_TYPES.ALIEN_TRACE||head.kind!=="decision"
        ||head.ownerId!==seatId||head.allowQuickActions||head.payload?.traceType!=="yellow"
        ||!Object.keys(head.payload).every(k=>k==="traceType"||k==="label")
        ||s.journal.actions[0]?.action?.family!=="land"||base.meta.stateVersion!==s.baseVersion
        ||turn.roundNumber!==4||turn.currentPlayerId!==seatId||turn.gameEnded||turn.cardTurnEventBonuses?.length
        ||localPlans.hasPendingFossilArrival(base))return null;
      const p=base.players.players.find(a=>a.id===seatId),known=knownCards(stored.envelope);
      const target=action.target,slot=base.aliens.aliens[String(target.alienSlotId)];
      const plain=!slot?.revealed&&slot?.traces.yellow.firstPlaced
        &&target.choiceId===\`trace:\${target.alienSlotId}:yellow\`&&!target.speciesId&&!target.position;
      if(!p?.mainActionCompleted||p.passCompletionPending||turn.passedPlayerIds.includes(seatId)
        ||p.reservedCards.some(c=>!known.has(c.id))
        ||!plain&&!scienceSession.isPlainPinkTrace(base,action,true,true,"yellow"))return null;
      const player={...p,resources:{...p.resources},scoreSources:{...p.scoreSources},reservedCards:copyForkData(p.reservedCards)};
      const state={...base,meta:{...base.meta,sequences:{...base.meta.sequences}},aliens:copyForkData(base.aliens),
        players:{...base.players,players:base.players.players.map(a=>a===p?player:a)}};
      let placed;
      if(plain){
        const mark=aliens.placeTraceForActor(players,state.aliens,player,target.alienSlotId,"yellow");
        if(!mark?.ok||mark.reward)return null;
        placed={ok:true,events:[{type:"alienTrace",playerId:seatId,traceType:"yellow",alienSlotId:target.alienSlotId,region:null}]};
      }else placed=scienceSession.applyPlainPinkTrace(state,head,action,true,true,"yellow");
      if(!placed?.ok)return null;
      const spawned=[placed.cardEffect,placed.regionEffect].filter(Boolean).map(effect=>({effect,priority:"direct"}));
      const augmented=residualSession.augmentEffectResult(state,{...placed,spawnedEffects:spawned},head);
      if(augmented.events.length!==1||augmented.spawnedEffects.length>spawned.length+1)return null;
      const checkpoint=stored.envelope.session,j=s.journal,scratch={...s},events=[...augmented.events],history=[];
      const queue=effectSession.normalizeSpawnedEffects(augmented.spawnedEffects,scratch,head);
      let revision=s.revision+1;
      const effects=[{effectId:head.effectId,groupId:head.groupId,groupKind:head.groupKind,type:head.type,revision}];
      if(queue[0]?.kind==="effect"){
        if(queue[0].type!==placed.regionEffect?.type)return null;
        const region=queue.shift(),result=residualSession.previewQuietAmibaRegion(state,region);
        if(!result)return null;
        events.push(...result.events);history.push(result.history);
        effects.push({effectId:region.effectId,groupId:region.groupId,groupKind:region.groupKind,type:region.type,revision:++revision});
      }
      if(queue.length){
        const pending=queue[0],species=placed.cardEffect?.payload.speciesId;
        if(pending.kind!=="decision"||pending.ownerId!==seatId||pending.allowQuickActions)return null;
        let choices;
        if(species&&pending.type===placed.cardEffect.type){
          const display=species==="amiba"?rootObservation.publicState.board.aliens.amibaTraces?.displayedCardIndex:
            species==="chong"?knownChongDisplayIndex:null;
          if(!Number.isSafeInteger(display)||state.aliens[species]?.displayedCardIndex!==display)return null;
          choices=residualSession.alienCardChoices(state,seatId,species);
        }else if(pending.type==="residual_card_decision"&&pending.payload.kind==="trigger")choices=localPlans.residualCardChoices(state,pending);
        if(!choices?.length)return null;
        const cursor=j.replay.length,decision={decisionId:head.effectId,decisionVersion:s.revision,ownerId:seatId,choice:action};
        const session=freeze({...checkpoint,replayCursor:cursor+1,session:{...scratch,workingState:state,queue,revision,
          journal:{...j,decisions:[...j.decisions,decision],effects:[...j.effects,...effects],events:[...j.events,...events],
            history:[...j.history,...history],replay:[...j.replay,{cursor,kind:"decision",confirmed:true,...decision}]}}});
        return {prepared:{envelope:withEnvelopeSession(stored.envelope,session),
          inspection:{phase:"awaiting_input",session:{irreversibleBarrier:null,decision:{choices}}}}};
      }
      state.meta.stateVersion=s.baseVersion+1;
      return {state,barrier:null};
    }

`+anchor);
 const check='      const fixedScan=previewQuietSpecifiedScan(node,stored,requested);';
 sub(check,`      const yellow=previewQuietYellowLanding(node,stored,requested);
      if(yellow){
        const child=yellow.prepared
          ?finishChild({session:{irreversibleBarrier:null}},{},nextMovementIntent(node,requested),null,null,requested,stored,yellow.prepared)
          :finishProvedCommittedState(node,stored,requested,yellow.state);
        ${notify?'globalThis.captureYellow(stored,requested,nodes.get(child),child,yellow.prepared);':''}
        return rememberPrefix(key,node,actionId,remember(key,child));
      }
`+check);
 return s;
};
