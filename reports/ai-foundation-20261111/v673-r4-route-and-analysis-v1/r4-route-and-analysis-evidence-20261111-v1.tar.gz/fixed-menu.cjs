'use strict';
const assert=require('node:assert/strict');
module.exports=(s)=>{
 function edit(a,b){assert.equal(s.split(a).length,2,a);s=s.replace(a,b);}
 edit('        const spec=cardPickSpec(current),tail=targetReached?localDecisionSpec(current):null;',
   '        const spec=current.status==="decision"?cardPickSpec(current):null,tail=targetReached?localDecisionSpec(current):null;');
 edit('        const spec=cardPickSpec(current)?.fixed?cardPickSpec(current):localDecisionSpec(current);',
   '        const pick=current.status==="decision"?cardPickSpec(current):null, spec=pick?.fixed?pick:localDecisionSpec(current);');
 edit('        const following=cardPickSpec(current)?.fixed?cardPickSpec(current):localDecisionSpec(current);',
   '        const nextPick=current.status==="decision"?cardPickSpec(current):null, following=nextPick?.fixed?nextPick:localDecisionSpec(current);');
 return s;
};
