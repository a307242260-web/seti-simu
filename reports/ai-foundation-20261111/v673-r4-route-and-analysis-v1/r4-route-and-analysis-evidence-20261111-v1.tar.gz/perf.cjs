'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
function edit(s,a,b){assert.equal(s.split(a).length,2,a);return s.replace(a,b);}
function load(name,transform){
 const f=path.resolve(name),m=new Module(f,module);
 m.filename=f;m.paths=Module._nodeModulePaths(path.dirname(f));
 m._compile(transform(fs.readFileSync(f,'utf8')),f);
 m.loaded=true;require.cache[f]=m;return m.exports;
}
function cheapData(source){
 return edit(source,' function dataPreviewPlayer(p){return{...p,resources:{...p.resources},income:{...p.income},hand:[...p.hand],dataState:structuredClone(p.dataState)};}',
 ` function dataPreviewPlayer(p){const dataState=p.dataState;return{...p,resources:{...p.resources},income:{...p.income},hand:[...p.hand],
   dataState:{...dataState,poolTokens:[...dataState.poolTokens],placedTokens:[...dataState.placedTokens]}};}`);
}
function cheapIncome(source){
 const a="  const p=owner(state,seatId),context={...state,players:state.players.players,aliens:structuredClone(state.aliens),finalScoring:structuredClone(state.finalScoring),cardEffects:effects,getCardTypeCode:c=>effects.getRuntimeCardTypeCode(c,effects.getCardModel(c)?.cardType)};\n  const delta=endScoring.computePlayerFinalScore(context,preview.player).totalScore-endScoring.computePlayerFinalScore(context,p).totalScore;";
 const b=`  const p=owner(state,seatId),copy=preview.player;
  let delta=provedDataScoreDelta(state,p,copy,true);
  if(delta===null){
   const context={...state,players:state.players.players,aliens:structuredClone(state.aliens),finalScoring:structuredClone(state.finalScoring),cardEffects:effects,getCardTypeCode:c=>effects.getRuntimeCardTypeCode(c,effects.getCardModel(c)?.cardType)};
   delta=endScoring.computePlayerFinalScore(context,copy).totalScore-endScoring.computePlayerFinalScore(context,p).totalScore;
  }`;
 source=edit(source,a,b);
 source=edit(source,' function provedDataScoreDelta(state,p,copy){',' function provedDataScoreDelta(state,p,copy,allowIncome=false){');
 return edit(source,"||['credits','energy','handSize'].some(k=>p.income[k]!==copy.income[k])",
 `||['credits','energy','handSize'].some(k=>p.income[k]!==copy.income[k])
      &&(!allowIncome||state.finalScoring?.tiles?.a?.marks?.some(m=>m.playerId===p.id))`);
}
exports.setup=mode=>{
 if(mode.includes('copy-data')||mode.includes('copy-income')){
  load('randomizer/game/ai/local-decision-plans.js',s=>{
   if(mode.includes('copy-data'))s=cheapData(s);
   if(mode.includes('copy-income'))s=cheapIncome(s);
   return s;
  });
 }
};
exports.port=(s,mode)=>{
 if(mode.includes('skip-restore'))
  s=edit(s,'      if(fixedScan){\n        restoreEnvelope(fixedScan.envelope);',
    '      if(fixedScan){\n        if(fixedScan.inspection.phase!=="awaiting_input")restoreEnvelope(fixedScan.envelope);');
 if(mode.includes('copy-scan')){
  const start=s.indexOf('    function previewQuietPublicScan('),end=s.indexOf('    function previewQuietScan4Action(',start);
  assert(start>0&&end>start);
  s=s.slice(0,start)+s.slice(start,end).replaceAll('structuredClone(', 'copyForkData(')+s.slice(end);
 }
 return s;
};
