# V673 early DLC25 electricity and third-round retention

Run from a clean Production checkout at cbd73e00c98455dac868bd43be3e1759130088a7.
Let p be the absolute path to the extracted archive. The archived audit contains
the native standard trace and exact source checkpoints. The official run is
reports/research/d3183131.cbd73e00.quick-400.json; the input ledger provenance is
also documented in docs/human405-v673-r3-symbol-causality-20261111.md.
The commands below read immutable archived inputs, and output to fresh filenames.

```sh
(cd "$p" && shasum -a 256 -c SHA256SUMS)
node "$p/verify-records.cjs" "$p"
node "$p/early.cjs" "$p" "$p/replay-early.json.gz"
node "$p/late.cjs" "$p" "$p/replay-late.json.gz"
node "$p/fourth.cjs" "$p" "$p/replay-fourth.json.gz"
node "$p/asset-variants.cjs" "$p" "$p/replay-asset-variants.json.gz"
node "$p/asset-fourth.cjs" "$p" "$p/replay-asset-fourth.json.gz"
node "$p/blue-first.cjs" "$p" "$p/replay-blue-first.json.gz"
node "$p/retain.cjs" "$p" "$p/replay-retain.json.gz"
node "$p/retain-fourth.cjs" "$p" "$p/replay-retain-fourth.json.gz"
for card in b_111.webp b_32.webp; do
  root="$p/$card"
  node "$p/base.cjs" "$p/fourth-20261111-v1.json.gz" "$root/replay-base.json.gz" "$card"
  node "$p/compare.cjs" comet-b9 "$root/base-20261111-v1.json.gz" "$root/replay-comparison.json.gz"
  node "$p/prove.cjs" "$root/base-20261111-v1.json.gz" "$root/replay-proof.json.gz"
  node "$p/resume.cjs" "$root" "$root/replay-resume.json.gz"
done
```

Suffix actions are resubmitted via the native input port and the resulting full
checkpoint is compared. The resume uses the recorded gate-admitted comparison
and independently verified search checkpoint. Time budgets are wall-clock
measurements; under a different load a run can stop earlier at the gate.
