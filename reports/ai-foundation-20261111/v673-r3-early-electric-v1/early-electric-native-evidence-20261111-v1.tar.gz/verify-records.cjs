'use strict';
const assert=require('node:assert/strict');
const {open,readZ,short}=require('./controlled-r3');
const d=process.argv[2],r=n=>readZ(d+'/'+n+'-20261111-v1.json.gz');
const audit=r('audit'),early=r('early'),late=r('late'),blue=r('blue-first'),assets=r('asset-variants');
let inputs=0,r3=0,r4=0,terminal=0,stopped=0;
function replay(root,actions,end){
 const m=open(root);
 try{
  for(const x of actions){
   const a=x.action||x;
   if(x.n!==undefined){assert(x.n<=256&&x.ms<=600);assert.equal(a.actorId,'player-white');}
   if(x.passive)assert.notEqual(a.actorId,'player-white');
   m.apply(a); inputs++;
  }
  assert.deepEqual(m.save(),end);
  return {round:m.facts().round,terminal:m.state().turn.gameEnded,score:m.state().match.finalScores?.find(p=>p.playerId==='player-white'),assets:short(m)};
 }finally{m.dispose();}
}
function third(group,root){
 for(const x of group.rows){
  replay(root,x.prefix,x.start);
  assert.equal(replay(x.start,x.actions,x.end).round,4);
  r3++;
 }
 for(const x of group.failures)replay(root,x.prefix,x.checkpoint);
}
const e=key=>early.rows.find(x=>x.label===key).start;
third(early,audit.roots[179]);
for(const [k,v] of Object.entries(late))third(v,e(k.slice(0,k.lastIndexOf('/'))));
for(const [k,v] of Object.entries(blue))third(v,e(k));
const main=late['publicity/slot/same-scan/dlc_20.png'].rows.find(x=>x.label.endsWith('/both'));
third(assets.cashAlt,main.checkpoints.analysis.state);
third(assets.keeps,main.checkpoints['extra-scan'].state);
for(const x of r('retain')){
 const y=replay(x.root,x.prefix,x.settled);
 assert.deepEqual(JSON.parse(JSON.stringify(y.assets)),x.assets);assert.equal(y.round,3);
}
for(const key of ['fourth','asset-fourth','retain-fourth','b_111.webp/resume','b_32.webp/resume']){
 const d=r(key);
 for(const x of d.results||[d]){
  const y=replay(x.root,x.actions||x.trace,x.end);
  assert.equal(y.terminal,x.stop==='terminal');
  if(y.terminal){assert.deepEqual(y.score,x.terminal);terminal++;}
  else {assert(x.stop.n>256||x.stop.ms>600);assert.equal(x.terminal,null);stopped++;}
  r4++;
 }
}
assert.deepEqual([r3,r4,terminal,stopped],[32,26,16,10]);
console.log(JSON.stringify({r3,r4,terminal,stopped,nativeReplayInputs:inputs}));
