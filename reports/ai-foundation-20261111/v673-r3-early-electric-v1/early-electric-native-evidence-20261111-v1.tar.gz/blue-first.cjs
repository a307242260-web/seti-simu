'use strict';
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),d=readZ(dir+'/early-20261111-v1.json.gz');
const a5='amiba_5.webp',a7='amiba_7.webp',a9='amiba_9.webp',b16='b_16.webp',d17='dlc_17.png';
const sel=(h,f,label)=>h.act(f,a=>a.summary===label),end=h=>h.act('end_turn');
const data=(h,label)=>{h.act('place_data');sel(h,'choose_target',label)};
const comp=(h,...nums)=>nums.forEach(i=>data(h,'第一排放置位 '+i));
const tech=(h,t)=>{h.act('research_tech');h.act('choose_target',a=>a.target.tileId===t&&(t!=='blue1'||a.target.blueSlot===3));};
const names=['publicity/buy/same-scan','publicity/slot+buy/same-scan','publicity/slot/same-scan'],result={};
for(const name of names){
 const root=d.rows.find(r=>r.label===name).start;
 const cases=['let decide after cash','add orange1','add orange1 and B16'].map(mode=>[name+'/'+mode,h=>{
  tech(h,'blue1');comp(h,5,6);data(h,'blue1 下方');
  if(h.m.facts().hand.some(x=>x[1]===a7))h.take(h.m.corner(a7));
  h.cut('cash1');end(h);
  h.take(h.m.play(a5));h.take(h.m.pick(d17));
  h.act('choose_target',a=>a.summary.includes('1数据'));end(h);
  h.act('analyze');h.act('choose_target',a=>a.target.speciesId==='amiba'&&a.target.traceType==='blue'&&a.target.position===3);
  h.act('choose_card',a=>a.summary.includes('科学论文'));h.cut('after-analysis');
  comp(h,1,2,3,4);sel(h,'choose_card','收入 '+d17);h.cut('cash2');end(h);
  if(mode==='let decide after cash')return;
  h.take(h.m.corner(a9));tech(h,'orange1');
  const choices=h.m.menu();const choice=choices.find(a=>a.summary==='dlc_20.png')||choices.find(a=>a.summary==='dlc_16.png')||choices.find(a=>a.family==='choose_card'&&a.target.source==='public');
  h.take(h.m.apply(choice));end(h);
  if(mode==='add orange1')return;
  h.take(h.m.play(b16));h.act('choose_target',a=>a.summary.endsWith('向外'));
  h.act('choose_target',a=>a.target.nebulaId==='sector-1-a');h.cut('third-scan');
 }]);
 result[name]=runCases(root,cases);
}
writeZ(out,result);
