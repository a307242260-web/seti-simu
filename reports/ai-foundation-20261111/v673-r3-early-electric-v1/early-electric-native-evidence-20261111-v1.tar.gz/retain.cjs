'use strict';
const assert=require('node:assert/strict');
const {open,readZ,writeZ,short}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2), rows=[], cases=[];
const file=n=>readZ(dir+'/'+n+'-20261111-v1.json.gz');
for(const x of Object.values(file('blue-first')).flatMap(v=>v.rows).filter(x=>x.checkpoints['third-scan'])){
 const id=x.label.includes('slot+buy')?'slot+buy':'buy';
 for(const storage of ['raw','computer','blue-energy'])
  cases.push({name:id+'/'+storage,root:x.checkpoints['third-scan'].state,storage,close:true});
}
const late=file('late')['publicity/slot/same-scan/dlc_20.png'].rows.find(x=>x.label.endsWith('/release'));
cases.push({name:'late cash/release Sirius',root:late.settled.state,storage:'none'});
for(const {name,root,storage,close} of cases){
 const m=open(root),prefix=[];
 try{
  if(storage==='computer'||storage==='blue-energy'){
   prefix.push(m.act('place_data'),m.act('choose_target',a=>a.summary===(storage==='computer'?'第一排放置位 5':'blue2 下方')));
  }
  if(close)prefix.push(m.act('end_turn'));
  if(m.menu()[0].actorId!=='player-white')m.advanceOpponents(prefix);
  assert.equal(m.facts().round,3);assert(!m.c.inspect().session);assert(m.menu().some(a=>a.family==='pass'));
  const settled=m.save(),assets=short(m);
  m.restore(root);prefix.forEach(m.apply);assert.deepEqual(m.save(),settled);
  m.act('pass');const options=m.menu().filter(a=>a.family==='choose_card').map(a=>a.summary);
  console.log(JSON.stringify([name,assets,options]));
  rows.push({name,root,prefix,settled,assets,options});
 }finally{m.dispose();}
}
writeZ(out,rows);
