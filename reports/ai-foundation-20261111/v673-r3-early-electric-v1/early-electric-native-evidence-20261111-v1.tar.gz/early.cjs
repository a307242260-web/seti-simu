'use strict';
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),d=readZ(dir+'/audit-20261111-v1.json.gz'),rec=new Map(d.ledger.map(r=>[r.i,r.input]));
const root=d.roots[179];
const a1='amiba_1.webp',a7='amiba_7.webp',a9='amiba_9.webp',b16='b_16.webp',d25='dlc_25.png',d20='dlc_20.png';
const fixed=(h,i)=>{const a=rec.get(i),exact=h.m.menu().find(x=>x.actionId===a.actionId);if(exact)return h.take(h.m.apply(a));
 return h.act(a.family,x=>x.summary===a.summary&&JSON.stringify(x.target)===JSON.stringify(a.target));};
const sel=(h,f,label)=>h.act(f,a=>a.summary===label);
const data=(h,label)=>{h.act('place_data');sel(h,'choose_target',label)};
const trade=(h,ids)=>{
 h.act('quick_trade',a=>a.target.tradeId==='cards-for-credit');
 for(const id of ids)sel(h,'choose_payment',id);
 h.act('choose_payment',a=>a.summary.startsWith('确认弃牌'));
};
const prep=(h,blue,mode)=>{
 fixed(h,179);h.act('choose_target',a=>a.target.slotId===(blue==='points'?'blue_1':'blue_3'));
 for(let i=181;i<=200;i++)fixed(h,i);
 if(mode==='slot'){
  data(h,'blue3 下方');h.take(h.m.pick(d25));data(h,'第一排放置位 4');
  sel(h,'choose_card','收入 '+d25);trade(h,[a1,a7]);
 }else if(mode==='buy'){
  h.act('quick_trade',a=>a.target.tradeId==='publicity-for-card');h.take(h.m.pick(d25));data(h,'第一排放置位 4');
  sel(h,'choose_card','收入 '+d25);trade(h,[a1,a7]);
 }else if(mode==='swap'){
  h.take(...h.m.swap(a1,d25));data(h,'第一排放置位 4');
  sel(h,'choose_card','收入 '+d25);
  data(h,'blue3 下方');h.take(h.m.pick(d20));trade(h,[d20,a7]);
 }else if(mode==='slot+buy'){
  data(h,'blue3 下方');h.take(h.m.pick(d25));
  h.act('quick_trade',a=>a.target.tradeId==='publicity-for-card');h.take(h.m.pick(d20));
  data(h,'第一排放置位 4');sel(h,'choose_card','收入 '+d25);trade(h,[a1,d20]);
 }
 h.cut('scan-wallet');h.act('end_turn');
};
const scan=h=>{
 h.act('scan');sel(h,'choose_target','扫描 开普勒22');
 sel(h,'choose_card','dlc_24.png → 开普勒22');
 h.act('choose_target',a=>a.target.speciesId==='amiba'&&a.target.position===3&&a.target.traceType==='pink');
 h.act('choose_card',a=>a.summary.includes('生物特征筛选'));
 h.act('accept_optional_effect',a=>a.summary.includes('amiba_0'));
 h.act('complete_task',a=>a.summary.includes('dlc_9'));
 h.cut('after-scan');h.act('end_turn');
};
const cases=[];
for(const blue of ['points','publicity'])for(const mode of ['slot','buy','swap','slot+buy'])for(const tail of ['auto','same-scan']){
 cases.push([[blue,mode,tail].join('/'),h=>{prep(h,blue,mode);if(tail==='same-scan')scan(h);}]);
}
writeZ(out,runCases(root,cases));
