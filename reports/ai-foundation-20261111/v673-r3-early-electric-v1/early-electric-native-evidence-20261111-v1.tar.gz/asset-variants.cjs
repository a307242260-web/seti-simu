'use strict';
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),d=readZ(dir+'/late-20261111-v1.json.gz'),g=d['publicity/slot/same-scan/dlc_20.png'],r=g.rows.find(x=>x.label.endsWith('/both'));
const data=(h,label)=>{h.act('place_data');h.act('choose_target',a=>a.summary===label)};
const end=h=>h.act('end_turn');
const cashAlt=runCases(r.checkpoints.analysis.state,[['DLC17 data, Amiba2 cash',h=>{
 h.take(h.m.corner('dlc_17.png'));for(let i=1;i<=4;i++)data(h,'第一排放置位 '+i);
 h.act('choose_card',a=>a.summary==='收入 amiba_2.webp');h.cut('cash');end(h);
}]]);
const keeps=runCases(r.checkpoints['extra-scan'].state,[
 ['preserve pool',h=>{end(h);h.cut('pool');}],
 ['preserve blue energy',h=>{data(h,'blue2 下方');end(h);h.cut('electric');}],
]);
writeZ(out,{cashAlt,keeps});
