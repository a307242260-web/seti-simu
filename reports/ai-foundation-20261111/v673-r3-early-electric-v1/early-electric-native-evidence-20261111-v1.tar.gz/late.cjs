'use strict';
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),d=readZ(dir+'/early-20261111-v1.json.gz');
const a2='amiba_2.webp',a5='amiba_5.webp',a9='amiba_9.webp',b16='b_16.webp',d17='dlc_17.png',d16='dlc_16.png',d20='dlc_20.png';
const sel=(h,f,label)=>h.act(f,a=>a.summary===label),end=h=>h.act('end_turn');
const data=(h,label)=>{h.act('place_data');sel(h,'choose_target',label)};
const comp=(h,...nums)=>nums.forEach(i=>data(h,'第一排放置位 '+i));
const tech=(h,t)=>{h.act('research_tech');h.act('choose_target',a=>a.target.tileId===t&&(t!=='blue1'||a.target.blueSlot===3));};
const prepare=(h,market)=>{
 tech(h,'orange1');h.take(h.m.pick(market));end(h);
 h.act('move',a=>a.summary.includes('向外'));sel(h,'choose_payment','弃 1 张移动牌');
 if(h.m.menu()[0]?.family==='choose_card')h.act('choose_card',a=>a.summary===market);
 h.take(h.m.corner(a9));tech(h,'blue1');comp(h,5,6);data(h,'blue1 下方');h.cut('cash1');end(h);
};
const finish=(h,card,mode)=>{
 h.take(h.m.play(a5));h.take(h.m.pick(card));
 const q=h.m.menu().find(a=>a.summary.includes('1数据'))||h.m.menu().find(a=>a.summary.includes('4分'));
 if(q)h.take(h.m.apply(q));
 end(h);h.act('analyze');h.act('choose_target',a=>a.target.speciesId==='amiba'&&a.target.position===3&&a.target.traceType==='blue');
 h.act('choose_card',a=>a.summary.includes('科学论文'));h.cut('analysis');
 if(mode==='release')return;
 h.take(h.m.corner(a2));comp(h,1,2,3,4);sel(h,'choose_card','收入 '+card);h.cut('cash2');end(h);
 h.take(h.m.play(b16));h.act('choose_target',a=>a.summary.endsWith('顺时针'));
 h.act('choose_target',a=>a.target.nebulaId==='sector-1-a');h.cut('extra-scan');
};
const results={};
for(const [base,market,card] of [
 ['points/slot/same-scan',d20,d17],
 ['publicity/slot/same-scan',d20,d17],
 ['publicity/slot/same-scan',d16,d17],
 ['publicity/swap/same-scan',d16,d17],
 ['publicity/buy/same-scan',d20,d17],
 ['publicity/slot+buy/same-scan',d16,d17],
]){
 const r=d.rows.find(x=>x.label===base);
 results[base+'/'+market]=runCases(r.start,['release','both'].map(mode=>[[base,market,card,mode].join('/'),h=>{prepare(h,market);finish(h,card,mode);}]));
}
writeZ(out,results);
