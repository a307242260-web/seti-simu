'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const {open,readZ,writeZ,short}=require('./controlled-r3');
const white='player-white', read=p=>JSON.parse(fs.readFileSync(p));
const [dir,out]=process.argv.slice(2),d=readZ(dir+'/asset-variants-20261111-v1.json.gz');
const cases=[...d.cashAlt.rows.map(r=>[r.label,r.settled.state]),
 ['Keep raw pool',d.keeps.rows.find(r=>r.label==='preserve pool').checkpoints.pool.state],
 ['Convert pool to electric',d.keeps.rows.find(r=>r.label==='preserve blue energy').settled.state]];
const first=[];
for(const [name,root] of cases){const m=open(root);try{m.act('pass');first.push([name,m.menu().filter(a=>a.family==='choose_card').map(a=>a.summary)]);}finally{m.dispose();}}
const common=['b_111.webp','b_32.webp'].filter(id=>first.every(([,options])=>options.includes(id)));
assert(common.length,JSON.stringify(first));
const results=[];
for(const [name,root] of cases)for(const card of common){
 const m=open(root),actions=[];
 try{
  actions.push({action:m.act('pass')},{action:m.act('choose_card',a=>a.summary===card)});
  let cp,stop;
  const turns=[];
  for(let i=0;i<200;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!==white){const passive=[];m.advanceOpponents(passive);actions.push(...passive.map(action=>({action,passive:true})));continue;}
   const q=m.automatic(cp);
   if(!q.a||!q.complete||q.n>256||q.ms>600){stop={kind:'gate',n:q.n,ms:q.ms,action:q.a?.summary,turn:m.facts().turn};break;}
   if(!cp||q.a.phase==='main'||q.a.family==='pass')turns.push({choice:q.a,n:q.n,ms:q.ms,assets:short(m)});
   cp=q.checkpoint;actions.push({action:m.apply(q.a),n:q.n,ms:q.ms,value:q.value});
  }
  assert(stop);
  const end=m.save(),terminal=stop==='terminal'?m.state().match.finalScores.find(p=>p.playerId===white):null;
  const peak=[Math.max(...actions.map(x=>x.n||0)),Math.max(...actions.map(x=>x.ms||0))];
  console.log(JSON.stringify([name,card,stop,terminal?.totalScore,peak,short(m)]));
  m.restore(root);actions.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),end);
  results.push({name,card,root,actions,turns,stop,terminal,peak,end});
 }finally{m.dispose();}
}
writeZ(out,{first,common,results});
