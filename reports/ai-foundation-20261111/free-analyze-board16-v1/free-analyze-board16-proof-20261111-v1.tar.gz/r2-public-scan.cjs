'use strict';
const assert=require('node:assert/strict');
function sub(s,a,b){assert.equal(s.split(a).length,2,a);return s.replace(a,b);}
module.exports=(s,witness)=>{
 s=sub(s,'t.roundNumber===3&&quietEarlySameSeatHandover(root)','quietEarlySameSeatHandover(root)');
 s=sub(s,'source==="scan"&&t.roundNumber===3&&quietEarlySameSeatHandover(state)','source==="scan"&&quietEarlySameSeatHandover(state)');
 if(witness){
  for(const [kind,at,raw] of [
   ['public-scan','        provedPublicScanChoices++;','publicScan.inspection.session?.decision?.choices'],
   ['scan4','        if(requested.target.mode==="move")provedScan4QuietMoves++;','prepared.inspection.session?.decision?.choices'],
  ])s=sub(s,at,`        if(readIdentityState(stored.envelope).turn.roundNumber===2)
          globalThis.dataProof.push({kind:"${kind}",source:stored.envelope,target:nodes.get(child).envelope,action:requested,raw:${raw}});\n`+at);
 }
 return s;
};
