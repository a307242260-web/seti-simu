'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const f=path.resolve('randomizer/game/effects/science-session.js'),lm=new Module(f,module);
lm.filename=f;lm.paths=Module._nodeModulePaths(path.dirname(f));
lm._compile(fs.readFileSync(path.join(__dirname,'board16-science-original.js'),'utf8'),f);lm.loaded=true;
const [input]=process.argv.slice(2),before=lm.exports,after=require(f),{readZ,open}=require('./controlled-r3');
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent')),{createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const row=readZ(input).rows[0],s=JSON.parse(row.root.committedState),seatId='player-white',m=open(row.root);
const port=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
let cases=0;
function* permutations(xs){if(!xs.length)yield [];else for(let i=0;i<xs.length;i++)for(const rest of permutations(xs.filter((_,j)=>i!==j)))yield[xs[i],...rest];}
try{
 const keys=Object.keys(s.solarSystem.sectorBySlot);
 for(const values of permutations(Object.values(s.solarSystem.sectorBySlot))){
  for(let mask=0;mask<16;mask++){
   const state=structuredClone(s),p=state.players.players.find(x=>x.id===seatId);
   state.solarSystem.sectorBySlot=Object.fromEntries(keys.map((k,i)=>[k,values[i]]));
   Object.values(state.data.nebulae).forEach((v,i)=>v.tokens.slice(0,(mask>>(i%4))%3).forEach((t,j)=>{
    t.replacedByPlayerId=j===0?p.id:'player-blue';t.replacedByPlayerColor=j===0?p.color:'blue';
   }));
   for(const condition of [{type:'hasPlayerSignal'},{type:'sectorSignalCount',minCount:2},{type:'sectorSignalCount',minCount:1}]){
    const o={mode:'conditional',condition,allMatching:true,gainData:false};
    assert.deepEqual(after.listScanStepChoices(state,p,o),before.listScanStepChoices(state,p,o));cases++;
   }
  }
 }
 const q=createSearchAgent({seatId,analysisPort:port}).decide({seatId,legalActions:m.menu()}).search;
 const actual=JSON.parse(JSON.stringify(q));
 for(const k of ['actionId','value','realization','preparationDebt','complete','roots','lines','unresolved','selectionPlan','candidates','sharedPrefixGraph'])assert.deepEqual(actual[k],row.q[k],k);
 assert.deepEqual(m.save(),row.root);assert.equal(q.diagnostics.nativeExecutions,row.n);
 console.log({menuCases:cases,n:row.n,rootAndSearchMs:q.rootAndSearchMilliseconds});
}finally{port.close();m.dispose();}
