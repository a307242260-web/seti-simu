# 第 16 盘：条件扫描复用
在旧源码 27d21b1b7 根目录运行本目录 admit-r2-public-scan.cjs，输入 b38-16-profile 的 gzip 和新的输出路径，独立核对 80 笔复用。
在完整新源码根目录运行 board16-scan-parity.cjs，输入 b38-16-scan-proof 的 gzip；脚本对照旧扫描源码、1,152 份菜单和实际原根搜索图。
完整新源码下，resume-current.cjs 从 fixtures 中旧存档续跑，参数二为新 gzip 输出文件。实际见证、终局及 CPU 样本均随档保存。
