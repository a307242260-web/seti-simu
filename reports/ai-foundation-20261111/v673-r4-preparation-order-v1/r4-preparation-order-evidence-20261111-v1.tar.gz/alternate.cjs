'use strict';
const {open,readZ,writeZ}=require('./controlled-r3'),assert=require('node:assert/strict');
const [input,out]=process.argv.slice(2),results=[];
for(const row of readZ(input)){
 const q=row.q,m=open(row.root),lines=new Map(q.lines.map(n=>[n.node,n]));
 function edge(n){
  const a=lines.get(n);
  return a.edges.find(e=>{const b=lines.get(e.target);return b?.value===a.value&&b.distance+e.cost===a.distance;});
 }
 try{
  const industry=q.roots.find(x=>x.actionId.startsWith('industry:')),start=lines.get(0).edges.find(e=>e.actionId===industry.actionId);
  const blue=edge(start.target),income=edge(blue.target),land=edge(income.target);
  assert(blue.resourcePlan.id==='data:blue:1'&&income.resourcePlan.id==='data:income:4'&&land.resourcePlan.goal.kind==='route');
  const action=id=>m.menu().find(a=>a.actionId===id),applyIds=ids=>ids.map(id=>m.apply(action(id)));
  const swaps=applyIds(start.steps),afterSwap=m.save(),ref=[...applyIds(blue.steps),...applyIds(income.steps)],afterFunding=m.save();
  const afterLandingInputs=applyIds(land.steps),afterLanding=m.save(),menu=m.menu();
  assert(m.facts().wallet.score>=130);
  m.restore(afterSwap);
  const norm=t=>JSON.stringify(Object.entries(t).sort());
  const applyActions=a=>a.map(x=>m.act(x.family,y=>norm(y.target)===norm(x.target)));
  const other=applyActions([...ref.slice(blue.steps.length),...ref.slice(0,blue.steps.length)]),afterOtherFunding=m.save();
  assert.deepEqual(m.facts().rng,JSON.parse(afterFunding.committedState).meta.rngState);
  applyActions(afterLandingInputs);const afterOtherLanding=m.save(),fact=m.facts();
  const getState=e=>JSON.parse(e.committedState);
  const normalize=s=>{
   s.cards.discardPile.sort((a,b)=>a.id.localeCompare(b.id));
   for(const p of s.players.players){
    for(const t of [...p.dataState.placedTokens,...p.dataState.poolTokens]){delete t.id;delete t.index;if(p.dataState.poolTokens.includes(t))delete t.slotIndex;}
    p.dataState.placedTokens.sort((a,b)=>a.placementKind.localeCompare(b.placementKind)||(a.placementSlot??a.blueSlot)-(b.placementSlot??b.blueSlot));
   }
   return s;
  };
  const normSession=e=>{
   const id=e.session?.session.sessionId;
   if(!id)return e.session;
   return JSON.parse(JSON.stringify(e.session).replaceAll(id,'@session'));
  };
  assert.deepEqual(normalize(getState(afterFunding)),normalize(getState(afterOtherFunding)));
  assert.deepEqual(normalize(getState(afterLanding)),normalize(getState(afterOtherLanding)));
  const landingShape=e=>{
   const cp=normSession(e);
   for(const k of ['baseState','workingState'])normalize(cp.session[k]);
   cp.session.undoFrames=[];
   return cp;
  };
  assert.deepEqual(landingShape(afterLanding),landingShape(afterOtherLanding));
  assert.deepEqual(m.menu().map(a=>[a.actionId,a.family,a.target]),menu.map(a=>[a.actionId,a.family,a.target]));
  for(const [funding,expected] of [[ref,afterLanding],[other,afterOtherLanding]]){
   m.restore(row.root);swaps.forEach(m.apply);funding.forEach(m.apply);applyActions(afterLandingInputs);assert.equal(m.save().committedState,expected.committedState);assert.deepEqual(normSession(m.save()),normSession(expected));
  }
  const cid=(e,id)=>getState(e).players.players.find(p=>p.id==='player-white').hand.find(c=>c.id===id)?.cardId;
  const summary={value:industry.value,incoming:cid(afterSwap,swaps[2].target.cardInstanceId),
   blueCorner:cid(afterSwap,ref[0].target.cardInstanceId),incomeCorner:cid(afterSwap,ref[blue.steps.length].target.cardInstanceId),
   incomeCard:cid(afterSwap,ref.at(-1).target.cardInstanceId),afterLanding:fact.wallet,menu:m.menu().map(a=>a.summary)};
  console.log(JSON.stringify(summary));
  results.push({root:row.root,swaps,ref,other,afterSwap,afterFunding,afterOtherFunding,afterLandingInputs,afterLanding,afterOtherLanding,summary});
 }finally{m.dispose();}
}
writeZ(out,results);
