'use strict';
const {open,readZ,writeZ}=require('./controlled-r3'),assert=require('node:assert/strict');
const [input,out]=process.argv.slice(2);
const diff=(a,b,at='')=>JSON.stringify(a)===JSON.stringify(b)?[]
 :a&&b&&typeof a==='object'&&typeof b==='object'?[...new Set([...Object.keys(a),...Object.keys(b)])].flatMap(k=>diff(a[k],b[k],at+'/'+k)):[[at,a,b]];
function run(row){
 const m=open(row.root);
 try{
  const rows=row.cp.plan.rows,actions=rows.map(x=>JSON.parse(x.actions).find(a=>a.actionId===x.actionId));assert(actions.every(Boolean));
  const norm=x=>JSON.stringify(Object.entries(x).sort());
 const same=action=>m.act(action.family,a=>norm(a.target)===norm(action.target));
  const results=[];
  for(const order of ['BIS','BSI','IBS','ISB','SBI','SIB']){
   m.restore(row.root); const sequence=[];
   for(const k of order)for(const a of ({B:actions.slice(0,3),I:actions.slice(3,7),S:actions.slice(7,10)})[k]){
    const v=same(a);sequence.push(v);
   }
   const after=m.save(),facts=m.facts(),next=m.menu();
   // Exercise the whole winning route through the first post-landing
   // place-data input. Any difference may alter rewards/RNG or legality.
   for(const a of actions.slice(10,22))sequence.push(same(a));
   results.push({order,after,facts,next,route:m.save(),routeFacts:m.facts(),sequence});
  }
  const ref=results[0];
  for(const x of results){
   x.differences=diff(JSON.parse(ref.after.committedState),JSON.parse(x.after.committedState));
   x.routeDifferences=diff(JSON.parse(ref.route.committedState),JSON.parse(x.route.committedState));
   assert.deepEqual(ref.next,x.next);assert.deepEqual(ref.facts.rng,x.facts.rng);
   m.restore(row.root);x.sequence.forEach(m.apply);assert.deepEqual(m.save(),x.route);
   console.log(JSON.stringify([x.order,x.differences.map(([p])=>p),x.routeDifferences.map(([p])=>p),x.facts.wallet,x.facts.hand]));
  }
  return {root:row.root,results};
 }finally{m.dispose();}
}
writeZ(out,readZ(input).map(run));
