'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),Module=require('node:module');
const {open,readZ,writeZ}=require('./controlled-r3'),compileScan=require('./reuse-scan.cjs'),compileYellow=require('./reuse-yellow2.cjs');
const [input,out]=process.argv.slice(2),src=path.resolve('randomizer/game/ai/analysis-port.js'),seatId='player-white';
const mod=new Module(src,module);mod.filename=src;mod.paths=Module._nodeModulePaths(path.dirname(src));
mod._compile(compileYellow(compileScan(fs.readFileSync(src,'utf8'),require(process.env.SETI_SCAN_PRIOR))),src);
const prod=require(src),{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const parity=['actionId','value','realization','preparationDebt','complete','roots','lines','unresolved','selectionPlan','candidates','sharedPrefixGraph'];
function test(api,root){
 const m=open(root),p=api.createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
 try{
  const q=createSearchAgent({analysisPort:p,seatId}).decide({seatId,legalActions:m.menu()}).search;
  assert.deepEqual(m.save(),root);
  return JSON.parse(JSON.stringify(q));
 }finally{p.close();m.dispose();}
}
function mask(root){
 const s=JSON.parse(root.committedState),deck=s.cards.drawPileCardIds,alien=s.aliens.amiba.cardDeck;
 assert(deck.length>1&&alien.length>1);
 [deck[0],deck[1]]=[deck[1],deck[0]];[alien[0],alien[1]]=[alien[1],alien[0]];
 return {...root,committedState:JSON.stringify(s)};
}
const results=[];
for(const x of readZ(input).rows){
 for(const variant of ['native','masked']){
  const root=variant==='native'?x.state:mask(x.state);
  const q=test(mod.exports,root),reference=variant==='native'?x.q:test(prod,root);
  for(const k of parity)assert.deepEqual(q[k],reference[k],k);
  assert.equal(q.actionId,x.q.actionId);assert.equal(q.value,x.q.value);
  results.push({card:x.card,variant,root,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,q});
  console.log(JSON.stringify([x.card,variant,reference.diagnostics.nativeExecutions,q.diagnostics.nativeExecutions,q.rootAndSearchMilliseconds,q.value]));
 }
}
writeZ(out,results);
