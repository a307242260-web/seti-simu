从 Production cbd73e00c98455dac868bd43be3e1759130088a7 的独立快照根目录执行。A 为归档解包的绝对目录。输出文件不能已存在；这些命令不提交任何自主超限决定，也不修改源码文件。

    node "$A/replay.cjs" "$A/prefix-reference.json.gz" "$A/replayed-orders.json.gz"
    node "$A/alternate.cjs" "$A/prefix-reference.json.gz" "$A/replayed-alternate.json.gz"
    SETI_SCAN_PRIOR="$A/prior.cjs" node "$A/prove-yellow2.cjs" "$A/profile2.json.gz" "$A/replayed-edge-witnesses.json.gz"
    SETI_SCAN_PRIOR="$A/prior.cjs" node "$A/gate-exact.cjs" "$A/profile2.json.gz" "$A/replayed-gate.json.gz"
    SETI_SCAN_PRIOR="$A/prior.cjs" node "$A/bind-joined.cjs" bound-move-join-route-yellow "$A/profile2.json.gz" "$A/replayed-join.json.gz"

前两条重放明确固定的输入，核对资产、原生存档、正式菜单、RNG 和后续登陆。第三条生成全部 450 个前后存档见证。第四条核对暗牌扰动后同根搜索图。最后一条是用途约束诊断，保留两个受测根的全部首层候选报价和已选路径，但不能推及其他盘面。耗时只用于记录这次运行。
