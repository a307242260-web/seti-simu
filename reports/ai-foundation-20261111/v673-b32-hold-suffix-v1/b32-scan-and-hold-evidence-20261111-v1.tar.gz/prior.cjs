'use strict';
const assert=require('node:assert/strict');
module.exports=function prepare(s,mode){
 function sub(from,to){assert.equal(s.split(from).length,2,from);s=s.replace(from,to);}
 if(['asteroid','both'].includes(mode)){
  sub('            :visitType!=="visitPlanet"||Object.keys(jobs).length))return null;',`            :Object.keys(jobs).length||!(visitType==="visitPlanet"
              ||!mercury&&visitType==="visitAsteroid"&&!players.playerOwnsTech(player,"orange2",next)
                &&move.payload.rewards.length===0)))return null;`);
 }
 if(['comet','comet-b9'].includes(mode)){
  sub('            :visitType!=="visitPlanet"||Object.keys(jobs).length))return null;',
      '            :!["visitPlanet","visitComet"].includes(visitType)||Object.keys(jobs).length))return null;');
 }
 if(['b9','both','comet-b9'].includes(mode)){
  const anchor='      if(s?.phase!=="awaiting_input"||s.failure||s.interruptContext||s.undoFrames.length\n        ||head.type!==types.SCAN_STEP||head.kind!=="decision"||head.ownerId!==seatId||head.allowQuickActions||!simple(opts)';
  sub(anchor,`      const start=s?.journal.actions[0]?.action;
      const lastB9=s?.queue.length===2&&s.irreversibleBarrier?.code==="hidden_card_reveal"
        &&opts?.mode==="any"&&opts.gainData===true&&opts.sameSectorRemaining===1
        &&Object.keys(opts).every(k=>["mode","gainData","label","sameSectorRemaining"].includes(k))
        &&start?.family==="play_card"&&rootObservation.selfState.hand
          .some(c=>!c.hidden&&c.id===start.target.cardInstanceId&&c.cardId==="b_9.webp")
        &&s.workingState.cards.publicCards.every(Boolean);
`+anchor+'&&!lastB9');
 }
 return s;
};
