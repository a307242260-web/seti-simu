'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
const [mode,input,refFile,out]=process.argv.slice(2),f=path.resolve('randomizer/game/ai/analysis-port.js');
const mod=new Module(f,module);mod.filename=f;mod.paths=Module._nodeModulePaths(path.dirname(f));
globalThis.scanWitnesses=[];
mod._compile(require('./scan-guard.cjs')(fs.readFileSync(f,'utf8'),mode),f);mod.loaded=true;require.cache[f]=mod;
const {open,readZ,writeZ}=require('./controlled-r3'),{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const {root}=readZ(input).results.find(r=>r.card==='b_32.webp'),{q:ref}=readZ(refFile),seatId='player-white';
const m=open(root),port=mod.exports.createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
const normal=e=>{
 const c=structuredClone(e);c.committedState=JSON.parse(c.committedState);
 const id=c.session?.session.sessionId;
 if(id){c.session.session.undoFrames=[];c.session=JSON.parse(JSON.stringify(c.session).replaceAll(id,'@session'));}
 return c;
};
try{
 const agent=createSearchAgent({seatId,analysisPort:port}),q=agent.decide({seatId,legalActions:m.menu()}).search;
 assert.deepEqual(m.save(),root);
 const canon=JSON.parse(JSON.stringify(q));
 for(const k of ['actionId','value','realization','preparationDebt','complete','roots','lines','unresolved','selectionPlan','candidates','sharedPrefixGraph'])assert.deepEqual(canon[k],ref[k],k);
 const counts={},witnesses=globalThis.scanWitnesses;
 if(mode==='witness')assert.equal(witnesses.length,ref.diagnostics.nativeExecutions-q.diagnostics.nativeExecutions);
 for(const {kind,source,action,target,barrier,raw} of witnesses){
  m.restore(source);
  const decision=m.c.inspect().session.decision;
  const nativeChoice=m.menu().find(a=>a.actionId===action.actionId);
  assert.deepEqual(nativeChoice,action);
  const r=m.c.inputPort.submitDecision({decisionId:decision.decisionId,decisionVersion:decision.decisionVersion,ownerId:decision.ownerId,choice:nativeChoice});
  assert(r.ok);
  const saved=m.save();
  assert.deepEqual(normal(saved),normal(target),kind+': '+action.summary);
  if(raw)assert.deepEqual(m.menu(),raw);
  assert.deepEqual(r.irreversibleBarrier??saved.session?.session.irreversibleBarrier??source.session?.session.irreversibleBarrier??null,barrier??null);
  counts[kind]=(counts[kind]||0)+1;
 }
 const ms=q.rootAndSearchMilliseconds,n=q.diagnostics.nativeExecutions;
 console.log(JSON.stringify({mode,counts,n,ms,admitted:n<=256&&ms<=600&&q.complete&&!q.unresolved.length,diagnostics:q.diagnostics},null,0).slice(0,3300));
 writeZ(out,{root,q,counts,witnesses});
}finally{port.close();m.dispose();}
