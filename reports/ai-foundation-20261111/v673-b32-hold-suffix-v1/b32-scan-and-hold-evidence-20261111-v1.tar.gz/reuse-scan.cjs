'use strict';
const assert=require('node:assert/strict');
module.exports=function(s,prior){
 s=prior(s,'b9');
 function sub(a,b){assert.equal(s.split(a).length,2,a);s=s.replace(a,b);}
 sub('      const start=s?.journal.actions[0]?.action;\n      const lastB9=', '      const start=s?.journal.actions[0]?.action;\n      const lastB9=');
 sub('      if(s?.phase!=="awaiting_input"||s.failure||s.interruptContext||s.undoFrames.length\n        ||head.type!==types.SCAN_STEP||head.kind!=="decision"||head.ownerId!==seatId||head.allowQuickActions||!simple(opts)&&!lastB9\n        ||finalize?.type!==types.SCAN_FINALIZE||finalize.kind!=="effect"||finalize.ownerId!==seatId\n        ||Object.keys(head.payload).length!==1)return null;',`      const publicStep=o=>o?.mode==="public"
        &&Object.keys(o).every(k=>["mode","max","selected","consumeMarkers"].includes(k))
        &&Number.isSafeInteger(o.max)&&o.max>0&&o.selected===0&&o.consumeMarkers===true;
      const scanPrefix=simple(opts)&&finalize?.type===types.SCAN_STEP&&finalize.kind==="effect"
        &&publicStep(finalize.payload?.options)&&Object.keys(finalize.payload).length===1
        &&s.queue[2]?.type===types.SCAN_ACTION_4&&s.queue[3]?.type===types.SCAN_FINALIZE
        &&(start?.family==="scan"&&s.queue.length===4||start?.family==="play_card"&&s.queue.length===6
          &&s.queue[4]?.payload?.cardEffect?.id==="b9-any-sector-scan"
          &&s.queue[5]?.type===types.SCAN_FINALIZE
          &&rootObservation.selfState.hand.some(c=>!c.hidden&&c.id===start.target.cardInstanceId&&c.cardId==="b_9.webp"));
      if(s?.phase!=="awaiting_input"||s.failure||s.interruptContext||s.undoFrames.length
        ||head.type!==types.SCAN_STEP||head.kind!=="decision"||head.ownerId!==seatId||head.allowQuickActions||!simple(opts)&&!lastB9
        ||!scanPrefix&&(finalize?.type!==types.SCAN_FINALIZE||finalize.kind!=="effect"||finalize.ownerId!==seatId)
        ||Object.keys(head.payload).length!==1)return null;`);
 sub('        }else if(type===types.SCAN_STEP&&simple(effect.payload?.options)){',`        }else if(scanPrefix&&type===types.SCAN_STEP&&effect===finalize){
          const o=effect.payload.options,raw=scienceSession.listPublicScanChoices(state);
          if(!raw.length||state.cards.publicCards.some(c=>c&&!known.has(c.id)))return null;
          result={ok:true,spawnedEffects:[scienceSession.scanDecisionEffect(types.SCAN_STEP,seatId,{options:o},"choose_card")]};
          if(!apply(effect,result))return null;
          choices=scienceSession.formalizeChoices(state,seatId,scienceSession.listScanStepChoices(state,actor,o));
          break;
        }else if(type===types.SCAN_STEP&&simple(effect.payload?.options)){`);
 return s;
};
