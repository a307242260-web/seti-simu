'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),Module=require('node:module');
const [input,out]=process.argv.slice(2),f=path.resolve('randomizer/game/ai/analysis-port.js');
const mod=new Module(f,module);mod.filename=f;mod.paths=Module._nodeModulePaths(path.dirname(f));
mod._compile(require('./scan-guard.cjs')(fs.readFileSync(f,'utf8'),'clean'),f);mod.loaded=true;require.cache[f]=mod;
const {open,readZ,writeZ,short}=require('./controlled-r3');
const proof=readZ(input),m=open(proof.root),actions=[];
let cp,stop,gate,end,terminal;
try{
 for(let i=0;i<160;i++){
  if(m.state().turn.gameEnded){stop='terminal';break;}
  if(m.menu()[0].actorId!=='player-white'){
   const passive=[];m.advanceOpponents(passive);actions.push(...passive.map(action=>({action,passive:true})));continue;
  }
  const q=m.automatic(cp);
  if(i===0)assert.deepEqual([q.a?.actionId,q.value,q.n],[proof.q.actionId,proof.q.value,proof.q.diagnostics.nativeExecutions]);
  if(!q.a||!q.complete||q.n>256||q.ms>600){stop='gate';gate={n:q.n,ms:q.ms,action:q.a,turn:m.facts().turn,cp};break;}
  cp=q.checkpoint;actions.push({action:m.apply(q.a),n:q.n,ms:q.ms,value:q.value});
  if(i===0)console.log(JSON.stringify({first:q.a.summary,n:q.n,ms:q.ms,checkpointRows:cp?.plan?.rows?.length}));
 }
 assert(stop);
 end=m.save();terminal=stop==='terminal'?m.state().match.finalScores.find(p=>p.playerId==='player-white'):null;
 const facts=short(m),peak=[Math.max(0,...actions.map(x=>x.n||0)),Math.max(0,...actions.map(x=>x.ms||0))];
 m.restore(proof.root);actions.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),end);
 console.log(JSON.stringify({stop,gate:gate&&{...gate,cp:undefined},terminal,actions:actions.length,peak,facts}));
 writeZ(out,{root:proof.root,end,actions,stop,terminal,facts,peak,gate,replayExact:true});
}finally{m.dispose();}
