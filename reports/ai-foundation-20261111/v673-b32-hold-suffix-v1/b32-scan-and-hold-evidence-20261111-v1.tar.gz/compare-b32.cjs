'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),Module=require('node:module');
const [arch,holdFile,out]=process.argv.slice(2),f=path.resolve('randomizer/game/ai/analysis-port.js');
const mod=new Module(f,module);mod.filename=f;mod.paths=Module._nodeModulePaths(path.dirname(f));
mod._compile(require('./scan-guard.cjs')(fs.readFileSync(f,'utf8'),'clean'),f);mod.loaded=true;require.cache[f]=mod;
const {open,readZ,writeZ}=require('./controlled-r3'),rows=readZ(arch).results.filter(r=>r.card==='b_32.webp'),
 hold=readZ(holdFile),results=[];
for(const old of rows){
 const m=open(old.root),actions=[],actor='player-white';
 let cp,stop,gate;
 try{
  actions.push({action:m.act('pass')},{action:m.act('choose_card',a=>a.summary===old.card)});
  for(let i=0;i<200;i++){
   if(old.name==='hold-after-income'&&JSON.stringify(m.save())===JSON.stringify(hold.root)){
    assert.deepEqual(m.save(),hold.root);
    stop='same-proved-hold-root';break;
   }
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!==actor){
    const passive=[];m.advanceOpponents(passive);actions.push(...passive.map(action=>({action,passive:true})));continue;
   }
   const q=m.automatic(cp);
   if(!q.a||!q.complete||q.n>256||q.ms>600){stop='gate';gate={n:q.n,ms:q.ms,action:q.a?.summary,turn:m.facts().turn};break;}
   cp=q.checkpoint;actions.push({action:m.apply(q.a),n:q.n,ms:q.ms,value:q.value});
  }
  assert(stop);
  const end=m.save(),terminal=stop==='terminal'?m.state().match.finalScores.find(p=>p.playerId===actor):null;
  m.restore(old.root);actions.forEach(a=>m.apply(a.action));assert.deepEqual(m.save(),end);
  const sameActions=JSON.stringify(actions.map(a=>a.action))===JSON.stringify(old.actions.map(a=>a.action));
  const sameEnd=JSON.stringify(end)===JSON.stringify(old.end);
  const peak=[Math.max(0,...actions.map(x=>x.n||0)),Math.max(0,...actions.map(x=>x.ms||0))];
  console.log(JSON.stringify({name:old.name,stop,gate,terminal:terminal?.totalScore,sameActions,sameEnd,peak}));
  results.push({name:old.name,root:old.root,stop,gate,terminal,sameActions,sameEnd,actions,end,peak});
 }finally{m.dispose();}
}
writeZ(out,{results});
