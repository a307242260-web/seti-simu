Production JS: 433765e936e26b6a25c8b599f580792471e3445b (dev evidence parent: 05d54d036bda99721edb7ccf468a8d98e7a42245).
Run from that checkout; let E be this extracted directory. Choose unused output names.
node "$E/admit.cjs" witness "$E/b32-root-20261111-v1.json.gz" "$E/b32-native-by-family-20261111-v1.json.gz" "$E/witness-replay.json.gz"
node "$E/hidden.cjs" "$E/b32-scan-witness-20261111-v1.json.gz" "$E/hidden-replay.json.gz"
node "$E/continue.cjs" "$E/b32-scan-witness-20261111-v1.json.gz" "$E/suffix-replay.json.gz"
The suffix refuses every candidate over 256 native executions or 600 ms before submitting it. Cold wall time is machine/load dependent.
The witness normalization removes only per-instance session IDs and simulation undo frames; the working state, RNG, rules journal, raw menu and information barrier are compared.
Use cargo-income-fourth-20261111-v1.json.gz from the original V673 evidence archive for the same-source comparison:
node "$E/compare-b32.cjs" /path/to/cargo-income-fourth-20261111-v1.json.gz "$E/b32-scan-resume-20261111-v1.json.gz" "$E/b32-controls-replay.json.gz"
