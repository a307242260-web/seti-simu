'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs');
const d=__dirname;
module.exports=(base, mode)=>{
 let s=require(d+'/reuse-scan.cjs')(base,require(d+'/prior.cjs'));
 const sub=(a,b)=>{assert.equal(s.split(a).length,2,a);s=s.replace(a,b);};
 // Awaiting-input inspection supplies the raw menu. finishChild restores if a
 // barrier needs a separate projection; stable children still need enumeration.
 sub('      if(fixedScan){\n        restoreEnvelope(fixedScan.envelope);','      if(fixedScan){\n        if(fixedScan.inspection.phase!=="awaiting_input")restoreEnvelope(fixedScan.envelope);');
 if(mode==='witness'){
  const a='    function previewQuietSpecifiedScan(node,stored,action){', b='    function knownStationaryCargoForScan(state) {';
  const i=s.indexOf(a),j=s.indexOf(b);assert(i>=0&&j>i);
  const middle=s.slice(i,j).replace('return {envelope,inspection:{phase:"idle",session:null},barrier};','return {envelope,inspection:{phase:"idle",session:null},barrier,extraPrefix:scanPrefix?"public-prefix":lastB9?"b9-tail":null};')
   .replace('decision:{choices}}},barrier};','decision:{choices}}},barrier,extraPrefix:scanPrefix?"public-prefix":lastB9?"b9-tail":null};');
  s=s.slice(0,i)+middle+s.slice(j);
  sub('        provedQuietSpecifiedScans++;','        provedQuietSpecifiedScans++;\n        if(fixedScan.extraPrefix)globalThis.scanWitnesses.push({kind:fixedScan.extraPrefix,action:requested,source:stored.envelope,target:fixedScan.envelope,barrier:fixedScan.barrier,raw:fixedScan.inspection.session?.decision.choices});');
 }
 return s;
};
