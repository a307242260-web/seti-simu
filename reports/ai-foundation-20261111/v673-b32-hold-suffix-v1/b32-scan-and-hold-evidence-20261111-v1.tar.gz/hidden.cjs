'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),Module=require('node:module');
const [proofFile,out]=process.argv.slice(2),f=path.resolve('randomizer/game/ai/analysis-port.js');
const mod=new Module(f,module);mod.filename=f;mod.paths=Module._nodeModulePaths(path.dirname(f));
mod._compile(require('./scan-guard.cjs')(fs.readFileSync(f,'utf8'),'clean'),f);mod.loaded=true;require.cache[f]=mod;
const {open,readZ,writeZ}=require('./controlled-r3'),{createStateStore}=require(path.resolve('randomizer/game/state/state-store')),
 {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const {root,q:ref}=readZ(proofFile),alt=structuredClone(root),s=JSON.parse(alt.committedState);
assert(!alt.session);
for(const pile of [s.cards.drawPileCardIds,s.aliens.amiba.cardDeck,s.aliens.chong.cardDeck]){
 assert(pile.length>=2&&pile[0]!==pile[1]);[pile[0],pile[1]]=[pile[1],pile[0]];
}
alt.committedState=createStateStore(s).serialize().serialized;
const base=open(root),twin=open(alt),seatId='player-white',port=mod.exports.createAnalysisPort({composition:twin.c,seatId,maxCacheEntries:0});
try{
 assert.deepEqual(twin.owner(seatId),base.owner(seatId));assert.deepEqual(twin.menu(),base.menu());
 const agent=createSearchAgent({seatId,analysisPort:port}),q=agent.decide({seatId,legalActions:twin.menu()}).search;
 assert.deepEqual(twin.save(),alt);assert.deepEqual(base.save(),root);
 for(const k of ['actionId','value','realization','preparationDebt','complete','roots','lines','unresolved','selectionPlan','candidates','sharedPrefixGraph'])assert.deepEqual(JSON.parse(JSON.stringify(q))[k],ref[k],k);
 assert.equal(q.diagnostics.nativeExecutions,ref.diagnostics.nativeExecutions);
 console.log(JSON.stringify({n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,graphSame:true,rootUnchanged:true,observationSame:true}));
 writeZ(out,{alt,q,checkpoint:agent.createCheckpoint(),graphSame:true,rootUnchanged:true,observationSame:true});
}finally{port.close();twin.dispose();base.dispose();}
