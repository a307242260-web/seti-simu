'use strict';
const assert=require('node:assert/strict'), fs=require('node:fs');
const {open}=require('./native-late-r3');
const before=require('./v661-r4-full-preflight-20261109-v1.json');
const m=open(before.checkpoint);
try {
 const after=m.automatic();
 assert(after.complete);assert.deepEqual(m.save(),before.checkpoint);
 const record={prior:{actionId:before.actionId,native:before.nativeInputs,ms:before.milliseconds,source:before.source},
  corrected:{action:after.a.summary,actionId:after.a.actionId,value:after.value,native:after.n,ms:after.ms,complete:after.complete},rootUnchanged:true};
 fs.writeFileSync(process.argv[2],JSON.stringify(record,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(record));
} finally {m.dispose();}
