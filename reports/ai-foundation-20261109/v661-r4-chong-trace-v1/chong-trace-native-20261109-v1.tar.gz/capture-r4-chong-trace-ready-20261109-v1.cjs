'use strict';
const assert = require('node:assert/strict'), fs = require('node:fs'), path = require('node:path'), z = require('node:zlib'), Module = require('node:module');
const { open, seat } = require('./native-late-r3');
const file = path.resolve('randomizer/game/ai/analysis-port.js');
const mod = new Module(file,module); mod.filename = file; mod.paths = Module._nodeModulePaths(path.dirname(file));
const hook = '    function executeCurrent(current) {', code = fs.readFileSync(file, 'utf8');
assert.equal(code.split(hook).length, 2);
mod._compile(code.replace(hook, hook + '\n      globalThis.captureChongReady(current, loadedEnvelope);'), file);
const { createAnalysisPort } = mod.exports;
const { createSearchAgent } = require(path.resolve('randomizer/game/ai/search-agent'));
const input = JSON.parse(z.gunzipSync(fs.readFileSync(process.argv[2]))).rows.find(row => row.input === 359);
const roots = {};
globalThis.captureChongReady = (action, envelope) => {
  if (!envelope) return;
  if (!roots.direct && action.family === 'complete_task' && action.target?.ruleId === 'trace' && !envelope.session)
    roots.direct = { action, envelope };
  if (!roots.confirm && action.family === 'accept_optional_effect' && /^confirm:chong_task:.*:trace$/.test(action.target?.choiceId))
    roots.confirm = { action, envelope };
};
const m = open(input.root), port = createAnalysisPort({ composition: m.c, seatId: seat, maxCacheEntries: 0 });
try {
  const result = createSearchAgent({ seatId: seat, analysisPort: port }).decide({ seatId: seat, legalActions: m.menu() }).search;
  assert(result.complete && !result.unresolved.length);
  assert.deepEqual(m.save(), input.root);
  assert.deepEqual(Object.keys(roots).sort(), ['confirm', 'direct']);
  fs.writeFileSync(process.argv[3], z.gzipSync(JSON.stringify(roots)+'\n'), {flag:'wx'});
} finally { port.close(); m.dispose(); }
