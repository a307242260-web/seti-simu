'use strict';
const assert = require('node:assert/strict'), fs = require('node:fs'), path = require('node:path'), z = require('node:zlib');
const { open, seat } = require('./native-late-r3');
const { createAnalysisPort } = require(path.resolve('randomizer/game/ai/analysis-port'));
const { createSearchAgent } = require(path.resolve('randomizer/game/ai/search-agent'));
const roots = JSON.parse(z.gunzipSync(fs.readFileSync(process.argv[2])));
const facts = [];
const selected = (m, pred) => { const a = m.menu().find(pred); assert(a, m.menu().map(a => a.summary).join(' / ')); return m.apply(a); };
const hidden = 'hidden_chong_task_fossils';
const action = id => a => a.target?.choiceId === id;
for (const [kind, fixture] of Object.entries(roots)) {
  const m = open(fixture.envelope);
  try {
    const beforeScore = m.player().resources.score;
    const initialFossils = m.state().aliens.chong.planetFossilIds;
    m.apply(fixture.action);
    assert.deepEqual(m.menu().map(a=>a.target.planetId), ['jupiter','saturn']);
    assert(m.menu().every(a=>a.target.fossilId==null));
    const beforePeek = m.save();
    const normal = m.c.projection({ playerId:seat, role:'player' });
    const probe = () => {
      const saved = m.save(), port = createAnalysisPort({ composition:m.c, seatId:seat, maxCacheEntries:0 });
      try {
        const root = port.openRoot();
        const a = root.legalActions.find(action('chong-task-planet:jupiter'));
        const child = port.expand(root, a.actionId);
        assert.equal(child.status,'information-barrier');
        assert.equal(child.boundary,hidden);
        assert.deepEqual(child.legalActions,[]);
        assert(!JSON.stringify(child.observation).includes('fossil_02'));
        port.close();
        const searched = createSearchAgent({ seatId:seat, analysisPort:port }).decide({ seatId:seat, legalActions:m.menu() }).search;
        assert(searched.complete && !searched.unresolved.length);
        assert.deepEqual(m.save(),saved);
        return { chosen:searched.actionId, value:searched.value, native:searched.diagnostics.nativeExecutions,
          roots:searched.roots.map(r=>[r.actionId,r.value,r.realization,r.preparationDebt]) };
      } finally { port.close(); }
    };
    const untouched = probe();
    const swapped = structuredClone(beforePeek);
    const swap = state => {
      const {planetFossilIds:ids, fossilsById:tokens}=state.aliens.chong;
      ids.jupiter[0]='fossil_06';ids.saturn[0]='fossil_02';
      tokens.fossil_02.planetId='saturn';tokens.fossil_06.planetId='jupiter';
    };
    const committed = JSON.parse(swapped.committedState);
    swap(committed);swapped.committedState=JSON.stringify(committed);
    swap(swapped.session.session.baseState);swap(swapped.session.session.workingState);
    m.restore(swapped);
    assert.deepEqual(m.c.projection({ playerId:seat, role:'player' }), normal);
    assert.deepEqual(probe(),untouched);
    m.restore(beforePeek);
    selected(m,action('chong-task-planet:jupiter'));
    const atReward = m.save();
    const actor = m.c.projection({ playerId:seat, role:'player' });
    assert.deepEqual(actor.decision.choices.map(a=>a.target.fossilId), initialFossils.jupiter);
    for (const viewer of [{playerId:'player-blue',role:'player'}, {role:'spectator'}]) {
      assert.equal(m.c.projection(viewer).decision,null);
    }
    const decision = m.c.inspect();
    assert.equal(decision.session.irreversibleBarrier.code, hidden);
    assert.equal(decision.session.controls.canUndo,false);
    const rng = m.state().meta.rngState;
    selected(m,action('chong-task-fossil:fossil_02'));
    const end = m.save();
    assert.equal(m.player().resources.score, beforeScore+7);
    assert.deepEqual(m.state().aliens.chong.planetFossilIds,initialFossils);
    assert.deepEqual(m.state().meta.rngState,rng);
    m.restore(atReward);
    selected(m,action('chong-task-fossil:fossil_02'));
    assert.deepEqual(m.save(),end);
    m.restore(atReward);
    selected(m,action('chong-task-fossil:fossil_03'));
    assert.equal(m.player().resources.score,beforeScore+3);
    assert(m.menu().some(a=>a.family==='choose_card'));
    assert.deepEqual(m.state().aliens.chong.planetFossilIds,initialFossils);
    facts.push({ kind, beforeScore, fixedScore:beforeScore+7, publicPickScore:beforeScore+3, planetChoice:untouched,
      noHiddenPeekInSearch:true, privateChoiceOnlyOwner:true, restoredResultExact:true, noFossilRemoved:true, rngExact:true });
  } finally { m.dispose(); }
}
fs.writeFileSync(process.argv[3],JSON.stringify(facts,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(facts));
