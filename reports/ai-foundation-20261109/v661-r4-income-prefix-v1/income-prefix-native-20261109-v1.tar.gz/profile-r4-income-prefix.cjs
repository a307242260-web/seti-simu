'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const [source,out]=process.argv.slice(2),{open,seat}=require('./native-late-r3');
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
let js=fs.readFileSync(file,'utf8');
const hooks=[
 ['    function executeCurrent(current) {','\n      globalThis.noteR4IncomeInput(current,loadedEnvelope?.session?.session);'],
];
const a='      let spec=null;\n      if(owner.mainActionCompleted';
const b='      if(!variants){variants=new Map();turnTailSpecs.set(node,variants);}variants.set(kind,spec);return spec;';
assert.equal(js.split(a).length,2);assert.equal(js.split(b).length,2);
js=js.replace(a,`      let spec=null;
      if(kind==="data-end-turn"&&computerPolicy?.plans[0]?.goal.kind==="income")
        globalThis.noteR4IncomeProof(state,stored,"guards",{
          knownAmibaTail,publicAmibaPlainEnd,publicAmibaCurrencyTail,fixedR4DeepSpace,quietR4ChongData,
          quietR4ChongEnd,knownHand:owner.hand.every(knownOrOpaque),knownReserve:owner.reservedCards.every(c=>knownCards(stored.envelope).has(c.id)),
          inert:hasPostMainInertReservations(endGuard,false,true,true),end:!!end
        });
      if(owner.mainActionCompleted`);
js=js.replace(b,`      if(kind==="data-end-turn"&&computerPolicy?.plans[0]?.goal.kind==="income")
        globalThis.noteR4IncomeProof(state,stored,"answer",{proof:spec?.proof||null,inputs:spec?.requiredNativeInputs||null});
`+b);
const d='              // Keep an exact value for every root option.';
assert.equal(js.split(d).length,2);
js=js.replace(d,`              if(plan.goal.kind==="income")
                globalThis.noteR4IncomeProof(state,stored,"compound",{available:compound.available,reason:compound.reason,primaryOnly:compound.primaryOnly,
                  goals:compound.plans?.map(x=>x.goal.id),netGain:compound.netGain});
`+d);
const e='    function executeCurrent(current) {';
assert.equal(js.split(e).length,2);js=js.replace(e,hooks[0].join(''));
mod._compile(js,file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
let guards,inputs;
const identify=s=>{
 const p=s.players.players.find(p=>p.id===seat);
 return JSON.stringify([p.resources,p.techState,p.hand.map(c=>c.id||null),p.reservedCards.map(c=>c.id),
  p.dataState.placedTokens.map(t=>[t.placementKind,t.placementSlot,t.blueSlot]),Object.keys(s.aliens.chong?.transportTasksByRocketId||{})]);
};
globalThis.noteR4IncomeInput=(a,s)=>{
 if(a.family==='choose_target'&&a.summary.endsWith('放置位 1')&&s?.baseState&&s.journal.actions[0]?.action.family==='place_data')
  inputs.push({id:identify(s.baseState),base:s.baseState});
};
globalThis.noteR4IncomeProof=(state,stored,type,x)=>{
 const k=identify(state),q=guards.get(k)||{};
 q[type]=x;
 q.barrier=stored.informationBarrier?.code||null;
 q.intent=stored.intent?.path?.length??null;
 q.control=!!stored.resourceControl;
 guards.set(k,q);
};
const rows=[];
for(const row of JSON.parse(z.gunzipSync(fs.readFileSync(source))).rows.filter(r=>r.input>=355)){
 const m=open(row.root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  guards=new Map();inputs=[];
  const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),row.root);
  const rows2=inputs.map(({id,base})=>{
   const p=base.players.players.find(p=>p.id===seat);
   return {pool:p.resources.availableData,wallet:[p.resources.credits,p.resources.energy,p.resources.publicity],
    cards:p.hand.map(c=>c.cardId),reserved:p.reservedCards.map(c=>c.cardId),
    jobs:Object.values(base.aliens.chong?.transportTasksByRocketId||{}).map(x=>x.delivered),check:guards.get(id)||null};
  });
  rows.push({input:row.input,rows:rows2});
  console.log(JSON.stringify(rows.at(-1)));
 }finally{p.close();m.dispose();}
}
fs.writeFileSync(out,JSON.stringify(rows,null,2)+'\n',{flag:'wx'});
