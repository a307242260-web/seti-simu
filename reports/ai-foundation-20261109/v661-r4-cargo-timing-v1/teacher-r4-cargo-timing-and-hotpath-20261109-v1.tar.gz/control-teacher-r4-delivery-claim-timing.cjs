'use strict';
const fs=require('node:fs'),z=require('node:zlib'),assert=require('node:assert/strict');
const [helper,cold,history,out]=process.argv.slice(2),{open}=require(helper),roots=JSON.parse(z.gunzipSync(fs.readFileSync(cold))),h=JSON.parse(fs.readFileSync(history)).replaySteps;
const start=roots.rows.find(x=>x.summary.i===354).root,m=open(start),rows=[];
for(const mode of ['claim-at-end','teacher-wait']){
 m.restore(start);const accepted=[],stages=[];
 const first=m.menu().find(a=>a.target.choiceId?.startsWith((mode==='claim-at-end'?'confirm':'skip')+':chong_task:'));
 assert(first);accepted.push(m.apply(first));stages.push({at:354,w:m.facts(),envelope:m.save()});
 for(let i=355;i<=(mode==='claim-at-end'?358:359);i++)accepted.push(m.apply(h[i-1].action));
 const end=m.save();stages.push({at:359,w:m.facts(),envelope:end});m.restore(start);accepted.forEach(m.apply);assert.deepEqual(m.save(),end);
 rows.push({mode,accepted,stages,end});console.log(JSON.stringify({mode,inputs:accepted.length,stages:stages.map(x=>({at:x.at,assets:x.w.wallet,established:x.w.final,computer:x.w.computer,blue:x.w.blue}))}));
}
m.restore(start);m.dispose();fs.writeFileSync(out,z.gzipSync(JSON.stringify(rows)+'\n'),{flag:'wx'});
