'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),assert=require('node:assert/strict');
const [helper,src,history,out]=process.argv.slice(2),{open}=require(helper),read=p=>JSON.parse(fs.readFileSync(p));
const orig=read(src).mismatch.source,h=read(history).replaySteps,m=open(orig),rows=[],accepted=[];
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port')),agent=require(path.resolve('randomizer/game/ai/search-agent'));
try{
 for(let i=301;i<=359;i++){
  const target=h[i-1].action;
  if([317,318,351,354,359].includes(i)){
   const root=m.save(),menu=m.menu(),p=createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});
   try{
    const q=agent.createSearchAgent({seatId:'player-white',analysisPort:p}).decide({seatId:'player-white',legalActions:menu}).search;
    assert.deepEqual(m.save(),root);
    const f=m.facts(),top=q.roots.find(x=>x.actionId===target.actionId),chosen=menu.find(a=>a.actionId===q.actionId);
    const summary={i,teacher:target.summary,chosen:chosen?.summary,teacherRoot:top,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,
      value:q.value,assets:{wallet:f.wallet,probes:f.probes.map(r=>[r.id,r.fossilId,r.sectorX,r.sectorY]),hand:f.hand.map(c=>c[1])}};
    rows.push({summary,root,menu,q});console.log(JSON.stringify(summary));
   }catch(e){rows.push({i,error:e.message,root,menu});console.log(JSON.stringify({i,error:e.message}));}
   finally{p.close();}
  }
  accepted.push(m.apply(target));
 }
 const end=m.save();m.restore(orig);accepted.forEach(m.apply);assert.deepEqual(m.save(),end);m.restore(orig);
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({rows,accepted,end,rootAndRngExact:true})+'\n'),{flag:'wx'});
}finally{m.dispose();}
