'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict'),[helper,fixture,out]=process.argv.slice(2);
const old=Module._extensions['.js'],events=[];
Module._extensions['.js']=function(m,p){
 if(!p.endsWith('/local-decision-plans.js'))return old(m,p);
 const code=fs.readFileSync(p,'utf8'),anchor='if(payload?.kind===\'task\')return deferredPublicityTask';
 assert(code.includes(anchor));return m._compile(code.replace(anchor,`if(payload?.kind==='task')globalThis.__taskAudit(state,seatId,actions,session,payload);
  if(payload?.kind==='task')return deferredPublicityTask`),p);
};
globalThis.__taskAudit=(s,id,actions,session,payload)=>{
 const p=s.players.players.find(x=>x.id===id);
 events.push({payload,queue:session.queue.map(e=>[e.type,e.ownerId,e.payload?.didPass]),turn:s.turn.roundNumber,main:p.mainActionCompleted,
  publicity:p.resources.publicity,credits:p.resources.credits,score:p.resources.score,passed:s.turn.passedPlayerIds,phase:session.phase,
  actions:actions.map(a=>a.target.choiceId),species:Object.values(s.aliens.aliens).map(x=>[x.revealed,x.revealed?x.alienId:null]),
  marks:Object.values(s.finalScoring.tiles).flatMap(x=>x.marks).filter(x=>x.playerId===id).map(x=>x.threshold)});
};
const {open}=require(helper),root=require(fixture).checkpoint,m=open(root);
try{const q=m.automatic();assert.equal(q.n,1361);assert.deepEqual(root,m.save());
 fs.writeFileSync(out,JSON.stringify(events,null,2)+'\n',{flag:'wx'});
 const sizes={};for(const x of events){const k=JSON.stringify([x.payload.kind,x.queue,x.main,x.passed,x.species,x.marks]);sizes[k]=(sizes[k]||0)+1;}
 console.log(JSON.stringify({n:events.length,k:Object.entries(sizes).sort((a,b)=>b[1]-a[1]).slice(0,10)}));
}finally{m.dispose();}
