'use strict';
const fs=require('node:fs'),z=require('node:zlib'),assert=require('node:assert/strict');
const [helper,cargo,source,out]=process.argv.slice(2),{open}=require(helper),a=JSON.parse(z.gunzipSync(fs.readFileSync(cargo))),historical=JSON.parse(fs.readFileSync(source)).replaySteps;
const rows=[];
for(const [timing,fund,mode] of [['none',false,'matched'],['before-launch',true,'skip'],['before-launch',true,'move8']]){
 const x=a.find(r=>r.timing===timing&&r.fund===fund),m=open(x.end),accepted=[],stages=[],changes=[];let stop;
 try{for(let i=301;i<=359;i++){
  const w=historical[i-1].action,menu=m.menu();let legal=menu.find(a=>a.actionId===w.actionId&&a.actorId===w.actorId);
  if(!legal&&fund&&[318,351].includes(i)){
   if(i===318&&mode==='move8')legal=menu.find(a=>a.target?.rocketId===8&&a.target.deltaY===-1);
   else legal=menu.find(a=>a.target?.skip===true||a.target?.mode==='skip');
   if(legal)changes.push({i,from:w.summary,to:legal.summary});
  }
  if(!legal&&mode==='move8'&&i===323){
   legal=menu.find(a=>a.target?.choiceId?.startsWith('confirm:chong_task:')&&a.summary.includes('chong_6'));
   if(legal)changes.push({i,from:w.summary,to:legal.summary});
  }
  if(!legal&&mode==='move8'&&[324,325].includes(i)
    &&!Object.values(m.state().aliens.chong.transportTasksByRocketId).some(t=>t.cardId.includes('chong-6'))){
   changes.push({i,from:w.summary,to:'already delivered by previous free move'});continue;
  }
  if(!legal&&fund&&[354,359].includes(i)&&!m.state().aliens.chong.transportTasksByRocketId[5]){
   changes.push({i,from:w.summary,to:'already delivered'});continue;
  }
  if(!legal){stop={i,expected:w,legal:menu,facts:m.facts(),envelope:m.save()};break;}
  accepted.push(m.apply(legal));
  if([301,317,318,320,323,325,351,359].includes(i))stages.push({i,assets:m.facts(),checkpoint:m.save()});
 }
 const end=m.save(),assets=m.facts();m.restore(x.end);accepted.forEach(m.apply);assert.deepEqual(m.save(),end);m.restore(x.end);
 rows.push({timing,fund,mode,accepted,stop,end,assets,stages,changes});
 console.log(JSON.stringify({timing,mode,accepted:accepted.length,changes,stop:stop&&{i:stop.i,expected:stop.expected.summary,menu:stop.legal.map(x=>x.summary).slice(-8)},wallet:assets.wallet,established:assets.final}));
 }finally{m.dispose();}
}
fs.writeFileSync(out,z.gzipSync(JSON.stringify(rows)+'\n'),{flag:'wx'});
