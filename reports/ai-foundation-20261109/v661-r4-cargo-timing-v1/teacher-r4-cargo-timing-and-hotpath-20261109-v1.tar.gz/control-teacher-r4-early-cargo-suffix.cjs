'use strict';
const fs=require('node:fs'),z=require('node:zlib'),assert=require('node:assert/strict');
const [helper,cargo,source,out]=process.argv.slice(2),{open}=require(helper),a=JSON.parse(z.gunzipSync(fs.readFileSync(cargo))),historical=JSON.parse(fs.readFileSync(source)).replaySteps;
const rows=[];
for(const [timing,fund] of [['none',false],['before-launch',false],['before-scan',false],['before-launch',true],['before-scan',true]]){
 const x=a.find(r=>r.timing===timing),m=open(x.end),accepted=[],checkpoints={};let stop;
 try{for(let i=272;i<=297;i++){
  const w=historical[i-1].action;
  if(i===280){
   checkpoints.before280={assets:m.facts(),checkpoint:m.save()};
   if(fund)accepted.push(m.act('quick_trade',a=>a.target.tradeId==='credits-for-energy'));
  }
  const legal=m.menu().find(a=>a.actionId===w.actionId&&a.actorId===w.actorId);
  if(!legal){stop={i,expected:w,legal:m.menu(),facts:m.facts(),envelope:m.save()};break;}
  accepted.push(m.apply(legal));
 }
 const end=m.save(),assets=m.facts();m.restore(x.end);accepted.forEach(m.apply);assert.deepEqual(m.save(),end);m.restore(x.end);
 rows.push({timing,fund,accepted,stop,end,assets,checkpoints});
 console.log(JSON.stringify({timing,fund,accepted:accepted.length,stop:stop&&{i:stop.i,expected:stop.expected.summary},wallet:assets.wallet,established:assets.final}));
 }finally{m.dispose();}
}
fs.writeFileSync(out,z.gzipSync(JSON.stringify(rows)+'\n'),{flag:'wx'});
