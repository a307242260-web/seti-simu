'use strict';
const fs=require('node:fs'),z=require('node:zlib'),Module=require('node:module'),path=require('node:path'),assert=require('node:assert/strict');
const [helper,teacher,official,out]=process.argv.slice(2),a=Module._extensions['.js'];
let stats;
Module._extensions['.js']=function(m,p){
 if(!p.endsWith('/randomizer/game/ai/analysis-port.js'))return a(m,p);
 let s=fs.readFileSync(p,'utf8');
 const needle='const before = comp.inspect(true);\n      if (!current';
 assert(s.includes(needle));s=s.replace(needle,`const before = comp.inspect(true);
      globalThis.__setiAuditNative(current,before);
      if (!current`);
 return m._compile(s,p);
};
globalThis.__setiAuditNative=(a,b)=>{
 const q=b.session?.decision,kind=a.family==='choose_target'||a.family==='choose_card'||a.family==='choose_payment'
   ?a.target?.kind||q?.effectType||q?.kind||'conditional':'';
 const key=kind?a.family+':'+kind:a.family;
 stats.count[key]=(stats.count[key]||0)+1;stats.actions[a.summary]=(stats.actions[a.summary]||0)+1;
};
const read=p=>JSON.parse(fs.readFileSync(p)),tr=JSON.parse(z.gunzipSync(fs.readFileSync(teacher))),{open}=require(helper),summary=[];
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port')),agent=require(path.resolve('randomizer/game/ai/search-agent'));
for(const [label,root] of [['teacher-265',tr.rows.find(x=>x.decision.input===265).before],['official-r4-first',read(official).checkpoint]]){
 stats={count:{},actions:{}};
 const m=open(root),p=createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});
 try{
  const q=agent.createSearchAgent({seatId:'player-white',analysisPort:p}).decide({seatId:'player-white',legalActions:m.menu()}).search;
  assert.deepEqual(m.save(),root);assert.equal(Object.values(stats.count).reduce((n,x)=>n+x,0),q.diagnostics.nativeExecutions);
  const top=o=>Object.entries(o).sort((a,b)=>b[1]-a[1]);
  summary.push({label,root,q,stats});
  console.log(JSON.stringify({label,action:m.menu().find(a=>a.actionId===q.actionId).summary,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,
   count:top(stats.count).slice(0,16),top:top(stats.actions).slice(0,15),d:q.diagnostics}));
 }finally{p.close();m.dispose();}
}
fs.writeFileSync(out,z.gzipSync(JSON.stringify(summary)+'\n'),{flag:'wx'});
