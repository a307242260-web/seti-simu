'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const [helper,near,far,out]=process.argv.slice(2),{open}=require(helper);
const x=JSON.parse(z.gunzipSync(fs.readFileSync(near))).rows.find(r=>r.summary.i===351);
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port')),agent=require(path.resolve('randomizer/game/ai/search-agent'));
const rows=[];
for(const [label,root] of [['final-step',x.root],['not-arriving',JSON.parse(fs.readFileSync(far))]]){
 const m=open(root),p=createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});
 try{
  const menu=m.menu(),q=agent.createSearchAgent({seatId:'player-white',analysisPort:p}).decide({seatId:'player-white',legalActions:menu}).search;
  assert.deepEqual(m.save(),root);assert(q.complete&&!q.unresolved.length);
  const delivery=q.lines[0].movementPolicy?.knownFreeScanDelivery||null;
  rows.push({label,delivery,action:menu.find(a=>a.actionId===q.actionId).summary,id:q.actionId,value:q.value,
   native:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,roots:q.roots.map(x=>[x.actionId,x.value,x.realization,x.completion])});
 }finally{p.close();m.dispose();}
}
fs.writeFileSync(out,JSON.stringify(rows,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(rows.map(({roots,...r})=>r)));
