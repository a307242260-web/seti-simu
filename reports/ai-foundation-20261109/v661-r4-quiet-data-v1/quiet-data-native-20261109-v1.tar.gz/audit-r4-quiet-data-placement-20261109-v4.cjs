'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {isDeepStrictEqual}=require('node:util'),{open,seat}=require('./native-late-r3');
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const code=fs.readFileSync(file,'utf8'),hook='      const fixedData = previewQuietFinalDataPlacement(stored, requested);';assert.equal(code.split(hook).length,2);
const tail='        return rememberPrefix(key,node,actionId,remember(key,child));';assert.equal(code.split(tail).length,2);
mod._compile(code.replace(hook,hook+`
      const witness = globalThis.auditQuietData({fixedData, stored, requested, executeCurrent, restoreEnvelope, snapshot, comp:fork.composition||fork,
        finish: (before, result) => finishChild(before, result, movementPlanning ? nextMovementIntent(node, requested) : null,
          null, stored.informationBarrier, requested, stored)});
`).replace(tail,`        assertQuietPlacementWitness(witness, child);
`+tail).replace('    function expand(node, actionId) {',`    function assertQuietPlacementWitness(witness, child) {
      globalThis.compareQuietWitness(witness, child, nodes, identity);
    }
    function expand(node, actionId) {`),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const {getBlueBonusPlacementReward,listComputerPlacedTokens}=require(path.resolve('randomizer/game/data'));
const read=file=>JSON.parse(z.gunzipSync(fs.readFileSync(path.join(__dirname,file))));
let verified, publicPickPreserved, beforeMainPreserved, declined;
globalThis.auditQuietData=({fixedData,stored,requested,executeCurrent,restoreEnvelope,snapshot,comp,finish})=>{
 const session=stored.envelope.session?.session;
 if(!session||session.queue[0]?.type!=='science_domain_place_data'||requested.family!=='choose_target')return;
 const before=session.workingState, p=before.players.players.find(p=>p.id===seat);
 if(requested.target.blueSlot&&getBlueBonusPlacementReward(p,requested.target.blueSlot)?.type==='choose_card'){
  assert(!fixedData); publicPickPreserved++;
 }
 if(requested.target.target==='computer'&&listComputerPlacedTokens(p).length===4&&!p.mainActionCompleted){
  assert(!fixedData); beforeMainPreserved++;
 }
 if(!fixedData){
  const t=before.turn, q=session.queue[0], slot=requested.target.blueSlot;
  if(p.mainActionCompleted&&((requested.target.target==='computer'&&listComputerPlacedTokens(p).length===4)
    ||slot===1&&getBlueBonusPlacementReward(p,1)?.type==='energy'
    ||slot===3&&['credits','publicity'].includes(getBlueBonusPlacementReward(p,3)?.type))){
   const reasons=[stored.intent?'intent':null,stored.resourceControl?'resource-control':null,session.queue.length!==1?'queue':null,
    session.interruptContext?'interrupt':null,session.irreversibleBarrier?'barrier':null,q.allowQuickActions?'quick':null,
    t.cardTurnEventBonuses?.length?'turn-bonus':null,Object.values(before.aliens.chong?.transportTasksByRocketId||{}).some(j=>!j.delivered)?'in-transit':null].filter(Boolean);
   const key=reasons.join('+')||'other';declined[key]=(declined[key]||0)+1;
  }
  return;
 }
 restoreEnvelope(stored.envelope,true);
 const executed=executeCurrent(requested);assert(executed.result.ok);
 const native=snapshot(comp);
 assert.equal(native.session,null);
 const actual=JSON.parse(native.committedState), preview=fixedData.state;
 for(const key of new Set([...Object.keys(preview),...Object.keys(actual)]))
  assert(isDeepStrictEqual(actual[key],preview[key]),`${fixedData.kind} differs in ${key}`);
 const q=actual.players.players.find(p=>p.id===seat);
 assert.deepEqual(actual.meta.rngState,before.meta.rngState);
 verified.push({kind:fixedData.kind,score:q.resources.score-p.resources.score,publicity:q.resources.publicity-p.resources.publicity,
  data:q.resources.availableData-p.resources.availableData,carriedIntent:Boolean(stored.intent),priorBarrier:stored.informationBarrier?.code||null,checkpointExact:true}); return finish(executed.before,executed.result);
};
globalThis.compareQuietWitness=(witness, child, nodes, identity)=>{
 assert.equal(child.status,witness.status);assert.equal(child.boundary,witness.boundary);
 assert.deepEqual(child.legalActions,witness.legalActions);
 assert.deepEqual(nodes.get(child).intent,nodes.get(witness).intent);
 assert.equal(identity(child),identity(witness));
};
const baseline=read('candidate-chong-peek-paired-native-20261109-v2.json.gz'), candidate=read(process.argv[2]), results=[];
for(const r of candidate.rows){
 const old=baseline.rows.find(x=>x.input===r.input), key=x=>[x.actionId,x.value,x.ranking,x.quotes,x.root];assert.deepEqual(key(old),key(r));
 if(r.input<355)continue;
 const m=open(r.root), port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  verified=[]; publicPickPreserved=0; beforeMainPreserved=0; declined={};
  const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),r.root);
  assert.equal(verified.length,old.native-r.native);assert.equal(q.diagnostics.nativeExecutions,old.native);
  assert(publicPickPreserved>0);
  results.push({input:r.input,beforeNative:old.native,afterNative:r.native,beforeMs:old.ms,afterMs:r.ms,
    publicPickPreserved,beforeMainPreserved,proofCounts:q.analysis.provedFinalDataPlacements,declined,verified});
 }finally{port.close();m.dispose();}
}
assert(results.some(x=>x.proofCounts.computer5));assert(results.some(x=>x.proofCounts['blue3:publicity']));
const official=require('./v661-r4-full-preflight-20261109-v1.json');
const oldOfficial=require('./r4-quiet-data-official-profile-20261109-v2.json');
const newOfficial=require('./r4-quiet-data-intent-official-cold-20261109-v1.json').corrected;
const m=open(official.checkpoint), port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try {
 verified=[]; publicPickPreserved=0; beforeMainPreserved=0; declined={};
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),official.checkpoint);
 assert.equal(q.actionId,official.actionId);assert.equal(q.actionId,newOfficial.actionId);
 assert.equal(JSON.stringify(q.roots.map(r=>[r.actionId,r.value,r.realization,r.preparationDebt])),JSON.stringify(oldOfficial.roots));
 assert.equal(verified.length,official.nativeInputs-newOfficial.native);
 assert.equal(q.diagnostics.nativeExecutions,official.nativeInputs);
 assert(publicPickPreserved>0&&beforeMainPreserved>0);
 results.push({input:'official-r4-start',beforeNative:official.nativeInputs,afterNative:newOfficial.native,
   beforeMs:official.milliseconds,afterMs:newOfficial.ms,publicPickPreserved,beforeMainPreserved,
   proofCounts:q.analysis.provedFinalDataPlacements,declined,verified});
}finally{port.close();m.dispose();}
fs.writeFileSync(process.argv[3],JSON.stringify({results,exactRankingAndSourceRng:true},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(results.map(({verified,...row})=>row)));
