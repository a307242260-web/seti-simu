'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {open,seat}=require('./native-late-r3');
const {checkpoint:official}=require('./v661-r4-full-preflight-20261109-v1.json');
const expected=require('./r4-shared-scoring-projection-cold-20261109-v1.json');
const teacher=JSON.parse(z.gunzipSync(fs.readFileSync(path.join(__dirname,'candidate-r4-active-task-preview-native-20261109-v1.json.gz')))).rows;
const [kind,input]=process.argv.slice(2),id=input==='official-r4'?input:Number(input);
const root=id==='official-r4'?official:teacher.find(x=>x.input===id).root,b=expected.find(x=>x.label===id);
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port')),{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const m=open(root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 const ranking=q.roots.map(x=>[x.actionId,x.value,x.realization,x.preparationDebt]);
 assert.equal(JSON.stringify(ranking),JSON.stringify(b.ranking));assert.equal(q.actionId,b.action);assert.equal(q.value,b.value);
 const graph=crypto.createHash('sha256').update(JSON.stringify(q.lines,(key,value)=>key==='routingNodes'?undefined:value)).digest('hex');
 assert.equal(graph,b.graph);
 const proof=Object.fromEntries(Object.entries(q.analysis).filter(([k])=>k.startsWith('provedChong')));
 const native=q.diagnostics.nativeExecutions,ms=q.rootAndSearchMilliseconds;
 assert.equal(native,b.native-Object.values(proof).reduce((n,v)=>n+v,0));
 console.log(JSON.stringify({kind,input:id,ms,native,proof,graph,nodes:q.analysis.nodeCount,logical:q.diagnostics.transitions,value:q.value,action:q.actionId}));
}finally{p.close();m.dispose();}
