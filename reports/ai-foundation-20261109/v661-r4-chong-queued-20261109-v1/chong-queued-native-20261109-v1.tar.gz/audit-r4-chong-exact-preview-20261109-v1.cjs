'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),crypto=require('node:crypto'),Module=require('node:module'),assert=require('node:assert/strict');
const equal=require('node:util').isDeepStrictEqual;
const {open,seat}=require('./native-late-r3');
const baseline=require('./r4-shared-scoring-projection-cold-20261109-v1.json');
const candidate=require('./r4-chong-queued-tasks-cold-20261109-v2.json');
const teacher=JSON.parse(z.gunzipSync(fs.readFileSync(path.join(__dirname,'candidate-r4-active-task-preview-native-20261109-v1.json.gz')))).rows;
const {checkpoint:official}=require('./v661-r4-full-preflight-20261109-v1.json');
const p=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(p,module);
mod.filename=p;mod.paths=Module._nodeModulePaths(path.dirname(p));
let js=fs.readFileSync(p,'utf8');
const types=['TransportInputs','TraceSkips','TraceMenus','EndMenus','QueuedTasks'];
for(const name of types){
 const anchor=`        provedChong${name}++;`;assert.equal(js.split(anchor).length,2);
 js=js.replace(anchor,anchor+`
        globalThis.auditChongPreview({name:'${name}',stored,requested,child,actual:nodes.get(child),
          restoreEnvelope,executeCurrent,snapshot,comp:fork.composition||fork,
          menu:legalActions,observe:project,barrier:stored.informationBarrier});`);
}
mod._compile(js,p);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const clean=s=>s&&JSON.parse(JSON.stringify(s).replace(/effect-session-[0-9]+/g,'effect-session-audited'));
const digest=v=>crypto.createHash('sha256').update(JSON.stringify(v)).digest('hex');
let rows=[];
globalThis.auditChongPreview=({name,stored,requested,child,actual,restoreEnvelope,executeCurrent,snapshot,comp,menu,observe,barrier})=>{
 const e=actual.envelope;
 const prefix=stored.envelope.session?.session;
 restoreEnvelope(stored.envelope,true);
 const outcome=executeCurrent(requested);assert(outcome.result.ok);
 const raw=snapshot(comp);
 const a=JSON.parse(e.committedState),b=JSON.parse(raw.committedState);
 for(const k of Object.keys(b))assert(equal(a[k],b[k]),`committed ${name} ${k}`);
 if(raw.session){
  const expected=clean(raw.session),got=clean(e.session);
  for(const k of Object.keys(expected.session)){
   if(!equal(expected.session[k],got.session[k])){
    const diff=expected.session[k]&&typeof expected.session[k]==='object'?Object.keys(expected.session[k]).filter(a=>!equal(expected.session[k][a],got.session[k][a])):[];
    if(k==='baseState')for(const field of diff){
      const first=expected.session[k][field],second=got.session[k][field];
      console.error(field,Object.keys(first).filter(x=>!equal(first[x],second[x])).map(x=>[x,JSON.stringify(first[x]).slice(0,380),JSON.stringify(second[x]).slice(0,380)]));
    }
    throw new Error(`session ${name} ${k} ${diff} ${requested.actionId}`);
   }
  }
  assert.equal(expected.schemaVersion,got.schemaVersion);assert.equal(expected.replayCursor,got.replayCursor);
 }else assert.equal(e.session,null);
 const rawMenu=menu(comp),rawObs=observe(comp,true);
 restoreEnvelope(e);
 const afterMenu=menu(comp),afterObs=observe(comp,true);
 assert.deepEqual(clean(afterMenu),clean(rawMenu),name);
 assert.deepEqual(clean(afterObs),clean(rawObs),name);
 assert.equal(actual.informationBarrier?.code??null,barrier?.code??null);
 rows.push({name,actionId:requested.actionId,rule:requested.target?.ruleId||prefix?.queue[0]?.payload?.ruleId||null,
  choice:requested.target?.choiceId||null,status:child.status,barrier:child.boundary,remaining:e.session?.session.queue.map(q=>q.type)||[],
  legal:rawMenu.length,stateSha:digest(b),sessionSha:raw.session?digest(clean(raw.session)):null,rngSha:digest(b.meta.rngState)});
};
const results=[];
for(const r of [{input:'official-r4',root:official},...teacher]){
 rows=[];const m=open(r.root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),r.root);
  const before=baseline.find(x=>x.label===r.input),after=candidate.find(x=>x.label===r.input);
  assert.equal(q.actionId,before.action);assert.equal(q.value,before.value);
  assert.equal(JSON.stringify(q.roots.map(x=>[x.actionId,x.value,x.realization,x.preparationDebt])),JSON.stringify(before.ranking));
  assert.equal(q.diagnostics.nativeExecutions,before.native);
  assert.equal(q.diagnostics.nativeExecutions-rows.length,after.native);
  const counts=Object.fromEntries(types.map(n=>[n,rows.filter(x=>x.name===n).length]));
  for(const [k,v] of Object.entries(counts))assert.equal(v,q.analysis['provedChong'+k]);
  results.push({input:r.input,extraNativeChecks:rows.length,counts,rows});
 }finally{port.close();m.dispose();}
}
fs.writeFileSync(process.argv[2],z.gzipSync(JSON.stringify(results)+'\n'),{flag:'wx'});
console.log(JSON.stringify(results.map(({rows,...x})=>x)));
