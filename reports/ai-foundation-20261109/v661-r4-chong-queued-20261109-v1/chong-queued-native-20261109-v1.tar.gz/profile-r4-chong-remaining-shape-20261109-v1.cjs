'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),Module=require('node:module'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const baseline=require('./r4-shared-scoring-projection-cold-20261109-v1.json');
const roots=JSON.parse(z.gunzipSync(fs.readFileSync(path.join(__dirname,'candidate-r4-active-task-preview-native-20261109-v1.json.gz')))).rows.filter(r=>r.input>=355);
const p=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(p,module);
mod.filename=p;mod.paths=Module._nodeModulePaths(path.dirname(p));
const js=fs.readFileSync(p,'utf8');
const hook='      if(quietMoveMenu&&!moveMenuTemplate)rememberMoveMenu(child,requested);';
assert.equal(js.split(hook).length,2);
mod._compile(js.replace(hook,`      if(requested.family==='complete_task'||requested.family==='accept_optional_effect'||requested.family==='end_turn'){
        globalThis.tallyChong({node,stored,requested,child,childStored:nodes.get(child),knownCards:knownCards(stored.envelope),fossils:visibleRootCargo(),
          inputState:readIdentityState(stored.envelope),outputState:readIdentityState(nodes.get(child).envelope),result});
      }
`+hook),p);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
let facts=[];
const owner=s=>s.players.players.find(p=>p.id===seat);
const digest=(a)=>JSON.stringify(a??null);
const queue=s=>s?.queue.map(x=>[x.type,x.payload?.kind??null,x.payload?.ruleId??null,x.allowQuickActions,x.ownerId])||[];
globalThis.tallyChong=({node,stored,requested,child,childStored,knownCards,fossils,inputState:before,outputState:after,result})=>{
 const old=stored.envelope.session?.session,next=childStored.envelope.session?.session;
 const phase=requested.family==='complete_task'?'active':requested.family==='end_turn'?'end':(requested.target?.choiceId||'').split(':')[0];
 const task=phase==='active'?requested.target:phase==='end'?next?.queue?.[0]?.payload:old?.queue?.[0]?.payload;
 if(!task||!['transport','trace'].includes(task.ruleId))return;
 const player=owner(before),later=owner(after);
 const jobs=Object.values(before.aliens.chong?.transportTasksByRocketId||{});
 const changed=Object.keys(before).filter(k=>digest(before[k])!==digest(after[k]));
 const delta=Object.fromEntries(Object.entries(later.resources).filter(([k,v])=>v!==player.resources[k]).map(([k,v])=>[k,v-player.resources[k]]));
 facts.push({phase,rule:task.ruleId,card:task.cardInstanceId,node:node.status,child:child.status,main:player.mainActionCompleted,turn:before.turn.turnNumber,
  barrier:stored.informationBarrier?.code||null,nextBarrier:childStored.informationBarrier?.code||null,
  beforeQueue:queue(old),afterQueue:queue(next),afterMenu:child.legalActions.map(a=>[a.family,a.target?.choiceId]),hasIntent:!!stored.intent,
  resourceControl:!!stored.resourceControl,known:knownCards.has(task.cardInstanceId),allKnown:player.reservedCards.every(c=>knownCards.has(c.id)),
  jobs:jobs.map(j=>[j.fossilId,j.delivered,fossils.has(j.fossilId)]),n:player.resources.availableData,changed,delta,
  active:before.turn.activePlayerIds.filter(id=>!before.turn.passedPlayerIds.includes(id)).length,
  resultBarrier:result.irreversibleBarrier?.code||null,events:next?.journal.events.map(e=>e.type)||[],
  version:[before.meta.stateVersion,after.meta.stateVersion],sequence:changed.includes('meta')?Object.keys(after.meta).filter(k=>digest(after.meta[k])!==digest(before.meta[k])):[]});
};
const rows=[];
for(const r of roots){
 const m=open(r.root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  facts=[];const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),r.root);
  const b=baseline.find(b=>b.label===r.input);
  assert.equal(q.diagnostics.nativeExecutions,b.native);
  assert.equal(JSON.stringify(q.roots.map(x=>[x.actionId,x.value,x.realization,x.preparationDebt])),JSON.stringify(b.ranking));
  rows.push({input:r.input,native:b.native,facts});
 }finally{port.close();m.dispose();}
}
fs.writeFileSync(process.argv[2],z.gzipSync(JSON.stringify(rows)+'\n'),{flag:'wx'});
for(const r of rows){const groups={};for(const f of r.facts){const k=[f.phase,f.rule,f.main,f.child,f.beforeQueue.map(x=>x[0]).join('/'),f.afterQueue.map(x=>x[0]).join('/'),f.active].join('|');groups[k]=(groups[k]||0)+1;} console.log(JSON.stringify({input:r.input,groups}));}
