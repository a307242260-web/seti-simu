'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),z=require('node:zlib');
const {open,seat}=require('./native-late-r3');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const base=require('./r4-paid-move-official-profile-20261109-v1.json');
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const js=fs.readFileSync(file,'utf8'),anchor='      if(endPrelude?.task&&!quietEndPreludeTemplate)rememberQuietEndPrelude(requested,child,endPrelude);';
assert.equal(js.split(anchor).length,2);
mod._compile(js.replace(anchor,`
      if(taskSession?.queue[0]?.type===scienceSession.EFFECT_TYPES.SCAN_STEP&&taskSession.queue[0].payload?.options?.mode==="public"&&requested.family==="choose_card")
        globalThis.observeScan4(stored,requested,nodes.get(child),child,result,knownCards(stored.envelope));
`+anchor),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const rows=[];
globalThis.observeScan4=(stored,action,dst,child,result,known)=>{
 const a=stored.envelope.session.session,b=dst.envelope.session?.session,x=a.workingState,y=b?.workingState||JSON.parse(dst.envelope.committedState);
 const changed=(l,r,pre='',out=[])=>{
  if(Object.is(l,r)||out.length>=35)return out;
  if(l&&r&&typeof l==='object'&&typeof r==='object')for(const k of new Set([...Object.keys(l),...Object.keys(r)]))changed(l[k],r[k],pre+'.'+k,out);
  else out.push(pre);return out;
 };
 const owner=x.players.players.find(p=>p.id===seat);
 rows.push({source:a.journal.actions[0].action.family,step:action.target.choiceId==='public:done'?'done':'consume-known-public-card',
  queue:a.queue.map(e=>e.type),afterQueue:b?.queue.map(e=>e.type)||[],status:child.status,
  barrier:result.irreversibleBarrier?.code||null,changed:changed(x,y),rngExact:JSON.stringify(x.meta.rngState)===JSON.stringify(y.meta.rngState),
  reservedKnown:owner.reservedCards.every(c=>known.has(c.id)),turnBonuses:x.turn.cardTurnEventBonuses?.length||0,
  transit:Object.values(x.aliens.chong?.transportTasksByRocketId||{}).filter(x=>!x.delivered).length,
  priorBarrier:stored.informationBarrier?.code||null,control:!!stored.resourceControl,actions:child.legalActions.length,
  action});
};
const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const r=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(r.complete&&!r.unresolved.length);assert.deepEqual(m.save(),root);assert.equal(r.diagnostics.nativeExecutions,base.native);
 assert.equal(JSON.stringify(r.roots.map(x=>[x.actionId,x.value,x.realization,x.preparationDebt])),JSON.stringify(base.roots));
 assert.equal(rows.length,99);
 const groups={};for(const {source,step,queue,afterQueue,status,barrier,rngExact,reservedKnown,turnBonuses,transit,priorBarrier,control} of rows){
  const k=JSON.stringify({source,step,queue,afterQueue,status,barrier,rngExact,reservedKnown,turnBonuses,transit,priorBarrier,control});groups[k]=(groups[k]||0)+1;
 }
 const groupRows=Object.entries(groups).map(([k,count])=>({count,...JSON.parse(k)}));
 fs.writeFileSync(process.argv[2],z.gzipSync(JSON.stringify({rows,groups:groupRows})+'\n'),{flag:'wx'});
 console.log(JSON.stringify(groupRows));
}finally{port.close();m.dispose();}
