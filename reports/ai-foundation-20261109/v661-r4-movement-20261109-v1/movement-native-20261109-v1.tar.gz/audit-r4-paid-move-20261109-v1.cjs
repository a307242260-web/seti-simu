'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {open,seat}=require('./native-late-r3');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const base=require('./r4-scan4-move-official-profile-20261109-v1.json');
const candidate=require('./r4-paid-move-official-profile-20261109-v1.json');
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const js=fs.readFileSync(file,'utf8'),starts=['      if(moveMenu){','      if(paidMove){'],ends=['        provedMoveMenus++;','        provedMovePayments++;'];
for(const a of [...starts,...ends])assert.equal(js.split(a).length,2);
const take=`
        const witnessed=globalThis.auditMove({stored,requested,restoreEnvelope,executeCurrent,snapshot,comp:fork.composition||fork,
          finish:(before,result)=>finishChild(before,result,nextMovementIntent(node,requested),null,stored.informationBarrier,requested,stored)});
`,check='\n        globalThis.compareMove({witnessed,child,nodes,identity});';
let wrapped=js;
for(const a of starts)wrapped=wrapped.replace(a,a+take);
for(const a of ends)wrapped=wrapped.replace(a,a+check);
mod._compile(wrapped,file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const rows=[];
const shape=e=>{
 const id=e.session?.session.sessionId;
 return {state:JSON.parse(e.committedState),session:id?JSON.parse(JSON.stringify(e.session).split(id).join('session-id')):null};
};
function diff(a,b,p='',d=[]){
 if(Object.is(a,b)||d.length>=12)return d;
 if(a&&b&&typeof a==='object'&&typeof b==='object')
  for(const k of new Set([...Object.keys(a),...Object.keys(b)]))diff(a[k],b[k],p+'.'+k,d);
 else d.push(p);
 return d;
}
globalThis.auditMove=({stored,requested,restoreEnvelope,executeCurrent,snapshot,comp,finish})=>{
 restoreEnvelope(stored.envelope,true);
 const raw=executeCurrent(requested);assert(raw.result.ok);assert.equal(raw.result.irreversibleBarrier??null,null);
 const after=snapshot(comp),saved=shape(after),p=stored.envelope.session?.session?.workingState||JSON.parse(stored.envelope.committedState);
 const q=saved.session?.session.workingState||saved.state;
 assert.deepEqual(p.meta.rngState,q.meta.rngState);
 return {native:finish(raw.before,raw.result),saved,requested};
};
globalThis.compareMove=({witnessed,child,nodes,identity})=>{
 const {native,saved,requested}=witnessed;
 assert.deepEqual(diff(saved,shape(nodes.get(child).envelope)),[]);
 assert.equal(native.status,child.status);assert.equal(native.boundary,child.boundary);assert.equal(identity(native),identity(child));
 assert.deepEqual(native.legalActions,child.legalActions);assert.deepEqual(nodes.get(native).intent,nodes.get(child).intent);
 assert.deepEqual(native.observation,child.observation);
 rows.push({family:requested.family,choices:child.legalActions.length,energy:requested.payload?.energyCost??null,
  discards:requested.target?.cardIds?.length??null,status:child.status});
};
const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);assert.equal(q.actionId,base.action);assert.equal(q.value,base.value);
 assert.equal(JSON.stringify(q.roots.map(r=>[r.actionId,r.value,r.realization,r.preparationDebt])),JSON.stringify(base.roots));
 assert.deepEqual(candidate.roots,base.roots);
 assert.equal(q.diagnostics.nativeExecutions,base.native);assert.equal(rows.length,base.native-candidate.native);
 assert.equal(q.analysis.provedMoveMenus,39);assert.equal(q.analysis.provedMovePayments,40);
}finally{port.close();m.dispose();}
const counts={};for(const r of rows){const k=r.family==='move'?r.family:[r.family,r.energy,r.discards].join('|');counts[k]=(counts[k]||0)+1;}
fs.writeFileSync(process.argv[2],JSON.stringify({nativeReplays:rows.length,counts,rows},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({nativeReplays:rows.length,counts}));
