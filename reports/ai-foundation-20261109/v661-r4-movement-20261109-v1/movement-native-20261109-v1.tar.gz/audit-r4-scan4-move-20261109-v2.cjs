'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),z=require('node:zlib');
const {open,seat}=require('./native-late-r3');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const base=require('./r4-end-prelude-official-profile-20261109-v1.json');
const candidate=require('./r4-scan4-move-official-profile-20261109-v1.json');
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const js=fs.readFileSync(file,'utf8'),a='      if(scanMove){',b='        provedScan4QuietMoves++;';
assert.equal(js.split(a).length,2);assert.equal(js.split(b).length,2);
mod._compile(js.replace(a,a+`
        const witnessed=globalThis.auditNativeScanMove({stored,requested,restoreEnvelope,executeCurrent,snapshot,comp:fork.composition||fork,
          preview:(store,action)=>previewQuietScan4Move(node,store,action),
          finish:(before,result)=>finishChild(before,result,nextMovementIntent(node,requested),null,stored.informationBarrier,requested,stored)});
`).replace(b,b+`
        globalThis.compareScanMove({witnessed,child,nodes,identity});
`),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
function diff(a,b,p='',d=[]){
 if(Object.is(a,b)||d.length>=15)return d;
 if(a&&b&&typeof a==='object'&&typeof b==='object'){
  for(const k of new Set([...Object.keys(a),...Object.keys(b)]))diff(a[k],b[k],p+'.'+k,d);
 }else d.push(p);
 return d;
}
const rows=[],negativeControls=[];
globalThis.auditNativeScanMove=({stored,requested,restoreEnvelope,executeCurrent,snapshot,comp,finish,preview})=>{
 restoreEnvelope(stored.envelope,true);
 const raw=executeCurrent(requested);assert(raw.result.ok);
 const after=snapshot(comp),s=stored.envelope.session.session;
 const next=after.session?.session.workingState||JSON.parse(after.committedState);
 assert.deepEqual(next.meta.rngState,s.workingState.meta.rngState);
 const empty=s.workingState.cards.publicCards.map((c,i)=>c?null:i).filter(i=>i!==null);
 if(!negativeControls.length){
  const deny=(name,mutate,action=requested)=>{
   const store={...stored,envelope:structuredClone(stored.envelope)};
   mutate(store.envelope.session.session,store);
   assert.equal(preview(store,action),null,name);negativeControls.push(name);
  };
  deny('paid-or-two-move-points',()=>{},{...requested,payload:{requiredMovePoints:2}});
  deny('unexpected-tail',s=>{s.queue.push(s.queue[1]);});
  deny('active-turn-reward',s=>{s.workingState.turn.cardTurnEventBonuses=[{}];});
  deny('transport-pending',s=>{s.workingState.aliens.chong.transportTasksByRocketId={x:{delivered:false}};});
  deny('foreign-probe',s=>{s.workingState.pieces.rockets.find(r=>r.id===requested.target.rocketId).playerId='player-blue';});
  deny('complete-sector',s=>{
   const d=s.workingState.data;
   const api=require(path.resolve('randomizer/game/data'));
   const bucket=api.NEBULA_IDS.map(id=>[id,d.nebulae[id]]).find(([id,n])=>n&&n.tokens.length===api.getNebulaCapacity(id));
   assert(bucket);
   for(const t of bucket[1].tokens)t.replacedByPlayerColor='white';
   assert(api.isSectorReadyToSettle(d,bucket[0]));
  });
 }
 return {after,native:finish(raw.before,raw.result),next,empty,source:s.journal.actions[0].action.family};
};
globalThis.compareScanMove=({witnessed,child,nodes,identity})=>{
 const {native,after,next,empty,source}=witnessed, got=nodes.get(child).envelope;
 assert.deepEqual(diff(after.session,got.session),[]);
 assert.deepEqual(diff(JSON.parse(after.committedState),JSON.parse(got.committedState)),[]);
 assert.equal(child.status,native.status);assert.equal(child.boundary,native.boundary);assert.equal(identity(child),identity(native));
 assert.deepEqual(child.legalActions,native.legalActions);assert.deepEqual(nodes.get(child).intent,nodes.get(native).intent);
 assert.deepEqual(nodes.get(child).informationBarrier,nodes.get(native).informationBarrier);
 const obs=child.observation;assert.deepEqual(obs,native.observation);
 for(const slot of empty){
  const replacement=next.cards.publicCards[slot];assert(replacement);
  assert.equal(obs.publicState.board.publicCards[slot]?.id,undefined);
  assert(!JSON.stringify(child.legalActions).includes(`"${replacement.id}"`));
 }
 rows.push({source,status:child.status,refills:empty.length,barrier:child.boundary,choices:child.legalActions.length});
};
const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 assert.equal(q.actionId,base.action);assert.equal(q.value,base.value);
 assert.equal(JSON.stringify(q.roots.map(r=>[r.actionId,r.value,r.realization,r.preparationDebt])),JSON.stringify(base.roots));
 assert.deepEqual(candidate.roots,base.roots);
 assert.equal(q.diagnostics.nativeExecutions,base.native);
 assert.equal(rows.length,base.native-candidate.native);assert.equal(q.analysis.provedScan4QuietMoves,rows.length);
}finally{port.close();m.dispose();}
const counts={};for(const r of rows){const k=[r.source,r.status].join('|');counts[k]=(counts[k]||0)+1;}
fs.writeFileSync(process.argv[2],JSON.stringify({nativeReplays:rows.length,counts,negativeControls,rows},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({nativeReplays:rows.length,counts,negativeControls}));
