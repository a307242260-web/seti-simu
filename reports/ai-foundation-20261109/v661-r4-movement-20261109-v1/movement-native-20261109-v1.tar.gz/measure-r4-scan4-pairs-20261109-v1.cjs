'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const m=open(root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const r=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(r.complete&&!r.unresolved.length);assert.deepEqual(m.save(),root);
 const base=require('./r4-end-prelude-slice-key-clean-20261109-v1.json')[0];
 assert.equal(r.actionId,base.action);assert.equal(r.value,base.value);
 assert.equal(JSON.stringify(r.roots.map(x=>[x.actionId,x.value,x.realization,x.preparationDebt])),JSON.stringify(base.ranking));
 const [mode,out]=process.argv.slice(2),native=r.diagnostics.nativeExecutions;
 assert.equal(native,mode==='base'?449:399);
 const result={mode,ms:r.rootAndSearchMilliseconds,native,action:r.actionId,value:r.value,
  proof:r.analysis.provedScan4QuietMoves||0,refillHits:r.analysis.scan4RefillHits||0,
  refillEntries:r.analysis.scan4RefillCacheEntries||0,msAnalysis:r.analysis.milliseconds};
 fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result));
}finally{p.close();m.dispose();}
