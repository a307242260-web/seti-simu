'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,open,short,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2);
const checkpoint=readZ(src).snapshots[234].envelope,m=open(checkpoint);
m.act('end_turn');const origin=m.save();
function prepare(h,o){
 const {m,act,take,cut}=h;
 act('analyze');act('choose_target',a=>a.target.choiceId==='trace:1:blue:amiba:3');
 act('choose_card',a=>a.target.source==='display'&&a.target.cardIndex===2);
 cut('after-analysis');
 if(o.swap)take(...m.swap(o.swap,'dlc_17.png'));
 act('place_data');act('choose_target',a=>a.target.target==='computer');
 take(m.corner(o.corner));
 act('place_data');act('choose_target',a=>a.target.blueSlot===1);
 act('quick_trade',a=>a.target.tradeId==='cards-for-energy');
 for(const card of o.pair)act('choose_payment',a=>a.summary===card);
 act('choose_payment',a=>a.target.confirm);
 cut('scan-funded');assert.equal(short(m).wallet[1],1);assert.equal(short(m).wallet[2],2);
 act('end_turn');act('scan');cut('actual-scan-menu');
}
const options=[
 {label:'retain-dlc25',corner:'amiba_2.webp',pair:['b_16.webp','amiba_5.webp']},
 {label:'retain-amiba5',corner:'amiba_2.webp',pair:['b_16.webp','dlc_25.png']},
 {label:'retain-amiba2',swap:'b_16.webp',corner:'dlc_17.png',pair:['amiba_5.webp','dlc_25.png']}
];
const readMenu=o=>{
 m.restore(origin);const prefix=[];
 const act=(f,p)=>prefix.push(m.act(f,p)),take=(...a)=>prefix.push(...a);
 try{prepare({m,act,take,cut:()=>{}},o);return m.menu().map(x=>x.target.nebulaId);}catch(e){return [];}
};
const cases=[['formal',()=>{}]];
for(const o of options){
 const ids=readMenu(o);console.log('current menu',o.label,ids);
 for(const id of ids){
  m.restore(origin);const c={m,act:(f,p)=>m.act(f,p),take:()=>{},cut:()=>{}};
  prepare(c,o);m.act('choose_target',a=>a.target.nebulaId===id);
  const targets=m.menu().filter(a=>a.target?.cardInstanceId&&a.target?.nebulaId);
  const choices=targets.filter(a=>a.target.nebulaId===id);
  const take=(choices.length?choices:targets).map(x=>x.target.choiceId);
  console.log('public targets',o.label,id,take);
  for(const chosen of take)cases.push([[o.label,id,chosen].join(':'),h=>{
   prepare(h,o);h.act('choose_target',a=>a.target.nebulaId===id);
   h.act('choose_card',a=>a.target.choiceId===chosen);
   h.cut('after-scan-signals');
  }]);
 }
}
m.dispose();
writeZ(out,{scope:'From the exact first available main after blue cash, move the already legal second analysis before the last paid main; use publicly known data and a single fixed two-card energy payment. Only public Native scan menus are evaluated.',origin,options,...runCases(origin,cases)});
