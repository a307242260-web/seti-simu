'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {readZ,writeZ,open,short}=require('./controlled-r3');
const load=n=>require(path.resolve(n)),rocket=load('randomizer/game/rockets'),ability=load('randomizer/game/abilities/rocket'),solar=load('randomizer/solar-system/core');
const [src,teacher,out]=process.argv.slice(2),seat='player-white',ref=readZ(src);
const earlier=ref.rows.find(x=>x.label==='fixed-yellow-fossil07');
const origins={candidate:earlier.settled.state,teacher:require(teacher).coreState.compositionEnvelope};
function pathToEarth(m,fossilId){
 const s=m.state(),ship=s.pieces.rockets.find(r=>r.fossilId===fossilId&&r.playerId===seat),earth=solar.collectPlanetLocations(s.solarSystem).find(p=>p.planetId==='earth');
 assert(ship&&earth);
 const queue=[{at:rocket.getRocketSectorCoordinate(ship),cost:0,path:[]}],seen=new Set();
 while(queue.length){
  queue.sort((a,b)=>a.cost-b.cost||a.path.length-b.path.length);
  const n=queue.shift(),id=n.at.x+','+n.at.y;if(seen.has(id))continue;seen.add(id);
  if(n.at.x===earth.x&&n.at.y===earth.y)return {rocketId:ship.id,earth:{x:earth.x,y:earth.y},...n};
  const cost=ability.getRequiredMovePointsFromCoordinate(s,m.player(),n.at);
  for(const d of ability.MOVE_DIRECTIONS){
   const a=rocket.canMoveFromCoordinate(s.pieces,n.at,d.deltaX,d.deltaY,ship.id);
   if(a.ok&&!seen.has(a.to.x+','+a.to.y))queue.push({at:a.to,cost:n.cost+cost,path:[...n.path,{...d,cost,from:n.at,to:a.to}]});
  }
 }
 throw new Error('No legal Earth route');
}
function control(root){
 const m=open(root),accepted=[],stages={};
 const act=(f,p)=>{const a=m.act(f,p);accepted.push(a);return a;};
 const checkpoint=label=>stages[label]={state:m.save(),assets:short(m),fossils:m.state().aliens.chong.transportTasksByRocketId};
 const settle=()=>{
  for(let i=0;m.c.inspect().phase==='awaiting_input';i++){
   assert(i<15);
   const target=m.menu().find(a=>a.target.choiceId?.startsWith('confirm:'))||m.menu().find(a=>a.target.choiceId?.startsWith('skip:'));
   assert(target,JSON.stringify(m.menu().map(x=>[x.family,x.summary])).slice(0,300));
   accepted.push(m.apply(target));
  }
 };
 try{
  checkpoint('r3-before-pass');
  const id=m.state().pieces.rockets.find(p=>p.fossilId&&p.playerId===seat).fossilId;
  const task=Object.values(m.state().aliens.chong.transportTasksByRocketId).find(t=>t.fossilId===id);
  act('pass');const reserve=act('choose_card',a=>a.target.kind==='pass-reserve-card'&&a.target.choiceId==='card-30-pass-3-1');
  if(m.menu()[0].actorId!==seat)m.advanceOpponents(accepted);
  settle();
  assert.equal(m.facts().round,4);assert.equal(m.player().mainActionCompleted,false);
  checkpoint('r4-before-first-main');
  const route=pathToEarth(m,id);
  for(const d of route.path){
   while(m.player().resources.energy<d.cost)act('quick_trade',a=>a.target.tradeId==='credits-for-energy');
   act('move',a=>a.target.rocketId===route.rocketId&&a.target.deltaX===d.deltaX&&a.target.deltaY===d.deltaY);
   act('choose_payment',a=>a.target.kind==='move-payment'&&!a.target.cardIds.length);settle();
  }
  checkpoint('delivered');assert.equal(m.state().aliens.chong.fossilsById[id].status,'delivered');
  act('complete_task',a=>a.target.cardInstanceId===task.cardId);settle();
  checkpoint('claimed');assert(m.state().aliens.chong.fossilsById[id].taskCompleted);
  const end=m.save();m.restore(root);accepted.forEach(m.apply);assert.deepEqual(m.save(),end);
  return {root,reserve:reserve.summary,route,accepted,stages,end,replayExact:true};
 }catch(error){return {root,accepted,stages,failure:String(error),menu:m.menu().slice(0,14)};}
 finally{m.dispose();}
}
const cases=Object.fromEntries(Object.entries(origins).map(([k,e])=>[k,control(e)]));
console.log(JSON.stringify(Object.fromEntries(Object.entries(cases).map(([k,q])=>[k,{reserve:q.reserve,pathCost:q.route?.cost,failure:q.failure,menu:q.failure?q.menu.map(x=>x.summary):undefined,stages:Object.fromEntries(Object.entries(q.stages).map(([n,v])=>[n,v.assets]))}]))));
writeZ(out,{scope:'Before first white R4 main, use the same reserve option and only legal energy-funded known Earth transport. Teacher and the original-seed controlled route both carry fossil 07, but their transport tasks and prior board differ. This is an asset payoff control, not a fourth-round autonomous run.',cases});
