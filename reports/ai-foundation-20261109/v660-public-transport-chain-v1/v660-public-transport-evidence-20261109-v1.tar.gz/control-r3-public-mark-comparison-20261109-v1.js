'use strict';
const fs=require('node:fs'),{readZ,runCases,writeZ}=require('./controlled-r3');
const [data,original,formal,out]=process.argv.slice(2);
const later=readZ(data).roots['pink-decision'],early=readZ(original).snapshots[172].envelope;
const record=JSON.parse(fs.readFileSync(formal+'/reports/research/6ff3b826.6b5ba279.quick-400.json')),save=JSON.parse(fs.readFileSync(formal+'/'+record.savePath));
function mark({act},id){act('choose_target',a=>a.target.choiceId===id);}
const choices=['trace:1:pink:state-extra','trace:1:pink:amiba:2','trace:1:pink:amiba:3','trace:2:pink'];
const at214=runCases(later,choices.map(id=>[id,h=>mark(h,id)]));
function at175(h,id){
 for(let i=172;i<=174;i++)h.take(h.m.apply(save.replaySteps[i-1].action));
 mark(h,id);
}
const at172=runCases(early,['trace:1:pink:amiba:4','trace:2:pink'].map(id=>[id,h=>at175(h,id)]));
writeZ(out,{scope:'Keep exact original native worlds and change only the known trace choice. All subsequent choices are autonomous and bounded; no new standard test.',roots:{later,early},at214,at172});
