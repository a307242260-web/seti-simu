'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {open,seat}=require('./native-late-r3');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const base=require('./r4-blue-pick-settle-official-profile-20261109-v1.json');
const candidate=require('./r4-end-prelude-official-profile-20261109-v1.json');
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const js=fs.readFileSync(file,'utf8');
for(const a of ['      if(endPrelude?.finished){','      if(endMenu){','        provedQuietEndHandovers++;','        provedQuietEndMenus++;'])assert.equal(js.split(a).length,2);
const inject=`
        const witnessed=globalThis.auditNativeEnd({stored,requested,restoreEnvelope,executeCurrent,snapshot,comp:fork.composition||fork,
          finish:(before,result)=>finishChild(before,result,movementPlanning?nextMovementIntent(node,requested):null,
            null,stored.informationBarrier,requested,stored)});
`;
const verify='\n        globalThis.compareEnd({witnessed,child,nodes,identity});';
mod._compile(js.replace('      if(endPrelude?.finished){','      if(endPrelude?.finished){'+inject)
 .replace('      if(endMenu){','      if(endMenu){'+inject).replace('        provedQuietEndHandovers++;','        provedQuietEndHandovers++;'+verify)
 .replace('        provedQuietEndMenus++;','        provedQuietEndMenus++;'+verify),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const local=require(path.resolve('randomizer/game/ai/local-decision-plans')),r=[];
const shape=e=>{
 const id=e.session?.session.sessionId;
 const canon=JSON.parse(e.committedState),session=id?JSON.parse(JSON.stringify(e.session).split(id).join('session-id')):null;
 return {canon,session};
};
globalThis.auditNativeEnd=({stored,requested,restoreEnvelope,executeCurrent,snapshot,comp,finish})=>{
 restoreEnvelope(stored.envelope,true);
 const raw=executeCurrent(requested);assert(raw.result.ok);assert.equal(raw.result.irreversibleBarrier??null,null);
 const after=snapshot(comp),before=JSON.parse(stored.envelope.committedState);
 const saved=shape(after);
 assert.deepEqual(before.meta.rngState,(saved.session?.session.workingState||saved.canon).meta.rngState);
 return {before,requested,native:finish(raw.before,raw.result),saved};
};
const declines=[];
globalThis.compareEnd=({witnessed,child,nodes,identity})=>{
 const {native,saved,before,requested}=witnessed,childSaved=shape(nodes.get(child).envelope);
 function diff(a,b,p='',d=[]){
  if(Object.is(a,b)||d.length>=12)return d;
  if(a&&b&&typeof a==='object'&&typeof b==='object')
   for(const k of new Set([...Object.keys(a),...Object.keys(b)]))diff(a[k],b[k],p+'.'+k,d);
  else d.push(p);
  return d;
 }
 assert.deepEqual(diff(saved,childSaved),[]);
 assert.equal(native.status,child.status);assert.equal(native.boundary,child.boundary);assert.equal(identity(native),identity(child));
 assert.deepEqual(native.legalActions,child.legalActions);assert.deepEqual(nodes.get(native).intent,nodes.get(child).intent);
 assert.deepEqual(native.observation,child.observation);
 if(saved.session&&!declines.length){
  const p=before.players.players.find(p=>p.id===seat),knownCards=new Set(p.reservedCards.map(c=>c.id));
  const run=(state=before,cards=knownCards)=>local.previewFinalForeignEndPrelude({state,seatId:seat,action:requested,knownCards:cards});
  assert(run()?.task);
  const decline=(name,mutate,cards=knownCards)=>{
   const s=structuredClone(before);mutate(s);
   assert.equal(run(s,cards),null,name);declines.push(name);
  };
  decline('unknown-reserved-card',()=>{},new Set());
  decline('new-milestone',s=>{for(const t of Object.values(s.finalScoring.tiles))t.marks=t.marks.filter(m=>m.playerId!==seat);});
  decline('turn-bonus',s=>{s.turn.cardTurnEventBonuses=[{}];});
  decline('three-seats',s=>{s.turn.activePlayerCount=3;});
  decline('pass',s=>{s.turn.passedPlayerIds.push(seat);});
  decline('no-foreign-seat',s=>{s.turn.passedPlayerIds=s.turn.activePlayerIds.filter(x=>x!==seat);});
 }
 r.push({status:child.status,rule:saved.session?.session.queue[0].payload.ruleId||null,choices:child.legalActions.length});
};
const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);assert.equal(q.actionId,base.action);assert.equal(q.value,base.value);
 assert.equal(JSON.stringify(q.roots.map(r=>[r.actionId,r.value,r.realization,r.preparationDebt])),JSON.stringify(base.roots));
 assert.deepEqual(base.roots,candidate.roots);
 assert.equal(q.diagnostics.nativeExecutions,base.native);assert.equal(r.length,base.native-candidate.native);
 assert.equal(q.analysis.provedQuietEndMenus+q.analysis.provedQuietEndHandovers,r.length);
}finally{port.close();m.dispose();}
const groups={};for(const x of r){const k=x.rule||x.status;groups[k]=(groups[k]||0)+1;}
fs.writeFileSync(process.argv[2],JSON.stringify({replays:r.length,groups,declines,rows:r},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({replays:r.length,groups,declines}));
