'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {open,seat}=require('./native-late-r3');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const base=require('./r4-end-prelude-clean-20261109-v1.json')[0];
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const js=fs.readFileSync(file,'utf8'),original=fs.readFileSync(path.resolve('../candidate-r4-end-prelude-v1/randomizer/game/ai/analysis-port.js'),'utf8');
const start=original.indexOf('  function forwardIdentity('),end=original.indexOf('  function createAnalysisPort(',start);
assert(start>0&&end>start);
const prior=original.slice(start,end).replace('function forwardIdentity(','function baselineForwardIdentity(');
const anchor='physicalKey=forwardIdentity(envelope,status,boundary,readIdentityState(envelope),normalizedIdentityStates,null,identitySlices);';
assert.equal(js.split(anchor).length,2);
mod._compile(js.replace('  function createAnalysisPort(',prior+'  function createAnalysisPort(').replace(anchor,anchor+`
          globalThis.verifyPhysicalKey(physicalKey,baselineForwardIdentity(envelope,status,boundary,readIdentityState(envelope)),status);
`).replace('return Object.freeze({ createAnalysisPort });','return Object.freeze({ createAnalysisPort, forwardIdentity, baselineForwardIdentity });'),file);
const {createAnalysisPort,forwardIdentity,baselineForwardIdentity}=mod.exports;
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const statuses={};
globalThis.verifyPhysicalKey=(actual,expected,status)=>{
 assert.equal(actual,expected);
 statuses[status]=(statuses[status]||0)+1;
};
const deep=x=>{if(x&&typeof x==='object'){for(const v of Object.values(x))deep(v);Object.freeze(x);}return x;};
const cache={values:new WeakMap(),hits:0,stores:0};
const probe=(state,id)=>{
 const envelope={session:id?{session:{sessionId:id,workingState:state,queue:[],
  journal:{actions:[]},phase:'awaiting_input'}}:null};
 return [forwardIdentity(envelope,'stable',null,state,null,null,cache),baselineForwardIdentity(envelope,'stable',null,state)];
};
const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 assert.equal(q.actionId,base.action);assert.equal(q.value,base.value);
 assert.equal(JSON.stringify(q.roots.map(r=>[r.actionId,r.value,r.realization,r.preparationDebt])),JSON.stringify(base.ranking));
 assert.equal(q.diagnostics.nativeExecutions,base.native);
 const total=Object.values(statuses).reduce((n,v)=>n+v,0);
 assert.equal(total,q.analysis.identityMaterializations);assert(q.analysis.identitySliceHits>0);
 const scopes={};
 for(const name of ['aliens','data','finalScoring','pieces','planets','solarSystem','tech']){
  const prefixA='effect-session-2',prefixB='effect-session-3';
  const withRefs=deep({[name]:{x:{effectId:prefixB+':effect:2'},y:{groupId:prefixB+':group:1'},z:['unchanged']}});
  const a=probe(withRefs,prefixA),b=probe(withRefs,prefixB);
  assert.equal(a[0],a[1]);assert.equal(b[0],b[1]);assert.notEqual(a[0],b[0]);
  const child={a:1},shallow=Object.freeze({[name]:Object.freeze({child})});
  const before=probe(shallow);child.a=2;const after=probe(shallow);
  assert.equal(before[0],before[1]);assert.equal(after[0],after[1]);assert.notEqual(before[0],after[0]);
  const stable=deep({[name]:{arr:['a','b'],z:{a:1,b:2}}});
  const p=probe(stable,prefixA),r=probe(stable,prefixB);assert.equal(p[0],p[1]);assert.equal(r[0],r[1]);assert.equal(p[0],r[0]);
  scopes[name]='prefix-references-and-shallow-mutation';
 }
 const facts={total,statuses,hits:q.analysis.identitySliceHits,stores:q.analysis.identitySliceStores,scopes};
 fs.writeFileSync(process.argv[2],JSON.stringify(facts,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(facts));
}finally{port.close();m.dispose();}
