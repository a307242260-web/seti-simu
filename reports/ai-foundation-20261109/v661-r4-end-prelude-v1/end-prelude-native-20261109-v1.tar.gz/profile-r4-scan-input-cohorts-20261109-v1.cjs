'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {open,seat}=require('./native-late-r3');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const base=require('./r4-end-prelude-official-profile-20261109-v1.json');
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const js=fs.readFileSync(file,'utf8'),a='      restoreEnvelope(stored.envelope, true);\n      const { before, result } = executeCurrent(requested);';
assert.equal(js.split(a).length,2);
mod._compile(js.replace(a,`
      const q=stored.envelope.session?.session?.queue?.[0];
      if(q&&[scienceSession.EFFECT_TYPES.SCAN_STEP,scienceSession.EFFECT_TYPES.SCAN_ACTION_4].includes(q.type))
        globalThis.observeScanInput(node,stored,requested,q,localDecisionSpec(node),cardPickSpec(node));
`+a),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const contexts=new Map();
globalThis.observeScanInput=(node,stored,action,q,local,pick)=>{
 const s=stored.envelope.session.session,a=s.journal.actions[0].action;
 const data=contexts.get(stored.envelope)||{source:a.family,effect:q.type,mode:q.payload?.options?.mode||null,
  nativeMenuSize:node.legalActions.length,priorBarrier:stored.informationBarrier?.code||null,
  actionFamilies:[...new Set(node.legalActions.map(x=>x.family))],localKind:local?.kind||null,localFixedId:local?.selectedActionId||null,
  pickKind:pick?.kind||null,pickFixedId:pick?.fixed?pick.selectedActionId:null,visited:[]};
 data.visited.push({family:action.family,selected:action.actionId,choice:action.target?.choiceId||null,
  nebula:action.target?.nebulaId||null});contexts.set(stored.envelope,data);
};
const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const r=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(r.complete&&!r.unresolved.length);assert.deepEqual(m.save(),root);assert.equal(r.diagnostics.nativeExecutions,base.native);
 assert.equal(JSON.stringify(r.roots.map(x=>[x.actionId,x.value,x.realization,x.preparationDebt])),JSON.stringify(base.roots));
 const rows=[...contexts.values()],groups={};
 for(const row of rows){
  const f=row.visited[0].family,key=[row.source,row.effect,f].join('|');
  const g=groups[key]||(groups[key]={menus:0,nativeInputs:0,menusWithMultiple:0,knownFixed:0,types:{}});
  g.menus++;g.nativeInputs+=row.visited.length;if(row.visited.length>1)g.menusWithMultiple++;
  if(row.visited.every(x=>x.selected===row.localFixedId||x.selected===row.pickFixedId))g.knownFixed++;
  const t=[row.mode||'—',row.localKind||row.pickKind||'—'].join('|');g.types[t]=(g.types[t]||0)+1;
 }
 const expected=Object.entries(base.categories).filter(([k])=>/\|science_domain_scan_(step|action_4)\|/.test(k)).reduce((v,[,n])=>v+n,0);
 const actual=rows.reduce((n,x)=>n+x.visited.length,0);assert.equal(actual,expected);
 fs.writeFileSync(process.argv[2],JSON.stringify({actual,groups,rows},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({actual,groups}));
}finally{port.close();m.dispose();}
