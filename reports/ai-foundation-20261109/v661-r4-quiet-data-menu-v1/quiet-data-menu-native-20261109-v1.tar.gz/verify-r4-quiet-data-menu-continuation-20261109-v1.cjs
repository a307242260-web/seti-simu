'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const load=p=>require(path.resolve(p));
const {createAnalysisPort}=load('randomizer/game/ai/analysis-port');
const {createSearchAgent}=load('randomizer/game/ai/search-agent');
const file=path.join(__dirname,'candidate-quiet-data-menu-lazy-native-20261109-v1.json.gz');
const fixture=JSON.parse(z.gunzipSync(fs.readFileSync(file))).rows.find(x=>x.input===355);
const m=open(fixture.root);
function decide(saved){
 const port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  const agent=createSearchAgent({seatId:seat,analysisPort:port}); if(saved)agent.loadCheckpoint(saved);
  const root=m.save(), q=agent.decide({seatId:seat,legalActions:m.menu()}).search;
  assert.deepEqual(m.save(),root);
  return {action:m.menu().find(a=>a.actionId===q.actionId),native:q.diagnostics.nativeExecutions,reuse:q.diagnostics.planContinuation,
    checkpoint:agent.createCheckpoint(),proofs:q.analysis.provedFinalDataMenuInputs};
 } finally {port.close();}
}
try{
 const first=decide(null);
 assert.equal(first.action.family,'place_data');assert(first.proofs>0&&first.checkpoint);
 m.apply(first.action);
 const next=decide(structuredClone(first.checkpoint));
 assert.equal(next.action.family,'choose_target');assert.equal(next.reuse,'hit');assert.equal(next.native,0);
 m.apply(next.action);
 const out={input:355,first:first.action.actionId,next:next.action.actionId,nextTarget:next.action.target,
   provedMenusInRoot:first.proofs,restoredPlanHit:true,nextNativeInputs:next.native};
 fs.writeFileSync(process.argv[2],JSON.stringify(out,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(out));
}finally{m.dispose();}
