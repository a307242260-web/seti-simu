'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {isDeepStrictEqual}=require('node:util'),{open,seat}=require('./native-late-r3');
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const code=fs.readFileSync(file,'utf8'),start='      if (menuPreview) {',tail='          null, stored.informationBarrier, requested, stored, {envelope:menuPreview, inspection});';
assert.equal(code.split(start).length,2);assert.equal(code.split(tail).length,2);
mod._compile(code.replace(start,start+`
        const witness=globalThis.auditQuietMenu({menuPreview,stored,requested,executeCurrent,restoreEnvelope,snapshot,comp:fork.composition||fork,
          finish:(before,result)=>finishChild(before,result,movementPlanning ? nextMovementIntent(node,requested):null,
            null,stored.informationBarrier,requested,stored)});
`).replace(tail,tail+`
        globalThis.compareQuietMenu({witness,child,stored,requested,nodes,identity,rememberPlan,exportPlan});
`),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const read=file=>JSON.parse(z.gunzipSync(fs.readFileSync(path.join(__dirname,file))));
const referenceKeys=new Set(['effectId','groupId','sessionId','parentEffectId','decisionId']);
function normalize(checkpoint){
 const prefix=checkpoint.session?.session?.sessionId;
 assert.match(prefix,/^effect-session-\d+$/);
 function visit(value,key){
   if(typeof value==='string'&&referenceKeys.has(key)&&(value===prefix||value.startsWith(prefix+':')))return '<session>'+value.slice(prefix.length);
   if(value===null||typeof value!=='object')return value;
   if(Array.isArray(value))return value.map(v=>visit(v,key));
   return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,visit(v,k)]));
 }
 return visit(checkpoint,'');
}
let verified, sample;
globalThis.auditQuietMenu=({menuPreview,stored,requested,executeCurrent,restoreEnvelope,snapshot,comp,finish})=>{
 restoreEnvelope(stored.envelope,true);const raw=executeCurrent(requested);assert(raw.result.ok);
 const native=snapshot(comp);
 assert.equal(native.committedState,stored.envelope.committedState);
 assert(isDeepStrictEqual(normalize(native),normalize(menuPreview)),`session mismatch for ${requested.stateVersion}`);
 return finish(raw.before,raw.result);
};
globalThis.compareQuietMenu=({witness,child,stored,requested,nodes,identity,rememberPlan,exportPlan})=>{
 assert.equal(child.status,witness.status);assert.equal(child.boundary,witness.boundary);
 assert.deepEqual(child.legalActions,witness.legalActions);assert.deepEqual(nodes.get(child).intent,nodes.get(witness).intent);
 assert.equal(identity(child),identity(witness));
 const options=child.legalActions.map(a=>a.target?.choiceId);
 verified.push({carriedIntent:Boolean(stored.intent),barrier:stored.informationBarrier?.code||null,options,stateVersion:requested.stateVersion});
 if(!sample&&!stored.intent&&!stored.informationBarrier&&child.status==='decision'){
  const row={node:child,actionId:child.legalActions[0].actionId,value:42,distance:1,sourceNode:0,
    roots:child.legalActions.map(a=>({actionId:a.actionId,value:42}))};
  const proof=rememberPlan([row],'menu-audit-default-value',{nodeCount:1});
  sample={root:stored.envelope,action:requested,chosen:row.actionId,saved:exportPlan(proof.token)};
 }
};
const before=read('candidate-quiet-data-intent-native-20261109-v1.json.gz'), after=read(process.argv[2]), results=[];
function audit(root,row){
 const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  verified=[];
  const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
  assert.equal(verified.length,row.beforeNative-row.afterNative);assert.equal(q.diagnostics.nativeExecutions,row.beforeNative);
  assert.equal(q.analysis.provedFinalDataMenuInputs,verified.length);assert.equal(q.actionId,row.actionId);
  const ranks=q.roots.filter(a=>row.input==='official-r4-start'||a.target!=null).map(r=>[r.actionId,r.value,r.realization,r.preparationDebt]);
  if(row.ranking)assert.equal(JSON.stringify(ranks),JSON.stringify(row.ranking));
  results.push({...row,verified,menusWithAlternatives:verified.filter(s=>s.options.length>1).length,
    menusWithMovementIntent:verified.filter(s=>s.carriedIntent).length});
 }finally{port.close();m.dispose();}
}
for(const r of after.rows){
 const old=before.rows.find(x=>x.input===r.input), key=x=>[x.actionId,x.value,x.ranking,x.quotes,x.root];assert.deepEqual(key(old),key(r));
 if(r.input<355)continue;
 audit(r.root,{input:r.input,beforeNative:old.native,afterNative:r.native,beforeMs:old.ms,afterMs:r.ms,actionId:r.actionId,ranking:r.ranking});
}
const official=require('./v661-r4-full-preflight-20261109-v1.json'), old=require('./r4-quiet-data-intent-official-cold-20261109-v1.json').corrected;
const now=require('./r4-quiet-data-menu-lazy-official-cold-20261109-v1.json').corrected, ranking=require('./r4-quiet-data-official-profile-20261109-v2.json').roots;
audit(official.checkpoint,{input:'official-r4-start',beforeNative:old.native,afterNative:now.native,beforeMs:old.ms,afterMs:now.ms,actionId:now.actionId,ranking});
assert(sample);
const m=open(sample.root);
try {
 m.apply(sample.action);
 const saved=m.save(), port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try {
  const token=port.importPlan(sample.saved), root=port.openRoot();
  const reused=port.reusePlan(root,token,sample.saved.modelKey);
  assert(reused.hit,JSON.stringify(reused));assert.equal(reused.actionId,sample.chosen);
  assert(root.legalActions.some(a=>a.actionId===reused.actionId));
  assert.deepEqual(m.save(),saved);
 }finally{port.close();}
}finally{m.dispose();}
fs.writeFileSync(process.argv[3],JSON.stringify({results,planCheckpointReusedAfterActualInput:true,unchangedRootsAndRng:true},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(results.map(({verified,ranking,...row})=>row)));
