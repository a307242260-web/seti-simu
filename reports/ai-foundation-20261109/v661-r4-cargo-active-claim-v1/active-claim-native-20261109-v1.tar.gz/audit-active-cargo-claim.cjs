'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const [source,previous,out]=process.argv.slice(2),{open,seat}=require('./native-late-r3');
const read=p=>JSON.parse(z.gunzipSync(fs.readFileSync(p)));
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const js=fs.readFileSync(file,'utf8'),hook='      return {proof:"seti-cargo-claim-and-quiet-end-equivalence-v1",';
assert.equal(js.split(hook).length,2);
mod._compile(js.replace(hook,'      globalThis.auditCargoEquivalence(stored.envelope,action,tail);\n'+hook)
 .replace('return Object.freeze({ createAnalysisPort });','return Object.freeze({ createAnalysisPort, forwardIdentity });'),file);
const {createAnalysisPort,forwardIdentity}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const sourceKey=e=>forwardIdentity(e,'stable',null),rows=[];
let audits,previousSources;
globalThis.auditCargoEquivalence=(root,claim,tail)=>{
 const old=previousSources.get(sourceKey(root));
 assert(old?.simple&&old.tail&&old.rule==='transport'&&old.value===old.endValue);
 const m=open(root);
 try{
  const paths=[];
  for(const early of [true,false]){
   m.restore(root);
   const actions=[];
   if(early)actions.push(m.apply(claim));
   actions.push(m.act('end_turn',a=>a.actionId===tail.firstActionId));
   if(!early)actions.push(m.act('accept_optional_effect',a=>a.target?.choiceId===`confirm:chong_task:${tail.quietCargoChoice.cardId}:${tail.quietCargoChoice.ruleId}`));
   const end=m.save();
   assert(!end.session);
   m.restore(root);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
   paths.push({actions,end});
  }
  assert.equal(sourceKey(paths[0].end),sourceKey(paths[1].end));
  audits.push({root,paths,oldChildAlternatives:old.edges,completeForwardIdentityEqual:true});
 }finally{m.dispose();}
};
const prev=new Map(read(previous).map(r=>[r.input,r]));
for(const row of read(source).rows.filter(r=>r.input>=355)){
 const m=open(row.root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  audits=[];
  previousSources=new Map(prev.get(row.input).report.filter(x=>x.rule==='transport').map(x=>[sourceKey(x.state),x]));
  const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),row.root);
  const count=q.lines.reduce((n,l)=>n+(l.cargoClaimEquivalences?.length||0),0);
  assert(count>0);assert.equal(count,audits.length);
  assert.deepEqual(q.roots.filter(a=>a.target!=null).map(a=>[a.actionId,a.value,a.realization||0,a.preparationDebt]),row.ranking);
  rows.push({input:row.input,count,audits});
  console.log(JSON.stringify({input:row.input,count}));
 }finally{p.close();m.dispose();}
}
fs.writeFileSync(out,z.gzipSync(JSON.stringify(rows)+'\n'),{flag:'wx'});
