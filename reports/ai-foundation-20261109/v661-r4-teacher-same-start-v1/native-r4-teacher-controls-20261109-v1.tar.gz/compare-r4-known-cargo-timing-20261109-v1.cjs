'use strict';
const fs=require('node:fs'),z=require('node:zlib'),assert=require('node:assert/strict');
const [helper,roots,history,out]=process.argv.slice(2),{open}=require(helper);
const read=p=>JSON.parse(fs.readFileSync(p)),x=JSON.parse(z.gunzipSync(fs.readFileSync(roots))),h=read(history).replaySteps,start=x.rows[0].before,m=open(start);
const assets=()=>{const f=m.facts();return {score:f.wallet.score,established:f.final,wallet:f.wallet,tech:f.tech,computer:f.computer,blue:f.blue,
 probes:f.probes.map(r=>[r.id,r.sectorX,r.sectorY,r.fossilId]),hand:f.hand.map(x=>x[1]),wins:f.wins};};
const cargo=()=>{const actions=[];
 const take=(f,p)=>actions.push(m.act(f,p));
 for(let i=0;i<2;i++){
  take('move',a=>a.target.rocketId===6&&a.target.deltaX===0&&a.target.deltaY===-1&&a.payload.requiredMovePoints===1);
  take('choose_payment',a=>a.target.kind==='move-payment'&&a.target.choiceId==='energy'&&a.payload.energyCost===1);
 }
 take('complete_task',a=>a.target.ruleId==='transport'&&a.summary.includes('chong_3'));
 return actions;
};
const rows=[];
for(const timing of ['none','before-launch','before-analysis','before-scan']){
 m.restore(start);const accepted=[],stages=[];let stop=null;
 for(let i=249;i<=271;i++){
  if(i===({ 'before-launch':249,'before-analysis':255,'before-scan':265 })[timing]){
   const before=assets();accepted.push(...cargo());stages.push({beforeInput:i,cargo:true,before,after:assets()});
  }
  const e=h[i-1].action,a=m.menu().find(a=>a.actionId===e.actionId&&a.actorId===e.actorId);
  if(!a){stop={i,expected:e.summary,available:m.menu().map(a=>a.summary)};break;}
  accepted.push(m.apply(a));
  if([254,264,271].includes(i))stages.push({afterInput:i,after:assets()});
 }
 const end=m.save();m.restore(start);accepted.forEach(m.apply);assert.deepEqual(end,m.save());
 rows.push({timing,accepted,stages,stop,end,replayExact:true});
 console.log(JSON.stringify({timing,stages:stages.map(s=>[s.beforeInput||s.afterInput,s.after.score,s.after.established,s.after.wallet.credits,s.after.wallet.energy,s.after.wallet.availableData,s.after.hand.length]),stop}));
}
m.restore(start);m.dispose();fs.writeFileSync(out,z.gzipSync(JSON.stringify(rows)+'\n'),{flag:'wx'});
