'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const [helper,source,history,out]=process.argv.slice(2),read=p=>JSON.parse(fs.readFileSync(p)),{open}=require(helper),m=open(read(source).end),steps=read(history).replaySteps,accepted=[];
const before=m.save();
let next=360,issue,lastResult;const adaptations=[];
function act(a){
 const d=m.c.inspect().session?.decision;
 const r=d?m.c.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:a})
  :a.phase==='quick'?m.c.inputPort.submitQuickAction(a):m.c.inputPort.submitAction(a);
 assert(r.ok,JSON.stringify(r));lastResult=r;
}
try{
 for(;next<=steps.length;next++){
  const e=steps[next-1],w=e.action,menu=m.menu(),chosen=menu.find(x=>x.actionId===w.actionId&&x.actorId===e.actorPlayerId);
  if(!chosen&&w.target?.choiceId?.startsWith('symbol:')){
   const group=[];
   for(let i=next;i<=steps.length;i++){
    const q=steps[i-1].action.target;
    if(!q?.choiceId?.startsWith('symbol:')||q.region!==w.target.region)break;
    group.push([q.slotId,q.symbolId]);
   }
   const state=m.save(),journal=state.session?.session?.journal||lastResult?.journal,events=journal?.events?.filter(e=>e.type==='amiba_symbol_resolved'&&e.region===w.target.region)||[];
   if(next===429){
    assert.deepEqual(group,[['blue_2','symbol_5'],['blue_1','symbol_2'],['blue_2','symbol_2']]);
    assert.deepEqual(events.map(e=>[e.slotId,e.symbolId]),[['blue_2','symbol_3'],['blue_1','symbol_2']]);
    assert(menu.some(a=>a.actionId===steps[431].action.actionId));
    adaptations.push({from:429,to:431,group,current:events.map(e=>[e.slotId,e.symbolId]),reason:'current regional blue reward already paid; old symbol identity differs and repeated moved symbol is not paid twice'});
    next=431;continue;
   }
   if([450,473,480].includes(next)&&events.length&&group.length>=2&&menu.some(a=>a.actionId===steps[next+group.length-1].action.actionId)){
    adaptations.push({from:next,to:next+group.length-1,group,current:events.map(e=>[e.slotId,e.symbolId]),reason:'current regional reward paid after historical trace; preserve next exact historical action'});
    next+=group.length-1;continue;
   }
   const matched=Math.min(events.length,group.length);
   const actual=events.slice(-matched).map(e=>[e.slotId,e.symbolId]);
   if(matched&&JSON.stringify(actual)===JSON.stringify(group.slice(0,matched))){
    adaptations.push({from:next,to:next+matched-1,group,actual,reason:'exact choices already resolved in the current Production session'});
    next+=matched-1;continue;
   }
  }
  if(next===441&&!chosen){
   assert.equal(w.family,'place_data');assert.equal(m.player().resources.availableData,0);
   assert.equal(steps[441].action.target.blueSlot,2);assert(menu.some(a=>a.actionId===steps[442].action.actionId));
   adaptations.push({from:441,to:442,reason:'one fewer pool data after removing repeated blue symbol; omit optional cash slot, scan remains legal'});
   next=442;continue;
  }
  if(!chosen){issue={historicalInput:next,expected:{family:w.family,summary:w.summary,target:w.target},actual:menu.map(x=>[x.family,x.summary,x.target]),events:(m.save().session?.session?.journal||lastResult?.journal)?.events?.filter(e=>e.type==='amiba_symbol_resolved'),state:m.save()};break;}
  assert.deepEqual(chosen.target,w.target);act(chosen);accepted.push(chosen);
 }
 const end=m.save(),facts=m.facts();m.restore(before);accepted.forEach(m.apply);assert.deepEqual(m.save(),end);m.restore(before);
 fs.writeFileSync(out,JSON.stringify({from:359,accepted:accepted.length,next,issue,end,facts,adaptations,replayExact:true,rootAndRngUnchanged:true})+'\n',{flag:'wx'});
 console.log(JSON.stringify({accepted:accepted.length,next,adaptations,score:facts.wallet.score,established:facts.final,terminal:JSON.parse(end.committedState).match.finalScoringSettled,issue:issue&&{expected:issue.expected,events:issue.events,actual:issue.actual.slice(0,6)}}));
}finally{m.dispose();}
