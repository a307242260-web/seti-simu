'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),assert=require('node:assert/strict');
const [helper,start,history,out]=process.argv.slice(2),{open}=require(helper);
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port')),agent=require(path.resolve('randomizer/game/ai/search-agent'));
const cp=JSON.parse(fs.readFileSync(start)),h=JSON.parse(fs.readFileSync(history)).replaySteps;
const m=open(cp.coreState.compositionEnvelope),rows=[],original=m.save(),accepted=[];
try{
 for(let i=245;i<=265;i++){
  const historical=h[i-1].action;
  if([249,255,259,265].includes(i)){
   const before=m.save(),menu=m.menu(),port=createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});
   try{
    const q=agent.createSearchAgent({seatId:'player-white',analysisPort:port}).decide({seatId:'player-white',legalActions:menu}).search;
    assert.deepEqual(before,m.save());
    const decision={input:i,teacher:historical.summary,teacherId:historical.actionId,
     ai:menu.find(x=>x.actionId===q.actionId)?.summary,aiId:q.actionId,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,
     teacherRoot:q.roots.find(x=>x.actionId===historical.actionId)||null,
     rootTop:q.roots.filter(x=>x.value!=null).sort((a,b)=>b.value-a.value).slice(0,6).map(r=>[menu.find(a=>a.actionId===r.actionId)?.summary,r.value]),
     value:q.value,complete:q.complete};
    rows.push({decision,before,facts:m.facts(),q,menu});
    console.log(JSON.stringify(decision));
   }catch(e){rows.push({input:i,before,error:e.message});console.log(JSON.stringify({input:i,error:e.message}));}
   finally{port.close();}
  }
  accepted.push(m.apply(historical));
 }
 const end=m.save();m.restore(original);accepted.forEach(m.apply);assert.deepEqual(m.save(),end);m.restore(original);
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({accepted,rows,end,nativeReplayExact:true,noAISubmissions:true})+'\n'),{flag:'wx'});
}finally{m.dispose();}
