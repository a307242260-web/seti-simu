'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),crypto=require('node:crypto'),z=require('node:zlib');
const [dir,helper]=process.argv.slice(2),{open}=require(helper),sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const src=dir+'/teacher-round3-before-pass-current-20261105-v2.checkpoint.json',native=require(src).coreState.compositionEnvelope;
const names=['v457-teacher-r4-first-two-20261108-v1.json','v457-teacher-r4-fossils-20261108-v1.json','v457-teacher-r4-fossils-adapted-20261108-v1.json','teacher-r4-after-359-20261109-v10.json'];
const phases=names.map(n=>require(dir+'/'+n)),counts=[],m=open(native);let full=[];
const canonical=x=>JSON.parse(JSON.stringify(x).replace(/effect-session-\d+/g,'effect-session-INSTANCE'));
function diffKeys(a,b,path='',out=[]){
 if(out.length>=20||Object.is(a,b))return out;
 if(a&&b&&typeof a==='object'&&typeof b==='object'){
  for(const k of new Set([...Object.keys(a),...Object.keys(b)]))diffKeys(a[k],b[k],path+'/'+k,out);
 }else out.push([path,typeof a==='string'&&a.length>300?a.slice(0,80):a,typeof b==='string'&&b.length>300?b.slice(0,80):b]);
 return out;
}
try{
 for(const phase of phases){
  const actions=phase.actions||phase.accepted;actions.forEach(m.apply);counts.push(actions.length);full.push(...actions);
  const a=canonical(m.save()),b=canonical(phase.end),diff=diffKeys(a,b);
  if(diff.length)throw Error(JSON.stringify({phase:counts.length,diff}));
  if(!a.session)assert.deepEqual(m.save(),phase.end);
 }
 const final=m.save(),w=JSON.parse(final.committedState).match.finalScores.find(x=>x.playerId==='player-white');
 assert.equal(w.totalScore,388);assert.equal(full.length,235);assert.equal(w.baseScore,246);
 m.restore(native);assert.deepEqual(m.save(),native);
 const proof={source:src.split('/').at(-1),sourceSha256:sha(src),phases:names.map((n,i)=>({file:n,nativeInputs:counts[i],sha256:sha(dir+'/'+n)})),
  terminal:true,white:{board:w.baseScore,tiles:w.tileScore,cards:w.cardScore,total:w.totalScore},
  nativeInputs:full.length,rootAndRngRestored:true,intermediateEnvelopeDifferenceOnlyVolatileEffectSessionInstanceIds:true,finalEnvelopeExact:true,
  scope:'Historical actions where legal; explicitly adapted rule effects, data and card payments, then an explicit controlled final PASS. No autonomous decisions.'};
 fs.writeFileSync(dir+'/teacher-r4-full-native-proof-20261109-v1.json',JSON.stringify(proof,null,2)+'\n',{flag:'wx'});
 fs.writeFileSync(dir+'/teacher-r4-full-native-actions-20261109-v1.json.gz',z.gzipSync(JSON.stringify({full,final})+'\n'),{flag:'wx'});
 console.log(JSON.stringify(proof));
}finally{m.dispose();}
