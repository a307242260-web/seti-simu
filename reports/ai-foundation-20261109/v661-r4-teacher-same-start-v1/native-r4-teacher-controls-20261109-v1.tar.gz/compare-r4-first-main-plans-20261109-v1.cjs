'use strict';
const fs=require('node:fs'),z=require('node:zlib'),assert=require('node:assert/strict');
const [helper,roots,history,out]=process.argv.slice(2),{open}=require(helper);
const read=p=>JSON.parse(fs.readFileSync(p)),x=JSON.parse(z.gunzipSync(fs.readFileSync(roots))),h=read(history).replaySteps,m=open(x.rows[0].before);
const rootsByInput=new Map(x.rows.map(r=>[r.decision.input,r]));
const planFor=r=>{
 const lines=new Map(r.q.lines.map(n=>[n.node,n])),result=[];
 let n=lines.get(0);
 for(let depth=0;n.distance;depth++){
  assert(depth<30);const edge=n.edges.find(e=>{const t=lines.get(e.target);return (depth||e.actionId===r.q.actionId)
   &&t?.value===n.value&&t.realization===n.realization&&t.preparationDebt===n.preparationDebt&&t.distance+e.cost===n.distance;});
  assert(edge);result.push(...edge.steps);n=lines.get(edge.target);
 }return result;
};
const facts=()=>{const f=m.facts();return {round:f.round,turn:f.turn,score:f.wallet.score,established:f.final,
 resources:f.wallet,income:f.income,computer:f.computer,blue:f.blue,tech:Object.keys(f.tech.ownedTiles),probes:f.probes.map(r=>[r.id,r.sectorX,r.sectorY,r.fossilId]),hand:f.hand.map(x=>x[1]),market:f.market.map(x=>x?.[1])};};
const teacher=(from,to)=>h.slice(from-1,to).map(e=>[e.action.actionId,e.action.summary]);
const selected=i=>planFor(rootsByInput.get(i)).map(id=>[id,null]);
const rows=[];
for(const [label,source,phases] of [
 ['teacher-launch-analysis-scan',249,[['main1',teacher(249,254)],['main2',teacher(255,264)],['main3',teacher(265,271)]]],
 ['orange1-instead-of-launch',249,[['main1',[...selected(249),...teacher(251,254)]],['main2',teacher(255,264)],['main3',teacher(265,271)]]],
 ['neptune-before-analysis',255,[['main2',selected(255)],['main3',teacher(255,264)]]],
 ['neptune-after-analysis',265,[['main3',selected(265)]]],
]){
 const start=rootsByInput.get(source).before;m.restore(start);const stages=[],accepted=[];
 let stop=null;
 for(const [name,inputs] of phases){
  const taken=[];
  for(const [id,summary] of inputs){
   const a=m.menu().find(a=>a.actionId===id);
   if(!a){stop={name,id,summary,facts:facts(),menu:m.menu(),checkpoint:m.save()};break;}
   taken.push(m.apply(a));accepted.push(a);
  }
  stages.push({name,taken,facts:facts(),checkpoint:m.save(),complete:!stop});if(stop)break;
 }
 const end=m.save();m.restore(start);accepted.forEach(m.apply);assert.deepEqual(m.save(),end);m.restore(start);
 rows.push({label,source,stages,stop,replayExact:true});
 console.log(JSON.stringify({label,stages:stages.map(s=>({name:s.name,complete:s.complete,facts:s.facts,steps:s.taken.length})),
  stop:stop&&{name:stop.name,summary:stop.summary,menu:stop.menu.slice(0,6).map(x=>x.summary)}}));
}
fs.writeFileSync(out,z.gzipSync(JSON.stringify(rows)+'\n'),{flag:'wx'});m.dispose();
