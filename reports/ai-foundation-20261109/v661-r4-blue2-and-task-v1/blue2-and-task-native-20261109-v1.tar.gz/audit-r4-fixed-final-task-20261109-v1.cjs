'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {open,seat}=require('./native-late-r3');const load=p=>require(path.resolve(p));
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const code=fs.readFileSync(file,'utf8'),hook='      if(!result&&resourcePlanning)result=quietScanTracePlan(node,stored,state);';assert.equal(code.split(hook).length,2);
mod._compile(code.replace(hook,`      if(result?.reason==='greedy-final-end-task-no-overflow')
        globalThis.auditFixedFinalTask({node,stored,state,policy:result,expand,nodes,valueObservation,known:knownCards(stored.envelope)});
`+hook),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=load('randomizer/game/ai/search-agent');
const evaluate=load('randomizer/game/ai/state-value').createStateValueEvaluator(seat), local=load('randomizer/game/ai/local-decision-plans');
const players=load('randomizer/game/players');const checked=[], negatives=new Set();
function owner(state){return state.players.players.find(p=>p.id===seat);}
globalThis.auditFixedFinalTask=({node,stored,state,policy,expand,nodes,valueObservation,known})=>{
 const session=stored.envelope.session.session, ruleId=session.queue[0].payload.ruleId;
 const raw={state,seatId:seat,actions:node.legalActions,session,knownCards:known};
 if(!negatives.has('unknown-task')){assert.equal(local.pureOptional({...raw,knownCards:new Set()}),null);negatives.add('unknown-task');}
 if(!negatives.has('second-effect')){const next={...session,queue:[...session.queue,session.queue[1]]};assert.equal(local.pureOptional({...raw,session:next}),null);negatives.add('second-effect');}
 if(!negatives.has('publicity-overflow')&&ruleId==='b60-jupiter-task'){
  const capped=structuredClone(state);owner(capped).resources.publicity=players.RESOURCE_LIMITS.publicity;
  assert.equal(local.pureOptional({...raw,state:capped}),null);negatives.add('publicity-overflow');
 }
 const confirm=expand(node,policy.selectedActionId), skip=expand(node,policy.excludedActionIds[0]);
 assert.equal(confirm.status,skip.status);assert.equal(confirm.boundary,skip.boundary);
 assert(['other-owner','information-barrier'].includes(confirm.status));
 const asState=n=>{const e=nodes.get(n).envelope;return e.session?.session?.workingState||JSON.parse(e.committedState);};
 const c=asState(confirm),s=asState(skip);assert.deepEqual(c.turn,s.turn);assert.deepEqual(c.meta.rngState,s.meta.rngState);
 const cV=evaluate.details(valueObservation(confirm)), sV=evaluate.details(valueObservation(skip));
 assert(cV.value>sV.value);
 assert.equal(cV.value-sV.value,ruleId==='b60-jupiter-task'?7.5:4);
 assert.equal(cV.purposePreparationDebt,sV.purposePreparationDebt);
 checked.push({ruleId,delta:cV.value-sV.value,status:confirm.status,claim:policy.selectedActionId});
};
const prev=require('./r4-blue2-pick-menu-official-cold-20261109-v1.json').corrected;
const candidate=require('./r4-blue2-fixed-end-task-official-cold-20261109-v1.json').corrected;
const root=require('./v661-r4-full-preflight-20261109-v1.json').checkpoint;
const oldRanking=require('./r4-quiet-data-official-profile-20261109-v2.json').roots;
const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 assert.equal(q.actionId,candidate.actionId);assert.equal(q.value,candidate.value);
 assert.equal(JSON.stringify(q.roots.map(r=>[r.actionId,r.value,r.realization,r.preparationDebt])),JSON.stringify(oldRanking));
 assert.equal(q.diagnostics.nativeExecutions,prev.native);assert.equal(checked.length,prev.native-candidate.native);
 assert.equal(negatives.size,3);
 const read=n=>JSON.parse(z.gunzipSync(fs.readFileSync(path.join(__dirname,n)))).rows;
 const a=read('candidate-blue2-pick-menu-native-20261109-v1.json.gz'),b=read('candidate-blue2-fixed-end-task-native-20261109-v1.json.gz');
 for(const [i,x] of b.entries()){
  const y=a[i];assert.equal(x.input,y.input);assert.equal(x.actionId,y.actionId);assert.equal(x.value,y.value);assert.deepEqual(x.ranking,y.ranking);assert.equal(x.native,y.native);
 }
 const facts={fixedDecisions:checked.length,declines:[...negatives],unchangedRootRankingAndRng:true,checked};
 fs.writeFileSync(process.argv[2],JSON.stringify(facts,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({fixed:facts.fixedDecisions,declines:facts.declines}));
}finally{port.close();m.dispose();}
