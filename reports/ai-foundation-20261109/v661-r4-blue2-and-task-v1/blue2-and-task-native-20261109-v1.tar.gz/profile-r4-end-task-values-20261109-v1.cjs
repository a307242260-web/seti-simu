'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {open,seat}=require('./native-late-r3');
const load=p=>require(path.resolve(p));
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const code=fs.readFileSync(file,'utf8'),hook='        &&source?.envelope.session?.session?.journal?.actions?.[0]?.action?.family==="analyze")resolvedPublicAnalysis.add(child);';assert.equal(code.split(hook).length,2);
mod._compile(code.replace(hook,hook+`
      if(sourceAction?.family==='accept_optional_effect'&&source?.envelope.session?.session?.journal?.actions?.[0]?.action?.family==='end_turn'){
        const session=source.envelope.session.session, task=session.queue[0]?.payload;
        if(task?.kind==='task')globalThis.collectEndTask({source:source.envelope,task,action:sourceAction,child,
          before:session.workingState,after:childState,valueObservation});
      }
`),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=load('randomizer/game/ai/search-agent');
const evaluate=load('randomizer/game/ai/state-value').createStateValueEvaluator(seat);
const bySource=new Map();
globalThis.collectEndTask=({source,task,action,child,before,after,valueObservation})=>{
 const owner=s=>s.players.players.find(p=>p.id===seat), prior=owner(before), now=owner(after);
 const pick=action.target.choiceId.startsWith('confirm:')?'claim':'skip';
 const group=bySource.get(source)||{rule:task.ruleId,card:task.cardInstanceId};bySource.set(source,group);
 assert(!group[pick]);
 const boundary=['other-owner','turn-boundary','information-barrier','terminal'].includes(child.status);
 const valuation=boundary?evaluate.details(valueObservation(child)):null;
 group[pick]={status:child.status,boundary:child.boundary,nextPlayer:after.turn.currentPlayerId,
  payout:Object.fromEntries(['score','credits','energy','publicity','availableData','handSize'].map(k=>[k,(now.resources[k]||0)-(prior.resources[k]||0)])),
  completedTasks:now.completedTaskCount-prior.completedTaskCount,reservationRemoved:prior.reservedCards.some(c=>c.id===task.cardInstanceId)
    &&!now.reservedCards.some(c=>c.id===task.cardInstanceId),rngExact:JSON.stringify(before.meta.rngState)===JSON.stringify(after.meta.rngState),
  value:valuation?.value??null,realized:valuation ? -valuation.unrealizedPurposeValue : null,debt:valuation?.purposePreparationDebt??null};
};
const original=require('./v661-r4-full-preflight-20261109-v1.json');
const wanted=require('./r4-blue2-pick-menu-official-cold-20261109-v1.json').corrected;
const m=open(original.checkpoint),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.equal(q.diagnostics.nativeExecutions,wanted.native);assert.deepEqual(m.save(),original.checkpoint);
 const pairs=[...bySource.values()],summary={};
 for(const pair of pairs){
  const {rule,claim,skip}=pair;
  assert(claim&&skip&&claim.rngExact&&skip.rngExact);
  const x=summary[rule]||={total:0,win:0,tie:0,loss:0,needsNative:0,statuses:{},valueDeltas:{}};x.total++;
  const key=`${claim.status}|${skip.status}`;x.statuses[key]=(x.statuses[key]||0)+1;
  if(claim.value==null||skip.value==null){x.needsNative++;continue;}
  const delta=claim.value-skip.value;x.valueDeltas[delta]=(x.valueDeltas[delta]||0)+1;
  if(delta>0)x.win++;else if(delta===0)x.tie++;else x.loss++;
 }
 fs.writeFileSync(process.argv[2],JSON.stringify({native:q.diagnostics.nativeExecutions,summary,pairs},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(summary));
}finally{p.close();m.dispose();}
