'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),z=require('node:zlib');
const {open,seat}=require('./native-late-r3');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const old=require('./r4-end-task-settle-official-profile-20261109-v2.json');
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const js=fs.readFileSync(file,'utf8'),anchor='      const child = finishChild(before, result, movementPlanning ? nextMovementIntent(node, requested) : null,';
assert.equal(js.split(anchor).length,2);
mod._compile(js.replace('    function expand(node, actionId) {','    function expand(node, actionId) {')
 .replace(anchor,`
      const auditPick = stored.envelope.session?.session?.queue?.[0]?.type === scienceSession.EFFECT_TYPES.PICK_CARD
        && stored.envelope.session.session.journal.actions[0]?.action?.family === 'place_data' && requested.family === 'choose_card';`+anchor)
 .replace('      if (quietSource && !quietDataMenuTemplate)',`
      if(auditPick)globalThis.auditBluePick({stored,requested,child,state:nodes.get(child),result,policy:cardPickSpec(node),known:knownCards(stored.envelope)});
      if (quietSource && !quietDataMenuTemplate)`),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const rows=[],groups={};
function paths(a,b,pre='',out=[]){
 if(Object.is(a,b)||out.length>=12)return out;
 if(a&&b&&typeof a==='object'&&typeof b==='object'){
  for(const k of new Set([...Object.keys(a),...Object.keys(b)]))paths(a[k],b[k],pre+'.'+k,out);
 }else out.push({p:pre,a:a??null,b:b??null});
 return out;
}
globalThis.auditBluePick=({stored,requested,child,state,result,policy,known})=>{
 const e=stored.envelope,s=e.session.session,a=s.workingState,b=JSON.parse(state.envelope.committedState);
 const card=a.cards.publicCards[requested.target.publicSlotIndex];
 const hold=a.players.players.find(p=>p.id===seat);
 const changes=Object.keys(a).filter(k=>JSON.stringify(a[k])!==JSON.stringify(b[k]));
 const details={actorMain:hold.mainActionCompleted,known:known.has(card.id),queued:s.queue.map(x=>x.type),
  bonuses:a.turn.cardTurnEventBonuses?.length||0,pendingTransport:Object.values(a.aliens.chong?.transportTasksByRocketId||{}).filter(j=>!j.delivered).length,
  fixed:policy?.fixed&&policy.selectedActionId===requested.actionId,control:!!stored.resourceControl,priorBarrier:stored.informationBarrier?.code||null,
  slot:requested.target.publicSlotIndex,after:child.status,barrier:child.boundary,actualBarrier:result.irreversibleBarrier?.code,
  actionFamilies:child.legalActions.map(a=>a.family),changes,rngExact:JSON.stringify(a.meta.rngState)===JSON.stringify(b.meta.rngState),pending:state.envelope.session?.session?.queue.map(e=>e.type)||[]};
 const key=JSON.stringify({...details,slot:undefined,actionFamilies:undefined});groups[key]=(groups[key]||0)+1;
 rows.push({...details,deltas:{aliens:paths(a.aliens,b.aliens),planets:paths(a.planets,b.planets),meta:paths(a.meta,b.meta),players:paths(a.players,b.players)}});
};
const m=open(root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const s=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(s.complete&&!s.unresolved.length);assert.deepEqual(m.save(),root);assert.equal(s.diagnostics.nativeExecutions,old.native);
 assert.equal(rows.length,old.categories['choose_card|science_domain_pick_card|place_data']);
 const facts={native:s.diagnostics.nativeExecutions,rows,groups:Object.entries(groups).map(([key,count])=>({count,...JSON.parse(key)}))};
 fs.writeFileSync(process.argv[2],JSON.stringify(facts,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(facts.groups.map(g=>({...g,deltas:rows.find(r=>r.changes.join('|')===g.changes.join('|')).deltas}))));
}finally{p.close();m.dispose();}
