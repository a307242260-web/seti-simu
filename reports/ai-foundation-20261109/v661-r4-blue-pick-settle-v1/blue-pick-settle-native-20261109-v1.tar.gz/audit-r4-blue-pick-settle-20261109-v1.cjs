'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {open,seat}=require('./native-late-r3');
const base=require('./r4-end-task-settle-official-profile-20261109-v2.json');
const candidate=require('./r4-blue-pick-settle-official-profile-20261109-v1.json');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const js=fs.readFileSync(file,'utf8'),start='      if(fixedBluePick){',end='        provedBluePickSettlements++;';
assert.equal(js.split(start).length,2);assert.equal(js.split(end).length,2);
mod._compile(js.replace(start,start+`
        const audited=globalThis.nativeBluePick({stored,requested,fixedBluePick,restoreEnvelope,executeCurrent,snapshot,
          comp:fork.composition||fork,known:knownCards(stored.envelope),
          finish:(before,result)=>finishChild(before,result,movementPlanning?nextMovementIntent(node,requested):null,
            null,stored.informationBarrier,requested,stored)});
`).replace(end,end+`
        globalThis.compareBluePick({audited,child,nodes,identity,expectedBarrier:boundary});
`),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const rows=[];
globalThis.nativeBluePick=({stored,requested,fixedBluePick,restoreEnvelope,executeCurrent,snapshot,comp,known,finish})=>{
 restoreEnvelope(stored.envelope,true);
 const raw=executeCurrent(requested);
 const native=snapshot(comp),prior=stored.envelope.session.session.workingState,after=JSON.parse(native.committedState);
 assert.equal(native.session,null);assert.deepEqual(fixedBluePick,after);
 assert.deepEqual(prior.meta.rngState,after.meta.rngState);
 const i=requested.target.publicSlotIndex, before=prior.cards.publicCards[i], refilled=after.cards.publicCards[i];
 assert(known.has(before.id)&&!known.has(refilled.id));assert.notEqual(before.id,refilled.id);
 assert.equal(after.players.players.find(p=>p.id===seat).hand.find(c=>c.id===before.id)?.blueBonusOwnerId,seat);
 return {native:finish(raw.before,raw.result),refilled:refilled.id,reward:before.id,slot:i,barrier:raw.result.irreversibleBarrier};
};
globalThis.compareBluePick=({audited,child,nodes,identity,expectedBarrier})=>{
 const {native,refilled,reward,slot,barrier}=audited;
 assert.deepEqual(barrier,expectedBarrier);
 assert.deepEqual(native.legalActions,child.legalActions);assert.equal(native.status,child.status);assert.equal(native.boundary,child.boundary);
 assert.deepEqual(nodes.get(native).intent,nodes.get(child).intent);assert.equal(identity(native),identity(child));
 const obs=child.observation;assert.deepEqual(native.observation,obs);
 assert.equal(obs.publicState.board.publicCards[slot]?.id,undefined);
 assert(!JSON.stringify(child.legalActions).includes(`"${refilled}"`));
 assert(obs.selfState.hand.some(c=>c.id===reward));
 rows.push({status:child.status,legalActions:child.legalActions.length,refillMasked:true});
};
const m=open(root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const s=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(s.complete&&!s.unresolved.length);assert.deepEqual(m.save(),root);
 assert.equal(s.actionId,base.action);assert.equal(s.value,base.value);
 const roots=s.roots.map(r=>[r.actionId,r.value,r.realization,r.preparationDebt]);
 assert.equal(JSON.stringify(roots),JSON.stringify(base.roots));assert.deepEqual(base.roots,candidate.roots);
 assert.equal(s.diagnostics.nativeExecutions,base.native);assert.equal(rows.length,base.native-candidate.native);
 assert.equal(s.analysis.provedBluePickSettlements,rows.length);
}finally{p.close();m.dispose();}
const counts={};for(const r of rows)counts[r.status]=(counts[r.status]||0)+1;
fs.writeFileSync(process.argv[2],JSON.stringify({nativeReplays:rows.length,counts,rows},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({nativeReplays:rows.length,counts}));
