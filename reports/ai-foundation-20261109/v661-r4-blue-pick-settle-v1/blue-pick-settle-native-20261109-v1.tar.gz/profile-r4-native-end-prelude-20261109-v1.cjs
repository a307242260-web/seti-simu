'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),z=require('node:zlib');
const {open,seat}=require('./native-late-r3');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const base=require('./r4-blue-pick-settle-official-profile-20261109-v1.json');
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const js=fs.readFileSync(file,'utf8'),anchor='      if (quietSource && !quietDataMenuTemplate)';
assert.equal(js.split(anchor).length,2);
mod._compile(js.replace(anchor,`
      if(requested.family==="end_turn"&&!stored.envelope.session)
        globalThis.auditEndPrelude({stored,requested,child,after:nodes.get(child).envelope,result,known:knownCards(stored.envelope)});
`+anchor),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const rows=[];
function changed(a,b,pre='',out=[]){
 if(Object.is(a,b)||out.length>=30)return out;
 if(a&&b&&typeof a==='object'&&typeof b==='object'){
  for(const k of new Set([...Object.keys(a),...Object.keys(b)]))changed(a[k],b[k],pre+'.'+k,out);
 }else out.push(pre);
 return out;
}
globalThis.auditEndPrelude=({stored,requested,child,after,result,known})=>{
 const before=JSON.parse(stored.envelope.committedState),s=after.session?.session,head=s?.queue[0],p=before.players.players.find(p=>p.id===seat);
 const current=s?.workingState||JSON.parse(after.committedState);
 rows.push({round:before.turn.roundNumber,status:child.status,priorBarrier:stored.informationBarrier?.code||null,
  nextBarrier:result.irreversibleBarrier?.code||null,nextSeat:current.turn.currentPlayerId,
  changes:changed(before,current),bonusCount:before.turn.cardTurnEventBonuses?.length||0,
  readyTasks:head?.payload?.ruleId?[head.payload.ruleId]:[],
  taskKnown:head?.payload?.cardInstanceId?known.has(head.payload.cardInstanceId):null,
  handoffs:s?.journal.effects.map(e=>e.type)||[],journalEvents:s?.journal.events.map(e=>e.type)||[],
  stable:!s,queue:s?.queue.map(e=>[e.type,e.ownerId])||[],before:stored.envelope,after,
  readyCardIds:p.reservedCards.filter(c=>known.has(c.id)).map(c=>c.cardId),action:requested.actionId});
};
const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const s=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(s.complete&&!s.unresolved.length);assert.deepEqual(m.save(),root);assert.equal(s.diagnostics.nativeExecutions,base.native);
 const expected=base.categories['end_turn|stable|—'];
 assert.equal(rows.length,expected);
 const groups={};
 for(const {round,status,nextBarrier,nextSeat,changes,bonusCount,readyTasks,taskKnown,handoffs,journalEvents,stable,queue} of rows){
  const k=JSON.stringify({round,status,nextBarrier,nextSeat,changes,bonusCount,readyTasks,taskKnown,handoffs,journalEvents,stable,queue});
  groups[k]=(groups[k]||0)+1;
 }
 const facts={native:s.diagnostics.nativeExecutions,inputs:rows.length,groups:Object.entries(groups).map(([k,count])=>({count,...JSON.parse(k)})),rows};
 fs.writeFileSync(process.argv[2],z.gzipSync(JSON.stringify(facts)+'\n'),{flag:'wx'});
 console.log(JSON.stringify({...facts,rows:undefined}));
}finally{port.close();m.dispose();}
