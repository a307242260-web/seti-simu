'use strict';
const fs=require('node:fs'),z=require('node:zlib'),assert=require('node:assert/strict'),{open}=require('./native-late-r3');
const [src,out]=process.argv.slice(2),{q,root,menu}=JSON.parse(z.gunzipSync(fs.readFileSync(src))).rows.find(r=>r.summary.i===359);
const {sumValueParts}=require(process.cwd()+'/randomizer/game/ai/state-value');
const m=open(root),rows=[];
try{
 for(const family of ['analyze','complete_task']){
  m.restore(root);
  const action=menu.find(x=>x.family===family),entry=q.roots.find(r=>r.actionId===action.actionId);
  const accepted=[],facts=[];
  function apply(id){
   const a=m.menu().find(x=>x.actionId===id);assert(a,id);accepted.push(m.apply(a));
   const f=m.facts();facts.push({family:a.family,label:a.summary,target:a.target,score:f.wallet.score,final:f.final,wallet:f.wallet,
    computer:f.computer,blue:f.blue,taskCount:f.taskCount,hand:f.hand,reserved:f.reserved});
  }
  apply(action.actionId);
  let line=q.lines[entry.target],proof=null;
  for(let i=0;i<64&&line.distance>0;i++){
   const edge=line.edges.find(e=>{
    const t=q.lines[e.target];return t.value===line.value&&t.realization===line.realization
     &&t.preparationDebt===line.preparationDebt&&t.distance+e.cost===line.distance;
   });
   assert(edge,JSON.stringify(line).slice(0,240));
   const target=q.lines[edge.target];
   if(target.planSummary){proof=target.planSummary;break;}
   for(const step of edge.steps||[edge.actionId])apply(step);
   line=target;
  }
  const end=m.save();m.restore(root);for(const action of accepted)m.apply(action);assert.deepEqual(m.save(),end);
  rows.push({family,entry,facts,proof,end,accepted});
  console.log(JSON.stringify({family,value:entry.value,path:facts.map(f=>[f.label,f.score,f.final,f.wallet.credits,f.wallet.energy,f.wallet.availableData,f.computer.length,f.blue.length]),proof:proof&&[proof.kind,proof.netGain]}));
 }
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({root,rows})+'\n'),{flag:'wx'});
}finally{m.dispose();}
