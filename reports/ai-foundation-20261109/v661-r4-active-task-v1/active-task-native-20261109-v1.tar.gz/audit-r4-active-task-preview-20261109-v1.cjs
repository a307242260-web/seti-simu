'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),assert=require('node:assert/strict'),Module=require('node:module');
const {isDeepStrictEqual}=require('node:util'),{open,seat}=require('./native-late-r3');const load=p=>require(path.resolve(p));
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const js=fs.readFileSync(file,'utf8'),start='      if (activeClaim) {',tail='        const child = finishProvedCommittedState(node, stored, requested, activeClaim);';
assert.equal(js.split(start).length,2);assert.equal(js.split(tail).length,2);
mod._compile(js.replace(start,start+`
        const auditNative=globalThis.auditActivePreview({stored,requested,activeClaim,restoreEnvelope,executeCurrent,snapshot,comp:fork.composition||fork,
          finish:(before,result)=>finishChild(before,result,movementPlanning ? nextMovementIntent(node,requested):null,
            null,stored.informationBarrier,requested,stored)});
`).replace(tail,tail+`
        globalThis.compareActivePreview({auditNative,child,nodes,identity});
`).replace('return Object.freeze({ createAnalysisPort });','return Object.freeze({ createAnalysisPort, forwardIdentity });'),file);
const {createAnalysisPort,forwardIdentity}=mod.exports,{createSearchAgent}=load('randomizer/game/ai/search-agent');
const owner=s=>s.players.players.find(p=>p.id===seat), findAction=(m,id)=>m.menu().find(a=>a.actionId===id);
const verified=[];
globalThis.auditActivePreview=({stored,requested,activeClaim,restoreEnvelope,executeCurrent,snapshot,comp,finish})=>{
 restoreEnvelope(stored.envelope,true);const raw=executeCurrent(requested);assert(raw.result.ok);
 const native=snapshot(comp);assert.equal(native.session,null);
 const before=JSON.parse(stored.envelope.committedState), after=JSON.parse(native.committedState);
 for(const k of Object.keys(after))assert(isDeepStrictEqual(after[k],activeClaim[k]),`state mismatch: ${k}`);
 assert.deepEqual(before.meta.rngState,after.meta.rngState);
 assert.equal(owner(after).completedTaskCount,owner(before).completedTaskCount+1);
 verified.push({rule:requested.target.ruleId,carryIntent:Boolean(stored.intent),score:owner(after).resources.score-owner(before).resources.score,
  credits:owner(after).resources.credits-owner(before).resources.credits,publicity:owner(after).resources.publicity-owner(before).resources.publicity});
 return finish(raw.before,raw.result);
};
globalThis.compareActivePreview=({auditNative,child,nodes,identity})=>{
 assert.deepEqual(auditNative.legalActions,child.legalActions);assert.equal(auditNative.status,child.status);assert.equal(auditNative.boundary,child.boundary);
 assert.deepEqual(nodes.get(auditNative).intent,nodes.get(child).intent);assert.equal(identity(auditNative),identity(child));
};
const prev=require('./r4-blue2-fixed-end-task-official-cold-20261109-v1.json').corrected;
const candidate=require('./r4-active-task-preview-official-cold-20261109-v1.json').corrected;
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const oldRanking=require('./r4-quiet-data-official-profile-20261109-v2.json').roots;
const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 assert.equal(q.actionId,candidate.actionId);assert.equal(q.value,candidate.value);
 assert.equal(JSON.stringify(q.roots.map(r=>[r.actionId,r.value,r.realization,r.preparationDebt])),JSON.stringify(oldRanking));
 assert.equal(q.diagnostics.nativeExecutions,prev.native);assert.equal(verified.length,prev.native-candidate.native);
 assert.equal(q.analysis.provedActiveFinalTaskInputs,verified.length);
}finally{port.close();m.dispose();}
const file2=path.join(__dirname,'r4-active-positive-task-20261109-v4.json.gz');
const {cases}=JSON.parse(z.gunzipSync(fs.readFileSync(file2))), endPairs=[], dataPairs=[];
const ruleKey=e=>forwardIdentity(e,'stable',null);
for(const c of cases){
 const {state:root,rule,cardId}=c;
 if(!c.simple&&!c.dataWitness)continue;
 const m=open(root);
 try{
  const claim=()=>m.act('complete_task',a=>a.target.ruleId===rule&&a.target.cardInstanceId===cardId);
  if(c.simple){
   claim();m.act('end_turn');const early=m.save();assert(!early.session);
   m.restore(root);m.act('end_turn');m.act('accept_optional_effect',a=>a.target.choiceId===`confirm:task:${cardId}:${rule}`);
   const delayed=m.save();assert(!delayed.session);
   assert.equal(ruleKey(early),ruleKey(delayed));
   assert.deepEqual(JSON.parse(early.committedState).meta.rngState,JSON.parse(delayed.committedState).meta.rngState);
   endPairs.push({index:c.index,rule,fullForwardIdentityEqual:true});
  }else{
   const steps=c.dataWitness.steps;
   claim();for(const id of steps){const a=findAction(m,id);assert(a,id);m.apply(a);}
   const early=m.save();
   m.restore(root);
   const completed=[];
   for(const id of steps){const a=findAction(m,id);if(!a)break;m.apply(a);completed.push(id);}
   const canDelay=completed.length===steps.length&&!m.save().session&&m.menu().some(a=>a.family==='complete_task'&&a.target.cardInstanceId===cardId&&a.target.ruleId===rule);
   if(canDelay)claim();
   const delayed=m.save();
   const equal=canDelay&&ruleKey(early)===ruleKey(delayed);
   dataPairs.push({index:c.index,steps,completed,canDelay,equal});
  }
  m.restore(root);assert.deepEqual(m.save(),root);
 }finally{m.dispose();}
}
assert.equal(endPairs.length,29);
const facts={nativePreviewReplays:verified.length,verified,endPairs,dataPairs,uncoveredCases:cases.length-endPairs.length-dataPairs.length};
fs.writeFileSync(process.argv[2],JSON.stringify(facts,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({proved:verified.length,end:endPairs.length,data:dataPairs.length,legalBefore:dataPairs.filter(p=>p.canDelay).length,
  dataStateEqual:dataPairs.filter(p=>p.equal).length,uncoveredCases:facts.uncoveredCases}));
