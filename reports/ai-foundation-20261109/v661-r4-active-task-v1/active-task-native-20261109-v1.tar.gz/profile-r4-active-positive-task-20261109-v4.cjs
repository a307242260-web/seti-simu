'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const [out]=process.argv.slice(2),{open,seat}=require('./native-late-r3');
function hooked(relative,anchor,hook){
 const file=path.resolve(relative),mod=new Module(file,module);
 mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
 const js=fs.readFileSync(file,'utf8');assert.equal(js.split(anchor).length,2);
 mod._compile(js.replace(anchor,hook),file);return mod.exports;
}
const {createAnalysisPort}=hooked('randomizer/game/ai/analysis-port.js','      nodeCount += 1;\n      return node;',
  '      nodeCount += 1;\n      globalThis.noteCargoState(node,envelope);\n      return node;');
const search=hooked('randomizer/game/ai/decision-search.js','    const lines = nodes.map((entry, index) => ({',
  '    globalThis.noteCargoClaimGraph(nodes,port);\n    const lines = nodes.map((entry, index) => ({');
const {OPTIONS,BUDGET}=require(path.resolve('randomizer/game/ai/search-agent'));
const stateValue=require(path.resolve('randomizer/game/ai/state-value')),evaluate=stateValue.createStateValueEvaluator(seat);
let states,report;
globalThis.noteCargoState=(node,e)=>states.set(node,e);
const family=a=>a.split(':')[0];
let graphNative;
globalThis.noteCargoClaimGraph=(nodes,port)=>{
 graphNative=port.getDiagnostics().submissionCount;
 const cases=[];
 const dataWitness=entry=>{
  if(family(entry.best?.actionId||'')!=='place_data')return null;
  const result=[];let cursor=entry;
  do {
   const best=cursor.best;
   if(best?.turnTailPlanValue||best?.knownIncomePlan){
    const summary=best.turnTailPlanValue||best.knownIncomePlan;
    const candidates=cursor.alternatives.filter(a=>a.firstActionId===best.actionId&&a.resourcePlan).map(a=>a.resourcePlan);
    const goals=summary.dataPlans?.map(p=>p.goal?.id)||[];
    const selected=best.provedResourcePlan||candidates.find(p=>goals.includes(p.goal.id))||(candidates.length===1?candidates[0]:null);
    if(!selected)return {unmaterialized:{keys:Object.keys(summary),goals,candidates:candidates.map(c=>c.goal.id)}};
    const actual=port.expandResourcePlan(cursor.node,selected,()=>null);
    assert(actual.complete&&actual.prefixes.length);
    return {steps:[...result,...actual.prefixes.map(p=>p.action.actionId)],boundary:actual.node.status,materializedProof:true};
   }
   if(!best||result.length>4)return null;
   result.push(...(best.steps||[best.actionId]));
   cursor=nodes[best.target];
  }while(cursor.node.status==='decision');
  return {steps:result,boundary:cursor.node.status};
 };
 const best=(e)=>e.edges.filter(x=>{
  const n=nodes[x.target];
  return n.value===e.value&&n.realization===e.realization&&n.preparationDebt===e.preparationDebt
    &&n.distance+x.cost===e.distance;
 }).map(x=>family(x.actionId));
 for(const [index,e] of nodes.entries()){
  for(const edge of e.edges.filter(x=>family(x.actionId)==='complete_task')){
   const child=nodes[edge.target],a=e.node.legalActions.find(x=>x.actionId===edge.actionId),envelope=states.get(e.node);
   const s=envelope.session?.session?.workingState||JSON.parse(envelope.committedState),p=s.players.players.find(p=>p.id===seat);
   const end=e.edges.find(x=>family(x.actionId)==='end_turn'),tail=end?.turnTailPlanValue?.quietCargoChoice;
   const fixed=child.edges.map(x=>family(x.actionId)),physical=child.node.legalActions.map(x=>x.family);
   const simple=child.edges.length>0&&fixed.every(k=>k==='end_turn');
   cases.push({index,target:edge.target,rule:a.target.ruleId,cardId:a.target.cardInstanceId,main:p.mainActionCompleted,pool:p.resources.availableData,
     sameRanking:end?child.value===nodes[end.target].value&&child.realization===nodes[end.target].realization&&child.preparationDebt===nodes[end.target].preparationDebt:false,
     dataWitness:dataWitness(child),mainChild:child.node.status,endEdge:end?.target??null,activeCost:edge.cost,activeSteps:edge.steps,endSteps:end?.steps,
     bestSuffix:child.best ? {actionId:child.best.actionId, steps:child.best.steps||[child.best.actionId], goal:child.best.resourcePlan?.goal?.id||null} : null,
     usedInBest:best(e).includes('complete_task'),bestAfter:best(child),simple,tail:!!tail,
     value:child.value,endValue:end?nodes[end.target].value:null,realization:child.realization,
     state:envelope,after:states.get(child.node),edges:fixed,physical});
  }
 }
 report=cases;
};
const baseline=require('./r4-blue2-fixed-end-task-official-cold-20261109-v1.json').corrected;
const ranking=require('./r4-quiet-data-official-profile-20261109-v2.json').roots;
const official=require('./v661-r4-full-preflight-20261109-v1.json');
const m=open(official.checkpoint),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 states=new WeakMap();report=[];
 const root=p.openRoot(),q=search.searchDecision({port:p,root,evaluate,budget:BUDGET,...OPTIONS,modelKey:evaluate.modelKey});
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),official.checkpoint);
 assert.equal(graphNative,baseline.native);
 assert.equal(JSON.stringify(q.roots.map(r=>[r.actionId,r.value,r.realization,r.preparationDebt])),JSON.stringify(ranking));
 const breakdown={};
 for(const c of report){const k=[c.rule,c.main?'post':'pre',c.mainChild,c.simple?'end-only':(c.edges.sort().join(',')||'boundary'),c.sameRanking?'same-rank':'other-rank',c.usedInBest?'best':'other'].join('|');breakdown[k]=(breakdown[k]||0)+1;}
 assert.equal(report.length,74);
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({native:graphNative,proofReplayExtraInputs:q.diagnostics.nativeExecutions-graphNative,breakdown,cases:report})+'\n'),{flag:'wx'});
 console.log(JSON.stringify(breakdown));
}finally{p.close();m.dispose();}
