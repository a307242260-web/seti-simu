'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),assert=require('node:assert/strict'),Module=require('node:module');
const {open,seat}=require('./native-late-r3');
const [source,selector,out]=process.argv.slice(2),i=Number(selector),root=JSON.parse(z.gunzipSync(fs.readFileSync(source))).rows.find(x=>x.summary.i===i).root;
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
let js=fs.readFileSync(file,'utf8');
for(const [anchor,kind,where] of [
 ['provedOwnEndHandovers++;','own-end','after'],
 ['const child = finishChild({session:null}, {}, movementPlanning ? nextMovementIntent(node, requested) : null,\n          null, stored.informationBarrier, requested, stored, {envelope:menuPreview, inspection});','data-menu','after'],
 ['const child = finishChild({session:null}, {}, movementPlanning ? nextMovementIntent(node, requested) : null,\n          null, stored.informationBarrier, requested, stored, {envelope:pickPreview, inspection});','blue-pick-menu','after'],
 ['const child = finishProvedCommittedState(node, stored, requested, state);\n        return rememberPrefix','data-settlement','between']]){
 assert.equal(js.split(anchor).length,2,kind);
 const mark=`\n        globalThis.auditTail("${kind}",stored.envelope,requested,nodes.get(child).envelope,child.status,child.legalActions);\n`;
 js=js.replace(anchor,where==='between'?anchor.replace('\n        return rememberPrefix',mark+'        return rememberPrefix'):anchor+mark);
}
mod._compile(js,file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const rows=[];
globalThis.auditTail=(kind,from,action,after,status,menu)=>rows.push({kind,from,action,after,status,menu});
const m=open(root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
const canon=(o,id)=>id&&o?JSON.parse(JSON.stringify(o).split(id).join('canonical-session')):o;
const firstDiff=(a,b,p='')=>{
 if(Object.is(a,b))return null;
 if(!a||!b||typeof a!=='object'||typeof b!=='object')return [p,a,b];
 for(const k of new Set([...Object.keys(a),...Object.keys(b)])){const x=firstDiff(a[k],b[k],p+'.'+k);if(x)return x;}
 return null;
};
try{
 const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 const groups={};for(const [index,row] of rows.entries()){
  const {composition:n}=m.c.counterfactualPort.createFork(row.from,{branchKey:"independent-quiet-tail",restoreRandomState:true});
  const menu=()=>n.inspect().session?.decision?.choices||n.inputPort.enumerateActions({});
  try{
   const d=n.inspect().session?.decision,action=menu().find(a=>a.actionId===row.action.actionId);
   assert(action,`${index} ${row.kind} native input`);
   const r=d?n.inputPort.submitDecision({decisionId:d.decisionId,decisionVersion:d.decisionVersion,ownerId:d.ownerId,choice:action})
    :action.phase==='quick'?n.inputPort.submitQuickAction(action):n.inputPort.submitAction(action);
   assert(r.ok);
   const a=n.lifecycle.save().envelope,b=row.after,sa=a.session?.session?.sessionId,sb=b.session?.session?.sessionId;
   const committedDiff=firstDiff(JSON.parse(a.committedState),JSON.parse(b.committedState));
   const sessionDiff=firstDiff(canon(a.session,sa),canon(b.session,sb));
   assert(!committedDiff,`${index} ${row.kind} ${row.action.summary} committed ${committedDiff?.[0]}`);
   assert(!sessionDiff,`${index} ${row.kind} ${row.action.summary} session ${sessionDiff?.[0]}`);
   const before=row.from.session?.session?.workingState||JSON.parse(row.from.committedState);
   const exact=a.session?.session?.workingState||JSON.parse(a.committedState);
   assert.deepEqual(before.meta.rngState,exact.meta.rngState);
   if(row.menu.length){
    const native=canon(menu(),sa),retained=canon(row.menu,sb);
    for(const choice of retained)assert(native.some(a=>a.actionId===choice.actionId&&firstDiff(a,choice)===null),`${index} ${row.kind} native menu ${choice.summary}`);
   }
   row.nativeExact=true;
   const inTransit=Object.values(before.aliens.chong?.transportTasksByRocketId||{}).filter(t=>!t.delivered).length;
   const k=row.kind+':'+inTransit;groups[k]=(groups[k]||0)+1;
  }finally{n.dispose();}
 }
 const saved={i,native:q.diagnostics.nativeExecutions,logical:q.diagnostics.transitions,groups,rows};
 fs.writeFileSync(out,z.gzipSync(JSON.stringify(saved)+'\n'),{flag:'wx'});
 console.log(JSON.stringify({...saved,rows:rows.length}));
}finally{p.close();m.dispose();}
