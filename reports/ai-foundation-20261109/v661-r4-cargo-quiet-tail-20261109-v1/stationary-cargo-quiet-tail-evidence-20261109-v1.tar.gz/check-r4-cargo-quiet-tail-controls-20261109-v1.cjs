'use strict';
const fs=require('node:fs'),z=require('node:zlib'),assert=require('node:assert/strict'),path=require('node:path');
const {open,seat}=require('./native-late-r3');
const load=n=>require(path.resolve(n)),local=load('randomizer/game/ai/local-decision-plans'),
 {createAnalysisPort}=load('randomizer/game/ai/analysis-port'),solar=load('randomizer/solar-system/core'),rockets=load('randomizer/game/rockets'),data=load('randomizer/game/data');
const [source,out]=process.argv.slice(2),rows=JSON.parse(z.gunzipSync(fs.readFileSync(source))).rows;
const choices=rows.filter(x=>x.kind==='own-end');
let fixture;
for(const row of choices){
 const s=JSON.parse(row.from.committedState),earth=solar.createSolarSnapshot(s.solarSystem).planetLocations.find(e=>e.planetId==='earth');
 const rocket=s.pieces.rockets.find(r=>r.kind==='chong-fossil'&&r.sectorX===earth.x&&Math.abs(r.sectorY-earth.y)===1);
 if(data.canPlaceAnyData(s.players.players.find(p=>p.id===seat)).ok&&rocket&&rockets.canMoveRocket(s.pieces,rocket.id,0,earth.y-rocket.sectorY).ok){fixture={row,s,earth,rocket};break;}
}
assert(fixture);
const {row,s,earth,rocket}=fixture,p=s.players.players.find(p=>p.id===seat),known=new Set(p.reservedCards.map(c=>c.id));
const preview=(state=s,knownCards=known)=>local.previewFinalOwnQuietEnd({state,seatId:seat,action:row.action,knownCards});
assert(preview());
assert(!local.hasPendingFossilArrival(s));
assert.equal(preview(s,new Set()),null);
const foreign=structuredClone(s);foreign.turn.passedPlayerIds.pop();assert.equal(preview(foreign),null);
const bonus=structuredClone(s);bonus.turn.cardTurnEventBonuses=[{}];assert.equal(preview(bonus),null);
const arrival=structuredClone(s);assert(rockets.moveRocket(arrival.pieces,rocket.id,0,earth.y-rocket.sectorY).ok);
assert(local.hasPendingFossilArrival(arrival));
assert.equal(preview(arrival),null);
const m=open({...row.from,committedState:JSON.stringify(arrival)});
let res;
try{
 const action=m.menu().find(a=>a.family==='place_data');assert(action);
 const port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 const root=port.openRoot();
 try{
  port.setResourcePlanning(true);
  port.expand(root,action.actionId);
  assert.equal(port.getDiagnostics().submissionCount,1);
 }finally{port.close();}
 const b=m.save();
 m.apply(action);
 const after=m.state();
 const task=Object.values(after.aliens.chong.transportTasksByRocketId).find(t=>t.fossilId===rocket.fossilId);
 assert(task?.delivered);
 assert.notDeepEqual(m.save(),b);
 res={unknownReservedDeclined:true,foreignSeatDeclined:true,turnBonusDeclined:true,realCargoArrivalDeclined:true,
  realDataInputDeliversCargo:true,fossilId:rocket.fossilId};
}finally{m.dispose();}
fs.writeFileSync(out,JSON.stringify(res,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(res));
