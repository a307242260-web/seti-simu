'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const load=n=>require(path.resolve(n)),solar=load('randomizer/solar-system/core'),rockets=load('randomizer/game/rockets'),
 ability=load('randomizer/game/abilities/rocket'),turn=load('randomizer/game/turn-flow'),chong=load('randomizer/game/aliens/chong');
const [fixture,out]=process.argv.slice(2),{rows,accepted}=JSON.parse(z.gunzipSync(fs.readFileSync(fixture)));
const same=(a,b)=>a.x===b.x&&a.y===b.y;
const root=rows.find(r=>r.summary.i===318).root,m=open(root);
const maxPaid=4,limit=64;
function shortest(state,ship,destination,owner){
 const move=rockets.createStaticCoordinateMoveQuery(state.pieces,ship.id),start=rockets.getRocketSectorCoordinate(ship);
 const frontier=[{at:start,points:0,path:[]}],best=new Map([[start.x+':'+start.y,0]]);
 let settled=0;
 while(frontier.length){
  frontier.sort((a,b)=>a.points-b.points);
  const x=frontier.shift(),key=x.at.x+':'+x.at.y;
  if(best.get(key)!==x.points)continue;
  if(++settled>limit)throw new Error('FOSSIL_TIMING_GEOMETRY_LIMIT');
  if(same(x.at,destination))return {points:x.points,path:x.path,settled};
  const moveCost=ability.getRequiredMovePointsFromCoordinate(state,owner,x.at);
  if(x.points+moveCost>maxPaid)continue;
  for(const {deltaX,deltaY} of ability.MOVE_DIRECTIONS){
   const n=move(x.at,deltaX,deltaY);if(!n.ok)continue;
   const k=n.to.x+':'+n.to.y,p=x.points+moveCost;
   if((best.get(k)??Infinity)<=p)continue;
   best.set(k,p);frontier.push({at:n.to,points:p,path:[...x.path,{deltaX,deltaY,at:n.to}]});
  }
 }
 return null;
}
const earth=s=>solar.createSolarSnapshot(s.solarSystem).planetLocations.find(p=>p.planetId==='earth');
const owner=s=>s.players.players.find(p=>p.id===seat);
const snapshot=s=>({earth:earth(s),cargo:s.pieces.rockets.filter(r=>r.playerId===seat&&r.fossilId)
 .map(r=>({id:r.id,fossilId:r.fossilId,at:rockets.getRocketSectorCoordinate(r)}))});
try{
 const state=m.state(),visible=m.owner(seat),now=earth(state),p=owner(state);
 assert.equal(state.turn.currentPlayerId,seat);
 assert(!p.mainActionCompleted);
 assert(!p.industryBorrowedTechTileId&&!state.turn.cardTurnEventBonuses.some(b=>b.movementModifiers));
 const jobs=Object.values(state.aliens.chong.transportTasksByRocketId).map(t=>{
  const card=p.reservedCards.find(c=>c.id===t.cardId&&visible.selfState.reservedCards.some(r=>r.id===c.id));
  const ship=state.pieces.rockets.find(r=>r.playerId===seat&&r.fossilId===t.fossilId);
  assert(card&&ship&&!t.delivered&&t.destinationPlanetId==='earth'&&chong.getCardTask(card).kind==='transport');
  assert(visible.publicState.board.rockets.some(r=>r.id===ship.id&&r.fossilId===ship.fossilId));
  return {ship,fossilId:t.fossilId};
 });
 assert.equal(jobs.length,2);
 const offers=new Map([['wait',m.menu().find(a=>a.target?.skip===true)]]);
 for(const {ship,fossilId} of jobs){
  const at=rockets.getRocketSectorCoordinate(ship);
  const direction=m.menu().find(a=>a.target.rocketId===ship.id&&a.target.deltaX===0&&a.target.deltaY===Math.sign(now.y-at.y));
  assert(at.x===now.x&&direction);
  const to=rockets.createStaticCoordinateMoveQuery(state.pieces,ship.id)(at,direction.target.deltaX,direction.target.deltaY);
  assert(to.ok);
  offers.set(same(to.to,now)?'deliver':'stage',{...direction,fossilId});
 }
 assert.equal(offers.size,3);
 const quotes=[];
 for(const [kind,offer] of offers){
  assert(offer);
  const projected=structuredClone(state);
  if(kind!=='wait')assert(rockets.moveRocket(projected.pieces,offer.target.rocketId,offer.target.deltaX,offer.target.deltaY).ok);
  assert(turn.rotateSolarSystem(projected,1,seat,{captureSnapshots:false}).ok);
  const dest=earth(projected),paths=jobs.map(({ship,fossilId})=>{
   const token=projected.pieces.rockets.find(r=>r.id===ship.id);
   return {fossilId,route:kind==='deliver'&&offer.fossilId===fossilId
    ?{points:0,path:[],settled:0}:shortest(projected,token,dest,owner(projected))};
  });
  assert(paths.every(x=>x.route));
  const paid=paths.reduce((n,x)=>n+x.route.points,0);
  quotes.push({kind,action:offer.summary,actionId:offer.actionId,paid,affordableWithoutLaterRewards:paid<=p.resources.energy,paths,projected:snapshot(projected)});
 }
 assert.deepEqual(m.save(),root);
 quotes.sort((a,b)=>a.paid-b.paid);
 const [best,second]=quotes;
 assert(best.affordableWithoutLaterRewards&&best.paid<second.paid);
 assert.equal(best.kind,'stage');
 const native=[];
 for(const {kind,actionId,projected} of quotes){
  m.restore(root);const steps=[m.apply(m.menu().find(a=>a.actionId===actionId))],research=m.menu().find(a=>a.family==='research_tech');
  assert(research&&research.actionId===accepted[319-301].actionId);
  steps.push(m.apply(research));
  const expected=accepted[320-301];
  if(m.menu().some(a=>a.actionId===expected.actionId))steps.push(m.apply(expected));
  const actual=snapshot(m.state());
  assert.deepEqual(actual,projected);
  const saved=m.save();
  m.restore(root);steps.forEach(m.apply);assert.deepEqual(m.save(),saved);
  native.push({kind,actual,steps,exact:true});
 }
 const result={conditionalOn:'same-turn legal standard research; one rotation before tech reward; no future free moves or random rewards credited',
  costsExclude:'benefits and costs of discarding the already-paid card and selecting a specific technology',
  currentEnergy:p.resources.energy,selected:best.action,quotes,native};
 fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({selected:best.action,quotes:quotes.map(q=>[q.kind,q.paid,q.paths.map(x=>[x.fossilId,x.route.points,x.route.settled])]),native:native.map(x=>x.exact)}));
}finally{m.dispose();}
