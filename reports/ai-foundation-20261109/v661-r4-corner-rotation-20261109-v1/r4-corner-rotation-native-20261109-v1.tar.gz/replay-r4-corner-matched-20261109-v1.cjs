'use strict';
const fs=require('node:fs'),z=require('node:zlib'),assert=require('node:assert/strict');
const {open}=require('./native-late-r3');
const path=require('node:path'),solar=require(path.resolve('randomizer/solar-system/core')),rockets=require(path.resolve('randomizer/game/rockets'));
const [source,out]=process.argv.slice(2);
const {rows,accepted}=JSON.parse(z.gunzipSync(fs.readFileSync(source)));
const moveRoot=rows.find(x=>x.summary.i===318).root;
const preCornerRoot=rows.find(x=>x.summary.i===317).root;
const target=i=>accepted[i-301];
const cargo=m=>Object.values(m.state().aliens.chong.transportTasksByRocketId)
  .map(t=>({fossil:t.fossilId,card:t.cardId,delivered:!!t.delivered}));
const earth=m=>solar.createSolarSnapshot(m.state().solarSystem).planetLocations.find(p=>p.planetId==='earth');
const facts=m=>{const f=m.facts(),p=earth(m);return {earth:[p.x,p.y],board:f.wallet.score,established:f.final,
  wallet:f.wallet,hand:f.hand.map(h=>h[1]),income:f.income,tech:Object.keys(f.tech.ownedTiles).filter(k=>f.tech.ownedTiles[k]),
  computer:f.computer,blue:f.blue,cargo:cargo(m),probes:f.probes.map(p=>[p.id,p.fossilId,p.sectorX,p.sectorY]),rng:f.rng};};
const results=[];
for(const mode of ['teacher','direct-save-energy','direct-restage','direct-restage-aim','keep-card']) {
 const root=mode==='keep-card'?preCornerRoot:moveRoot;
 const m=open(root),inputs=[],edits=[],stages=[];let stopped=null;
 try {
  const enter=(i,a,why)=>{const expected=target(i);if(why)edits.push({i,why,from:expected.summary,to:a?.summary||null});
   if(a)inputs.push(m.apply(a));};
  const find=p=>m.menu().find(p);
  const settle=(i,which,card,why)=>{
   const a=find(a=>a.family==='accept_optional_effect'&&a.target.choiceId===which+':chong_task:'+card+':transport');
   if(a)enter(i,a,why);
   return a;
  };
  for(let i=318;i<=359;i++){
   const expected=target(i);
   if(mode==='keep-card'){
    if(i===318)enter(i,null,'keep the card; no corner or free movement');
    else {
     const a=find(a=>a.actionId===expected.actionId&&a.actorId===expected.actorId);
     if(a)enter(i,a);
     else if([354,359].includes(i)&&cargo(m).some(t=>t.fossil==='fossil_07'&&!t.delivered))enter(i,null,'fossil_07 cannot be claimed');
     else {stopped={i,expected:expected.summary,menu:m.menu()};break;}
    }
   }else if(mode!=='teacher'){
    if(i===318){const a=find(a=>a.target?.rocketId===8&&a.target?.deltaY===-1);assert(a);enter(i,a,'direct delivery of fossil_06');}
    else if(i===323) {
     assert(settle(i,'skip','alien-chong-3-10','skip the undelivered fossil_07 settlement'));
     assert(settle(i,'confirm','alien-chong-6-16','claim fossil_06 at its first legal settlement, before the same analysis'));
     if(mode.startsWith('direct-restage')){
      const a=find(a=>a.actionId===expected.actionId);assert(a);enter(i,a);
     } else enter(i,null,'save the energy formerly used to move R8');
    }else if(i===324){
     if(mode.startsWith('direct-restage')){
      const a=find(a=>a.target?.rocketId===6&&a.target?.deltaY===-1);assert(a);enter(i,a,'reuse paid movement to advance fossil_07');
     }else enter(i,null,'no paid movement');
    }else if(i===351&&mode==='direct-restage-aim'){
     const state=m.state(),ship=state.pieces.rockets.find(r=>r.fossilId==='fossil_07'),at=rockets.getRocketSectorCoordinate(ship),dest=earth(m);
     const move=rockets.createStaticCoordinateMoveQuery(state.pieces,ship.id);
     const a=find(a=>{if(a.target?.rocketId!==ship.id)return false;const n=move(at,a.target.deltaX,a.target.deltaY);
      return n.ok&&n.to.x===dest.x&&n.to.y===dest.y;});
     const fallback=find(a=>a.actionId===expected.actionId);
     assert(a||fallback);
     enter(i,a||fallback,a?'steer the already known scan move to the current Earth':'no one-step direction reaches the current Earth');
    }else if(i===325||i===354||i===359){
     const a=find(a=>a.actionId===expected.actionId);
     if(a)enter(i,a);
     else if(i===325||i===359) {
      const ready=find(a=>a.family==='complete_task'&&a.target?.ruleId==='transport');
      if(ready)enter(i,ready,'claim the actually delivered transport at matched checkpoint');
      else enter(i,null,'no claimable transport at matched checkpoint');
     }else if(!find(a=>a.family==='accept_optional_effect')) enter(i,null,'no optional claim menu');
     else {stopped={i,expected:expected.summary,menu:m.menu()};break;}
    }else{
     const a=find(a=>a.actionId===expected.actionId&&a.actorId===expected.actorId);
     if(!a){stopped={i,expected:expected.summary,menu:m.menu()};break;}
     enter(i,a);
    }
   }else enter(i,expected);
   if([318,322,323,324,325,327,347,350,351,354,359].includes(i))stages.push({i,...facts(m)});
  }
  const end=m.save(),endFacts=facts(m);
  m.restore(root);for(const a of inputs)m.apply(a);assert.deepEqual(m.save(),end);
  results.push({mode,inputs,edits,stages,stopped,end,endFacts,exactReplay:true});
  console.log(JSON.stringify({mode,edits,stopped:stopped&&{i:stopped.i,expected:stopped.expected,menu:stopped.menu.map(a=>a.summary).slice(0,6)},
   endFacts,inputs:inputs.length,coords:stages.filter(s=>[324,350,351].includes(s.i)).map(s=>[s.i,s.earth,s.probes.filter(p=>p[1])])}));
 }finally{m.dispose();}
}
fs.writeFileSync(out,z.gzipSync(JSON.stringify(results)+'\n'),{flag:'wx'});
