'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const [source,official,which]=process.argv.slice(2);
const {rows,accepted}=JSON.parse(z.gunzipSync(fs.readFileSync(source)));
const i=Number(which);
const root=which==='official'?JSON.parse(fs.readFileSync(official)).checkpoint:rows.find(x=>x.summary.i===i).root;
const m=open(root),menu=m.menu();
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:menu}).search;
 assert.deepEqual(m.save(),root);
 const wanted=which==='official'?[]:i===318?[accepted[i-301].actionId,menu.find(a=>a.target?.rocketId===8&&a.target?.deltaY===-1).actionId]:[accepted[i-301].actionId];
 const targets=wanted.map(id=>{const r=q.roots.find(x=>x.actionId===id);return {action:menu.find(a=>a.actionId===id)?.summary,policy:r?.policy,status:r?.completion,value:r?.value};});
 console.log(JSON.stringify({which,chosen:menu.find(a=>a.actionId===q.actionId)?.summary,value:q.value,
  complete:q.complete,unresolved:q.unresolved.length,ms:q.rootAndSearchMilliseconds,native:q.diagnostics.nativeExecutions,targets,rootAndRngExact:true}));
}finally{p.close();m.dispose();}
