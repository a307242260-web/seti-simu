'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const {rows,accepted}=JSON.parse(z.gunzipSync(fs.readFileSync(path.join(__dirname,'teacher-r4-ready-transport-cold-20261109-v1.json.gz'))));
const solar=require(path.resolve('randomizer/solar-system/core'));
const rockets=require(path.resolve('randomizer/game/rockets'));
const fixture=rows.find(r=>r.summary.i===318),stable=rows.find(r=>r.summary.i===317);
const action317=accepted[317-301],action318=accepted[318-301];
const facts=m=>{
 const state=m.state(),turn=state.turn,f=m.facts();
 const dest=solar.collectPlanetLocations(state.solarSystem).find(p=>p.planetId==='earth');
 return {score:f.wallet.score,established:f.final,wallet:f.wallet,hand:f.hand.map(a=>a[1]),planet:[dest.x,dest.y],
  probes:f.probes.map(r=>[r.id,r.fossilId,rockets.getRocketSectorCoordinate(r)]),
  jobs:Object.values(state.aliens.chong.transportTasksByRocketId).map(x=>[x.fossilId,!!x.delivered]),
  actor:turn.currentPlayerId,turn:turn.turnNumber,main:f.main};
};
const m=open(stable.root),out=[];
try{
 const noPay=facts(m);m.apply(action317);
 const afterCorner=facts(m);
 assert.deepEqual(JSON.parse(m.save().committedState),JSON.parse(fixture.root.committedState));
 assert.equal(m.save().session.session.queue[0].type,fixture.root.session.session.queue[0].type);
 for(const action of fixture.menu){
  m.restore(fixture.root);const pre=facts(m),legal=m.menu().find(a=>a.actionId===action.actionId);assert(legal);
  m.apply(legal);const first=facts(m),menu=m.menu().map(a=>[a.family,a.summary,a.target]);
  const follow=[];let blocked=null;
  for(let i=319;i<=359;i++){
   const intended=accepted[i-301],option=m.menu().find(a=>a.actorId===intended.actorId&&a.actionId===intended.actionId);
   if(!option){blocked={step:i,expected:intended.summary,actionId:intended.actionId,menu:m.menu().map(a=>[a.family,a.summary,a.target])};break;}
   m.apply(option);follow.push(option.actionId);
  }
  const end=m.save();m.restore(fixture.root);m.apply(legal);
  for(const id of follow){const a=m.menu().find(a=>a.actionId===id);assert(a);m.apply(a);}
  assert.deepEqual(m.save(),end);
  out.push({action:{id:action.actionId,summary:action.summary,target:action.target},teacher:action.actionId===action318.actionId,pre,first,
   menu,follow,blocked,endFacts:facts(m),checkpoint:end,fullNativeReplayExact:true});
 }
 assert.equal(out.find(x=>x.teacher).blocked,null);
 fs.writeFileSync(process.argv[2],z.gzipSync(JSON.stringify({noPay,afterCorner,rows:out})+'\n'),{flag:'wx'});
 console.log(JSON.stringify(out.map(x=>({a:x.action.summary,teacher:x.teacher,earth:x.first.planet,probes:x.first.probes,
  jobs:x.first.jobs,firstScore:x.first.score,blocked:x.blocked&&[x.blocked.step,x.blocked.expected],follow:x.follow.length}))));
}finally{m.dispose();}
