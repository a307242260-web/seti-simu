'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const [source,out]=process.argv.slice(2),{open,seat}=require('./native-late-r3');
const file=path.resolve('randomizer/game/ai/analysis-port.js');
const mod=new Module(file,module);mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
let js=fs.readFileSync(file,'utf8');
const hooks=[
 ['    function executeCurrent(current) {','\n      globalThis.countNativeCargo(current);'],
 ['    function expand(node, actionId) {','\n      globalThis.trackCargoJoin(nodes.get(node)?.envelope,actionId,resourceSpecs.get(node));'],
];
for(const [anchor,hook] of hooks){assert.equal(js.split(anchor).length,2);js=js.replace(anchor,anchor+hook);}
const exportHook='return Object.freeze({ createAnalysisPort });';
assert(js.includes(exportHook));mod._compile(js.replace(exportHook,'return Object.freeze({ createAnalysisPort, forwardIdentity });'),file);
const {createAnalysisPort,forwardIdentity}=mod.exports;
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
let groups,joins;
globalThis.countNativeCargo=a=>{
 const key=a.family==='choose_target'&&a.target?.target?[a.family,a.target.target].join(':'):
  a.family==='choose_card'&&a.target?.choiceId?.startsWith('income:')?'choose_card:income':
  a.family==='accept_optional_effect'?a.family+':'+a.target?.choiceId?.split(':').slice(0,2).join(':'):a.family;
 groups[key]=(groups[key]||0)+1;
};
globalThis.trackCargoJoin=(e,id,spec)=>{
 if(spec?.fundedCargoJoin)joins.push({root:e,id,...spec.fundedCargoJoin});
};
const rows=[];
for(const row of JSON.parse(z.gunzipSync(fs.readFileSync(source))).rows.filter(r=>r.input>=355)){
 const m=open(row.root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  groups={};joins=[];
  const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),row.root);
  assert.equal(Object.values(groups).reduce((a,b)=>a+b,0),q.diagnostics.nativeExecutions);
  const ranking=q.roots.filter(a=>a.target!=null).map(a=>[a.actionId,a.value,a.realization||0,a.preparationDebt]);
  assert.deepEqual(ranking,row.ranking);
  const linked=q.lines.filter(l=>l.resourcePolicy?.fundedCargoJoin).map(l=>[l.node,l.edges]);
  assert.equal(linked.length,joins.length);
  const replayProof=joins.map(join=>{
   const branch=open(join.root);
   try{
    const ways=[];
    for(const early of [true,false]){
     branch.restore(join.root);const replay=[];
     const claim=()=>replay.push(branch.act('complete_task',a=>a.actionId===join.id));
     if(early)claim();
     for(let i=0;i<4;i++){
      replay.push(branch.act('place_data'));
      replay.push(branch.act('choose_target',a=>a.target.target==='computer'));
     }
     replay.push(branch.act('choose_card',a=>a.target.choiceId===`income:${join.incomeCardId}`
       ||a.target.cardInstanceId===join.incomeCardId));
     if(!early)claim();
     const end=branch.save();branch.restore(join.root);replay.forEach(branch.apply);assert.deepEqual(branch.save(),end);
     ways.push({replay,end});
    }
    assert.equal(forwardIdentity(ways[0].end,'stable',null),forwardIdentity(ways[1].end,'stable',null));
    return {...join,ways,exactForwardIdentity:true};
   }finally{branch.dispose();}
  });
  const equivalences=linked.reduce((n,[,e])=>n+e.filter(x=>x.equivalent).length,0);
  rows.push({input:row.input,groups,joins:replayProof,linked,equivalences,native:q.diagnostics.nativeExecutions,ranking});
  console.log(JSON.stringify({input:row.input,groups,joins:joins.length,equivalences}));
 }finally{p.close();m.dispose();}
}
fs.writeFileSync(out,z.gzipSync(JSON.stringify(rows)+'\n'),{flag:'wx'});
