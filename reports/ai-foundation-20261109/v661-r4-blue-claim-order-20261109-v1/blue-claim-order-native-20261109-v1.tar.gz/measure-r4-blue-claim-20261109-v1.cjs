'use strict';
const path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {open,seat}=require('./native-late-r3');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const baseline=require('./r4-rejected-plan-work-cold-20261109-v1.json')[0];
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 assert.equal(q.diagnostics.nativeExecutions,baseline.native);
 assert.equal(q.actionId,baseline.action);assert.equal(q.value,baseline.value);
 assert.equal(JSON.stringify(q.roots.map(x=>[x.actionId,x.value,x.realization,x.preparationDebt])),JSON.stringify(baseline.ranking));
 const p=q.lines.flatMap(x=>x.blueClaimEquivalences||[]);
 console.log(JSON.stringify({label:process.argv[2],ms:q.rootAndSearchMilliseconds,native:q.diagnostics.nativeExecutions,
  accepted:p.length,byGoal:p.reduce((m,x)=>(m[x.goal]=(m[x.goal]||0)+1,m),{}),logical:q.diagnostics.transitions,
  nodes:q.analysis.nodeCount,values:q.diagnostics.valueEvaluations,
  graph:crypto.createHash('sha256').update(JSON.stringify(q.lines,(key,value)=>key==='routingNodes'?undefined:value)).digest('hex')}));
}finally{port.close();m.dispose();}
