'use strict';
const path=require('node:path'),fs=require('node:fs'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const {searchDecision}=require(path.resolve('randomizer/game/ai/decision-search'));
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {OPTIONS,BUDGET}=require(path.resolve('randomizer/game/ai/search-agent'));
const evaluate=require(path.resolve('randomizer/game/ai/state-value')).createStateValueEvaluator(seat);
const rows=[];
for(const [mode,cap] of [['transition',220],['transition',1110],['node',320],['frontier',12]]){
 const m=open(root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 const budget={...BUDGET,[{transition:'transitions',node:'nodes',frontier:'frontier'}[mode]]:cap};
 try{
  const result=searchDecision({port:p,root:p.openRoot(),evaluate,budget,...OPTIONS,modelKey:evaluate.modelKey});
  assert.equal(result.complete,false,mode+':'+cap);assert.equal(result.actionId,null);assert.equal(result.stopReason,mode+'-budget');
  assert(result.unresolved.length);assert.deepEqual(m.save(),root);
  assert(result.unresolved.every(x=>Array.isArray(x.actionIds)));
  const work=result.lines.flatMap(x=>x.blueClaimEquivalences||[]).length;
  rows.push({mode,cap,native:result.diagnostics.nativeExecutions,proofsBeforeStop:work,
   logical:result.diagnostics.transitions,unresolved:result.unresolved.length,stopReason:result.stopReason});
 }finally{p.close();m.dispose();}
}
assert(rows[1].proofsBeforeStop>0);
fs.writeFileSync(process.argv[2],JSON.stringify(rows,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(rows));
