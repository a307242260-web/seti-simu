'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const {cases}=JSON.parse(z.gunzipSync(fs.readFileSync(path.join(__dirname,'r4-data-before-claim-20261109-v1.json.gz'))));
const casesToTry=cases.filter(c=>c.dataWitness?.steps);
const byField=(x,y)=>Object.keys({...x,...y}).filter(k=>JSON.stringify(x[k])!==JSON.stringify(y[k]));
const turnOwner=s=>s.players.players.find(p=>p.id===seat);
const menuSig=a=>JSON.stringify([a.family,a.actionId,a.target,a.payload]);
function menus(a,b){
 const sa=new Set(a.map(menuSig)),sb=new Set(b.map(menuSig));
 return {added:b.filter(x=>!sa.has(menuSig(x))).map(x=>[x.family,x.target]),removed:a.filter(x=>!sb.has(menuSig(x))).map(x=>[x.family,x.target])};
}
function stateDeltas(a,b){
 const p=turnOwner(a),q=turnOwner(b);
 return {top:byField(a,b),player:byField(p,q),wallet:Object.fromEntries(byField(p.resources,q.resources).map(k=>[k,q.resources[k]-p.resources[k]])),
  drawDelta:b.cards.drawPileCardIds.length-a.cards.drawPileCardIds.length,
  marketBefore:a.cards.publicCards.map(c=>c?.id||null),marketAfter:b.cards.publicCards.map(c=>c?.id||null),
  privateRngEqual:JSON.stringify(a.meta.rngState)===JSON.stringify(b.meta.rngState)};
}
const results=[];
for(const c of casesToTry){
 const m=open(c.state),pathIds=c.dataWitness.steps;
 const claim=()=>m.act('complete_task',a=>a.target.ruleId===c.rule&&a.target.cardInstanceId===c.cardId);
 const execute=()=>pathIds.map(id=>{const a=m.menu().find(x=>x.actionId===id);assert(a,id);m.apply(a);return {id,family:a.family,target:a.target};});
 try{
  const before=m.state(),beforeMenu=m.menu();claim();const claimed=m.state(),earlyMenu=m.menu();
  const earlySteps=execute(),early=m.save(),endMenu=m.menu(),endState=m.state();
  m.restore(c.state);
  const lateSteps=execute(),dataOnly=m.state(),dataOnlyMenu=m.menu();
  assert.deepEqual(earlySteps,lateSteps);claim();const delayed=m.save(),lateMenu=m.menu();
  assert.deepEqual(JSON.parse(early.committedState),JSON.parse(delayed.committedState));
  assert.deepEqual(early.session,delayed.session);assert.deepEqual(endMenu,lateMenu);
  const goal=c.beforeEdges.find(x=>x.family==='place_data').goal;
  results.push({index:c.index,goal,steps:earlySteps,rootMoney:turnOwner(before).resources.credits,rootData:turnOwner(before).resources.availableData,
   beforeClaimDelta:stateDeltas(before,claimed),lateClaimDelta:stateDeltas(dataOnly,endState),
   earlyDataDelta:stateDeltas(claimed,endState),lateDataDelta:stateDeltas(before,dataOnly),
   earlyMenuChange:menus(beforeMenu,earlyMenu),lateMenuChange:menus(dataOnlyMenu,endMenu),
   claimAfterDataLegal:true,sameStateMenuSessionRng:true,endpointSha:crypto.createHash('sha256').update(delayed.committedState).digest('hex')});
  m.restore(c.state);
 }finally{m.dispose();}
}
assert.equal(results.length,44);
const by={};
for(const r of results){
 const k=r.goal,group=by[k]??={samples:0,earlyUnlocks:{},lateUnlocks:{},earlyRemoves:{},dataPayment:{},knownPick:{},rngChanges:0};
 const incr=(o,k)=>{o[k]=(o[k]||0)+1;};
 group.samples++;
 for(const [fam,t] of r.earlyMenuChange.added)incr(group.earlyUnlocks,fam+':'+(t.tradeId||t.kind||t.cardInstanceId||'-'));
 for(const [fam,t] of r.lateMenuChange.added)incr(group.lateUnlocks,fam+':'+(t.tradeId||t.kind||t.cardInstanceId||'-'));
 for(const [fam,t] of r.earlyMenuChange.removed)incr(group.earlyRemoves,fam+':'+(t.tradeId||t.kind||t.cardInstanceId||'-'));
 incr(group.dataPayment,JSON.stringify(r.lateDataDelta.wallet));
 if(r.steps.length===3)incr(group.knownPick,r.steps[2].target.cardInstanceId);
 if(!r.lateDataDelta.privateRngEqual)group.rngChanges++;
}
fs.writeFileSync(process.argv[2],JSON.stringify({by,results},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(by));
