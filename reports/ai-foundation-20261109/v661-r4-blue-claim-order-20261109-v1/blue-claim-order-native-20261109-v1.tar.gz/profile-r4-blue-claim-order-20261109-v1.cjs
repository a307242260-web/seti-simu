'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),Module=require('node:module'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const base=require('./r4-lazy-snapshots-official-profile-20261109-v1.json');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const old=JSON.parse(z.gunzipSync(fs.readFileSync(path.join(__dirname,'r4-data-before-claim-20261109-v1.json.gz')))).cases;
const verified=require('./r4-blue-claim-order-wallet-20261109-v1.json');
const f=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(f,module);mod.filename=f;mod.paths=Module._nodeModulePaths(path.dirname(f));
const js=fs.readFileSync(f,'utf8'),a=js.indexOf('    function proveDeferredFinalDataClaim('),b=js.indexOf('    function redundantCargoClaim',a);
assert(a>=0&&b>a);let n=0;
const probed=js.slice(a,b).replace(/return null;/g,()=>`return globalThis.rejectBlueClaim(${++n});`).replace(
 '      return {proof:"seti-final-claim-blue-order-v1",','      globalThis.acceptBlueClaim(stored.envelope,action,plan,steps);\n      return {proof:"seti-final-claim-blue-order-v1",');
mod._compile(js.slice(0,a)+probed+js.slice(b),f);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const sort=x=>Array.isArray(x)?x.map(sort):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,sort(x[k])])):x;
const key=e=>JSON.stringify(sort(JSON.parse(e.committedState)));
const oldByKey=new Map(old.map(x=>[key(x.state),x]));
const cases=[],rejected={};
globalThis.rejectBlueClaim=i=>{rejected[i]=(rejected[i]||0)+1;return null;};
globalThis.acceptBlueClaim=(e,claim,plan,steps)=>{
 const origin=oldByKey.get(key(e));assert(origin);
 const proved=verified.results.find(r=>r.index===origin.index);assert(proved&&proved.sameStateMenuSessionRng);
 assert.equal(plan.goal.id,proved.goal);
 assert.deepEqual(steps.map(a=>a.actionId),proved.steps.map(a=>a.id));
 cases.push({index:origin.index,goal:plan.goal.id,claim:claim.actionId,steps:steps.map(a=>a.actionId)});
};
const m=open(root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);assert.equal(q.diagnostics.nativeExecutions,base.native);
 const roots=q.roots.map(x=>[x.actionId,x.value,x.realization,x.preparationDebt]);assert.equal(JSON.stringify(roots),JSON.stringify(base.roots));
 assert.equal(q.actionId,base.action);assert.equal(q.value,base.value);
 assert.equal(q.lines.flatMap(x=>x.blueClaimEquivalences||[]).length,cases.length);
 const result={rejected,accepted:cases.length,cases,roots,ms:q.rootAndSearchMilliseconds,native:q.diagnostics.nativeExecutions,
  transitions:q.diagnostics.transitions,nodes:q.analysis.nodeCount,valueEvaluations:q.diagnostics.valueEvaluations};
 fs.writeFileSync(process.argv[2],JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({...result,cases:undefined,roots:undefined}));
}finally{p.close();m.dispose();}
