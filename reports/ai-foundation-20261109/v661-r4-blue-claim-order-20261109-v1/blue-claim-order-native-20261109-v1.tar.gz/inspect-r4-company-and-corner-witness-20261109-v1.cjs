'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const file=path.resolve('randomizer/game/ai/decision-search.js'),m=new Module(file,module);m.filename=file;m.paths=Module._nodeModulePaths(path.dirname(file));
const js=fs.readFileSync(file,'utf8'),anchor='    const lines = nodes.map((entry, index) => ({';
assert.equal(js.split(anchor).length,2);
m._compile(js.replace(anchor,'    globalThis.captureBest(nodes,port,resourceExecutions);\n'+anchor),file);
const {searchDecision}=m.exports,{createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {OPTIONS,BUDGET}=require(path.resolve('randomizer/game/ai/search-agent'));
const evaluate=require(path.resolve('randomizer/game/ai/state-value')).createStateValueEvaluator(seat);
let witnesses;
globalThis.captureBest=(nodes,port,resourceExecutions)=>{
 witnesses=['industry:e887dc52','card_corner:bf0cc13d'].map(id=>{
  const matching=nodes[0].edges.filter(e=>e.actionId===id).sort((a,b)=>nodes[b.target].value-nodes[a.target].value);
  const root=matching[0];assert(root);
  let edge=root;const path=[];
  for(let i=0;i<40&&edge;i++){
   const node=nodes[edge.target],fixed=resourceExecutions.get(edge);
   path.push({actionId:edge.actionId,steps:edge.steps||[edge.actionId],plan:edge.resourcePlan||null,
     tail:edge.turnTailPlanValue||edge.knownIncomePlan||null,status:node.node.status,value:node.value,
     intent:edge.goalPlan||null,target:edge.target,fixed:fixed?.goalStatus||null});
   edge=node.best;
  }
  return {id,rootValue:nodes[root.target].value,path};
 });
};
const env=open(root),port=createAnalysisPort({composition:env.c,seatId:seat,maxCacheEntries:0});
try{
 const q=searchDecision({port,root:port.openRoot(),evaluate,budget:BUDGET,...OPTIONS,modelKey:evaluate.modelKey});
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(env.save(),root);
 assert.deepEqual(witnesses.map(x=>x.rootValue),[205.5,204.5]);
 fs.writeFileSync(process.argv[2],JSON.stringify(witnesses,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(witnesses.map(x=>({id:x.id,path:x.path.map(e=>({a:e.actionId,steps:e.steps,goal:e.plan?.goal.id,tail:e.tail&&[e.tail.kind,e.tail.dataPlans?.map(p=>p.goal?.id)],status:e.status,v:e.value}))}))));
}finally{port.close();env.dispose();}
