'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const [source,out]=process.argv.slice(2),{open,seat}=require('./native-late-r3');
function hooked(relative,anchor,hook){
 const file=path.resolve(relative),mod=new Module(file,module);
 mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
 const js=fs.readFileSync(file,'utf8');assert.equal(js.split(anchor).length,2);
 mod._compile(js.replace(anchor,hook),file);return mod.exports;
}
const {createAnalysisPort}=hooked('randomizer/game/ai/analysis-port.js','      nodeCount += 1;\n      return node;',
  '      nodeCount += 1;\n      globalThis.noteCargoState(node,envelope);\n      return node;');
const search=hooked('randomizer/game/ai/decision-search.js','    const lines = nodes.map((entry, index) => ({',
  '    globalThis.noteCargoClaimGraph(nodes,port);\n    const lines = nodes.map((entry, index) => ({');
const {OPTIONS,BUDGET}=require(path.resolve('randomizer/game/ai/search-agent'));
const stateValue=require(path.resolve('randomizer/game/ai/state-value')),evaluate=stateValue.createStateValueEvaluator(seat);
let states,report;
globalThis.noteCargoState=(node,e)=>states.set(node,e);
const family=a=>a.split(':')[0];
globalThis.noteCargoClaimGraph=(nodes,port)=>{
 const cases=[];
 const best=(e)=>e.edges.filter(x=>{
  const n=nodes[x.target];
  return n.value===e.value&&n.realization===e.realization&&n.preparationDebt===e.preparationDebt
    &&n.distance+x.cost===e.distance;
 }).map(x=>family(x.actionId));
 const selected=(e)=>e.edges.filter(x=>{
  const n=nodes[x.target];
  return n.value===e.value&&n.realization===e.realization&&n.preparationDebt===e.preparationDebt
    &&n.distance+x.cost===e.distance;
 });
 function witness(start){
  const chain=[];
  for(let e=start,i=0;i<40;i++){
   const hit=selected(e)[0];if(!hit)break;
   const a=e.node.legalActions.find(x=>x.actionId===hit.actionId);
   chain.push([a?.family,a?.summary,hit.steps?.length||hit.cost,hit.turnTailPlanValue?.kind]);
   e=nodes[hit.target];
  }
  return chain;
 }
 for(const [index,e] of nodes.entries()){
  const envelope=states.get(e.node),session=envelope?.session?.session;
  if(session?.queue?.[0]?.type!=='science_domain_alien_trace'||session.journal.actions[0]?.action.family!=='scan')continue;
  for(const edge of e.edges) {
   const child=nodes[edge.target],a=e.node.legalActions.find(x=>x.actionId===edge.actionId);
   const s=envelope.session?.session?.workingState||JSON.parse(envelope.committedState),p=s.players.players.find(p=>p.id===seat);
   const end=e.edges.find(x=>family(x.actionId)==='end_turn'),tail=end?.turnTailPlanValue?.quietCargoChoice;
   const fixed=child.edges.map(x=>family(x.actionId)),physical=child.node.legalActions.map(x=>x.family);
   const simple=child.edges.length>0&&fixed.every(k=>k==='end_turn');
   cases.push({index,target:edge.target,action:a.summary,cargo:Object.keys(s.aliens.chong?.transportTasksByRocketId||{}).length,main:p.mainActionCompleted,pool:p.resources.availableData,chain:witness(child),
     usedInBest:best(e).includes('complete_task'),bestAfter:best(child),simple,tail:!!tail,
     value:child.value,endValue:end?nodes[end.target].value:null,realization:child.realization,
     state:envelope,after:states.get(child.node),edges:fixed,physical});
  }
 }
 report=cases;
};
const rows=[];
for(const row of JSON.parse(z.gunzipSync(fs.readFileSync(source))).rows.filter(r=>r.input>=355)){
 const m=open(row.root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  states=new WeakMap();report=[];
  const root=p.openRoot(),q=search.searchDecision({port:p,root,evaluate,budget:BUDGET,...OPTIONS,modelKey:evaluate.modelKey});
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),row.root);
  const ranking=q.roots.filter(a=>a.target!=null).map(a=>[a.actionId,a.value,a.realization||0,a.preparationDebt]);
  assert.deepEqual(ranking,row.ranking);
  const breakdown={};
  for(const c of report){
   const k=[c.cargo,c.action,c.chain.map(x=>x[0]).join(',')].join('|');
   breakdown[k]=(breakdown[k]||0)+1;
  }
  rows.push({input:row.input,breakdown,report});
  console.log(JSON.stringify({input:row.input,traceEdges:report.length,breakdown}));
 }finally{p.close();m.dispose();}
}
fs.writeFileSync(out,z.gzipSync(JSON.stringify(rows)+'\n'),{flag:'wx'});
