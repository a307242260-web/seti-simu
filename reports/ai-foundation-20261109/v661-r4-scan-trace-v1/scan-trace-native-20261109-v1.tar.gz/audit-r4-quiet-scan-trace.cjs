'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const [source,oldFile,out]=process.argv.slice(2),{open,seat}=require('./native-late-r3'),read=p=>JSON.parse(z.gunzipSync(fs.readFileSync(p)));
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const hook='      return {policy:"seti-known-scan-trace-score-tail-v1",',js=fs.readFileSync(file,'utf8');assert.equal(js.split(hook).length,2);
mod._compile(js.replace(hook,'      globalThis.auditR4TracePlan(stored.envelope,ranks,open,node.legalActions);\n'+hook)
 .replace('return Object.freeze({ createAnalysisPort });','return Object.freeze({ createAnalysisPort, forwardIdentity });'),file);
const {createAnalysisPort,forwardIdentity}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const key=e=>forwardIdentity(e,'decision',null),rows=[];
let audits,oldByRoot;
globalThis.auditR4TracePlan=(root,ranks,openChoices,menu)=>{
 const previous=oldByRoot.get(key(root));
 assert(previous,JSON.stringify(menu.map(a=>a.summary)));
 assert(ranks.length>1&&openChoices.length);
 const keep=menu.find(a=>a.actionId===ranks[0].actionId),fixed=previous.find(x=>x.action===keep.summary);
 assert(fixed);
 const m=open(root),cases=[];
 try{
  for(const rank of ranks){
   const a=menu.find(a=>a.actionId===rank.actionId),old=previous.find(x=>x.action===a.summary);
   assert(old&&old.edges.length===1&&old.edges[0]==='end_turn');
   assert.equal(rank.value-ranks[0].value,old.value-fixed.value);
   assert.equal(rank.purpose-ranks[0].purpose,fixed.realization-old.realization);
   m.restore(root);m.apply(a);assert(!m.save().session);
   const end=m.act('end_turn'),actions=[a,end];
   if(m.save().session)actions.push(m.act('accept_optional_effect',x=>x.target?.choiceId?.startsWith('confirm:chong_task:')));
   const checkpoint=m.save();
   m.restore(root);actions.forEach(m.apply);assert.deepEqual(m.save(),checkpoint);
   cases.push({label:a.summary,actions,checkpoint,oldValue:old.value,oldRealization:old.realization,rank});
  }
  audits.push({root,kept:keep.summary,open:openChoices.map(id=>menu.find(a=>a.actionId===id).summary),cases});
 }finally{m.dispose();}
};
const old=new Map(read(oldFile).map(x=>[x.input,x]));
for(const row of read(source).rows.filter(r=>r.input>=355)){
 const m=open(row.root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  audits=[];oldByRoot=new Map();
  for(const prior of old.get(row.input).report){
   const id=key(prior.state);if(!oldByRoot.has(id))oldByRoot.set(id,[]);
   oldByRoot.get(id).push(prior);
  }
  const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length&&audits.length);assert.deepEqual(m.save(),row.root);
  assert.deepEqual(q.roots.filter(a=>a.target!=null).map(a=>[a.actionId,a.value,a.realization||0,a.preparationDebt]),row.ranking);
  const eliminated=audits.reduce((n,x)=>n+x.cases.length-1,0);
  rows.push({input:row.input,eliminated,audits});
  console.log(JSON.stringify({input:row.input,eliminated,menus:audits.map(x=>[x.kept,x.open,x.cases.length])}));
 }finally{p.close();m.dispose();}
}
fs.writeFileSync(out,z.gzipSync(JSON.stringify(rows)+'\n'),{flag:'wx'});
