'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const [source,out]=process.argv.slice(2),{open,seat}=require('./native-late-r3');
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const hook='    function executeCurrent(current) {',js=fs.readFileSync(file,'utf8');assert.equal(js.split(hook).length,2);
mod._compile(js.replace(hook,hook+'\n      globalThis.measureScanTrace(current,loadedEnvelope);'),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const rows=[];let contexts;
globalThis.measureScanTrace=(a,e)=>{
 const s=e?.session?.session;
 if(s?.queue[0].type!=='science_domain_alien_trace'||s.journal.actions[0]?.action.family!=='scan')return;
 const p=s.workingState.players.players.find(x=>x.id===seat),t=s.workingState.turn;
 const key=require('node:crypto').createHash('sha256').update(JSON.stringify(e)).digest('hex');
 if(!contexts.has(key))contexts.set(key,{wallet:p.resources,hand:p.hand.map(c=>c.cardId),sources:s.journal.actions.map(x=>x.action.summary),
  readyTasks:p.reservedCards.filter(c=>c.chongTask||c.amibaTask).map(c=>c.cardId),envelope:e,choices:[]});
 contexts.get(key).choices.push(a);
};
for(const row of JSON.parse(z.gunzipSync(fs.readFileSync(source))).rows.filter(r=>r.input>=355)){
 const m=open(row.root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  contexts=new Map();
  const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),row.root);
  const entries=[...contexts.values()];
  assert.equal(entries.reduce((n,x)=>n+x.choices.length,0),42);
  rows.push({input:row.input,entries});
  console.log(JSON.stringify({input:row.input,entries:entries.map(x=>[x.wallet.credits,x.wallet.energy,x.wallet.availableData,x.wallet.score,x.readyTasks,x.sources,x.choices.map(a=>a.summary)])}));
 }finally{p.close();m.dispose();}
}
fs.writeFileSync(out,z.gzipSync(JSON.stringify(rows)+'\n'),{flag:'wx'});
