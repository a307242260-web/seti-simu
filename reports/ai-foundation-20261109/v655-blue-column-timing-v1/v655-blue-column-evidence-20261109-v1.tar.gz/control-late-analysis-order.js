'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const {open,read,z,seat}=require('./native-late-r3');
const [dir,out]=process.argv.slice(2),fixture=n=>read(dir+'/v654-formal-r'+n+'-fixture-20261109-v1.json').compositionEnvelope;
const root=fixture(235),formal=fixture(242),m=open(root);
function trace(actions,pos){
 actions.push(m.act('analyze'),m.act('choose_target',a=>a.target.choiceId===('trace:1:blue:amiba:'+pos)));
 if(pos===3){
  assert.equal(m.facts().alienDisplay,2);
  actions.push(m.act('choose_card',a=>a.target.source==='display'&&a.target.cardIndex===2));
 }
}
function amiba(actions,pick='dlc_17.png',red=2){
 actions.push(m.play('amiba_5.webp'),m.pick(pick),m.act('choose_target',a=>a.target.slotId==='red_'+red));
 actions.push(...m.swap('b_16.webp',pick==='dlc_17.png'?'dlc_15.png':'dlc_17.png'));
}
function blueScan(actions,sector,first){
 actions.push(m.play('b_16.webp'),m.act('choose_target',a=>a.target.skip),m.act('choose_target',a=>a.target.nebulaId===sector));
 actions.push(...m.swap('amiba_5.webp','dlc_15.png'));
}
function suffix(){
 const start=m.save(),accepted=[],mainRoots=[],roots=[];let checkpoint,settled=null,opening=null,stop;
 for(let j=0;j<95;j++){
  const {round}=m.facts(),legal=m.menu();
  if(legal[0].actorId!==seat){
   const a=[];m.advanceOpponents(a);accepted.push(...a.map(action=>({action,passive:true})));
   continue;
  }
  if(round===4){
   assert(!m.c.inspect().session);opening=m.facts();stop='first-white-r4-main';break;
  }
  assert.equal(round,3);
  const e=m.save(),q=m.automatic(checkpoint),a=q.a;
  if(!q.complete||q.n>256||q.ms>600){stop={kind:'gate',n:q.n,ms:q.ms,action:a?.summary};break;}
  if(!j||a.phase==='main'||a.family==='pass')roots.push({action:a,n:q.n,ms:q.ms,value:q.value,roots:q.roots});
  if(a.family==='pass')settled={facts:m.facts(),envelope:e};
  checkpoint=q.checkpoint;
  accepted.push({action:m.apply(a),n:q.n,ms:q.ms,value:q.value});
 }
 assert(stop);const end=m.save();m.restore(start);for(const r of accepted)m.apply(r.action);
 assert.deepEqual(m.save(),end);m.restore(start);
 return {start,accepted,roots,settled,opening,stop,end};
}
const cases=[
 ['formal',235,a=>{amiba(a);a.push(m.act('end_turn'));assert.deepEqual(m.save(),formal);trace(a,3)}],
 ['formal-alt-pick',235,a=>{amiba(a,'dlc_15.png');a.push(m.act('end_turn'));trace(a,3)}],
 ...[2,3].flatMap(blue=>[1,2].map(red=>['analyze-blue'+blue+'-red'+red,235,a=>{trace(a,blue);a.push(m.act('end_turn'));amiba(a,'dlc_17.png',red)}])),
 ['amiba-first-blue2',242,a=>trace(a,2)],
 ...['sector-2-a','sector-1-a'].map(sector=>['scan-'+sector,235,a=>{blueScan(a,sector,true);a.push(m.act('end_turn'));trace(a,3)}]),
 ...['sector-2-a','sector-1-a'].map(sector=>['analysis-then-scan-'+sector,235,a=>{trace(a,3);a.push(m.act('end_turn'));blueScan(a,sector,false)}])
];
try{
 const rows=[];
 for(const [label,n,apply] of cases){
  const origin=fixture(n);m.restore(origin);const prefix=[];apply(prefix);
  const atTwoMains=m.facts(),result=suffix();
  m.restore(origin);prefix.forEach(m.apply);assert.deepEqual(m.save(),result.start);m.restore(origin);
  const row={label,base:n,prefix,atTwoMains,...result,replayExact:true};
  rows.push(row);
  const short=f=>f&&[f.wallet.score,f.final,f.wallet.availableData,f.hand.map(x=>x[1]),f.computer,f.blue,f.income.energy,f.wallet.credits,f.wallet.energy];
  console.log(JSON.stringify([label,short(atTwoMains),short(row.settled?.facts),short(row.opening),result.stop,
    Math.max(0,...result.accepted.map(x=>x.n||0)),Math.max(0,...result.accepted.map(x=>x.ms||0))]));
 }
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({scope:'Matched known second analyze and other named main choices on original V654; only public slot, trace and movement choices fixed, autonomous to first R4 white main after the fixed pair; never a full simulation.',rows})),{flag:'wx'});
}finally{m.dispose()}
