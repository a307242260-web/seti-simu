'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const {open,read,z,seat}=require('./native-late-r3');
const [dir,out]=process.argv.slice(2),fixture=n=>read(dir+'/v654-formal-r'+n+'-fixture-20261109-v1.json').compositionEnvelope;
const root=fixture(219),m=open(root);
function take(a,tile,blueSlot=null,publicCard=null){
 a.push(m.act('research_tech'),m.act('choose_target',x=>x.target.tileId===tile&&x.target.blueSlot===blueSlot));
 if(publicCard)a.push(m.pick(publicCard));
}
function suffix(){
 const start=m.save(),accepted=[],mainRoots=[],roots=[];let checkpoint,settled=null,opening=null,stop;
 for(let j=0;j<95;j++){
  const {round}=m.facts(),legal=m.menu();
  if(legal[0].actorId!==seat){
   const a=[];m.advanceOpponents(a);accepted.push(...a.map(action=>({action,passive:true})));
   continue;
  }
  if(round===4){
   assert(!m.c.inspect().session);opening=m.facts();stop='first-white-r4-main';break;
  }
  assert.equal(round,3);
  const e=m.save(),q=m.automatic(checkpoint),a=q.a;
  if(!q.complete||q.n>256||q.ms>600){stop={kind:'gate',n:q.n,ms:q.ms,action:a?.summary};break;}
  if(!j||a.phase==='main'||a.family==='pass')roots.push({action:a,n:q.n,ms:q.ms,value:q.value,roots:q.roots});
  if(a.family==='pass')settled={facts:m.facts(),envelope:e};
  checkpoint=q.checkpoint;
  accepted.push({action:m.apply(a),n:q.n,ms:q.ms,value:q.value});
 }
 assert(stop);const end=m.save();m.restore(start);for(const r of accepted)m.apply(r.action);
 assert.deepEqual(m.save(),end);m.restore(start);
 return {start,accepted,roots,settled,opening,stop,end};
}
const q=JSON.parse(z.gunzipSync(fs.readFileSync(dir+'/v654-formal-r219-search-20261109-v1.json.gz')));
const startTrade=q.lines[0].edges.find(e=>e.resourcePlan?.id==='play:alien-amiba-5-12').steps;
function chosen(a,seq){
 for(const id of seq){const legal=m.menu().find(x=>x.actionId===id);assert(legal,id);a.push(m.apply(legal));}
}
function reverse(a,pick){
 take(a,'blue1',3);
 a.push(m.act('place_data'),m.act('choose_target',x=>x.target.target==='computer'),
  m.act('place_data'),m.act('choose_target',x=>x.target.blueSlot===3),m.act('end_turn'));
 a.push(m.play('amiba_5.webp'),m.pick(pick),m.act('choose_target',x=>x.target.slotId==='red_2'),m.act('end_turn'));
 a.push(m.corner('amiba_9.webp'),m.corner('b_16.webp'));
 take(a,'orange1',null,'dlc_15.png');
 if(pick==='dlc_20.png')a.push(...m.swap('dlc_20.png','dlc_17.png'));
 a.push(m.act('place_data'),m.act('choose_target',x=>x.target.target==='computer'),m.act('end_turn'));
}
const cases=[
 ['paid-amiba-first',219,a=>chosen(a,startTrade)],
 ['blue1-amiba-orange1-dlc17',219,a=>reverse(a,'dlc_17.png')],
 ['blue1-amiba-orange1-dlc20',219,a=>reverse(a,'dlc_20.png')]
];
try{
 const rows=[],failures=[];
 for(const [label,n,apply] of cases){
  const origin=fixture(n);m.restore(origin);const prefix=[];
  try{apply(prefix)}catch(err){failures.push({label,reason:String(err),inputs:prefix.length,menu:m.menu()});
   console.log(JSON.stringify([label,'native-unavailable',String(err).slice(0,380)]));continue;}
  const atTwoMains=m.facts(),result=suffix();
  m.restore(origin);prefix.forEach(m.apply);assert.deepEqual(m.save(),result.start);m.restore(origin);
  const row={label,base:n,prefix,atTwoMains,...result,replayExact:true};
  rows.push(row);
  const short=f=>f&&[f.wallet.score,f.final,f.wallet.availableData,f.hand.map(x=>x[1]),f.computer,f.blue,f.income.energy,f.wallet.credits,f.wallet.energy];
  console.log(JSON.stringify([label,short(atTwoMains),short(row.settled?.facts),short(row.opening),result.stop,
    Math.max(0,...result.accepted.map(x=>x.n||0)),Math.max(0,...result.accepted.map(x=>x.ms||0))]));
 }
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({scope:'Compare actual root 219 trade and two named blue-cash then orange-launch sequences. Public picks observed at their action boundary, no future card required.',rows,failures})),{flag:'wx'});
}finally{m.dispose()}
