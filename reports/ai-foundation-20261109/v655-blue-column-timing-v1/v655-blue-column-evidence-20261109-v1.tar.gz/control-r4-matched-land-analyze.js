'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path');
const {open,z,seat}=require('./native-late-r3');
const probe=require(path.resolve('randomizer/game/ai/probe-capital'));
const [source,out,...args]=process.argv.slice(2),extra=args.includes('--fund-with-dlc20'),labels=args.filter(x=>x!=='--fund-with-dlc20'),selected=JSON.parse(z.gunzipSync(fs.readFileSync(source))).rows.filter(r=>labels.includes(r.label));
assert.equal(selected.length,labels.length);
function follow(r){
 const m=open(r.end);
 try{
  const accepted=[],checkpoints={},cut=label=>checkpoints[label]={facts:m.facts(),envelope:m.save()};
  const act=(f,test)=>{const a=m.act(f,test);accepted.push(a);return a;};
  function finish(){
   act('end_turn');
   while(m.save().session)act('accept_optional_effect',a=>a.target.choiceId.startsWith('confirm:task:'));
   m.advanceOpponents(accepted);
  }
  function fill(){
   for(let i=0;i<6;i++){
    const f=m.facts();if(f.computer.length===6||!f.wallet.availableData)break;
    act('place_data');act('choose_target',a=>a.target.target==='computer');
    if(m.save().session){
     const id=m.player().hand.find(h=>h.cardId==='dlc_25.png')?.id;assert(id);
     act('choose_card',a=>a.target.cardInstanceId===id);
    }
   }
  }
  cut('R4-before-first-main');
  if(extra){
   accepted.push(...m.swap('b_16.webp','dlc_17.png'),m.play('dlc_20.png'));
   const payer=m.player().hand.find(h=>h.cardId==='dlc_17.png');assert(payer);
   act('choose_card',a=>a.target.cardInstanceId===payer.id);
   fill();assert.equal(m.facts().computer.length,4);assert.equal(m.facts().income.energy,4);
   finish();cut('R4-after-paid-data-preparation');
  }
  const p=m.player(),goal=probe.requirements(probe.factsFromState(m.state(),p))
   .find(g=>g.planetId==='saturn'&&g.endpointFamily==='land'&&g.requirementId.endsWith(':planet'));
  assert(goal);const rocketId=Number(goal.requirementId.split(':')[0]);assert(Number.isSafeInteger(rocketId));
  const need=(goal.endpointFacts.cost.energy||0)+goal.route.cost,credits=goal.endpointFacts.cost.credits||0;
  assert(p.resources.credits>=credits+2*Math.max(0,need-p.resources.energy));
  while(m.player().resources.energy<need)act('quick_trade',a=>a.target.tradeId==='credits-for-energy');
  for(const q of goal.route.path){
   act('move',a=>a.target.rocketId===rocketId&&a.target.deltaX===q.deltaX&&a.target.deltaY===q.deltaY);
   if(m.save().session)act('choose_payment',a=>a.target.kind==='move-payment'&&!a.target.cardIds.length);
  }
  act('land',a=>!a.target.planetId||a.target.planetId==='saturn');
  if(m.menu().some(a=>a.target.planetId==='saturn'&&a.target.actionType==='land'))
   act('choose_target',a=>a.target.planetId==='saturn'&&a.target.landTarget.type==='planet');
  act('choose_target',a=>a.target.traceType==='yellow'&&a.target.stateExtra===true&&a.target.alienSlotId===1);
  if(m.save().session)act('accept_optional_effect',a=>a.target.ruleId==='amiba0-yellow-data'&&a.target.choiceId.startsWith('confirm:'));
  cut('R4-after-land');
  fill();
  // An alternative may retain a data card yet need to spend it before
  // reaching the same analysis. Use only the retained card, never a new draw.
  if(m.facts().computer.length<6&&r.settled.facts.hand.some(x=>x[1]==='dlc_15.png')){
   accepted.push(m.corner('dlc_15.png'));fill();
  }
  finish();cut('R4-before-analysis');
  if(m.facts().computer.length<6)return close('insufficient-computer-for-matched-analysis');
  act('analyze');act('choose_target',a=>a.target.traceType==='blue'&&a.target.stateExtra===true&&a.target.alienSlotId===1);
  finish();cut('R4-before-third-main');
  return close('matched-two-mains');
  function close(stop){
   const end=m.save();m.restore(r.end);accepted.forEach(m.apply);assert.deepEqual(m.save(),end);m.restore(r.end);
   return {label:r.label,stop,checkpoints,accepted,end,replayExact:true};
  }
 }finally{m.dispose();}
}
const rows=[];
for(const r of selected)try{rows.push(follow(r));}catch(e){rows.push({label:r.label,error:String(e)});}
fs.writeFileSync(out,z.gzipSync(JSON.stringify({scope:'Fixed same Saturn landing then second-turn analyze from distinct verified actual and counterfactual R3 endpoints. Only same public marker and income already held, no autonomous R4 opening.',extra,rows})),{flag:'wx'});
for(const row of rows){
 const short=f=>[f.wallet.score,f.final,f.wallet.credits,f.wallet.energy,f.wallet.availableData,f.wallet.publicity,f.hand.map(x=>x[1]),f.computer,f.blue];
 console.log(JSON.stringify([row.label,row.stop,row.error,Object.fromEntries(Object.entries(row.checkpoints||{}).map(([k,x])=>[k,short(x.facts)]))]));
}
