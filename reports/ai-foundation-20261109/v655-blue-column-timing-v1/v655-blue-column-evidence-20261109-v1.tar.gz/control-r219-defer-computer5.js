'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const {open,read,z,seat}=require('./native-late-r3');
const [dir,out]=process.argv.slice(2),fixture=n=>read(dir+'/v654-formal-r'+n+'-fixture-20261109-v1.json').compositionEnvelope;
const root=fixture(219),m=open(root);
function take(a,tile,blueSlot=null,publicCard=null){
 a.push(m.act('research_tech'),m.act('choose_target',x=>x.target.tileId===tile&&x.target.blueSlot===blueSlot));
 if(publicCard)a.push(m.pick(publicCard));
}
function suffix(){
 const start=m.save(),accepted=[],mainRoots=[],roots=[];let checkpoint,settled=null,opening=null,stop;
 for(let j=0;j<95;j++){
  const {round}=m.facts(),legal=m.menu();
  if(legal[0].actorId!==seat){
   const a=[];m.advanceOpponents(a);accepted.push(...a.map(action=>({action,passive:true})));
   continue;
  }
  if(round===4){
   assert(!m.c.inspect().session);opening=m.facts();stop='first-white-r4-main';break;
  }
  assert.equal(round,3);
  const e=m.save(),q=m.automatic(checkpoint),a=q.a;
  if(!q.complete||q.n>256||q.ms>600){stop={kind:'gate',n:q.n,ms:q.ms,action:a?.summary};break;}
  if(!j||a.phase==='main'||a.family==='pass')roots.push({action:a,n:q.n,ms:q.ms,value:q.value,roots:q.roots});
  if(a.family==='pass')settled={facts:m.facts(),envelope:e};
  checkpoint=q.checkpoint;
  accepted.push({action:m.apply(a),n:q.n,ms:q.ms,value:q.value});
 }
 assert(stop);const end=m.save();m.restore(start);for(const r of accepted)m.apply(r.action);
 assert.deepEqual(m.save(),end);m.restore(start);
 return {start,accepted,roots,settled,opening,stop,end};
}
function defer(a,cut){
 take(a,'orange1',null,'dlc_20.png');
 assert.equal(m.facts().wallet.availableData,3);
 assert.deepEqual(m.facts().computer,[1,2,3,4]);
 a.push(m.act('end_turn'));
 if(cut==='start-blue-turn')return;
 a.push(m.act('move',x=>x.target.rocketId===6&&x.target.deltaX===0&&x.target.deltaY===1));
 const payer=m.player().hand.find(x=>x.cardId==='dlc_20.png').id;
 a.push(m.act('choose_payment',x=>x.target.cardIds?.length===1&&x.target.cardIds[0]===payer));
 a.push(m.corner('amiba_9.webp'));
 if(cut==='before-blue')return;
 take(a,'blue1',3);
 if(cut==='after-blue')return;
 for(const slot of [5,6]){
  a.push(m.act('place_data'),m.act('choose_target',x=>x.target.target==='computer'));
  assert.equal(m.facts().computer.at(-1),slot);
 }
 a.push(m.act('place_data'),m.act('choose_target',x=>x.target.blueSlot===3));
 if(cut==='after-cash')return;
 a.push(m.act('end_turn'));
}
const cases=[
 ['formal',219,a=>{}],
 ...['start-blue-turn','before-blue','after-blue','after-cash','after-end'].map(cut=>['defer-'+cut,219,a=>defer(a,cut)])
];
try{
 const rows=[],failures=[];
 for(const [label,n,apply] of cases){
  const origin=fixture(n);m.restore(origin);const prefix=[];
  try{apply(prefix)}catch(err){failures.push({label,reason:String(err),inputs:prefix.length,menu:m.menu()});
   console.log(JSON.stringify([label,'native-unavailable',String(err).slice(0,380)]));continue;}
  const atTwoMains=m.facts(),result=suffix();
  m.restore(origin);prefix.forEach(m.apply);assert.deepEqual(m.save(),result.start);m.restore(origin);
  const row={label,base:n,prefix,atTwoMains,...result,replayExact:true};
  rows.push(row);
  const short=f=>f&&[f.wallet.score,f.final,f.wallet.availableData,f.hand.map(x=>x[1]),f.computer,f.blue,f.income.energy,f.wallet.credits,f.wallet.energy];
  console.log(JSON.stringify([label,short(atTwoMains),short(row.settled?.facts),short(row.opening),result.stop,
    Math.max(0,...result.accepted.map(x=>x.n||0)),Math.max(0,...result.accepted.map(x=>x.ms||0))]));
 }
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({scope:'Keep the actual launch and paid movement; defer computer5/6 until blue1 is in the column. All fixed actions use visible supplies, then autonomous at five exact cuts.',rows,failures})),{flag:'wx'});
}finally{m.dispose()}
