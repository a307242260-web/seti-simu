'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const {open,z,seat}=require('./native-late-r3');
const [source,out,...labels]=process.argv.slice(2),cases=JSON.parse(z.gunzipSync(fs.readFileSync(source))).rows.filter(x=>labels.includes(x.label));
assert.equal(cases.length,labels.length);
function run(row){
 const m=open(row.end);
 try{
  const accepted=[],checkpoints=[],mains=[];let checkpoint,settled=null,stop;
  const start=m.facts();
  for(let j=0;j<175;j++){
   const f=m.facts(),actions=m.menu();
   if(checkpoints.length===3){stop='three-own-turns';break;}
   if(f.round!==4){stop='advanced-past-r4';break;}
   if(actions[0].actorId!==seat){
    const a=[];m.advanceOpponents(a);accepted.push(...a.map(action=>({action,passive:true})));continue;
   }
   const q=m.automatic(checkpoint);
   if(!q.complete||q.n>256||q.ms>600){stop={kind:'gate',n:q.n,ms:q.ms,action:q.a?.summary};break;}
   const {a}=q;assert(a);
   if(a.family==='pass'){stop='chosen-pass-before-third-main';break;}
   if(a.phase==='main')mains.push({input:j+1,action:a,n:q.n,value:q.value,wallet:f.wallet});
   if(a.family==='end_turn')checkpoints.push({settled:f,main:mains[mains.length-1],before:m.save()});
   checkpoint=q.checkpoint;accepted.push({action:m.apply(a),n:q.n,ms:q.ms,value:q.value});
  }
  assert(stop);const end=m.save();m.restore(row.end);accepted.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),end);m.restore(row.end);
  return {label:row.label,stop,start,accepted,mains,checkpoints,end,replayExact:true};
 }finally{m.dispose();}
}
const rows=cases.map(run);
fs.writeFileSync(out,z.gzipSync(JSON.stringify({scope:'Autonomous first three white R4 turns after actual and controlled R3 endpoints; no intervention after entry and no action submitted above gate.',rows})),{flag:'wx'});
for(const r of rows)console.log(JSON.stringify([r.label,r.stop,r.mains.map(x=>x.action.summary),r.checkpoints.map(x=>{const f=x.settled;return [f.wallet.score,f.final,f.wallet.credits,f.wallet.energy,f.wallet.availableData,f.wallet.publicity,f.hand.map(h=>h[1]),Object.keys(f.tech.ownedTiles),f.computer,f.blue]}),Math.max(0,...r.accepted.map(x=>x.n||0)),Math.max(0,...r.accepted.map(x=>x.ms||0))]));
