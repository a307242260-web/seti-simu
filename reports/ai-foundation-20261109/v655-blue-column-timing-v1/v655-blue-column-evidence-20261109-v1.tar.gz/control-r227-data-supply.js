'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const {open,read,z,seat}=require('./native-late-r3');
const [dir,out]=process.argv.slice(2),fixture=n=>read(dir+'/v654-formal-r'+n+'-fixture-20261109-v1.json').compositionEnvelope;
const root=fixture(227),m=open(root);
function fixed(a,steps){
 for(const id of steps){const legal=m.menu().find(x=>x.actionId===id);assert(legal,id);a.push(m.apply(legal));}
}
function repeatData(a,publicCard,tail){
 a.push(...m.swap('b_16.webp',publicCard));
 a.push(m.act('quick_trade',x=>x.target.tradeId==='cards-for-credit'));
 for(const id of ['alien-amiba-9-5','alien-amiba-5-12'])a.push(m.act('choose_payment',x=>x.target.cardInstanceId===id));
 a.push(m.act('choose_payment',x=>x.target.confirm),m.play('dlc_20.png'));
 const id=m.player().hand.find(x=>x.cardId===publicCard).id;
 a.push(m.act('choose_card',x=>x.target.cardInstanceId===id));
 if(tail==='auto')return;
 assert.equal(m.facts().wallet.availableData,4);
 a.push(m.act('end_turn'));
 a.push(m.act('analyze'),m.act('choose_target',x=>x.target.choiceId==='trace:1:blue:amiba:3'));
 assert.equal(m.facts().alienDisplay,2);
 a.push(m.act('choose_card',x=>x.target.source==='display'&&x.target.cardIndex===2));
 if(tail==='data')return;
 assert.equal(m.facts().wallet.availableData,5);
 for(let i=1;i<=4;i++){
  a.push(m.act('place_data'),m.act('choose_target',x=>x.target.target==='computer'));
  assert.deepEqual(m.facts().computer,Array.from({length:i},(_,j)=>j+1));
 }
 const income=m.player().hand.find(h=>h.cardId==='dlc_25.png');assert(income);
 a.push(m.act('choose_card',x=>x.target.cardInstanceId===income.id));
 assert.equal(m.facts().income.energy,4);
 if(tail==='computer4')return;
 if(tail==='take-dlc15'){
  a.push(m.act('place_data'),m.act('choose_target',x=>x.target.blueSlot===2),m.pick('dlc_15.png'));
 }
 a.push(m.act('end_turn'));
 a.push(m.act('move',x=>x.target.rocketId===6&&x.target.deltaY===1&&x.target.deltaX===0));
 if(m.menu().some(x=>x.family==='choose_payment')){
  a.push(m.act('choose_payment',x=>x.target.cardIds?.length===0&&x.payload.energyCost===1));
 }
 a.push(m.act('research_tech'),m.act('choose_target',x=>x.target.tileId==='blue1'&&x.target.blueSlot===3));
 if(tail==='computer4-to-blue1')return;
 if(tail==='spend-cash-to-draw'){
  a.push(m.act('place_data'),m.act('choose_target',x=>x.target.blueSlot===3),m.act('end_turn'),m.play('amiba_2.webp'));
 }

}
const search=JSON.parse(z.gunzipSync(fs.readFileSync(dir+'/v654-formal-r227-search-20261109-v1.json.gz')));
const tradeToAmiba=search.lines[0].edges.find(e=>e.resourcePlan?.id==='play:alien-amiba-5-12').steps;
function suffix(){
 const start=m.save(),accepted=[],mainRoots=[],roots=[];let checkpoint,settled=null,opening=null,stop;
 for(let j=0;j<95;j++){
  const {round}=m.facts(),legal=m.menu();
  if(legal[0].actorId!==seat){
   const a=[];m.advanceOpponents(a);accepted.push(...a.map(action=>({action,passive:true})));
   continue;
  }
  if(round===4){
   assert(!m.c.inspect().session);opening=m.facts();stop='first-white-r4-main';break;
  }
  assert.equal(round,3);
  const e=m.save(),q=m.automatic(checkpoint),a=q.a;
  if(!q.complete||q.n>256||q.ms>600){stop={kind:'gate',n:q.n,ms:q.ms,action:a?.summary};break;}
  if(!j||a.phase==='main'||a.family==='pass')roots.push({action:a,n:q.n,ms:q.ms,value:q.value,roots:q.roots});
  if(a.family==='pass')settled={facts:m.facts(),envelope:e};
  checkpoint=q.checkpoint;
  accepted.push({action:m.apply(a),n:q.n,ms:q.ms,value:q.value});
 }
 assert(stop);const end=m.save();m.restore(start);for(const r of accepted)m.apply(r.action);
 assert.deepEqual(m.save(),end);m.restore(start);
 return {start,accepted,roots,settled,opening,stop,end};
}
const cases=[
 ['formal-r227',227,a=>{}],
 ['trade-to-amiba',227,a=>fixed(a,tradeToAmiba)],
 ...['auto','data','computer4','computer4-to-blue1','take-dlc15','spend-cash-to-draw'].map(tail=>
  ['triple-dlc17-'+tail,227,a=>repeatData(a,'dlc_17.png',tail)]),
 ['triple-dlc15-computer4-to-blue1',227,a=>repeatData(a,'dlc_15.png','computer4-to-blue1')]

];
try{
 const rows=[],failures=[];
 for(const [label,n,apply] of cases){
  const origin=fixture(n);m.restore(origin);const prefix=[];
  try{apply(prefix)}catch(err){failures.push({label,reason:String(err),inputs:prefix.length,menu:m.menu()});
   console.log(JSON.stringify([label,'native-unavailable',String(err).slice(0,380)]));continue;}
  const atTwoMains=m.facts(),result=suffix();
  m.restore(origin);prefix.forEach(m.apply);assert.deepEqual(m.save(),result.start);m.restore(origin);
  const row={label,base:n,prefix,atTwoMains,...result,replayExact:true};
  rows.push(row);
  const short=f=>f&&[f.wallet.score,f.final,f.wallet.availableData,f.hand.map(x=>x[1]),f.computer,f.blue,f.income.energy,f.wallet.credits,f.wallet.energy];
  console.log(JSON.stringify([label,short(atTwoMains),short(row.settled?.facts),short(row.opening),result.stop,
    Math.max(0,...result.accepted.map(x=>x.n||0)),Math.max(0,...result.accepted.map(x=>x.ms||0))]));
 }
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({scope:'Named public data production alternatives at actual input 227; exact known market and payment, then autonomous through the same R3 settled checkpoint. No future draw identity used to fix a prefix.',rows,failures})),{flag:'wx'});
}finally{m.dispose()}
