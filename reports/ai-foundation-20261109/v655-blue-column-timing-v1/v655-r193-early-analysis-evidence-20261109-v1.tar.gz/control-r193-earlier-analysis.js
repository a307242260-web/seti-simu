'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const {open,read,z,seat}=require('./native-late-r3');
const [dir,out,formal]=process.argv.slice(2),file=dir+'/v655-standard-r3-analysis-scan-windows-20261109-v1.json.gz';
const snapshot=JSON.parse(z.gunzipSync(fs.readFileSync(file))).snapshots,fixture=n=>snapshot[n].envelope;
const record=read(formal+'/reports/research/6ff3b826.6b5ba279.quick-400.json'),saved=read(formal+'/'+record.savePath);
const root=fixture(193),m=open(root);
function earlier(a,stage){
 for(let i=193;i<=203;i++)a.push(m.apply(saved.replaySteps[i-1].action));
 for(const slot of [5,6]){
  if(!m.facts().wallet.availableData)a.push(m.corner('amiba_7.webp'));
  a.push(m.act('place_data'),m.act('choose_target',x=>x.target.target==='computer'));
  assert.equal(m.facts().computer.at(-1),slot);
 }
 a.push(m.act('end_turn'));
 assert(m.menu().some(x=>x.family==='analyze'));
 if(stage==='ready')return;
 a.push(m.act('analyze'));
 a.push(m.act('choose_target',x=>x.target.choiceId==='trace:1:blue:amiba:'+stage));
 if(stage===3)a.push(m.act('choose_card',x=>x.target.source==='display'&&x.target.cardIndex===5));
}
function suffix(){
 const start=m.save(),accepted=[],mainRoots=[],roots=[];let checkpoint,settled=null,opening=null,stop;
 for(let j=0;j<95;j++){
  const {round}=m.facts(),legal=m.menu();
  if(legal[0].actorId!==seat){
   const a=[];m.advanceOpponents(a);accepted.push(...a.map(action=>({action,passive:true})));
   continue;
  }
  if(round===4){
   assert(!m.c.inspect().session);opening=m.facts();stop='first-white-r4-main';break;
  }
  assert.equal(round,3);
  const e=m.save(),q=m.automatic(checkpoint),a=q.a;
  if(!q.complete||q.n>256||q.ms>600){stop={kind:'gate',n:q.n,ms:q.ms,action:a?.summary};break;}
  if(!j||a.phase==='main'||a.family==='pass')roots.push({action:a,n:q.n,ms:q.ms,value:q.value,roots:q.roots});
  if(a.family==='pass')settled={facts:m.facts(),envelope:e};
  checkpoint=q.checkpoint;
  accepted.push({action:m.apply(a),n:q.n,ms:q.ms,value:q.value});
 }
 assert(stop);const end=m.save();m.restore(start);for(const r of accepted)m.apply(r.action);
 assert.deepEqual(m.save(),end);m.restore(start);
 return {start,accepted,roots,settled,opening,stop,end};
}
const cases=[
 ['formal-from-193',193,a=>{}],
 ['earlier-analysis-ready',193,a=>earlier(a,'ready')],
 ['earlier-analysis-blue2',193,a=>earlier(a,2)],
 ['earlier-analysis-blue3',193,a=>earlier(a,3)]
];
try{
 const rows=[],failures=[];
 for(const [label,n,apply] of cases){
  const origin=fixture(n);m.restore(origin);const prefix=[];
  try{apply(prefix)}catch(err){failures.push({label,reason:String(err),inputs:prefix.length,menu:m.menu()});
   console.log(JSON.stringify([label,'native-unavailable',String(err).slice(0,380)]));continue;}
  const atTwoMains=m.facts(),result=suffix();
  m.restore(origin);prefix.forEach(m.apply);assert.deepEqual(m.save(),result.start);m.restore(origin);
  const row={label,base:n,prefix,atTwoMains,...result,replayExact:true};
  rows.push(row);
  const short=f=>f&&[f.wallet.score,f.final,f.wallet.availableData,f.hand.map(x=>x[1]),f.computer,f.blue,f.income.energy,f.wallet.credits,f.wallet.energy];
  console.log(JSON.stringify([label,short(atTwoMains),short(row.settled?.facts),short(row.opening),result.stop,
    Math.max(0,...result.accepted.map(x=>x.n||0)),Math.max(0,...result.accepted.map(x=>x.ms||0))]));
 }
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({scope:'From actual input 193 allocate the same six available tokens to all six computer slots rather than two blue bonuses; Native earlier free analysis before the actual late scan. No action above gate.',rows,failures})),{flag:'wx'});
}finally{m.dispose()}
