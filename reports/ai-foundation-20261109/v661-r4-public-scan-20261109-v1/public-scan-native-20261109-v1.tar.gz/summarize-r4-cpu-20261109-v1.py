import collections,json,sys
from pathlib import Path
src,dst=map(Path,sys.argv[1:3]); p=json.loads(src.read_text())
nodes={x['id']:x for x in p['nodes']}
parents={child:x['id'] for x in p['nodes'] for child in x.get('children',())}
def label(i):
    f=nodes[i]['callFrame']; u=f['url']
    if '/randomizer/' in u:
        u='randomizer/'+u.split('/randomizer/',1)[1]
    elif u.startswith('file:'):
        u=Path(u).name
    return f"{f['functionName'] or '(anonymous)'}@{u}:{f['lineNumber']+1}"
self_time=collections.Counter(); inclusive=collections.Counter()
for sample,delta in zip(p['samples'],p['timeDeltas']):
    self_time[label(sample)]+=delta
    seen=set()
    while sample:
        name=label(sample)
        if name not in seen:
            inclusive[name]+=delta;seen.add(name)
        sample=parents.get(sample)
def top(src,predicate,n): return [{'call':k,'ms':round(v/1000,2)} for k,v in src.most_common() if predicate(k)][:n]
repo=lambda s:'@randomizer/' in s
out={'samples':len(p['samples']),'totalMs':sum(p['timeDeltas'])/1000,
     'repoSelf':top(self_time,repo,18),'repoInclusive':top(inclusive,repo,25),'allSelf':top(self_time,lambda _:True,14)}
with dst.open('x') as f:f.write(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(out,ensure_ascii=False))
