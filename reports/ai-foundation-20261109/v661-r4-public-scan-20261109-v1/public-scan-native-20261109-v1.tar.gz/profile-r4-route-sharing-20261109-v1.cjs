'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),z=require('node:zlib');
const {open,seat}=require('./native-late-r3');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const base=require('./r4-paid-move-clean-20261109-v1.json')[0];
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const js=fs.readFileSync(file,'utf8'),pre='    function rememberPrefix(key,node,actionId,child){',native='    function executeCurrent(current) {';
for(const a of [pre,native])assert.equal(js.split(a).length,2);
mod._compile(js.replace(pre,pre+`
      globalThis.observePrefix(node,actionId,child,nodes.get(node),nodes.get(child));
`).replace(native,native+`
      globalThis.observeNative(loadedEnvelope,current);
`),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const prefix=[],seenPrefixes=new Set(),nativeRows=[],menus=new Map(),envelopeIds=new WeakMap();let seq=0;
const id=e=>{if(!e)return null;if(!envelopeIds.has(e))envelopeIds.set(e,++seq);return envelopeIds.get(e);};
globalThis.observePrefix=(n,a,c,src,dst)=>{
 if(!src||!dst)return;
 const k=[src.serial,a,dst.serial].join(':');
 if(seenPrefixes.has(k))return;seenPrefixes.add(k);
 const action=n.legalActions.find(x=>x.actionId===a),s=src.envelope.session?.session, e=s?.queue[0];
 prefix.push({source:src.serial,target:dst.serial,action:a,fromEnvelope:id(src.envelope),toEnvelope:id(dst.envelope),family:action?.family,
   effect:e?.type||null,status:n.status,goal:src.resourceControl?.goal?.id||null,src,dst});
 if(e?.type==='science_domain_scan_step'&&e.payload?.options?.mode==='public'){
   const rec=menus.get(src.envelope)||{snapshot:src.envelope,selected:e.payload.options.selected,legal:n.legalActions.map(a=>a.actionId),executed:[]};
   rec.executed.push({id:a,next:dst.envelope,status:c.status,boundary:c.boundary});menus.set(src.envelope,rec);
 }
};
globalThis.observeNative=(e,a)=>nativeRows.push({envelope:id(e),action:a?.actionId,family:a?.family,domain:e?.session?.session?.queue[0]?.type||null});
const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
function by(arr,key){
 const groups=new Map();
 for(const x of arr){const k=key(x),items=groups.get(k)||[];items.push(x);groups.set(k,items);}
 return groups;
}
function grouped(arr,key){
 return [...by(arr,key)].map(([name,items])=>({name,count:items.length})).sort((a,b)=>b.count-a.count);
}
try{
 const r=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(r.complete&&!r.unresolved.length);assert.deepEqual(m.save(),root);assert.equal(r.diagnostics.nativeExecutions,base.native);
 assert.equal(JSON.stringify(r.roots.map(x=>[x.actionId,x.value,x.realization,x.preparationDebt])),JSON.stringify(base.ranking));
 const exactEnvelopeGroups=by(prefix,x=>x.fromEnvelope+':'+x.action);
 const exactDupes=[...exactEnvelopeGroups.values()].flatMap(xs=>xs.slice(1));
 const strict=by(prefix,x=>JSON.stringify([x.src.physicalKey,x.action]));
 const physicalDupes=[...strict.values()].flatMap(xs=>xs.slice(1));
 const nativeMap=by(nativeRows,x=>x.envelope+':'+x.action);
 const nativeDupes=[...nativeMap.values()].flatMap(xs=>xs.slice(1));
 const list=r.lines, reach=new Map(), perRoot=[];
 for(const edge of list[0].edges){
  const set=new Set();const visit=i=>{if(set.has(i))return;set.add(i);for(const e of list[i].edges)visit(e.target);};
  visit(edge.target);for(const i of set)reach.set(i,(reach.get(i)||0)+1);
  perRoot.push({family:edge.actionId.split(':')[0],action:edge.actionId,value:list[edge.target].value,nodes:set.size,nodeIds:[...set]});
 }
 for(const x of perRoot){x.exclusive=x.nodeIds.filter(i=>reach.get(i)===1).length;delete x.nodeIds;}
 const summary={prefixes:prefix.length,exactEnvelopeRepeat:grouped(exactDupes,x=>[x.family,x.effect||'—'].join('|')),
  exactPhysicalRepeat:grouped(physicalDupes,x=>[x.family,x.effect||'—'].join('|')),nativeEnvelopeRepeat:grouped(nativeDupes,x=>[x.family,x.domain||'—'].join('|')),
  native:nativeRows.length,roots:perRoot.sort((a,b)=>b.exclusive-a.exclusive),scanMenus:menus.size};
 const data={summary,menus:[...menus.values()]};
 fs.writeFileSync(process.argv[2],z.gzipSync(JSON.stringify(data)+'\n'),{flag:'wx'});
 console.log(JSON.stringify(summary));
}finally{port.close();m.dispose();}
