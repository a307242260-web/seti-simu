'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {open,seat}=require('./native-late-r3');
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const code=fs.readFileSync(file,'utf8'),hook='    function executeCurrent(current) {';assert.equal(code.split(hook).length,2);
mod._compile(code.replace(hook,hook+`
      const s=loadedEnvelope?.session?.session;
      globalThis.collectOfficialNative(current,s);
`),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const {checkpoint:root,nativeInputs:baseline,actionId:prior}=require('./v661-r4-full-preflight-20261109-v1.json');
const data=require(path.resolve('randomizer/game/data')), cardEffects=require(path.resolve('randomizer/game/cards/effects'));
const categories={}, dataPlacementScopes={};
globalThis.collectOfficialNative=(a,s)=>{
 const effect=s?.queue?.[0]?.type, origin=s?.journal?.actions?.[0]?.action?.family;
 const key=[a.family,effect||'stable',origin||'—'].join('|');categories[key]=(categories[key]||0)+1;
 if(effect!=='science_domain_place_data'||a.family!=='choose_target')return;
 const t=s.workingState.turn, p=s.workingState.players.players.find(p=>p.id===seat);
 const copy=structuredClone(p), r=data.placeDataToComputer(copy,a.target.target==='computer'?{}:{target:a.target.target,blueSlot:a.target.blueSlot});
 assert(r.ok);
 const slot=r.placementKind==='computer'?{placementSlot:r.placementSlot}:{blueSlot:r.blueSlot};
 const event={type:'placeData',playerId:seat,placementKind:r.placementKind,...slot};
 const domain=[p.mainActionCompleted?'post-main':'pre-main',t.activePlayerIds.every(id=>id===seat||t.passedPlayerIds.includes(id))?'solo':'others',
   r.placementKind==='computer'?`computer${r.placementSlot}`:`blue${r.blueSlot}`,r.slotBonuses.map(b=>b.type).join('+')||'none',
   cardEffects.collectMatchingTriggers(copy,event).length?'card-trigger':'no-card-trigger',
   t.cardTurnEventBonuses?.length?'turn-bonus':'no-turn-bonus'].join('|');
 dataPlacementScopes[domain]=(dataPlacementScopes[domain]||0)+1;
};
const m=open(root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const s=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(s.complete&&!s.unresolved.length);assert.deepEqual(m.save(),root);
 assert.equal(Object.values(categories).reduce((a,b)=>a+b,0),s.diagnostics.nativeExecutions);
 const facts={baselineNativeInputs:baseline,baselineAction:prior,action:s.actionId,value:s.value,native:s.diagnostics.nativeExecutions,
  msInstrumented:s.rootAndSearchMilliseconds,categories,dataPlacementScopes,provedPlacements:s.analysis.provedFinalDataPlacements,
  selectedSteps:s.plan?.steps||null,roots:s.roots.map(r=>[r.actionId,r.value,r.realization,r.preparationDebt])};
 fs.writeFileSync(process.argv[2],JSON.stringify(facts,null,2)+'\n',{flag:'wx'});
 const top=Object.entries(categories).sort((a,b)=>b[1]-a[1]).slice(0,10);
 console.log(JSON.stringify({native:facts.native,ms:facts.msInstrumented,action:facts.action,provedPlacements:facts.provedPlacements,top,dataPlacementScopes}));
}finally{p.close();m.dispose();}
