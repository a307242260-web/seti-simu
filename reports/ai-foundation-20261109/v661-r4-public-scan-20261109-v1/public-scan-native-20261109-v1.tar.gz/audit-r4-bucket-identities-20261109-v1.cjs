'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),crypto=require('node:crypto');
const {open,seat}=require('./native-late-r3');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const base=require('./r4-public-scan-official-profile-20261109-v1.json');
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const js=fs.readFileSync(file,'utf8'),anchor='          if(physicalId===undefined)physicalId=internPhysicalIdentity(this,envelope,status,boundary);';
assert.equal(js.split(anchor).length,2);
mod._compile(js.replace(anchor,`
          if(physicalId===undefined){
            physicalId=internPhysicalIdentity(this,envelope,status,boundary);
            globalThis.verifyPhysicalId(this.physicalKey,physicalId,status);
          }
`).replace('    return Object.freeze({ openRoot, expand, identity,','    return Object.freeze({ openRoot, expand, identity,\n      diagnosticNode:(e,status,barrier)=>createNode(e,null,[],status,barrier),'),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
let byKey=new Map(),byId=new Map(),calls=0,byStatus={};
globalThis.verifyPhysicalId=(key,id,status)=>{
 if(byKey.has(key))assert.equal(byKey.get(key),id,'the bucket split an exact identity');
 if(byId.has(id))assert.equal(byId.get(id),key,'a bucket collision merged distinct states');
 byKey.set(key,id);byId.set(id,key);calls++;byStatus[status]=(byStatus[status]||0)+1;
};
const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
const checks=[];
try{
 port.openRoot();
 const make=(change=()=>{},status='stable',barrier=null)=>{
  const state=JSON.parse(root.committedState);change(state);
  const n=port.diagnosticNode({...root,committedState:JSON.stringify(state),session:null},status,barrier);
  return port.identity(n);
 };
 const original=make();
 assert.equal(make(s=>{s.meta.stateVersion+=100;s.match.decisionVersion+=10;s.meta.rngState.branch=true;}),original);
 checks.push('authority-and-branch-marker-equivalence');
 assert.equal(make(s=>{s.meta.sequences.dataToken+=5;for(const p of s.players.players)for(const t of p.dataState.poolTokens){t.id+=':renumber';t.index+=10;}}),original);
 checks.push('fungible-data-equivalence');
 assert.notEqual(make(s=>{s.meta.rngState.state+=1;}),original);
 checks.push('same-bucket-different-rng');
 assert.notEqual(make(s=>{s.players.players[3].income.credits+=1;}),original);
 checks.push('same-bucket-different-income');
 assert.notEqual(make(undefined,'stable',{code:'hidden_card_reveal'}),original);
 checks.push('visibility-boundary-distinct');
 port.close();
 byKey=new Map();byId=new Map();calls=0;byStatus={};
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);assert.equal(q.actionId,base.action);assert.equal(q.value,base.value);
 assert.equal(JSON.stringify(q.roots.map(r=>[r.actionId,r.value,r.realization,r.preparationDebt])),JSON.stringify(base.roots));
 assert.equal(q.diagnostics.nativeExecutions,base.native);
 assert.equal(byKey.size,byId.size);
 const facts={checked:calls,physicalDistinct:byKey.size,byStatus,checks,buckets:q.analysis.physicalBucketCount,collisions:q.analysis.identityBucketCollisions,
  graph:crypto.createHash('sha256').update(JSON.stringify(q.lines)).digest('hex')};
 fs.writeFileSync(process.argv[2],JSON.stringify(facts,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(facts));
}finally{port.close();m.dispose();}
