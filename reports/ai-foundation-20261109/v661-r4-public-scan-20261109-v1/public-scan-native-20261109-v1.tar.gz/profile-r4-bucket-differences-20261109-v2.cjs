'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {open,seat}=require('./native-late-r3');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const js=fs.readFileSync(file,'utf8'),anchor='        const exact=stored.physicalKey;';
assert.equal(js.split(anchor).length,2);
mod._compile(js.replace(anchor,anchor+'\n        globalThis.noteBucket(exact,bucket);'),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const rows={};
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
globalThis.noteBucket=(exact,bucket)=>{
 if(bucket.some(b=>b.stored.physicalKey===exact)){rows.equal=(rows.equal||0)+1;return;}
 const a=JSON.parse(exact),b=JSON.parse(bucket[0].stored.physicalKey),x=a.state,y=b.state;
 const scopes=Object.keys(x).filter(k=>!same(x[k],y[k]));
 if(scopes.includes('players')){
  const changing=new Set();
  for(let i=0;i<x.players.players.length;i++)for(const k of Object.keys(x.players.players[i]))if(!same(x.players.players[i][k],y.players.players[i][k]))changing.add(k);
  scopes.splice(scopes.indexOf('players'),1,...[...changing].sort().map(k=>'p:'+k));
 }
 for(const name of ['aliens','data']){
  if(!scopes.includes(name))continue;
  const changed=Object.keys(x[name]).filter(k=>!same(x[name][k],y[name][k]));
  scopes.splice(scopes.indexOf(name),1,...changed.map(k=>name+':'+k+(x[name][k]&&y[name][k]&&typeof x[name][k]==='object'&&!Array.isArray(x[name][k])
    ?'('+Object.keys(x[name][k]).filter(j=>!same(x[name][k][j],y[name][k][j])).join(',')+')':'')));
 }
 if(!same(a.pending,b.pending))scopes.push('queue');
 const key=scopes.sort().join('|');rows[key]=(rows[key]||0)+1;
};
const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 const entries=Object.entries(rows).sort((a,b)=>b[1]-a[1]);assert.equal(entries.reduce((n,[,v])=>n+v,0),q.analysis.identityBucketCollisions);
 fs.writeFileSync(process.argv[2],JSON.stringify({buckets:q.analysis.physicalBucketCount,differences:entries},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(entries.slice(0,14)));
}finally{port.close();m.dispose();}
