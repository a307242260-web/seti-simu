'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),crypto=require('node:crypto');
const {open,seat}=require('./native-late-r3');
const source=JSON.parse(z.gunzipSync(fs.readFileSync(path.join(__dirname,'r4-route-sharing-20261109-v1.json.gz'))));
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const js=fs.readFileSync(file,'utf8'),needle='return Object.freeze({ createAnalysisPort });';assert.equal(js.split(needle).length,2);
mod._compile(js.replace(needle,'return Object.freeze({ createAnalysisPort, forwardIdentity });'),file);
const {forwardIdentity}=mod.exports;
const state=e=>e.session?.session.workingState||JSON.parse(e.committedState),key=e=>forwardIdentity(e,'decision',null);
const md=e=>crypto.createHash('sha256').update(key(e)).digest('hex');
const actual=new Map(source.menus.map(m=>[md(m.snapshot),m]));
const choices=m=>m.menu().filter(a=>a.family==='choose_card'&&a.target.publicSlotIndex!=null);
function diff(a,b,p='',out=[]){
 if(Object.is(a,b)||out.length>=40)return out;
 if(a&&b&&typeof a==='object'&&typeof b==='object'){
  for(const k of new Set([...Object.keys(a),...Object.keys(b)]))diff(a[k],b[k],p+'.'+k,out);
 }else out.push(p);
 return out;
}
const roots=source.menus.filter(m=>!m.selected),rows=[];
for(const r of roots){
 const m=open(r.snapshot);
 try{
  const opt=choices(m).filter(a=>true&&r.executed.some(x=>x.id===a.actionId));
  for(let i=0;i<opt.length;i++)for(let j=i+1;j<opt.length;j++){
   const a=opt[i],b=opt[j],run=(first,second)=>{
    m.restore(r.snapshot);
    const f=m.menu().find(x=>x.actionId===first.actionId);assert(f);m.apply(f);
    const afterFirst=m.save(),done=m.menu().find(x=>x.actionId===second.actionId);
    if(!done)return null;
    const followed=Boolean(actual.get(md(afterFirst))?.executed.some(x=>x.id===second.actionId));
    m.apply(done);
    return {end:m.save(),followed};
   };
   const x=run(a,b),y=run(b,a);
   if(!x||!y){rows.push({legalBoth:false});continue;}
   const as=state(x.end),bs=state(y.end);
   const same=key(x.end)===key(y.end),different=diff(as,bs);
   rows.push({legalBoth:true,first:a.target.nebulaId,second:b.target.nebulaId,exactForward:same,
    exploredBoth:x.followed&&y.followed,oneExplored:x.followed||y.followed,changes:different,
    rngExact:JSON.stringify(as.meta.rngState)===JSON.stringify(bs.meta.rngState)});
  }
 }finally{m.dispose();}
}
const counts={};for(const x of rows){const k=[x.legalBoth,x.exploredBoth,x.exactForward].join('|');counts[k]=(counts[k]||0)+1;}
const facts={initialMenus:roots.length,testedPairs:rows.length,counts,rows};
fs.writeFileSync(process.argv[2],JSON.stringify(facts,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({...facts,rows:undefined}));
