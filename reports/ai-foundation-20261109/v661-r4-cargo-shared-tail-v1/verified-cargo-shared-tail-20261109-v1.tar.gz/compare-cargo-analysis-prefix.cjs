'use strict';
const fs=require('fs'),path=require('path'),z=require('zlib'),assert=require('node:assert/strict'),Module=require('node:module');
const [src,out]=process.argv.slice(2),{open,seat}=require('./native-late-r3');
const {root,rows}=JSON.parse(z.gunzipSync(fs.readFileSync(src)));
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const hook='return Object.freeze({ createAnalysisPort });';
const js=fs.readFileSync(file,'utf8');assert(js.includes(hook));
mod._compile(js.replace(hook,'return Object.freeze({ createAnalysisPort, forwardIdentity });'),file);
const {forwardIdentity}=mod.exports;
const makeKey=e=>forwardIdentity(e,'stable',null);
const m=open(root);
try{
 const firstClaim=rows.find(r=>r.family==='complete_task').accepted[0];
 const analyze=rows.find(r=>r.family==='analyze').accepted[0],paths=[];
 m.apply(analyze);
 const variants=m.menu();
 for(const choice of variants){
  const ways=[];
  for(const order of [[firstClaim,analyze,choice],[analyze,choice,firstClaim]]){
   m.restore(root);
   const replay=[];let absent=null;
   for(const action of order){
    const native=m.menu().find(a=>a.actionId===action.actionId);
    if(!native){absent={action:action.summary,menu:m.menu().map(a=>a.summary)};break;}
    replay.push(m.apply(native));
   }
   const end=m.save(),f=m.facts();m.restore(root);replay.forEach(m.apply);assert.deepEqual(m.save(),end);
   ways.push({replay,end,absent,facts:f});
  }
  const equality=!ways.some(x=>x.absent)&&makeKey(ways[0].end)===makeKey(ways[1].end);
  paths.push({choice,ways,equality});
  console.log(JSON.stringify({choice:choice.summary,equality,paths:ways.map(x=>[x.replay.map(a=>a.summary),x.facts.wallet,x.absent?.action])}));
 }
 fs.writeFileSync(out,z.gzipSync(JSON.stringify({root,paths})+'\n'),{flag:'wx'});
}finally{m.dispose();}
