'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const [source,out]=process.argv.slice(2),{open,seat}=require('./native-late-r3');
const file=path.resolve('randomizer/game/ai/analysis-port.js');
const mod=new Module(file,module);mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const anchor='    function turnTailBoundary(node,spec){';
const js=fs.readFileSync(file,'utf8');assert.equal(js.split(anchor).length,2);
mod._compile(js.replace(anchor,anchor+`
      if(spec.quietR4ChongEnd){
        const before=valueObservation(node);
        let child=expand(node,spec.firstActionId);
        for(const tileId of spec.markedTiles){
          const mark=child.legalActions.find(a=>a.target?.tileId===tileId);
          if(!mark)throw Error("NO_NATIVE_MARK");
          child=expand(child,mark.actionId);
        }
        globalThis.auditQuietChong(before,valueObservation(child),child.status,spec);
      }`),file);
const {createAnalysisPort}=mod.exports;
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const stateValue=require(path.resolve('randomizer/game/ai/state-value'));
const evalV=stateValue.createStateValueEvaluator(seat),rows=[];
let details;
globalThis.auditQuietChong=(before,after,status,spec)=>{
 assert(['turn-boundary','information-barrier'].includes(status),status);
 assert.equal(after.publicState.roundNumber,before.publicState.roundNumber);
 assert.equal(after.publicState.currentPlayerId,before.publicState.currentPlayerId);
 const b=evalV.details(before),a=evalV.details(after);
 assert.equal(stateValue.sumValueParts([b.value,spec.netGain]),a.value);
 assert.equal(stateValue.sumValueParts([b.unrealizedPurposeValue,spec.unrealizedPurposeDelta||0]),a.unrealizedPurposeValue);
 assert.equal(b.purposePreparationDebt,a.purposePreparationDebt);
 details.push({status,marks:spec.markedTiles,gain:spec.netGain,nativeValue:a.value});
};
for(const row of JSON.parse(z.gunzipSync(fs.readFileSync(source))).rows.filter(r=>r.input>=355)){
 const m=open(row.root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  details=[];
  const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length);
  assert.deepEqual(m.save(),row.root);
  assert(details.length>0);
  assert.deepEqual(q.roots.filter(a=>a.target!=null).map(a=>[a.actionId,a.value,a.realization||0,a.preparationDebt]),row.ranking);
  rows.push({input:row.input,audited:details.length,details});
  console.log(JSON.stringify({input:row.input,audited:details.length,allExact:true}));
 }finally{p.close();m.dispose();}
}
fs.writeFileSync(out,JSON.stringify(rows,null,2)+'\n',{flag:'wx'});
