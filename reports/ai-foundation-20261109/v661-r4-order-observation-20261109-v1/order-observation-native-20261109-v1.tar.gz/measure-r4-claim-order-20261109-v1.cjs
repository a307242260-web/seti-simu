'use strict';
const path=require('node:path'),assert=require('node:assert/strict'),{open,seat}=require('./native-late-r3');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const base=require('./r4-lazy-snapshots-official-profile-20261109-v1.json');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 assert.equal(q.actionId,base.action);assert.equal(q.value,base.value);
 assert.equal(JSON.stringify(q.roots.map(r=>[r.actionId,r.value,r.realization,r.preparationDebt])),JSON.stringify(base.roots));
 console.log(JSON.stringify({label:process.argv[2],native:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,
 nodes:q.analysis.nodeCount,transitions:q.diagnostics.transitions,values:q.diagnostics.valueEvaluations,
 proofCount:q.lines.flatMap(x=>x.finalEndClaimEquivalences||[]).length}));
}finally{port.close();m.dispose();}
