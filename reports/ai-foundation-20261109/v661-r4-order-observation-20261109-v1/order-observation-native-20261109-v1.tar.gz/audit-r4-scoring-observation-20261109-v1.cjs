'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),z=require('node:zlib'),crypto=require('node:crypto');
const file=path.resolve('randomizer/app/rule-observation.js'),current=require(file);
const old=require(path.join(__dirname,'candidate-r4-lazy-snapshots-v1/randomizer/app/rule-observation.js'));
const count={total:0,frozenBoards:0,full:0,cheap:0};
require.cache[file].exports={...current,buildRuleObservation:(state,seed,seat,actions,options)=>{
 const board=JSON.stringify(state.finalScoring);
 const a=current.buildRuleObservation(state,seed,seat,actions,options);
 assert.deepEqual(a,old.buildRuleObservation(state,seed,seat,actions,options));
 const override={...options,cheap:!options?.cheap};
 assert.deepEqual(current.buildRuleObservation(state,seed,seat,actions,override),old.buildRuleObservation(state,seed,seat,actions,override));
 assert.equal(JSON.stringify(state.finalScoring),board);
 count.total++;count.full++;count.cheap++;if(Object.isFrozen(state.finalScoring))count.frozenBoards++;
 return a;
}};
const {open,seat}=require('./native-late-r3');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const teacher=JSON.parse(z.gunzipSync(fs.readFileSync(path.join(__dirname,'candidate-r4-active-task-preview-native-20261109-v1.json.gz')))).rows;
const baseline=require('./r4-lazy-snapshots-clean-20261109-v1.json');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const results=[];
for(const s of [{input:'official-r4',root},...teacher]){
 const m=open(s.root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});const before=count.total;
 try{
  const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),s.root);
  const graph=crypto.createHash('sha256').update(JSON.stringify(q.lines,(key,value)=>key==='routingNodes'?undefined:value)).digest('hex');
  const prior=baseline.find(x=>x.label===s.input);
  assert.equal(graph,prior.graph);assert.equal(q.actionId,prior.action);assert.equal(q.value,prior.value);assert.equal(q.diagnostics.nativeExecutions,prior.native);
  assert.equal(JSON.stringify(q.roots.map(x=>[x.actionId,x.value,x.realization,x.preparationDebt])),JSON.stringify(prior.ranking));
  results.push({input:s.input,graph,projections:count.total-before,native:prior.native});
 }finally{p.close();m.dispose();}
}
assert(count.total>100);
fs.writeFileSync(process.argv[2],JSON.stringify({count,results},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({count,results}));
