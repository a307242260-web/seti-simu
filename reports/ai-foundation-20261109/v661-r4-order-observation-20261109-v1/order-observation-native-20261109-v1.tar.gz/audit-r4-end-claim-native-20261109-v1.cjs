'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),zlib=require('node:zlib');
const {open,seat}=require('./native-late-r3');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const prior=require('./r4-lazy-snapshots-official-profile-20261109-v1.json');
const witnesses=require('./r4-active-task-preview-proof-20261109-v2.json');
const originals=JSON.parse(zlib.gunzipSync(fs.readFileSync(path.join(__dirname,'r4-data-before-claim-20261109-v1.json.gz')))).cases;
const p=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(p,module);
mod.filename=p;mod.paths=Module._nodeModulePaths(path.dirname(p));
const js=fs.readFileSync(p,'utf8'), anchor='      return {proof:"seti-final-positive-task-quiet-end-order-v1",equivalentTo:endId,';
assert.equal(js.split(anchor).length,2);
mod._compile(js.replace(anchor,'      globalThis.captureEndClaim(stored.envelope, action, end, early, delayed);\n'+anchor)
 .replace('return Object.freeze({ createAnalysisPort });','return Object.freeze({ createAnalysisPort, forwardIdentity });'),p);
const {createAnalysisPort,forwardIdentity}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const captured=[];
globalThis.captureEndClaim=(e,claim,end,early,delayed)=>captured.push({e,claim,end,early,delayed});
const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
let q;
try{
 q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 assert.equal(q.actionId,prior.action);assert.equal(q.value,prior.value);
 assert.equal(JSON.stringify(q.roots.map(r=>[r.actionId,r.value,r.realization,r.preparationDebt])),JSON.stringify(prior.roots));
 assert.equal(q.lines.flatMap(x=>x.finalEndClaimEquivalences||[]).length,captured.length);
}finally{port.close();m.dispose();}
const expected=new Map(originals.map(c=>[forwardIdentity(c.state,'stable',null),c.index]));
const observed=[];
for(const {e,claim,end,early,delayed} of captured){
 const before={schemaVersion:e.schemaVersion,committedState:e.committedState,session:e.session};
 const index=expected.get(forwardIdentity(before,'stable',null));assert(Number.isSafeInteger(index));
 const canonical=originals.find(c=>c.index===index).state;
 const run=open(canonical);
 try{
  run.apply(claim);run.act('end_turn');const a=run.save();
  for(const k of Object.keys(early))assert(require("node:util").isDeepStrictEqual(run.state()[k],early[k]),`early ${index} ${k}`);assert(!a.session);
  run.restore(canonical);run.apply(end);
  const menu=run.menu();assert.equal(menu.length,2);
  run.act('accept_optional_effect',x=>x.target.choiceId===`confirm:task:${claim.target.cardInstanceId}:${claim.target.ruleId}`);
  const b=run.save();for(const k of Object.keys(delayed))assert(require("node:util").isDeepStrictEqual(run.state()[k],delayed[k]),`delayed ${index} ${k}`);assert(!b.session);
  assert.equal(forwardIdentity(a,'other-owner',null),forwardIdentity(b,'other-owner',null));
  assert.deepEqual(JSON.parse(a.committedState).meta.rngState,JSON.parse(b.committedState).meta.rngState);
  run.restore(canonical);
  observed.push({index,cardId:claim.target.cardInstanceId,rule:claim.target.ruleId,earlyInputs:2,lateInputs:2,fullStateAndRngEqual:true});
 }finally{run.dispose();}
}
assert.deepEqual(observed.map(x=>x.index).sort((a,b)=>a-b),witnesses.endPairs.map(x=>x.index).sort((a,b)=>a-b));
assert.equal(new Set(observed.map(x=>x.index)).size,29);
assert.equal(q.diagnostics.nativeExecutions,221);
assert.equal(q.diagnostics.transitions,1258);
const results={observed,proofs:observed.length,native:q.diagnostics.nativeExecutions,transitions:q.diagnostics.transitions,
 nodes:q.analysis.nodeCount,values:q.diagnostics.valueEvaluations,otherUnproven:originals.filter(x=>!observed.some(y=>y.index===x.index)).map(x=>x.index)};
fs.writeFileSync(process.argv[2],JSON.stringify(results,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({...results,observed:undefined,otherUnproven:results.otherUnproven.length}));
