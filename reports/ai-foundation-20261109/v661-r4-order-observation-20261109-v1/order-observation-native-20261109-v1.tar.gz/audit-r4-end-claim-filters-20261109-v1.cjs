'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {open,seat}=require('./native-late-r3');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const base=require('./r4-lazy-snapshots-official-profile-20261109-v1.json');
const p=path.resolve('randomizer/game/ai/analysis-port.js'), mod=new Module(p,module);
mod.filename=p;mod.paths=Module._nodeModulePaths(path.dirname(p));
const js=fs.readFileSync(p,'utf8'),i=js.indexOf('    function redundantFinalEndClaim('),j=js.indexOf('    function redundantCargoClaim(',i);
assert(i>=0&&j>i);
let g=0;const original=js.slice(i,j),probe=original.replace(/return null;/g,()=>`return globalThis.filterEndClaim(${++g});`);
mod._compile(js.slice(0,i)+probe+js.slice(j),p);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const count={};globalThis.filterEndClaim=i=>{count[i]=(count[i]||0)+1;return null;};
const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 const changes=q.roots.filter((r,i)=>JSON.stringify([r.actionId,r.value,r.realization,r.preparationDebt])!==JSON.stringify(base.roots[i]));
 assert.deepEqual(changes,[]);
 const proofs=q.lines.flatMap(x=>x.finalEndClaimEquivalences||[]);
 const facts={count,proofs,ms:q.rootAndSearchMilliseconds,native:q.diagnostics.nativeExecutions,nodes:q.analysis.nodeCount,
 transitions:q.diagnostics.transitions,values:q.diagnostics.valueEvaluations};
 fs.writeFileSync(process.argv[2],JSON.stringify(facts,null,2)+'\n',{flag:'wx'});console.log({...facts,proofs:proofs.length});
}finally{port.close();m.dispose();}
