'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),z=require('node:zlib');
const {open,seat}=require('./native-late-r3');
const {checkpoint:official}=require('./v661-r4-full-preflight-20261109-v1.json');
const baseline=require('./r4-lazy-snapshots-clean-20261109-v1.json');
const teacher=JSON.parse(z.gunzipSync(fs.readFileSync(path.join(__dirname,'candidate-r4-active-task-preview-native-20261109-v1.json.gz')))).rows;
const p=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(p,module);
mod.filename=p;mod.paths=Module._nodeModulePaths(path.dirname(p));
const js=fs.readFileSync(p,'utf8'),anchor='      if (!current || current.actorId !== seatId) throw new Error("ANALYSIS_ACTION_STALE");';
assert.equal(js.split(anchor).length,2);
mod._compile(js.replace(anchor,anchor+'\n      globalThis.tallyNativeInput(current,head);'),p);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
let tally,families,claims;
globalThis.tallyNativeInput=(a,b)=>{
 const d=b;
 if(a.family==='complete_task'||a.family==='accept_optional_effect'){
  const payload=d?.payload||a.target;
  const phase=a.family==='complete_task'?'active':(a.target?.choiceId||'').split(':')[0];
  const key=[phase,payload.kind||'task',payload.ruleId||'-',payload.cardInstanceId||'-'].join('|');
  claims[key]=(claims[key]||0)+1;
 }
 const key=[a.family,d?.type||d?.kind||'-',a.target?.kind||'-'].join('|');
 tally[key]=(tally[key]||0)+1;families[a.family]=(families[a.family]||0)+1;
};
const roots=[{input:'official-r4',root:official},...teacher.filter(t=>[355,359].includes(t.input))],rows=[];
for(const r of roots){
 tally={};families={};claims={};const m=open(r.root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),r.root);
  const base=baseline.find(x=>x.label===r.input);
  assert.equal(q.actionId,base.action);assert.equal(q.value,base.value);assert.equal(q.diagnostics.nativeExecutions,base.native);
  assert.equal(Object.values(tally).reduce((n,x)=>n+x,0),base.native);
  const sort=o=>Object.entries(o).sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0]));
  rows.push({label:r.input,native:base.native,source:sort(families),categories:sort(tally),claims:sort(claims)});
 }finally{port.close();m.dispose();}
}
fs.writeFileSync(process.argv[2],JSON.stringify(rows,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(rows.map(({label,native,claims})=>({label,native,claims}))));
