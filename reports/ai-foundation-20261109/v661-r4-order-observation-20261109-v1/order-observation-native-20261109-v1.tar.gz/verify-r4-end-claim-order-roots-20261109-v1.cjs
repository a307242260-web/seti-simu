'use strict';
const crypto=require('node:crypto'),fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),z=require('node:zlib'),{open,seat}=require('./native-late-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const official=require('./v661-r4-full-preflight-20261109-v1.json').checkpoint;
const base=require('./r4-scan-state-buckets-clean-20261109-v2.json');
const old=JSON.parse(z.gunzipSync(fs.readFileSync(path.join(__dirname,'candidate-r4-active-task-preview-native-20261109-v1.json.gz')))).rows;
const roots=[{input:'official-r4',root:official},...old],result=[];
for(const r of roots){
 const m=open(r.root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),r.root);
  const ranking=q.roots.map(x=>[x.actionId,x.value,x.realization,x.preparationDebt]);
  const prior=base.find(x=>x.label===r.input);
  assert.equal(q.actionId,prior.action);assert.equal(q.value,prior.value);
  assert.equal(JSON.stringify(ranking),JSON.stringify(prior.ranking));
  result.push({label:r.input,action:q.actionId,value:q.value,native:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,
   proofCount:q.analysis.provedScan4QuietMoves,refillHits:q.analysis.scan4RefillHits,refillEntries:q.analysis.scan4RefillCacheEntries,moveMenus:q.analysis.provedMoveMenus,movePayments:q.analysis.provedMovePayments,graph:crypto.createHash('sha256').update(JSON.stringify(q.lines,(key,value)=>key==='routingNodes'?undefined:value)).digest('hex'),analysis:q.analysis,diagnostics:q.diagnostics,ranking});
 }finally{p.close();m.dispose();}
}
assert.equal(result[0].native,221);
assert.equal(result[0].analysis.nodeCount,1465);
fs.writeFileSync(process.argv[2],JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(result.map(({ranking,analysis,diagnostics,...r})=>({...r,identityBytes:analysis.identityMaterializations,buckets:analysis.physicalBucketCount,lazy:analysis.lazyCommittedEnvelopes,previewSerializations:analysis.lazyPreviewSerializations,referenceSaves:analysis.committedReferenceCount}))));
