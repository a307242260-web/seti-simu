'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict');
const [where,out]=process.argv.slice(2),r=p=>JSON.parse(z.gunzipSync(fs.readFileSync(path.join(where,p))));
const {open,seat}=require(path.resolve(where,'native-late-r3')),cold=r('teacher-r4-ready-transport-cold-20261109-v1.json.gz');
const wait=r('teacher-r4-delivery-claim-timing-20261109-v1.json.gz').find(x=>x.mode==='teacher-wait');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const {quoteDeferredCargo}=require(path.resolve('randomizer/game/ai/local-decision-plans'));
const roots=[
 [314,JSON.parse(fs.readFileSync(path.join(where,'teacher-r4-scan4-not-adjacent-20261109-v1.json')))],
 ...cold.rows.filter(x=>[351,354,359].includes(x.summary.i)).map(x=>[x.summary.i,x.root]),
 [355,wait.stages[0].envelope],
];
const rows=[];
for(const [input,root] of roots){
 const m=open(root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  const menu=m.menu(),q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:menu}).search;
  assert.deepEqual(m.save(),root);assert(q.complete&&!q.unresolved.length);
  const quotes=q.lines.flatMap(l=>l.deferredCargo?[{...l.deferredCargo,boundary:l.boundary}]:[]);
  const chosen=menu.find(a=>a.actionId===q.actionId);
  if(input===351||input===354){
   assert.equal(q.actionId,input===351?'choose_target:43d1120f':'accept_optional_effect:564fb7e2');
   assert.equal(quotes.length,1);assert.equal(quotes[0].value,7);assert.deepEqual(quotes[0].slots,[5,6]);
   assert.equal(q.value,257.5);assert(q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600);
  }else assert.equal(quotes.length,0);
  rows.push({input,root,chosen:chosen.summary,actionId:q.actionId,value:q.value,native:q.diagnostics.nativeExecutions,
   ms:q.rootAndSearchMilliseconds,quotes,ranking:q.roots.filter(a=>a.target!=null).map(a=>[a.actionId,a.value,a.realization,a.preparationDebt])});
  console.log(JSON.stringify({input,chosen:chosen.summary,value:q.value,native:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds,quotes}));
 }finally{p.close();m.dispose();}
}
const m=open(wait.stages[0].envelope);
let negatives,matched;
try{
 const base=m.state(),root=structuredClone(base),cards=new Set(m.player().reservedCards.map(c=>c.id)),fossils=new Set(['fossil_07']);
 const opts={state:base,seatId:seat,knownCards:cards,knownFossilIds:fossils};
 assert.deepEqual(quoteDeferredCargo(opts)?.slots,[5,6]);assert.deepEqual(base,root);
 const wrongTurn=structuredClone(base);wrongTurn.turn.passedPlayerIds.pop();
 const noSpace=structuredClone(base),player=noSpace.players.players.find(p=>p.id===seat);
 player.dataState.placedTokens.push({id:'probe-test-computer-5',index:100,placementKind:'computer',placementSlot:5});
 const claims=[
  ['unknown-fossil',{knownFossilIds:new Set()}],['unknown-task',{knownCards:new Set()}],
  ['other-player-active',{state:wrongTurn}],['only-one-quiet-slot',{state:noSpace}],
 ];
 negatives=claims.map(([label,override])=>{assert.equal(quoteDeferredCargo({...opts,...override}),null);return label;});
 const comparison=r('teacher-r4-claim-vs-analysis-20261109-v1.json.gz');
 const a=comparison.rows.find(x=>x.family==='analyze'),b=comparison.rows.find(x=>x.family==='complete_task');
 m.restore(comparison.root);
 const pre=b.accepted.slice(0,-1);pre.forEach(m.apply);
 const corner=m.apply(a.accepted.find(x=>x.family==='card_corner')),end=m.apply(b.accepted.at(-1)),claim=m.save();
 const f=m.facts();m.restore(a.end);const g=m.facts();assert.deepEqual(f,g);
 m.restore(comparison.root);[...pre,corner,end].forEach(m.apply);assert.deepEqual(m.save(),claim);
 matched={acceptance:[...pre,corner,end],claim,analyze:a.end,exactVisibleFactsAndRng:true,score:f.wallet.score,final:f.final,wallet:f.wallet};
}finally{m.dispose();}
fs.writeFileSync(out,z.gzipSync(JSON.stringify({rows,negatives,matched})+'\n'),{flag:'wx'});
