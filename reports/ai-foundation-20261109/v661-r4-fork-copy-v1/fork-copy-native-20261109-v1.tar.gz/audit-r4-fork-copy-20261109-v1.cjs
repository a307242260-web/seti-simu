'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const z = require('node:zlib');
const path = require('node:path');
const { open } = require('./native-late-r3');
const read = name => JSON.parse(z.gunzipSync(fs.readFileSync(path.join(__dirname, name))));
const menu = c => c.inspect().session?.decision?.choices || c.inputPort.enumerateActions({});
const save = c => c.lifecycle.save().envelope;
function submit(c, a, compact, invalid = false) {
  const d = c.inspect(true).session?.decision;
  const options = { skipProjection: true, omitTrustedResult: compact };
  if (d) return c.inputPort.submitDecision({ ownerId: d.ownerId, decisionId: d.decisionId,
    decisionVersion: invalid ? d.decisionVersion + 1 : d.decisionVersion, choice: a }, options);
  return a.phase === 'quick' ? c.inputPort.submitQuickAction(a, options) : c.inputPort.submitAction(a, options);
}
const base = read('candidate-cargo-scan-trace-native-20261109-v4.json.gz');
const { root, rows } = read('teacher-r4-claim-vs-analysis-20261109-v1.json.gz');
const sources = rows.map(row => ({ name: row.family, root, actions: row.accepted }));
for (const input of [314, 351, 354]) {
  const { root, actionId } = base.rows.find(row => row.input === input);
  sources.push({ name: `teacher-${input}`, root, actions: [{ actionId }] });
}
const { createSimulationRuleComposition } = require(path.resolve('randomizer/training/simulation-rule-composition'));
const { createSeededRandom } = require(path.resolve('randomizer/game/random'));
const seed = 'fork-copy-information-barrier-v1';
const setup = createSimulationRuleComposition({ seed, activePlayerCount: 4, random: createSeededRandom(seed) });
setup.newGame({ seed, activePlayerCount: 4 });
setup.composition.inputPort.beginDrain({});
const start = menu(setup.composition).find(a => a.target?.kind === 'start_initial_setup');
assert(start);
sources.push({ name: 'initial-offer-information-barrier', root: save(setup.composition), actions: [start] });
setup.composition.dispose();
const evidence = [];
for (const row of sources) {
  const source = open(row.root), normal = open(row.root), normalControl = open(row.root);
  const forks = Array.from({ length: 4 }, () => {
    const fork = source.c.counterfactualPort.createFork(row.root, { branchKey: 'fork-copy-audit', restoreRandomState: true });
    return fork.composition || fork;
  });
  const [ordinary, compact, publishedOrdinary, publishedCompact] = forks;
  const events = [[], []];
  publishedOrdinary.subscribe(event => events[0].push(event));
  publishedCompact.subscribe(event => events[1].push(event));
  let pending = 0, terminal = 0, barriers = 0, rejected = 0;
  try {
    for (const action of row.actions) {
      const fullMenu = menu(ordinary);
      for (const c of [compact, publishedOrdinary, publishedCompact, normal.c]) assert.deepEqual(menu(c), fullMenu);
      const a = fullMenu.find(x => x.actionId === action.actionId);
      assert(a, action.actionId);
      const previous = save(ordinary);
      if (ordinary.inspect(true).session?.decision) {
        const expected = submit(ordinary, a, false, true);
        assert(!expected.ok);
        assert.deepEqual(submit(compact, a, true, true), expected);
        assert.deepEqual(save(ordinary), previous);
        assert.deepEqual(save(compact), previous);
        rejected++;
      }
      const expected = submit(ordinary, a, false);
      assert(expected.ok, JSON.stringify(expected));
      const actual = submit(compact, a, true);
      assert(actual.ok);
      assert.equal(actual.phase, expected.phase);
      assert.deepEqual(actual.irreversibleBarrier, expected.irreversibleBarrier);
      assert.deepEqual(actual.failure, expected.failure);
      assert(Object.hasOwn(expected, 'journal'));
      assert(!Object.hasOwn(actual, 'journal'));
      const expectedPublished = submit(publishedOrdinary, a, false);
      assert.deepEqual(submit(publishedCompact, a, true), expectedPublished);
      const responseNormal = submit(normal.c, a, true);
      assert(responseNormal.ok && Object.hasOwn(responseNormal, 'journal'));
      assert.deepEqual(responseNormal, submit(normalControl.c, a, false));
      assert.deepEqual(normal.save(), normalControl.save());
      const envelope = save(ordinary);
      for (const [index, c] of [compact, publishedOrdinary, publishedCompact].entries()) {
        const actual = save(c);
        if (!require('node:util').isDeepStrictEqual(actual, envelope)) {
          const diffs = Object.keys(envelope).filter(key => !require('node:util').isDeepStrictEqual(actual[key], envelope[key]));
          throw Error(JSON.stringify({ source: row.name, action: a.family, variant: index, diffs,
            sessionKeys: Object.keys(envelope.session || {}).filter(key => !require('node:util').isDeepStrictEqual(actual.session?.[key], envelope.session[key])) }));
        }
      }
      assert.deepEqual(events[0], events[1]);
      assert.deepEqual(source.save(), row.root);
      if (actual.phase === 'completed') terminal++; else pending++;
      if (actual.irreversibleBarrier || envelope.session?.session?.irreversibleBarrier) barriers++;
    }
    evidence.push({ path: row.name, nativeInputs: row.actions.length, pending, terminal, barriers, staleRejected: rejected,
      publishedEvents: events[0].length, identicalEnvelopesAndOriginalRoot: true });
  } finally {
    for (const c of forks) c.dispose();
    source.dispose(); normal.dispose(); normalControl.dispose();
  }
}
assert(evidence.some(x => x.barriers > 0));
assert(evidence.every(x => x.staleRejected > 0));
const candidate = read(process.argv[2]);
const compare = ({ ms, ...row }) => row;
assert.deepEqual(candidate.rows.map(compare), base.rows.map(compare));
fs.writeFileSync(process.argv[3], JSON.stringify({ rows: evidence, coldRoots: candidate.rows.map((row, i) => ({ input: row.input,
  actionId: row.actionId, native: row.native, oldMs: base.rows[i].ms, newMs: row.ms, equalRankingValueAndRoot: true })) }, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(evidence));
