'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),z=require('node:zlib');
const {open,seat}=require('./native-late-r3');
const load=p=>require(path.resolve(p));
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const js=fs.readFileSync(file,'utf8'),start='      if(endClaim){',tail='        const child=finishProvedForeignTurn(stored,requested,endClaim);';
assert.equal(js.split(start).length,2);assert.equal(js.split(tail).length,2);
mod._compile(js.replace(start,start+`
        const audited=globalThis.auditEndClaim({stored,requested,endClaim,restoreEnvelope,executeCurrent,snapshot,comp:fork.composition||fork,
          finish:(before,result)=>finishChild(before,result,movementPlanning?nextMovementIntent(node,requested):null,
            null,stored.informationBarrier,requested,stored)});
`).replace(tail,tail+`
        globalThis.compareEndClaim({audited,child,nodes,identity});
`),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=load('randomizer/game/ai/search-agent');
const local=load('randomizer/game/ai/local-decision-plans');
const rows=[],declined=[];
globalThis.auditEndClaim=({stored,requested,endClaim,restoreEnvelope,executeCurrent,snapshot,comp,finish})=>{
 restoreEnvelope(stored.envelope,true);
 const raw=executeCurrent(requested);assert(raw.result.ok);
 const native=snapshot(comp),s=stored.envelope.session.session,after=JSON.parse(native.committedState);
 assert.equal(native.session,null);assert.deepEqual(after,endClaim);
 assert.deepEqual(s.workingState.meta.rngState,after.meta.rngState);
 assert.notEqual(after.turn.currentPlayerId,seat);
 const p=x=>x.players.players.find(p=>p.id===seat),before=p(s.workingState),owner=p(after);
 const reward=Object.fromEntries(['score','credits','publicity'].map(k=>[k,owner.resources[k]-before.resources[k]]));
 rows.push({rule:s.queue[0].payload.ruleId,reward,nextSeat:after.turn.currentPlayerId});
 if(!declined.length){
  assert.notEqual(comp.inspect().phase,'awaiting_input');
  restoreEnvelope(stored.envelope);
  const legal=comp.inspect().session.decision.choices;
  const fact={state:s.workingState,seatId:seat,actions:legal,session:s,action:requested,
    knownCards:new Set(before.reservedCards.map(c=>c.id))};
  assert.deepEqual(local.previewFinalPositiveEndTask(fact),after);
  for(const [label,change] of [
    ['skip',{action:legal.find(a=>a.target.choiceId.startsWith('skip:'))}],
    ['unknown-task',{knownCards:new Set()}],
    ['additional-effect',{session:{...s,queue:[...s.queue,s.queue[1]]}}],
    ['pass-transition',{session:{...s,queue:[s.queue[0],{...s.queue[1],payload:{...s.queue[1].payload,didPass:true}}]}}],
    ['irreversible-barrier',{session:{...s,irreversibleBarrier:{code:'hidden_card_draw'}}}],
  ]){
    assert.equal(local.previewFinalPositiveEndTask({...fact,...change}),null,label);declined.push(label);
  }
  restoreEnvelope(native);
 }
 return finish(raw.before,raw.result);
};
globalThis.compareEndClaim=({audited,child,nodes,identity})=>{
 assert.deepEqual(audited.legalActions,child.legalActions);assert.equal(audited.status,child.status);assert.equal(audited.boundary,child.boundary);
 assert.deepEqual(nodes.get(audited).intent,nodes.get(child).intent);assert.equal(identity(audited),identity(child));
};
const base=require('./r4-active-task-preview-official-cold-20261109-v1.json').corrected;
const candidate=require('./r4-end-task-settle-official-profile-20261109-v1.json');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 assert.equal(q.actionId,base.actionId);assert.equal(q.value,base.value);
 assert.equal(JSON.stringify(q.roots.map(r=>[r.actionId,r.value,r.realization,r.preparationDebt])),JSON.stringify(candidate.roots));
 assert.equal(q.diagnostics.nativeExecutions,base.native);assert.equal(rows.length,base.native-candidate.native);
 assert.equal(q.analysis.provedFinalEndTaskInputs,rows.length);
}finally{port.close();m.dispose();}
const {cases}=JSON.parse(z.gunzipSync(fs.readFileSync(path.join(__dirname,'r4-data-before-claim-20261109-v1.json.gz'))));
const pairs=cases.filter(c=>c.dataWitness).map(c=>{
 const same=c.beforeEdges.find(x=>x.family==='place_data'&&JSON.stringify(x.steps)===JSON.stringify(c.dataWitness.steps));
 assert(same);assert.equal(same.value,c.value);
 return {index:c.index,steps:same.steps,goal:same.goal,value:same.value,materializedProof:Boolean(c.dataWitness.materializedProof)};
});
assert.equal(pairs.length,44);
const facts={nativeReplays:rows,negativeControls:declined,sameRankDataFirst:pairs};
fs.writeFileSync(process.argv[2],JSON.stringify(facts,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({proved:rows.length,negativeControls:declined,dataFirst:pairs.length}));
