'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),z=require('node:zlib'),{open}=require('./native-late-r3');
const official=require('./v661-r4-full-preflight-20261109-v1.json').checkpoint;
const known=JSON.parse(z.gunzipSync(fs.readFileSync('../candidate-r4-active-task-preview-native-20261109-v1.json.gz'))).rows;
const roots=[{input:'official-r4',root:official},...known];
const report=[];
for(const r of roots){
 const m=open(r.root);
 try{
  const q=m.automatic();
  assert(q.complete);
  const ranking=q.roots.map(x=>[x.actionId,x.value,x.realization,x.preparationDebt]);
  if(r.ranking){
   assert.equal(q.a.actionId,r.actionId);assert.equal(q.value,r.value);
   assert.equal(JSON.stringify(ranking.filter(x=>Number.isFinite(x[1]))),JSON.stringify(r.ranking.filter(x=>Number.isFinite(x[1]))));
  }
  report.push({label:r.input,action:q.a.actionId,value:q.value,native:q.n,ms:q.ms,ranking});
 }finally{m.dispose();}
}
fs.writeFileSync(process.argv[2],JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(report.map(({ranking,...r})=>r)));
