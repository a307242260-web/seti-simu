'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),z=require('node:zlib'),crypto=require('node:crypto');
const {open,seat}=require('./native-late-r3');
const base=require('./r4-end-task-settle-official-profile-20261109-v2.json');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const {cases}=JSON.parse(z.gunzipSync(fs.readFileSync(path.join(__dirname,'r4-data-before-claim-20261109-v1.json.gz'))));
const {dataPairs,endPairs}=require('./r4-active-task-preview-proof-20261109-v2.json');
const proofSet=new Set([...endPairs.filter(x=>x.fullForwardIdentityEqual),...dataPairs.filter(x=>x.equal)].map(x=>x.index));
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const exact=new Map();
for(const c of cases.filter(x=>proofSet.has(x.index))){
 const a=c.beforeEdges.find(x=>x.family==='complete_task').steps[0];
 const end=c.beforeEdges.find(x=>x.family==='end_turn');
 assert(end&&!c.state.session);
 exact.set(sha(c.state.committedState)+':'+a,{index:c.index,
  proof:'experiment-exact-native-order-witness',equivalentTo:c.dataWitness?.steps[0]||end.steps[0],
  kind:c.dataWitness?'data-first':'end-claim'});
}
assert.equal(exact.size,73);
const mode=process.argv[3]||'all',exclusions=[];
globalThis.fixedActiveOrder=(envelope,actionId)=>{
 const found=exact.get(sha(envelope.committedState)+':'+actionId);
 if(!found||mode!=='all'&&found.kind!==mode)return null;
 exclusions.push(found);
 return found;
};
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const js=fs.readFileSync(file,'utf8'),anchor='    function redundantCargoClaim(node, actionId) {';
assert.equal(js.split(anchor).length,2);
mod._compile(js.replace(anchor,anchor+`
      if(node!==openedRoot&&node.status==='stable'&&!nodes.get(node).resourceControl){
        const witnessed=globalThis.fixedActiveOrder(nodes.get(node).envelope,actionId);
        if(witnessed)return witnessed;
      }
`),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);assert(exclusions.length);
 const roots=q.roots.map(r=>[r.actionId,r.value,r.realization,r.preparationDebt]);
 const changed=roots.flatMap((x,i)=>JSON.stringify(x)===JSON.stringify(base.roots[i])?[]:[{before:base.roots[i],after:x}]);
 const facts={mode,complete:true,unresolved:0,action:q.actionId,value:q.value,priorAction:base.action,priorValue:base.value,
  native:q.diagnostics.nativeExecutions,priorNative:base.native,ms:q.rootAndSearchMilliseconds,exclusions,changed};
 fs.writeFileSync(process.argv[2],JSON.stringify(facts,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({...facts,exclusions:exclusions.length}));
}finally{port.close();m.dispose();}
