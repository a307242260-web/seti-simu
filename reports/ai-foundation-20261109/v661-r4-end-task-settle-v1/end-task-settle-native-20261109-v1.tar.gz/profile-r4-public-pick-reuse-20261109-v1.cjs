'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {open,seat}=require('./native-late-r3');
const base=require('./r4-end-task-settle-official-profile-20261109-v2.json');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const js=fs.readFileSync(file,'utf8'),anchor='    function executeCurrent(current) {';
assert.equal(js.split(anchor).length,2);
mod._compile(js.replace(anchor,anchor+`
      const s=loadedEnvelope?.session?.session;
      if(s?.queue?.[0]?.type===scienceSession.EFFECT_TYPES.PICK_CARD&&s.journal.actions[0]?.action?.family==="place_data"
        &&current.family==="choose_card")globalThis.observeR4PublicPick(s,loadedEnvelope,current,knownCards(loadedEnvelope));
`),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const contexts=new Map();
globalThis.observeR4PublicPick=(session,envelope,action,known)=>{
 const s=session.workingState,p=s.players.players.find(p=>p.id===seat);
 const market=s.cards.publicCards.map(c=>c&&known.has(c.id)?c.cardId:c?'opaque':null);
 const slots=session.journal.actions.filter(x=>x.action.family==='choose_target').map(x=>x.action.target.choiceId);
 const input=action.target;
 const offer=input.publicSlotIndex??input.slotIndex??(input.source==='blind'?'blind':input.choiceId);
 const fact=contexts.get(envelope)||{market,slots,credits:p.resources.credits,energy:p.resources.energy,data:p.resources.availableData,
  publicity:p.resources.publicity,score:p.resources.score,heldTasks:p.reservedCards.filter(c=>known.has(c.id)).map(c=>c.cardId),
  knownHand:p.hand.filter(c=>known.has(c.id)).map(c=>c.cardId),offers:[]};
 fact.offers.push(offer);contexts.set(envelope,fact);
};
const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);assert.equal(q.actionId,base.action);
 assert.equal(q.diagnostics.nativeExecutions,base.native);
 const rows=[...contexts.values()], groups=new Map();
 for(const r of rows){
  const key=JSON.stringify(r.market),x=groups.get(key)||{market:r.market,menus:0,submissions:0,offers:{},distinctResources:new Set()};
  x.menus++;x.submissions+=r.offers.length;
  x.distinctResources.add(JSON.stringify([r.credits,r.energy,r.data,r.publicity]));
  for(const o of r.offers)x.offers[o]=(x.offers[o]||0)+1;
  groups.set(key,x);
 }
 const groupsOut=[...groups.values()].map(x=>({...x,distinctResources:x.distinctResources.size})).sort((a,b)=>b.submissions-a.submissions);
 const inputs=rows.reduce((n,r)=>n+r.offers.length,0);
 assert.equal(inputs,base.categories['choose_card|science_domain_pick_card|place_data']);
 const summary={inputs,menus:rows.length,markets:groups.size,menusWithMultipleSubmissions:rows.filter(r=>r.offers.length>1).length,groups:groupsOut,rows};
 fs.writeFileSync(process.argv[2],JSON.stringify(summary,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({...summary,rows:undefined,groups:groupsOut.slice(0,6)}));
}finally{port.close();m.dispose();}
