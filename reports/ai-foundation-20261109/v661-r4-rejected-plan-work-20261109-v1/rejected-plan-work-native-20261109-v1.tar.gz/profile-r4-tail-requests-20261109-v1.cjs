'use strict';
const path=require('node:path'),fs=require('node:fs'),z=require('node:zlib'),assert=require('node:assert/strict'),Module=require('node:module');
const {open,seat}=require('./native-late-r3');
const baseline=require('./r4-chong-queued-tasks-cold-20261109-v3.json');
const {checkpoint:official}=require('./v661-r4-full-preflight-20261109-v1.json');
const teacher=JSON.parse(z.gunzipSync(fs.readFileSync(path.join(__dirname,'candidate-r4-active-task-preview-native-20261109-v1.json.gz')))).rows.filter(r=>r.input>=355);
const p=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(p,module);
mod.filename=p;mod.paths=Module._nodeModulePaths(path.dirname(p));
const s=fs.readFileSync(p,'utf8'),anchor='    function turnTailSummary(node,kind="end-turn") {';
assert.equal(s.split(anchor).length,2);
mod._compile(s.replace(anchor,`    function turnTailSummary(node,kind="end-turn"){
      const hit=turnTailSpecs.get(node)?.has(kind)===true,t=performance.now(),ans=computeTurnTailSummary(node,kind);
      globalThis.noteTailRequest(node,kind,hit,Boolean(ans),performance.now()-t);return ans;
    }
    function computeTurnTailSummary(node,kind) {`),p);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
let cases;
globalThis.noteTailRequest=(node,kind,hit,ans,ms)=>{
 let v=cases.get(node);if(!v){v={};cases.set(node,v);}
 (v[kind]??=[]).push({hit,ans,ms});
};
const result=[];
for(const r of [{input:'official-r4',root:official},...teacher]){
 cases=new Map();
 const m=open(r.root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),r.root);
  const b=baseline.find(x=>x.label===r.input);assert.equal(q.diagnostics.nativeExecutions,b.native);
  assert.equal(JSON.stringify(q.roots.map(x=>[x.actionId,x.value,x.realization,x.preparationDebt])),JSON.stringify(b.ranking));
  const kinds={};
  for(const row of cases.values())for(const [kind,seq] of Object.entries(row)){
   const k=kinds[kind]??={nodes:0,calls:0,rejected:0,repeatRejectedUncached:0,repeatRejectedUncachedMs:0,totalMs:0,changedAnswers:0};
   k.nodes++;k.calls+=seq.length;k.totalMs+=seq.reduce((s,x)=>s+x.ms,0);k.rejected+=seq.filter(x=>!x.ans).length;
   const repeat=seq.slice(1).filter(x=>!x.ans&&!x.hit);k.repeatRejectedUncached+=repeat.length;
   k.repeatRejectedUncachedMs+=repeat.reduce((s,x)=>s+x.ms,0);if(seq.some(x=>x.ans!==seq[0].ans))k.changedAnswers++;
  }
  result.push({input:r.input,kinds});
 }finally{port.close();m.dispose();}
}
fs.writeFileSync(process.argv[2],JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(result));
