'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),Module=require('node:module'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const before='candidate-r4-chong-queued-tasks-v1';
const prior=name=>require(path.join(__dirname,before,'randomizer/game',name));
const oldPlans=prior('ai/local-decision-plans'),oldDemand=prior('ai/resource-demand'),oldEffects=prior('cards/effects');
const opts={};
function replace(file,a,b){(opts[path.resolve(file)]??=[]).push([a,b]);}
replace('randomizer/game/ai/resource-demand.js',
 '    if(state.turn.roundNumber>=4&&Object.values(state.aliens?.aliens||{}).some(slot=>slot.revealed))return null;',
 '    if(state.turn.roundNumber>=4&&Object.values(state.aliens?.aliens||{}).some(slot=>slot.revealed)){globalThis.auditSwap(state,p,committed);return null;}');
replace('randomizer/game/ai/local-decision-plans.js',
 '  return {state:claim,player:r,dataGain,credits};',
 '  const answer={state:claim,player:r,dataGain,credits};if(Object.isFrozen(state))globalThis.auditCargo({state,seatId,cargo},answer);return answer;');
replace('randomizer/game/ai/local-decision-plans.js',
 '  if(Number.isSafeInteger(minimum)&&minimum>p.resources.score||alreadyClaimed)',
 '  if(alreadyClaimed)globalThis.auditQuiet({state,seatId});\n  if(Number.isSafeInteger(minimum)&&minimum>p.resources.score||alreadyClaimed)');
replace('randomizer/game/cards/effects.js','  function hasMatchingTrigger(player, event) {',
 '  function hasMatchingTrigger(player, event) {\n    const result=hasTrigger(player,event);globalThis.auditTrigger(player,event,result);return result;\n  }\n\n  function hasTrigger(player,event) {');
const auditKey=process.env.SETI_AUDIT_GROUPED_CHONG_KEY==='1';
if(auditKey)replace('randomizer/game/ai/analysis-port.js',
 '      return JSON.stringify([cardId,stored.informationBarrier?.code||null,cardKnowledgeKey(stored.envelope),physical]);',
 `      const prefix=[cardId,stored.informationBarrier?.code||null,cardKnowledgeKey(stored.envelope)];
      const result=JSON.stringify([...prefix,physical]);globalThis.auditChongKey(result,()=>JSON.stringify([...prefix,
        forwardIdentity({},status,null,state)]));return result;`);
const nativeLoad=Module._extensions['.js'];
Module._extensions['.js']=function(m,p){
 if(!opts[p])return nativeLoad(m,p);
 let js=fs.readFileSync(p,'utf8');for(const [a,b] of opts[p]){assert.equal(js.split(a).length,2);js=js.replace(a,b);}
 return m._compile(js,p);
};
const {open,seat}=require('./native-late-r3');
const {checkpoint:official}=require('./v661-r4-full-preflight-20261109-v1.json');
const teacher=JSON.parse(z.gunzipSync(fs.readFileSync(path.join(__dirname,'candidate-r4-active-task-preview-native-20261109-v1.json.gz')))).rows;
const baseline=require('./r4-chong-queued-tasks-cold-20261109-v3.json');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
let stats,oldToNew,newToOld;
globalThis.auditSwap=(s,p,c)=>{assert.equal(oldDemand.incomeSwapPlan(s,p,c),null);stats.swap++;};
globalThis.auditCargo=(args,result)=>{assert.deepEqual(result,oldPlans.previewKnownCargoClaim(args));stats.cargo++;};
globalThis.auditQuiet=(args)=>{assert.deepEqual(oldPlans.quietEndCompletion(args),{available:true,netGain:0,purposeDelta:0,requiredNativeInputs:1,markedTiles:[]});stats.quiet++;};
globalThis.auditTrigger=(player,event,seen)=>{assert.equal(seen,Boolean(oldEffects.collectMatchingTriggers(structuredClone(player),event).length));stats.trigger++;if(seen)stats.positiveTrigger++;};
globalThis.auditChongKey=(key,exact)=>{
 const prior=exact();if(oldToNew.has(prior))assert.equal(oldToNew.get(prior),key);if(newToOld.has(key))assert.equal(newToOld.get(key),prior);
 oldToNew.set(prior,key);newToOld.set(key,prior);stats.chongKey++;
};
const testEffects=require(path.resolve('randomizer/game/cards/effects.js'));
stats={trigger:0,positiveTrigger:0};
const sample={id:'probe-trigger-fixture',cardId:'b_44.webp',set:'basic'};
const event={type:'visitPlanet',planetId:'venus'};
const model=testEffects.getCardModel(sample),venus=model.triggers.find(t=>t.event.includePlanetIds.includes('venus'));
for(const [label,state,change,want] of [
 ['new card',undefined,{},true],['stale model',{modelCardId:'b_46.webp',consumedTriggerIds:[venus.id]}, {},true],
 ['already consumed',{modelCardId:sample.cardId,consumedTriggerIds:[venus.id]}, {},false],
 ['wrong planet',undefined,{planetId:'earth'},false],['own effect',undefined,{sourceCardInstanceId:sample.id},false],
]){
 const card=Object.freeze({...sample,...(state?{cardEffectState:Object.freeze(state)}:{})});
 const player=Object.freeze({reservedCards:Object.freeze([card])}),old=JSON.stringify(player);
 assert.equal(testEffects.hasMatchingTrigger(player,{...event,...change}),want,label);
 assert.equal(JSON.stringify(player),old,label);
}
const triggerControls={tests:stats.trigger,positive:stats.positiveTrigger};
const results=[];
for(const r of [{input:'official-r4',root:official},...teacher]){
 stats={swap:0,cargo:0,quiet:0,trigger:0,positiveTrigger:0,chongKey:0};oldToNew=new Map();newToOld=new Map();
 const m=open(r.root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),r.root);
  const old=baseline.find(x=>x.label===r.input);assert.equal(q.diagnostics.nativeExecutions,old.native);
  const graph=crypto.createHash('sha256').update(JSON.stringify(q.lines,(k,v)=>k==='routingNodes'?undefined:v)).digest('hex');
  assert.equal(graph,old.graph);assert.equal(q.actionId,old.action);
  assert.equal(JSON.stringify(q.roots.map(x=>[x.actionId,x.value,x.realization,x.preparationDebt])),JSON.stringify(old.ranking));
  results.push({input:r.input,...stats,distinctChongKeys:oldToNew.size,newMaterializations:q.analysis.chongClaimKeyMaterializations??0,graph});
 }finally{p.close();m.dispose();}
}
const totals=Object.fromEntries(['swap','cargo','quiet','trigger','positiveTrigger','chongKey','distinctChongKeys','newMaterializations'].map(k=>[k,results.reduce((n,x)=>n+x[k],0)]));
assert(totals.swap&&totals.cargo&&totals.quiet&&totals.trigger&&(!auditKey||totals.chongKey));
fs.writeFileSync(process.argv[2],JSON.stringify({totals,triggerControls,results},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({totals,triggerControls,results}));
