'use strict';
const assert=require('node:assert/strict'), fs=require('node:fs'), path=require('node:path'), z=require('node:zlib'), Module=require('node:module');
const {isDeepStrictEqual}=require('node:util'), {createHash}=require('node:crypto'), {open,seat}=require('./native-late-r3');
const load=file=>require(path.resolve(file));
const read=file=>JSON.parse(z.gunzipSync(fs.readFileSync(path.join(__dirname,file))));
const file=path.resolve('randomizer/game/ai/analysis-port.js'), mod=new Module(file,module);mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const code=fs.readFileSync(file,'utf8'), hook='      return boundary;\n    }\n\n    function quietScanTracePlan';assert.equal(code.split(hook).length,2);
mod._compile(code.replace(hook,'      globalThis.auditPeek({node, actionId, boundary, stored, expand, valueObservation});\n'+hook),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=load('randomizer/game/ai/search-agent');
const {createStateValueEvaluator}=load('randomizer/game/ai/state-value');
const evaluate=createStateValueEvaluator(seat), results=[];
let steps, nodes;
globalThis.auditPeek=({node,actionId,boundary,stored,expand,valueObservation})=>{
  const native=expand(node,actionId);
  assert.equal(native.status,'information-barrier');
  assert.equal(native.boundary,boundary.boundary);
  assert.deepEqual(native.legalActions,[]);
  const before=valueObservation(boundary),after=valueObservation(native);
  for(const k of Object.keys(before))assert(isDeepStrictEqual(before[k],after[k]),`${k} ${stored.informationBarrier?.code} ${actionId}`);
  assert.deepEqual(boundary.observation,native.observation);
  assert.deepEqual(evaluate.details(before),evaluate.details(after));
  const score=evaluate.details(after);
  if(!nodes.has(node))nodes.set(node,nodes.size);
  const plan=node.legalActions.find(a=>a.actionId===actionId);
  steps.push({source:nodes.get(node),planet:plan.target.planetId,priorBarrier:stored.informationBarrier?.code||null,
    sourceFamily:stored.envelope.session?.session?.journal?.actions?.[0]?.action?.family,value:score.value,
    debt:score.purposePreparationDebt,purpose:score.unrealizedPurposeValue,
    visibleBoundaryKey:createHash('sha256').update(JSON.stringify(after)).digest('hex')});
};
const before=read('candidate-chong-trace-reward-native-20261109-v2.json.gz'), after=read(process.argv[2]);
for(const ref of after.rows){
 const old=before.rows.find(x=>x.input===ref.input);
 const signature=r=>[r.actionId,r.value,r.ranking,r.quotes,r.root];
 assert.deepEqual(signature(old),signature(ref));
 if(ref.input<355)continue;
 const m=open(ref.root), port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try {
  steps=[];nodes=new Map();
  const s=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(s.complete&&!s.unresolved.length);
  assert.deepEqual(m.save(),ref.root);
  assert.equal(steps.length,old.native-ref.native);
  assert.equal(steps.length,nodes.size*2);
  assert.equal(s.diagnostics.nativeExecutions,old.native);
  const byScope=new Map();
  for(const step of steps.filter(s=>s.planet==='jupiter')) {
    const key=step.visibleBoundaryKey, scope=byScope.get(key)||{end_turn:0,complete_task:0};
    scope[step.sourceFamily]++;byScope.set(key,scope);
  }
  const matchingActiveAndEnd=[...byScope.values()].reduce((n,s)=>n+Math.min(s.end_turn,s.complete_task),0);
  results.push({input:ref.input,before:old.native,after:ref.native,oldMs:old.ms,newMs:ref.ms,sources:nodes.size,replayed:steps.length,matchingActiveAndEnd,steps});
 } finally {port.close();m.dispose();}
}
const ready=read('r4-chong-trace-ready-20261109-v1.json.gz').direct;
const m=open(ready.envelope);
try {
 m.apply(ready.action);const before=m.save();
 const known=structuredClone(before);
 const revealOne=s=>{const a=s.aliens.chong;const id=a.planetFossilIds.jupiter[0];a.fossilsById[id].visibleToPlayerIds=[seat];};
 const committed=JSON.parse(known.committedState);revealOne(committed);known.committedState=JSON.stringify(committed);
 revealOne(known.session.session.baseState);revealOne(known.session.session.workingState);
 m.restore(known);
 const port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try {
  const root=port.openRoot(), j=root.legalActions.find(a=>a.target.planetId==='jupiter'), s=root.legalActions.find(a=>a.target.planetId==='saturn');
  assert.equal(port.chongTaskPeekBoundary(root,j.actionId),null);
  const leaf=port.chongTaskPeekBoundary(root,s.actionId);
  assert.equal(leaf.status,'information-barrier');
  assert.throws(()=>port.expand(leaf,s.actionId),/BOUNDARY_CLOSED/);
  assert.deepEqual(m.save(),known);
 }finally{port.close();}
}finally{m.dispose();}
fs.writeFileSync(process.argv[3],JSON.stringify({results,knownPlanetNotShortcutted:true,unchangedRootAndRng:true},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(results.map(({steps,...row})=>row)));
