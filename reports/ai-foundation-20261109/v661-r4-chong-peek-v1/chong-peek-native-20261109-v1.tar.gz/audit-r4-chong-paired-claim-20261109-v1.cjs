'use strict';
const assert=require('node:assert/strict'), fs=require('node:fs'), path=require('node:path'), z=require('node:zlib'), Module=require('node:module');
const {isDeepStrictEqual}=require('node:util'), {open,seat}=require('./native-late-r3');
const load=file=>require(path.resolve(file)), read=file=>JSON.parse(z.gunzipSync(fs.readFileSync(path.join(__dirname,file))));
const file=path.resolve('randomizer/game/ai/analysis-port.js'), mod=new Module(file,module);mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const code=fs.readFileSync(file,'utf8'), hook='      return chongDirectClaims.get(chongClaimKey(stored, task.cardInstanceId)) || null;';assert.equal(code.split(hook).length,2);
mod._compile(code.replace(hook,`      const match = chongDirectClaims.get(chongClaimKey(stored, task.cardInstanceId)) || null;
      if (match) globalThis.auditPair({node, actionId, match, expand, valueObservation, prior:stored.informationBarrier?.code});
      return match;`),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=load('randomizer/game/ai/search-agent');
const evaluate=load('randomizer/game/ai/state-value').createStateValueEvaluator(seat);
const results=[];let steps;
globalThis.auditPair=({node,actionId,match,expand,valueObservation,prior})=>{
 const confirm=expand(node,actionId);
 assert.equal(confirm.status,'decision');
 assert.deepEqual(confirm.legalActions.map(a=>a.target.planetId),['jupiter','saturn']);
 const shared=valueObservation(match), proof=evaluate.details(shared);
 for(const action of confirm.legalActions){
  const native=expand(confirm,action.actionId);
  assert.equal(native.status,match.status);assert.equal(native.boundary,match.boundary);assert.deepEqual(native.legalActions,[]);
  const after=valueObservation(native);
  for(const k of Object.keys(shared))assert(isDeepStrictEqual(shared[k],after[k]),`${k} ${prior} ${actionId}`);
  assert.deepEqual(match.observation,native.observation);
  assert.deepEqual(proof,evaluate.details(after));
 }
 steps.push({value:proof.value,prepDebt:proof.purposePreparationDebt,purpose:proof.unrealizedPurposeValue,priorBarrier:prior});
};
const before=read('candidate-chong-peek-boundary-native-20261109-v2.json.gz'), after=read(process.argv[2]);
for(const row of after.rows){
 const old=before.rows.find(r=>r.input===row.input), key=r=>[r.root,r.actionId,r.value,r.ranking,r.quotes];assert.deepEqual(key(old),key(row));
 if(row.input<355)continue;
 const m=open(row.root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  steps=[];const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),row.root);
  assert.equal(steps.length,old.native-row.native);
  assert.equal(q.diagnostics.nativeExecutions,row.native+steps.length*3);
  results.push({input:row.input,before:old.native,after:row.native,beforeMs:old.ms,afterMs:row.ms,verifiedPairs:steps.length,replayed:steps.length*3,steps});
 }finally{port.close();m.dispose();}
}
fs.writeFileSync(process.argv[3],JSON.stringify({results,exactRankingAndRootRng:true},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(results.map(({steps,...row})=>row)));
