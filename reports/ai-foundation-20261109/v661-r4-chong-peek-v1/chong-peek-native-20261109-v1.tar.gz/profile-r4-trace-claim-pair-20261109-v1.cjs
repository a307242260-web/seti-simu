'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const {createHash}=require('node:crypto'),{open,seat}=require('./native-late-r3');
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const code=fs.readFileSync(file,'utf8'),hook='      const head = envelope.session?.session?.queue?.[0], effect = head?.payload?.cardEffect;';assert.equal(code.split(hook).length,2);
mod._compile(code.replace(hook,hook+`
      if(head?.type==='residual_chong_task_fossil'&&!head.payload?.planetId&&source&&sourceAction){
        const task=source.envelope.session?.session?.queue?.[0]?.payload;
        const mode=sourceAction.family==='complete_task'?'active':sourceAction.target?.choiceId?.startsWith('confirm:chong_task:')?'end':null;
        if(mode){
          const key=(envelope)=>forwardIdentity({committedState:envelope.committedState},'chong-peek-state-only',null,readIdentityState(envelope));
          globalThis.tracePair({mode,card:sourceAction.target?.cardInstanceId||task?.cardInstanceId,
            before:key(source.envelope),after:key(envelope),barrier:source.informationBarrier?.code||null});
        }
      }
`),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
let samples=[];
const hash=text=>createHash('sha256').update(text).digest('hex');
globalThis.tracePair=x=>samples.push({...x,before:hash(x.before),after:hash(x.after)});
const roots=JSON.parse(z.gunzipSync(fs.readFileSync(process.argv[2]))).rows.filter(r=>r.input>=355), results=[];
for(const r of roots){
 const m=open(r.root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  samples=[];const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length);assert.equal(q.diagnostics.nativeExecutions,r.native);assert.deepEqual(m.save(),r.root);
  const pair=fields=>{
    const by=new Map();for(const x of samples){const k=JSON.stringify(fields.map(f=>x[f])),counts=by.get(k)||{active:0,end:0};counts[x.mode]++;by.set(k,counts);}
    return [...by.values()].reduce((n,x)=>n+Math.min(x.active,x.end),0);
  };
  const facts={input:r.input,active:samples.filter(x=>x.mode==='active').length,end:samples.filter(x=>x.mode==='end').length,
    exactPreClaimPairs:pair(['card','barrier','before']),exactPostClaimPairs:pair(['card','barrier','after']),exactPairsAtBothEnds:pair(['card','barrier','before','after'])};
  console.log(JSON.stringify(facts));results.push({...facts,samples});
 }finally{p.close();m.dispose();}
}
fs.writeFileSync(process.argv[3],JSON.stringify(results,null,2)+'\n',{flag:'wx'});
