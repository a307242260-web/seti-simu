'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,runCases,short}=require('./controlled-r3'),path=require('node:path');
const route=require(path.resolve('randomizer/game/ai/probe-capital'));
const [dir,out]=process.argv.slice(2),O=dir+'/adhoc-v655-20261109';
const W=readZ(O+'/v655-standard-r3-analysis-scan-windows-20261109-v1.json.gz'),origin=W.snapshots[211].envelope;
function place({act},slot){act('place_data');act('choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');}
const tech=(h,tile,slot)=>{h.act('research_tech');h.act('choose_target',a=>a.target.tileId===tile&&(slot===undefined||slot===a.target.blueSlot));};
const task=h=>h.act('complete_task',a=>a.summary==='完成 dlc_9.png');
const id=(h,card)=>h.m.player().hand.find(c=>c.cardId===card)?.id;
const goal=(h,planet)=>route.requirements(route.factsFromState(h.m.state(),h.m.player())).find(g=>g.planetId===planet&&g.endpointFamily==='land'&&!g.satelliteId);
function move(h,{deltaX,deltaY},pay){
 h.act('move',a=>a.target.deltaX===deltaX&&a.target.deltaY===deltaY);
 const c=id(h,pay);assert(c,pay);
 h.act('choose_payment',a=>a.target.cardIds?.length===1&&a.target.cardIds[0]===c);
}
function throughTransport(h,{dx=0,dy=1,fund='b_16.webp',pair=['amiba_9.webp','dlc_25.png'],planet='saturn',stop='transport',orange='dlc_20.png'}={}){
 const {m,act,cut,take}=h;
 act('scan');act('choose_target',a=>a.target.nebulaId==='sector-3-a');
 act('choose_card',a=>a.target.nebulaId==='sector-3-a'&&a.summary.startsWith('dlc_24.png'));
 act('choose_target',a=>a.target.traceType==='pink'&&a.target.alienSlotId===2);
 act('accept_optional_effect',a=>a.summary==='结算 amiba_0.webp');
 task(h);act('end_turn');cut('revealed');
 tech(h,'orange1');take(m.pick(orange));act('end_turn');cut('orange-launched');
 move(h,{deltaX:dx,deltaY:dy},orange);cut('move-publicity');
 take(m.corner(fund));tech(h,'blue1',3);place(h);place(h);place(h,3);
 cut('before-analysis');act('end_turn');
 act('analyze');act('choose_target',a=>a.target.traceType==='blue'&&a.target.alienSlotId===2&&a.target.position===9);
 act('choose_card',a=>a.target.source==='display'&&a.target.cardIndex===9);
 cut('transport-known');act('end_turn');
 if(stop==='known')return;
 act('quick_trade',a=>a.target.tradeId==='cards-for-credit');
 const ids=pair.map(x=>id(h,x));assert(ids.every(Boolean));
 for(const i of ids)act('choose_payment',a=>a.target.cardInstanceId===i);
 act('choose_payment',a=>a.target.confirm===true);
 const g=goal(h,planet);cut('funded');assert(g,'no known legal goal');
 console.log('ROUTE',dx,dy,planet,JSON.stringify(g.route));
 assert(g.route.path.length<=2,'route longer than known two move cards'); 
 for(const [i,d] of g.route.path.entries())move(h,d,['chong_7.webp','chong_2.webp'][i]);
 cut('at-landing');take(m.play('chong_9.webp'));
 act('choose_target',a=>a.target.planetId===planet&&!a.target.satelliteId);
 cut('landing-resolution');
}
const cases=[
 ['baseline',()=>{}],
 ['native-known-outward',h=>throughTransport(h,{stop:'known'})],
 ...[[0,1],[1,0],[-1,0]].flatMap(([dx,dy])=>['saturn','jupiter'].map(planet=>[dx+':'+dy+':'+planet,h=>throughTransport(h,dx?{dx,dy,planet,fund:'amiba_9.webp',pair:['b_16.webp','dlc_25.png']}:{dx,dy,planet})])),
 ['saturn-keep-dlc25',h=>throughTransport(h,{fund:'dlc_25.png',pair:['amiba_9.webp','b_16.webp']})]
];
writeZ(out,{scope:'Original seed: reveal from exact scan, spend the sector task once, select already known movement and use only public transport card after actual native reveal. Route and total movement costs verified after solar rotation.',origin,...runCases(origin,cases)});
