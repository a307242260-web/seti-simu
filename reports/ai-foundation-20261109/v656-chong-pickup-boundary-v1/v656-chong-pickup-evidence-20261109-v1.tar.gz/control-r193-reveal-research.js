'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,runCases,open,short}=require('./controlled-r3');
const [source,out]=process.argv.slice(2),rev=readZ(source).rows.find(r=>r.label==='early-scan-second-species'),m=open(rev.start);
let origin;
try{
 for(const {action:a} of rev.accepted){if(a.phase==='main')break;m.apply(a);}
 origin=m.save();assert.equal(short(m).chongOffer,9);assert.equal(short(m).wallet[1],1);
}finally{m.dispose();}
function research({m,take,act,cut},tile,card=null){
 act('research_tech');act('choose_target',a=>a.target.tileId===tile&&(!a.target.blueSlot||a.target.blueSlot===3));
 if(card)take(m.pick(card));
 cut(tile);
}
function produce(h,card,swapOut='amiba_9.webp'){
 const {m,take,act,cut}=h;research(h,'orange1',card);act('end_turn');
 const swapIn=card==='dlc_20.png'?'dlc_17.png':'dlc_20.png';
 take(...m.swap(swapOut,swapIn));take(m.play('dlc_20.png'));
 const id=m.player().hand.find(x=>x.cardId==='dlc_17.png').id;
 act('choose_card',a=>a.target.cardInstanceId===id);cut('three-data');
}
function prepareBlue(h,card,variant){
 const {m,take,act,cut}=h;
 produce(h,card,variant==='retain-amiba'?'chong_2.webp':'amiba_9.webp');
 if(variant==='take-market'){
  act('place_data');act('choose_target',a=>a.target.blueSlot===2);take(m.pick('dlc_25.png'));
 }
 act('end_turn');
 if(variant==='retain-amiba')take(m.corner('amiba_9.webp'));
 else {
  act('move',a=>a.payload.requiredMovePoints===1&&a.target.deltaY===1&&a.target.deltaX===0);
  const payer=m.player().hand.find(x=>x.cardId==='chong_2.webp').id;
  act('choose_payment',a=>a.target.cardIds?.length===1&&a.target.cardIds[0]===payer);
 }
 cut('before-blue');
 research(h,'blue1');
}
const cases=[
 ['current',()=>{}],
 ...['dlc_20.png','dlc_17.png','dlc_25.png'].map(card=>['orange-'+card,h=>research(h,'orange1',card)]),
 ['blue1-first',h=>research(h,'blue1')],
 ...['dlc_20.png','dlc_17.png'].flatMap(card=>[
  ['triple-'+card,h=>produce(h,card)],
  ['triple-blue-'+card,h=>prepareBlue(h,card,'move')]
 ]),
 ['triple-market-then-blue',h=>prepareBlue(h,'dlc_20.png','take-market')],
 ['triple-corner-blue',h=>prepareBlue(h,'dlc_20.png','retain-amiba')]
];
writeZ(out,{scope:'After the actual earlier-analysis alternative has natively revealed Chong9, test free launch, known DLC20 triple data, and a paid blue research. No invisible new offer used in a prescribed prefix.',origin,...runCases(origin,cases)});
