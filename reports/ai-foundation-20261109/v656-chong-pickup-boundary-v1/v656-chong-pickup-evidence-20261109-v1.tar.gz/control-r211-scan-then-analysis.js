'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,runCases,short}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),O=dir+'/adhoc-v655-20261109';
const W=readZ(O+'/v655-standard-r3-analysis-scan-windows-20261109-v1.json.gz'),origin=W.snapshots[211].envelope;
function place({act},slot){act('place_data');act('choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');}
const tech=(h,tile,slot)=>{h.act('research_tech');h.act('choose_target',a=>a.target.tileId===tile&&(slot===undefined||slot===a.target.blueSlot));};
const task=h=>h.act('complete_task',a=>a.summary==='完成 dlc_9.png');
function reveal(h,opt={}){
 const {m,act,cut}=h;
 act('scan');act('choose_target',a=>a.target.nebulaId==='sector-3-a');
 act('choose_card',a=>a.target.nebulaId==='sector-3-a'&&a.summary.startsWith('dlc_24.png'));
 act('choose_target',a=>a.target.traceType==='pink'&&a.target.alienSlotId===2);
 act('accept_optional_effect',a=>a.summary==='结算 amiba_0.webp');
 cut('after-scan');
 if(opt.task==='now')task(h);
 if(opt.computer){place(h);place(h);}
 if(opt.defer) {
  act('end_turn');cut('after-reveal');return;
 }
 act('end_turn');cut('after-reveal');
 if(opt.tech){
  tech(h,opt.tech,opt.tech==='blue1'?3:undefined);
  if(opt.card)h.take(m.pick(opt.card));
  if(opt.useCash){place(h,3);}
  if(opt.task==='after')task(h);
  act('end_turn');cut('after-research');
 }
 act('analyze');cut('known-analysis-choices');
 act('choose_target',a=>a.target.traceType==='blue'&&a.target.alienSlotId===opt.species&&a.target.position===opt.position);
 cut('after-blue');
 if(opt.takeOffer){
  const index=opt.species===2?short(m).chongOffer:short(m).amibaOffer;
  assert(Number.isInteger(index));
  act('choose_card',a=>a.target.source==='display'&&a.target.cardIndex===index);
  cut('after-known-offer');
 }
}
const cases=[['exact',()=>{}],['reveal-untouched',h=>reveal(h,{defer:true})],['reveal-computer',h=>reveal(h,{defer:true,computer:true})]];
for (const [species,position,takeOffer] of [[2,9,true],[1,3,true],[2,6,false]]) {
 for (const t of ['now','later','after']) {
  const opt={species,position,takeOffer,computer:true,task:t};
  if(t==='after') Object.assign(opt,{tech:'orange1',card:'dlc_20.png'});
  cases.push([[species,position,t].join(':'),h=>reveal(h,opt)]);
 }
}
cases.push(['blue1-cash-then-chong9',h=>reveal(h,{species:2,position:9,takeOffer:true,computer:true,task:'after',tech:'blue1',useCash:true})]);
writeZ(out,{scope:'From the standard exact scan root, keep its actual scan and market card, assign the pink mark to species 2, and test the known blue trace immediately, or after one already affordable research. The offered transport card and successor are read from public Native observations only.',origin,...runCases(origin,cases)});
