'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,runCases,short}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),O=dir+'/adhoc-v655-20261109';
const W=readZ(O+'/v655-standard-r3-analysis-scan-windows-20261109-v1.json.gz'),origin=W.snapshots[193].envelope;
function place({act},slot){act('place_data');act('choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');}
function knownPrep(h,opts){
 const {m,take,act,cut}=h;
 act('quick_trade',a=>a.target.tradeId==='publicity-for-card');take(m.pick('dlc_25.png'));
 cut('DLC17-now-public');assert(short(m).market.includes('dlc_17.png'));
 take(...m.swap(opts.swapOut,'dlc_17.png'));
 act('research_tech');act('choose_target',a=>a.target.tileId==='purple1');
 for(let i=1;i<=4;i++)place(h);
 act('choose_card',a=>a.summary==='收入 '+opts.income);
 take(m.corner('amiba_7.webp'));take(m.corner('dlc_17.png'));
 place(h);place(h);place(h,1);cut('seven-data-used');act('end_turn');
 assert.equal(short(m).wallet[2],2);
 act('analyze');act('choose_target',a=>a.target.choiceId==='trace:1:blue:amiba:'+opts.blue);
 if(opts.blue===3)act('choose_card',a=>a.target.source==='display'&&a.target.cardIndex===5);
 cut('paid-scan-ready');act('end_turn');
 act('scan');cut('native-scan');
 act('choose_target',a=>a.target.nebulaId==='sector-3-a');
 act('choose_card',a=>a.target.nebulaId==='sector-3-a'&&a.summary.startsWith('dlc_24.png'));
 cut('pink-choice');
 if(opts.pink==='chong')act('choose_target',a=>a.target.traceType==='pink'&&a.target.alienSlotId===2);
 else act('choose_target',a=>a.target.choiceId==='trace:1:pink:amiba:'+opts.pink);
}
const cases=[];
for(const [swapOut,income] of [['b_16.webp','amiba_1.webp'],['amiba_1.webp','b_16.webp'],['amiba_9.webp','amiba_1.webp']])
 for(const [blue,pink] of [[3,3],[3,'chong'],[2,3]]) {
  const args={swapOut,income,blue,pink};
  cases.push([[swapOut,income,blue,pink].join(':'),h=>knownPrep(h,args)]);
 }
writeZ(out,{scope:'The current public DLC25 is bought with publicity to reveal the next market offer; only then may Deep Space exchange for DLC17. Its extra data pays for restoring blue energy while keeping the full computer and exact Kepler scan without a preceding rotation.',origin,...runCases(origin,cases)});
