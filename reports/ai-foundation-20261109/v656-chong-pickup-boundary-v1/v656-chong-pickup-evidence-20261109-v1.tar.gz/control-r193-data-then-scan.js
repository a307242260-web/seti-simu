'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),{readZ,writeZ,runCases,short}=require('./controlled-r3');
const [source,formal,out]=process.argv.slice(2),origin=readZ(source).snapshots[193].envelope;
const record=JSON.parse(fs.readFileSync(formal+'/reports/research/6ff3b826.6b5ba279.quick-400.json')),save=JSON.parse(fs.readFileSync(formal+'/'+record.savePath));
function reachDlc20({m,take,act,cut},swapOut){
 for(let i=193;i<=208;i++)take(m.apply(save.replaySteps[i-1].action));
 take(m.pick('dlc_20.png'));act('end_turn');cut('known-market-after-pick');
 const before=short(m);assert.equal(before.wallet[1],1);assert.equal(before.wallet[2],2);
 take(...m.swap(swapOut,'dlc_17.png'));take(m.play('dlc_20.png'));
 act('choose_card',a=>a.target.cardInstanceId===m.player().hand.find(c=>c.cardId==='dlc_17.png').id);
 cut('data-from-dlc20');assert.equal(short(m).wallet[4],3);
}
function blue(h,swapOut){
 const {m,act,cut}=h;
 reachDlc20(h,swapOut);act('end_turn');
 act('research_tech');act('choose_target',a=>a.target.tileId==='blue1'&&a.target.blueSlot===3);
 for(const slot of [5,6]){
  act('place_data');act('choose_target',a=>a.target.target==='computer');
  assert.equal(short(m).computer.at(-1),slot);
 }
 act('place_data');act('choose_target',a=>a.target.blueSlot===3);
 act('end_turn');cut('analysis-ready');assert.deepEqual(short(m).wallet.slice(1,3),[1,2]);
}
function analyze(h,swapOut,blueChoice,scan=false){
 const {m,act,cut}=h;blue(h,swapOut);
 act('analyze');act('choose_target',a=>a.target.choiceId==='trace:1:blue:amiba:'+blueChoice);
 if(m.c.inspect().session)act('choose_card',a=>a.target.source==='display'&&a.target.cardIndex===5);
 cut('analysis-paid-scan-ready');
 if(scan){act('end_turn');act('scan');cut('native-scan');}
}
const cases=[['actual',()=>{}],
 ...['b_16.webp','amiba_9.webp'].flatMap(s=>[
 [s+'-data',h=>reachDlc20(h,s)],
 [s+'-blue-cash',h=>blue(h,s)],
 [s+'-analyze2',h=>analyze(h,s,2)],
 [s+'-analyze3',h=>analyze(h,s,3)],
 [s+'-analyze3-scan',h=>analyze(h,s,3,true)]
 ])];
writeZ(out,{scope:'Known market DLC20 selected at blue3, then only newly public DLC17 used as triple data. Blue1 replenishes cash for a paid scan after the second analysis, without discarding another card for energy.',origin,...runCases(origin,cases)});
