'use strict';
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [source,out]=process.argv.slice(2),origin=readZ(source).snapshots[186].envelope;
function earlier({m,take,act,cut},choice,follow=true){
 act('analyze');act('choose_target',a=>a.target.choiceId===choice);
 if(m.c.inspect().session)act('choose_card',a=>a.target.source==='display'&&a.target.cardIndex===7);
 cut('after-analysis');
 if(!follow)return;
 act('end_turn');take(m.play('amiba_3.webp'));act('choose_target',a=>a.target.traceType==='yellow'&&a.target.position===1);act('end_turn');cut('after-amiba');
}
const cases=[['current',()=>{}],...[2,3,4].flatMap(pos=>[
 ['analysis-blue'+pos,h=>earlier(h,'trace:1:blue:amiba:'+pos,false)],
 ['analysis-blue'+pos+'-then-amiba',h=>earlier(h,'trace:1:blue:amiba:'+pos)]
]),['analysis-slot2-then-amiba',h=>earlier(h,'trace:2:blue')]];
writeZ(out,{scope:'Reorder first analysis and known Amiba3 at actual step 186; each named blue target, no new hidden cards selected before reveal.',origin,...runCases(origin,cases)});
