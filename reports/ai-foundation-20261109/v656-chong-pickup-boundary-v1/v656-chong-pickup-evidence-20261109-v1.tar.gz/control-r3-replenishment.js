'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,runCases,short}=require('./controlled-r3');
const [dir,out]=process.argv.slice(2),O=dir+'/adhoc-v655-20261109',W=readZ(O+'/v655-standard-r3-analysis-scan-windows-20261109-v1.json.gz');
const early=readZ(O+'/v655-r193-earlier-analysis-20261109-v1.json.gz').rows.find(r=>r.label==='earlier-analysis-blue3');
const research=(h,tile,slot)=>{h.act('research_tech');h.act('choose_target',a=>a.target.tileId===tile&&(slot===undefined||a.target.blueSlot===slot));};
const place=(h,slot)=>{h.act('place_data');h.act('choose_target',a=>slot?a.target.blueSlot===slot:a.target.target==='computer');};
const end=h=>h.act('end_turn');
const card=(h,id)=>h.take(h.m.pick(id));
const corner=(h,id)=>h.take(h.m.corner(id));
const swap=(h,a,b)=>h.take(...h.m.swap(a,b));
const analyze=(h,choice)=>{h.act('analyze');h.act('choose_target',a=>a.target.choiceId==='trace:1:blue:amiba:'+choice);};
const play=(h,id)=>h.take(h.m.play(id));
function exactScan(h,cardId='dlc_24.png'){
 h.act('scan');h.cut('native-scan');
 h.act('choose_target',a=>a.target.nebulaId==='sector-3-a');
 h.act('choose_card',a=>a.target.nebulaId==='sector-3-a'&&a.summary.startsWith(cardId));
}
function earlyPaid(h){
 swap(h,'b_16.webp','dlc_25.png');
 h.act('quick_trade',a=>a.target.tradeId==='publicity-for-card');card(h,'dlc_17.png');
 research(h,'purple1');
 for(let i=1;i<=4;i++)place(h);
 h.act('choose_card',a=>a.summary==='收入 amiba_1.webp');
 corner(h,'amiba_7.webp');corner(h,'dlc_17.png');
 place(h);place(h);place(h,1);h.cut('seven-data-used');end(h);
 analyze(h,3);h.act('choose_card',a=>a.target.source==='display'&&a.target.cardIndex===5);
 h.cut('matched-scan-wallet');end(h);exactScan(h);
}
function throughBlue(h,{swapOut,discard,blueChoice,phase}){
 research(h,'orange1');card(h,'dlc_17.png');
 swap(h,swapOut,'dlc_20.png');end(h);
 corner(h,'amiba_9.webp');corner(h,discard);
 assert(short(h.m).wallet[3]>=6);
 research(h,'blue1',3);place(h);place(h);place(h,3);
 h.cut('funded-second-analysis');end(h);
 if(phase==='before'){
  play(h,'dlc_20.png');
  h.act('choose_card',a=>a.target.cardInstanceId===h.m.player().hand.find(c=>c.cardId==='dlc_17.png').id);
  h.cut('triple-before');return;
 }
 analyze(h,blueChoice);
 if(blueChoice===3)h.act('choose_card',a=>a.target.source==='display'&&a.target.cardIndex===2);
 end(h);
 play(h,'dlc_20.png');
 h.act('choose_card',a=>a.target.cardInstanceId===h.m.player().hand.find(c=>c.cardId==='dlc_17.png').id);
 h.cut('triple-after');
}
const out193=runCases(W.snapshots[193].envelope,[['early-paid-scan-preserve-offer',earlyPaid]]);
const outEarly=runCases(early.start,['sector-1-a','sector-2-a'].map(id=>['b16-'+id,h=>{
 end(h);play(h,'b_16.webp');h.act('choose_target',a=>a.target.skip);h.cut('b16-native-scan');
 h.act('choose_target',a=>a.target.nebulaId===id);
}]));
const out219=runCases(W.snapshots[219].envelope,[
 ['baseline',()=>{}],
 ...['before','after'].flatMap(phase=>[
 ['retain-amiba5-'+phase,h=>throughBlue(h,{swapOut:'b_16.webp',discard:'dlc_25.png',blueChoice:3,phase})],
 ['retain-energy-income-'+phase,h=>throughBlue(h,{swapOut:'amiba_5.webp',discard:'b_16.webp',blueChoice:3,phase})]
 ])
]);
writeZ(out,{scope:'Known card and cash controls at exact V655 roots. On the early-analysis alternative, test the native blue-card scan; on the actual roots, test acquiring one more data before the same Kepler scan or buying three after analysis.',sources:{s193:W.snapshots[193].envelope,earlyBlue3:early.start,s219:W.snapshots[219].envelope},out193,outEarly,out219});
