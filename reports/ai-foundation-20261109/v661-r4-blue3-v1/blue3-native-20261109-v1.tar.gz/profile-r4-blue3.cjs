'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const [source,out]=process.argv.slice(2),{open,seat}=require('./native-late-r3');
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const hook='    function executeCurrent(current) {',js=fs.readFileSync(file,'utf8');assert.equal(js.split(hook).length,2);
mod._compile(js.replace(hook,hook+'\n      globalThis.measureR4Pending(current,loadedEnvelope?.session?.session);'),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const rows=[],data=require(path.resolve('randomizer/game/data')),chong=require(path.resolve('randomizer/game/aliens/chong')),fx=require(path.resolve('randomizer/game/cards/effects'));
let counts,slots,blueProofs;
globalThis.measureR4Pending=(a,s)=>{
 const h=s?.queue?.[0],first=s?.journal?.actions?.[0]?.action?.family,kind=h?.payload?.step||h?.payload?.cardEffect?.type||h?.payload?.kind||null;
 const key=[a.family,h?.type||'stable',first||'—',kind||'—'].join('|');
 counts[key]=(counts[key]||0)+1;
 if(h?.type==='science_domain_place_data'&&a.family==='choose_target'){
  const p=s.workingState.players.players.find(p=>p.id===a.actorId);
  const label=a.target.target==='computer'?a.summary:'blue '+a.target.blueSlot;
  const k=[label,p.mainActionCompleted?'post-main':'pre-main',p.resources.availableData].join('|');
  slots[k]=(slots[k]||0)+1;
  if(label==='blue 3'||label.endsWith('放置位 5')){
   const root=s.workingState,jobs=Object.values(root.aliens.chong?.transportTasksByRocketId||{});
   const reward=data.getBlueBonusPlacementReward(p,3),tasks=p.reservedCards.filter(c=>{
    const t=c.chongTask||chong.getCardTask(c);
    return !c.chongTaskCompleted&&t?.kind==='trace'&&chong.isTraceTaskReady(structuredClone(root.aliens),p,t);
   });
   const e={type:'placeData',playerId:a.actorId,placementKind:a.target.target,
    ...(a.target.target==='computer'?{placementSlot:5}:{blueSlot:3})};
   const key=[label,p.mainActionCompleted?'post':'pre',reward?.type||'none',
    jobs.length?jobs.map(x=>x.delivered?'delivered':'in-transit').join(','):'no-job',
    tasks.length?'trace-ready':'no-trace',fx.collectMatchingTriggers(structuredClone(p),e).length?'observer':'no-observer'].join('|');
   blueProofs[key]=(blueProofs[key]||0)+1;
  }
 }
};
for(const row of JSON.parse(z.gunzipSync(fs.readFileSync(source))).rows.filter(r=>r.input>=355)){
 const m=open(row.root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  counts={};slots={};blueProofs={};
  const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),row.root);
  assert.equal(Object.values(counts).reduce((x,y)=>x+y,0),row.native);
  rows.push({input:row.input,counts,slots,blueProofs});
  console.log(JSON.stringify({input:row.input,blueProofs}));
 }finally{p.close();m.dispose();}
}
fs.writeFileSync(out,JSON.stringify(rows,null,2)+'\n',{flag:'wx'});
