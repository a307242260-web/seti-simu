'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const [source,out]=process.argv.slice(2),{open,seat}=require('./native-late-r3');
const file=path.resolve('randomizer/game/ai/analysis-port.js');
const mod=new Module(file,module);mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const anchor='    function turnTailBoundary(node,spec){',js=fs.readFileSync(file,'utf8');
assert.equal(js.split(anchor).length,2);
mod._compile(js.replace(anchor,anchor+`
      if(spec.cargoAfterBlue3||spec.blue3PublicProof){
        const source=nodes.get(node),before=valueObservation(node);
        globalThis.auditDataTail(source.envelope,spec,before,source.informationBarrier,
          (native)=>observeEnvelope(native,spec.blue3PublicProof?{code:"hidden_card_reveal"}:source.informationBarrier,true));
      }`),file);
const {createAnalysisPort}=mod.exports;
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const stateValue=require(path.resolve('randomizer/game/ai/state-value'));
const data=require(path.resolve('randomizer/game/data')),evalV=stateValue.createStateValueEvaluator(seat),rows=[];
let checks;
globalThis.auditDataTail=(root,spec,before,barrier,observe)=>{
 const m=open(root),actions=[];
 const take=(family,predicate)=>actions.push(m.act(family,predicate));
 const place=(target,slot)=>{take('place_data');take('choose_target',a=>a.target.target===target&&(!slot||a.target.blueSlot===slot));};
 const income=id=>take('choose_card',a=>a.target.choiceId===`income:${id}`||a.target.cardInstanceId===id);
 const corner=id=>take('card_corner',a=>a.target.cardInstanceId===id&&a.payload.kind==='resource'&&a.payload.multiplier===1);
 try{
  if(spec.blue3PublicProof){
   if(spec.bluePublicPick.fundedComputerPlacement===5)place('computer');
   place('blueBonus',3);
   take('choose_card',a=>a.actionId===spec.bluePublicPick.cardActionId);
  }
  for(const plan of [...(spec.dataPlans||[]),...(spec.bluePublicPick?.continuingDataPlans||[])]){
   assert(!plan.bluePublicPick,'public pick requires another replay contract');
   const {goal}=plan;
   for(const id of plan.dataCornerIds||[plan.dataCornerId].filter(Boolean))corner(id);
   if(['income','computer-prefix'].includes(goal.kind)){
    const target=goal.targetComputerSlot;
    while(data.listComputerPlacedTokens(m.player()).length<target)place('computer');
    if(goal.kind==='income')income(plan.incomeCardId||goal.incomeCardId);
   }else if(goal.kind==='blue-data'){
    for(let i=0;i<(plan.computerPlacements||0);i++)place('computer');
    if(plan.incomeCardId)income(plan.incomeCardId);
    place('blueBonus',goal.blueSlot);
   }else assert.fail('unknown plan '+goal.kind);
  }
  if(spec.scoredFinish)corner(spec.scoredFinish.cardId);
  take('end_turn');
  if(spec.cargoAfterBlue3){
   const choice=spec.quietCargoChoice;
   take('accept_optional_effect',a=>a.target?.choiceId===`${choice.claim?'confirm':'skip'}:chong_task:${choice.cardId}:${choice.ruleId}`);
  }
  for(const tile of spec.markedTiles)take('choose_target',a=>a.target.tileId===tile);
  assert.equal(actions.length,spec.requiredNativeInputs);
  const exact=m.save();
  assert(!exact.session);
  const after=observe(exact),b=evalV.details(before),a=evalV.details(after);
  assert.equal(after.publicState.roundNumber,before.publicState.roundNumber);
  assert.equal(after.publicState.currentPlayerId,before.publicState.currentPlayerId);
  assert.equal(stateValue.sumValueParts([b.value,spec.netGain]),a.value,JSON.stringify([spec,b.value,a.value]));
  assert.equal(stateValue.sumValueParts([b.unrealizedPurposeValue,spec.unrealizedPurposeDelta||0]),a.unrealizedPurposeValue);
  assert.equal(b.purposePreparationDebt,a.purposePreparationDebt);
  m.restore(root);actions.forEach(m.apply);assert.deepEqual(m.save(),exact);
  let ordering;
  if(spec.cargoAfterBlue3){
   const choice=spec.quietCargoChoice,tail=actions.slice(0,-1),options={};
   for(const claim of [false,true]){
    m.restore(root);tail.forEach(m.apply);
    const type=claim?'confirm':'skip';
    m.act('accept_optional_effect',a=>a.target?.choiceId===`${type}:chong_task:${choice.cardId}:${choice.ruleId}`);
    const result=observe(m.save()),d=evalV.details(result);
    options[type]={value:d.value,unrealized:d.unrealizedPurposeValue,pool:m.player().resources.availableData};
   }
   assert.equal(stateValue.sumValueParts([options.skip.value,choice.gain]),options.confirm.value);
   assert.equal(stateValue.sumValueParts([options.skip.unrealized,choice.capital]),options.confirm.unrealized);
   m.restore(root);
   const startPool=m.player().resources.availableData;
   m.act('complete_task',a=>a.target.cardInstanceId===choice.cardId&&a.target.ruleId===choice.ruleId);
   tail.forEach(m.apply);
   const earlyPool=m.player().resources.availableData,latePool=options.confirm.pool;
   assert(latePool>=earlyPool);
   ordering={startPool,earlyPool,latePool,options};
  }
  checks.push({status:barrier?.code||'own-turn-complete',spec,actions,exact,ordering});
 }finally{m.dispose();}
};
for(const row of JSON.parse(z.gunzipSync(fs.readFileSync(source))).rows.filter(r=>r.input>=355)){
 const m=open(row.root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  checks=[];
  const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length&&checks.length);
  assert.deepEqual(m.save(),row.root);
  assert.deepEqual(q.roots.filter(a=>a.target!=null).map(a=>[a.actionId,a.value,a.realization||0,a.preparationDebt]),row.ranking);
  rows.push({input:row.input,checks});
  console.log(JSON.stringify({input:row.input,count:checks.length,publicPick:checks.filter(x=>x.spec.blue3PublicProof).length,cargo:checks.filter(x=>x.spec.cargoAfterBlue3).length,
   nativeInputs:checks.reduce((n,x)=>n+x.actions.length,0),dataSaved:checks.flatMap(x=>x.ordering?[x.ordering.latePool-x.ordering.earlyPool]:[])}));
 }finally{p.close();m.dispose();}
}
fs.writeFileSync(out,z.gzipSync(JSON.stringify(rows)+'\n'),{flag:'wx'});
