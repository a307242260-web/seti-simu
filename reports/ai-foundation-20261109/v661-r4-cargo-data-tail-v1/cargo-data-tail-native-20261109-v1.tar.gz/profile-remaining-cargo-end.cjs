'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const [source,out]=process.argv.slice(2),{open,seat}=require('./native-late-r3');
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const hook='      const before = comp.inspect(true);',js=fs.readFileSync(file,'utf8');assert.equal(js.split(hook).length,2);
mod._compile(js.replace(hook,hook+`
      if(current.family==="accept_optional_effect"&&current.target?.choiceId?.startsWith("confirm:chong_task:")){
        const session=loadedEnvelope?.session?.session;
        globalThis.captureOutstandingEnd(session?.journal?.actions?.[0]?.action?.family,session?.baseState,session?.workingState,current.target.choiceId);
      }`),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const effects=require(path.resolve('randomizer/game/cards/effects')),chong=require(path.resolve('randomizer/game/aliens/chong')),rows=[];
let items;
globalThis.captureOutstandingEnd=(family,base,working,prompt)=>{
 if(!base||!working)return;
 const p=base.players.players.find(p=>p.id===seat),w=working.players.players.find(p=>p.id===seat);
 const cards=p.reservedCards.map(c=>c.cardId);
 items.push({family,prompt,traceReady:p.reservedCards.some(c=>{const task=c.chongTask||chong.getCardTask(c);return task?.kind==="trace"&&chong.isTraceTaskReady(structuredClone(base.aliens),p,task);}),score:p.resources.score,pool:p.resources.availableData,hand:p.hand.map(c=>c.cardId),
  credits:p.resources.credits,energy:p.resources.energy,phase:base.turn.currentPlayerId,
  scoreAtPrompt:w.resources.score,queueTriggerKeys:effects.listPendingTriggerKeys(structuredClone(p),base.turn),cards,
  reservationsChanged:p.reservedCards.length!==w.reservedCards.length,
  bonusEvents:(base.turn.cardTurnEventBonuses||[]).map(b=>b.eventType),reserveKinds:p.reservedCards.map(c=>[c.cardId,effects.getCardModel(c)?.cardType])});
};
for(const row of JSON.parse(z.gunzipSync(fs.readFileSync(source))).rows.filter(r=>r.input>=355)){
 const m=open(row.root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  items=[];
  const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),row.root);
  const causes={};
  for(const item of items){
   const key=[item.family,item.prompt.split(":").at(-1),item.traceReady,item.reservationsChanged,item.queueTriggerKeys.length,item.bonusEvents.join(','),item.cards.join(',')].join('|');
   causes[key]=(causes[key]||0)+1;
  }
  rows.push({input:row.input,items,causes});
  console.log(JSON.stringify({input:row.input,count:items.length,causes}));
 }finally{p.close();m.dispose();}
}
fs.writeFileSync(out,JSON.stringify(rows,null,2)+'\n',{flag:'wx'});
