'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const base=require('./r4-scan-state-buckets-clean-20261109-v2.json')[0];
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const m=open(root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
try{
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 assert.equal(q.diagnostics.nativeExecutions,base.native);assert.equal(JSON.stringify(q.roots.map(x=>[x.actionId,x.value,x.realization,x.preparationDebt])),JSON.stringify(base.ranking));
 const lines=q.lines,names=new Map(m.menu().map(a=>[a.actionId,{summary:a.summary,target:a.target,payload:a.payload}]));
 const get=(e)=>e.resourcePlan?.goal?.id||e.turnTailPlanValue?.kind||e.actionId.split(':')[0];
 const roots=lines[0].edges.map((rootEdge)=>{
  const seen=new Set(),visit=i=>{if(seen.has(i))return;seen.add(i);for(const e of lines[i].edges)visit(e.target);};visit(rootEdge.target);
  const visited=[...seen].map(i=>lines[i]),all=visited.flatMap(x=>x.edges);
  const groups={};for(const e of all){
   const id=get(e),g=groups[id]||(groups[id]={edges:0,steps:0,min:null,max:null});
   const target=lines[e.target];g.edges++;g.steps+=e.cost||0;
   if(target.value!=null){g.min=g.min==null?target.value:Math.min(g.min,target.value);g.max=g.max==null?target.value:Math.max(g.max,target.value);}
  }
  const earliest=visited.filter(x=>x.edges.length>1).slice(0,9).map(x=>({node:x.node,stage:x.status,value:x.value,
    children:x.edges.map(e=>({node:e.target,actionId:e.actionId,goal:get(e),value:lines[e.target].value,realization:lines[e.target].realization,cost:e.cost}))}));
  return {actionId:rootEdge.actionId,...names.get(rootEdge.actionId),steps:rootEdge.steps||[],goal:get(rootEdge),target:rootEdge.target,value:lines[rootEdge.target].value,nodes:seen.size,edges:all.length,
   byStatus:visited.reduce((m,x)=>(m[x.status]=(m[x.status]||0)+1,m),{}),
   groups:Object.entries(groups).sort((a,b)=>b[1].steps-a[1].steps).slice(0,18),earliest};
 }).sort((a,b)=>b.nodes-a.nodes);
 fs.writeFileSync(process.argv[2],JSON.stringify({native:base.native,roots},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(roots.slice(0,5).map(({earliest,...r})=>({...r,groups:r.groups.slice(0,7)}))));
}finally{p.close();m.dispose();}
