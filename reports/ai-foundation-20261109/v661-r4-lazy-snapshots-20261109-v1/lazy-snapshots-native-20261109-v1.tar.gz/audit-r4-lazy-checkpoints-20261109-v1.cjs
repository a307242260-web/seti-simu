'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module'),crypto=require('node:crypto');
const {open,seat}=require('./native-late-r3');
const {checkpoint:root}=require('./v661-r4-full-preflight-20261109-v1.json');
const base=require('./r4-scan-state-buckets-clean-20261109-v2.json')[0];
const file=path.resolve('randomizer/game/ai/analysis-port.js'),mod=new Module(file,module);
mod.filename=file;mod.paths=Module._nodeModulePaths(path.dirname(file));
const js=fs.readFileSync(file,'utf8'),anchor='      const saved = comp.lifecycle.save({ trustedFork: true, deferSerialization:true });';
assert.equal(js.split(anchor).length,2);
mod._compile(js.replace(anchor,anchor+'\n      globalThis.noteLazySnapshot(comp,saved);'),file);
const {createAnalysisPort}=mod.exports,{createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const captures=[],stats={committed:0,pending:0,external:0,openRootExternalGetter:false};
globalThis.noteLazySnapshot=(comp,lazy)=>{
 assert(lazy.ok);
 const eager=comp.lifecycle.save({trustedFork:true});
 assert(eager.ok);
 assert.equal(lazy.envelope.schemaVersion,eager.envelope.schemaVersion);
 assert.deepEqual(lazy.envelope.session,eager.envelope.session);
 const getter=Object.getOwnPropertyDescriptor(lazy.envelope,'committedState').get;
 if(!lazy.trustedState){assert(!getter);stats.external++;}
 else{
  assert(getter);assert(Object.isFrozen(lazy.trustedState));assert(Object.isFrozen(lazy.envelope));
  assert.equal(lazy.trustedState,eager.trustedState);
  if(lazy.envelope.session){assert(Object.isFrozen(lazy.envelope.session.session.workingState));stats.pending++;}
  else stats.committed++;
  captures.push({envelope:lazy.envelope,bytes:eager.envelope.committedState});
 }
};
const m=open(root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:port}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 assert.equal(q.actionId,base.action);assert.equal(q.value,base.value);assert.equal(q.diagnostics.nativeExecutions,base.native);
 assert.equal(crypto.createHash('sha256').update(JSON.stringify(q.lines)).digest('hex'),base.graph);
 for(const x of captures)assert.equal(x.envelope.committedState,x.bytes);
 assert(stats.pending&&stats.committed&&stats.external);
 const external=m.c.lifecycle.save({trustedFork:true,deferSerialization:true});
 assert(!Object.getOwnPropertyDescriptor(external.envelope,'committedState').get);
 const result={...stats,comparedBytesAfterClose:captures.length,lazyPreviews:q.analysis.lazyCommittedEnvelopes,
  previewBytesRead:q.analysis.lazyPreviewSerializations,graph:base.graph};
 fs.writeFileSync(process.argv[2],JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result));
}finally{port.close();m.dispose();}
