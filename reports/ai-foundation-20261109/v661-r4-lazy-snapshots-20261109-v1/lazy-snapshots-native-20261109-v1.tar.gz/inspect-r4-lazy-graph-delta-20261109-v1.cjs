'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),assert=require('node:assert/strict');
const {open,seat}=require('./native-late-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const rows=JSON.parse(z.gunzipSync(fs.readFileSync('../candidate-r4-active-task-preview-native-20261109-v1.json.gz'))).rows;
const label=Number(process.argv[2]),root=rows.find(r=>r.input===label).root;
const m=open(root),p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
try{
 const q=createSearchAgent({seatId:seat,analysisPort:p}).decide({seatId:seat,legalActions:m.menu()}).search;
 assert(q.complete&&!q.unresolved.length);assert.deepEqual(m.save(),root);
 const {actionId,value,roots,lines,diagnostics,analysis,rootAndSearchMilliseconds:ms}=q;
 fs.writeFileSync(process.argv[3],z.gzipSync(JSON.stringify({label,actionId,value,roots,lines,diagnostics,analysis,ms})),{flag:'wx'});
 console.log(JSON.stringify({label,actionId,value,native:diagnostics.nativeExecutions,transitions:diagnostics.transitions,nodes:analysis.nodeCount,ms}));
}finally{p.close();m.dispose();}
