'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,open,short}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),d=readZ(src).cases,rows={};
for(const label of ['preserve','spend']){
 const origin=d[label].stages['after-common-blue8'].state,m=open(origin),actions=[],take=(f,p)=>actions.push(m.act(f,p));
 try{
  if(label==='preserve'){
   for(let i=0;i<4;i++){take('place_data');take('choose_target',a=>a.target.target==='computer');}
   take('choose_card',a=>a.target.choiceId==='income:card-30-pass-3-1');
  }
  const wallet=short(m),end=m.save();m.restore(origin);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  rows[label]={origin,wallet,end,actions,replayExact:true};console.log(label,JSON.stringify(wallet));
 }finally{m.dispose();}
}
writeZ(out,{scope:'After the same R4 first main (blue8 analysis), convert preserved four data into the same B111 permanent electricity during that turn. Neither line spends another main.',rows});
