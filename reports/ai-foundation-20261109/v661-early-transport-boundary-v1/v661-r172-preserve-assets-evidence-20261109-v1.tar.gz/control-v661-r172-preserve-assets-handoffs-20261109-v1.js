'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{readZ,writeZ,runCases,open,short}=require('./controlled-r3');
const [dir,out,mode='native']=process.argv.slice(2);
const data=n=>readZ(path.join(dir,n+'.json.gz'));
const origin=data('v575-official-r3-scan-ledger-20261108-v1').rows.find(r=>r.step===172).origin;
const segments=[
 data('v594-a0-before-early-reveal-20261108-v1').rows[0],
 data('v595-a0-first-fund-transport-20261108-v1').rows[0],
 data('v595-a0-first-cargo-20261108-v1').rows[0],
 data('v596-a0-first-preserve-assets-20261108-v1').rows[0]
],m=open(origin),timeline=[],checkpoints={},origins={};
function snap(label){origins[label]=m.save();checkpoints[label]={index:timeline.length,assets:short(m),next:m.menu().map(a=>[a.family,a.summary,a.actionId])};}
snap('r172-no-prefix');
for(const [i,segment] of segments.entries()){
 for(const [j,a] of segment.accepted.entries()){
  if(i===0&&j===1)snap('after-amiba0');
  if(i===0&&a.family==='play_card'&&a.summary==='dlc_19.png')snap('before-dlc19');
  if(i===0&&a.family==='choose_target'&&a.target.alienSlotId===2&&a.target.traceType==='pink')snap('pink-menu-'+timeline.length);
  if(i===1&&a.family==='research_tech'&&j>4)snap('before-blue1');
  if(i===2&&j===1)snap('movement-payment-before-chong3');
  timeline.push(m.apply(a));
 }
 assert.deepEqual(m.save(),segment.end,'native stored endpoint '+segment.goal);
 snap(['before-orange1','before-chong3','after-cargo','fully-fixed-before-pass'][i]);
}
m.restore(origin);timeline.forEach(m.apply);assert.deepEqual(m.save(),origins['fully-fixed-before-pass']);m.dispose();
console.log(JSON.stringify({prefix:timeline.length,summary:Object.fromEntries(Object.entries(checkpoints).map(([k,v])=>[k,[v.index,v.assets.wallet,v.assets.hand]]))}));
const cases={};
if(mode==='autonomous')for(const [label,root] of Object.entries(origins))cases[label]=runCases(root,[[label,()=>{}]]);
writeZ(out,{scope:'V592 asset-preserving teacher-like native chain on the latest identical Production rules. Fixed input handoffs remain separately classified; no new standard opening run.',origin,timeline,origins,checkpoints,cases,nativeReplayExact:true});
