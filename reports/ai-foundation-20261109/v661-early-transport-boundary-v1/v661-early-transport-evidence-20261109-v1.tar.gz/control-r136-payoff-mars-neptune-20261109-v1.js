'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,runCases,open,short}=require('./controlled-r3');
const [source,out]=process.argv.slice(2);
const r=readZ(source).cases['sector-3-a:false'].rows[0],m=open(r.start);
let root;
for(const [i,{action:a}] of r.actions.entries()){if(i===32){root=m.save();break;}m.apply(a);}
assert.equal(short(m).chongOffer,9);m.dispose();
function funding({act},pair){
 act('quick_trade',a=>a.target.tradeId==='credits-for-energy');
 act('quick_trade',a=>a.target.tradeId==='cards-for-energy');
 for(const id of pair)act('choose_payment',a=>a.summary===id);
 act('choose_payment',a=>a.target.confirm);
}
function land(h,planet,pair){
 const {m,act,cut}=h;
 funding(h,pair);
 if(planet==='neptune'){
  for(const card of ['chong_7.webp','chong_2.webp']){
   act('move',a=>a.target.deltaY===1&&a.target.deltaX===0);
   const id=m.player().hand.find(c=>c.cardId===card).id;
   act('choose_payment',a=>a.target.cardIds?.length===1&&a.target.cardIds[0]===id);
  }
 }
 act('land',a=>!a.target.planetId||a.target.planetId===planet);
 if(m.menu().some(a=>a.target.actionType==='land'))act('choose_target',a=>a.target.planetId===planet&&a.target.landTarget.type==='planet');
 cut('after-land');
 act('choose_target',a=>a.target.traceType==='yellow'&&a.target.alienSlotId===1);
 cut('mark');
 act('end_turn');
 if(m.menu().some(a=>a.target.choiceId==='final:b'))act('choose_target',a=>a.target.choiceId==='final:b');
 cut('after-native-reveal');
}
function research(h,tile){
 const {act,cut}=h;act('research_tech');act('choose_target',a=>a.target.tileId===tile&&(!a.target.blueSlot||a.target.blueSlot===3));cut(tile);
}
const cases=[['policy',()=>{}],
 ['neptune',h=>land(h,'neptune',['dlc_19.png','dlc_25.png'])],
 ['mars-same-fees',h=>land(h,'mars',['dlc_19.png','dlc_25.png'])],
 ['mars-keep-dlc25',h=>land(h,'mars',['dlc_19.png','chong_7.webp'])],
 ['mars-keep-dlc19',h=>land(h,'mars',['dlc_25.png','chong_7.webp'])],
 ['orange3',h=>research(h,'orange3')],['orange2',h=>research(h,'orange2')],
 ['orange4',h=>research(h,'orange4')]];
writeZ(out,{scope:'Same original exposed Chong9 root, matched mandatory cash/energy cost for Mars and Neptune, and only three named known technology alternatives. No hidden card used before Native reveals it.',root,...runCases(root,cases)});
