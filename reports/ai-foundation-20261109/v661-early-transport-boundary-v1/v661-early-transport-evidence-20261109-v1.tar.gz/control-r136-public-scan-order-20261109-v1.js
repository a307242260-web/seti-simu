'use strict';
const {readZ,writeZ,runCases}=require('./controlled-r3');
const [src,out]=process.argv.slice(2),origin=readZ(src).snapshots[136].envelope;
const sphere={'sirius':'sector-2-a','procyon':'sector-1-a'};
function prefix({act,cut},order,where){
 act('scan');act('choose_target',a=>a.target.nebulaId==='sector-3-a');
 for(const [i,card] of order.entries()){
  const id=sphere[where[i]];
  act('choose_card',a=>a.summary.startsWith(card+' →')&&a.target.nebulaId===id);
 }
 cut('public-scan-complete');
}
const cases=[];
for(const order of [['b_14.webp','dlc_30.png'],['dlc_30.png','b_14.webp']])
 for(const where of [['sirius','sirius'],['procyon','procyon'],['sirius','procyon'],['procyon','sirius']])
  cases.push([[...order,...where].join(':'),h=>prefix(h,order,where)]);
writeZ(out,{scope:'From original R3 input 136, preserve known DLC31 Mars supplier. Fix only the order and target of the two original visible public scan cards, then continue autonomously under the original gate. No new standard game.',origin,...runCases(origin,cases)});
