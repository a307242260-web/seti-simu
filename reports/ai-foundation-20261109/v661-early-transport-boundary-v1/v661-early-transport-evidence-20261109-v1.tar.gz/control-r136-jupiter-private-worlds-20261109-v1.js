'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{readZ,writeZ,runCases,open}=require('./controlled-r3');
const {createStateStore}=require(path.resolve('randomizer/game/state/state-store'));
const [src,out]=process.argv.slice(2),r=readZ(src),root=r.root,seat='player-white',m=open(root);
const view=m.owner(seat),menu=m.menu(),q=m.automatic(),ref=[q.a.actionId,q.value,q.roots],hidden=m.state().aliens.aliens['1'].assignedAlienId;
const possible=m.state().aliens.revealPoolAlienIds.filter(x=>x!=='虫'),worlds=new Map([[hidden,{root,seed:null}]]);
for(let i=0;i<128&&worlds.size<possible.length;i++){
 const seed='r136-jupiter-private-world-v1:'+i;
 const next=m.c.counterfactualPort.prepareRoot(root,{publicSeed:seed,restoreRandomState:false});
 const s=JSON.parse(next.committedState),id=s.aliens.aliens['1'].assignedAlienId;
 assert.deepEqual(s.meta.rngState,m.state().meta.rngState);
 if(!worlds.has(id)){
  const encoded=createStateStore(s).serialize(s);assert(encoded.ok);worlds.set(id,{root:{...next,committedState:encoded.serialized},seed});
 }
}
m.dispose();assert.equal(worlds.size,possible.length);
const prefix=r.rows.find(x=>x.label==='energy-chong7-first-species').prefix;
const result={};
for(const [id,w] of worlds){
 const current=open(w.root);
 try{
  assert.deepEqual(current.owner(seat),view);assert.deepEqual(current.menu(),menu);
  const q=current.automatic();assert.deepEqual([q.a.actionId,q.value,q.roots],ref);
 }finally{current.dispose();}
 const route=prefix;
 try {
  result[id]={...w,...runCases(w.root,[['no-fixed-actions',()=>{}],['fixed-jupiter-first-yellow',h=>route.forEach(a=>h.take(h.m.apply(a)))]] )};
 }catch(e){result[id]={...w,error:String(e)};console.log(id,String(e).slice(0,230));}
}
writeZ(out,{scope:'Same public original R3 turn 8, Native public-seed hidden permutations only. Never choose a fossil before its Native reveal. Two paths per hidden world; each search gate remains enforced.',possible,hidden,reference:ref,result});
