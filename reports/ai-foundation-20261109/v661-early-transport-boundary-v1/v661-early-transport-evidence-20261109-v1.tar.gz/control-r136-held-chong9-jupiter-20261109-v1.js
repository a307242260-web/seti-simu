'use strict';
const {readZ,writeZ,runCases,open,short}=require('./controlled-r3');
const [source,out]=process.argv.slice(2);
const r=readZ(source).rows.find(x=>x.label==='orange4'),m=open(r.start);
r.actions.slice(0,8).forEach(({action:a})=>m.apply(a));
const root=m.save();m.dispose();
function route({m,act,take,cut},payer,trace){
 for(const [i,[x,y]] of [[0,1],[-1,0]].entries()){
  act('move',a=>a.target.deltaX===x&&a.target.deltaY===y);
  const card=m.player().hand.find(c=>c.cardId===payer[i]);
  act('choose_payment',a=>card?a.target.cardIds?.length===1&&a.target.cardIds[0]===card.id:a.target.choiceId==='energy');
 }
 take(m.play('chong_9.webp'));
 act('choose_target',a=>a.target.planetId==='jupiter'&&a.target.landTarget.type==='planet');
 cut('landing');
 act('choose_target',a=>a.target.choiceId===trace);
 cut('trace');
}
const rows=runCases(root,[['autonomous',()=>{}],['energy-chong7-first-species',h=>route(h,[null,'chong_7.webp'],'trace:1:yellow')],['two-cards-first-species',h=>route(h,['chong_7.webp','chong_2.webp'],'trace:1:yellow')],['energy-chong7-public-chong-yellow4',h=>route(h,[null,'chong_7.webp'],'trace:2:yellow:chong:4')]]);
writeZ(out,{scope:'Original hidden order; fixed publicly payable Jupiter landing at the round 3 turn 8 root, with one energy plus one held corner versus two held corners and two legal yellow trace alternatives. Autonomous after each prefix.',root,...rows});
