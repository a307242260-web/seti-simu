'use strict';
const path=require('node:path'),assert=require('node:assert/strict');
const {readZ,writeZ,open,short}=require('./controlled-r3');
const load=n=>require(path.resolve(n)),{createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{createSearchAgent}=load('randomizer/game/ai/search-agent');
const [source,output]=process.argv.slice(2),cases=readZ(source).rows;
const out=[];
for(const r of cases){
 const m=open(r.end);const root=m.save(),actions=m.menu();
 const port=createAnalysisPort({composition:m.c,seatId:'player-white',maxCacheEntries:0});
 try{
  globalThis.__setiAuditInputs=[];
  const q=createSearchAgent({seatId:'player-white',analysisPort:port}).decide({seatId:'player-white',legalActions:actions}).search;
  const steps=globalThis.__setiAuditInputs;assert.equal(steps.length,q.diagnostics.nativeExecutions);
  assert.deepEqual(m.save(),root);
  const count=keys=>Object.fromEntries(Object.entries(steps.reduce((o,s)=>{const k=keys(s);o[k]=(o[k]||0)+1;return o;},{})).sort((a,b)=>b[1]-a[1]));
  const families=count(s=>s.family),bySubject=count(s=>s.family+':'+(s.head||s.target.tradeId||s.target.planetId||'')),detailed=count(s=>s.family+':'+s.summary+':'+(s.source?.tradeId||s.sourceFamily||''));
  const values=q.roots.filter(x=>x.value!=null).map(x=>[actions.find(a=>a.actionId===x.actionId)?.summary,x.value,x.goal?.id]);
  const sourceEdges=q.lines[0].edges.map(e=>[actions.find(a=>a.actionId===e.actionId)?.summary,e.newInputs??e.cost,e.resourcePlan?.id,e.target]);
  out.push({label:r.label,root,summary:short(m),q,steps,families,bySubject,detailed,values,sourceEdges});
  console.log(JSON.stringify({label:r.label,diagnostics:{n:q.diagnostics.nativeExecutions,logical:q.diagnostics.logicalResourceInputs,shared:q.diagnostics.sharedResourceInputHits},families,bySubject,sourceEdges,values}));
 }finally{port.close();m.dispose();delete globalThis.__setiAuditInputs;}
}
writeZ(output,{scope:'Instrumentation-only copy: record every native submit and distinguish selection input by its initiating action. Cold search leaves root, session and RNG intact.',out});
