'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{readZ,writeZ,open,runCases}=require('./controlled-r3');
const native=require(path.resolve('randomizer/game/production-kernel'));
const [src,out]=process.argv.slice(2),r=readZ(src).at214.rows[3],m=open(r.start),roots={};
for(const [i,e] of r.actions.entries()){
 m.apply(e.action);
 if(i===16)roots['before-analysis']=m.save();
 if(i===22){roots['after-analysis']=m.save();break;}
}
m.dispose();
const result={};
for(const [label,root] of Object.entries(roots)){
 const setup=(nebulaId)=>({m,act,take,cut})=>{
  const dir=native.getProbeRouteRequirements(m.state(),'player-white').candidates.find(q=>
   !q.launchRequired&&q.endpointFamily==='land'&&q.planetId==='saturn'&&q.endpointTarget.type==='planet');
  assert.equal(dir.required.paidMovementPoints,2);
  const step=dir.path[0];
  take(m.play('b_16.webp'));
  act('choose_target',a=>a.target.rocketId===dir.rocketId&&a.target.deltaX===step.deltaX&&a.target.deltaY===step.deltaY);
  act('choose_target',a=>a.target.nebulaId===nebulaId);cut('scan');
  for(let i=0;m.c.inspect().phase==='awaiting_input';i++){
   assert(i<15);
   const a=m.menu().find(a=>a.target.choiceId?.startsWith('confirm:'))||m.menu().find(a=>a.target.choiceId?.startsWith('skip:'));
   if(!a)break;take(m.apply(a));
  }
  cut('scan-reward');
 };
 result[label]={root,...runCases(root,[['policy',()=>{}],...['sector-1-a','sector-2-a'].map(id=>[id,setup(id)])])};
}
writeZ(out,{scope:'Use held one-credit blue scan B16 before or after actual analysis on the controlled late-Saturn prefix. One named free move toward Saturn, two Native blue targets, then unchanged autonomous search and original gates.',result});
