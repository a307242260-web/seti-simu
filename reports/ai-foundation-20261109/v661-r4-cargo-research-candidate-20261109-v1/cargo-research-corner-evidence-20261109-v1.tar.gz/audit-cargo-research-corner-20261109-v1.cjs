'use strict';
const fs=require('node:fs'),z=require('node:zlib'),path=require('node:path'),assert=require('node:assert/strict'),Module=require('node:module');
const [source,selector,out]=process.argv.slice(2);
const fixture=JSON.parse(z.gunzipSync(fs.readFileSync(source))),which=Number(selector),records={};
const original=Module._extensions['.js'];
globalThis.auditCargoInput=(a,q)=>{
 const kind=a.family==='choose_target'||a.family==='choose_card'||a.family==='choose_payment'?q?.session?.decision?.effectType||q?.session?.decision?.decisionId?.split(':').at(0)||'target':'';
 const key=kind?a.family+':'+kind:a.family; records[key]=(records[key]||0)+1;
};
Module._extensions['.js']=(m,p)=>{
 if(!p.endsWith('/randomizer/game/ai/analysis-port.js'))return original(m,p);
 const s=fs.readFileSync(p,'utf8'),anchor='      if (!current || current.actorId !== seatId) throw new Error("ANALYSIS_ACTION_STALE");';
 assert(s.includes(anchor));return m._compile(s.replace(anchor,anchor+'\n      globalThis.auditCargoInput(current,before);'),p);
};
const {open,seat}=require('./native-late-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const root=fixture.rows.find(x=>x.summary.i===which).root,m=open(root);
const port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
const agent=createSearchAgent({seatId:seat,analysisPort:port});
try{
 const menu=m.menu(),q=agent.decide({seatId:seat,legalActions:menu}).search,cp=agent.createCheckpoint();
 assert.deepEqual(m.save(),root);
 assert.equal(Object.values(records).reduce((a,b)=>a+b,0),q.diagnostics.nativeExecutions);
 const names=new Map(menu.map(a=>[a.actionId,a.summary]));
 const wanted=q.lines[0].edges.find(e=>e.resourcePlan?.goal.kind==='cargo-research-corner');
 const rootGroups=q.lines[0].edges.map(e=>({action:names.get(e.actionId),goal:e.resourcePlan?.goal.id,
  value:q.lines[e.target].value,firstPrefix:e.cost,firstInputs:e.newInputs}));
 const tasks=()=>Object.values(m.state().aliens.chong.transportTasksByRocketId).map(j=>[j.fossilId,j.delivered]);
 const steps=[];
 for(const row of cp?.plan.rows||[]){
  const a=m.menu().find(a=>a.actionId===row.actionId);if(!a)break;
  m.apply(a);
  const f=m.facts();steps.push({id:a.actionId,action:a.summary,target:a.target,turn:f.turn,score:f.wallet.score,established:f.final,
    energy:f.wallet.energy,credits:f.wallet.credits,pool:f.wallet.availableData,tasks:tasks(),tech:Object.keys(f.tech.ownedTiles).filter(k=>f.tech.ownedTiles[k])});
 }
 const end=m.save();
 m.restore(root);for(const row of steps){const a=m.menu().find(a=>a.actionId===row.id);assert(a);m.apply(a);}
 assert.deepEqual(m.save(),end);
 const result={which,complete:q.complete,unresolved:q.unresolved.length,rootExact:true,records,rootGroups,steps,end,
  cargoPlan:wanted?.resourcePlan,ms:q.rootAndSearchMilliseconds,native:q.diagnostics.nativeExecutions,
  value:q.value,realization:q.realization,debt:q.preparationDebt,logical:q.diagnostics.transitions,diagnostics:q.diagnostics};
 fs.writeFileSync(out,z.gzipSync(JSON.stringify(result)+'\n'),{flag:'wx'});
 console.log(JSON.stringify({...result,end:undefined,diagnostics:undefined,cargoPlan:undefined}));
}finally{port.close();m.dispose();}
