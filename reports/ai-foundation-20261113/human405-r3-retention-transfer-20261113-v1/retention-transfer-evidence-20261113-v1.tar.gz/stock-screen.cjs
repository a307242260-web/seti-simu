'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),{open,short,writeZ}=require('./controlled-r3');
const K=require('./randomizer/game/production-kernel'),seat='player-white';
const read=p=>JSON.parse(fs.readFileSync(p));
const result=[];
for(const {board,f,score} of read('summary.json').rows){
 const record=read('reports/research/'+f), cp=read(record.roundEnds[2].checkpointPath), save=read(record.savePath);
 const root=cp.coreState.compositionEnvelope,m=open(root),start=short(m),cardVisits=[],options=[],first=[];
 try{
  for(let i=cp.replayCursor.stepIndex;i<save.replaySteps.length;i++){
   const a=save.replaySteps[i].action;
   if(a.actorId===seat&&a.family==='play_card'){
    const h=m.facts().hand.find(x=>x[0]===a.target.cardInstanceId);
    cardVisits.push([i+1,h?.[1]]);
   }
   if(a.actorId===seat&&a.phase==='main'&&!m.c.inspect().session&&m.facts().round===4){
    if(first.length===0)first.push(short(m));
    if(m.facts().hand.some(h=>h[1]==='b_16.webp')&&m.menu().some(x=>x.family==='play_card'&&m.facts().hand.find(h=>h[0]===x.target.cardInstanceId)?.[1]==='b_16.webp')){
     const routes=K.getProbeRouteRequirements(m.state(),seat).candidates.filter(x=>x.rocketId!=null&&x.path.length>0&&x.endpointFamily==='land'&&x.targetBenefit.score>0);
     options.push({input:i+1,actual:a.summary,assets:short(m),routes,root:m.save()});
    }
   }
   m.apply(a);
  }
  const end=m.save();assert.equal(m.state().match.finalScores.find(x=>x.playerId===seat).totalScore,score);
  result.push({board,score,start,first:first[0],cardVisits,options,finalExact:end.committedState===save.committedState});
 }finally{m.dispose();}
}
writeZ(process.argv[2],{revision:'37b970e55',source:'463fc442',rows:result});
for(const row of result)console.log(JSON.stringify({board:row.board,score:row.score,hand:row.start.hand,open:row.first?.hand,play:row.cardVisits,b16:row.options.map(x=>[x.input,x.routes.length,x.actual]),exact:row.finalExact}));
