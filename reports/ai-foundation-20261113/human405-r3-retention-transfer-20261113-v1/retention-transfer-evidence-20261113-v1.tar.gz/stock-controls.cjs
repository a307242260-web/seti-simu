'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),{open,short,readZ,writeZ}=require('./controlled-r3');
const seat='player-white',read=p=>JSON.parse(fs.readFileSync(p));
const result=[];
const source=read('summary.json').rows;
const screened=readZ('stock-screen-37b970e55-20261113-v1.json.gz');
for(const [board,alternatives] of [[20,['b_16.webp']],[12,['b_56.webp','b_95.webp']]]){
 const record=read('reports/research/'+source.find(x=>x.board===board).f), cp=read(record.roundEnds[2].checkpointPath),save=read(record.savePath);
 const m=open(cp.coreState.compositionEnvelope),toFirst=[];
 try{
  for(let i=cp.replayCursor.stepIndex;i<save.replaySteps.length;i++){
   const a=save.replaySteps[i].action;
   if(a.actorId===seat&&a.phase==='main'&&!m.c.inspect().session&&m.facts().round===4)break;
   toFirst.push(m.apply(a));
  }
  assert.equal(m.facts().round,4);assert.deepEqual(JSON.parse(JSON.stringify(short(m))),screened.rows.find(x=>x.board===board).first);
  const root=m.save(),menu=m.menu(),budget=[256,600],checks=[];
  const q=m.automatic();
  checks.push({n:q.n,ms:q.ms,complete:q.complete,action:q.a?.summary,value:q.value,roots:q.roots});
  const eligible=q.complete&&q.n<=budget[0]&&q.ms<=budget[1];
  for(const card of [null,...alternatives]){
   m.restore(root);
   const actions=[],decisions=[],main=[];let stop,cp;
   if(!eligible){result.push({board,card,initial:checks[0],stop:'initial gate'});continue;}
   if(card){
    const h=m.facts().hand.find(x=>x[1]===card);
    const a=menu.find(a=>a.family==='play_card'&&a.target.cardInstanceId===h?.[0]);
    if(!a){result.push({board,card,initial:checks[0],stop:'unavailable',assets:short(m),playable:menu.filter(a=>a.family==='play_card')});continue;}
    actions.push(m.apply(a));
    main.push([m.facts().turn,a.summary]);
   }
   for(let i=0;i<200;i++){
    if(m.state().turn.gameEnded){stop={kind:'terminal'};break;}
    if(m.menu()[0].actorId!==seat){m.advanceOpponents(actions);continue;}
    const u=card===null&&i===0?q:m.automatic(cp),a=u.a;
    if(!a||!u.complete||u.n>budget[0]||u.ms>budget[1]){stop={kind:'gate',n:u.n,ms:u.ms,action:a?.summary,root:m.save()};break;}
    if(a.phase==='main')main.push([m.facts().turn,a.summary]);
    decisions.push({n:u.n,ms:u.ms,value:u.value});
    cp=u.checkpoint;actions.push(m.apply(a));
   }
   assert(stop);const end=m.save(),score=m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore;
   m.restore(root);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
   result.push({board,card,score,initial:checks[0],stop,main,root,toFirst,actions,decisions,end,
    peak:[Math.max(0,...decisions.map(d=>d.n)),Math.max(0,...decisions.map(d=>d.ms))]});
  }
 }finally{m.dispose();}
}
writeZ(process.argv[2],{revision:'37b970e55',source:'463fc442',rows:result});
for(const {board,card,score,initial,stop,main,peak} of result)console.log(JSON.stringify({board,card,score,initial:{...initial,roots:undefined},stop:typeof stop==='object'?{...stop,root:undefined}:stop,main,peak}));
