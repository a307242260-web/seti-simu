'use strict';
const assert=require('node:assert/strict');
const {readZ,open,short,writeZ}=require('./controlled-r3');
const source=readZ('cargo.gz').groups[0].rows[0].end;
const m=open(source),seat='player-white',actions=[],points=[];
try{
 let checkpoint,stop;
 for(let i=0;i<120;i++){
  if(m.menu()[0]?.actorId!==seat){m.advanceOpponents(actions);continue;}
  const root=m.save(),before=short(m),x=m.automatic(checkpoint),a=x.a;
  const p={a:a?.summary,n:x.n,ms:x.ms,value:x.value,before,root,roots:x.roots};
  points.push(p);
  if(!a||!x.complete||x.n>256||x.ms>600){stop='gate';break;}
  if(a.family==='pass'){stop='prepass';break;}
  actions.push(m.apply(a));checkpoint=x.checkpoint;
  p.after=short(m);
  console.log(JSON.stringify({a:p.a,n:p.n,ms:p.ms,goal:p.roots.find(y=>y.actionId===a.actionId&&y.goal)?.goal,change:{wallet:p.after.wallet,hand:p.after.hand,computer:p.after.computer,blue:p.after.blue,probe:p.after.probes}}));
 }
 assert(stop);const end=m.save();m.restore(source);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
 writeZ(process.argv[2],{sourceRevision:'928cf91a4',source,actions,points,stop,end});
 console.log(JSON.stringify({stop,actions:actions.length,p:points.at(-1).before}));
}finally{m.dispose();}
