'use strict';
const assert=require('node:assert/strict');
const {readZ,open,short,writeZ}=require('./controlled-r3');
const base=readZ('trace-prepass-928cf91a4-20261113-v1.json.gz');
const blue=readZ('second-blue-928cf91a4-20261113-v1.json.gz');
const source=base.source,m=open(source),white='player-white',rows=[];
function pass(reserve,inputs){
 inputs.push(m.act('pass'));
 if(m.menu()[0]?.actorId!==white)m.advanceOpponents(inputs);
 inputs.push(m.act('choose_card',a=>a.target.kind==='pass-reserve-card'&&a.target.cardId===reserve));
 if(m.menu()[0]?.actorId!==white)m.advanceOpponents(inputs);
 assert.equal(m.facts().round,4);
}
function placeComputer(inputs){
 inputs.push(m.act('place_data'),m.act('choose_target',a=>a.target.target==='computer'));
}
function finish(inputs, main){
 let stop,checkpoint;const q=[];
 for(let i=0;i<200;i++){
  if(m.state().turn.gameEnded){stop={kind:'terminal'};break;}
  if(m.menu()[0]?.actorId!==white){m.advanceOpponents(inputs);continue;}
  const x=m.automatic(checkpoint),a=x.a;
  if(!a||!x.complete||x.n>256||x.ms>600){stop={kind:'gate',n:x.n,ms:x.ms,action:a?.summary,envelope:m.save()};break;}
  q.push({n:x.n,ms:x.ms,a:a.summary,value:x.value});
  if(a.phase==='main')main.push(a.summary);
  checkpoint=x.checkpoint;inputs.push(m.apply(a));
 }
 assert(stop);
 return {stop,q,peak:[Math.max(0,...q.map(x=>x.n)),Math.max(0,...q.map(x=>x.ms))]};
}
try{
 for(const reserve of ['b_111.webp','b_32.webp'])for(const mode of ['analyze-r3','fill-r3','fill-r4','pass-r3']){
  if(mode==='pass-r3'){
   const r=blue.rows.find(x=>x.reserve===reserve&&x.timing==='none');
   m.restore(source);r.inputs.forEach(m.apply);assert.deepEqual(m.save(),r.end);
   rows.push({...r,mode,reused:true});continue;
  }
  m.restore(source);
  const inputs=[],main=[];
  if(mode==='analyze-r3'){for(const a of base.actions)inputs.push(m.apply(a));assert.deepEqual(m.save(),base.end);}
  if(mode==='fill-r3'){placeComputer(inputs);placeComputer(inputs);}
  const round3=m.save(),r3=short(m);
  pass(reserve,inputs);
  if(mode==='fill-r4'){placeComputer(inputs);placeComputer(inputs);}
  const start=m.save(),r4=short(m),result=finish(inputs,main),end=m.save();
  const score=m.state().match.finalScores?.find(p=>p.playerId===white)?.totalScore;
  m.restore(source);inputs.forEach(m.apply);assert.deepEqual(m.save(),end);
  const row={reserve,mode,round3,r3,start,r4,score,inputs,main,end,...result};
  rows.push(row);
  console.log(JSON.stringify({reserve,mode,r3:r3.wallet,hand:r3.hand,computer:r3.computer,blue:r3.blue,score,peak:row.peak,stop:{...row.stop,envelope:undefined},main}));
 }
 writeZ(process.argv[2],{sourceRevision:'928cf91a4',source,rows});
}finally{m.dispose();}
