'use strict';
const assert=require('node:assert/strict');
const {readZ,open,short,writeZ}=require('./controlled-r3');
const source=readZ('cargo.gz').groups[0].rows[0].end;
const m=open(source),white='player-white',rows=[];
function putBlue(inputs,card){
 inputs.push(m.act('place_data'),m.act('choose_target',a=>a.target.blueSlot===2));
 const pick=m.menu().find(a=>a.family==='choose_card'&&a.summary===card);
 if(!pick)return false;
 inputs.push(m.apply(pick));assert(!m.c.inspect().session);return true;
}
function pass(reserve,inputs){
 inputs.push(m.act('pass'));
 if(m.menu()[0]?.actorId!==white)m.advanceOpponents(inputs);
 inputs.push(m.act('choose_card',a=>a.target.kind==='pass-reserve-card'&&a.target.cardId===reserve));
 if(m.menu()[0]?.actorId!==white)m.advanceOpponents(inputs);
 assert.equal(m.facts().round,4);
}
try{
 for(const reserve of ['b_111.webp','b_32.webp'])for(const [timing,card] of [['none',null],...['b_60.webp','dlc_15.png','b_16.webp'].flatMap(card=>[['round-3',card],['round-4',card]])]){
  m.restore(source);
  const inputs=[],q=[],main=[];
  if(timing==='round-3'&&!putBlue(inputs,card)){rows.push({reserve,timing,card,stop:'unavailable',inputs,end:m.save()});continue;}
  const round3=m.save(),r3=short(m);
  pass(reserve,inputs);
  if(timing==='round-4'&&!putBlue(inputs,card)){rows.push({reserve,timing,card,stop:'unavailable',inputs,end:m.save()});continue;}
  const start=m.save(),r4=short(m);let stop,checkpoint;
  for(let i=0;i<200;i++){
   if(m.state().turn.gameEnded){stop={kind:'terminal'};break;}
   if(m.menu()[0]?.actorId!==white){m.advanceOpponents(inputs);continue;}
   const x=m.automatic(checkpoint),a=x.a;
   if(!a||!x.complete||x.n>256||x.ms>600){stop={kind:'gate',n:x.n,ms:x.ms,action:a?.summary,envelope:m.save()};break;}
   q.push({n:x.n,ms:x.ms,a:a.summary,value:x.value});
   if(a.phase==='main')main.push(a.summary);
   checkpoint=x.checkpoint;
   inputs.push(m.apply(a));
  }
  assert(stop);
  const end=m.save(),score=m.state().match.finalScores?.find(p=>p.playerId===white)?.totalScore;
  m.restore(source);inputs.forEach(m.apply);assert.deepEqual(m.save(),end);
  const peak=[Math.max(0,...q.map(x=>x.n)),Math.max(0,...q.map(x=>x.ms))];
  rows.push({reserve,timing,card,round3,r3,start,r4,stop,score,inputs,q,main,end,peak});
  console.log(JSON.stringify({reserve,timing,card,r3:r3.wallet,r4:r4.wallet,blue:r3.blue,stop:{...stop,envelope:undefined},score,peak,main}));
 }
 for(const reserve of ['b_111.webp','b_32.webp'])for(const card of ['b_60.webp','dlc_15.png','b_16.webp']){
  const [early,late]=['round-3','round-4'].map(timing=>rows.find(r=>r.reserve===reserve&&r.timing===timing&&r.card===card));
  if(!early.start||!late.start)continue;
  const a=JSON.parse(early.start.committedState),b=JSON.parse(late.start.committedState);
  const eq=JSON.stringify(a)===JSON.stringify(b);
  console.log(JSON.stringify({reserve,card,openingStateEqual:eq,openingAssetsEqual:JSON.stringify(early.r4)===JSON.stringify(late.r4),rngEqual:JSON.stringify(a.meta.rngState)===JSON.stringify(b.meta.rngState)}));
 }
 writeZ(process.argv[2],{sourceRevision:'928cf91a4',source,rows});
}finally{m.dispose();}
