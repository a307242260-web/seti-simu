'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,short}=require('./controlled-r3');
const src=readZ(process.argv[2]).rows.find(r=>r.label==='force-6'&&r.reserve==='b_111.webp'),seat='player-white';
const m=open(src.origin),prefix=[];let seen=false;
for(const a of src.actions){
 prefix.push(m.apply(a));
 if(a.family==='play_card'&&a.summary==='b_9.webp')seen=true;
 if(seen&&!m.save().session)break;
}
assert(seen);const root=m.save(),rows=[];
const native=require(path.resolve('randomizer/game/production-kernel'));
const nextTurn=()=>{const a=[m.act('end_turn')];if(m.menu()[0].actorId!==seat)m.advanceOpponents(a);return a;};
const baseline=m.automatic();
const diagnostic={choice:baseline.a,roots:baseline.roots,lines:baseline.lines,assets:short(m),n:baseline.n,ms:baseline.ms};
for(const mode of ['end-now','blue2','computer5','blue2-then-saturn','keep-saturn']){
 m.restore(root);const actions=[],take=a=>(actions.push(a),a),checks=[],main=[];
 if(mode==='computer5'||mode.startsWith('blue2')){
  take(m.act('place_data'));take(m.act('choose_target',a=>mode==='computer5'?a.target.target==='computer':a.target.blueSlot===1));
 }
 if(mode==='end-now'||mode.endsWith('saturn')){
  actions.push(...nextTurn());
  if(mode.endsWith('saturn')){
   const g=native.getProbeRouteRequirements(m.state(),seat).candidates.find(r=>r.planetId==='saturn'&&r.endpointFamily==='land'&&r.endpointTarget.type==='planet');
   assert(g.required.energy<=m.facts().wallet.energy);
   for(const step of g.path){take(m.act('move',a=>a.target.rocketId===g.rocketId&&a.target.deltaX===step.deltaX&&a.target.deltaY===step.deltaY));take(m.act('choose_payment',a=>a.target.choiceId==='energy'));}
   take(m.act('land'));assert(m.state().planets.planets.saturn.landingMarkers.some(x=>x.playerId===seat));
  }
 }
 const at=short(m),start=m.save(),forced=actions.length;let cp,stop;
 for(let i=0;i<210;i++){
  if(m.state().turn.gameEnded){stop={kind:'terminal'};break;}
  if(m.menu()[0].actorId!==seat){m.advanceOpponents(actions);continue;}
  const u=m.automatic(cp),a=u.a,x={n:u.n,ms:u.ms,complete:u.complete,value:u.value,a:a?.summary};
  if(!a||!u.complete||u.n>256||u.ms>600){stop={kind:'gate',...x,root:m.save(),roots:u.roots};break;}
  if(a.phase==='main')main.push([m.facts().turn,a.family,a.summary]);
  cp=u.checkpoint;checks.push(x);take(m.apply(a));
 }
 assert(stop);const end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore,peak=[Math.max(0,...checks.map(x=>x.n)),Math.max(0,...checks.map(x=>x.ms))];
 m.restore(src.origin);[...prefix,...actions].forEach(m.apply);assert.deepEqual(m.save(),end);
 console.log(JSON.stringify({mode,at,forced,terminal,stop:{...stop,root:undefined,roots:undefined},main,peak}));
 rows.push({mode,at,start,forced,actions,checks,main,stop,end,terminal,peak});
}
m.dispose();writeZ(process.argv[3],{origin:src.origin,root,prefix,diagnostic,rows});
