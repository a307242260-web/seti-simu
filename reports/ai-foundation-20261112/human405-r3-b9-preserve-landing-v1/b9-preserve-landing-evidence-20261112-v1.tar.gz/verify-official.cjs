'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),{open}=require('./controlled-r3');
const read=f=>JSON.parse(fs.readFileSync(f));
const [run]=read(process.argv[2]),base=read('reports/research/599c3f5b.93947ab2.quick-400.json'),now=read('reports/research/'+run.record);
const acts=rec=>read(rec.savePath).replaySteps.map(x=>x.action);
const actions=acts(now);assert.equal(actions.length,259);assert.deepEqual(actions,acts(base));
const metrics=rec=>rec.metrics.searches.map(s=>[s.step,s.actionId,s.value,s.diagnostics.nativeExecutions,s.complete]);
assert.deepEqual(metrics(now),metrics(base));
assert.deepEqual(now.roundEnds.map(c=>c.score),[15,48,118]);
assert(now.metrics.searches.every(s=>s.complete&&!s.unresolved.length&&s.diagnostics.nativeExecutions<=256&&s.rootAndSearchMilliseconds<=600));
const cp=read(read('reports/ai-foundation-20261023/human405-white-only-opening-20261030-v1.json').checkpointPath);
assert.deepEqual(cp.replaySteps.map(x=>x.action),actions.slice(0,23));
const m=open(cp.coreState.compositionEnvelope);
try{
 const cuts=new Map(now.roundEnds.map((x,i)=>{
  const a=read(x.checkpointPath),b=read(base.roundEnds[i].checkpointPath);
  assert.deepEqual(a.coreState.compositionEnvelope,b.coreState.compositionEnvelope);
  return [a.replayCursor.stepIndex,a.coreState.compositionEnvelope];
 }));
 for(let i=23;i<actions.length;i++){
  if(cuts.has(i))assert.deepEqual(m.save(),cuts.get(i));
  m.apply(actions[i]);
 }
 const end=m.save(),recorded=read(now.savePath);
 assert.deepEqual(JSON.parse(end.committedState),JSON.parse(recorded.committedState));
 console.log(JSON.stringify({actions:actions.length-23,decisions:metrics(now).length,cuts:cuts.size,peak:run.peak}));
}finally{m.dispose();}
