'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),original=require.extensions['.js'];
const [which,cutsFile,targetFile,out]=process.argv.slice(2);
if(which==='base')require.extensions['.js']=(m,p)=>p===path.resolve('randomizer/game/ai/goal-movement.js')?m._compile(fs.readFileSync(path.join(__dirname,'before-goal-movement.js'),'utf8'),p):original(m,p);
const {open,readZ,writeZ}=require('./controlled-r3'),rows=[],seat='player-white';
function compare(label,e){
 const m=open(e);
 try{
  const u=m.automatic();
  assert(u.complete&&u.n<=256&&u.ms<=600);
  return {label,root:e,action:u.a,complete:u.complete,n:u.n,ms:u.ms,value:u.value,roots:u.roots,view:m.owner(seat),menu:m.menu(),reason:u.lines[0].movementPolicy?.reason};
 }finally{m.dispose();}
}
for(const r of readZ(cutsFile).rows)for(const c of r.cuts)rows.push(compare(`board${r.board}:${c.input}`,c.root));
const target=readZ(targetFile).root,d=[];
for(const swap of [null,[0,4],[1,6]]){
 const s=JSON.parse(target.committedState);
 if(swap){const [i,j]=swap,p=s.cards.drawPileCardIds;assert(p[i]&&p[j]);[p[i],p[j]]=[p[j],p[i]];}
 const e=swap?{...target,committedState:JSON.stringify(s)}:target,r=compare(`target:${swap}`,e);
 if(swap){const a=d[0];for(const k of ['view','menu','action','n','value','roots','reason'])assert.deepEqual(r[k],a[k]);}
 d.push(r);
}
console.log(JSON.stringify({rows:rows.map(r=>[r.label,r.action.summary,r.n,r.ms,r.value]),d:d.map(r=>[r.label,r.action.summary,r.n,r.ms,r.value,r.reason])}));
writeZ(out,{rows,d});
