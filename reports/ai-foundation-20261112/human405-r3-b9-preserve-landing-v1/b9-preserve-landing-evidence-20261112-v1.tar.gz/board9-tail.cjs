'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),original=require.extensions['.js'];
const [which,cutFile,out]=process.argv.slice(2),seat='player-white';
if(which==='base')require.extensions['.js']=(m,p)=>p===path.resolve('randomizer/game/ai/goal-movement.js')?m._compile(fs.readFileSync(path.join(__dirname,'before-goal-movement.js'),'utf8'),p):original(m,p);
const {open,readZ,writeZ,short}=require('./controlled-r3');
const source=readZ(cutFile).rows.find(r=>r.board===9).cuts[0],m=open(source.root),actions=[],checks=[],main=[];
try{
 let cp,stop;
 for(let i=0;i<220;i++){
  if(m.state().turn.gameEnded){stop={kind:'terminal'};break;}
  if(m.menu()[0].actorId!==seat){m.advanceOpponents(actions);continue;}
  const u=m.automatic(cp),a=u.a,x={n:u.n,ms:u.ms,complete:u.complete,value:u.value,a:a?.summary};
  if(!a||!u.complete||u.n>256||u.ms>600){stop={kind:'gate',...x,root:m.save(),roots:u.roots};break;}
  if(a.phase==='main')main.push([m.facts().turn,a.family,a.summary]);
  cp=u.checkpoint;checks.push(x);actions.push(m.apply(a));
 }
 assert(stop);
 const end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore,peak=[Math.max(0,...checks.map(x=>x.n)),Math.max(0,...checks.map(x=>x.ms))];
 m.restore(source.root);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
 console.log(JSON.stringify({which,input:source.input,assets:source.assets,terminal,stop:{...stop,root:undefined,roots:undefined},peak,main}));
 writeZ(out,{source,actions,checks,main,end,stop,terminal,peak});
}finally{m.dispose();}
