'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [file,out]=process.argv.slice(2),native=require(path.resolve('randomizer/game/production-kernel')),seat='player-white',rows=[];
for(const r of readZ(file).rows.filter(r=>r.afterBlue2)){
 const m=open(r.afterBlue2.e),actions=[],take=a=>(actions.push(a),a),checks=[],main=[];
 try{
  take(m.act('place_data'));take(m.act('choose_target',a=>a.target.target==='computer'));
  take(m.act('place_data'));take(m.act('choose_target',a=>a.target.blueSlot===3));
  take(m.act('end_turn'));if(m.menu()[0].actorId!==seat)m.advanceOpponents(actions);
  const q=native.getProbeRouteRequirements(m.state(),seat).candidates.find(x=>x.planetId==='saturn'&&x.endpointFamily==='land'&&x.endpointTarget.type==='planet');
  assert(q.required.energy<=m.facts().wallet.energy);
  for(const d of q.path){take(m.act('move',a=>a.target.rocketId===q.rocketId&&a.target.deltaX===d.deltaX&&a.target.deltaY===d.deltaY));take(m.act('choose_payment',a=>a.target.choiceId==='energy'));}
  take(m.act('land'));
  assert(m.state().planets.planets.saturn.landingMarkers.some(p=>p.playerId===seat));
  const after={assets:short(m),root:m.save()},prefix=actions.length;
  let cp,stop;
  for(let i=0;i<230;i++){
   if(m.state().turn.gameEnded){stop={kind:'terminal'};break;}
   if(m.menu()[0].actorId!==seat){m.advanceOpponents(actions);continue;}
   const u=m.automatic(cp),a=u.a,x={a:a?.summary,value:u.value,n:u.n,ms:u.ms,complete:u.complete};
   if(!a||!u.complete||u.n>256||u.ms>600){stop={kind:'gate',...x,root:m.save()};break;}
   if(a.phase==='main')main.push([m.facts().turn,a.family,a.summary]);
   cp=u.checkpoint;checks.push(x);take(m.apply(a));
  }
  assert(stop);
  const end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore,peak=[Math.max(0,...checks.map(x=>x.n)),Math.max(0,...checks.map(x=>x.ms))];
  m.restore(r.initial.e);[...r.actions.slice(0,r.prefix),...actions].forEach(m.apply);assert.deepEqual(m.save(),end);
  rows.push({reserve:r.reserve,extra:r.extra,after,prefix,actions,checks,main,end,stop,terminal,peak});
  console.log(JSON.stringify({reserve:r.reserve,extra:r.extra,after:after.assets,terminal,stop:{...stop,root:undefined},peak}));
 }finally{m.dispose();}
}
writeZ(out,{rows});
