'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [prior,out]=process.argv.slice(2),k=require(path.resolve('randomizer/game/production-kernel')),seat='player-white';
const control=readZ(prior).rows.filter(r=>r.label==='force-6'),rows=[];
for(const src of control)for(const extra of ['sector-2-b','sector-3-a']){
 const m=open(src.start),actions=[],take=a=>(actions.push(a),a),turns=[],checks=[];
 const asset=()=>({summary:short(m),e:m.save()});
 const goal=()=>k.getProbeRouteRequirements(m.state(),seat).candidates.find(r=>r.planetId==='saturn'&&r.endpointFamily==='land'&&r.endpointTarget.type==='planet');
 try{
  const initial=asset(),known=m.state().cards.publicCards.map(c=>c.id);
  take(m.play('b_9.webp'));
  take(m.act('choose_target',a=>a.target.nebulaId==='sector-2-b'));
  take(m.act('choose_card',a=>a.summary==='dlc_20.png → 巴纳德'&&known.includes(a.target.cardInstanceId)));
  take(m.act('choose_card',a=>a.summary==='dlc_15.png → 天狼星A'&&known.includes(a.target.cardInstanceId)));
  take(m.act('choose_target',a=>a.target.choiceId==='scan4:launch'));
  const more=m.automatic(),offer=m.menu();
  assert(more.complete&&more.n<=256&&more.ms<=600);
  take(m.act('choose_target',a=>a.target.nebulaId===extra));
  while(m.save().session){
   const a=m.menu()[0];assert.equal(m.menu().length,1);
   assert(a.family==='choose_target'&&!a.target.cardInstanceId);take(m.apply(a));
  }
  const afterScan=asset();
  take(m.act('place_data'));take(m.act('choose_target',a=>a.target.blueSlot===1));
  const afterBlue2=asset();
  const route=goal();
  assert(route&&route.required.credits<=m.facts().wallet.credits&&route.required.energy<=m.facts().wallet.energy);
  const prefix=actions.length;let cp,stop,firstLand;
  for(let i=0;i<250;i++){
   if(m.state().turn.gameEnded){stop={kind:'terminal'};break;}
   if(m.menu()[0].actorId!==seat){m.advanceOpponents(actions);continue;}
   const u=m.automatic(cp),a=u.a,x={n:u.n,ms:u.ms,complete:u.complete,value:u.value,a:a?.summary};
   if(!a||!u.complete||u.n>256||u.ms>600){stop={kind:'gate',...x,root:m.save(),roots:u.roots};break;}
   if(a.phase==='main')turns.push([m.facts().turn,a.family,a.summary]);
   cp=u.checkpoint;checks.push(x);take(m.apply(a));
   if(a.family==='land'&&!firstLand){const p=m.state().planets.planets;firstLand=Object.keys(p).find(n=>p[n].landingMarkers.some(q=>q.playerId===seat));}
  }
  assert(stop);
  const end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore,peak=[Math.max(0,...checks.map(x=>x.n)),Math.max(0,...checks.map(x=>x.ms))];
  m.restore(src.start);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  rows.push({reserve:src.reserve,extra,initial,afterScan,afterBlue2,offer,more:{a:more.a,roots:more.roots,n:more.n,ms:more.ms},route,prefix,actions,checks,turns,firstLand,end,terminal,stop,peak});
  console.log(JSON.stringify({reserve:src.reserve,extra,afterScan:afterScan.summary.wallet,afterBlue2:afterBlue2.summary.wallet,route:route.required,firstLand,terminal,stop:{...stop,root:undefined,roots:undefined},peak}));
 }catch(e){rows.push({reserve:src.reserve,extra,error:String(e),actions,end:m.save()});console.log(JSON.stringify({reserve:src.reserve,extra,error:String(e).slice(0,300),menu:m.menu().map(a=>a.summary)}));}finally{m.dispose();}
}
writeZ(out,{rows});
