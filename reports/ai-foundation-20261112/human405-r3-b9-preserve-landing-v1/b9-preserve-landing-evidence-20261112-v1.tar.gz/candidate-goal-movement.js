(function(root,factory){
  "use strict";
  const common=typeof module==="object"&&module.exports;
  const api=factory(common?require('../abilities/rocket'):root.SetiAbilityRocket,
    common?require('../rockets'):root.SetiRocketActions,common?require('../../solar-system/core'):root.SetiSolarSystem,
    common?require('../cards/deck'):root.SetiCards,common?require('../cards/effects'):root.SetiCardEffects,
    common?require('../cards/play-domain'):root.SetiCardPlayDomain,common?require('../players'):root.SetiPlayers,common?require('../data'):root.SetiData);
  if(common)module.exports=api;else root.SetiGoalMovement=api;
})(typeof globalThis!=="undefined"?globalThis:window,function(ability,rockets,solar,cards,effects,cardPlay,players,data){
  "use strict";
  const VERSION='seti-goal-movement-policy-v5';
  const direction=action=>Number.isInteger(action.target?.rocketId)&&Number.isInteger(action.target.deltaX)
    &&Number.isInteger(action.target.deltaY)&&Math.abs(action.target.deltaX)+Math.abs(action.target.deltaY)===1;
  const startsMovement=action=>action.target?.tradeId==='energy-for-move'||action.family==='card_corner'&&action.payload?.kind==='move';
  const ending=action=>action.target?.skip===true||action.target?.mode==='skip';
  const same=(a,b)=>a&&b&&a.x===b.x&&a.y===b.y;
  const value=effect=>{
    const options=effect?.options||{};
    if(effect?.type==='gain_resources')return Object.entries(options.gain||{}).reduce((n,[key,v])=>n+v*({score:1,credits:1,energy:1,publicity:.5}[key]||0),0);
    return ['draw_cards','pick_card','gain_data'].includes(effect?.type)?Math.max(1,options.count||1)*(effect.type==='gain_data'?.5:1):0;
  };
  // 几何寻路只访问每探测器至多32个坐标；不创建游戏分支或执行奖励。
  function routes(state,owner,ship,cache){
    const cacheKey=JSON.stringify([state.solarSystem,state.pieces,owner.id,owner.techState,owner.industryBorrowedTechTileId,owner.industryBorrowedTechRound,owner.industryBorrowedTechTurn,state.turn.roundNumber,state.turn.turnNumber,state.turn.cardTurnEventBonuses||[],ship.id]);
    if(cache?.has(cacheKey))return{best:cache.get(cacheKey),settled:0};
    const context={state,players:state.players,pieces:state.pieces,turn:state.turn,solarSystem:state.solarSystem};
    const canMove=rockets.createStaticCoordinateMoveQuery(state.pieces,ship.id);
    const start=rockets.getRocketSectorCoordinate(ship),best=new Map(),queue=[{coordinate:start,cost:0,path:[],key:''}];let settled=0;
    while(queue.length){queue.sort((a,b)=>a.cost-b.cost||a.path.length-b.path.length||(a.key<b.key?-1:a.key>b.key?1:0));
      const next=queue.shift(),key=`${next.coordinate.x},${next.coordinate.y}`;if(best.has(key))continue;best.set(key,next);settled+=1;
      const cost=ability.getRequiredMovePointsFromCoordinate(context,owner,next.coordinate);if(!Number.isSafeInteger(cost)||cost<1)throw new Error('GOAL_MOVEMENT_COST_INVALID');

      for(const d of ability.MOVE_DIRECTIONS){const move=canMove(next.coordinate,d.deltaX,d.deltaY);if(!move.ok)continue;
        if(best.has(`${move.to.x},${move.to.y}`))continue;const step={from:next.coordinate,to:move.to,deltaX:d.deltaX,deltaY:d.deltaY,requiredMovePoints:cost};
        queue.push({coordinate:move.to,cost:next.cost+cost,path:[...next.path,step],key:next.key+'/'+d.id});
      }
    }
    if(cache){if(cache.size>=64)cache.delete(cache.keys().next().value);cache.set(cacheKey,best);}
    return{best,settled};
  }
  // These two exact effects buy the landing for the card's fee. A printed
  // satellite reward may be quoted, but never the identity of a fossil/card.
  function knownSatellitePickup(player){
    const suppliers=player.hand.filter(card=>{
      if(!card.id||!card.cardId||card.hidden)return false;
      const model=effects.getCardModel(card),list=model?.playEffects||[];
      const [land,pick]=list;
      return model?.cardType===2&&!model.triggers?.length&&!model.temporaryTasks?.length&&list.length===2
        &&land.type==='chong_orbit_or_land_for_pickup'&&pick.type==='chong_pickup_fossil'
        &&land.options?.orbitOrLand===true&&pick.options?.orbitOrLand===true
        &&land.options.cardIndex===pick.options.cardIndex
        &&[land,pick].every(e=>Object.keys(e.options).every(key=>key==='cardIndex'||key==='orbitOrLand'));
    });
    if(suppliers.length!==1)return null;
    const [card]=suppliers,cost=effects.getCardPlayCost(card);
    return Object.keys(cost).length===1&&Number.isSafeInteger(cost.credits)&&cost.credits>0
      &&player.resources.credits>=cost.credits?{card,cost}:null;
  }
  function knownSatelliteSectorCount(state,owner,rewards,plannedScans=[]){
    const own=row=>row.playerId===owner.id||row.playerColor===owner.color;
    const ready=rewards.filter(effect=>effect.type==='choose_colored_nebula_scan'
      &&effect.options?.nebulaIds?.some(id=>{
        const tokens=data.listNebulaTokens(state.data,id),next=data.getNextReplaceableNebulaToken(state.data,id);
        const additions=plannedScans.filter(scan=>scan===id).length;
        if(!next||tokens.length!==data.getNebulaCapacity(id)
          ||tokens.filter(t=>!t.replacedByPlayerColor&&!t.playerColor).length-additions!==1)return false;
        const ranking=data.getSectorRanking(state.data,id),mine=(ranking.find(own)?.count||0)+additions;
        return ranking.every(row=>own(row)||mine+1>row.count);
      }));
    return new Set(ready.map(effect=>effect.options.color)).size;
  }
  function plan({state,seatId,actions,status,session,intent=null,endpoints=()=>[],objectiveOnly=false,routeCache=null,compareTiming=null}){
    const moving=actions.filter(direction);
    const owner=state.players.players.find(p=>p.id===seatId);if(!owner)throw new Error('GOAL_MOVEMENT_OWNER_MISSING');
    const payment=intent&&actions.filter(a=>a.family==='choose_payment'&&a.target?.kind==='move-payment');
    if(payment?.length){
      const reserve=intent.goal.timing==='current-turn'?(intent.goal.endpointCost?.energy||0):0;
      const choices=payment.filter(a=>owner.resources.energy-(a.payload?.energyCost||0)>=reserve)
        .sort((a,b)=>(a.target.cardIds?.length||0)-(b.target.cardIds?.length||0)||(a.actionId<b.actionId?-1:1));
      if(!choices.length)throw new Error('GOAL_MOVEMENT_PAYMENT_UNAVAILABLE');
      return{policy:VERSION,selectionBasis:'committed-goal-payment',isEquivalence:false,reason:'reserve-endpoint-energy',chosenGoal:intent.goal,intent,
        selectedActionId:choices[0].actionId,retainedActionIds:[choices[0].actionId],excludedActionIds:actions.filter(a=>a!==choices[0]).map(a=>a.actionId),
        excludedDirectionCount:0,routingNodes:0,objectiveCount:0};
    }
    if(!moving.length&&!objectiveOnly)return null;
    const active=state.turn.activePlayerIds,passed=state.turn.passedPlayerIds;
    const onlySeatRemaining=Array.isArray(active)&&active.includes(seatId)&&Array.isArray(passed)
      &&active.every(id=>id===seatId||passed.includes(id));
    const hasExpiringMovement=Boolean(owner.industryBorrowedTechTileId||(state.turn.cardTurnEventBonuses||[])
      .some(b=>(b.ownerId||b.playerId)===seatId&&b.movementModifiers));
    const free=status==='decision',head=session?.queue?.[0];
    const allowance=free?(cardPlay.getMovementAllowance(head,state)??moving.find(a=>Number.isInteger(a.payload?.remaining))?.payload.remaining??head?.payload?.remaining??1):
      owner.resources.energy+owner.hand.reduce((n,c)=>n+(cards.getDiscardActionMoveRewardForCard(c)?.movementPoints||0),0);
    if(!Number.isSafeInteger(allowance)||allowance<0)throw new Error('GOAL_MOVEMENT_ALLOWANCE_INVALID');
    const stop=actions.find(ending),mandatoryPrefix=!objectiveOnly&&free&&!stop&&actions.length>0&&actions.every(direction),matches=(a,ship,step)=>a.target.rocketId===ship&&a.target.deltaX===step.deltaX&&a.target.deltaY===step.deltaY;
    function result(chosen,selected,why,routingNodes=0,objectiveCount=0){
      const retained=actions.filter(a=>direction(a)?a===selected:!free&&startsMovement(a)?false:free&&ending(a)?a===selected:true).map(a=>a.actionId);
      if(!retained.length){const error=new Error('GOAL_MOVEMENT_NO_LEGAL_EXIT');error.details={status,allowance,actions:actions.map(a=>({target:a.target,payload:a.payload})),resources:owner.resources,handCount:owner.hand.length};throw error;}
      return{policy:VERSION,selectionBasis:'explicit-objective-policy',isEquivalence:false,reason:why,
        chosenGoal:chosen?.goal||null,plan:chosen?{kind:'goal-plan',objective:chosen.goal,route:chosen.path,execution:'deterministic-native-route'}:null,intent:chosen?{goal:chosen.goal,rocketId:chosen.rocketId,path:chosen.path,startedTurn:chosen.startedTurn,startedRound:chosen.startedRound,free:chosen.free,prefixOnly:chosen.prefixOnly===true}:null,selectedActionId:selected?.actionId||null,retainedActionIds:retained,
        excludedActionIds:actions.filter(a=>!retained.includes(a.actionId)).map(a=>a.actionId),excludedDirectionCount:actions.filter(a=>direction(a)&&!retained.includes(a.actionId)).length,routingNodes,objectiveCount};
    }
    if(intent){const endpointCost=intent.goal.timing==='current-turn'?(intent.goal.endpointCost||{}):{},resourceValid=(endpointCost.credits||0)<=owner.resources.credits
      &&(endpointCost.energy||0)<=owner.resources.energy&&intent.path.reduce((n,s)=>n+s.requiredMovePoints,0)+(free?0:(endpointCost.energy||0))<=allowance;const ship=state.pieces.rockets.find(r=>r.id===intent.rocketId),at=ship&&rockets.getRocketSectorCoordinate(ship);
      if(resourceValid&&!intent.path.length&&same(at,intent.goal.coordinate))return result(intent,free?stop:null,'objective-reached');
      const next=intent.path[0],selected=next&&same(at,next.from)&&moving.find(a=>matches(a,intent.rocketId,next));
      if((resourceValid||mandatoryPrefix)&&selected&&next.requiredMovePoints<=allowance)return result(intent,selected,'continue-bound-route');
    }
    const ships=state.pieces.rockets.filter(r=>r.playerId===seatId&&rockets.isControllablePlayerRocket(r)),goals=[],pathByShip=new Map();let routingNodes=0;
    for(const ship of ships){const found=routes(state,owner,ship,routeCache);routingNodes+=found.settled;pathByShip.set(ship.id,found.best);}
    let visitCards;
    function triggerPlayer() {
      // Native collection itself ignores cards with no triggers. Normalize
      // only matching-capable entities, once for this query, without writing
      // the owner's stored cards. A native match still checks the event.
      if (visitCards === undefined) visitCards={...owner,reservedCards:owner.reservedCards
        .filter(c=>effects.getCardModel(c)?.triggers?.length)
        .map(c=>{const copy=structuredClone(c);effects.ensureCardEffectState(copy);return copy;})};
      return visitCards;
    }
    const arrivalValue=content=>owner.resources.publicity>=players.RESOURCE_LIMITS.publicity?0:
      content.kind==='comet'||content.kind==='planet'&&content.planetId!=='earth'||content.kind==='asteroid'&&players.playerOwnsTech(owner,'orange2',{turn:state.turn})? 0.5 : 0;
    function add(goal,ship,route,gain,endpointCost=0){if(!route||mandatoryPrefix&&!route.path.length||!mandatoryPrefix&&goal.timing!=='next-turn'&&route.cost>allowance)return;const first=route.path[0],selected=first&&moving.find(a=>matches(a,ship.id,first));if(!objectiveOnly&&route.path.length&&!selected)return;
      // Only the current native allowance is free; a preparation prefix must
      // still account for the remaining route rather than pricing all steps at0.
      const paidMovement=free?Math.max(0,route.cost-allowance):route.cost;
      const net=gain-endpointCost-paidMovement;if(!(net>0))return;
      goals.push({goal,rocketId:ship.id,path:route.path,cost:route.cost,net,selected,startedTurn:state.turn.turnNumber,startedRound:state.turn.roundNumber,free,prefixOnly:mandatoryPrefix});
    }
    for(const ship of ships)for(const route of pathByShip.get(ship.id).values()){
      // add() already rejects these routes before comparing gains. Check the
      // same resource and legal-first-step conditions before reading events.
      if(!route.path.length)continue;
      const first=route.path[0];
      if((!mandatoryPrefix&&route.cost>allowance)||(!objectiveOnly&&!moving.some(a=>matches(a,ship.id,first)))){
        __planetQueries.skippedUnusableVisitQuotes++;continue;
      }
      const c=solar.resolveVisibleContent(route.coordinate.x,route.coordinate.y,state.solarSystem).content;
      const type={planet:'visitPlanet',asteroid:'visitAsteroid',comet:'visitComet'}[c.kind];if(!type)continue;
      const normalized=triggerPlayer();
      let rewards=[];
      if(normalized.reservedCards.length){
        const ownOrbit=(state.planets.planets[c.planetId]?.orbitMarkers||[]).some(m=>m.playerId===seatId||m.playerColor===owner.color||m.color===owner.color);
        const event={type,planetId:c.planetId,playerId:seatId,source:free?'card':'move',hasOwnOrbit:ownOrbit};
        rewards=effects.collectMatchingTriggers(normalized,event).map(match=>({id:`${match.card.id}:${match.trigger.id}`,value:value(match.trigger.effect)})).sort((a,b)=>b.value-a.value||(a.id<b.id?-1:1));
      }
      const reward=rewards[0],gain=arrivalValue(c)+(reward?.value||0);
      add({id:`visit:${ship.id}:${route.coordinate.x}:${route.coordinate.y}:${reward?.id||'publicity'}`,kind:'visit',timing:'current-turn',label:reward?`领取访问奖励 ${reward.id}`:'领取到达宣传',coordinate:route.coordinate},ship,route,gain);
    }
    // Production给出合法环绕/登陆终点、费用与收益；本策略只确定目标及路线。
    let planetLocations;
    const sameSeatScan=free&&head?.type==='science_domain_scan_action_4'&&onlySeatRemaining
      &&state.turn.roundNumber===4&&state.turn.currentPlayerId===seatId&&!state.turn.gameEnded
      &&!passed.includes(seatId)&&owner.mainActionCompleted&&!owner.passCompletionPending
      &&!hasExpiringMovement&&allowance===1;
    const pickup=sameSeatScan&&knownSatellitePickup(owner);
    const nextTurn=[];
    let hasFundedPickup=false;
    for(const candidate of endpoints()){
      const ship=ships.find(s=>s.id===candidate.rocketId);if(!ship)continue;
      if(planetLocations){__planetQueries.reuses++;}
      else{planetLocations=solar.collectPlanetLocations(state.solarSystem);__planetQueries.builds++;}
      const location=planetLocations.find(p=>p.planetId===candidate.planetId);if(!location)continue;
      const coordinate={x:location.x,y:location.y},route=pathByShip.get(ship.id).get(`${coordinate.x},${coordinate.y}`),cost=candidate.endpointFacts?.cost||{};
      if(!mandatoryPrefix&&!owner.mainActionCompleted&&((cost.credits||0)>owner.resources.credits||(cost.energy||0)>owner.resources.energy
        ||!free&&(route?.cost||0)+(cost.energy||0)>allowance))continue;
      const benefit=candidate.targetBenefit;if(!benefit)throw new Error('GOAL_MOVEMENT_ENDPOINT_BENEFIT_MISSING');
      if(pickup&&route?.path.length===1&&route.cost===allowance
        &&(objectiveOnly||moving.some(a=>matches(a,ship.id,route.path[0])))){
        const eligible=candidate.endpointFamily==='land'&&candidate.endpointTarget?.type==='satellite'
          &&['jupiter','saturn'].includes(candidate.planetId)&&!ship.fossilId
          &&knownSatelliteSectorCount(state,owner,candidate.endpointFacts.rewards)>=2;
        const ordinary=players.canAfford(owner,cost);
        const standardCost=ordinary?(cost.credits||0)+(cost.energy||0):Infinity;
        const cardCost=eligible?pickup.cost.credits+1:Infinity;
        const price=Math.min(standardCost,cardCost);
        const gross=benefit.score+benefit.dataCount*.5;
        if(price<gross){
          const usesCard=cardCost<standardCost;
          if(usesCard)hasFundedPickup=true;
          nextTurn.push({goal:{id:candidate.requirementId,kind:candidate.endpointFamily,
            label:usesCard?`用已知牌登陆 ${candidate.planetId}`:`${candidate.endpointFamily} ${candidate.planetId}`,
            timing:'funded-next-own-turn',coordinate,planetId:candidate.planetId,endpointTarget:{...candidate.endpointTarget},
            endpointCost:usesCard?pickup.cost:{...cost},...(usesCard?{cardId:pickup.card.id}:{})},rocketId:ship.id,
            path:route.path,cost:route.cost,net:gross-price,selected:moving.find(a=>matches(a,ship.id,route.path[0])),
            startedTurn:state.turn.turnNumber,startedRound:state.turn.roundNumber,free:true,prefixOnly:true});
        }
      }
      add({id:candidate.requirementId,kind:candidate.endpointFamily,label:`${candidate.endpointFamily} ${candidate.planetId}`,coordinate,
        timing:mandatoryPrefix?'preparation':owner.mainActionCompleted?'next-turn':'current-turn',planetId:candidate.planetId,endpointTarget:{...candidate.endpointTarget},endpointCost:{...cost}},ship,route,benefit.score+benefit.dataCount*.5+benefit.incomeCount*(4-state.turn.roundNumber),
        (cost.credits||0)+(cost.energy||0));
    }
    const compare=(a,b)=>b.net-a.net||a.cost-b.cost||a.path.length-b.path.length||(a.goal.id<b.goal.id?-1:1);
    if(hasFundedPickup){
      // No opponent acts and no rotation occurs before the next own turn.
      // Compare funded endpoints reachable with this free move, not a route
      // that needs more paid movement or a hypothetical intervening rotation.
      const chosen=[...nextTurn,...goals.filter(g=>g.goal.kind==='visit')].sort(compare)[0];
      return objectiveOnly?{routingNodes,intent:{goal:chosen.goal,rocketId:chosen.rocketId,path:chosen.path,
        startedTurn:chosen.startedTurn,startedRound:chosen.startedRound,free:true,prefixOnly:true}}
        :result(chosen,chosen.selected,'funded-next-own-turn-after-free-scan',routingNodes,nextTurn.length);
    }
    goals.sort(compare);
    let chosen=null,deferredGoal=null;
    for(const candidate of goals){
      if(!candidate.path.length&&owner.mainActionCompleted&&!mandatoryPrefix){
        deferredGoal ||= {...candidate.goal,timing:'defer'};continue;
      }
      let executable=candidate;
      // With all other seats passed, ending this turn returns to this seat
      // without a rotation. Defer only if no temporary movement ability can expire.
      if(owner.mainActionCompleted&&!mandatoryPrefix&&!free&&onlySeatRemaining&&!hasExpiringMovement&&['orbit','land'].includes(candidate.goal.kind)){
        deferredGoal ||= {...candidate.goal,timing:'defer',reason:'no-intervening-rotation-before-next-own-turn'};continue;
      }
      if(owner.mainActionCompleted&&!mandatoryPrefix&&['orbit','land'].includes(candidate.goal.kind)&&compareTiming){
        let timing=compareTiming(candidate.goal.id,candidate.path.map(step=>({...step,rocketId:candidate.rocketId})),free?allowance:0);
        if(timing.comparable){
          const feasible=timing.alternatives.filter(a=>!a.prefixLength||a.prefixMovementPoints<=allowance);
          const best=feasible.reduce((best,a)=>a.totalPaidPoints<best.totalPaidPoints?a:best);
          timing={...timing,availablePrefixPoints:allowance,bestPrefixLength:best.prefixLength,bestTotalPaidPoints:best.totalPaidPoints,
            classification:best.prefixLength?'advance-before-rotation':'defer'};
        }
        if(!timing.comparable||!timing.bestPrefixLength){
          deferredGoal ||= {...candidate.goal,timing:'defer',movementTiming:timing};continue;
        }
        const path=candidate.path.slice(0,timing.bestPrefixLength);
        // A speculative rotation cannot justify exhausting the fee of a
        // funded landing at the probe's current planet after the main action.
        if(!free&&!hasExpiringMovement&&state.turn.roundNumber===4&&ships.length===1
          &&(ships[0].kind||'standard')==='standard'&&!ships[0].fossilId){
          const current=goals.find(g=>!g.path.length&&g.goal.kind==='land'&&g.goal.endpointTarget?.type==='planet'
            &&g.goal.endpointCost.energy>0&&players.canAfford(owner,g.goal.endpointCost));
          if(current){
            const cardsToMove=owner.hand.reduce((n,c)=>n+(!c.hidden?cards.getDiscardActionMoveRewardForCard(c)?.movementPoints||0:0),0);
            const minEnergy=Math.max(0,path.reduce((n,s)=>n+s.requiredMovePoints,0)-cardsToMove);
            if(minEnergy>owner.resources.energy-current.goal.endpointCost.energy){
              if(objectiveOnly)return null;
              return {...result(null,null,'reserve-funded-current-landing',routingNodes,goals.length),
                deferredGoal:{...current.goal,timing:'defer'}};
            }
          }
        }
        executable={...candidate,path,goal:{...candidate.goal,targetCoordinate:candidate.goal.coordinate,coordinate:path[path.length-1].to,
          timing:'advance-before-rotation',movementTiming:timing}};
      }
      chosen=executable;break;
    }
    if(!chosen&&deferredGoal){
      if(objectiveOnly)return null;
      return {...result(null,free?stop:null,'defer-movement',routingNodes,goals.length),deferredGoal};
    }
    if(objectiveOnly)return chosen?{routingNodes,intent:{goal:chosen.goal,rocketId:chosen.rocketId,path:chosen.path,startedTurn:chosen.startedTurn,startedRound:chosen.startedRound,free:chosen.free,prefixOnly:chosen.prefixOnly===true}}:null;
    return result(chosen||null,chosen?.selected||(free?stop:null),chosen?'selected-objective':'no-affordable-objective',routingNodes,goals.length);
  }
  const __planetQueries={builds:0,reuses:0,skippedUnusableVisitQuotes:0};
  return Object.freeze({VERSION,diagnosticPlanetQueries:()=>({...__planetQueries}),isDirection:direction,knownSatellitePickup,knownSatelliteSectorCount,movementAllowance:(head,state)=>cardPlay.getMovementAllowance(head,state),plan});
});
