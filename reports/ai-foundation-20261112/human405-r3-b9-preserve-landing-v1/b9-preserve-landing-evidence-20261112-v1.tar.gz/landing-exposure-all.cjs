'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const read=f=>JSON.parse(fs.readFileSync(f)),seat='player-white',solar=require(path.resolve('randomizer/solar-system/core')),native=require(path.resolve('randomizer/game/production-kernel'));
const base=read('reports/iteration/free-analyze-random20-funded-planet-20261111/summary-463fc442-20261111.json');
const rows=[];
for(const r of base.rows){
 const rec=read('reports/research/'+r.f),cp=read(rec.roundEnds[2].checkpointPath),game=read(rec.savePath),m=open(cp.coreState.compositionEnvelope);
 const cuts=[];
 try{
  for(let i=cp.replayCursor.stepIndex;i<game.replaySteps.length;i++){
   const a=game.replaySteps[i].action;
   if(a.actorId===seat&&true&&!m.c.inspect().session){
    const state=m.state(),p=state.players.players.find(x=>x.id===seat);
    const probe=state.pieces.rockets.filter(q=>q.playerId===seat);
    if(p.mainActionCompleted&&probe.length===1&&(probe[0].kind||'standard')==='standard'&&!probe[0].fossilId&&p.resources.energy>0
      &&solar.resolveVisibleContent(probe[0].sectorX,probe[0].sectorY,state.solarSystem).content.kind==='planet'){
      const ship=probe[0],local=native.getProbeRouteRequirements(state,seat).candidates.find(c=>c.rocketId===ship.id&&c.endpointFamily==='land'
       &&c.endpointTarget.type==='planet'&&!c.path.length&&c.required.energy>0&&c.required.energy<=p.resources.energy&&c.required.credits<=p.resources.credits);
      if(local&&m.menu().some(a=>a.family==='move'))
        cuts.push({input:i+1,actual:a,root:m.save(),assets:short(m),local:local.requirementId});
    }
   }
   m.apply(a);
  }
 }finally{m.dispose();}
 rows.push({board:r.board,record:r.f,cuts});
}
console.log(JSON.stringify(rows.filter(r=>r.cuts.length).map(r=>[r.board,r.cuts.map(x=>x.input)])));
writeZ(process.argv[2],{rows});
