'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),original=require.extensions['.js'];
const [which,cutsFile,targetFile,out]=process.argv.slice(2);
if(which==='base')require.extensions['.js']=(m,p)=>p===path.resolve('randomizer/game/ai/goal-movement.js')?m._compile(fs.readFileSync(path.join(__dirname,'before-goal-movement.js'),'utf8'),p):original(m,p);
const {open,readZ,writeZ}=require('./controlled-r3'),rows=[],seat='player-white';
function compare(label,e){
 const m=open(e);
 try{
  const u=m.automatic();
  assert(u.complete&&u.n<=256&&u.ms<=600);
  return {label,root:e,action:u.a,complete:u.complete,n:u.n,ms:u.ms,value:u.value,roots:u.roots,view:m.owner(seat),menu:m.menu(),reason:u.lines[0].movementPolicy?.reason};
 }finally{m.dispose();}
}
for(const r of readZ(cutsFile).rows)for(const c of r.cuts)rows.push(compare(`board${r.board}:${c.input}`,c.root));
const d=[];console.log(JSON.stringify({rows:rows.map(r=>[r.label,r.action.summary,r.n,r.ms,r.value]),d:d.map(r=>[r.label,r.action.summary,r.n,r.ms,r.value,r.reason])}));
writeZ(out,{rows,d});
