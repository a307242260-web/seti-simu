'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const source=readZ(__dirname+'/late-orange-asteroid-v457-20261112-v1.json.gz');
const seat='player-white',rows=[];
const k=require(require('node:path').resolve('randomizer/game/production-kernel'));
const m=open(source.rows[0].start);
try{
 for(const base of source.rows){
  m.restore(base.start);
  const nebulaId=null;
  const plan=k.getProbeRouteRequirements(m.state(),seat).candidates.find(r=>r.rocketId===6&&r.planetId==='saturn'&&r.endpointFamily==='land');
  assert.equal(plan.required.energy,5);
  const prefix=[];
  for(const step of plan.path){
   prefix.push(m.act('move',a=>a.target.rocketId===6&&a.target.deltaX===step.deltaX&&a.target.deltaY===step.deltaY));
   prefix.push(m.act('choose_payment',a=>a.target.choiceId==='energy'));
  }
  const endpoint=k.getProbeRouteRequirements(m.state(),seat).candidates.find(r=>r.rocketId===6&&r.planetId==='saturn'&&r.endpointFamily==='land');
  assert.equal(endpoint.path.length,0);
  prefix.push(m.act('land',a=>a.target.planetId==='saturn'||a.target.select));
  if(m.menu().some(a=>a.target.planetId==='saturn'))
   prefix.push(m.act('choose_target',a=>a.target.planetId==='saturn'));
  const assets=short(m),start=m.save(),actions=[],checks=[],main=[];let stop,cp;
  for(let i=0;i<240;i++){
   if(m.state().turn.gameEnded){stop={kind:'terminal'};break;}
   if(m.menu()[0].actorId!==seat){m.advanceOpponents(actions);continue;}
   const u=m.automatic(cp),a=u.a,x={n:u.n,ms:u.ms,complete:u.complete,value:u.value,a:a?.summary};
   if(!a||!u.complete||u.n>256||u.ms>600){stop={kind:'gate',...x,root:m.save(),roots:u.roots};break;}
   if(a.phase==='main')main.push([m.facts().turn,a.family,a.summary,a.target]);
   cp=u.checkpoint;checks.push(x);actions.push(m.apply(a));
  }
  assert(stop);
  const end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore;
  m.restore(base.start);[...prefix,...actions].forEach(m.apply);assert.deepEqual(m.save(),end);
  const peak=[Math.max(0,...checks.map(x=>x.n)),Math.max(0,...checks.map(x=>x.ms))];
  console.log(JSON.stringify({reserve:base.reserve,nebulaId,terminal,assets,main,peak,stop:{...stop,root:undefined,roots:undefined}}));
  rows.push({reserve:base.reserve,opening:base.start,nebulaId,start,assets,prefix,actions,checks,main,stop,end,terminal,peak});
 }
 writeZ(process.argv[2],{rows});
}finally{m.dispose();}
