'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [file,out]=process.argv.slice(2),seat='player-white';
const source=readZ(file).rows.find(r=>r.label==='known-data-late-orange1');
const origin=source.settled.state,rows=[];
const m=open(origin);
try{
 assert.deepEqual(JSON.parse(JSON.stringify(short(m))),source.settled.summary);
 for(const reserve of ['b_111.webp','b_32.webp']){
  m.restore(origin);const actions=[],checks=[],main=[];
  actions.push(m.act('pass'));actions.push(m.act('choose_card',a=>a.target.kind==='pass-reserve-card'&&a.target.cardId===reserve));
  if(m.menu()[0].actorId!==seat)m.advanceOpponents(actions);
  const start=m.save(),assets=short(m);
  let stop,cp;
  for(let i=0;i<240;i++){
   if(m.state().turn.gameEnded){stop={kind:'terminal'};break;}
   if(m.menu()[0].actorId!==seat){m.advanceOpponents(actions);continue;}
   const u=m.automatic(cp),a=u.a,x={n:u.n,ms:u.ms,complete:u.complete,value:u.value,a:a?.summary};
   if(i===0)console.log(JSON.stringify({reserve,first:x,assets}));
   if(!a||!u.complete||u.n>256||u.ms>600){stop={kind:'gate',...x,root:m.save(),roots:u.roots};break;}
   if(a.phase==='main')main.push([m.facts().turn,a.family,a.summary,a.target]);
   cp=u.checkpoint;checks.push(x);actions.push(m.apply(a));
  }
  assert(stop);
  const end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore;
  m.restore(origin);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  const peak=[Math.max(0,...checks.map(x=>x.n)),Math.max(0,...checks.map(x=>x.ms))];
  console.log(JSON.stringify({reserve,terminal,stop:{...stop,root:undefined,roots:undefined},main,peak}));
  rows.push({reserve,start,assets,actions,checks,main,stop,end,terminal,peak});
 }
 writeZ(out,{origin,assets:source.settled.summary,rows});
}finally{m.dispose();}
