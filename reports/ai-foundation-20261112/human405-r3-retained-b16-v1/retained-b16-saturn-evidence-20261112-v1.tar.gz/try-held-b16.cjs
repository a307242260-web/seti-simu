'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const source=readZ(__dirname+'/late-orange-asteroid-v457-20261112-v1.json.gz');
const seat='player-white',rows=[];
const base=source.rows.find(x=>x.reserve==='b_32.webp');
const m=open(base.start);
try{
 for(const nebulaId of ['sector-2-a','sector-1-a']){
  m.restore(base.start);
  const prefix=[m.play('b_16.webp'),m.act('choose_target',a=>a.target.rocketId===6&&a.target.deltaX===-1)];
  assert.equal(m.facts().wallet.energy,5);
  prefix.push(m.act('choose_target',a=>a.target.nebulaId===nebulaId));
  const assets=short(m),start=m.save(),actions=[],checks=[],main=[];let stop,cp;
  for(let i=0;i<240;i++){
   if(m.state().turn.gameEnded){stop={kind:'terminal'};break;}
   if(m.menu()[0].actorId!==seat){m.advanceOpponents(actions);continue;}
   const u=m.automatic(cp),a=u.a,x={n:u.n,ms:u.ms,complete:u.complete,value:u.value,a:a?.summary};
   if(!a||!u.complete||u.n>256||u.ms>600){stop={kind:'gate',...x,root:m.save(),roots:u.roots};break;}
   if(a.phase==='main')main.push([m.facts().turn,a.family,a.summary,a.target]);
   cp=u.checkpoint;checks.push(x);actions.push(m.apply(a));
  }
  assert(stop);
  const end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore;
  m.restore(base.start);[...prefix,...actions].forEach(m.apply);assert.deepEqual(m.save(),end);
  const peak=[Math.max(0,...checks.map(x=>x.n)),Math.max(0,...checks.map(x=>x.ms))];
  console.log(JSON.stringify({nebulaId,terminal,assets,main,peak,stop:{...stop,root:undefined,roots:undefined}}));
  rows.push({nebulaId,start,assets,prefix,actions,checks,main,stop,end,terminal,peak});
 }
 writeZ(process.argv[2],{opening:base.start,rows});
}finally{m.dispose();}
