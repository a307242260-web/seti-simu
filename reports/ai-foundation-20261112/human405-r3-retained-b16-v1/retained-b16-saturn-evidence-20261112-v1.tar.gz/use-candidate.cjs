'use strict';
const fs=require('node:fs'),path=require('node:path'),orig=require.extensions['.js'];
require.extensions['.js']=(m,p)=>p===path.resolve('randomizer/game/ai/analysis-port.js')
 ?m._compile(fs.readFileSync(path.join(__dirname,'candidate-analysis-port.js'),'utf8'),p):orig(m,p);
