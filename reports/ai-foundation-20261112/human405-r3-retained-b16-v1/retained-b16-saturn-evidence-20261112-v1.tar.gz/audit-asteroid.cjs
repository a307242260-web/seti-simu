'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),file=path.resolve('randomizer/game/ai/analysis-port.js');
const dir=__dirname, variant=process.argv[3];
let js=fs.readFileSync(path.join(dir,variant==='base'?'before-analysis-port.js':'candidate-analysis-port.js'),'utf8');
const raw=[];
if(variant!=='base'){
 const unique=(a,b)=>{assert.equal(js.split(a).length,2);js=js.replace(a,b);};
 unique('      let actionEvents=[{type:"scanAction4Skipped",playerId:seatId}];','      let isQuietAsteroid=false;\n      let actionEvents=[{type:"scanAction4Skipped",playerId:seatId}];');
 unique('          const arrival=residualSession.augmentEffectResult(next,{ok:true,events:actionEvents},head);','          isQuietAsteroid=quietAsteroid;\n          const arrival=residualSession.augmentEffectResult(next,{ok:true,events:actionEvents},head);');
 unique('        return {next,barrier};\n      }\n\n      // The first scan has','        return {next,barrier,isQuietAsteroid};\n      }\n\n      // The first scan has');
 const start=js.indexOf('    function previewQuietScan4Action('),end=js.indexOf('\n    function ',start+15);
 const body=js.slice(start,end);
 assert.match(body,/return \{prepared:\{envelope:withEnvelopeSession/);
 js=js.slice(0,start)+body.replace(/return \{prepared:\{envelope:withEnvelopeSession/g,'return {isQuietAsteroid,prepared:{envelope:withEnvelopeSession')+js.slice(end);
 unique('        if(requested.target.mode==="move")provedScan4QuietMoves++;','        if(scanAction.isQuietAsteroid)globalThis.recordAsteroid(stored.envelope,requested,nodes.get(child),child);\n        if(requested.target.mode==="move")provedScan4QuietMoves++;');
}
const orig=require.extensions['.js'];require.extensions['.js']=(m,p)=>p===file?m._compile(js,p):orig(m,p);
const {open,readZ,writeZ}=require('./controlled-r3');
globalThis.recordAsteroid=(e,a,pred,child)=>raw.push({e,a,envelope:pred.envelope,barrier:pred.informationBarrier,status:child.status,menu:child.legalActions});
const first=readZ(dir+'/late-orange-v457-20261112-v1.json.gz'),rows=[];
for(const row of first.rows){
 const m=open(row.start);
 try{
  const n=raw.length,u=m.automatic();
  rows.push({reserve:row.reserve,n:u.n,ms:u.ms,a:u.a.actionId,value:u.value,complete:u.complete,roots:u.roots,lines:u.lines,newWitnesses:raw.length-n});
 }finally{m.dispose();}
}
const normal=(env)=>{
 const ns=env.session?.session?.sessionId||'__none__';
 const n=JSON.parse(JSON.stringify(env).split(ns).join('effect-session-X'));
 if(n.session?.session)n.session.session.undoFrames=[];
 return n;
};
for(const w of raw){
 const m=open(w.e);
 try{
  m.apply(w.a);const native=m.save(),a=normal(native),b=normal(w.envelope);
  assert.deepEqual(JSON.parse(a.committedState),JSON.parse(b.committedState));
  assert.deepEqual(a.session,b.session);
  if(w.status==='decision')assert.deepEqual(w.menu,m.menu());
  if(native.session?.session?.irreversibleBarrier)assert.equal(w.barrier?.code,native.session.session.irreversibleBarrier.code);
 }finally{m.dispose();}
}
console.log(JSON.stringify(rows.map(r=>[r.reserve,r.n,r.ms,r.complete,r.newWitnesses])));
writeZ(process.argv[2],{rows,witnesses:raw});
