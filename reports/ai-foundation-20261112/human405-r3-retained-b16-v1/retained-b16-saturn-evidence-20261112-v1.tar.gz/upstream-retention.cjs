'use strict';
const assert=require('node:assert/strict'),{open,readZ,short,writeZ}=require('./controlled-r3');
const src=readZ(process.argv[2]),caseRow=src.rows.find(x=>x.label==='known-data-late-orange1');
const m=open(src.root),rows=[];
try{
 for(const [i,a] of caseRow.prefix.entries()){
  const before=m.save(),u=m.automatic(),legal=m.menu();
  assert(legal.some(x=>x.actionId===a.actionId));assert(u.complete&&u.n<=256&&u.ms<=600);
  const alternatives=u.roots.filter(x=>x.actionId===a.actionId);
  const hit=u.a.actionId===a.actionId;
  const row={i,action:a,chosen:u.a,value:u.value,alternatives,assets:short(m),root:before,n:u.n,ms:u.ms};
  rows.push(row);
  if(!hit)console.log(JSON.stringify({i,a:a.summary,chosen:u.a.summary,value:u.value,alternate:alternatives.map(x=>[x.value,x.completion]),assets:row.assets.wallet}));
  m.apply(a);
 }
 assert.deepEqual(m.save(),caseRow.start);
 writeZ(process.argv[3],{origin:src.root,final:m.save(),rows});
}finally{m.dispose();}
