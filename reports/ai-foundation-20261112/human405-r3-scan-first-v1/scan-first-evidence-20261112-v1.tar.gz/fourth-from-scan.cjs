'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [input,out,keep]=process.argv.slice(2),src=readZ(input),seat='player-white',rows=[];
const opponents={preferredReserve:{'player-green':'b_138.webp','player-blue':'b_55.webp','player-brown':'dlc_12.png'},version:'seti-human405-pass-only-teacher-r3-v1'};
for(const arm of src.rows){
 const root=arm.result.settled.state,m=open(root,opponents),prefix=[],actions=[],checks=[];let cp,stop,start;
 try{
  prefix.push(m.act('pass'));if(m.menu()[0].actorId!==seat)m.advanceOpponents(prefix);
  const a=m.menu().find(a=>a.target?.kind==='pass-reserve-card'&&a.summary===keep);
  assert(a,JSON.stringify(m.menu().map(x=>x.summary)));prefix.push(m.apply(a));
  if(m.menu()[0].actorId!==seat)m.advanceOpponents(prefix);
  start=short(m);assert.equal(m.facts().round,4);
  for(let i=0;i<240;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!==seat){m.advanceOpponents(actions);continue;}
   const u=m.automatic(cp),a=u.a,x={n:u.n,ms:u.ms,complete:u.complete,value:u.value,a:a?.summary};
   if(!u.complete||!a||u.n>256||u.ms>600){stop={gate:x,root:m.save()};break;}
   cp=u.checkpoint;checks.push(x);actions.push(m.apply(a));
  }
  assert(stop);
  const end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)??null;
  m.restore(root);prefix.forEach(m.apply);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  const peak=[Math.max(...checks.map(x=>x.n),0),Math.max(...checks.map(x=>x.ms),0)];
  rows.push({arm:arm.arm,root,prefix,start,actions,checks,peak,stop,terminal,end});
  console.log(JSON.stringify({arm:arm.arm,keep,score:terminal?.totalScore,scoreParts:terminal&&[terminal.baseScore,terminal.tileScore,terminal.cardScore],start,peak,stop:stop.gate||stop}));
 }finally{m.dispose();}
}
writeZ(out,{source:input,rows});
