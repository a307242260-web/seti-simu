'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ,autonomous}=require('./controlled-r3');
const [from,out,variant]=process.argv.slice(2),e=readZ(from),seat='player-white',rows=[];
const seq=e.steps.filter(x=>x.input>=141&&x.input<=146),source=seq[0].before,base=JSON.parse(source.committedState);
if(variant!=='base'){const [i,j]=variant.split(',').map(Number),d=base.cards.drawPileCardIds;assert(d[i]&&d[j]);[d[i],d[j]]=[d[j],d[i]];}
const root={...source,committedState:JSON.stringify(base)},options={preferredReserve:{'player-green':'b_138.webp','player-blue':'b_55.webp','player-brown':'dlc_12.png'},version:'seti-human405-pass-only-teacher-r3-v1'};
const m=open(root,options);
try{
 const menu=m.menu(),observation=m.owner(seat),u=m.automatic();assert(u.complete&&u.n<=256&&u.ms<=600);
 if(variant!=='base'){
  const baseline=readZ(out.replace('swap-'+variant,'base'));assert.deepEqual(menu,baseline.menu);assert.deepEqual(observation,baseline.observation);
  assert.equal(JSON.stringify(u.roots),JSON.stringify(baseline.q.roots));
  assert.deepEqual([u.a.actionId,u.n,u.value],[baseline.q.a.actionId,baseline.q.n,baseline.q.value]);
 }
 for(const [arm,prefix] of [['auto',[]],['first-scan',seq.slice(0,1)],['teacher-scan',seq]]){
  m.restore(root);const fixed=prefix.map(x=>m.apply(x.actual));
  const r=autonomous(m);m.restore(root);fixed.forEach(m.apply);r.actions.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),r.end);
  m.restore(root);
  const all=[...fixed,...r.actions.map(x=>x.action)],first=[];
  for(const a of all){m.apply(a);first.push({a:a.summary,s:short(m)});if(a.family==='end_turn')break;}
  rows.push({arm,fixed,first,result:r});
  const s=r.settled?.summary,peak=[Math.max(0,...r.actions.map(x=>x.n||0)),Math.max(0,...r.actions.map(x=>x.ms||0))];
  console.log(JSON.stringify({variant,arm,stop:r.stop,peak,first:first.map(x=>x.a),end1:first.at(-1)?.s,settled:s}));
 }
 writeZ(out,{root,menu,observation,q:{a:u.a,roots:u.roots,n:u.n,value:u.value},rows});
}finally{m.dispose();}
