'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ}=require('./controlled-r3');
const data=require(path.resolve('randomizer/game/data'));
const [from,out]=process.argv.slice(2),d=readZ(from),seat='player-white';
const arms=d.rows.filter(x=>x.arm.endsWith('scan')), rows=[];
for(const arm of arms){
 const m=open(d.root),first=[],r3=[];
 try{
  for(const a of [...arm.fixed,...arm.result.actions.map(x=>x.action)]){
   if(a.actorId===seat&&(a.phase==='main'||a.target?.nebulaId))r3.push([m.facts().turn,a.family,a.summary,m.facts().wallet.score]);
   m.apply(a);
   if(!first.length&&a.family==='end_turn'){
    assert.equal(m.save().session,null);
    const st=m.state(),p=m.player();
    const sectors=Object.keys(st.data.nebulae).filter(x=>x.startsWith('sector-')).map(x=>[x,data.listNebulaTokens(st.data,x).filter(t=>t.replacedByPlayerColor).map(t=>[t.slotIndex,t.replacedByPlayerColor])]);
    first.push({state:m.save(),sectors,visible:m.owner(seat)});
   }
  }
  assert.equal(first.length,1);
  rows.push({arm:arm.arm,first:first[0],r3});
 }finally{m.dispose();}
}
const [a,b]=rows.map(x=>JSON.parse(x.first.state.committedState));
function diff(a,b,keys=[],out=[]){
 if(JSON.stringify(a)===JSON.stringify(b))return out;
 if(a&&b&&typeof a==='object'&&typeof b==='object'){
  for(const k of new Set([...Object.keys(a),...Object.keys(b)]))diff(a[k],b[k],[...keys,k],out);
 }else out.push({keys,a,b});
 return out;
}
const differences=diff(a,b);
assert.deepEqual(a.meta.rngState,b.meta.rngState);
assert.deepEqual(a.cards,b.cards);
assert.deepEqual(a.players.players.find(x=>x.id===seat).resources,b.players.players.find(x=>x.id===seat).resources);
assert.deepEqual(a.turn,b.turn);
writeZ(out,{rows,differences});
console.log(JSON.stringify({differencePaths:differences.map(x=>x.keys.join('.')),r3:rows.map(x=>[x.arm,x.r3])}));
