'use strict';
const fs=require('node:fs'),{open,readZ,writeZ}=require('./controlled-r3');
const d=readZ(process.argv[2]);const rows=[];
for(const input of [141,142,143,144]){
 const m=open(d.steps.find(x=>x.input===input).before);
 try{
  const r=m.automatic(),options=r.roots.map(x=>({name:m.menu().find(y=>y.actionId===x.actionId)?.summary,...x})).filter(x=>Number.isFinite(x.value));
  rows.push({input,r,options});
  console.log(JSON.stringify({input,n:r.n,ms:r.ms,a:r.a.summary,v:r.value,options:options.map(x=>[x.name,x.value])}));
 }finally{m.dispose();}
}
writeZ(process.argv[3],{rows});
