'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const file=path.resolve('randomizer/game/ai/local-decision-plans.js'),code=fs.readFileSync(file,'utf8');
const match='&&p.resources.availableData===players.RESOURCE_LIMITS.availableData){\n   const available=actions.filter';
assert.equal(code.split(match).length,2);
const candidate=code.replace(match,match.replace('===players.RESOURCE_LIMITS.availableData','>=players.RESOURCE_LIMITS.availableData-1'));
const m=new Module(file,module);m.filename=file;m.paths=Module._nodeModulePaths(path.dirname(file));m._compile(candidate,file);m.loaded=true;require.cache[file]=m;
