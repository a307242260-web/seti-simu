'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const [from,out]=process.argv.slice(2),study=readZ(from),by=n=>study.cuts.find(x=>x.step===n),root=by(232).envelope;
const mode=process.argv[4]||'control',gate=q=>q.complete&&q.a&&q.n<=256&&q.ms<=600;
const m=open(root),a=m.automatic();
console.log(JSON.stringify({mode,action:a.a?.summary,complete:a.complete,n:a.n,ms:a.ms,v:a.value,roots:a.roots.filter(x=>x.value!=null).map(x=>[m.menu().find(a=>a.actionId===x.actionId)?.summary,x.value])}));
m.dispose();
if(mode==='candidate'){
 const evidence={root,comparison:{a:a.a,n:a.n,ms:a.ms,value:a.value,complete:a.complete,roots:a.roots},row:null};
 if(gate(a))evidence.row=runCases(root,[['candidate-autonomous',()=>{}]]);
 writeZ(out,evidence);
}else{
 assert(gate(a));const cases=[['current-autonomous',()=>{}]];
 for(const cut of [234,235,238,243])cases.push(['teacher-prefix-to-'+cut,({m,take})=>{
   study.timeline.slice(by(232).at,by(cut).at).forEach(a=>take(m.apply(a)));const normalize=e=>JSON.parse(JSON.stringify(e).replace(/effect-session-\d+/g,'effect-session-X'));assert.deepEqual(normalize(m.save()),normalize(by(cut).envelope),'same rule state and session structure');
 }]);
 const d=runCases(root,cases);assert.equal(d.failures.length,0);writeZ(out,{root,comparison:{a:a.a,n:a.n,ms:a.ms,value:a.value,roots:a.roots},...d});
}
