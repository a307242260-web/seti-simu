'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),{open,writeZ,short,runCases}=require('./controlled-r3');
const [record,checkpoint,expected,out]=process.argv.slice(2),read=f=>JSON.parse(fs.readFileSync(f));
const {rows}=read(record),extract=f=>read(f).coreState.compositionEnvelope,origin=extract(checkpoint),m=open(origin);
const relevant=new Set([185,199,202,207,220,223,228,231,232,234,235,237,238,239,240,241,242,243,244]),cuts=[];
const compare=q=>({action:q.a?.summary,value:q.value,n:q.n,ms:q.ms,complete:q.complete});
const timeline=[];
try{
 for(const row of rows){
  const step=row.historicalInput??row.input;
  const menu=m.menu(),a=menu.find(a=>a.actionId===row.action.actionId&&a.actorId===row.action.actorId);
  if(!a)throw new Error(JSON.stringify({step,wanted:row.action.summary,menu:menu.map(x=>x.summary)}));
  if(relevant.has(step)){
   const envelope=m.save(),q=m.automatic(),roots=q.roots?.map(x=>({a:menu.find(a=>a.actionId===x.actionId)?.summary,v:x.value})).filter(x=>x.v!=null);
   const r={step,at:timeline.length,envelope,actual:a.summary,comparison:compare(q),value:roots?.find(x=>x.a===a.summary)?.v,roots,assets:short(m)};
   cuts.push(r);console.log(JSON.stringify({...r,envelope:undefined,roots:undefined}));
  }
  timeline.push(m.apply(a));
 }
 const end=m.save(),teacher=extract(expected);
 assert.deepEqual(JSON.parse(end.committedState),JSON.parse(teacher.committedState));assert.deepEqual(end.session,teacher.session);
 const final=short(m);
 m.restore(origin);timeline.forEach(m.apply);assert.deepEqual(m.save(),end);
 writeZ(out,{origin,cuts,timeline,end,final});
 console.log(JSON.stringify({verifiedExact:true,final}));
}finally{m.dispose();}
