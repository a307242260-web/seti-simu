'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [old,newer,teacher,out]=process.argv.slice(2),seat='player-white',rows=[];
const roots=[
 ['trade',readZ(old).rows[0].end],
 ['income',readZ(newer).row.rows[0].end],
 ['teacher-retained',readZ(teacher).end],
];
for(const [label,root] of roots){
 const m=open(root),actions=[],checks=[],cuts=[];
 let cp,stop;
 try{
  if(label==='teacher-retained'){
   actions.push(m.act('pass'));
   if(m.menu()[0].actorId!==seat)m.advanceOpponents(actions);
   actions.push(m.act('choose_card',a=>a.summary==='b_111.webp'));
   if(m.menu()[0].actorId!==seat)m.advanceOpponents(actions);
  }
  assert.equal(m.facts().round,4);const opening=short(m);
  for(let i=0;i<175;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!==seat){m.advanceOpponents(actions);continue;}
   const q=m.automatic(cp);
   if(!q.complete||!q.a||q.n>256||q.ms>600){stop={gate:{n:q.n,ms:q.ms,action:q.a?.summary,complete:q.complete}};break;}
   cp=q.checkpoint;checks.push({n:q.n,ms:q.ms});actions.push(m.apply(q.a));
   if(q.a.family==='end_turn')cuts.push(short(m));
  }
  assert(stop);const end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore??null;
  m.restore(root);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  const peak=[Math.max(0,...checks.map(x=>x.n)),Math.max(0,...checks.map(x=>x.ms))];
  rows.push({label,root,end,opening,actions,checks,cuts,stop,peak,terminal});
  console.log(JSON.stringify({label,terminal,peak,stop,opening}));
 }finally{m.dispose();}
}
writeZ(out,{rows});
