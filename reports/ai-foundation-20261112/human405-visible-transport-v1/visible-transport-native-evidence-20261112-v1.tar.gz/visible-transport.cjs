'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const [from,out]=process.argv.slice(2),study=readZ(from),cut=study.cuts.find(x=>x.step===228),seat='player-white';
const m=open(cut.envelope);m.apply(study.timeline[cut.at]);
const root=m.save(),q=m.automatic(),menu=m.menu();
assert(q.complete&&q.n<=256&&q.ms<=600);
console.log(JSON.stringify({menu:menu.map(a=>[a.summary,a.target]),root:short(m),q:q.a.summary,value:q.value,
 roots:q.roots.filter(x=>x.value!=null).map(x=>[menu.find(a=>a.actionId===x.actionId)?.summary,x.value])}));
m.dispose();
const pickVisible=({m,act})=>act('choose_card',a=>a.target.source==='display'&&a.summary==='获得展示的虫');
const pickBlind=({m,act})=>act('choose_card',a=>a.target.source==='blind');
function followVisible({m,act,cut}){
 pickVisible({m,act});act('end_turn');
 act('accept_optional_effect',a=>a.summary==='结算 dlc_9.png');
 cut('visible-next-main');
}
function income({m,act,cut}){
 followVisible({m,act,cut});
 act('place_data');act('choose_target',a=>a.target.target==='computer');act('choose_card',a=>a.summary==='收入 chong_7.webp');
 cut('one-credit');
}
const scenarios=[
 ['blind-autonomous',pickBlind],['visible-autonomous',pickVisible],['visible-with-cash-income',income],
 ['visible-cash-then-inspect',({m,act,cut,take})=>{
  income({m,act,cut});
  act('play_card',a=>a.summary==='chong_2.webp');cut('inspect-decision');
  console.log(JSON.stringify({inspection:m.menu().map(a=>[a.summary,a.target]),assets:short(m)}));
  const money=m.menu().find(a=>a.target.fossilId&&a.summary.includes('信用点'));
  if(money)take(m.apply(money));
  cut('after-inspection');
 }]
];
const results=runCases(root,scenarios);
writeZ(out,{root,menu,comparison:{choice:q.a.summary,value:q.value,n:q.n,ms:q.ms,roots:q.roots},results});
