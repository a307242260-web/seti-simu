'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [from,out]=process.argv.slice(2),seat='player-white',rows=[];
for(const r of readZ(from).rows){
 assert(!r.error,r.error);const m=open(r.end),actions=[],checks=[],frames=[];
 let cp,stop;
 try{
  actions.push(m.act('pass'));
  if(m.menu()[0].actorId!==seat)m.advanceOpponents(actions);
  actions.push(m.act('choose_card',a=>a.summary==='b_111.webp'));
  if(m.menu()[0].actorId!==seat)m.advanceOpponents(actions);
  const start=short(m);
  for(let i=0;i<200;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!==seat){m.advanceOpponents(actions);continue;}
   const q=m.automatic(cp);
   if(!q.complete||!q.a||q.n>256||q.ms>600){stop={gate:{action:q.a?.summary,n:q.n,ms:q.ms}};break;}
   cp=q.checkpoint;checks.push({n:q.n,ms:q.ms});
   if(q.a.family==='pass')frames.push(short(m));
   actions.push(m.apply(q.a));
  }
  assert(stop);const end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore??null;
  m.restore(r.end);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  const peak=[Math.max(0,...checks.map(x=>x.n)),Math.max(0,...checks.map(x=>x.ms))];
  rows.push({fossil:r.fossil,root:r.end,end,start,frames,actions,checks,peak,terminal,stop});
  console.log(JSON.stringify({fossil:r.fossil,terminal,stop,peak,start}));
 }finally{m.dispose();}
}
writeZ(out,{rows});
