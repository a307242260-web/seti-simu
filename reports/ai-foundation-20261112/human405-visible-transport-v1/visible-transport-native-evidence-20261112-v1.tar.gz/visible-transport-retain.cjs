'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [from,out]=process.argv.slice(2),f=readZ(from),control=f.results.rows.find(x=>x.label==='visible-cash-then-inspect');
const source=control.checkpoints['after-inspection'].state,seat='player-white',rows=[];
for(const fossil of ['fossil_07','fossil_06','fossil_01']){
 const m=open(source),actions=[],cold=[],facts=[];
 const take=a=>{assert(a,JSON.stringify(m.menu().map(a=>a.summary)));actions.push(m.apply(a));};
 const choose=p=>take(m.menu().find(a=>typeof p==='string'?a.summary===p:p(a)));
 const observe=(phase)=>{const o=m.owner(seat);facts.push({phase,assets:short(m),offer:o.publicState.board.aliens.chongOffer?.displayedCardIndex});};
 const quote=phase=>{const q=m.automatic();assert(q.complete&&q.n<=256&&q.ms<=600);cold.push({phase,n:q.n,ms:q.ms,value:q.value,action:q.a?.summary});};
 try{
  choose('结束回合');observe('funded');quote('funded');
  choose('chong_9.webp');
  choose(a=>a.target.landTarget?.satelliteId==='titan');observe('after-landing');quote('after-landing');
  choose(a=>a.target.alienSlotId===2&&a.target.traceType==='yellow'&&a.target.position===4);
  observe('first-offer');choose(a=>a.family==='choose_card'&&a.target.source==='display');
  if(m.menu().some(a=>a.summary==='结算 amiba_0.webp'))choose('结算 amiba_0.webp');
  choose(a=>a.target.alienSlotId===2&&a.target.traceType==='yellow'&&a.target.position===3);
  observe('second-offer');choose(a=>a.family==='choose_card'&&a.target.source==='display');
  choose(a=>a.target.fossilId===fossil);
  choose('结束回合');
  const beforePass=short(m),end=m.save();assert(m.menu().some(a=>a.family==='pass'));
  m.restore(source);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  rows.push({fossil,source,actions,beforePass,end,facts,cold});
  console.log(JSON.stringify({fossil,beforePass,cold,actions:actions.map(a=>a.summary)}));
 }catch(e){rows.push({fossil,source,actions,error:String(e),at:short(m)});console.log(JSON.stringify({fossil,error:String(e),actions:actions.map(a=>a.summary)}));}finally{m.dispose();}
}
writeZ(out,{rows});
