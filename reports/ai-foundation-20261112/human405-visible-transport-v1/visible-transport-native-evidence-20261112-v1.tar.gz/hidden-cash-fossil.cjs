'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [from,out]=process.argv.slice(2),f=readZ(from),path=f.results.rows.find(x=>x.label==='visible-cash-then-inspect');
const root=path.checkpoints['one-credit'].state,seat='player-white',rows=[];
const original=open(root),before=original.owner(seat),legal=original.menu();original.dispose();
const options=[null,'fossil_02','fossil_05'];
for(const other of options){
 const s=JSON.parse(root.committedState),ch=s.aliens.chong,money='fossil_07';
 if(other){
  const a=ch.planetFossilIds.jupiter,b=ch.planetFossilIds.saturn;
  assert(a.includes(other)&&b.includes(money));
  a[a.indexOf(other)]=money;b[b.indexOf(money)]=other;
  ch.fossilsById[money].planetId='jupiter';ch.fossilsById[other].planetId='saturn';
  const order=ch.initialConfiguration.fossilOrder,i=order.indexOf(money),j=order.indexOf(other);
  [order[i],order[j]]=[order[j],order[i]];
 }
 const envelope=other?{...root,committedState:JSON.stringify(s)}:root,m=open(envelope),actions=[];
 try{
  assert.deepEqual(m.owner(seat),before);assert.deepEqual(m.menu(),legal);
  const q=m.automatic();assert(q.complete&&q.n<=256&&q.ms<=600);
  const quote={a:q.a.summary,value:q.value,n:q.n,roots:q.roots.map(r=>[r.actionId,r.value])};
  actions.push(m.act('play_card',a=>a.summary==='chong_2.webp'));
  const inspection=m.menu().map(a=>({summary:a.summary,fossilId:a.target.fossilId}));
  const money=m.menu().find(a=>a.summary.includes('2信用点'));
  if(money)actions.push(m.apply(money));
  const end=m.save(),assets=short(m);m.restore(envelope);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  rows.push({other,envelope,quote,inspection,actions,end,assets});
  console.log(JSON.stringify({other,quote:quote.a,value:quote.value,n:quote.n,inspection,credits:assets.wallet[1]}));
 }finally{m.dispose();}
}
assert(rows.slice(1).every(r=>JSON.stringify(r.quote)===JSON.stringify(rows[0].quote)));
writeZ(out,{rows});
