'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const p=path.resolve('randomizer/game/ai/decision-search.js'),raw=fs.readFileSync(p,'utf8'),m=new Module(p,module);
m.filename=p;m.paths=Module._nodeModulePaths(path.dirname(p));
const key='    const elapsed = now() - startedAt;';
assert.equal(raw.split(key).length,2);
const code=raw.replace(key,`
    const profile={groups:{},states:{},first:[]},put=(box,k,n=1)=>box[k]=(box[k]||0)+n;
    for(const node of nodes){
      put(profile.states,node.node.status);
      for(const e of node.edges){
        const a=node.node.legalActions?.find(x=>x.actionId===e.actionId);
        const k=a?.family==='choose_target'&&a?.target?.traceType?'trace:'+a.target.traceType
          :a?.family==='choose_card'&&a.target?.source?'card:'+a.target.source:a?.family||e.actionId.split(':')[0];
        const r=resourceExecutions.get(e);
        put(profile.groups,k,r?.newSubmissions??e.cost);
        if(r)put(profile.groups,'resource:'+r.goal?.kind+':'+r.goal?.id,r.newSubmissions??e.cost);
      }
    }
    for(const edge of nodes[0].edges){
      const a=nodes[0].node.legalActions.find(x=>x.actionId===edge.actionId),seen=new Set(),queue=[edge.target];
      while(queue.length){
        const i=queue.pop();if(seen.has(i))continue;seen.add(i);queue.push(...nodes[i].edges.map(e=>e.target));
      }
      profile.first.push({first:a?.summary,goal:edge.resourcePlan?.goal?.id||null,cost:edge.cost,reachable:seen.size,
        children:[...seen].reduce((n,i)=>n+nodes[i].edges.length,0),value:nodes[edge.target].value});
    }
    globalThis.$visibleProfile=profile;
`+key);
m._compile(code,p);m.loaded=true;require.cache[p]=m;
const {open,readZ,writeZ,short}=require('./controlled-r3');
const [from,out]=process.argv.slice(2),data=readZ(from),rows=[];
for(const row of data.results.rows.filter(x=>x.stop?.kind==='gate')){
 const m=open(row.end);
 try{
  const result=m.automatic(),profile=globalThis.$visibleProfile;
  assert.deepEqual(m.save(),row.end);
  const evidence={label:row.label,root:row.end,assets:short(m),result:{n:result.n,ms:result.ms,a:result.a?.summary,value:result.value,complete:result.complete},profile};
  rows.push(evidence);
  console.log(JSON.stringify({...evidence,root:undefined,profile:{...profile,first:profile.first.sort((a,b)=>b.reachable-a.reachable).slice(0,10),groups:Object.entries(profile.groups).sort((a,b)=>b[1]-a[1]).slice(0,20)}}));
 }finally{m.dispose();}
}
writeZ(out,{rows});
