'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const p=path.resolve('randomizer/game/ai/analysis-port.js'),m=new Module(p,module);
m.filename=p;m.paths=Module._nodeModulePaths(path.dirname(p));
const key='      submissionCount += 1;';
const raw=fs.readFileSync(p,'utf8');
assert.equal(raw.split(key).length,2);
const inputs=[];
m._compile(raw.replace(key,`
      globalThis.$countNativeTransport?.(current, head);
`+key),p);
m.loaded=true;require.cache[p]=m;
globalThis.$countNativeTransport=(a,h)=>inputs.push({family:a.family,phase:a.phase,summary:a.summary,
  actionId:a.actionId,target:a.target,decision:h?.effect?.type||h?.decisionType||h?.type||null});
const {open,readZ,writeZ}=require('./controlled-r3');
const [from,out]=process.argv.slice(2),rows=[];
for(const row of readZ(from).results.rows.filter(x=>x.stop?.kind==='gate')){
 const m=open(row.end);inputs.length=0;
 try{
  const r=m.automatic();assert.deepEqual(m.save(),row.end);
  assert.equal(r.n,inputs.length);assert.equal(r.n,row.stop.n);
  const counts=Object.entries(inputs.reduce((acc,a)=>{acc[a.family]=(acc[a.family]||0)+1;return acc;},{})).sort((a,b)=>b[1]-a[1]);
  const summaries=Object.entries(inputs.reduce((acc,a)=>{const k=a.family+' '+a.summary;acc[k]=(acc[k]||0)+1;return acc;},{})).sort((a,b)=>b[1]-a[1]);
  rows.push({label:row.label,result:{action:r.a?.summary,n:r.n,ms:r.ms,value:r.value},counts,summaries,inputs:[...inputs]});
  console.log(JSON.stringify({label:row.label,n:r.n,counts,summaries:summaries.slice(0,12)}));
 }finally{m.dispose();}
}
writeZ(out,{rows});
