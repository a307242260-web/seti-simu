'use strict';
const assert=require('node:assert/strict'),{open,readZ,short,writeZ}=require('./controlled-r3');
const [from,out]=process.argv.slice(2),src=readZ(from),row=src.results.rows.find(x=>x.label==='visible-cash-then-inspect');
const start=row.checkpoints['inspect-decision'].state,rows=[];
const quote=m=>{
 const before=m.save(),r=m.automatic(),menu=m.menu();
 assert.deepEqual(m.save(),before);
 return {assets:short(m),complete:r.complete,n:r.n,ms:r.ms,a:r.a.summary,v:r.value,
  roots:r.roots.map(x=>({a:menu.find(a=>a.actionId===x.actionId)?.summary,v:x.value}))};
};
const m=open(start);
try{
 const reward=quote(m);
 for(const a of m.menu()){
  m.restore(start);const actions=[m.apply(a)],rewards=short(m);
  if(!a.target.fossilId){rows.push({reward:a.summary,rewards});continue;}
  const after=quote(m);
  actions.push(m.act('end_turn'));m.advanceOpponents(actions);
  const e=m.save(),next=quote(m);
  m.restore(start);actions.forEach(m.apply);assert.deepEqual(m.save(),e);
  rows.push({reward:a.summary,rewards,after,next,exact:true});
  console.log(JSON.stringify({reward:a.summary,after:{a:after.a,v:after.v,n:after.n},next:{a:next.a,v:next.v,n:next.n,ms:next.ms,complete:next.complete}}));
 }
 writeZ(out,{reward,rows});
}finally{m.dispose();}
