'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const [from,out,mode]=process.argv.slice(2);
const p=path.resolve('randomizer/game/ai/analysis-port.js'),m=new Module(p,module);
m.filename=p;m.paths=Module._nodeModulePaths(path.dirname(p));
const key='&&chong.getAvailablePlanetFossils(state.aliens,"saturn").some(f=>!f.visibleToPlayerIds?.includes(seatId));';
const raw=fs.readFileSync(p,'utf8');assert.equal(raw.split(key).length,2);
if(mode==='allow-visible'){
 m._compile(raw.replace(key,'&&chong.getAvailablePlanetFossils(state.aliens,"saturn").length>0;'),p);
 m.loaded=true;require.cache[p]=m;
}
const {open,readZ,writeZ,short}=require('./controlled-r3');
const rows=[];
for(const row of readZ(from).results.rows){
 const refs=row.stop?.kind==='gate'?[['gate',row.end]]:Object.entries(row.checkpoints).filter(([name])=>name==='after-inspection').map(([k,v])=>[k,v.state]);
 for(const [name,e] of refs){
  const k=open(e);
  try{
   const r=k.automatic();assert.deepEqual(k.save(),e);
   const q={case:row.label,name,n:r.n,ms:r.ms,complete:r.complete,value:r.value,action:r.a?.actionId,summary:r.a?.summary,assets:short(k)};
   rows.push(q);console.log(JSON.stringify({...q,assets:undefined}));
  }finally{k.dispose();}
 }
}
writeZ(out,{mode,rows});
