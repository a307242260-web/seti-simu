'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [from,teacher,summary,blind,out]=process.argv.slice(2),read=p=>JSON.parse(fs.readFileSync(p)),seat='player-white';
const check=m=>{
 const before=m.save(),r=m.automatic(),legal=m.menu();assert.deepEqual(m.save(),before);
 return {a:r.a?.summary,v:r.value,n:r.n,ms:r.ms,complete:r.complete,roots:r.roots.map(x=>[legal.find(a=>a.actionId===x.actionId)?.summary,x.value])};
};
const s=readZ(from).results.rows.find(x=>x.label==='visible-cash-then-inspect'),root=s.checkpoints['inspect-decision'].state;
const worlds=[];
for(const [id,e] of [['base',root],...readZ(blind).rows.slice(1).map(x=>[x.other,x.end])]){
 const m=open(e);
 try{const q=check(m);assert(q.complete&&q.n<=256&&q.ms<=600);assert.equal(q.a,id==='base'?'fossil_07：2信用点':'fossil_06：2能量');worlds.push({id,...q});}
 finally{m.dispose();}
}
const candidate=runCases(root,[['native-from-exposed-menu',()=>{}]]).rows[0];
assert.equal(candidate.actions[0].action.target.fossilId,'fossil_07');
assert.deepEqual(candidate.settled.state,s.settled.state);
const cuts=readZ(teacher).cuts,teacherRows=[];
for(const r of cuts){
 const m=open(r.envelope);
 try{
  const q=check(m);assert.deepEqual([q.a,q.v,q.n,q.complete],[r.comparison.action,r.comparison.value,r.comparison.n,r.comparison.complete]);
  assert(q.n<=256&&q.ms<=600);
  teacherRows.push({step:r.step,...q});
 }finally{m.dispose();}
}
const controls=[];
for(const {board,f} of [...read(summary).rows,{board:0,f:'b8f75432.0aee4a8e.quick-400.json'}]){
 const record=read(path.join('reports/research',f)),save=read(record.savePath);
 const cp=read(record.roundEnds[1].checkpointPath),m=open(cp.coreState.compositionEnvelope);
 const choices=[];
 try{
  for(let i=cp.replayCursor.stepIndex;i<record.roundEnds[2].beforeInput;i++){
   const move=save.replaySteps[i].action;
   const h=m.c.inspect().session;
   if(move.actorId===seat&&h?.decision?.choices.length>1&&h.decision.choices.every(a=>a.target?.choiceId?.startsWith('chong-reward:'))){
    const q=check(m);assert(q.complete&&q.n<=256&&q.ms<=600);
    choices.push({input:i+1,reference:move.summary,...q});
   }
   m.apply(move);
  }
  controls.push({board,choices});
 }finally{m.dispose();}
}
console.log(JSON.stringify({worlds,teacherRoots:teacherRows.length,controls:controls.map(c=>[c.board,c.choices]),r3:candidate.settled.summary}));
writeZ(out,{worlds,teacherRows,controls,candidate});
