'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,writeZ,short}=require('./controlled-r3');
const {createStateValueEvaluator}=require(path.resolve('randomizer/game/ai/state-value'));
const {buildRuleObservation}=require(path.resolve('randomizer/app/rule-observation'));
const {getFossilReward}=require(path.resolve('randomizer/game/aliens/chong'));
const [from,out]=process.argv.slice(2),study=readZ(from),seat='player-white',evaluate=createStateValueEvaluator(seat);
const row=study.results.rows.find(x=>x.label==='visible-cash-then-inspect');
const root=row.checkpoints['inspect-decision'].state, rows=[];
for(const trace of [[['yellow',2],['pink',2]],[['pink',2],['yellow',2]]]){
 const m=open(root),actions=[],frames=[],read=()=>evaluate(buildRuleObservation(m.state(),m.state().meta.seed,seat,[],{valueOnly:true}));
 const take=(name,test)=>{const a=m.menu().find(test);assert(a,name);actions.push(m.apply(a));frames.push([name,read(),short(m).wallet]);};
 try{
  take('reward',a=>a.target.fossilId==='fossil_07');
  take('end',a=>a.family==='end_turn');
  take('card',a=>a.summary==='chong_9.webp');
  take('target',a=>a.target.landTarget?.satelliteId==='titan');
  for(const [color,index] of trace){
   take('trace:'+color,a=>a.target.speciesId==='chong'&&a.target.traceType===color&&a.target.position===index);
   if(m.menu().some(a=>a.target.ruleId?.startsWith('amiba0-')))take('trigger',a=>a.target.ruleId?.startsWith('amiba0-'));
  }
  for(const a of m.menu())if(a.target.fossilId)console.log('pickup',a.summary,getFossilReward(a.target.fossilId));
  take('pick',a=>a.target.fossilId==='fossil_07');
  assert(!m.save().session);
  const end=m.save(),assets=short(m);
  m.restore(root);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  rows.push({trace,frames,assets,end,actions});
  console.log(JSON.stringify({trace,frames,assets}));
 }finally{m.dispose();}
}
writeZ(out,{rows});
