'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [source,out]=process.argv.slice(2),seat='player-white',rows=[];
for(const r of readZ(source).results.filter(x=>!x.label.includes('深空探测'))){
 const m=open(r.root),fixed=[];
 try{
  let reached=false;
  for(const {action:a} of r.rows.filter(x=>x.controlled)){
   if(a.family==='choose_card'&&a.summary==='b_16.webp'&&m.menu().some(x=>x.summary==='b_9.webp')){
    reached=true;break;
   }
   fixed.push(m.apply(a));
  }
  assert(reached);
  const root=m.save(),q=m.automatic(),a=m.menu().find(x=>x.summary==='b_9.webp'),before=short(m),opts=m.menu();
  assert(q.complete&&q.n<=256&&q.ms<=600);const inputs=[m.apply(a)],checks=[],turns=[];let cp,stop;
  for(let i=0;i<240;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!==seat){m.advanceOpponents(inputs);continue;}
   const u=m.automatic(cp),b=u.a,x={a:b?.summary,n:u.n,ms:u.ms,complete:u.complete,v:u.value};
   if(!u.complete||!b||u.n>256||u.ms>600){stop={gate:x,root:m.save()};break;}
   if(b.phase==='main')turns.push([m.facts().turn,b.summary]);
   cp=u.checkpoint;checks.push(x);inputs.push(m.apply(b));
  }
  assert(stop);const end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)??null;
  m.restore(r.root);fixed.forEach(m.apply);inputs.forEach(m.apply);assert.deepEqual(m.save(),end);
  const peak=[Math.max(q.n,...checks.map(x=>x.n)),Math.max(q.ms,...checks.map(x=>x.ms))];
  rows.push({label:r.label,card:r.card,fixed,root,opts,before,q:{a:q.a,value:q.value,roots:q.roots,n:q.n,ms:q.ms},a,inputs,checks,turns,stop,end,terminal,peak});
  console.log(JSON.stringify({label:r.label,card:r.card,automatic:q.a.summary,q:q.value,options:q.roots.map(x=>[opts.find(a=>a.actionId===x.actionId)?.summary,x.value,x.completion]),peak,stop:stop.gate||stop,terminal:terminal?.totalScore,turns}));
 }finally{m.dispose();}
}
writeZ(out,{rows});
