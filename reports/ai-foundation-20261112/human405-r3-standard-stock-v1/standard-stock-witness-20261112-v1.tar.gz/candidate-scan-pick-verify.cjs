'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ}=require('./controlled-r3');
const [record,out,...swaps]=process.argv.slice(2),checks=[];
const d=readZ(record);
const cases=d.rows.map(r=>({label:r.label+':'+r.card,root:r.root,desired:r.a,expected:r.terminal.totalScore,actions:r.inputs,end:r.end}));
for(const f of swaps){
 const d=readZ(f),r=d.result.find(x=>x.name==='b_9.webp');
 cases.push({label:'hidden:'+d.swap,root:d.root,desired:r.actions[0],expected:r.terminal.totalScore,actions:r.actions,end:r.end});
}
for(const r of cases){
 const m=open(r.root),steps=[];let cp,stop;
 try{
  for(let i=0;i<220;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!=='player-white'){m.advanceOpponents(steps);continue;}
   const u=m.automatic(cp);assert(u.complete&&u.n<=256&&u.ms<=600);
   if(i===0){assert.equal(u.a.actionId,r.desired.actionId);checks.push({label:r.label,n:u.n,ms:u.ms,choice:u.a.summary,expected:r.expected});}
   cp=u.checkpoint;steps.push(m.apply(u.a));
  }
  assert.equal(stop,'terminal');assert.deepEqual(steps,r.actions);assert.deepEqual(m.save(),r.end);
  console.log(JSON.stringify({...checks.at(-1),inputs:steps.length}));
 }finally{m.dispose();}
}
writeZ(out,{checks});
