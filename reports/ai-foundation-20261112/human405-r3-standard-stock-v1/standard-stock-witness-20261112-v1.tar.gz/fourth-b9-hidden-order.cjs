'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [source,out,swapArg]=process.argv.slice(2),seat='player-white',x=readZ(source).rows[0],result=[];
const [i,j]=swapArg.split(',').map(Number),sourceRoot=x.root,root=structuredClone(sourceRoot);
const committed=JSON.parse(root.committedState),states=[committed,root.session.session.baseState,root.session.session.workingState];
const expected=states[0].cards.drawPileCardIds.slice();
for(const s of states){const d=s.cards.drawPileCardIds;assert.deepEqual(d,expected);assert(i!==j&&d[i]&&d[j]);[d[i],d[j]]=[d[j],d[i]];}
root.committedState=JSON.stringify(committed);
const m=open(root),b=open(sourceRoot);
try{
 assert.deepEqual(m.owner(seat),b.owner(seat));assert.deepEqual(m.menu(),b.menu());
 const d=m.automatic();assert(d.complete&&d.n<=256&&d.ms<=600);
 assert.equal(d.a.actionId,x.q.a.actionId);assert.equal(d.value,x.q.value);assert.equal(d.n,x.q.n);assert.equal(JSON.stringify(d.roots),JSON.stringify(x.q.roots));
 for(const name of ['b_16.webp','b_9.webp']){
  m.restore(root);const chosen=m.act('choose_card',a=>a.summary===name),actions=[chosen],checks=[];
  let cp,stop;
  for(let k=0;k<230;k++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!==seat){m.advanceOpponents(actions);continue;}
   const u=m.automatic(cp),a=u.a,p={n:u.n,ms:u.ms,a:a?.summary,v:u.value,complete:u.complete};
   if(!u.complete||!a||u.n>256||u.ms>600){stop={gate:p,root:m.save()};break;}
   cp=u.checkpoint;checks.push(p);actions.push(m.apply(a));
  }
  assert(stop);const terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)??null,end=m.save();
  m.restore(root);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  const peak=[Math.max(...checks.map(x=>x.n),0),Math.max(...checks.map(x=>x.ms),0)];
  result.push({name,terminal,end,actions,checks,peak,stop});
  console.log(JSON.stringify({swap:swapArg,name,terminal:terminal?.totalScore,peak,stop:stop.gate||stop}));
 }
 writeZ(out,{root,swap:swapArg,observed:m.owner(seat),d:{a:d.a,value:d.value,roots:d.roots,n:d.n},result});
}finally{m.dispose();b.dispose();}
