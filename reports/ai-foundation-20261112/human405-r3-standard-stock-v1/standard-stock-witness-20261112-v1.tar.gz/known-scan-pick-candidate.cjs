'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const file=path.resolve('randomizer/game/ai/analysis-port.js'),code=fs.readFileSync(file,'utf8');
const anchor="      if(status==='decision'&&state.turn.roundNumber===3&&session?.queue?.length===2";
const insert=`      // With no energy or probe, keep a visible card that can pay for
      // the ordinary scan and one further signal with the existing cash.
      if(status==="decision"&&state.turn.roundNumber===4&&session?.queue?.length===1
        &&!session.interruptContext&&head.type===scienceSession.EFFECT_TYPES.PICK_CARD&&head.ownerId===seatId
        &&head.payload.blueBonusSource&&session.journal.actions[0]?.action?.family==="place_data"){
        const p=state.players.players.find(q=>q.id===seatId),ids=knownCards(envelope),w=p.resources;
        const fits=c=>{
          const e=cardEffects.buildPlayEffects(c),cost=cardEffects.getCardPlayCost(c);
          return e.length===2&&e[0].type===cardEffects.EFFECT_TYPES.SCAN_ACTION&&e[0].options.skipCost===true
            &&e[1].type===cardEffects.EFFECT_TYPES.ANY_SECTOR_SCAN&&e[1].options.gainData===true
            &&Object.keys(cost).length===1&&cost.credits>0&&cost.credits+1<=w.credits;
        };
        if(p.mainActionCompleted&&industryCatalog.getPlayerIndustryDefinition(p)?.passiveIds.includes("deepspace_free_analyze")&&w.energy===0
          &&p.hand.length<=1&&p.hand.every(c=>ids.has(c.id)&&!fits(c))&&!hasOwnVisitSource(state)
          &&data.listComputerPlacedTokens(p).map(x=>x.placementSlot).join(",")==="1,2,3,4,5"
          &&w.availableData>=1&&Object.keys(state.data.nebulae).some(id=>id.startsWith("sector-")&&data.getNextReplaceableNebulaToken(state.data,id))
          &&state.cards.publicCards.filter(Boolean).every(c=>ids.has(c.id))){
          const options=actions.flatMap(action=>{
            if(action.family!=="choose_card"||!action.target?.choiceId?.startsWith("pick:"))return [];
            const card=state.cards.publicCards.find(c=>c?.id===action.target.cardInstanceId);
            return card&&fits(card)?[{card,action}]:[];
          });
          if(options.length===1){
            const {card,action}=options[0],goal={id:"free-visible-funded-scan",kind:"free-reward",cardId:card.id};
            const result=freeze({policy:"seti-fixed-blue-funded-scan-v1",isEquivalence:false,kind:"fixed-card-plan",fixed:true,
              goal,selection:{cardId:card.id,blind:false},discardIds:[],selectedActionId:action.actionId,
              retainedActionIds:[action.actionId],excludedActionIds:actions.filter(a=>a!==action).map(a=>a.actionId),
              reason:"keep-paid-scan-without-energy"});
            envelopeCardSpecs.set(envelope,result);return result;
          }
        }
      }
`;
assert.equal(code.split(anchor).length,2);
const candidate=code.replace(anchor,insert+anchor),m=new Module(file,module);
m.filename=file;m.paths=Module._nodeModulePaths(path.dirname(file));m._compile(candidate,file);m.loaded=true;require.cache[file]=m;
