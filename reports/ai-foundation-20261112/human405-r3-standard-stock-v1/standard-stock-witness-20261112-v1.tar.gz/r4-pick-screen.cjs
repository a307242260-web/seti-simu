'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{open,writeZ}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const [source,out]=process.argv.slice(2),seat='player-white',read=p=>JSON.parse(fs.readFileSync(p));
const rows=read(source).rows;
const results=[];
for(const {board,f} of rows){
 const r=read('reports/research/'+f),s=read(r.savePath),cp=read(r.roundEnds[2].checkpointPath),m=open(cp.coreState.compositionEnvelope);
 const visits=[];
 try{
  for(let i=cp.replayCursor.stepIndex;i<s.replaySteps.length;i++){
   const a=s.replaySteps[i].action;
   const e=m.c.inspect().session;
   if(a.actorId===seat&&m.facts().round===4&&a.family==='choose_card'&&a.target?.choiceId?.startsWith('pick:')&&e){
    const root=m.save();
    if(root.session?.session?.queue[0]?.payload?.blueBonusSource){
     const p=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
     try{
      const n=p.openRoot();p.setCardPickPlanning(true);
      const spec=p.cardPickSpec(n);
      visits.push({input:i+1,observed:a.summary,options:m.menu().map(x=>x.summary),spec,eligible:spec?.reason==='keep-paid-scan-without-energy'});
      assert.deepEqual(m.save(),root);
     }finally{p.close();}
    }
   }
   m.apply(a);
  }
  const final=m.save();assert.equal(final.committedState,s.committedState);assert.deepEqual(final.session,s.session);
  results.push({board,f,visits});
 }catch(e){results.push({board,f,visits,error:String(e).slice(0,200)});}finally{m.dispose();}
}
writeZ(out,{rows:results});console.log(JSON.stringify({menus:results.reduce((n,r)=>n+r.visits.length,0),eligible:results.flatMap(r=>r.visits.filter(x=>x.eligible).map(x=>[r.board,x.input])),errors:results.filter(r=>r.error).map(x=>[x.board,x.error])}));
