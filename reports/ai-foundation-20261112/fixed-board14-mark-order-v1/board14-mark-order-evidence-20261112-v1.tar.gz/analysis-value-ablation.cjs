'use strict';
const {readZ,writeZ,open}=require('./controlled-r3'),path=require('node:path'),assert=require('node:assert/strict');
const src=n=>require(path.resolve('randomizer/game/ai',n)),V=src('state-value'),P=src('probe-capital'),R=src('ready-analysis-capital');
const [source,out]=process.argv.slice(2), rows=readZ(source).rows,seat='player-white';
function extract(o){
 const f=P.factsFromObservation(o,seat),p=f.player;
 return {...f,supply:f.board.techSupply,researchCost:p.researchPublicityCost,analyzeEnergyCost:R.energyCost(p.industryAbilityId)};
}
function read(f){
 const q=V.purposeCapital(f);
 return Object.fromEntries(Object.entries(q).filter(([k,v])=>k!=='dataPlan'&&(typeof v!=='object'||v?.value||k==='analysisPlan')));
}
const originals=rows.map(row=>{const m=open(row.end);try{return extract(m.owner(seat));}finally{m.dispose();}});
const [discard,play]=originals;
assert.equal(discard.player.availableData,play.player.availableData);
const extra=discard.hand.filter(c=>!play.hand.some(d=>d.id===c.id));assert.equal(extra.length,1);
const safe=f=>({hand:f.hand.map(c=>c.cardId),score:f.player.score,pub:f.player.publicity,computer:f.computerSlots,data:f.player.availableData,round:f.round,tech:f.player.techState.ownedTiles});
const scopes=[];
for(const [label,f] of [['discard',discard],['play',play]]) for(const [abl,replace] of Object.entries({
 none:{},
 hand:{hand:label==='discard'?play.hand:discard.hand,player:{...f.player,handSize:label==='discard'?play.hand.length:discard.hand.length}},
 publicity:{player:{...f.player,publicity:label==='discard'?play.player.publicity:discard.player.publicity}},
 score:{player:{...f.player,score:label==='discard'?play.player.score:discard.player.score}},
 boardData:{board:{...f.board,data:label==='discard'?play.board.data:discard.board.data}},
})){
 const input={...f,...replace};scopes.push({label,abl,inputs:safe(input),capital:read(input)});
}
for(const {label,abl,inputs,capital} of scopes)console.log(JSON.stringify({label,abl,inputs:[inputs.score,inputs.pub,inputs.hand],analysisPotential:capital.analysisPotential,analysis:capital.analysisPlan,research:capital.researchPotential,finalMark:capital.finalMarkPotential}));
writeZ(out,{extra,scopes});
