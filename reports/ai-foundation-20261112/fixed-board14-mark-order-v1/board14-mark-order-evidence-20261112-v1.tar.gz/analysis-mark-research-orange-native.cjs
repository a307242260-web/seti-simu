'use strict';
const {readZ,writeZ,open,short}=require('./controlled-r3'),assert=require('node:assert/strict');
const [source,out]=process.argv.slice(2),rows=[];
for(const row of readZ(source).rows){
 assert(!row.error,row.error);
 const m=open(row.end),steps=[];
 const step=(family,p=()=>true)=>{const a=m.act(family,p);steps.push({a,assets:short(m)});};
 const choose=s=>{const a=m.menu().find(a=>s.test(a.summary));assert(a,JSON.stringify(m.menu().map(a=>[a.family,a.summary,a.target])));step(a.family,b=>b.actionId===a.actionId);};
 const report=phase=>console.log(JSON.stringify({label:row.label,phase,assets:short(m),menu:m.menu().map(a=>[a.family,a.summary,a.target])}));
 try{
  if(row.label==='play'){
   choose(/yichangdian_0.webp：弃牌角标/);step('end_turn');
   report('earned-mark');
   choose(/^标记 B$/);
  }
  report('before-research');step('research_tech');
  report('choose-tech');choose(/^研究 orange1/);
  report('after-tech');
  if(m.menu().some(a=>a.summary==='标记 B'))choose(/^标记 B$/);
  else if(m.menu().some(a=>a.family==='end_turn')){
   step('end_turn');if(m.menu().some(a=>a.summary==='标记 B'))choose(/^标记 B$/);
  }
  const end=m.save(),facts=m.facts();
  m.restore(row.end);for(const {a} of steps)m.apply(a);assert.deepEqual(m.save(),end);
  rows.push({label:row.label,steps,end,facts});
 }catch(err){console.error(row.label,String(err));rows.push({label:row.label,steps,error:String(err),menu:m.menu()});}finally{m.dispose();}
}
writeZ(out,{rows});
