'use strict';
const {readZ,writeZ,open}=require('./controlled-r3'),fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const [match,summary,out]=process.argv.slice(2),read=f=>JSON.parse(fs.readFileSync(f)),seat='player-white';
const roots=[],screen=[],V=require(path.resolve('randomizer/game/ai/state-value'));
const known=readZ(match).rows;
for(const {label,root,end} of known){
 for(const [at,checkpoint] of [['decision',root],['matched-tech',end]]){
  if(label==='play'&&at==='decision')continue;
  const m=open(checkpoint);
  try{
   const q=m.automatic(),value=V.evaluateStateValue(m.owner(seat),seat).total;
   assert.deepEqual(m.save(),checkpoint);
   roots.push({label,at,value,action:q.a?.summary,n:q.n,ms:q.ms,complete:q.complete,roots:q.roots});
   console.log(JSON.stringify({label,at,value,action:q.a?.summary,n:q.n,ms:q.ms,complete:q.complete}));
  }finally{m.dispose();}
 }
}
for(const r of [...read(summary).rows,{board:0,record:'4539c186.ff577dea.quick-400.json'}]){
 const data=read('reports/research/'+(r.f||r.record)),save=read(data.savePath),c=read(data.roundEnds[1].checkpointPath),m=open(c.coreState.compositionEnvelope);
 const found=[];let screened=0;
 try{
  for(let i=c.replayCursor.stepIndex;i<data.roundEnds[2].beforeInput;i++){
   const a=save.replaySteps[i].action,f=m.facts(),o=m.owner(seat),s=o.selfState,mark=s.nextFinalMark;
   if(a.actorId===seat&&f.round===3&&mark?.valuationSafe&&mark.followingThreshold===null&&f.wallet.score<mark.threshold
     &&f.wallet.score+12>=mark.threshold&&s.traceCounts.blue>=Math.min(s.traceCounts.pink,s.traceCounts.yellow)
     &&mark.options.every(x=>['b1','c2'].includes(x.formulaId))&&!f.probes.length&&f.computer.length>=4){
    const v=V.evaluateStateValue(o,seat);screened++;
    found.push({step:i+1,score:f.wallet.score,value:v.total,analysis:v.components.analysisPotential,action:a.summary});
   }
   m.apply(a);
  }
  screen.push({board:r.board,screened,found});console.log(JSON.stringify(screen.at(-1)));
 }finally{m.dispose();}
}
writeZ(out,{roots,screen});
