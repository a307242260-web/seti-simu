'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const {readZ,writeZ,open}=require('./controlled-r3');
const src=n=>path.resolve('randomizer/game/ai',n+'.js'),p=src('state-value'),code=fs.readFileSync(p,'utf8');
const probe=require(src('probe-capital')),R=require(src('ready-analysis-capital')),V=require(p),patched=new Module(p,module);
patched.filename=p;patched.paths=Module._nodeModulePaths(path.dirname(p));
const location='return arithmetic.sum([lower.total,preparation.value],weights);';
assert.equal(code.split(location).length,2);
patched._compile(code.replace(location,`if(globalThis.capture&&facts===globalThis.captureFacts)globalThis.capture.push({wallet,slots:progress.computerSlots,lower,preparation,nextFinalMark:next.nextFinalMark});
      ${location}`),p);
const [source,out]=process.argv.slice(2),seat='player-white', rows=[];
for(const row of readZ(source).rows){
 const m=open(row.end);
 try{
  const o=m.owner(seat),f=probe.factsFromObservation(o,seat),a={...f,supply:f.board.techSupply,researchCost:f.player.researchPublicityCost,analyzeEnergyCost:R.energyCost(f.player.industryAbilityId)};
  globalThis.captureFacts=a;globalThis.capture=[];
  const q=patched.exports.purposeCapital(a),calls=globalThis.capture;
  assert.equal(q.total,V.purposeCapital(a).total);
  rows.push({label:row.label,mark:a.nextFinalMark,q,calls});
  console.log(JSON.stringify({label:row.label,mark:a.nextFinalMark,calls:calls.map(c=>({score:c.wallet.score,pub:c.wallet.publicity,slots:c.slots,mark:c.lower.finalMarkPotential,research:c.lower.researchPotential,computer:c.lower.computerPotential,prep:c.preparation}))}));
 }finally{m.dispose();}
}
writeZ(out,{rows});
