      // This last mark is already earned by the typed analysis prefix.
      // It resolves before the next main action but spends no publicity.
      // Keep its existing value; quote only the research delta after it.
      const mark=next.nextFinalMark,traces=facts.traceCounts;
      const stableLastMark=mark?.valuationSafe&&mark.playerId===wallet.id
        &&mark.followingThreshold===null&&wallet.score>=mark.threshold
        &&next.uncontestedRound&&!next.researchSymbols?.revealInitialized
        &&!next.reservedCards?.length&&!probeCapital.ownedProbes(next.board.rockets,wallet).length
        &&traces?.blue>=Math.min(traces.pink,traces.yellow)
        &&mark.options.length>0&&mark.options.every(o=>o.formulaId==='b1'||o.formulaId==='c2');
      const funded=stableLastMark?{...next,nextFinalMark:null,sourcePendingFinalMarkChoice:null}:next;
      const preparation=publicityPreparation.quote(funded,weights,publicityPortfolio,stableLastMark
        ?{...lower,total:arithmetic.sum([lower.total,-lower.finalMarkPotential],weights)}:lower);
