'use strict';
const fs=require('node:fs'),Module=require('node:module'),path=require('node:path'),assert=require('node:assert/strict');
const p=path.resolve('randomizer/game/ai/state-value.js'),old=fs.readFileSync(p,'utf8');
const key='const lower=basePurposeCapital(next,weights),preparation=publicityPreparation.quote(next,weights,\n        publicityPortfolio,lower);';
assert.equal(old.split(key).length,2);
const newCode=old.replace(key,'const lower=basePurposeCapital(next,weights);\n'+fs.readFileSync(path.join(__dirname,'after-final-mark-section.js'),'utf8').trimEnd());
const m=new Module(p,module);m.filename=p;m.paths=Module._nodeModulePaths(path.dirname(p));m._compile(newCode,p);m.loaded=true;require.cache[p]=m;
