'use strict';
const {readZ,writeZ,open,short}=require('./controlled-r3'),assert=require('node:assert/strict');
const [source,out]=process.argv.slice(2),rows=[];
for(const row of readZ(source).rows){
 const m=open(row.end),steps=[];
 const step=(family,p=()=>true)=>{const a=m.act(family,p);steps.push({a,assets:short(m)});};
 const choose=s=>{const a=m.menu().find(a=>s.test(a.summary));assert(a,JSON.stringify(m.menu().map(a=>[a.family,a.summary,a.target])));step(a.family,b=>b.actionId===a.actionId);};
 const report=phase=>console.log(JSON.stringify({label:row.label,phase,assets:short(m),menu:m.menu().map(a=>[a.family,a.summary,a.target])}));
 try{
  step('place_data');choose(/放置位 6$/);step('end_turn');
  step('analyze');report('choose-trace');choose(/^外星人 2 蓝/);
  report('after-trace');
  step('place_data');choose(/放置位 1$/);
  step('place_data');choose(/blue[0-9]+ 下方/);
  report('after-tail');
  if(row.label==='discard'){
   choose(/yichangdian_0.webp：弃牌角标/);choose(/yichangdian_7.webp：弃牌角标/);
   step('end_turn');
   report('before-research');
  }
  const end=m.save();m.restore(row.end);for(const {a} of steps)m.apply(a);assert.deepEqual(m.save(),end);
  rows.push({label:row.label,steps,end,menu:m.menu()});
 }catch(err){console.error(row.label,String(err));rows.push({label:row.label,steps,error:String(err),menu:m.menu()});}finally{m.dispose();}
}
writeZ(out,{rows});
