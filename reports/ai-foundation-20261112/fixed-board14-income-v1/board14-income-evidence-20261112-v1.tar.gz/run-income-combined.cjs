'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path'),Module=require('node:module');
const [source,diagnostics,out]=process.argv.slice(2),p=path.resolve('randomizer/game/ai/sector-card-capital.js'),base=fs.readFileSync(p,'utf8');
const patched=new Module(p,module);patched.filename=p;patched.paths=Module._nodeModulePaths(path.dirname(p));require(p);
const anchor=' function quote(facts,weights,portfolio,currentCapital){';
const extra=[
 '  for(const card of facts.hand){',
 '   const floor=knownSectorFloor(facts,weights,card);',
 '   if(!floor)continue;',
 '   const after={...facts,player:{...facts.player,handSize:facts.player.handSize-1},hand:facts.hand.filter(c=>c.id!==card.id)};',
 '   const other=portfolio(after),netGain=arithmetic.sum([floor.utility,Math.min(currentCapital,other),-currentCapital],weights);',
 "   candidates.push({...floor,netGain,kind:'known-two-signal-sector-floor'});",
 '  }',
 '  for(const card of eligible){'
].join('\n');
const code=base.replace(anchor,fs.readFileSync(source,'utf8')+anchor)
 .replace('if(!eligible.length||facts.terminal||facts.round+Number(facts.passing)>=4)','if(facts.terminal||facts.round+Number(facts.passing)>=4)')
 .replace('  for(const card of eligible){',extra)
 .replace('Object.freeze({supported,quote})','Object.freeze({supported,quote,knownSectorFloor})');
assert(code!==base);patched._compile(code,p);require.cache[p].exports=patched.exports;
const rp=path.resolve('randomizer/game/ai/resource-demand.js'),demandBase=fs.readFileSync(rp,'utf8'),rd=new Module(rp,module);
rd.filename=rp;rd.paths=Module._nodeModulePaths(path.dirname(rp));require(rp);
const demandAnchor='  function rankIncomeChoices(state,p,rows){';
let demandCode=demandBase.replace('root.SetiAlienChong);','root.SetiAlienChong,common?require(\'../aliens/state\'):root.SetiAlienState);')
 .replace('incomeOrder,scanIncome,techCatalog,chong){','incomeOrder,scanIncome,techCatalog,chong,alienState){')
 .replace(demandAnchor,fs.readFileSync(process.argv[5],'utf8')+demandAnchor)
 .replace('    rows.sort((a,b)=>b.value-a.value||incomeOrder.compare(a.card,b.card));','    rows.sort((a,b)=>b.value-a.value||incomeOrder.compare(a.card,b.card));\n    const retained=retainedSectorIncome(state,p,rows);if(retained)return retained.row;')
 .replace('VERSION,MONEY,isPreparation','retainedSectorIncome,VERSION,MONEY,isPreparation');
assert(demandCode!==demandBase);rd._compile(demandCode,rp);require.cache[rp].exports=rd.exports;
const {open,readZ,writeZ,short}=require('./controlled-r3'),rows=[];
const seat='player-white', score=m=>m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore;
for(const c of readZ(diagnostics).rows.filter(x=>['14-125','board14-income'].includes(x.name))){
 const m=open(c.root),accepted=[],checks=[];let stop,cp,r3,r3State;
 try {
  for(let i=0;i<210;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!==seat){const rest=[];m.advanceOpponents(rest);accepted.push(...rest.map(a=>({a})));continue;}
   const q=m.automatic(cp);
   if(!q.complete||!q.a||q.n>256||q.ms>600){stop={n:q.n,ms:q.ms,a:q.a?.summary};break;}
   if(!r3&&m.facts().round===3&&q.a.family==='pass'){
    r3=short(m);r3State=m.save();
    accepted.push({a:m.act('pass'),fixed:true});accepted.push({a:m.act('choose_card',a=>a.summary==='b_117.webp'),fixed:true});
    cp=null;continue;
   }
   cp=q.checkpoint;accepted.push({a:m.apply(q.a)});
   checks.push({n:q.n,ms:q.ms});
  }
  assert(stop);const end=m.save(),final=score(m);
  m.restore(c.root);accepted.forEach(x=>m.apply(x.a));assert.deepEqual(m.save(),end);
  rows.push({name:c.name,root:c.root,accepted,end,r3,r3State,final,stop,checks});
  console.log(JSON.stringify({name:c.name,stop,r3,final,main:accepted.filter(x=>x.a.phase==='main'||x.a.target?.choiceId?.startsWith('income:')).map(x=>x.a.summary),
    peak:[Math.max(0,...checks.map(q=>q.n)),Math.round(Math.max(0,...checks.map(q=>q.ms)))]}));
 }finally{m.dispose();}
}
writeZ(out,{rows});
