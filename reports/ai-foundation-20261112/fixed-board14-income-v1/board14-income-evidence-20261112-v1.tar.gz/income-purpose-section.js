  // One held, free two-signal card can close a visible ordinary sector.
  // Quote one fixed target and the generic printed rewards only; no second
  // sector, sector refill, new species, or anonymous card supplies value.
  function retainedSectorIncome(state,p,rows){
    if(rows.length!==2||p.hand.length!==2||p.hand.some(c=>c.hidden)
      ||state.turn.roundNumber!==3||!p.mainActionCompleted||p.passCompletionPending
      ||state.turn.currentPlayerId!==p.id||state.turn.cardTurnEventBonuses?.length||p.reservedCards.length
      ||industry.getPlayerIndustryDefinition(p)?.activeAbilityId!=='deepspace_swap_cards'
      ||data.NEBULA_IDS.some(id=>data.isSectorReadyToSettle(state.data,id)))return null;
    const [consume,keep]=rows,card=consume.card,model=effects.getCardModel(card),gain=cards.getIncomeGainForCard(card);
    const income=cards.getIncomeGainForCard(keep.card);
    if(Object.keys(gain||{}).length!==1||gain.energy!==1||Object.keys(income||{}).length!==1||income.handSize!==1
      ||model?.cardType!==0||model.triggers?.length||model.tasks?.length||model.temporaryTasks?.length||model.endGameScoring
      ||Object.keys(effects.getCardPlayCost(card)).length)return null;
    const play=effects.buildPlayEffects(card),effect=play[0],opts=effect?.options;
    if(play.length!==1||effect.type!=='card_conditional_reward'||opts.condition?.type!=='distinctSignalSectors'
      ||(opts.repeat??1)!==1||opts.rewards.length!==2||opts.rewards.some(r=>r.type!=='card_any_sector_scan'||r.options.gainData!==false)
      ||!effects.taskConditionMet({condition:opts.condition},p,state))return null;
    const own=v=>v.playerId===p.id||v.playerColor===p.color;
    const weights=stateValue.DEFAULT_WEIGHTS, wallet=p.resources;
    let best=null;
    for(const id of data.NEBULA_IDS){
      if(id===data.AOMOMO_NEBULA_ID)continue;
      const tokens=data.listNebulaTokens(state.data,id);
      const open=tokens.filter(t=>!t.replacedByPlayerColor&&!t.playerColor);
      if(tokens.length!==data.getNebulaCapacity(id)||open.length<1||open.length>2)continue;
      const participants=data.getSectorRanking(state.data,id),winner=participants.find(own);
      if(!winner||participants.some(r=>!own(r)&&r.count>=winner.count+open.length))continue;
      let score=open.reduce((sum,t)=>sum+data.getNebulaSlotScoreReward(id,t.slotIndex),0),publicity=0;
      for(const reward of data.buildSectorRewardDescriptors({ok:true,sectorId:id,participants,winner,
        settlementNumber:(state.data.sectorSettlements?.sectors?.[id]?.settlementCount||0)+1})){
        if(!own(reward.owner))continue;
        if(reward.kind==='resource'){
          score+=reward.gain.score||0;publicity+=reward.gain.publicity||0;
        }else if(reward.kind==='alien_trace'){
          // Only an unrevealed slot's ordinary first/extra payout is known.
          const available=Object.entries(state.aliens.aliens).flatMap(([slotId,slot])=>{
            const trace=slot.traces?.[reward.traceType];
            if(!trace||slot.revealed)return [];
            const g=(trace.firstPlaced?alienState.getExtraTraceReward():alienState.getFirstTraceRewardForSlot(slotId))?.gain;
            return g?[g]:[];
          });
          available.sort((a,b)=>(b.score||0)-(a.score||0)||(b.publicity||0)-(a.publicity||0));
          score+=available[0]?.score||0;publicity+=available[0]?.publicity||0;
        }
      }
      const utility=score+Math.min(publicity,players.RESOURCE_LIMITS.publicity-wallet.publicity)*weights.publicity-weights.handSize;
      if(!best||utility>best.utility)best={id,score,publicity,utility};
    }
    return best&&best.utility>0&&best.utility>=consume.value-keep.value?{row:keep,...best}:null;
  }
