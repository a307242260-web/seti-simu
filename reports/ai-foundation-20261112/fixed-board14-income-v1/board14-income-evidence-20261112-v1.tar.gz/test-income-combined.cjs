'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path'),Module=require('node:module');
const [source,diagnostics,out]=process.argv.slice(2),p=path.resolve('randomizer/game/ai/sector-card-capital.js'),base=fs.readFileSync(p,'utf8');
const patched=new Module(p,module);patched.filename=p;patched.paths=Module._nodeModulePaths(path.dirname(p));require(p);
const anchor=' function quote(facts,weights,portfolio,currentCapital){';
const extra=[
 '  for(const card of facts.hand){',
 '   const floor=knownSectorFloor(facts,weights,card);',
 '   if(!floor)continue;',
 '   const after={...facts,player:{...facts.player,handSize:facts.player.handSize-1},hand:facts.hand.filter(c=>c.id!==card.id)};',
 '   const other=portfolio(after),netGain=arithmetic.sum([floor.utility,Math.min(currentCapital,other),-currentCapital],weights);',
 "   candidates.push({...floor,netGain,kind:'known-two-signal-sector-floor'});",
 '  }',
 '  for(const card of eligible){'
].join('\n');
const code=base.replace(anchor,fs.readFileSync(source,'utf8')+anchor)
 .replace('if(!eligible.length||facts.terminal||facts.round+Number(facts.passing)>=4)','if(facts.terminal||facts.round+Number(facts.passing)>=4)')
 .replace('  for(const card of eligible){',extra)
 .replace('Object.freeze({supported,quote})','Object.freeze({supported,quote,knownSectorFloor})');
assert(code!==base);patched._compile(code,p);require.cache[p].exports=patched.exports;
const rp=path.resolve('randomizer/game/ai/resource-demand.js'),demandBase=fs.readFileSync(rp,'utf8'),rd=new Module(rp,module);
rd.filename=rp;rd.paths=Module._nodeModulePaths(path.dirname(rp));require(rp);
const demandAnchor='  function rankIncomeChoices(state,p,rows){';
let demandCode=demandBase.replace('root.SetiAlienChong);','root.SetiAlienChong,common?require(\'../aliens/state\'):root.SetiAlienState);')
 .replace('incomeOrder,scanIncome,techCatalog,chong){','incomeOrder,scanIncome,techCatalog,chong,alienState){')
 .replace(demandAnchor,fs.readFileSync(process.argv[5],'utf8')+demandAnchor)
 .replace('    rows.sort((a,b)=>b.value-a.value||incomeOrder.compare(a.card,b.card));','    rows.sort((a,b)=>b.value-a.value||incomeOrder.compare(a.card,b.card));\n    const retained=retainedSectorIncome(state,p,rows);if(retained)return retained.row;')
 .replace('VERSION,MONEY,isPreparation','retainedSectorIncome,VERSION,MONEY,isPreparation');
assert(demandCode!==demandBase);rd._compile(demandCode,rp);require.cache[rp].exports=rd.exports;
const {open,readZ,writeZ}=require('./controlled-r3'),rows=[];
for(const r of readZ(diagnostics).rows){
 const m=open(r.root);
 try{
  const q=m.automatic(),chosen=q.a?.summary;
  const row={name:r.name,previous:r.previous,root:r.root,chosen,value:q.value,n:q.n,ms:q.ms,complete:q.complete,roots:q.roots};
  rows.push(row);
  console.log(JSON.stringify({name:r.name,previous:r.previous,chosen,value:q.value,n:q.n,ms:q.ms,ok:q.complete&&q.n<=256&&q.ms<=600}));
 }finally{m.dispose();}
}
writeZ(out,{rows});
