'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path'),Module=require('node:module');
const [input,hidden,section,summary,out]=process.argv.slice(2),p=path.resolve('randomizer/game/ai/resource-demand.js'),base=fs.readFileSync(p,'utf8');
const patched=new Module(p,module);patched.filename=p;patched.paths=Module._nodeModulePaths(path.dirname(p));require(p);
const anchor='  function rankIncomeChoices(state,p,rows){';
let code=base.replace('root.SetiAlienChong);','root.SetiAlienChong,common?require(\'../aliens/state\'):root.SetiAlienState);')
 .replace('incomeOrder,scanIncome,techCatalog,chong){','incomeOrder,scanIncome,techCatalog,chong,alienState){')
 .replace(anchor,fs.readFileSync(section,'utf8')+anchor)
 .replace('    rows.sort((a,b)=>b.value-a.value||incomeOrder.compare(a.card,b.card));','    rows.sort((a,b)=>b.value-a.value||incomeOrder.compare(a.card,b.card));\n    const retained=retainedSectorIncome(state,p,rows);if(retained)return retained.row;')
 .replace('VERSION,MONEY,isPreparation','retainedSectorIncome,VERSION,MONEY,isPreparation');
assert(code!==base);patched._compile(code,p);require.cache[p].exports=patched.exports;
const {open,readZ,writeZ}=require('./controlled-r3'),read=f=>JSON.parse(fs.readFileSync(f)),rows=[];
const recorded=readZ(input).rows.find(x=>x.label==='salary-card'),firstRoots=[{name:'board14-income',root:recorded.root,previous:recorded.first.a}];
const s=read(summary);
const files=[...s.rows,{board:0,f:'4539c186.ff577dea.quick-400.json'}];
for(const b of files){
 const r=read('reports/research/'+b.f),save=read(r.savePath),cp=read(r.roundEnds[1].checkpointPath);
 const from=cp.replayCursor.stepIndex,to=r.roundEnds[2].beforeInput;
 const list=save.replaySteps.slice(from,to).filter(x=>x.actorPlayerId==='player-white'&&x.action.target?.choiceId?.startsWith('income:'));
 if(b.board===14)list.push(save.replaySteps[124]);
 for(const {stepIndex,action} of list){
  if(b.board===14&&stepIndex===135)continue;
  const m=open(cp.coreState.compositionEnvelope);
  try{
   save.replaySteps.slice(from,stepIndex).forEach(x=>m.apply(x.action));
   firstRoots.push({name:b.board+'-'+(stepIndex+1),root:m.save(),previous:action.summary});
  }finally{m.dispose();}
 }
}
const other=readZ(hidden).rows.filter(x=>x.label==='cards').map(x=>({name:'hidden-'+x.world,root:x.root,previous:x.cold.a}));
for(const r of [...firstRoots,...other]){
 const m=open(r.root);
 try{
  const state=m.state(),p=m.player(),demand=patched.exports;
  const candidates=p.hand.map(card=>({card,value:demand.computerIncomeValue(state,p.id,card)})).filter(x=>x.value!=null).sort((a,b)=>b.value-a.value);
  const quote=demand.retainedSectorIncome(state,p,candidates),q=m.automatic(),chosen=q.a?.summary;
  const row={...r,quote:quote?{...quote,row:quote.row.card.cardId}:null,chosen,value:q.value,n:q.n,ms:q.ms,complete:q.complete,roots:q.roots};
  rows.push(row);
  console.log(JSON.stringify({name:r.name,previous:r.previous,chosen,quote:row.quote,n:q.n,ms:q.ms,ok:q.complete&&q.n<=256&&q.ms<=600}));
 }finally{m.dispose();}
}
writeZ(out,{rows});
