'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [input,out]=process.argv.slice(2),cases=readZ(input).rows.filter(r=>r.stop==='settled'),rows=[];
const seat='player-white',score=m=>m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore;
for(const c of cases){
 const m=open(c.end),setup=[],accepted=[],checks=[];
 try{
  setup.push(m.act('pass'));
  if(m.menu()[0].actorId!==seat)m.advanceOpponents(setup);
  setup.push(m.act('choose_card',a=>a.summary==='b_117.webp'));
  if(m.menu()[0].actorId!==seat)m.advanceOpponents(setup);
  const root=m.save();let cp,stop;
  for(let i=0;i<150;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!==seat){const rest=[];m.advanceOpponents(rest);accepted.push(...rest);continue;}
   const q=m.automatic(cp);
   if(!q.complete||!q.a||q.n>256||q.ms>600){stop={a:q.a?.summary,n:q.n,ms:q.ms};break;}
   cp=q.checkpoint;accepted.push(m.apply(q.a));checks.push({n:q.n,ms:q.ms});
  }
  assert(stop);const end=m.save(),final=score(m);
  m.restore(c.end);setup.forEach(m.apply);accepted.forEach(m.apply);assert.deepEqual(m.save(),end);
  const row={world:c.world,label:c.label,root,start:c.end,setup,accepted,checks,stop,final,end};
  rows.push(row);console.log(JSON.stringify({world:c.world,label:c.label,final,stop,peak:[Math.max(0,...checks.map(x=>x.n)),Math.round(Math.max(0,...checks.map(x=>x.ms)))]}));
 }finally{m.dispose();}
}
writeZ(out,{rows});
