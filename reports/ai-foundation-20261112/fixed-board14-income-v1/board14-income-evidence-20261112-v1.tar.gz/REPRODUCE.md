# 第 14 盘收入对照
Node 22，从生产源码 ff577dea6 或 10df4c762 的仓库根目录执行。解包到临时 CASE_DIR，执行 `shasum -a 256 -c SHA256SUMS`。第三轮源存档取自上一个证据包 reports/ai-foundation-20261112/fixed-boards-third-round-v1/third-round-opportunities-20261112-v1.tar.gz 中的 third-round-controls-463fc442-20261112-v1.json.gz。

```sh
node "$CASE_DIR/blind-order.cjs" "$CASE_DIR/third-round-controls-463fc442-20261112-v1.json.gz" "$CASE_DIR/recheck-r3.json.gz"
node "$CASE_DIR/blind-order-tail.cjs" "$CASE_DIR/recheck-r3.json.gz" "$CASE_DIR/recheck-r4.json.gz"
node "$CASE_DIR/test-income-combined.cjs" "$CASE_DIR/known-sector-floor.js" "$CASE_DIR/income-candidate-ff577dea-20261112-v1.json.gz" "$CASE_DIR/recheck-quotes.json.gz" "$CASE_DIR/income-purpose-section.js"
node "$CASE_DIR/run-income-combined.cjs" "$CASE_DIR/known-sector-floor.js" "$CASE_DIR/income-candidate-ff577dea-20261112-v1.json.gz" "$CASE_DIR/recheck-combined.json.gz" "$CASE_DIR/income-purpose-section.js"
node "$CASE_DIR/forced-scan-combined.cjs" "$CASE_DIR/known-sector-floor.js" "$CASE_DIR/income-candidate-ff577dea-20261112-v1.json.gz" "$CASE_DIR/recheck-scan.json.gz" "$CASE_DIR/income-purpose-section.js"
```

原生动作与结果已留在同包。候选只替换临时进程中的 Node 模块，不改生产源码。换牌序只交换两张原根不可见牌，保持原根公开观察和随机数状态；真实后继揭晓后才允许使用那张牌。计时随负载变化。
