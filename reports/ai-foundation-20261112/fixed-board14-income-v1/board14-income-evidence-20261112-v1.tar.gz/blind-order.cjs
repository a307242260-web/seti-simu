'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [input,out]=process.argv.slice(2),r=readZ(input).rows.find(x=>x.label==='salary-card'),rows=[];
const seat='player-white',m=open(r.root);
const original=m.owner(seat), deck=m.state().cards.drawPileCardIds;
const pairs=[ [deck[0],deck[1]],[deck[0],deck[4]],[deck[0],deck[6]] ];
const admit=q=>q.complete&&q.a&&q.n<=256&&q.ms<=600;
function change(source,[a,b]){
 const copy=structuredClone(source),committed=JSON.parse(copy.committedState);let edited=0;
 function visit(x){
  if(!x||typeof x!=='object')return;
  if(Array.isArray(x.drawPileCardIds)){
   const i=x.drawPileCardIds.indexOf(a),j=x.drawPileCardIds.indexOf(b);
   if(i>=0&&j>=0){[x.drawPileCardIds[i],x.drawPileCardIds[j]]=[x.drawPileCardIds[j],x.drawPileCardIds[i]];edited++;}
  }
  for(const item of Object.values(x))if(item&&typeof item==='object')visit(item);
 }
 visit(committed);visit(copy.session);copy.committedState=JSON.stringify(committed);assert(edited>=3);return copy;
}
try{
 for(const [i,pair] of pairs.entries()){
  const root=change(r.root,pair);m.restore(root);assert.deepEqual(m.owner(seat),original);
  const cold=m.automatic();assert(admit(cold));assert.equal(cold.a.summary,r.first.a);
  assert.equal(cold.value,r.first.v);
  for(const [label,choice] of [['electric','收入 dlc_19.png'],['cards','收入 b_137.webp']]){
   m.restore(root);
   const first=m.act('choose_card',a=>a.summary===choice),moves=[{a:first,manual:true}],frames=[];
   let cp,stop;
   for(let i=0;i<140;i++){
    if(m.menu()[0].actorId!==seat){const extra=[];m.advanceOpponents(extra);moves.push(...extra.map(a=>({a,passive:true})));continue;}
    const q=m.automatic(cp);if(!admit(q)){stop={gate:{a:q.a?.summary,n:q.n,ms:q.ms,complete:q.complete}};break;}
    if(q.a.family==='pass'&&m.facts().round===3){stop='settled';break;}
    if(q.a.phase==='main')frames.push({a:q.a.summary,before:short(m)});
    cp=q.checkpoint;moves.push({a:m.apply(q.a),n:q.n,ms:q.ms});
   }
   assert(stop);const end=m.save(),assets=short(m);
   m.restore(root);moves.forEach(x=>m.apply(x.a));assert.deepEqual(m.save(),end);
   rows.push({world:i+1,pair,label,root,cold:{a:cold.a.summary,value:cold.value,n:cold.n},moves,frames,stop,end,assets});
   console.log(JSON.stringify({world:i+1,label,stop,assets,main:frames.map(x=>x.a),peak:[Math.max(0,...moves.map(x=>x.n||0)),Math.round(Math.max(0,...moves.map(x=>x.ms||0)))]}));
  }
 }
}finally{m.dispose();}
writeZ(out,{rows});
