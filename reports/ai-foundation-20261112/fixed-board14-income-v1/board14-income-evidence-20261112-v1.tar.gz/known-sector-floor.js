 function knownSectorFloor(facts,weights,card){
    const {player:p,board}=facts;
    if(weights!==arithmetic.DEFAULT_WEIGHTS||facts.round!==3||facts.passing||facts.terminal||!card?.id||!card.cardId||card.hidden
      ||facts.reservedCards?.length||facts.turnCardBonusCount||board.aliens.slots.some(s=>s.revealed))return null;
    const model=effects.getCardModel(card);
    if(model?.cardType!==0||model.triggers?.length||model.tasks?.length||model.temporaryTasks?.length||model.endGameScoring
      ||Object.keys(effects.getCardPlayCost(card)).length)return null;
    const play=effects.buildPlayEffects(card),effect=play[0],opts=effect?.options;
    if(play.length!==1||effect.type!=='card_conditional_reward'||opts.condition?.type!=='distinctSignalSectors'
      ||(opts.repeat??1)!==1||opts.rewards.length!==2||opts.rewards.some(r=>r.type!=='card_any_sector_scan'||r.options.gainData!==false)
      ||!effects.taskConditionMet({condition:opts.condition},p,{data:board.data}))return null;
    if(data.NEBULA_IDS.some(id=>data.isSectorReadyToSettle(board.data,id)))return null;
    const own=v=>v.playerId===p.id||v.playerColor===p.color;
    const wallet=p;
    let best=null;
    for(const id of data.NEBULA_IDS){
      if(id===data.AOMOMO_NEBULA_ID)continue;
      const tokens=data.listNebulaTokens(board.data,id);
      const open=tokens.filter(t=>!t.replacedByPlayerColor&&!t.playerColor);
      if(tokens.length!==data.getNebulaCapacity(id)||open.length<1||open.length>2)continue;
      const participants=data.getSectorRanking(board.data,id),winner=participants.find(own);
      if(!winner||participants.some(r=>!own(r)&&r.count>=winner.count+open.length))continue;
      let score=open.reduce((sum,t)=>sum+data.getNebulaSlotScoreReward(id,t.slotIndex),0),publicity=0;
      for(const reward of data.buildSectorRewardDescriptors({ok:true,sectorId:id,participants,winner,
        settlementNumber:(board.data.sectorSettlements?.sectors?.[id]?.settlementCount||0)+1})){
        if(!own(reward.owner))continue;
        if(reward.kind==='resource'){
          score+=reward.gain.score||0;publicity+=reward.gain.publicity||0;
        }else if(reward.kind==='alien_trace'){
          // Only an unrevealed slot's ordinary first/extra payout is known.
          const available=board.aliens.slots.map(slot=>[slot.slotId,slot]).flatMap(([slotId,slot])=>{
            const trace=slot.traces?.[reward.traceType];
            if(!trace||slot.revealed)return [];
            const g=(trace.firstPlaced?aliens.getExtraTraceReward():aliens.getFirstTraceRewardForSlot(slotId))?.gain;
            return g?[g]:[];
          });
          available.sort((a,b)=>(b.score||0)-(a.score||0)||(b.publicity||0)-(a.publicity||0));
          score+=available[0]?.score||0;publicity+=available[0]?.publicity||0;
        }
      }
      const utility=score+Math.min(publicity,players.RESOURCE_LIMITS.publicity-wallet.publicity)*weights.publicity-weights.handSize;
      if(!best||utility>best.utility)best={id,score,publicity,utility};
    }
    return best&&best.utility>0?{...best,cardId:card.id}:null;
 }
