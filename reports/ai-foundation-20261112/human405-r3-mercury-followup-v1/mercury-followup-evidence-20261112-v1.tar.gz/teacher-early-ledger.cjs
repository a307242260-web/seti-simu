'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{open,short,writeZ}=require('./controlled-r3');
const t=require(path.resolve('tools/research-human405-round1')).thirdRoundOpening();
const root=t.checkpoint.coreState.compositionEnvelope, seat='player-white', read=p=>JSON.parse(fs.readFileSync(p));
const history=read(process.argv[2]).replaySteps, m=open(root),steps=[],actions=[];
let stop;
try{
 for(let i=112;i<148;i++){
  const h=history[i].action, native=m.menu().find(a=>a.actionId===h.actionId&&a.actorId===h.actorId);
  if(!native){stop={step:i+1,kind:'history-native-menu-mismatch',h,menu:m.menu()};break;}
  if(native.actorId===seat){
   const before=m.save(),q=m.automatic();assert.deepEqual(m.save(),before);
   const current=q.roots.find(r=>r.actionId===native.actionId);
   steps.push({input:i+1,before,assets:short(m),actual:native,preferred:q.a,model:q.value,teacherOption:current,root:q.roots,n:q.n,ms:q.ms,complete:q.complete});
   if(q.a?.actionId!==native.actionId) console.log(JSON.stringify({i:i+1,expected:native.summary,chosen:q.a?.summary,v:[current?.value,q.value],status:current?.completion,n:q.n,ms:q.ms,complete:q.complete}));
  }
  actions.push(m.apply(native));
 }
 const end=m.save();m.restore(root);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
 console.log(JSON.stringify({covered:steps.length,actions:actions.length,stop:stop&&[stop.step,stop.kind,stop.h.summary]}));
 writeZ(process.argv[3],{root,steps,actions,end,stop});
}finally{m.dispose();}
