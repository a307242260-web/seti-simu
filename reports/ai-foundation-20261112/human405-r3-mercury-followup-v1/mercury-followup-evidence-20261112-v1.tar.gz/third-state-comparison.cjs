'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{open,readZ,writeZ}=require('./controlled-r3');
const source=require(path.resolve('tools/research-human405-round1')),data=require(path.resolve('randomizer/game/data'));
const [dir,out]=process.argv.slice(2),get=f=>JSON.parse(fs.readFileSync(f)),cp=f=>get(f).coreState.compositionEnvelope,seat='player-white';
const std=get('reports/research/1db636c6.d74f5aed.quick-400.json'),sv=get(std.savePath),v189=get(dir+'/db594a2e.1609bf50.full.json');
const teacher=source.thirdRoundOpening().checkpoint.coreState.compositionEnvelope;
const auto=readZ(dir+'/teacher-third-autonomous-d74f5aed-20261112-v1.json.gz');
const openBeforeStd= get(std.roundEnds[1].checkpointPath),m=open(openBeforeStd.coreState.compositionEnvelope);
let start;
try{
 for(const {action} of sv.replaySteps.slice(openBeforeStd.replayCursor.stepIndex)){
  if(m.facts().round===3&&action.actorId===seat&&action.phase==='main'&&!m.save().session){start=m.save();break;}
  m.apply(action);
 }
 assert(start);
}finally{m.dispose();}
function extract(envelope){
 const t=JSON.parse(envelope.committedState),p=t.players.players.find(p=>p.id===seat), cards=t.cards;
 const marks=Object.fromEntries(Object.entries(t.finalScoring.tiles).map(([id,tile])=>[id,tile.marks.filter(x=>x.playerId===seat)]));
 const sites=Object.fromEntries(Object.entries(t.data.nebulae).filter(([id])=>id.startsWith('sector-')));
 const transports=Object.values(t.aliens.chong?.transportTasksByRocketId||{}).filter(x=>x.playerId===seat||x.ownerId===seat);
 return {round:t.turn.roundNumber,turn:t.turn.turnNumber,currentPlayer:t.turn.currentPlayerId,paid:p.income,
  wallet:p.resources,tech:p.techState,hand:p.hand.map(c=>c.cardId),reserved:p.reservedCards.map(c=>c.cardId),pool:p.dataState.poolTokens,
  computer:data.listComputerPlacedTokens(p).map(x=>x.placementSlot),blue:data.listBlueBonusPlacedTokens(p).map(x=>x.blueSlot),
  probes:t.pieces.rockets.filter(r=>r.playerId===seat),planets:t.planets,
  sites,aliens:t.aliens.aliens,amiba:t.aliens.amiba?.revealInitialized?{symbolPositions:t.aliens.amiba.symbolPositions,displayedCardIndex:t.aliens.amiba.displayedCardIndex}:null,
  transports,marks,market:cards.publicCards.map(c=>c?.cardId??null),drawCount:cards.drawPileCardIds.length,
  deckFingerprint:require('node:crypto').createHash('sha256').update(JSON.stringify(cards.drawPileCardIds)).digest('hex')};
}
const first2=get(dir+'/v189-first2-save.json'),full=get(dir+'/v189-full.json');
assert.deepEqual(first2.replaySteps,full.replaySteps.slice(0,125));
const v189Start={committedState:first2.committedState,session:first2.session};
assert.equal(extract(v189Start).round,3);
const rows=[
 ['V189',v189Start,cp(dir+'/v189-round-end-3.json'),v189.summary.scores[seat]],
 ['standard',start,cp(std.roundEnds[2].checkpointPath),null],
 ['teacher',teacher,cp(dir+'/teacher-round-end-3.json'),null],
 ['teacher-start AI',teacher,auto.result.settled.state,null],
].map(([label,start,end,terminal])=>({label,start:extract(start),end:extract(end),terminal}));
const compact=x=>({round:x.round,turn:x.turn,active:x.currentPlayer,w:x.wallet,paid:x.paid,tech:x.tech,hand:x.hand,comp:x.computer,blue:x.blue,p:x.probes.map(r=>[r.sectorX,r.sectorY,r.fossilId??null]),marks:Object.keys(x.marks).filter(k=>x.marks[k].length),market:x.market,drawCount:x.drawCount});
for(const row of rows)console.log(JSON.stringify([row.label,compact(row.start),compact(row.end),row.terminal]));
writeZ(out,{rows});
