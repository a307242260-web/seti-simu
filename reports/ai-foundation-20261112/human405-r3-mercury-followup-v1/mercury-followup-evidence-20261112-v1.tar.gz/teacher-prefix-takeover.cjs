'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ,autonomous}=require('./controlled-r3');
const [from,out]=process.argv.slice(2),e=readZ(from),rows=[];
for(const step of [133,136,141,147,148]){
 const entry=e.steps.find(x=>x.input===step);assert(entry);
 const m=open(entry.before,{preferredReserve:{'player-green':'b_138.webp','player-blue':'b_55.webp','player-brown':'dlc_12.png'},version:'seti-human405-pass-only-teacher-r3-v1'});
 try{
  const u=autonomous(m),peak=[Math.max(0,...u.actions.map(r=>r.n||0)),Math.max(0,...u.actions.map(r=>r.ms||0))];
  assert.deepEqual(m.save(),entry.before);
  rows.push({step,root:entry.before,opening:entry.assets,peak,...u});
  console.log(JSON.stringify({step,first:u.actions[0]?.action?.summary,stop:u.stop,peak,opening:entry.assets,settled:u.settled?.summary}));
 }finally{m.dispose();}
}
writeZ(out,{rows});
