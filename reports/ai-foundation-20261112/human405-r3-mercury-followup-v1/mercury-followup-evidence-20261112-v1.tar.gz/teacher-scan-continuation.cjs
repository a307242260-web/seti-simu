'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ,autonomous}=require('./controlled-r3');
const [from,out]=process.argv.slice(2),data=readZ(from),seat='player-white',rows=[];
for(const branch of data.rows.filter(x=>[3,4].includes(x.length))){
 const m=open(data.root,{preferredReserve:{'player-green':'b_138.webp','player-blue':'b_55.webp','player-brown':'dlc_12.png'},version:'seti-human405-pass-only-teacher-r3-v1'});
 try{
  const [scan,sector,first]=branch.fixed;[scan,sector,first].forEach(m.apply);
  const record=[],actions=[];let cp,root,states;
  for(let i=0;i<3;i++){
   const before=m.save(),cold=m.automatic(),retained=m.automatic(cp);
   const e={before,assets:short(m),cold:{a:cold.a,n:cold.n,ms:cold.ms,value:cold.value,roots:cold.roots},
    retained:{a:retained.a,n:retained.n,ms:retained.ms,value:retained.value,roots:retained.roots},legal:m.menu()};
   record.push(e);
   if(i===2){root=before;states=e;break;}
   const a=i===0&&branch.length===4?branch.fixed.at(-1):retained.a;
   cp=a.actionId===retained.a.actionId?retained.checkpoint:null;
   actions.push(m.apply(a));
  }
  const arms=[];
  for(const a of states.legal){
   m.restore(root);m.apply(a);const settled=short(m),r=autonomous(m);
   m.restore(root);m.apply(a);r.actions.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),r.end);
   arms.push({a,settled,result:r});
   console.log(JSON.stringify({publicChoice:actions[0].summary,postLaunch:a.summary,quoted:[states.cold.a.summary,states.retained.a.summary],
    immediately:settled,round3:r.settled?.summary,stop:r.stop}));
  }
  rows.push({length:branch.length,root,record,actions,arms});
 }finally{m.dispose();}
}
writeZ(out,{rows});
