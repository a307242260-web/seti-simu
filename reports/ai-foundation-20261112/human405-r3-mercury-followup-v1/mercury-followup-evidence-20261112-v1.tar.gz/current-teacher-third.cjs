'use strict';
const path=require('node:path'),assert=require('node:assert/strict'),{open,short,writeZ,autonomous}=require('./controlled-r3');
const teacher=require(path.resolve('tools/research-human405-round1'));
const fixture=teacher.thirdRoundOpening(),e=fixture.checkpoint.coreState.compositionEnvelope;
const m=open(e,{preferredReserve:{'player-green':'b_138.webp','player-blue':'b_55.webp','player-brown':'dlc_12.png'},version:'seti-human405-pass-only-teacher-r3-v1'});
try {
 assert.deepEqual(m.save(),e);
 const opening=short(m),result=autonomous(m);
 const peak=[Math.max(0,...result.actions.map(x=>x.n||0)),Math.max(0,...result.actions.map(x=>x.ms||0))];
 console.log(JSON.stringify({opening,stop:result.stop,settled:result.settled?.summary,peak,actions:result.actions.length,main:result.roots.map(x=>x.action.summary)}));
 writeZ(process.argv[2],{provenance:fixture.provenance,opening,peak,result});
} finally{m.dispose();}
