'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),{open,readZ,writeZ,autonomous}=require('./controlled-r3');
const {origin,steps}=readZ('randomizer/game/ai/fixtures/teacher-mercury-followup-20261112-v1.json.gz');
const out=process.argv[2],variant=process.argv[3],swap=variant==='base'?null:variant.split(',').map(Number);
const committed=JSON.parse(origin.committedState);
if(swap){const [i,j]=swap,d=committed.cards.drawPileCardIds;[d[i],d[j]]=[d[j],d[i]];}
const root={...origin,committedState:JSON.stringify(committed)},seat='player-white';
const m=open(root,{preferredReserve:{'player-green':'b_138.webp','player-blue':'b_55.webp','player-brown':'dlc_12.png'},version:'seti-human405-pass-only-teacher-r3-v1'});
try{
 steps.slice(0,3).forEach(m.apply);
 const menuRoot=m.save(),obs=m.owner(seat),menu=m.menu(),checks=[];let cp;
 for(const wanted of steps.slice(3)){
  const before=m.save(),q=m.automatic(cp);
  assert(q.complete&&q.n<=256&&q.ms<=600);
  assert.equal(q.a.actionId,wanted.actionId);assert.deepEqual(m.save(),before);
  if(cp){const cold=m.automatic();assert(cold.complete&&cold.n<=256&&cold.ms<=600);assert.equal(cold.a.actionId,q.a.actionId);}
  checks.push({a:q.a,n:q.n,ms:q.ms,value:q.value,roots:q.roots});
  cp=q.checkpoint;m.apply(q.a);
 }
 const suffix=autonomous(m);
 assert.equal(suffix.stop,'r4-first-white-main');
 const data={root,variant,menuRoot,menu,obs,checks,suffix};
 if(swap){const b=readZ(out.replace('swap-'+variant,'base'));assert.deepEqual(obs,b.obs);assert.deepEqual(menu,b.menu);
  assert.equal(JSON.stringify(checks[0].roots),JSON.stringify(b.checks[0].roots));
  assert.equal(checks[0].value,b.checks[0].value);assert.equal(checks[0].n,b.checks[0].n);}
 writeZ(out,data);
 console.log(JSON.stringify({variant,checks:checks.map(x=>[x.a.summary,x.n,x.ms,x.value]),settled:suffix.settled.summary,
  peak:[Math.max(...suffix.actions.map(x=>x.n||0)),Math.max(...suffix.actions.map(x=>x.ms||0))]}));
}finally{m.dispose();}
