'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {open,readZ,short}=require('./controlled-r3');
const load=n=>require(path.resolve('randomizer/game/ai/'+n));
const {evaluateStateValue}=load('state-value'),{createAnalysisPort}=load('analysis-port'),demand=load('resource-demand');
const [input,out]=process.argv.slice(2),seat='player-white',results=[];
for(const spec of readZ(input).rows){
 const m=open(spec.root),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try {
  const root=port.openRoot(), before=m.save();let node=root;
  const take=(label,obs)=>({label,...evaluateStateValue(obs,seat),
   paid:obs.publicState.players.find(x=>x.playerId===seat).income,
   hand:obs.selfState.hand.map(x=>[x.cardId??null,x.hidden??false]),
   market:obs.publicState.board.publicCards.map(x=>x?.cardId??null)});
  const src=take('root',port.valueObservation(root));
  const frames=[];
  if(spec.offer.family==='pass'){
   const leaf=port.expand(root,spec.offer.actionId);
   frames.push({...take('PASS masked',port.valueObservation(leaf)),boundary:leaf.boundary});
   assert.deepEqual(m.save(),before);
   m.apply(spec.offer);
  }else{
   for(const a of spec.actions.slice(0,4)){
    node=port.expand(node,a.actionId);
    frames.push({...take(a.summary,port.valueObservation(node)),boundary:node.boundary});
   }
   assert.deepEqual(m.save(),before);
   for(const a of spec.actions.slice(0,10)){
    m.apply(a);const p=m.player();
    const f=demand.forecastDataPlan(m.state(),p);
    frames.push({...take('native:'+a.summary,m.owner(seat)),assets:short(m),
     forecast:f?.fixed?.selected||null});
   }
  }
  const compact=o=>({label:o.label,total:o.total,components:Object.fromEntries(Object.entries(o.components).filter(([,v])=>v)),hand:o.hand,market:o.market,boundary:o.boundary});
  console.log(JSON.stringify([spec.offer.family,[src,...frames].map(compact)]));
  results.push({family:spec.offer.family,src,frames});
 }finally{port.close();m.dispose();}
}
fs.writeFileSync(out,JSON.stringify(results,null,2)+'\n',{flag:'wx'});
