'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ,autonomous}=require('./controlled-r3');
const [from,out]=process.argv.slice(2),e=readZ(from),rows=[],entry=e.steps.find(x=>x.input===141);
const sequence=e.steps.filter(x=>x.input>=141&&x.input<=146).map(x=>x.actual);
assert.equal(sequence.length,6);
for(const length of [1,2,3,4]){
 const m=open(entry.before,{preferredReserve:{'player-green':'b_138.webp','player-blue':'b_55.webp','player-brown':'dlc_12.png'},version:'seti-human405-pass-only-teacher-r3-v1'});
 try{
  const fixed=sequence.slice(0,length).map(m.apply);
  const u=autonomous(m),peak=[Math.max(0,...u.actions.map(r=>r.n||0)),Math.max(0,...u.actions.map(r=>r.ms||0))];
  m.restore(entry.before);fixed.forEach(m.apply);u.actions.forEach(r=>m.apply(r.action));assert.deepEqual(m.save(),u.end);
  rows.push({length,fixed,peak,...u});
  console.log(JSON.stringify({length,first:u.actions.slice(0,5).map(x=>x.action.summary),stop:u.stop,peak,settled:u.settled?.summary}));
 }finally{m.dispose();}
}
writeZ(out,{root:entry.before,rows});
