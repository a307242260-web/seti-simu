'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ,autonomous}=require('./controlled-r3');
const [from,out]=process.argv.slice(2),e=readZ(from),rows=[];
for(const step of [120,121,128,137]){
 const entry=e.steps.find(x=>x.input===step);assert(entry&&entry.complete&&entry.n<=256&&entry.ms<=600);
 for(const [label,action] of [['teacher',entry.actual],['preferred',entry.preferred]]){
  const m=open(entry.before,{preferredReserve:{'player-green':'b_138.webp','player-blue':'b_55.webp','player-brown':'dlc_12.png'},version:'seti-human405-pass-only-teacher-r3-v1'});
  try{
   const fixed=m.apply(action),after=short(m),u=autonomous(m);
   const peak=[Math.max(0,...u.actions.map(r=>r.n||0)),Math.max(0,...u.actions.map(r=>r.ms||0))];
   m.restore(entry.before);m.apply(fixed);u.actions.forEach(r=>m.apply(r.action));assert.deepEqual(m.save(),u.end);
   rows.push({step,label,fixed,after,peak,...u});
   console.log(JSON.stringify({step,label,fixed:action.summary,score:u.settled?.summary?.wallet[0],end:u.settled?.summary,stop:u.stop,peak}));
  }finally{m.dispose();}
 }
}
writeZ(out,{rows});
