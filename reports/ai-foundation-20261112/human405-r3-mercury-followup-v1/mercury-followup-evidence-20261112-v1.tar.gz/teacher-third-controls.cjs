'use strict';
const path=require('node:path'),assert=require('node:assert/strict'),{open,short,writeZ}=require('./controlled-r3');
const teacher=require(path.resolve('tools/research-human405-round1'));
const opening=teacher.thirdRoundOpening().checkpoint.coreState.compositionEnvelope,seat='player-white';
const cases=[['teacher-landing',true,false],['purple2',false,true],['teacher-landing-purple2',true,true]],out=[];
for(const [label,cardLanding,purple2] of cases){
 const m=open(opening,{preferredReserve:{'player-green':'b_138.webp','player-blue':'b_55.webp','player-brown':'dlc_12.png'},version:'seti-human405-pass-only-teacher-r3-v1'});
 const actions=[],fixed=[],checks=[],main=[];let cp,stop,settled,forcedPurple=false;
 const applyFixed=a=>{const r=m.apply(a);actions.push(r);fixed.push(r);cp=null;return r;};
 try{
  if(cardLanding){
   const record=JSON.parse(require('node:fs').readFileSync(process.argv[2]));
   for(const {action} of record.replaySteps.slice(112,115))applyFixed(action);
  }
  for(let i=0;i<220;i++){
   if(m.menu()[0].actorId!==seat){m.advanceOpponents(actions);continue;}
   if(m.facts().round===4&&!m.save().session){stop='r4-first-white-main';break;}
   const q=m.automatic(cp),a=q.a;
   if(!q.complete||!a||q.n>256||q.ms>600){stop={gate:[a?.summary,q.n,q.ms],root:m.save()};break;}
   if(purple2&&!forcedPurple&&a.target?.tileId==='purple1'){
    const substitute=m.menu().find(x=>x.target?.tileId==='purple2');
    if(substitute){applyFixed(substitute);forcedPurple=true;continue;}
   }
   if(a.family==='pass'&&m.facts().round===3)settled={state:m.save(),assets:m.facts(),summary:short(m)};
   if(a.phase==='main')main.push([actions.length+113,a.family,a.summary,q.value]);
   checks.push([q.n,q.ms]);cp=q.checkpoint;actions.push(m.apply(a));
  }
  assert(stop);const end=m.save();m.restore(opening);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  const peak=[Math.max(0,...checks.map(r=>r[0])),Math.max(0,...checks.map(r=>r[1]))];
  out.push({label,actions,fixed,main,checks,settled,end,peak,stop});
  console.log(JSON.stringify({label,fixed:fixed.map(a=>a.summary),settled:settled?.summary,peak,stop:typeof stop==='string'?stop:stop.gate,main}));
 }finally{m.dispose();}
}
writeZ(process.argv[3],{opening,rows:out});
