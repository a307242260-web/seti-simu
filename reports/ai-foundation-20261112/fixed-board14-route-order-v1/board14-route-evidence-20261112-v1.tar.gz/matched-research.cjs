'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [earlier,later,out]=process.argv.slice(2),base=readZ(earlier).rows.find(x=>x.name==='14-125'),control=readZ(later).rows.find(x=>x.timing==='instead-of-corner');
const index=base.accepted.findIndex(x=>x.a.summary==='dlc_19.png：弃牌角标');
const rows=[];
for(const [label,path] of [['discard',base.accepted.slice(index)],['play',control.accepted]]){
 const m=open(control.root),chosen=[];
 try{
  for(const x of path){
   chosen.push(m.apply(x.a));
   if(chosen.some(a=>a.summary.includes('研究 blue1'))&&x.a.summary==='b_33.webp')break;
  }
  assert(chosen.some(a=>a.summary==='研究 blue1（蓝槽 4）'));assert.equal(chosen.at(-1).summary,'b_33.webp');
  const end=m.save(),assets=short(m),facts=m.facts();
  m.restore(control.root);chosen.forEach(m.apply);assert.deepEqual(m.save(),end);
  rows.push({label,root:control.root,chosen,end,assets,facts});
  console.log(JSON.stringify({label,actions:chosen.map(a=>a.summary),assets,rng:facts.rng}));
 }finally{m.dispose();}
}
assert.deepEqual(rows[0].facts.tech,rows[1].facts.tech);
assert.deepEqual(rows[0].facts.income,rows[1].facts.income);
assert.deepEqual(rows[0].facts.rng,rows[1].facts.rng);
writeZ(out,{rows});
