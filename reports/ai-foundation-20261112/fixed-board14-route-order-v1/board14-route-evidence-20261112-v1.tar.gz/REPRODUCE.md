# 第 14 盘同根路线顺序
Node 22，从 SETI 仓库根目录执行。解包到 CASE_DIR，用 `shasum -a 256 -c SHA256SUMS` 核验内容。先从上一份第 14 盘收入证据包中解出 known-sector-floor.js、income-purpose-section.js、income-candidate-ff577dea-20261112-v1.json.gz 和 income-combined-suffix-ff577dea-20261112-v1.json.gz 到 CASE_DIR。

```sh
node "$CASE_DIR/ledger.cjs" "$CASE_DIR/known-sector-floor.js" "$CASE_DIR/income-candidate-ff577dea-20261112-v1.json.gz" "$CASE_DIR/ledger-check.json.gz" "$CASE_DIR/income-purpose-section.js"
node "$CASE_DIR/use-signal-later.cjs" "$CASE_DIR/known-sector-floor.js" "$CASE_DIR/income-candidate-ff577dea-20261112-v1.json.gz" "$CASE_DIR/later-check.json.gz" "$CASE_DIR/income-purpose-section.js" "$CASE_DIR/income-combined-suffix-ff577dea-20261112-v1.json.gz"
node "$CASE_DIR/matched-research.cjs" "$CASE_DIR/income-combined-suffix-ff577dea-20261112-v1.json.gz" "$CASE_DIR/later-check.json.gz" "$CASE_DIR/matched-check.json.gz"
```

候选只在临时 Node 进程内加载，不改正式策略。受控路线分别只固定一处出牌，末轮保留 B117 与原对照相同。所有已接受动作独立重放，完整终态一致；未修改、不读取猜测的盲抽身份。
