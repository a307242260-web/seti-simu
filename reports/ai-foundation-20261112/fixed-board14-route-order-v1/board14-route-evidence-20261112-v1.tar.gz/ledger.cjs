'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path'),Module=require('node:module');
const [source,diagnostics,out]=process.argv.slice(2),p=path.resolve('randomizer/game/ai/sector-card-capital.js'),base=fs.readFileSync(p,'utf8');
const patched=new Module(p,module);patched.filename=p;patched.paths=Module._nodeModulePaths(path.dirname(p));require(p);
const anchor=' function quote(facts,weights,portfolio,currentCapital){';
const extra=[
 '  for(const card of facts.hand){',
 '   const floor=knownSectorFloor(facts,weights,card);',
 '   if(!floor)continue;',
 '   const after={...facts,player:{...facts.player,handSize:facts.player.handSize-1},hand:facts.hand.filter(c=>c.id!==card.id)};',
 '   const other=portfolio(after),netGain=arithmetic.sum([floor.utility,Math.min(currentCapital,other),-currentCapital],weights);',
 "   candidates.push({...floor,netGain,kind:'known-two-signal-sector-floor'});",
 '  }',
 '  for(const card of eligible){'
].join('\n');
const code=base.replace(anchor,fs.readFileSync(source,'utf8')+anchor)
 .replace('if(!eligible.length||facts.terminal||facts.round+Number(facts.passing)>=4)','if(facts.terminal||facts.round+Number(facts.passing)>=4)')
 .replace('  for(const card of eligible){',extra)
 .replace('Object.freeze({supported,quote})','Object.freeze({supported,quote,knownSectorFloor})');
assert(code!==base);patched._compile(code,p);require.cache[p].exports=patched.exports;
const rp=path.resolve('randomizer/game/ai/resource-demand.js'),demandBase=fs.readFileSync(rp,'utf8'),rd=new Module(rp,module);
rd.filename=rp;rd.paths=Module._nodeModulePaths(path.dirname(rp));require(rp);
const demandAnchor='  function rankIncomeChoices(state,p,rows){';
let demandCode=demandBase.replace('root.SetiAlienChong);','root.SetiAlienChong,common?require(\'../aliens/state\'):root.SetiAlienState);')
 .replace('incomeOrder,scanIncome,techCatalog,chong){','incomeOrder,scanIncome,techCatalog,chong,alienState){')
 .replace(demandAnchor,fs.readFileSync(process.argv[5],'utf8')+demandAnchor)
 .replace('    rows.sort((a,b)=>b.value-a.value||incomeOrder.compare(a.card,b.card));','    rows.sort((a,b)=>b.value-a.value||incomeOrder.compare(a.card,b.card));\n    const retained=retainedSectorIncome(state,p,rows);if(retained)return retained.row;')
 .replace('VERSION,MONEY,isPreparation','retainedSectorIncome,VERSION,MONEY,isPreparation');
assert(demandCode!==demandBase);rd._compile(demandCode,rp);require.cache[rp].exports=rd.exports;
const ds=path.resolve('randomizer/game/ai/decision-search.js'),dm=new Module(ds,module);
dm.filename=ds;dm.paths=Module._nodeModulePaths(path.dirname(ds));require(ds);
const hook=[
 '    const ledger=roots.filter(r=>r.value!=null).map(r=>{',
 '      const edge=nodes[0].edges.find(e=>e.actionId===r.actionId&&e.target===r.target);',
 '      if(!edge)return null;',
 '      const path=[edge],entries=[];',
 '      let at=nodes[edge.target];',
 '      while(at.best&&nodes[at.best.target].distance<at.distance){entries.push(at.node.status);path.push(at.best);at=nodes[at.best.target];}',
 '      const node=at.node,status=node.status,summary=node.planSummary||null;',
 '      const actual=status==="turn-tail-value"?port.turnTailBase(node):status==="income-plan-value"?port.incomePlanBase(node):node;',
 '      const ob=observationForValue(actual),player=ob.publicState.players.find(p=>p.playerId===evaluate.seatId);',
 '      const fact=stateValue.evaluateStateValue(ob,evaluate.seatId);',
 '      return {r,path:path.map(e=>({steps:e.steps,goal:e.resourcePlan?.goal||e.goalPlan?.objective,goalStatus:e.goalStatus})),entries,status,summary,',
 '        leaf:{score:player.score,finalScore:player.finalScore,wallet:[player.credits,player.energy,player.publicity,player.availableData],',
 '          hand:ob.selfState.hand.map(c=>[c.id,c.cardId,!!c.hidden]),income:player.income,tech:Object.keys(player.techState.ownedTiles),',
 '          value:fact.total,components:fact.components,aliens:ob.publicState.board.aliens.slots.map(x=>[x.revealed,x.alienId])}};',
 '    }).filter(Boolean);',
 '    const elapsed = now() - startedAt;'
].join('\n');
const original=fs.readFileSync(ds,'utf8'),sig='    const elapsed = now() - startedAt;';
assert.equal(original.split(sig).length,2);
dm._compile(original.replace(sig,hook).replace('schemaVersion: VERSION, complete: accepted,','schemaVersion: VERSION, complete: accepted, ledger,'),ds);
require.cache[ds].exports=dm.exports;
const {open,readZ,writeZ}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));
const [,,, , ,fixture]=process.argv.slice(2);
const rows=[];
for(const c of readZ(diagnostics).rows.filter(x=>['14-125','board14-income'].includes(x.name))){
 const m=open(c.root),seatId='player-white',p=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
 try{
  const q=createSearchAgent({analysisPort:p,seatId}).decide({seatId,legalActions:m.menu()}).search;
  assert(q.complete&&!q.unresolved.length&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600);
  const keys=new Set(m.menu().filter(a=>['scan','launch','choose_card'].includes(a.family)||a.summary==='2能量 → 1信用点').map(a=>a.actionId));
  const summaries=new Map(m.menu().map(a=>[a.actionId,a.summary]));
  const row={name:c.name,root:c.root,results:q.ledger.filter(x=>keys.has(x.r.actionId)).map(x=>({name:summaries.get(x.r.actionId),...x})),roots:q.roots,n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds};
  rows.push(row);
  for(const x of row.results)console.log(JSON.stringify({name:c.name,action:x.name,value:x.r.value,status:x.status,path:x.path,leaf:x.leaf}));
 }finally{p.close();m.dispose();}
}
writeZ(out,{rows});
