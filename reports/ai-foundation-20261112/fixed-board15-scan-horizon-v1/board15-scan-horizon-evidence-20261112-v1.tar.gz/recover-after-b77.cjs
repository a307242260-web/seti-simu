'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const D=require(path.resolve('randomizer/game/ai/resource-demand'));
const [dir,out]=process.argv.slice(2),seat='player-white',rows=[],admit=q=>q.complete&&q.a&&q.n<=256&&q.ms<=600;
for(const world of [0,4,6]){
 const sample=readZ(path.join(dir,'paired-scan-'+world+'-ff577dea-20261112-v1.json.gz')),base=sample.rows[0],m=open(sample.root);
 try{
  const first=base.moves.findIndex(x=>x.a.summary==='dlc_38.png：弃牌角标');
  assert(first>0);base.moves.slice(0,first).forEach(x=>m.apply(x.a));const root=m.save(),before=short(m),cold=m.automatic();
  assert(admit(cold));const goal={kind:'scan-flow',required:{credits:1,energy:2}};
  const greedy=D.paymentCards(m.state(),seat,goal,2);
  const protect=m.player().hand.find(c=>c.cardId==='dlc_38.png').id;
  assert(greedy.includes(protect));
  const keep=greedy.map(id=>id===protect?m.player().hand.find(c=>c.cardId==='dlc_41.png').id:id);
  assert.equal(new Set(keep).size,2);
  for(const [label,ids] of [['greedy',greedy],['keep-income',keep]]){
   m.restore(root);const start=performance.now(),moves=[],rounds={},checks=[];
   const apply=a=>moves.push({a:m.apply(a),fixed:true});
   const action=(family,p=()=>true)=>{const a=m.menu().find(a=>a.family===family&&p(a));assert(a,JSON.stringify(m.menu().map(a=>[a.family,a.summary])));apply(a);};
   action('quick_trade',a=>a.target.tradeId==='cards-for-credit');
   for(const id of ids)action('choose_payment',a=>a.target.cardInstanceId===id&&a.target.select);
   action('choose_payment',a=>a.summary.includes('确认弃牌'));
   action('scan');
   let cp,stop;
   for(let i=0;i<200;i++){
    if(m.state().turn.gameEnded){stop='terminal';break;}
    if(m.menu()[0].actorId!==seat){const rest=[];m.advanceOpponents(rest);moves.push(...rest.map(a=>({a,passive:true})));continue;}
    const q=m.automatic(cp);
    if(!admit(q)){stop={gate:{a:q.a?.summary,n:q.n,ms:q.ms,complete:q.complete}};break;}
    const f=m.facts();if(q.a.family==='pass')rounds[f.round]=short(m);
    checks.push({n:q.n,ms:q.ms});cp=q.checkpoint;moves.push({a:m.apply(q.a)});
   }
   assert(stop);const wallMs=Math.round(performance.now()-start),end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore??null;
   m.restore(root);moves.forEach(x=>m.apply(x.a));assert.deepEqual(m.save(),end);
   const peak=[Math.max(cold.n,...checks.map(x=>x.n)),Math.round(Math.max(cold.ms,...checks.map(x=>x.ms)))];
   rows.push({world,label,ids,base:base.terminal,before,root,cold:{n:cold.n,ms:cold.ms,a:cold.a.summary,v:cold.value,roots:cold.roots},terminal,rounds,moves,stop,peak,wallMs,end});
   console.log(JSON.stringify({world,label,base:base.terminal,terminal,rounds,stop,peak,first:moves.slice(0,19).map(x=>x.a.summary)}));
  }
 }finally{m.dispose();}
}
writeZ(out,{rows});
