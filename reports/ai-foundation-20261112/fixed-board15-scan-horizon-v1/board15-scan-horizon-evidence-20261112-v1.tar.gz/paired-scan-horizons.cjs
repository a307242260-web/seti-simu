'use strict';
const {readZ,writeZ,open,short}=require('./controlled-r3'),path=require('node:path'),assert=require('node:assert/strict');
const [dir,out]=process.argv.slice(2),seat='player-white',V=require(path.resolve('randomizer/game/ai/state-value')),rows=[];
for(const run of [0,1,2,3,4,5,6,'20-0']){
 const caseFile=readZ(path.join(dir,'paired-scan-'+run+'-ff577dea-20261112-v1.json.gz'));
 for(const branch of caseFile.rows){
  const m=open(caseFile.root),frames=[],seen=new Set();
  try{
   const add=(id,at,reason)=>{
    if(seen.has(id))return;seen.add(id);
    const f=m.facts(),o=m.owner(seat),q=V.evaluateStateValue(o,seat);
    frames.push({id,at,reason,value:q.total,components:q.components,assets:short(m),
      menu:m.menu().filter(a=>a.phase==='main').map(a=>a.summary),nAvailable:ranges(o.publicState.board.data),nextMark:o.selfState.nextFinalMark?.threshold});
   };
   const ranges=board=>Object.fromEntries(Object.entries(board.nebulae).map(([id,n])=>[id,n.tokens.reduce((a,t)=>{
    if(!t.replacedByPlayerId&&!t.replacedByPlayerColor)a[0]++;
    else if(t.replacedByPlayerId===seat)a[1]++;
    return a;
   },[0,0])]));
   for(const [i,{a}] of branch.moves.entries()){
    const f=m.facts();
    if(f.round===3&&a.actorId===seat&&!m.save().session){
     if(!f.main&&i>0)add('next-'+f.turn,i,a.summary);
     if(f.main&&a.family==='end_turn')add('end-'+f.turn,i,a.summary);
     if(a.family==='pass')add('pass-'+f.turn,i,a.summary);
    }
    m.apply(a);
   }
   assert.deepEqual(m.save(),branch.end);
   rows.push({run,first:branch.first,frames});
   if([0,4,6,'20-0'].includes(run))console.log(JSON.stringify({run,first:branch.first,frames:frames.map(f=>[f.id,f.value,f.assets.wallet,f.menu,f.reason])}));
  }finally{m.dispose();}
 }
}
writeZ(out,{rows});
