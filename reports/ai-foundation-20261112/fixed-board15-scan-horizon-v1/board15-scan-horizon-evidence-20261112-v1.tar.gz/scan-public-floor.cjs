'use strict';
const {readZ,writeZ,open}=require('./controlled-r3'),path=require('node:path'),assert=require('node:assert/strict');
const req=n=>require(path.resolve('randomizer/game',n)),science=req('effects/science-session'),data=req('data'),scan=req('actions/scan-effects'),cards=req('cards/deck');
const [dir,out]=process.argv.slice(2),rows=[],seat='player-white';
const codeToSectors=Array.from({length:4},(_,code)=>({code,id:'class-'+code,scanActionCode:code}));
for(const key of [0,'20-0']){
 const p=readZ(path.join(dir,'paired-scan-'+key+'-ff577dea-20261112-v1.json.gz'));
 for(const branch of p.rows){
  const m=open(p.root);
  try{
   const known=new Set(m.state().cards.publicCards.filter(Boolean).map(c=>c.id)),first=branch.moves.findIndex(x=>x.a.actorId===seat&&x.a.family==='end_turn');
   assert(first>0);branch.moves.slice(0,first).forEach(x=>m.apply(x.a));
   const s=m.state(),owner=m.player(),w=owner.resources,cost=scan.getStandardScanCost(owner),cash=[w.credits,w.energy],tech=data.listComputerPlacedTokens(owner).map(t=>t.placementSlot);
   const slots=s.cards.publicCards.map(c=>!c?null:known.has(c.id)?Number(c.scanActionCode??cards.getCatalogEntryForCard(c).scan_action_code):'?');
   const deficit=Math.max(0,6-tech.length-w.availableData);
   const row={board:key===0?15:20,first:branch.first,cash,cost,tech,deficit,slots,fillable:w.credits>=cost.credits&&w.energy>=cost.energy,classes:[]};
   if(row.fillable){
    const first=scan.buildScanEffectQueue(owner,{turn:s.turn})[0],earth=science.listNebulaChoices(s,{...science.getPlanetScanSource(s,first.type),gainData:true}).map(a=>a.target.nebulaId);
    const byCode=new Map(codeToSectors.map(c=>[c.code,science.listPublicScanChoices({...s,cards:{...s.cards,publicCards:[c]}}).map(a=>a.target.nebulaId)]));
    const sector=Object.fromEntries(Object.keys(s.data.nebulae).map(id=>{
     const next=new Set(),index=[];
     for(;;){const t=data.getNextReplaceableNebulaToken(s.data,id,next);if(!t)break;assert(!next.has(t.id));next.add(t.id);index.push(t.slotIndex);}
     const r=data.getSectorRanking(s.data,id);
     return [id,{index,mine:r.find(x=>x.playerId===seat)?.count||0,rival:Math.max(0,...r.filter(x=>x.playerId!==seat).map(x=>x.count))}];
    }));
    const visit=(a,i)=>{
     if(i===slots.length){consider(a);return;}
     for(const code of slots[i]==='?'?[0,1,2,3]:[slots[i]])visit([...a,code],i+1);
    };
    function consider(a){
     let maxData=0,maxScore=0,maxWins=0,analysisFloorScore=null,analyticalPlan=null;
     const n=1+(w.additionalPublicScan||0),ids={};
     const add=(id,sign)=>{ids[id]=(ids[id]||0)+sign;};
     const v=()=>Object.entries(ids).reduce((r,[id,x])=>{
      const {index,mine,rival}=sector[id];
      r.rawData+=x;
      r.score+=index.slice(0,x).reduce((z,i)=>z+data.getNebulaSlotScoreReward(id,i),0);
      r.strictWins+=Number(x>0&&x===index.length&&mine+x>rival&&id!=='aomomo');
      return r;
     },{rawData:0,score:0,strictWins:0});
     function play(i,left){
      if(i===a.length||left===0){
       const s=v();maxData=Math.max(maxData,s.rawData);maxScore=Math.max(maxScore,s.score);maxWins=Math.max(maxWins,s.strictWins);
       if(s.rawData>=deficit&&s.score>(analysisFloorScore??-1)){analysisFloorScore=s.score;analyticalPlan={...ids};}
       return;
      }
      play(i+1,left);
      if(a[i]===null)return;
      for(const id of byCode.get(a[i])||[]){
       if((ids[id]||0)>=sector[id].index.length)continue;
       add(id,1);play(i+1,left-1);add(id,-1);
      }
     }
     for(const id of [null,...earth]){if(id){if(!sector[id].index.length)continue;add(id,1);}
      play(0,n);if(id)add(id,-1);
     }
     row.classes.push({codes:a,maxData,maxScore,maxWins,analysisFloorScore,analyticalPlan});
    }
    visit([],0);
   }
   rows.push(row);
   console.log(JSON.stringify({...row,classes:row.classes.length,
    dataFloor:row.classes.length?Math.min(...row.classes.map(c=>c.maxData)):null,
    scoreWhenReady:row.classes.length?[Math.min(...row.classes.map(c=>c.analysisFloorScore??-1)),Math.max(...row.classes.map(c=>c.analysisFloorScore??-1))]:null,
    winningClasses:row.classes.filter(c=>c.maxWins>0).length}));
  }finally{m.dispose();}
 }
}
writeZ(out,{rows});
