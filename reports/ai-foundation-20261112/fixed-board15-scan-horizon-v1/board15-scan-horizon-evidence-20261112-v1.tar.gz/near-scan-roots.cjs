'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path'),{open,writeZ,short}=require('./controlled-r3');
const [batch,out]=process.argv.slice(2),read=p=>JSON.parse(fs.readFileSync(p)),seat='player-white';
const targets=[...read(batch).rows.filter(x=>[9,14,15,16,20].includes(x.board)),{board:0,record:'4539c186.ff577dea.quick-400.json'}], rows=[];
for(const target of targets){
 const record=read(path.join('reports/research',target.record)),save=read(record.savePath),c=read(record.roundEnds[1].checkpointPath);
 const m=open(c.coreState.compositionEnvelope),seen=new Set();
 try{
  for(let i=c.replayCursor.stepIndex;i<record.roundEnds[2].beforeInput;i++){
   const move=save.replaySteps[i].action,menu=m.menu(),f=m.facts(),scan=menu.find(a=>a.family==='scan');
   if(move.actorId===seat&&scan&&f.round===3&&!seen.has(f.turn)){
    seen.add(f.turn);const q=m.automatic(),edge=q.roots?.find(x=>x.actionId===scan.actionId);
    const delta=edge?.value==null||q.value==null?null:q.value-edge.value;
    const row={board:target.board,input:i+1,turn:f.turn,old:move.summary,best:q.a?.summary,bestV:q.value,scanV:edge?.value,
      delta,assets:short(m),complete:q.complete,n:q.n,ms:q.ms};
    if(delta!=null&&delta<=3&&q.a?.family!=='scan'&&q.complete&&q.n<=256&&q.ms<=600)row.root=m.save();
    rows.push(row);console.log(JSON.stringify({...row,root:!!row.root,assets:[row.assets.wallet,row.assets.income,row.assets.computer,row.assets.probes.length]}));
   }
   m.apply(move);
  }
 }finally{m.dispose();}
}
writeZ(out,{rows});
