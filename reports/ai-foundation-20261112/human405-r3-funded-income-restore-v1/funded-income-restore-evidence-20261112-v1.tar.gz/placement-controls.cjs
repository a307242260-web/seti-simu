'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const q=__dirname,read=f=>JSON.parse(fs.readFileSync(f));
if(process.argv[3]==='before'){
 const orig=require.extensions['.js'];
 require.extensions['.js']=(m,p)=>{
  if(p===path.resolve('randomizer/game/ai/analysis-port.js')||p===path.resolve('randomizer/game/ai/decision-search.js'))
   return m._compile(fs.readFileSync(path.join(q,'before-'+path.basename(p)),'utf8'),p);
  return orig(m,p);
 };
}
const {open,writeZ}=require('./controlled-r3');
const baseline=read('reports/iteration/free-analyze-random20-funded-planet-20261111/summary-463fc442-20261111.json');
const plans=[['standard','c052b038.0852ceb0.quick-400.json'],...baseline.rows.filter(r=>[8,9,13].includes(r.board)).map(r=>[r.board,r.f])],rows=[];
for(const [label,name] of plans){
 const rec=read('reports/research/'+name),entries=read(rec.savePath).replaySteps;
 const cut2=read(rec.roundEnds[1].checkpointPath),cut3=read(rec.roundEnds[2].checkpointPath);
 const m=open(cut2.coreState.compositionEnvelope),hits=[];
 try{
  for(let i=cut2.replayCursor.stepIndex;i<cut3.replayCursor.stepIndex;i++){
   const a=entries[i].action;
   if(a.actorId==='player-white'&&a.family==='choose_target'&&['computer','blueBonus'].includes(a.target.target)){
    const f=m.facts(),remaining=f.wallet.availableData,filled=f.computer.length;
    if(f.round===3&&f.main&&filled>=1&&filled<=2&&remaining===4-filled&&f.hand.length===1&&m.menu().length>1){
     const u=m.automatic();assert(u.complete&&u.n<=256&&u.ms<=600);
     hits.push({step:i+1,action:u.a.actionId,value:u.value,n:u.n,ms:u.ms,roots:u.roots});
    }
   }
   m.apply(a);
  }
  assert.deepEqual(m.save(),cut3.coreState.compositionEnvelope);
  console.log(label,hits.length);rows.push({label,name,hits});
 }finally{m.dispose();}
}
writeZ(process.argv[2],{rows});
