'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),out=process.argv[2];
if(process.argv[3]==='before'){
 const orig=require.extensions['.js'];
 require.extensions['.js']=(m,p)=>{
  if(p===path.resolve('randomizer/game/ai/analysis-port.js')||p===path.resolve('randomizer/game/ai/decision-search.js'))
   return m._compile(fs.readFileSync(path.join(__dirname,'before-'+path.basename(p)),'utf8'),p);
  return orig(m,p);
 };
}
const {open,short,readZ,writeZ}=require('./controlled-r3'),seat='player-white';
const records=readZ(path.join(__dirname,'cold-tie-original-20261111.json.gz')),rows=[];
const gate=u=>{assert(u.a&&u.complete&&u.n<=256&&u.ms<=600);return {a:u.a,value:u.value,n:u.n,ms:u.ms,roots:u.roots};};
for(const [variant,r] of Object.entries(records)){
 const m=open(r.start);try{
  let cp;
  for(const a of r.inputs){
   const u=m.automatic(cp);gate(u);assert.equal(u.a.actionId,a.actionId);cp=u.checkpoint;m.apply(a);
  }
  const origin=m.save();assert.deepEqual(origin,r.details.e);
  const checks=[],actions=[];let settled;
  for(let i=0;i<16;i++){
   const warm=m.automatic(cp),cold=m.automatic();const [a,b]=[warm,cold].map(gate);
   checks.push({warm:a,cold:b});
   if(process.argv[3]!=='before')assert.equal(a.a.actionId,b.a.actionId);
   if(b.a.family==='end_turn'){settled={e:m.save(),short:short(m),wallet:m.facts().wallet,income:m.facts().income};break;}
   cp=warm.checkpoint;actions.push(m.apply(b.a));
  }
  assert(settled);
  m.restore(origin);actions.forEach(m.apply);assert.deepEqual(m.save(),settled.e);
  console.log(JSON.stringify({variant,checks:checks.map(x=>[x.warm.a.summary,x.cold.a.summary,x.warm.value,x.cold.value,x.warm.n,x.cold.n]),settled:settled.short}));
  rows.push({variant,origin,checks,actions,settled});
 }finally{m.dispose();}
}
writeZ(out,{rows});
