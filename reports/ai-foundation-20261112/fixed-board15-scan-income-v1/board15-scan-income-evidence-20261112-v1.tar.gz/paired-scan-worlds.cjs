'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [input,dir,boardArg='15']=process.argv.slice(2),board=Number(boardArg),seat='player-white',r=readZ(input).rows.find(x=>x.board===board&&x.label==='scan-first'),m=open(r.root);
const actions=[board===15?'2能量 → 1信用点':'发射','扫描'],admit=q=>q.complete&&q.a&&q.n<=256&&q.ms<=600;
const pub=m.owner(seat),deck=m.state().cards.drawPileCardIds,variants=[null,[[0,1]],[[0,4]],[[0,6]],[[0,5],[1,7]],[[0,7],[1,9]],[[0,5],[1,7],[2,9],[3,12]]];
function change(p){
 if(!p)return r.root;
 const e=structuredClone(r.root),s=JSON.parse(e.committedState),pile=s.cards.drawPileCardIds;
 assert.equal(e.session,null);
 for(const [i,j] of p)[pile[i],pile[j]]=[pile[j],pile[i]];e.committedState=JSON.stringify(s);return e;
}
try{
 for(const [world,pair] of (board===15?variants:[null]).entries()){
  const root=change(pair),file=path.join(dir,(board===15?'paired-scan-':'paired-scan-'+board+'-')+world+'-ff577dea-20261112-v1.json.gz');
  if(fs.existsSync(file))continue;
  m.restore(root);assert.deepEqual(m.owner(seat),pub);
  const cold=m.automatic();assert(admit(cold));
  const rows=[];
  for(const first of actions){
   const start=performance.now();
   m.restore(root);const action=m.menu().find(a=>a.summary===first);assert(action);
   const moves=[{a:m.apply(action),fixed:true}],rounds={},frames=[];
   let cp,stop;
   for(let i=0;i<200;i++){
    if(m.state().turn.gameEnded){stop='terminal';break;}
    if(m.menu()[0].actorId!==seat){const rest=[];m.advanceOpponents(rest);moves.push(...rest.map(a=>({a,passive:true})));continue;}
    const q=m.automatic(cp);
    if(!admit(q)){stop={gate:{action:q.a?.summary,n:q.n,ms:q.ms,complete:q.complete}};break;}
    const f=m.facts();
    if(q.a.family==='pass')rounds[f.round]={at:moves.length,assets:short(m),state:m.save()};
    if(q.a.phase==='main')frames.push({at:moves.length,round:f.round,a:q.a.summary,assets:short(m)});
    cp=q.checkpoint;moves.push({a:m.apply(q.a),n:q.n,ms:q.ms});
   }
   const wallMs=Math.round(performance.now()-start),end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore??null;
   assert(stop);m.restore(root);moves.forEach(x=>m.apply(x.a));assert.deepEqual(m.save(),end);
   const peak=[Math.max(cold.n,...moves.map(x=>x.n||0)),Math.round(Math.max(cold.ms,...moves.map(x=>x.ms||0)))];
   rows.push({first,moves,frames,rounds,stop,end,terminal,peak,wallMs});
   console.log(JSON.stringify({world,first,stop,terminal,peak,wallMs,rounds:Object.fromEntries(Object.entries(rounds).map(([k,v])=>[k,v.assets]))}));
  }
  writeZ(file,{world,pair,root,swapped:pair?.map(pair=>pair.map(i=>deck[i])),cold:{a:cold.a.summary,v:cold.value,n:cold.n,ms:cold.ms},rows});
 }
}finally{m.dispose();}
