'use strict';
const {open,readZ,writeZ,short}=require('./controlled-r3');
const assert=require('node:assert/strict'),path=require('node:path'),src=n=>require(path.resolve('randomizer/game/ai',n));
const V=src('state-value'),P=src('probe-capital'),R=src('ready-analysis-capital');
const [control,ledger,out]=process.argv.slice(2),seat='player-white',rows=[];
const roots=readZ(control).rows,known=readZ(ledger).rows;
function snapshot(m){
 const o=m.owner(seat),f=P.factsFromObservation(o,seat),a={...f,supply:f.board.techSupply,researchCost:f.player.researchPublicityCost,analyzeEnergyCost:R.energyCost(f.player.industryAbilityId)};
 const q=V.purposeCapital(a),v=V.evaluateStateValue(o,seat);
 return {assets:short(m),score:v.total,components:v.components,dataPlan:q.dataPlan,computerPotential:q.computerPotential,
   analysisPlan:q.analysisPlan,probePotential:q.probePotential,reserved:f.reservedCards.map(c=>c.cardId),aliens:f.board.aliens.slots.map(s=>[s.revealed,s.alienId])};
}
for(const {board,results} of known)for(const {name,path:route,r} of results){
 const c=roots.find(x=>x.board===board&&x.label==='scan-first'),m=open(c.root),taken=[],tail=[];
 const apply=a=>{assert(a,JSON.stringify(m.menu().map(x=>[x.summary,x.target])));const action=m.apply(a);taken.push(action);return action;};
 try{
  for(const id of route.flatMap(x=>x.steps||[]))apply(m.menu().find(a=>a.actionId===id));
  const checkpoint=m.save(),before=snapshot(m),rootHand=new Set(c.initial.known.hand.map(h=>h[0]));
  const witness=(pattern,filter)=>{const a=m.menu().find(a=>pattern.test(a.summary)&&(!filter||filter(a)));if(!a)return false;tail.push({a:apply(a),s:snapshot(m)});return true;};
  if(board===15&&name==='扫描'){
   for(const slot of [3,4]){
    if(!m.facts().computer.includes(slot)){assert(witness(/^放置数据$/));assert(witness(new RegExp('放置位 '+slot+'$')));}
   }
   assert(witness(/^收入 dlc_38.png$/,a=>rootHand.has(a.target.cardInstanceId)||rootHand.has(m.player().hand.find(c=>c.cardId==='dlc_38.png').id)));
   if(witness(/^放置数据$/))assert(witness(/^blue4 下方$/));
  }
  const end=m.save(),after=snapshot(m);m.restore(c.root);taken.forEach(m.apply);assert.deepEqual(m.save(),end);
  rows.push({board,name,searchValue:r.value,checkpoint,before,tail,end,after});
  console.log(JSON.stringify({board,name,searchValue:r.value,computed:before.score,
   wallet:before.assets.wallet,computer:before.assets.computer,dataPlan:before.dataPlan?.fixed?.selected,
   reserved:before.reserved,aliens:before.aliens,tail:tail.map(t=>t.a.summary),after:after.assets,afterScore:after.score}));
 }finally{m.dispose();}
}
writeZ(out,{rows});
