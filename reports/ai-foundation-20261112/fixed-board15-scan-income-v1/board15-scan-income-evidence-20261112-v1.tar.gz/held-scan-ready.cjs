'use strict';
const {open,readZ,writeZ,short}=require('./controlled-r3'),path=require('node:path'),assert=require('node:assert/strict');
const V=require(path.resolve('randomizer/game/ai/state-value')), [from,out]=process.argv.slice(2),seat='player-white',rows=[];
for(const r of readZ(from).rows.filter(x=>x.name==='扫描')){
 const m=open(r.checkpoint),actions=[],frames=[],income=r.board===15?'dlc_38.png':'b_29.webp',held=r.board===15?'b_19.webp':'b_16.webp';
 const original=new Map(m.player().hand.map(c=>[c.cardId,c.id])),val=()=>V.evaluateStateValue(m.owner(seat),seat).total;
 const step=(name,p=()=>true)=>{const a=m.menu().find(a=>(typeof name==='string'?a.summary===name:name.test(a.summary))&&p(a));assert(a,JSON.stringify(m.menu().map(a=>[a.summary,a.target])));actions.push(m.apply(a));};
 const snapshot=name=>frames.push({name,assets:short(m),value:val()});
 const handoff=()=>{step('结束回合');if(m.menu()[0].actorId!==seat)m.advanceOpponents(actions);};
 function fill(slot){
  step('放置数据');step(new RegExp('放置位 '+slot+'$'));
 }
 try{
  snapshot('after-scan');
  fill(3);fill(4);step('收入 '+income);
  snapshot('income-one-data-kept');handoff();
  step(held,a=>a.target.cardInstanceId===original.get(held));
  const before=m.state(),quote=m.menu().filter(a=>a.target?.nebulaId).map(a=>{
   const n=before.data.nebulae[a.target.nebulaId];
   return {a,open:n.tokens.filter(t=>!t.replacedByPlayerId&&!t.replacedByPlayerColor).length,
    ours:n.tokens.filter(t=>t.replacedByPlayerId===seat).length};
  }).filter(q=>q.open>=2).sort((a,b)=>b.ours-a.ours||a.open-b.open||a.a.actionId.localeCompare(b.a.actionId));
  assert(quote.length);step(quote[0].a.summary,a=>a.actionId===quote[0].a.actionId);
  snapshot('known-held-scan');
  fill(5);fill(6);snapshot('analysis-ready');handoff();step('分析');
  const trace=m.menu().find(a=>a.target.traceType==='blue'&&a.target.alienSlotId===2);
  assert(trace);step(trace.summary,a=>a.actionId===trace.actionId);
  snapshot('analysis-realized');
  const end=m.save(),finished=short(m);m.restore(r.checkpoint);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  rows.push({board:r.board,root:r.checkpoint,actions,frames,end,finished});
  console.log(JSON.stringify({board:r.board,frames,actions:actions.map(a=>a.summary)}));
 }catch(e){
  console.log(JSON.stringify({board:r.board,error:String(e),actions:actions.map(a=>a.summary)}));rows.push({board:r.board,error:String(e),actions,frames});
 }finally{m.dispose();}
}
writeZ(out,{rows});
