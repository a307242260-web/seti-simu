Runtime: source ff577dea65548d78f22f34aae5412f55c91651ce (V69).
Run all scripts from the repository root, using paths to this unpacked directory.
CONTROL is third-round-controls-463fc442-20261112-v1.json.gz from the prior fixed-boards-third-round-v1 evidence archive.

node DIR/board15-ledger.cjs CONTROL OUT_LEDGER.json.gz
node DIR/known-scan-income.cjs CONTROL OUT_LEDGER.json.gz OUT_INCOME.json.gz
node DIR/held-scan-ready.cjs OUT_INCOME.json.gz OUT_HELD.json.gz
node DIR/paired-scan-worlds.cjs CONTROL EMPTY_OUTPUT_DIR 15
node DIR/paired-scan-worlds.cjs CONTROL EMPTY_OUTPUT_DIR 20

Each suffix checkpoints independently. The fourth round is autonomous, including round-three PASS selection. Board 20's scan branch intentionally stops before submitting the over-budget choice. In boards 15, variants 1–3 initially used the single-pair metadata form; the script now represents each variant as an array of swap pairs.
