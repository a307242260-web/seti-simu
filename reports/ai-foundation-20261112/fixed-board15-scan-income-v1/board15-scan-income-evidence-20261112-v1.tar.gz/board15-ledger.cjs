'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path'),Module=require('node:module');
const ds=path.resolve('randomizer/game/ai/decision-search.js'),dm=new Module(ds,module);
dm.filename=ds;dm.paths=Module._nodeModulePaths(path.dirname(ds));require(ds);
const hook=[
 '    const ledger=roots.filter(r=>r.value!=null).map(r=>{',
 '      const edge=nodes[0].edges.find(e=>e.actionId===r.actionId&&e.target===r.target);',
 '      if(!edge)return null;',
 '      const path=[edge],entries=[];',
 '      let at=nodes[edge.target];',
 '      while(at.best&&nodes[at.best.target].distance<at.distance){entries.push(at.node.status);path.push(at.best);at=nodes[at.best.target];}',
 '      const node=at.node,status=node.status,summary=node.planSummary||null;',
 '      const actual=status==="turn-tail-value"?port.turnTailBase(node):status==="income-plan-value"?port.incomePlanBase(node):node;',
 '      const ob=observationForValue(actual),player=ob.publicState.players.find(p=>p.playerId===evaluate.seatId);',
 '      const fact=stateValue.evaluateStateValue(ob,evaluate.seatId);',
 '      return {r,path:path.map(e=>({steps:e.steps,goal:e.resourcePlan?.goal||e.goalPlan?.objective,goalStatus:e.goalStatus})),entries,status,summary,',
 '        leaf:{score:player.score,finalScore:player.finalScore,wallet:[player.credits,player.energy,player.publicity,player.availableData],',
 '          hand:ob.selfState.hand.map(c=>[c.id,c.cardId,!!c.hidden]),income:player.income,tech:Object.keys(player.techState.ownedTiles),',
 '          value:fact.total,components:fact.components,aliens:ob.publicState.board.aliens.slots.map(x=>[x.revealed,x.alienId])}};',
 '    }).filter(Boolean);',
 '    const elapsed = now() - startedAt;'
].join('\n');
const original=fs.readFileSync(ds,'utf8'),sig='    const elapsed = now() - startedAt;';
assert.equal(original.split(sig).length,2);
dm._compile(original.replace(sig,hook).replace('schemaVersion: VERSION, complete: accepted,','schemaVersion: VERSION, complete: accepted, ledger,'),ds);
require.cache[ds].exports=dm.exports;
const {open,readZ,writeZ}=require('./controlled-r3');
const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
const {createSearchAgent}=require(path.resolve('randomizer/game/ai/search-agent'));

const [controls,out]=process.argv.slice(2),rows=[];
for(const c of readZ(controls).rows.filter(x=>x.label==='scan-first'&&[15,20].includes(x.board))){
 const m=open(c.root),seatId='player-white',p=createAnalysisPort({composition:m.c,seatId,maxCacheEntries:0});
 try{
  const legalActions=m.menu(),q=createSearchAgent({analysisPort:p,seatId}).decide({seatId,legalActions}).search;
  assert(q.complete&&!q.unresolved.length&&q.diagnostics.nativeExecutions<=256&&q.rootAndSearchMilliseconds<=600);
  const labels=new Map(legalActions.map(a=>[a.actionId,a.summary]));
  const interesting=q.ledger.filter(x=>['扫描','发射','2能量 → 1信用点'].includes(labels.get(x.r.actionId)));
  const evidence={board:c.board,initial:c.initial,results:interesting.map(x=>({name:labels.get(x.r.actionId),...x})),n:q.diagnostics.nativeExecutions,ms:q.rootAndSearchMilliseconds};
  rows.push(evidence);
  for(const x of evidence.results)console.log(JSON.stringify({board:c.board,action:x.name,value:x.r.value,steps:x.path.flatMap(e=>e.steps||[]).map(t=>t.summary),leaf:x.leaf}));
 }finally{p.close();m.dispose();}
}
writeZ(out,{rows});
