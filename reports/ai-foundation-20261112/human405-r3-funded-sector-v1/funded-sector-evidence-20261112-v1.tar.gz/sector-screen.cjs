'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{open,short,writeZ}=require('./controlled-r3');
const load=p=>require(path.resolve('randomizer/game/'+p)),data=load('data'),science=load('effects/science-session'),scans=load('actions/scan-effects');
const [from,out]=process.argv.slice(2),seat='player-white',read=p=>JSON.parse(fs.readFileSync(p)),all=[];
for(const {board,f} of read(from).rows){
 const r=read('reports/research/'+f),sv=read(r.savePath),begin=read(r.roundEnds[1].checkpointPath),m=open(begin.coreState.compositionEnvelope),cases=[];
 let slots=0,choices=0,mercury=0;
 try{
 for(let i=begin.replayCursor.stepIndex;i<r.roundEnds[2].beforeInput-1;i++){
  const a=sv.replaySteps[i].action,e=m.c.inspect().session?.decision;
  if(a.actorId===seat&&e&&e.choices?.some(z=>z.target?.nebulaId)){
   const env=m.save(),sess=env.session?.session,o=sess?.queue?.[0]?.payload.options;
   if(sess?.journal.actions[0]?.action?.family==='scan'&&o?.mode==='specified'&&o.skippable)mercury++;
   if(sess?.journal.actions[0]?.action?.family==='scan'&&o?.mode==='public'){
    slots++;const s=m.state(),p=m.player(),t=s.turn;
    const earthEffect=scans.playerOwnsPurpleTech(p,1,{turn:t})?scans.EFFECT_TYPES.IMPROVED_SECTOR_SCAN:scans.EFFECT_TYPES.EARTH_SECTOR_SCAN;
    const earth=science.listNebulaChoices(s,{...science.getPlanetScanSource(s,earthEffect),gainData:true}).map(x=>x.target.nebulaId);
    const othersPassed=t.activePlayerIds.every(id=>id===seat||t.passedPlayerIds.includes(id)),cost=scans.getStandardScanCost(p),groups=new Map();
    for(const x of e.choices){
     const {nebulaId,cardInstanceId}=x.target||{};if(!cardInstanceId||!nebulaId)continue;
     const list=groups.get(cardInstanceId)||[];list.push(x);groups.set(cardInstanceId,list);
    }
    for(const [cardInstanceId,list] of groups){
     if(list.length<2)continue;
     choices++;
     const choicesData=list.map(x=>{
      const id=x.target.nebulaId,free=data.listNebulaTokens(s.data,id).filter(z=>!z.replacedByPlayerId&&!z.replacedByPlayerColor);
      return {actionId:x.actionId,summary:x.summary,id,slots:free.length,next:free[0]&&data.getNebulaSlotScoreReward(id,free[0].slotIndex),
       nextRepeat:free[1]&&data.getNebulaSlotScoreReward(id,free[1].slotIndex),earth:earth.includes(id)};
     });
     if(choicesData.some(x=>x.earth)&&choicesData.some(x=>!x.earth))
      cases.push({input:i+1,cardInstanceId,choicesData,othersPassed,canPayScan:p.resources.credits>=cost.credits&&p.resources.energy>=cost.energy,root:env,assets:short(m),played:a});
    }
   }
  }
  m.apply(a);
 }
 assert.deepEqual(m.save(),read(r.roundEnds[2].checkpointPath).coreState.compositionEnvelope);
 all.push({board,f,slots,choices,mercury,cases});
 if(cases.length)console.log(JSON.stringify({board,slots,choices,mercury,cases:cases.map(x=>({input:x.input,funded:x.canPayScan,solo:x.othersPassed,choices:x.choicesData.map(y=>[y.summary,y.slots,y.next,y.earth])}))}));
 }finally{m.dispose();}
}
writeZ(out,{rows:all});
