'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [from,out]=process.argv.slice(2),rows=[],seat='player-white';
for(const src of readZ(from).rows.filter(x=>!x.a.target?.skip)){
 const m=open(src.root);
 try{
  m.apply(src.a);let start;
  for(const {action:a} of src.result.actions){
   if(a.actorId===seat&&a.phase==='main'&&m.facts().turn===12){start=m.save();break;}
   m.apply(a);
  }
  assert(start);
  const before=short(m),q=m.automatic(),scan=m.menu().find(a=>a.family==='scan'),scanQuote=q.roots.find(r=>r.actionId===scan.actionId);
  assert(q.complete&&q.n<=256&&q.ms<=600);
  rows.push({arm:src.arm,before,q,scanQuote,start});
  console.log(JSON.stringify({arm:src.arm,before,best:q.a.summary,v:q.value,scan:scanQuote?.value,n:q.n,ms:q.ms}));
 }finally{m.dispose();}
}
const a=JSON.parse(rows[0].start.committedState),b=JSON.parse(rows[1].start.committedState);
assert.deepEqual(a.meta.rngState,b.meta.rngState);
assert.deepEqual(a.cards,b.cards);
assert.deepEqual(a.players.players.find(x=>x.id===seat),b.players.players.find(x=>x.id===seat));
const differences=[];
function walk(a,b,p=[]){if(JSON.stringify(a)===JSON.stringify(b))return;if(a&&b&&typeof a==='object'&&typeof b==='object'){for(const k of new Set([...Object.keys(a),...Object.keys(b)]))walk(a[k],b[k],[...p,k]);}else differences.push({path:p,left:a,right:b});}
walk(a,b);
assert(differences.every(x=>x.path[0]==='data'&&x.path[1]==='nebulae'));
writeZ(out,{rows,differences});
console.log(JSON.stringify({paths:differences.map(x=>x.path.join('.'))}));
