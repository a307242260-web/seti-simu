'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,short,readZ,writeZ}=require('./controlled-r3');
const data=require(path.resolve('randomizer/game/data')),id='sector-1-a',rows=[];
const [from,out]=process.argv.slice(2);
for(const x of readZ(from).rows){
 const m=open(x.start);
 try{
  const wallet=short(m).wallet,q=m.automatic(),r=[];
  const prefix=[m.act('scan'),m.act('choose_target',a=>a.target?.nebulaId===id)];
  const root=m.save(),legal=m.menu(),source=legal.find(a=>a.summary==='dlc_26.png → 南河三');assert(source);
  const q2=m.automatic();
  const before=short(m),slots=s=>data.listNebulaTokens(s.data,id).filter(t=>t.replacedByPlayerId).length;
  const count=slots(m.state()),capacity=data.listNebulaTokens(m.state().data,id).length;
  const earlier=m.state().data.sectorSettlements.winsByPlayerId['player-white']?.[id]??0;
  const a=m.apply(source),after=short(m),sessions=m.save().session?.session?.queue?.map(x=>x.type)||[],end=m.save();
  assert.deepEqual(m.save(),end);m.restore(x.start);prefix.forEach(m.apply);m.apply(a);assert.deepEqual(m.save(),end);
  const result={arm:x.arm,start:x.start,main:{a:q.a.summary,v:q.value},prefix,root,legal,preferred:q2.a.summary,source:a,wallet,before,after,count,capacity,sessions,end};
  console.log(JSON.stringify({arm:x.arm,main:result.main,before:before.wallet,after:after.wallet,count,capacity,sessions,preferred:q2.a.summary}));
  rows.push(result);
 }finally{m.dispose();}
}
writeZ(out,{rows});
