'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ,autonomous}=require('./controlled-r3');
const [source,out]=process.argv.slice(2),d=readZ(source),seat='player-white',rows=[];
for(const arm of d.rows.filter(x=>x.arm.endsWith('scan'))){
 const m=open(d.root);
 try{
  for(const a of [...arm.fixed,...arm.result.actions.map(x=>x.action)]){
   const e=m.save().session?.session?.queue?.[0];
   if(m.facts().turn===11&&e?.payload.options?.skippable&&e.payload.options?.cost?.publicity===1){
    const root=m.save(),before=short(m),menu=m.menu().filter(x=>x.target?.skip||x.target?.nebulaId);
    assert.equal(menu.length,2);
    for(const a of menu){
     m.restore(root);m.apply(a);const after=short(m),r=autonomous(m);
     const peak=[Math.max(0,...r.actions.map(x=>x.n||0)),Math.max(0,...r.actions.map(x=>x.ms||0))];
     const untilNext=r.actions.slice(0,r.actions.findIndex(x=>x.action.family==='end_turn')+1);
     m.restore(root);m.apply(a);untilNext.forEach(x=>m.apply(x.action));const ready=short(m);
     m.restore(root);m.apply(a);r.actions.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),r.end);
     rows.push({arm:arm.arm,root,a,before,after,ready,peak,stop:r.stop,result:r});
     console.log(JSON.stringify({arm:arm.arm,a:a.summary,before:before.wallet,after:after.wallet,ready:[ready.wallet,ready.blue],r3:r.settled?.summary,stop:r.stop,peak}));
    }
    break;
   }
   m.apply(a);
  }
 }finally{m.dispose();}
}
writeZ(out,{rows});
