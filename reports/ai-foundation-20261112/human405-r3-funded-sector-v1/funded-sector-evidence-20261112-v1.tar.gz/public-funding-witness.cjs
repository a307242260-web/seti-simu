'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ,autonomous}=require('./controlled-r3');
const [source,out]=process.argv.slice(2),d=readZ(source),seat='player-white',rows=[];
const options={preferredReserve:{'player-green':'b_138.webp','player-blue':'b_55.webp','player-brown':'dlc_12.png'},version:'seti-human405-pass-only-teacher-r3-v1'};
for(const arm of d.rows.filter(x=>x.arm.endsWith('scan'))){
 const m=open(d.root,options);
 try{
  for(const a of [...arm.fixed,...arm.result.actions.map(x=>x.action)]){
   const e=m.save().session?.session?.queue?.[0],o=e?.payload?.options;
   if(m.facts().turn===11&&o?.mode==='public'&&o.selected===0){
    const root=m.save(),before=short(m),known=m.menu().filter(x=>x.summary.startsWith('dlc_26.png')&&x.target?.nebulaId);
    if(!known.length){rows.push({arm:arm.arm,root,before,missing:'DLC26 not visible at root'});break;}
    for(const a of known){
     m.restore(root);m.apply(a);const after=short(m),r=autonomous(m);
     const peak=[Math.max(0,...r.actions.map(x=>x.n||0)),Math.max(0,...r.actions.map(x=>x.ms||0))];
     m.restore(root);m.apply(a);r.actions.forEach(x=>m.apply(x.action));assert.deepEqual(m.save(),r.end);
     rows.push({arm:arm.arm,root,a,before,after,peak,stop:r.stop,result:r});
     console.log(JSON.stringify({arm:arm.arm,a:a.summary,before:before.wallet,after:after.wallet,r3:r.settled?.summary,stop:r.stop,peak}));
    }
    break;
   }
   m.apply(a);
  }
 }finally{m.dispose();}
}
writeZ(out,{rows});
