'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,short,readZ,writeZ}=require('./controlled-r3');
const data=require(path.resolve('randomizer/game/data')),id='sector-1-a',seat='player-white',rows=[];
const [out,...files]=process.argv.slice(2);
for(const f of files)for(const x of readZ(f).rows){
 const m=open(x.end);
 try{
  const win=()=>m.state().data.sectorSettlements.sectors[id],before=structuredClone(win()),actions=[];
  for(let i=0;i<4&&m.save().session;i++){
   const skip=m.menu().find(a=>a.target?.skip||a.target?.done||a.target?.mode==='skip');if(!skip)break;actions.push(m.apply(skip));
  }
  const end=m.save(),after=structuredClone(win());
  m.restore(x.end);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  const slots=data.listNebulaTokens(m.state().data,id).filter(t=>t.replacedByPlayerId).length;
  const out={f,arm:x.arm,actions,before,after,end,slots,assets:short(m),menu:m.menu().map(a=>a.summary)};
  console.log(JSON.stringify({arm:x.arm,slots,turn:out.assets.turn,win:after,menu:out.menu.slice(0,4)}));
  rows.push(out);
 }finally{m.dispose();}
}
writeZ(out,{rows});
