'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [screen,opportunities,out]=process.argv.slice(2),seed=readZ(screen).result,seat='player-white',results=[];
for(const x of readZ(opportunities).results.filter(x=>x.branches)){
 const retain=seed.find(r=>r.board===x.board).roundFourCard;
 for(const [label,root] of [['original',x.root],...x.branches.rows.filter(r=>r.settled).map(r=>[r.label,r.settled.state])]){
  const m=open(root),actions=[],start3=short(m),searches=[];
  let stop,root4,start4,q,checkpoint;
  try{
   actions.push(m.act('pass'));
   const keep=m.menu().find(a=>a.family==='choose_card'&&a.summary===retain);
   if(!keep){
    stop={kind:'no-common-card',menu:m.menu().map(a=>a.summary)};
   }else{
    actions.push(m.apply(keep));m.advanceOpponents(actions);
    start4=short(m);root4=m.save();assert.equal(m.facts().round,4);
    for(let i=0;i<240;i++){
     if(m.state().turn.gameEnded){stop='terminal';break;}
     if(m.menu()[0]?.actorId!==seat){m.advanceOpponents(actions);continue;}
     const r=m.automatic(checkpoint);
     q={n:r.n,ms:r.ms,value:r.value,action:r.a?.summary,complete:r.complete};
     if(!r.complete||!r.a||r.n>256||r.ms>600){stop={kind:'gate',root:m.save(),...q};break;}
     searches.push(q);checkpoint=r.checkpoint;actions.push(m.apply(r.a));
    }
   }
   assert(stop);
   const end=m.save(),terminal=stop==='terminal'?m.state().match.finalScores.find(a=>a.playerId===seat)?.totalScore:null;
   m.restore(root);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
   results.push({board:x.board,label,retain,start3,root4,start4,root,end,actions,searches,terminal,stop});
   console.log(JSON.stringify({board:x.board,label,retain,start3:[start3.wallet,start3.hand,start3.computer,start3.blue],start4,terminal,stop:typeof stop==='string'?stop:{...stop,root:undefined},peak:[Math.max(0,...searches.map(x=>x.n)),Math.max(0,...searches.map(x=>x.ms))]}));
  }finally{m.dispose();}
 }
}
writeZ(out,{results});
