'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {open,short,writeZ}=require('./controlled-r3');
const read=p=>JSON.parse(fs.readFileSync(p)),seat='player-white';
const [summary,standard,out]=process.argv.slice(2),cases=[{board:0,f:standard},...read(summary).rows];
const result=[];
for(const {board,f} of cases){
 const r=read('reports/research/'+f),saved=read(r.savePath),cp=read(r.roundEnds[1].checkpointPath);
 const m=open(cp.coreState.compositionEnvelope),steps=saved.replaySteps;
 const before=r.roundEnds[2].beforeInput;
 try{
  let pending=null,lastAnalysis=null;
  const white=[],drains=[];
  for(let i=cp.replayCursor.stepIndex;i<before-1;i++){
   const a=steps[i].action;
   if(a.actorId===seat){
    const q=short(m),facts=m.facts();
    const s={input:i+1,a:a.summary,family:a.family,turn:q.turn,assets:q};
    white.push(s);
    if(a.family==='analyze'){
     pending={before:{...s,root:m.save(),canPass:m.menu().some(x=>x.family==='pass')},late:[]};
     lastAnalysis=pending;
    }else if(pending){
     if(!pending.stable&&!m.save().session)pending.stable={...s,root:m.save(),endTurn:m.menu().some(x=>x.family==='end_turn'),canPass:m.menu().some(x=>x.family==='pass')};
     pending.late.push(s);
    }
    if(a.family==='card_corner'&&a.payload.kind==='resource'){
     drains.push({input:i+1,id:facts.hand.find(x=>x[0]===a.target.cardInstanceId)?.[1],before:q.wallet[4],beforeHands:q.hand.length});
    }
   }
   m.apply(a);
  }
  assert.deepEqual(m.save(),read(r.roundEnds[2].checkpointPath).coreState.compositionEnvelope);
  const assets=short(m),roundFourCard=steps.slice(before).find(a=>a.action.actorId===seat&&a.action.family==='choose_card')?.action.summary;
  result.push({board,score:r.terminal?r.summary.scores[seat]:null,record:f,assets,roundFourCard,lastAnalysis,drains});
  console.log(JSON.stringify({board,score:r.terminal?r.summary.scores[seat]:null,assets:[assets.wallet,assets.income,assets.hand.length,assets.computer.length,assets.blue.length],last:lastAnalysis&&[lastAnalysis.before.input,lastAnalysis.before.turn,lastAnalysis.before.assets.wallet,lastAnalysis.before.assets.hand.length,lastAnalysis.stable?.assets.wallet,lastAnalysis.stable?.assets.hand.length,lastAnalysis.late.filter(x=>['analyze','scan','play_card','research_tech','launch','land','orbit'].includes(x.family)).map(x=>x.a),lastAnalysis.late.filter(x=>x.a.startsWith('收入')).map(x=>x.a)],drains:drains.length,roundFourCard}));
 }finally{m.dispose();}
}
writeZ(out,{result});
