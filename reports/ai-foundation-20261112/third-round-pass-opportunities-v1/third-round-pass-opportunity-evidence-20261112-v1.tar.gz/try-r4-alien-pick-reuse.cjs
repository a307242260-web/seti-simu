'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const [from,out,mode]=process.argv.slice(2);
const science=path.resolve('randomizer/game/effects/science-session.js'),moduleScience=new Module(science,module);
moduleScience.filename=science;moduleScience.paths=Module._nodeModulePaths(path.dirname(science));
let rawScience=fs.readFileSync(science,'utf8');
const speciesKey='|| !["阿米巴", "虫"].includes(slot.alienId)) return false;';
assert.equal(rawScience.split(speciesKey).length,2);
rawScience=rawScience.replace(speciesKey,'|| !["阿米巴", "虫", "奥陌陌"].includes(slot.alienId)) return false;');
moduleScience._compile(rawScience,science);moduleScience.loaded=true;require.cache[science]=moduleScience;
const residual=path.resolve('randomizer/game/effects/residual-domain-session.js'),moduleRes=new Module(residual,module);
moduleRes.filename=residual;moduleRes.paths=Module._nodeModulePaths(path.dirname(residual));
let rawRes=fs.readFileSync(residual,'utf8');
const traceKey='const owner=actor(source,head?.ownerId),traceType=paired?selected.target.traceType:"pink";';
assert.equal(rawRes.split(traceKey).length,2);
rawRes=rawRes.replace(traceKey,'const owner=actor(source,head?.ownerId),traceType=paired?selected.target.traceType:session.journal.actions[0]?.action?.family==="analyze"?"blue":"pink";')
 .replace('if(session.queue.length!==1||session.journal.actions[0]?.action?.family!=="land")return null;',
  'if(session.queue.length!==1||!["land","analyze"].includes(session.journal.actions[0]?.action?.family))return null;');
const completed='||turn.currentPlayerId!==head.ownerId||!owner?.mainActionCompleted||owner.passCompletionPending';
const onlyPlain=rawRes.indexOf('  function previewPlainPinkTrace(');
const next=rawRes.indexOf('  function previewLastPlainPinkTrace(',onlyPlain);
assert(rawRes.slice(onlyPlain,next).includes(completed));
rawRes=rawRes.slice(0,onlyPlain)+rawRes.slice(onlyPlain,next).replace(completed,
 '||turn.currentPlayerId!==head.ownerId||!owner||!owner.mainActionCompleted&&session.journal.actions[0]?.action?.family!=="analyze"||owner.passCompletionPending')+rawRes.slice(next);
rawRes=rawRes.replace('head.payload?.traceType!==(paired?null:"pink")','head.payload?.traceType!==(paired?null:traceType)');
moduleRes._compile(rawRes,residual);moduleRes.loaded=true;require.cache[residual]=moduleRes;
const p=path.resolve('randomizer/game/ai/analysis-port.js'),m=new Module(p,module);
m.filename=p;m.paths=Module._nodeModulePaths(path.dirname(p));
let raw=fs.readFileSync(p,'utf8');
const mark='    function previewQuietAlienDisplay(node,stored,action){';
assert.equal(raw.split(mark).length,2);
raw=raw.replace(mark,`    function previewQuietAomomoCard(node,stored,action){
      const s=stored.envelope.session?.session,head=s?.queue[0],tail=s?.queue[1],source=action.target?.source;
      if(!resourcePlanning||!cardPickPlanning||node.status!=="decision"||action.family!=="choose_card"
        ||!["display","blind","cancel"].includes(source)||stored.informationBarrier
        ||s?.phase!=="awaiting_input"||s.failure||s.interruptContext||s.irreversibleBarrier||s.undoFrames.length
        ||head?.type!=="residual_alien_card_decision"||head.kind!=="decision"||head.ownerId!==seatId||head.allowQuickActions
        ||head.payload.speciesId!=="aomomo"||head.payload.source!=="trace_reward"||s.queue.length>2
        ||tail&&(tail.type!==scienceSession.EFFECT_TYPES.PUBLIC_REFILL||tail.kind!=="effect"||tail.ownerId!==seatId
          ||tail.allowQuickActions||Object.keys(tail.payload).length))return null;
      const state=s.workingState,t=state.turn,p=state.players.players.find(q=>q.id===seatId),deck=state.aliens.aomomo;
      if(t.roundNumber!==4||t.currentPlayerId!==seatId||t.gameEnded||!p.mainActionCompleted||p.passCompletionPending
        ||t.cardTurnEventBonuses?.length||t.passedPlayerIds.includes(seatId)||!knownRootAlienIds.has("奥陌陌")
        ||p.reservedCards.some(c=>!knownCards(stored.envelope).has(c.id))||localPlans.hasPendingFossilArrival(state)
        ||!deck?.revealInitialized)return null;
      const player={...p,resources:{...p.resources},hand:[...p.hand],reservedCards:structuredClone(p.reservedCards)};
      const next={...state,meta:{...quietSavedMeta(state.meta,s.baseVersion+1),sequences:{...state.meta.sequences}},
        players:{...state.players,players:state.players.players.map(q=>q===p?player:q)},
        aliens:{...state.aliens,aomomo:{...deck,cardDeck:[...deck.cardDeck]}}};
      let random=false;
      const result=residualSession.resolveAlienCardSelection(next,head,action,()=>{random=true;return 0;});
      const expected=source!=="cancel";
      if(!result.ok||random||(result.irreversible?.code==="hidden_alien_card")!==expected
        ||(result.events?.length||0)!==Number(expected))return null;
      const augmented=residualSession.augmentEffectResult(next,result,head);
      if((augmented.spawnedEffects?.length||0)||(augmented.events?.length||0)!==Number(expected))return null;
      const barrier=expected?{effectId:head.effectId,revision:s.revision+1,...result.irreversible}:null;
      return tail?prepareQuietPublicRefill(stored,s,next,1,0,2)
        :{envelope:provedCommittedEnvelope(stored,next),inspection:{phase:"idle",session:null},barrier};
    }

`+mark+`
      if(stored.envelope.session?.session?.queue[0]?.payload?.speciesId==="aomomo")
        return previewQuietAomomoCard(node,stored,action);`);
raw=raw.replace('function prepareQuietPublicRefill(stored,session,state,refillIndex=1,extraEffects=0){\n      const missing=state.cards.publicCards.filter(c=>!c).length;\n      if(missing!==1)return null;',
 'function prepareQuietPublicRefill(stored,session,state,refillIndex=1,extraEffects=0,maxMissing=1){\n      const missing=state.cards.publicCards.filter(c=>!c).length;\n      if(missing<1||missing>maxMissing)return null;');
const pink='        &&requested.family==="choose_target"&&(requested.target?.traceType==="pink"||pairedTrace&&requested.target?.traceType)';
assert.equal(raw.split(pink).length,2);
raw=raw.replace(pink,'        &&requested.family==="choose_target"&&(requested.target?.traceType==="pink"||pairedTrace&&requested.target?.traceType\n          ||requested.target?.traceType==="blue"&&taskSession.journal.actions[0]?.action?.family==="analyze")');
raw=raw.replace('1,Number(pinkBeforeRefill.regionSettled));','1,Number(pinkBeforeRefill.regionSettled),2);');
const check='      if((!pick?.fixed||pick.selectedActionId!==action.actionId)\n';
assert.equal(raw.split(check).length,2);
raw=raw.replace(check,`      if(!(species==="amiba"&&s.workingState.turn.roundNumber===4&&head.payload.source==="trace_reward"
        &&!stored.informationBarrier&&!fossil&&!trace&&!pairedTrigger)
        &&(!pick?.fixed||pick.selectedActionId!==action.actionId)
`);
const spot='      if(alienDisplay){\n        restoreEnvelope(alienDisplay.envelope);';
assert.equal(raw.split(spot).length,2);
if(mode==='audit'){
 const menuSpot='      if(traceCardMenu){';
 assert.equal(raw.split(menuSpot).length,2);
 raw=raw.replace(menuSpot,menuSpot+`
        if(taskSession.journal.actions[0]?.action?.family==="analyze"){
          const comp=fork.composition||fork,prev=loadedEnvelope,count=submissionCount;
          restoreEnvelope(stored.envelope,true);
          const {result}=executeCurrent(requested),actual=snapshot(comp);
          globalThis.$alienPickAudit?.(actual,traceCardMenu.prepared.envelope,result.irreversibleBarrier,null,requested);
          submissionCount=count;
          if(prev)restoreEnvelope(prev);
        }`);
 const checks=[['if(plainPink){','plainPink',null],['if(pinkRefill){','pinkRefill.envelope','pinkRefill.barrier']];
 for(const [spot,expr,barrier] of checks){
  assert.equal(raw.split(spot).length,2);
  const envelope=barrier?expr:`provedCommittedEnvelope(stored,${expr})`;
  raw=raw.replace(spot,spot+`
        if(taskSession.journal.actions[0]?.action?.family===${barrier?'"scan"':'"analyze"'}){
          const comp=fork.composition||fork,prev=loadedEnvelope,count=submissionCount;
          restoreEnvelope(stored.envelope,true);
          const {result}=executeCurrent(requested),actual=snapshot(comp);
          globalThis.$alienPickAudit?.(actual,${envelope},result.irreversibleBarrier,${barrier||'null'},requested);
          submissionCount=count;
          if(prev)restoreEnvelope(prev);
        }`);
 }
 raw=raw.replace(spot,`      if(alienDisplay){
        if(taskSession.queue[0].payload.speciesId==="aomomo"||!cardPickSpec(node)?.fixed){
          const comp=fork.composition||fork,prev=loadedEnvelope,count=submissionCount;
          restoreEnvelope(stored.envelope,true);
          const {result}=executeCurrent(requested),actual=snapshot(comp);
          globalThis.$alienPickAudit?.(actual,alienDisplay.envelope,result.irreversibleBarrier,alienDisplay.barrier,requested);
          submissionCount=count;
          if(prev)restoreEnvelope(prev);
        }
        restoreEnvelope(alienDisplay.envelope);`);
}
const physical=[];
if(mode==="profile"){
 const spot='      submissionCount += 1;';
 assert.equal(raw.split(spot).length,2);
 raw=raw.replace(spot,`      globalThis.$r4Physical?.(current,head,session);
`+spot);
 globalThis.$r4Physical=(a,h,s)=>physical.push([a.family,a.summary,h?.type||null,s?.journal?.actions[0]?.action?.summary||null]);
}
if(mode==="baseline"){
 delete require.cache[science];delete require.cache[residual];
}else{
 m._compile(raw,p);m.loaded=true;require.cache[p]=m;
}

const audits=[];
globalThis.$alienPickAudit=(actual,projected,barrierA,barrierB,a)=>{
 const x=JSON.parse(actual.committedState),y=JSON.parse(projected.committedState);
 assert.deepEqual(x,y,a.summary);
 assert.deepEqual(actual.session,projected.session,a.summary);
 assert.deepEqual(barrierA?.code??null,barrierB?.code??null,a.summary);
 audits.push(a.summary);
};
const {open,readZ,writeZ}=require('./controlled-r3');
const evidence=readZ(from);
const row=mode==="profile"?evidence.continuation:evidence.results.find(x=>x.stop?.kind==='gate');
const model=open(row.stop.root);
try{
 const q=model.automatic();assert.deepEqual(model.save(),row.stop.root);
 const result={a:q.a?.summary,v:q.value,n:q.n,ms:q.ms,complete:q.complete,roots:q.roots,lines:q.lines,diagnostics:q.diagnostics,audits};
 console.log(JSON.stringify({a:result.a,v:result.v,n:result.n,ms:result.ms,roots:result.roots.length,audits:audits.length}));
 if(mode==="continue"&&q.complete&&q.n<=256&&q.ms<=600){
  const actions=[],checks=[];let cp,stop;
  for(let i=0;i<210;i++){
   if(model.state().turn.gameEnded){stop='terminal';break;}
   if(model.menu()[0]?.actorId!=='player-white'){model.advanceOpponents(actions);continue;}
   const x=i===0?q:model.automatic(cp);
   const xq={n:x.n,ms:x.ms,complete:x.complete,a:x.a?.summary,v:x.value};
   if(!x.complete||!x.a||x.n>256||x.ms>600){stop={kind:'gate',...xq,root:model.save()};break;}
   checks.push(xq);cp=x.checkpoint;actions.push(model.apply(x.a));
  }
  assert(stop);
  const end=model.save(),terminal=stop==='terminal'?model.state().match.finalScores.find(x=>x.playerId==='player-white').totalScore:null;
  model.restore(row.stop.root);actions.forEach(x=>model.apply(x));assert.deepEqual(model.save(),end);
  result.continuation={actions,checks,stop,terminal,end};
  console.log(JSON.stringify({stop:typeof stop==='string'?stop:{...stop,root:undefined},terminal,steps:actions.length,
    peak:[Math.max(0,...checks.map(x=>x.n)),Math.max(0,...checks.map(x=>x.ms))]}));
 }
 if(mode==="profile")result.physical=physical;
 writeZ(out,result);
}finally{model.dispose();}
