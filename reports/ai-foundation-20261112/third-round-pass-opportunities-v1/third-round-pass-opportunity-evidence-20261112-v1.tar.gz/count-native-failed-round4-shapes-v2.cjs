'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const p=path.resolve('randomizer/game/ai/analysis-port.js'),m=new Module(p,module);
m.filename=p;m.paths=Module._nodeModulePaths(path.dirname(p));
const key='      submissionCount += 1;';
const raw=fs.readFileSync(p,'utf8');
assert.equal(raw.split(key).length,2);
const inputs=[];
m._compile(raw.replace(key,`
      globalThis.$countNativeTransport?.(current, head, session);
`+key),p);
m.loaded=true;require.cache[p]=m;
globalThis.$countNativeTransport=(a,h,s)=>inputs.push({family:a.family,phase:a.phase,summary:a.summary,
  actionId:a.actionId,target:a.target,decision:h?.type||null,kind:h?.payload?.kind,rule:h?.payload?.ruleId,event:h?.payload?.event?.type,species:h?.payload?.speciesId,source:h?.payload?.source,origin:s?.journal?.actions[0]?.action?.summary,queued:s?.queue?.map(x=>x.type),barrier:s?.irreversibleBarrier?.code??null,payload:h?.payload, main:s?.workingState.players.players.find(p=>p.id==='player-white')?.mainActionCompleted, rev:s?.revision,undo:s?.undoFrames?.length});
const {open,readZ,writeZ}=require('./controlled-r3');
const [from,out]=process.argv.slice(2),rows=[];
for(const row of readZ(from).results.filter(x=>x.stop?.kind==='gate')){
 const m=open(row.stop.root);inputs.length=0;
 try{
  const r=m.automatic();assert.deepEqual(m.save(),row.stop.root);
  assert.equal(r.n,inputs.length);assert.equal(r.n,row.stop.n);
  const counts=Object.entries(inputs.reduce((acc,a)=>{acc[a.family]=(acc[a.family]||0)+1;return acc;},{})).sort((a,b)=>b[1]-a[1]);
  const summaries=Object.entries(inputs.reduce((acc,a)=>{const k=a.family+' '+a.summary;acc[k]=(acc[k]||0)+1;return acc;},{})).sort((a,b)=>b[1]-a[1]);
  rows.push({label:row.label,result:{action:r.a?.summary,n:r.n,ms:r.ms,value:r.value},counts,summaries,inputs:[...inputs]});
  console.log(JSON.stringify({label:row.label,n:r.n,counts,summaries:summaries.slice(0,12)}));
 }finally{m.dispose();}
}
writeZ(out,{rows});
