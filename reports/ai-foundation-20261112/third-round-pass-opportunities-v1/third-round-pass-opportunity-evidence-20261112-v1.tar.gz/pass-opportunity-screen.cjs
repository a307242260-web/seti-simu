'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const {open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const [screen,out]=process.argv.slice(2),read=f=>JSON.parse(fs.readFileSync(f)),results=[];
for(const row of readZ(screen).result){
 const record=read('reports/research/'+row.record),root=read(record.roundEnds[2].checkpointPath).coreState.compositionEnvelope,m=open(root);
 try{
  const menu=m.menu(),f=short(m),missed=f.computer.length>=4&&f.computer.length<6&&f.wallet[4]>=6-f.computer.length;
  const direct=menu.some(a=>a.family==='scan'),analyze=menu.some(a=>a.family==='analyze');
  if(!missed&&!direct&&!analyze){
   results.push({board:row.board,missed,direct,analyze,main:menu.filter(a=>a.phase==='main').map(a=>a.summary)});continue;
  }
  const q=m.automatic(),base={a:q.a?.summary,n:q.n,ms:q.ms,v:q.value,complete:q.complete,roots:q.roots.map(r=>[menu.find(a=>a.actionId===r.actionId)?.summary,r.value])};
  assert.deepEqual(m.save(),root);
  const cases=[];
  if(missed)cases.push(['fill-and-free-analyze',({act,m})=>{
   for(let i=f.computer.length;i<6;i++){act('place_data');act('choose_target',a=>a.target.target==='computer');}
   assert(m.menu().some(a=>a.family==='analyze'));act('analyze');
  }]);
  if(direct)cases.push(['scan-before-pass',({act})=>act('scan')]);
  if(analyze)cases.push(['free-analyze-before-pass',({act})=>act('analyze')]);
  const branches=runCases(root,cases);
  const observed=branches.rows.map(r=>[r.label,r.stop,r.settled?.summary,r.actions.length]);
  console.log(JSON.stringify({board:row.board,missed,direct,analyze,base,observed,failures:branches.failures.map(r=>r.reason)}));
  results.push({board:row.board,missed,direct,analyze,root,base,branches});
 }finally{m.dispose();}
}
writeZ(out,{results});
