'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [from,out]=process.argv.slice(2),src=readZ(from).results.find(x=>x.board===11),base=src.root,seat='player-white';
const m0=open(base),pub=m0.owner(seat),legal=m0.menu();m0.dispose();
const results=[];
for(const [i,j] of [[0,3],[3,5]]){
 const before=JSON.parse(base.committedState),deck=before.aliens.aomomo.initialConfiguration.cardDeck;
 [deck[i],deck[j]]=[deck[j],deck[i]];
 const root={...base,committedState:JSON.stringify(before)},m=open(root);
 try{
  assert.deepEqual(m.owner(seat),pub);assert.deepEqual(m.menu(),legal);
  for(const arm of ['original','fill-and-free-analyze']){
   m.restore(root);const actions=[];
   const fixed=arm==='original'?[]:src.branches.rows[0].prefix;
   for(const a of fixed)actions.push(m.apply(a));
   if(arm!=='original'){
    let checkpoint;
    for(let i=0;i<35;i++){
     if(m.menu().some(a=>a.family==='pass'))break;
     const q=m.automatic(checkpoint);assert(q.complete&&q.n<=256&&q.ms<=600);
     checkpoint=q.checkpoint;actions.push(m.apply(q.a));
    }
   }
   const end3=short(m);
   actions.push(m.act('pass'),m.act('choose_card',a=>a.summary==='b_9.webp'));
   m.advanceOpponents(actions);assert.equal(m.facts().round,4);
   const root4=m.save(),start=short(m);
   m.restore(root);actions.forEach(a=>m.apply(a));assert.deepEqual(m.save(),root4);
   results.push({board:11,label:arm,swap:[i,j],deck:[...deck],root4,end3,start,actions});
   console.log(JSON.stringify({arm,swap:[i,j],round4:[start.hand,start.wallet]}));
  }
 }finally{m.dispose();}
}
writeZ(out,{results});
