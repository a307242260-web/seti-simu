'use strict';
const path=require('node:path'),fs=require('node:fs'),orig=require.extensions['.js'];
require.extensions['.js']=(m,p)=>p===path.resolve('randomizer/game/ai/decision-search.js')?m._compile(fs.readFileSync(path.join(__dirname,'candidate-decision-search.js'),'utf8'),p):orig(m,p);
