'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const src=readZ(process.argv[2]).rows.find(r=>r.swap===null),seat='player-white',rows=[];
for(const keep of ['b_111.webp','b_32.webp'])for(const mode of ['end-now','one-slot','three-slots']){
 const m=open(src.root),actions=[],checks=[],main=[];
 try{
  const launch=src.actions.findIndex(a=>a.target?.choiceId==='scan4:launch'),length=launch+1+({ 'end-now':0,'one-slot':2,'three-slots':6 })[mode];
  for(const a of src.actions.slice(0,length)){
   const b=a.actorId===seat&&a.target?.kind==='pass-reserve-card'?m.act('choose_card',a=>a.target.cardId===keep):m.apply(a);
   actions.push(b);
  }
  if(mode==='end-now')actions.push(m.act('end_turn'));
  const start=m.save(),prefix=actions.length,assets=short(m);
  let cp,stop;
  for(let i=0;i<230;i++){
   if(m.state().turn.gameEnded){stop={kind:'terminal'};break;}
   if(m.menu()[0].actorId!==seat){m.advanceOpponents(actions);continue;}
   const u=m.automatic(cp),a=u.a,x={n:u.n,ms:u.ms,complete:u.complete,value:u.value,a:a?.summary};
   if(!a||!u.complete||u.n>256||u.ms>600){stop={kind:'gate',...x,root:m.save(),roots:u.roots};break;}
   if(a.phase==='main')main.push([m.facts().turn,a.family,a.summary]);
   cp=u.checkpoint;checks.push(x);actions.push(m.apply(a));
  }
  assert(stop);
  const end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore;
  m.restore(src.root);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  const peak=[Math.max(0,...checks.map(x=>x.n)),Math.max(0,...checks.map(x=>x.ms))];
  rows.push({keep,mode,root:src.root,start,prefix,assets,checks,main,actions,end,stop,terminal,peak});
  console.log(JSON.stringify({keep,mode,terminal,assets,main,peak,stop:{...stop,root:undefined,roots:undefined}}));
 }finally{m.dispose();}
}
writeZ(process.argv[3],{rows});
