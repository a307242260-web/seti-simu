'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [o1file,o3file,out]=process.argv.slice(2),k=require(path.resolve('randomizer/game/production-kernel')),seat='player-white';
const o1=readZ(o1file),o3=readZ(o3file),seeds=[['early-scan-landing',o1.origin],['relaunch-direct-landing',o3.common.end]],rows=[];
for(const [label,origin] of seeds)for(const swap of [null,[0,4],[1,6]]){
 const early=label==='early-scan-landing',s=JSON.parse(origin.committedState),deck=s.cards.drawPileCardIds;
 if(swap){assert(deck[swap[0]]&&deck[swap[1]]);[deck[swap[0]],deck[swap[1]]]=[deck[swap[1]],deck[swap[0]]];}
 const e=swap?{...origin,committedState:JSON.stringify(s)}:origin,m=open(e);
 try{
  const view=m.owner(seat),menu=m.menu(),rng=m.facts().rng,known=new Set(m.player().hand.map(c=>c.id));
  const baseline=rows.find(r=>r.label===label);
  if(baseline){assert.deepEqual(view,baseline.view);assert.deepEqual(menu,baseline.menu);assert.deepEqual(rng,baseline.rng);}
  const actions=[],take=a=>(actions.push(a),a),pay=()=>{if(m.menu()[0].actorId!==seat)m.advanceOpponents(actions);};
  const endTurn=()=>{take(m.act('end_turn'));pay();};
  take(m.act('pass'));pay();take(m.act('choose_card',a=>a.target.kind==='pass-reserve-card'&&a.target.cardId==='b_111.webp'));pay();
  const r4=short(m);
  const route=()=>k.getProbeRouteRequirements(m.state(),seat).candidates.find(r=>r.planetId==='saturn'&&r.endpointFamily==='land'&&r.endpointTarget.type==='planet');
  if(early){
   const p=route(),dir=p.path[0],b16=m.player().hand.find(c=>c.cardId==='b_16.webp');assert(known.has(b16.id));
   take(m.play('b_16.webp'));
   take(m.act('choose_target',a=>a.target.rocketId===p.rocketId&&a.target.deltaX===dir.deltaX&&a.target.deltaY===dir.deltaY));
   take(m.act('choose_target',a=>a.target.nebulaId==='sector-2-a'));
  }else take(m.act('launch'));
  const afterFirst=short(m);
  endTurn();const tail=route();
  for(const d of tail.path){
   take(m.act('move',a=>a.target.rocketId===tail.rocketId&&a.target.deltaX===d.deltaX&&a.target.deltaY===d.deltaY));
   take(m.act('choose_payment',a=>a.target.choiceId==='energy'));
  }
  take(m.act('land'));
  assert(m.state().planets.planets.saturn.landingMarkers.some(x=>x.playerId===seat));
  const after=short(m),end=m.save();m.restore(e);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  rows.push({label,swap,root:e,view,menu,rng,r4,afterFirst,after,tail:tail.required,actions,end,main:2});
  console.log(JSON.stringify([label,swap,r4.wallet,after.wallet,tail.required,after.hand]));
 }finally{m.dispose();}
}
writeZ(out,{rows});
