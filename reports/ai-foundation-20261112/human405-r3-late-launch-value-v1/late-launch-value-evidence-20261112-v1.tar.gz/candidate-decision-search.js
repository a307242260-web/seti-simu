(function (root, factory) {
  "use strict";
  const api = factory(typeof module === "object" && module.exports ? require("./state-value") : root.SetiStateValue);
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.SetiDecisionSearch = api;
})(typeof globalThis !== "undefined" ? globalThis : window, function (stateValue) {
  "use strict";

  const VERSION = "seti-complete-decision-search-v457";
  const BOUNDARIES = new Set(["terminal", "other-owner", "information-barrier", "turn-boundary", "income-plan-value", "turn-tail-value"]);
  // 这是单决策诊断额度，不是允许截断的棋力配置；超限绝不返回可提交动作。
  const DEFAULT_BUDGET = Object.freeze({ transitions: 128, nodes: 129, frontier: 128, milliseconds: 1000 });

  function searchDecision({ port, root, evaluate, budget = {}, continuation = null, planContinuation = null, planReuse = false,
    modelKey = null, movementPlanning = false, cardPickPlanning = false, resourcePlanning = false, finalMarkPlanning = false, scanPlanning = false, resourceDominance = false, moneyCapacityDominance = false, cardTradePruning = false, postMainPruning = false, openingPruning = false, cardChoiceEquivalence = false,
    scanOrbitBudget = null, now = () => performance.now() } = {}) {
    if (typeof port?.expand !== "function" || typeof port?.identity !== "function"
      || typeof evaluate !== "function" || !root) throw new TypeError("SEARCH_INPUT_INVALID");
    const configuredLimits = { ...DEFAULT_BUDGET, ...budget };
    for (const [key, value] of Object.entries(configuredLimits)) {
      if (!Object.hasOwn(DEFAULT_BUDGET, key) || value !== null && (!Number.isSafeInteger(value) || value < 1)) {
        throw new TypeError(`SEARCH_BUDGET_INVALID: ${key}`);
      }
    }
    // null is an explicit, JSON-safe opt-out; Infinity never leaves this calculation.
    const limits = Object.fromEntries(Object.entries(configuredLimits).map(([key,value])=>[key,value === null ? Infinity : value]));
    const unlimited = Object.values(configuredLimits).every(limit=>limit===null);
    const valueCache = new WeakMap(), realizationCache = new WeakMap(), preparationDebtCache = new WeakMap();
    const realizationTies = stateValue?.isDefaultStateValueEvaluator?.(evaluate);
    let valueCacheHits=0,valueEvaluations=0;
    function valueOf(observation) {
      if (valueCache.has(observation)) { valueCacheHits++; return valueCache.get(observation); }
      valueEvaluations++;
      const details = realizationTies ? evaluate.details(observation) : null;
      const value = details ? details.value : evaluate(observation);
      if (details) {realizationCache.set(observation,-details.unrealizedPurposeValue);preparationDebtCache.set(observation,details.purposePreparationDebt);}
      valueCache.set(observation,value); return value;
    }
    const quietLeaves=new WeakMap();
    function quietLeaf(node){
      if(!realizationTies||!resourcePlanning||!port.quietFinalValue)return null;
      if(quietLeaves.has(node))return quietLeaves.get(node);
      const q=port.quietFinalValue(node);
      quietLeaves.set(node,q);return q;
    }
    const observationForValue=node=>stateValue?.isStateValueEvaluator?.(evaluate)&&port.valueObservation?port.valueObservation(node):node.observation;
    const legacyProof = node => !stateValue?.isStateValueEvaluator?.(evaluate)
      || stateValue.supportsLegacyValueProof(observationForValue(node));
    // Exact default-model ledger terms include computer and blind-income
    // fractions. The audited quiet tail changes only these same ledger terms.
    const exactTailSum=(base,gain)=>{
      const scale=stateValue.valueScale,units=[base,gain].map(v=>Math.round(v*scale));
      if(!units.every((n,i)=>Number.isSafeInteger(n)&&n/scale===[base,gain][i])
        ||!Number.isSafeInteger(units[0]+units[1]))return null;
      return stateValue.sumValueParts([base,gain]);
    };
    const valueForNode=node=>{
      if(!["income-plan-value","turn-tail-value"].includes(node.status))return quietLeaf(node)?.value??valueOf(observationForValue(node));
      if(!stateValue?.isDefaultStateValueEvaluator?.(evaluate)||evaluate.seatId!==root.legalActions?.[0]?.actorId)throw new TypeError("SEARCH_INCOME_PROOF_MODEL_INVALID");
      const baseValue=valueOf(observationForValue((node.status==="income-plan-value"?port.incomePlanBase(node):port.turnTailBase(node))));
      // A complete audited plan with exactly zero value change is an identity,
      // including fixed data realization under a fractional expectation.
      // Other income shortcuts retain their existing half-unit guard.
      if(node.planSummary.netGain===0)return baseValue;
      if(node.status==="turn-tail-value"||node.planSummary.publicAmibaBlindIncome){
        const total=exactTailSum(baseValue,node.planSummary.netGain);
        if(total===null)throw new Error("SEARCH_TURN_TAIL_VALUE_INVALID");
        return total;
      }
      const total=baseValue+node.planSummary.netGain;
      if(!Number.isSafeInteger(total*2))throw new Error("SEARCH_INCOME_PROOF_VALUE_INVALID");
      return total;
    };
    function realizationForNode(node) {
      if (!realizationTies) return 0;
      // A scalar proof has no successor observation. An audited purpose delta
      // carries the boundary's exact realization; older proofs keep the base.
      if (["income-plan-value","turn-tail-value"].includes(node.status)) {
        const before=realizationForNode(node.status==="income-plan-value"?port.incomePlanBase(node):port.turnTailBase(node));
        return node.planSummary.unrealizedPurposeDelta===undefined?before:stateValue.sumValueParts([before,-node.planSummary.unrealizedPurposeDelta]);
      }
      const quiet=quietLeaf(node);
      if(quiet)return -quiet.unrealizedPurposeValue;
      const observation=observationForValue(node);
      valueOf(observation);
      return realizationCache.get(observation);
    }
    function preparationDebtForNode(node) {
      if (!realizationTies) return 0;
      if (node.status === "income-plan-value") return preparationDebtForNode(port.incomePlanBase(node));
      if (node.status === "turn-tail-value") return preparationDebtForNode(port.turnTailBase(node));
      if(quietLeaf(node))return 0;
      const observation=observationForValue(node);valueOf(observation);return preparationDebtCache.get(observation);
    }
    const startedAt = now();
    const scope=(movementPlanning?"own-turn-visible-window-with-goal-directed-movement-policy":"own-turn-visible-decision-window-to-turn-owner-information-or-terminal-boundary")+(cardPickPlanning?"+fixed-card-pick-policy":"")+(resourcePlanning?"+goal-bound-greedy-resource-policy":"")+(finalMarkPlanning?"+local-final-mark-policy":"")+(scanPlanning?"+scan-purpose-policy":"");
    if (movementPlanning && typeof port.goalMovementSpec !== "function") throw new TypeError("SEARCH_MOVEMENT_PORT_REQUIRED");
    port.setMovementPlanning?.(movementPlanning);
    if(cardPickPlanning&&typeof port.expandWithCardPick!=="function")throw new TypeError("SEARCH_CARD_PICK_PORT_REQUIRED");
    port.setCardPickPlanning?.(cardPickPlanning);
    if(resourcePlanning&&typeof port.expandResourcePlan!=="function")throw new TypeError("SEARCH_RESOURCE_PORT_REQUIRED");
    port.setResourcePlanning?.(resourcePlanning);
    if(scanPlanning&&!resourcePlanning)throw new TypeError("SEARCH_SCAN_RESOURCE_PLANNING_REQUIRED");
    if((finalMarkPlanning||scanPlanning)&&typeof port.setDecisionPlanning!=="function")throw new TypeError("SEARCH_LOCAL_PLANNING_PORT_REQUIRED");
    port.setDecisionPlanning?.({finalMarkPlanning,scanPlanning,rankKnownFossilTraces:realizationTies===true});
    if (openingPruning && (!stateValue?.isDefaultStateValueEvaluator?.(evaluate)
      || evaluate.seatId !== root.legalActions?.[0]?.actorId
      || typeof port.openingPlanSpec !== "function")) throw new TypeError("SEARCH_OPENING_MODEL_INVALID");
    if (moneyCapacityDominance && (!stateValue?.isDefaultStateValueEvaluator?.(evaluate)
      || evaluate.seatId !== root.legalActions?.[0]?.actorId
      || typeof port.openingMoneyCapacity !== "function")) throw new TypeError("SEARCH_MONEY_CAPACITY_MODEL_INVALID");
    if (resourceDominance && (!stateValue?.isMoneyMonotoneEvaluator?.(evaluate)
      || evaluate.seatId !== root.legalActions?.[0]?.actorId
      || typeof port.postMainResourceOrder !== "function")) throw new TypeError("SEARCH_RESOURCE_PROOF_MODEL_INVALID");
    if (cardTradePruning && (!stateValue?.isStateValueEvaluator?.(evaluate)
      || evaluate.seatId !== root.legalActions?.[0]?.actorId
      || typeof port.cardTradeBound !== "function")) throw new TypeError("SEARCH_CARD_BOUND_MODEL_INVALID");
    if (postMainPruning && (!stateValue?.isDefaultStateValueEvaluator?.(evaluate)
      || evaluate.seatId !== root.legalActions?.[0]?.actorId
      || typeof port.postMainPlanSpec !== "function")) throw new TypeError("SEARCH_POST_MAIN_MODEL_INVALID");
    if (cardChoiceEquivalence && (!stateValue?.isStateValueEvaluator?.(evaluate)
      || evaluate.seatId !== root.legalActions?.[0]?.actorId
      || typeof port.cardTradeBound !== "function")) throw new TypeError("SEARCH_CARD_CHOICE_MODEL_INVALID");
    if (modelKey != null && (typeof modelKey !== "string" || !modelKey)) throw new TypeError("SEARCH_MODEL_KEY_INVALID");
    if (planReuse && (!stateValue?.isStateValueEvaluator?.(evaluate) || evaluate.seatId !== root.legalActions?.[0]?.actorId
      || typeof port.rememberPlan !== "function" || typeof port.reusePlan !== "function")) throw new TypeError("SEARCH_PLAN_MODEL_INVALID");
    const planKey = JSON.stringify([VERSION, modelKey, evaluate.modelKey, resourceDominance, moneyCapacityDominance,
      cardTradePruning, postMainPruning, openingPruning, cardChoiceEquivalence, movementPlanning, cardPickPlanning, resourcePlanning, finalMarkPlanning, scanPlanning]);
    const retainedRegionSource=resourcePlanning&&realizationTies&&scanOrbitBudget&&port.retainedRegionCardSource?.();
    const reused = continuation && modelKey && port.reuseSelection?.(root, continuation, modelKey);
    const regionCashGoal="retained-region-cash-income";
    const reusedPlan = !reused?.hit && planReuse && planContinuation
      && port.reusePlan(root, planContinuation, planKey, retainedRegionSource ? regionCashGoal : null);
    const hit = reused?.hit ? reused : reusedPlan?.hit ? reusedPlan : null;
    if (hit && now() - startedAt < limits.milliseconds) return {
      schemaVersion: VERSION, complete: true, actionId: hit.actionId, value: hit.value, realization: hit.realization ?? 0, preparationDebt:hit.preparationDebt??0,
      selectionPlan: reused?.hit ? { selectedIds: reused.selectedIds, cardIds: reused.cardIds, proof: reused.proof, complete: true } : null,
      selectionContinuation: reused?.hit ? continuation : null,
      planContinuation: reusedPlan?.hit ? planContinuation : null,
      reusedCoverage: reused?.hit ? { evidenceId: reused.evidenceId, exitCount: reused.exitCount, proof: reused.proof }
        : { evidenceId: hit.evidenceId, proof: hit.proof, sourceNode: hit.sourceNode, source: hit.source, distance: hit.distance },
      stopReason: null, scope,
      roots: hit.roots, lines: [], unresolved: [],
      diagnostics: { realizationTies:realizationTies?"funded-preparation-debt-and-latest-native-purpose-capital":"off", valueEvaluations,valueCacheHits, finalMarkPlanning:finalMarkPlanning,scanPlanning:scanPlanning, resourcePlanning:resourcePlanning?"goal-bound-greedy-preparation":"off", cardPickPlanning:cardPickPlanning?"purpose-bound-fixed-plan":"off", movementPlanning: movementPlanning ? "goal-directed-policy" : "off", movementPolicyNodes: 0, movementDirectionsExcluded: 0, routeGeometryNodes: 0,
        incomePlanProofs:0,provedIncomeInputs:0,turnTailProofs:0,provedTurnTailInputs:0,nativeExecutions:0,logicalResourceInputs:0,sharedResourceInputHits:0,sharedResourceInternalStates:0,
        fixedDataChoiceStates:0,fixedDataChoicesExcluded:0,branchingStates:0,singleAlternativeStates:0,disabledBorrowStarts:0,disabledRemoveTechIncomeStarts:0,
        transitions: 0, nodes: 1, equivalents: 0, selectionMacros: 0, peakFrontier: 0, graphNodes: 1, certificateNodes: 0,
        postMainOptimalPlans: 0, postMainOptimalPlanSteps: 0,
        dominancePrunes: 0, resourceDominance: resourceDominance
          ? reused?.hit ? "disabled-for-selection-certificate" : "reused-complete-window" : "off",
        moneyCapacityPrunes: 0, moneyCapacityDominance: moneyCapacityDominance
          ? reused?.hit ? "disabled-for-selection-certificate" : "reused-complete-window" : "off",
        postMainValuePrunes: 0, scanValuePrunes: 0, scanActionPrunes: 0,movementValuePrunes:0,
        cardTradePrunes: 0, cardTradePruning: cardTradePruning
          ? reused?.hit ? "disabled-for-selection-certificate" : "reused-complete-window" : "off",
        postMainProofNodes: 0, postMainExcludedActions: 0, postMainPruning: postMainPruning ? "enabled" : "off",
        openingProofNodes: 0, openingExcludedActions: 0, openingPruning: openingPruning ? "enabled" : "off",
        openingPassMacros: 0, postMainBorrowProofNodes: 0, postMainBorrowExcludedChoices: 0, postMainBorrowMacros: 0,
        cardChoiceProofNodes: 0, cardChoiceExcludedActions: 0, cardCornerProofNodes: 0, cardCornerExcludedActions: 0,
        preMainDataProofNodes: 0, preMainDataExcludedActions: 0,
        cardChoiceEquivalence: cardChoiceEquivalence ? "enabled" : "off",
        continuation: reused?.hit ? "hit" : reused ? reused.reason : "not-requested",
        planContinuation: reusedPlan?.hit ? "hit" : planReuse ? "not-requested" : "off",
        milliseconds: now() - startedAt, limits: configuredLimits },
    };
    // The new R3 asset is inapplicable to earlier and final rounds. Do
    // not run a portfolio hook at any leaf of those existing searches.
    const quoteDeferredSector = resourcePlanning && realizationTies
      && root.observation.publicState.roundNumber===3 && port.deferredSectorPublicityEnabled?.()===true;
    const finalDataSalary=resourcePlanning&&realizationTies&&port.finalDataSalarySource?.();
    const knownPickupFunding=resourcePlanning&&realizationTies&&stateValue?.isDefaultStateValueEvaluator?.(evaluate)
      &&port.knownPickupFundingEnabled?.()===true;
    const quoteDeferredCargo=resourcePlanning&&realizationTies&&stateValue?.isDefaultStateValueEvaluator?.(evaluate)
      &&port.deferredCargoEnabled?.()===true;
    const researchDataPurpose=quoteDeferredSector&&stateValue?.isDefaultStateValueEvaluator?.(evaluate)
      ?port.researchDataPurpose?.():null;
    const researchScanPurpose=resourcePlanning&&realizationTies&&root.observation.publicState.roundNumber===3
      ?port.researchScanPurpose?.():null;
    const deferredComputerIncome=resourcePlanning&&realizationTies&&root.observation.publicState.roundNumber===3
      &&stateValue?.isDefaultStateValueEvaluator?.(evaluate)?port.deferredComputerIncomeSource?.():null;
    const amibaRegion=resourcePlanning&&realizationTies&&root.observation.publicState.roundNumber===3
      &&stateValue?.isDefaultStateValueEvaluator?.(evaluate)?port.amibaRegionPurpose?.():null;
    const scanTiming=resourcePlanning&&realizationTies&&root.observation.publicState.roundNumber===3
      &&stateValue?.isDefaultStateValueEvaluator?.(evaluate)?port.scanTimingPurpose?.():null;
    const analysisFunding=resourcePlanning&&realizationTies&&root.observation.publicState.roundNumber===3
      &&stateValue?.isDefaultStateValueEvaluator?.(evaluate)?port.analysisFundingSource?.():null;
    const matchedAnalysisScan=resourcePlanning&&realizationTies&&stateValue?.isDefaultStateValueEvaluator?.(evaluate)
      ?port.matchedAnalysisScanSource?.():null;
    const researchTransport=resourcePlanning&&movementPlanning&&realizationTies&&root.observation.publicState.roundNumber===3
      ?port.researchTransportPurpose?.():null;
    const transportPreparationEnabled=resourcePlanning&&movementPlanning&&realizationTies&&root.observation.publicState.roundNumber===3;
    const displayedAnalysisTransport=transportPreparationEnabled&&stateValue?.isDefaultStateValueEvaluator?.(evaluate)
      ?port.displayedAnalysisTransportSource?.():null;
    const transportPreparation=transportPreparationEnabled?port.transportPreparationPurpose?.():null;
    const upstreamTransport=transportPreparationEnabled&&!transportPreparation&&port.upstreamTransportEnabled?.();
    const displayedTransport=transportPreparationEnabled&&stateValue?.isDefaultStateValueEvaluator?.(evaluate)
      ?port.displayedTransportPurpose?.():null;
    const fundedScanAnalysis=resourcePlanning&&realizationTies&&stateValue?.isDefaultStateValueEvaluator?.(evaluate)
      &&port.fundedScanAnalysisSource?.();
    const coreExtendedPurpose=fundedScanAnalysis||researchDataPurpose||researchScanPurpose||deferredComputerIncome||amibaRegion||scanTiming||analysisFunding||matchedAnalysisScan||researchTransport||displayedAnalysisTransport||transportPreparation||upstreamTransport;
    const extendedPurpose=coreExtendedPurpose||displayedTransport;
    const nodes = [];
    const known = new Map();
    const queue = [];
    const resourceGroups = new Map();
    const resourceExecutions = new Map();
    const useResourceDominance = !resourcePlanning && !movementPlanning && !cardPickPlanning && resourceDominance && !port.selectionSpec?.(root);
    const useMoneyCapacity = !resourcePlanning && !movementPlanning && !cardPickPlanning && moneyCapacityDominance && !port.selectionSpec?.(root);
    const useCardTradePruning = !resourcePlanning && cardTradePruning && !port.selectionSpec?.(root);
    const useScanBound = !extendedPurpose && cardChoiceEquivalence && stateValue?.isDefaultStateValueEvaluator?.(evaluate) && !port.selectionSpec?.(root);
    const usePostMainValueBound = !extendedPurpose && postMainPruning && !port.selectionSpec?.(root);
    let movementPolicyNodes = 0, movementDirectionsExcluded = 0, routeGeometryNodes = 0;
    let transitions = 0, logicalResourceInputs = 0, sharedResourceInputHits = 0;
    const sharedInternalStates=new Set();
    function resourceStateAdditions(states){
      const fresh=new Set();for(const node of states){const id=port.identity(node);if(!known.has(id)&&!sharedInternalStates.has(id))fresh.add(id);}return fresh;
    }
    let equivalents = 0;
    let incomePlanProofs=0,provedIncomeInputs=0,turnTailProofs=0,provedTurnTailInputs=0;
    let winningIncomePlans=0,winningIncomeInputs=0;
    let selectionMacros = 0;
    let peakFrontier = 0;
    let pendingFrontier = 0;
    let dominancePrunes = 0;
    let moneyCapacityPrunes = 0;
    let cardTradePrunes = 0;
    let postMainValuePrunes = 0,movementValuePrunes=0,dataPrimaryBoundPrunes=0;
    let scanValuePrunes = 0, scanActionPrunes = 0;
    let certificateNodes = 0, postMainOptimalPlans = 0, postMainOptimalPlanSteps = 0;
    let postMainProofNodes = 0, postMainExcludedActions = 0;
    let openingProofNodes = 0, openingExcludedActions = 0;
    let openingPassMacros = 0;
    let postMainBorrowProofNodes = 0, postMainBorrowExcludedChoices = 0, postMainBorrowMacros = 0;
    let cardChoiceProofNodes = 0, cardChoiceExcludedActions = 0;
    let cardCornerProofNodes = 0, cardCornerExcludedActions = 0;
    let preMainDataProofNodes = 0, preMainDataExcludedActions = 0;
    let incumbent = null;
    let stopReason = null;
    function dominates(upper, lower) {
      if (upper.credits >= lower.credits && upper.energy >= lower.energy && lower.moneyValue) {
        const a = upper.moneyValue(), b = lower.moneyValue();
        if (![a, b].every(value => Number.isSafeInteger(value * 2) && value >= 0 && value <= Number.MAX_SAFE_INTEGER / 64)
          || a - b !== upper.credits - lower.credits + upper.energy - lower.energy) return null;
      }
      if (upper.credits >= lower.credits && upper.energy >= lower.energy
        && (upper.credits > lower.credits || upper.energy > lower.energy)) return lower.proof;
      if (upper.moneyCapacity && lower.moneyCapacity
        && upper.capacityProof === lower.capacityProof
        && upper.credits >= upper.moneyCapacity.credits && upper.energy >= upper.moneyCapacity.energy
        && upper.credits + upper.energy > lower.credits + lower.energy) return lower.capacityProof;
      return null;
    }
    function prune(index, dominator) {
      const entry = nodes[index];
      if (entry.prunedBy) return;
      const upper = nodes[dominator].resources;
      const proof = dominates(upper, entry.resources);
      entry.prunedBy = { node: dominator, proof,
        gap: Object.fromEntries(["credits", "energy"]
          .map(key => [key, upper[key] - entry.resources[key]])) };
      dominancePrunes += 1;
      if (proof === entry.resources.capacityProof) moneyCapacityPrunes += 1;
      if (entry.queued) { entry.queued = false; pendingFrontier -= 1; }
    }
    function add(node, queuePriority = 0, initializeDeferred = false) {
      const identity = port.identity(node), previous=known.get(identity);
      if (previous!==undefined&&!initializeDeferred) return { index: previous, equivalent: true };
      const index = initializeDeferred?previous:nodes.length;
      if(!initializeDeferred){
        if(sharedInternalStates.delete(identity))certificateNodes--;
        known.set(identity,index);
      }
      // A stable native state may already be dominated by a closed witness.
      // Delay policy/route construction until after its bound check, including
      // ordinary states without a carried hidden-information barrier.
      if(!initializeDeferred&&resourcePlanning&&node.status==="stable"){
        nodes.push({node,edges:[],alternatives:[],alternativeCount:0,queuePriority,deferredPolicy:true,
          queued:true,expanded:false,value:null,distance:Infinity,best:null});
        const ahead=queue.findIndex(i=>nodes[i].queuePriority>queuePriority);
        if(ahead<0)queue.push(index);else queue.splice(ahead,0,index);
        pendingFrontier++;peakFrontier=Math.max(peakFrontier,pendingFrontier);
        return{index,equivalent:false};
      }
      const boundary = BOUNDARIES.has(node.status) || node.status === "plan-infeasible";
      if (!boundary && !node.legalActions?.length) throw new Error("SEARCH_EMPTY_NONTERMINAL");
      const deferredPublicity = quoteDeferredSector&&BOUNDARIES.has(node.status)?port.deferredSectorPublicityQuote(node):null;
      const researchData=researchDataPurpose&&BOUNDARIES.has(node.status)?port.quoteResearchDataPurpose(node,researchDataPurpose):null;
      const baseValue = BOUNDARIES.has(node.status) ? valueForNode(node) : null;
      if(deferredPublicity&&researchData)throw new Error('SEARCH_RESEARCH_TASK_QUOTED_TWICE');
      const researchScan=researchScanPurpose&&BOUNDARIES.has(node.status)?port.quoteResearchScanPurpose(node,researchScanPurpose):null;
      const researchIncome=deferredComputerIncome&&BOUNDARIES.has(node.status)?port.quoteDeferredComputerIncome(node,deferredComputerIncome):null;
      const regionFollowup=amibaRegion&&BOUNDARIES.has(node.status)?port.quoteAmibaRegionPurpose(node,amibaRegion):null;
      const scanTimingQuote=scanTiming&&BOUNDARIES.has(node.status)?port.quoteScanTimingPurpose(node,scanTiming):null;
      const fundedScanQuote=node.status==="turn-tail-value"?node.planSummary.nextFundedScan:null;
      const analysisFundingQuote=analysisFunding&&BOUNDARIES.has(node.status)?port.quoteAnalysisFunding(node,analysisFunding):null;
      const matchedScanQuote=matchedAnalysisScan&&BOUNDARIES.has(node.status)?port.quoteMatchedAnalysisScan(node,matchedAnalysisScan):null;
      const transportQuote=BOUNDARIES.has(node.status)?(researchTransport&&port.quoteResearchTransport(node,researchTransport)
        ||displayedAnalysisTransport&&port.quoteDisplayedAnalysisTransport(node,displayedAnalysisTransport)):null;
      const preparedTransport=(transportPreparation||upstreamTransport)&&BOUNDARIES.has(node.status)?port.quoteTransportPreparation(node,transportPreparation):null;
      const displayTransportQuote=displayedTransport&&BOUNDARIES.has(node.status)?port.quoteDisplayedTransport(node,displayedTransport,baseValue):null;
      const preparedGain=preparedTransport?stateValue.sumValueParts([preparedTransport.value,-baseValue]):0;
      const deferredCargo=quoteDeferredCargo?port.quoteDeferredCargo(node):null;
      const pickupFunding=knownPickupFunding?port.quoteKnownPickupFunding(node):null;
      const paidScanAnalysis=fundedScanAnalysis&&BOUNDARIES.has(node.status)?port.quoteFundedScanAnalysis(node):null;
      const priorForecast=Math.max(paidScanAnalysis?.value||0,deferredCargo?.value||0,preparedGain,displayTransportQuote?.gain||0,researchScan?.value||0,(researchData||deferredPublicity)?.value||0,researchIncome?.value||0,regionFollowup?.value||0,scanTimingQuote?.value||0,fundedScanQuote?.value||0,analysisFundingQuote?.value||0,matchedScanQuote?matchedScanQuote.value-baseValue:0);
      const baseRealization = BOUNDARIES.has(node.status) ? realizationForNode(node) : null;
      // All current unrealized uses may compete for the same wallet/probe.
      // Charge the entire prior capital before offering the landing floor.
      const transportForecast=transportQuote?stateValue.sumValueParts([transportQuote.value,baseRealization]):0;
      const takesTransport=transportForecast>priorForecast;
      const forecast=takesTransport?transportForecast:priorForecast;
      const salary=finalDataSalary&&port.finalDataSalaryQuote(node,finalDataSalary);
      const value = forecast?stateValue.sumValueParts([baseValue,forecast]):baseValue;
      if (BOUNDARIES.has(node.status) && !Number.isFinite(value)) throw new Error("SEARCH_VALUE_INVALID");
      const realization = takesTransport ? -transportQuote.value : baseRealization;
      const preparationDebt = BOUNDARIES.has(node.status) ? preparationDebtForNode(node) : null;
      const landingCompanyRetained = realizationTies && BOUNDARIES.has(node.status) ? port.landingCompanyRetained?.(node) || 0 : 0;
      const publicDataCard=realizationTies&&BOUNDARIES.has(node.status)?port.retainedPublicDataCard?.(node)||null:null;
      // A closed leaf retains its exact native envelope and scalar V; its full
      // observation can be regenerated, rather than pinning a second large tree.
      if (BOUNDARIES.has(node.status)&&!["income-plan-value","turn-tail-value"].includes(node.status)&&!quietLeaf(node))
        port.releaseBoundaryObservation?.(node);
      if (BOUNDARIES.has(node.status) && (!incumbent || value > incumbent.value)) incumbent = { node: index, value };
      const pickPolicy = !boundary && cardPickPlanning ? port.cardPickSpec(node) : null;
      let decisionPolicy=!boundary&&(finalMarkPlanning||resourcePlanning)?port.localDecisionSpec?.(node):null;
      let resourcePolicy=!boundary&&resourcePlanning?port.resourceSpec(node):null;
      const fundedEnd=resourcePolicy&&(analysisFunding&&port.analysisFundingEnd?.(node,analysisFunding)
        ||matchedAnalysisScan&&port.matchedAnalysisScanEnd?.(node,matchedAnalysisScan));
      if(fundedEnd&&resourcePolicy.excludedActionIds.includes(fundedEnd)){
        resourcePolicy={...resourcePolicy,retainedActionIds:[...resourcePolicy.retainedActionIds,fundedEnd],
          excludedActionIds:resourcePolicy.excludedActionIds.filter(id=>id!==fundedEnd),keptForAnalysisFunding:fundedEnd};
      }
      // A concrete resource purpose owns its data slot. The unbound generic
      // computer-first advisory must not delete its fixed blue funding choice.
      if(resourcePolicy?.plans.length&&decisionPolicy?.kind==="fixed-data-choice")decisionPolicy=null;
      const selection = boundary || decisionPolicy || pickPolicy?.fixed || resourcePolicy?.bound || resourcePolicy?.plans.length ? null : port.selectionSpec?.(node) || null;
      const postMainPlan = !boundary && !selection && !resourcePlanning && postMainPruning && node.status === "stable" && legacyProof(node)
        ? port.postMainPlanSpec(node) : null;
      let localPlan = postMainPlan ? { ...postMainPlan, kind: "post-main" } : null;
      if (!boundary && !selection && !localPlan && !resourcePlanning && openingPruning && node.status === "stable" && legacyProof(node)) {
        const opening = port.openingPlanSpec(node);
        if (opening) localPlan = { ...opening, kind: "opening" };
      }
      if (!boundary && !selection && !resourcePlanning && openingPruning && node.status === "stable" && legacyProof(node)) {
        const data = port.preMainDataPlanSpec?.(node);
        const fresh = data?.excludedActionIds.filter(id => !localPlan?.excludedActionIds.includes(id));
        if (fresh?.length) {
          const previous = localPlan;
          localPlan = previous ? { ...previous, proof: "seti-composed-before-main-strict-plans-v1",
            componentPlans: [previous, { ...data, kind: "pre-main-data" }],
            retainedActionIds: previous.retainedActionIds.filter(id => !fresh.includes(id)),
            excludedActionIds: [...previous.excludedActionIds, ...fresh] }
            : { ...data, kind: "pre-main-data" };
          localPlan.preMainDataExcludedActions = fresh.length;
        }
      }
      if (!boundary && !selection && !localPlan && !resourcePlanning && cardChoiceEquivalence && node.status === "stable") {
        const corners = port.postMainCornerChoiceSpec?.(node);
        if (corners && legacyProof(node)) localPlan = { ...corners, kind: "card-corner-choice" };
      }
      if (localPlan) {
        const kept = new Set(localPlan.retainedActionIds), removed = new Set(localPlan.excludedActionIds);
        if (!kept.size || !removed.size || kept.size !== localPlan.retainedActionIds.length
          || removed.size !== localPlan.excludedActionIds.length || kept.size + removed.size !== node.legalActions.length
          || node.legalActions.some(action => kept.has(action.actionId) === removed.has(action.actionId))) {
          throw new TypeError("SEARCH_LOCAL_PLAN_INVALID");
        }
      }
      if (localPlan?.kind === "post-main") {
        if (!Number.isSafeInteger(localPlan.maximumValueIncrease * 2) || localPlan.maximumValueIncrease < 0) {
          throw new TypeError("SEARCH_POST_MAIN_PROOF_INVALID");
        }
        const observation = node.observation;
        const player = observation.publicState.players.find(player => player.playerId === evaluate.seatId);
        const currentValue = valueOf(observation);
        // 所有贡献为非负整数/半整数；保留足够的精确加法空间，不以容差证明平分。
        if (!Number.isSafeInteger(player.finalScore) || player.finalScore < player.score
          || !Number.isSafeInteger(currentValue * 2) || currentValue < 0
          || currentValue * 2 + localPlan.maximumValueIncrease * 2 >= Number.MAX_SAFE_INTEGER / 2) localPlan = null;
        else { postMainProofNodes += 1; postMainExcludedActions += localPlan.excludedActionIds.length; }
      }
      if (["opening", "pre-main-data"].includes(localPlan?.kind)) {
        const preparations = localPlan.passPreparationActionIds || [];
        if (!Array.isArray(preparations) || new Set(preparations).size !== preparations.length
          || preparations.some(id => !localPlan.retainedActionIds.includes(id))) throw new TypeError("SEARCH_LOCAL_PLAN_INVALID");
        const observation = node.observation, currentValue = valueOf(observation);
        const player = observation.publicState.players.find(player => player.playerId === evaluate.seatId);
        if (!Number.isSafeInteger(player.finalScore) || player.finalScore < player.score
          || !Number.isSafeInteger(currentValue * 2) || currentValue < 0 || currentValue > Number.MAX_SAFE_INTEGER / 64) localPlan = null;
        else {
          if (localPlan.kind === "opening") { openingProofNodes += 1; openingExcludedActions += localPlan.excludedActionIds.length; }
          if (localPlan.preMainDataExcludedActions) {
            preMainDataProofNodes += 1; preMainDataExcludedActions += localPlan.preMainDataExcludedActions;
          }
        }
      }
      if (localPlan?.kind === "card-corner-choice") {
        cardCornerProofNodes += 1; cardCornerExcludedActions += localPlan.excludedActionIds.length;
      }
      let borrowPlan = !resourcePlanning && !boundary && !selection && !resourcePolicy?.bound && postMainPruning && limits.transitions <= 4096 && legacyProof(node)
        ? port.postMainBorrowSpec?.(node) : null;
      if (borrowPlan) {
        const value = valueForNode(node);
        if (!Number.isSafeInteger(value * 2) || value < 0 || value > Number.MAX_SAFE_INTEGER / 64) borrowPlan = null;
        else if (!borrowPlan.retainedTileIds.length && localPlan) borrowPlan = null;
      }
      if (borrowPlan) {
        postMainBorrowProofNodes += 1; postMainBorrowExcludedChoices += borrowPlan.excludedTileIds.length;
        if (!borrowPlan.retainedTileIds.length) localPlan = { kind: "post-main-borrow-skip", proof: borrowPlan.proof,
          retainedActionIds: node.legalActions.filter(action => action.actionId !== borrowPlan.industryActionId).map(action => action.actionId),
          excludedActionIds: [borrowPlan.industryActionId] };
      }
      const needsMovementPlan = !resourcePolicy?.bound && !resourcePolicy?.cargoCommittedMovement && node.legalActions.some(action => (!localPlan || localPlan.retainedActionIds.includes(action.actionId))
        && (Number.isInteger(action.target?.deltaX) || action.target?.kind === "move-payment"
          || action.target?.tradeId === "energy-for-move" || action.family === "card_corner" && action.payload?.kind === "move"));
      let movementPolicy = movementPlanning && !boundary && needsMovementPlan ? port.goalMovementSpec(node) : null;
      // Do not spend paid moves for an unobserved rotation before collecting
      // the proved, immediately available energy of a just-launched probe.
      const advance=movementPolicy?.chosenGoal?.timing==="advance-before-rotation"&&movementPolicy.selectedActionId;
      const fixedBlueEnergy=advance&&node.status==="stable"&&node.observation?.publicState?.roundNumber===4
        &&resourcePolicy?.plans.length===1&&resourcePolicy.plans[0].goal.kind==="blue-data"&&(()=>{
          const self=node.observation.selfState?.playerId,pub=node.observation.publicState;
          const own=pub.players.find(p=>p.playerId===self),ships=pub.board?.rockets?.filter(r=>r.playerId===self);
          const ship=ships?.length===1&&ships[0];
          return own?.mainActionCompleted&&ship&&(ship.kind||"standard")==="standard"&&!ship.fossilId
            &&ship.sectorX===ship.launchSectorCoordinate?.x&&ship.sectorY===ship.launchSectorCoordinate?.y
            &&resourcePolicy.blueTails?.some(t=>t.selected&&t.netGain>0&&t.goalId===resourcePolicy.plans[0].goal.id
              &&t.requiredNativeInputs===2&&!t.dataCornerId&&!t.incomeCardId
              &&own.dataProgress?.blueSlots?.some(b=>b.slot===t.blueSlot&&b.tileId==="blue2"));
        })();
      if(resourcePlanning&&movementPolicy?.chosenGoal?.timing==="advance-before-rotation"&&movementPolicy.selectedActionId
        &&!fixedBlueEnergy
        &&!resourcePolicy?.plans.some(p=>["held-landing-route","blue-landing-supply"].includes(p.goal.kind))){
        const retainedActionIds=[movementPolicy.selectedActionId];
        const delivery=movementPolicy.knownFreeScanDelivery?.actionId;
        if(delivery&&!retainedActionIds.includes(delivery))retainedActionIds.push(delivery);
        movementPolicy={...movementPolicy,forceExecution:true,reason:"execute-selected-advance-timing",
          retainedActionIds,excludedActionIds:node.legalActions.filter(a=>!retainedActionIds.includes(a.actionId)).map(a=>a.actionId),
          suppressedResourceGoals:resourcePolicy?.plans.map(p=>p.goal.id)||[]};
      }
      if (movementPolicy) {
        movementPolicyNodes += 1; movementDirectionsExcluded += movementPolicy.excludedDirectionCount;
        routeGeometryNodes += movementPolicy.routingNodes;
      }
      const retainedActions = node.legalActions.filter(action => (!localPlan || localPlan.retainedActionIds.includes(action.actionId))
        && (!movementPolicy || movementPolicy.retainedActionIds.includes(action.actionId))
        && (!pickPolicy || pickPolicy.retainedActionIds.includes(action.actionId))
        // A selected urgent movement prefix supersedes the greedy resource tail.
        // Suppressing its plans must also stop its filter from deleting this move.
        && (!resourcePolicy || movementPolicy?.forceExecution || resourcePolicy.retainedActionIds.includes(action.actionId))
        && (!decisionPolicy||decisionPolicy.retainedActionIds.includes(action.actionId)));
      if (!boundary && !retainedActions.length && (!resourcePolicy?.plans.length || movementPolicy?.forceExecution) && !resourcePolicy?.bound) throw new Error("SEARCH_MOVEMENT_POLICY_CONFLICT");
      const alternatives = selection ? port.selectionPlans(node)
        : retainedActions.flatMap(action => {
          if (movementPolicy?.plan && movementPolicy.selectedActionId === action.actionId
            && movementPolicy.intent.path.length && Number.isInteger(action.target?.deltaX)) return {
            firstActionId: action.actionId, submissions: movementPolicy.intent.path.length*2+3,
            goalPlan: movementPolicy.plan };
          if (borrowPlan?.industryActionId === action.actionId) return borrowPlan.retainedTileIds.map(tileId => ({
            firstActionId: action.actionId, submissions: 2, borrowTileId: tileId }));
          const pickPlan=pickPolicy?.selectedActionId===action.actionId?pickPolicy:null;
          const openingPass = localPlan?.kind === "opening" && localPlan.passPreparationActionIds?.includes(action.actionId);
          if (openingPass && typeof port.expandOpeningPass !== "function") throw new TypeError("SEARCH_OPENING_PASS_PORT_INVALID");
          return { firstActionId: action.actionId, submissions: openingPass ? 2 : 1, ...(pickPlan?{cardPickPlan:pickPlan}:{}), ...(openingPass ? { openingPass: true } : {}) };
        });
      if(resourcePolicy?.plans.length&&!movementPolicy?.forceExecution)alternatives.push(...resourcePolicy.plans.map(plan=>({firstActionId:plan.firstActionId,submissions:1,resourcePlan:plan})));
      const alternativeCount = selection ? Array.from({ length: selection.requiredCount }, (_, i) =>
        (selection.cardIds.length - i) / (selection.unordered ? i + 1 : 1))
        .reduce((count, n) => count * n, 1) : alternatives.length;
      let resources = !boundary && !selection && useMoneyCapacity ? port.openingMoneyCapacity(node) : null;
      if (resources?.moneyCapacity) {
        const currentValue = valueForNode(node);
        if (!Number.isSafeInteger(currentValue * 2) || currentValue < 0 || currentValue > Number.MAX_SAFE_INTEGER / 64) resources = null;
      }
      if (!resources && !boundary && !selection && useResourceDominance) {
        resources = port.postMainResourceOrder(node) || port.openingResourceOrder?.(node) || null;
        if (!resources && limits.transitions <= 4096 && stateValue?.isDefaultStateValueEvaluator?.(evaluate)) {
          resources = port.knownCardMoneyOrder?.(node) || null;
          if (resources) {
            let value;
            resources = { ...resources, moneyValue: () => value ??= valueForNode(node) };
          }
        }
      }
      const configured={ node, edges: [], selection, alternatives, alternativeCount, resources, localPlan, borrowPlan,
        movementPolicy, pickPolicy, resourcePolicy, decisionPolicy, queuePriority, salary, deferredPublicity, deferredCargo, pickupFunding, pickupRank:pickupFunding?.rank, researchData, researchScan, researchIncome, regionFollowup, scanTimingQuote, paidScanAnalysis, analysisFundingQuote, matchedScanQuote, transportQuote:takesTransport?transportQuote:null, preparedTransport:preparedGain>0?preparedTransport:null, displayTransportQuote, expanded: boundary || resourcePolicy?.step?.kind==="infeasible", value, realization, preparationDebt, landingCompanyRetained, publicDataCard, distance: boundary ? 0 : Infinity, best: null };
      if(initializeDeferred){configured.queued=nodes[index].queued;nodes[index]=configured;}else nodes.push(configured);
      if (resources) {
        const peers = (resourceGroups.get(resources.group) || []).filter(i => !nodes[i].prunedBy);
        const upper = peers.find(i => dominates(nodes[i].resources, resources));
        if (upper != null) prune(index, upper);
        else {
          for (const lower of peers) if (lower !== 0 && !nodes[lower].expanded
            && dominates(resources, nodes[lower].resources)) prune(lower, index);
          resourceGroups.set(resources.group, [...peers, index]);
        }
      }
      if (!initializeDeferred && !nodes[index].expanded && !nodes[index].prunedBy) {
        const ahead=queue.findIndex(i=>nodes[i].queuePriority>queuePriority);
        if(ahead<0)queue.push(index);else queue.splice(ahead,0,index); nodes[index].queued = true; pendingFrontier += 1;
      }
      peakFrontier = Math.max(peakFrontier, pendingFrontier);
      return { index, equivalent: false };
    }
    add(root);
    outer: while (queue.length) {
      const currentIndex=queue.pop();let entry = nodes[currentIndex];
      if (entry.prunedBy) {  continue; }
      if (usePostMainValueBound && incumbent && entry.node.status === "stable") {
        if (now() - startedAt >= limits.milliseconds) { stopReason = "watchdog"; break; }
        const bound = port.postMainValueBound?.(entry.node);
        if (bound && (bound.capitalValueModel===stateValue.MODEL_VERSION||legacyProof(entry.node))) {
          const currentValue = valueForNode(entry.node);
          const player = observationForValue(entry.node).publicState.players.find(player => player.playerId === evaluate.seatId);
          const increase = bound.maximumValueIncrease;
          if (!Number.isFinite(increase) || increase < 0) throw new TypeError("SEARCH_POST_MAIN_BOUND_INVALID");
          const safe = [currentValue,increase].every(value => Number.isSafeInteger(value*2) && value >= 0
            && value < Number.MAX_SAFE_INTEGER/64) && player.finalScore === player.score;
          const upperBound = safe ? currentValue+increase : null;
          if (now() - startedAt >= limits.milliseconds) { stopReason = "watchdog"; break; }
          if (upperBound != null && incumbent.value > upperBound) {
            entry.prunedByBound = { ...incumbent, upperBound, proof: bound.proof, modelKey: evaluate.modelKey,
              boundKind: "post-main-continuation", currentValue, bound };
            postMainValuePrunes += 1;
            if (entry.queued) { entry.queued = false; pendingFrontier -= 1; }
             continue;
          }
        }
      }
      if (useScanBound && incumbent && entry.node.status === "decision") {
        if(now()-startedAt>=limits.milliseconds){stopReason="watchdog";break;}
        const bound=port.standardScanValueBound?.(entry.node);
        if(bound&&legacyProof(entry.node)){const currentValue=valueForNode(entry.node),player=entry.node.observation.publicState.players.find(p=>p.playerId===evaluate.seatId);
          const upperBound=currentValue+bound.valueDelta;
          if(!Number.isSafeInteger(bound.valueDelta*2))throw new TypeError("SEARCH_SCAN_BOUND_INVALID");
          if(now()-startedAt>=limits.milliseconds){stopReason="watchdog";break;}
          if(player.finalScore===player.score && [currentValue,upperBound].every(v=>Number.isSafeInteger(v*2)&&v>=0&&v<Number.MAX_SAFE_INTEGER/64) && incumbent.value>upperBound){
            entry.prunedByBound={...incumbent,upperBound,proof:bound.proof,modelKey:evaluate.modelKey,boundKind:"standard-scan-refill",currentValue,bound};scanValuePrunes+=1;
            if(entry.queued){entry.queued=false;pendingFrontier-=1;}continue;
          }
        }
      }
      if(entry.deferredPolicy){add(entry.node,entry.queuePriority,true);entry=nodes[currentIndex];}
      const incomeProof=resourcePlanning&&stateValue?.isDefaultStateValueEvaluator?.(evaluate)
        &&entry.alternatives.length===1&&entry.alternatives[0].resourcePlan?.goal.kind==="income"
        ?port.incomePlanSummary?.(entry.node):null;
      if(incomeProof&&(incomeProof.netGain===0||(incomeProof.publicAmibaBlindIncome
        ?exactTailSum(valueForNode(entry.node),incomeProof.netGain)!==null
        :[valueForNode(entry.node),incomeProof.netGain].every(v=>Number.isSafeInteger(v*2))))){
        if(nodes.length+certificateNodes>=limits.nodes){stopReason="node-budget";break;}
        if(now()-startedAt>=limits.milliseconds){stopReason="watchdog";break;}
        const leaf=port.incomePlanBoundary(entry.node,incomeProof),added=add(leaf);
        entry.edges=[{actionId:incomeProof.firstActionId,target:added.index,cost:incomeProof.requiredNativeInputs,equivalent:added.equivalent,
          knownIncomePlan:incomeProof,actualNativeInputs:0,provedNativeInputs:incomeProof.requiredNativeInputs}];
        incomePlanProofs++;provedIncomeInputs+=incomeProof.requiredNativeInputs;entry.expanded=true;
        if(entry.queued){entry.queued=false;pendingFrontier--;}
        continue;
      }
      // A rejected or out-of-budget plan cannot use the legacy proof. Avoid
      // projecting its full value observation just to reject it again.
      const optimal = usePostMainValueBound && !entry.resourcePolicy?.bound && entry.node.status === "stable"
        ? port.postMainOptimalPlanSpec?.(entry.node) : null;
      if (optimal && transitions+optimal.submissions <= limits.transitions
        && nodes.length+certificateNodes+optimal.submissions <= limits.nodes
        && pendingFrontier+optimal.submissions-1 <= limits.frontier && legacyProof(entry.node)) {
        const currentValue = valueForNode(entry.node), increase = optimal.bound.maximumValueIncrease;
        const safe = [currentValue,increase].every(value => Number.isSafeInteger(value*2) && value >= 0 && value < Number.MAX_SAFE_INTEGER/64);
        if (safe) {
          const macro = port.expandPostMainOptimalPlan(entry.node, () => now()-startedAt < limits.milliseconds);
          transitions += macro.submissions; certificateNodes += macro.submissions;
          postMainOptimalPlanSteps += macro.submissions;
          peakFrontier = Math.max(peakFrontier,pendingFrontier+macro.submissions-(macro.complete?1:0));
          if (!macro.complete) {
            entry.attainmentAttempt = { proof: optimal.proof, submissions: macro.submissions,
              steps: macro.prefixes.map(prefix => prefix.action.actionId), pendingCertificateStates: macro.submissions };
            stopReason = "watchdog"; break;
          }
          if (macro.submissions !== optimal.submissions || !BOUNDARIES.has(macro.node.status)
            || valueForNode(macro.node) !== currentValue+increase) throw new Error("SEARCH_ATTAINED_BOUND_WITNESS_MISMATCH");
          certificateNodes -= 1;
          const added = add(macro.node), first = macro.prefixes[0].action.actionId;
          if (nodes[added.index].value !== currentValue+increase) throw new Error("SEARCH_ATTAINED_BOUND_IDENTITY_MISMATCH");
          if (added.equivalent) equivalents += 1;
          entry.optimalAttainment = macro;
          entry.attainedPlan = { ...optimal, ...(resourcePlanning?{resourceGoal:optimal.income?"data:income:4":"end-turn"}:{}), expectedValue: currentValue+increase, actualBoundary: added.index,
            certificatePrefixes: macro.prefixes.length, minimumInputs: optimal.submissions };
          const excluded = entry.node.legalActions.filter(action => action.actionId !== first).map(action => action.actionId);
          entry.localPlan = excluded.length ? { kind: "post-main-attained-bound", proof: optimal.proof,
            retainedActionIds: [first], excludedActionIds: excluded } : null;
          entry.edges = [{ actionId: first, target: added.index, cost: macro.submissions, equivalent: added.equivalent,
            optimalPlan: true, proof: optimal.proof, steps: macro.prefixes.map(prefix => prefix.action.actionId) }];
          entry.alternatives = [{ firstActionId: first, submissions: macro.submissions }]; entry.alternativeCount = 1;
          entry.expanded = true; postMainOptimalPlans += 1;
          if (entry.queued) { entry.queued = false; pendingFrontier -= 1; }
           continue;
        }
      }
      let bound = null, upperBound = null, boundChecked = false;
      if (useCardTradePruning && incumbent && entry.node.status === "decision" && legacyProof(entry.node)) {
        if (now() - startedAt >= limits.milliseconds) { stopReason = "watchdog"; break; }
        bound = port.cardTradeBound(entry.node); boundChecked = true;
        upperBound = bound
          ? stateValue.evaluateHandCountDelta(evaluate, entry.node.observation, bound.handDelta) : null;
        if (now() - startedAt >= limits.milliseconds) { stopReason = "watchdog"; break; }
        if (bound && incumbent.value > upperBound) {
          entry.prunedByBound = { ...incumbent, upperBound, proof: bound.proof, modelKey: evaluate.modelKey };
          cardTradePrunes += 1;
          if (entry.queued) { entry.queued = false; pendingFrontier -= 1; }
          
          continue;
        }
      }
      if (cardChoiceEquivalence && !entry.resourcePolicy && !entry.selection && !entry.pickPolicy?.fixed && entry.node.status === "decision" && entry.node.legalActions.length > 1
        && entry.node.legalActions.every(action => action.family === "choose_card") && legacyProof(entry.node)) {
        if (now() - startedAt >= limits.milliseconds) { stopReason = "watchdog"; break; }
        const tradeChoice = entry.node.legalActions.every(action => action.target?.kind === "trade-card-selection");
        if (!boundChecked && tradeChoice) bound = port.cardTradeBound(entry.node);
        const passChoice = !tradeChoice && port.passReserveChoiceSpec?.(entry.node);
        if (passChoice) bound = passChoice;
        if ((tradeChoice || passChoice) && bound?.handDelta === 1) {
          const expectedValue = upperBound ?? stateValue.evaluateHandCountDelta(evaluate, entry.node.observation, 1);
          if (now() - startedAt >= limits.milliseconds) { stopReason = "watchdog"; break; }
          const actionIds = entry.node.legalActions.map(action => action.actionId).sort();
          if (new Set(actionIds).size !== actionIds.length) throw new TypeError("SEARCH_LOCAL_PLAN_INVALID");
          entry.localPlan = { kind: "card-choice", proof: passChoice ? passChoice.proof : "seti-card-trade-information-choice-value-equivalence-v1",
            boundProof: bound.proof, retainedActionIds: actionIds.slice(0, 1), excludedActionIds: actionIds.slice(1), expectedValue,
            expectedStatus: passChoice ? passChoice.expectedStatus : "information-barrier" };
          entry.alternatives = [{ firstActionId: actionIds[0], submissions: 1 }];
          entry.alternativeCount = 1;
          cardChoiceProofNodes += 1; cardChoiceExcludedActions += actionIds.length - 1;
        }
      }
      const tailNeedsNative=coreExtendedPurpose||displayedTransport&&port.displayedTransportTailRelevant(entry.node,displayedTransport);
      const orderClaim=!tailNeedsNative&&currentIndex!==0&&resourcePlanning&&realizationTies&&port.proveDeferredFinalDataClaim
        &&entry.alternatives.some(x=>x.resourcePlan?.goal.kind==="blue-data"&&[1,2].includes(x.resourcePlan.goal.blueSlot))
        &&entry.node.legalActions.find(a=>a.family==="complete_task"&&a.target?.ruleId==="b117-orbit-land-count-task"
          &&entry.alternatives.some(x=>x.firstActionId===a.actionId));
      if(orderClaim)entry.alternatives=[...entry.alternatives.filter(x=>x.firstActionId!==orderClaim.actionId),
        ...entry.alternatives.filter(x=>x.firstActionId===orderClaim.actionId)];
      for (const alternative of entry.alternatives) {
        if (entry.prunedBy) break;
        if(!extendedPurpose&&alternative.goalPlan&&incumbent&&resourcePlanning&&movementPlanning&&cardPickPlanning&&finalMarkPlanning
          &&stateValue?.isDefaultStateValueEvaluator?.(evaluate)){
          if(now()-startedAt>=limits.milliseconds){stopReason="watchdog";break outer;}
          const bound=port.movementPlanValueBound?.(entry.node);
          if(bound&&bound.firstActionId===alternative.firstActionId){
            const currentValue=valueForNode(entry.node),finalRound=root.observation.publicState.roundNumber===4;
            const upperBound=finalRound?exactTailSum(currentValue,bound.valueDelta):currentValue+bound.valueDelta;
            if(!finalRound&&!Number.isSafeInteger(bound.valueDelta*2))throw new TypeError("SEARCH_MOVEMENT_BOUND_INVALID");
            if(upperBound!==null&&incumbent.value>upperBound){
              (entry.actionBounds||=[]).push({actionId:alternative.firstActionId,...incumbent,upperBound,proof:bound.proof,modelKey:evaluate.modelKey,boundKind:"fixed-paid-movement-tail",currentValue,bound});movementValuePrunes++;continue;
            }
            if(root.observation.publicState.roundNumber===4&&entry.alternatives.length===1
              &&queue.length&&!entry.movementDeferred){
              // Resolve other pending purposes before paying this fixed prefix.
              // One deferral preserves this exact node and every budget charge.
              entry.movementDeferred=true;queue.unshift(currentIndex);continue outer;
            }
          }
        }
        if(!tailNeedsNative&&resourcePlanning&&realizationTies
          &&entry.node.legalActions.some(a=>a.actionId===alternative.firstActionId&&a.family==="complete_task")
          &&entry.alternatives.some(x=>entry.node.legalActions.some(a=>a.actionId===x.firstActionId&&a.family==="end_turn"))){
          if(orderClaim&&alternative.firstActionId===orderClaim.actionId
            &&nodes.length+certificateNodes+5<limits.nodes&&transitions+5<=limits.transitions
            &&pendingFrontier+5<=limits.frontier){
            const blue=entry.edges.find(x=>x.resourcePlan?.goal.kind==="blue-data"
              &&[1,2].includes(x.resourcePlan.goal.blueSlot)&&x.goalStatus==="completed");
            const execution=blue&&resourceExecutions.get(blue);
            const end=entry.alternatives.find(x=>entry.node.legalActions.some(a=>a.actionId===x.firstActionId&&a.family==="end_turn"));
            const deferred=execution&&port.proveDeferredFinalDataClaim(entry.node,alternative.firstActionId,end.firstActionId,
              {plan:blue.resourcePlan,execution},()=>now()-startedAt<limits.milliseconds);
            if(deferred){(entry.blueClaimEquivalences||=[]).push({actionId:alternative.firstActionId,...deferred});continue;}
          }
          // These two complete fixed paths can share a handover. Keep the
          // original budget charges for callers with configured limits.
          const quietEnd=entry.alternatives.length===2&&!alternative.resourcePlan&&!alternative.goalPlan
            &&unlimited
            &&entry.alternatives.find(a=>!a.resourcePlan&&!a.goalPlan&&entry.node.legalActions.some(x=>x.actionId===a.firstActionId&&x.family==="end_turn"));
          const quiet=quietEnd&&port.redundantQuietFinalClaim?.(entry.node,alternative.firstActionId,quietEnd.firstActionId,
            ()=>now()-startedAt<limits.milliseconds);
          if(quiet){
            (entry.quietClaimEquivalences||=[]).push({actionId:alternative.firstActionId,...quiet});
            continue;
          }
          const proof=port.redundantCargoClaim?.(entry.node,alternative.firstActionId);
          if(proof){
            (entry.cargoClaimEquivalences||=[]).push({actionId:alternative.firstActionId,...proof});
            continue;
          }
        }
        const tailKind=!tailNeedsNative&&alternative.cardPickPlan?.goal.id==="income:computer:4"
          &&entry.node.legalActions.some(a=>a.actionId===alternative.firstActionId&&a.target?.tradeId==="publicity-for-card")?"paid-income-end-turn"
          :alternative.resourcePlan?.goal.kind==="blue-data"?"blue-end-turn"
          :["income","computer-prefix"].includes(alternative.resourcePlan?.goal.kind)?"data-end-turn"
          :entry.node.legalActions.some(a=>a.actionId===alternative.firstActionId&&a.family==="end_turn")?"end-turn":null;
        const regionNeedsTail=tailKind!=="end-turn"&&amibaRegion&&port.amibaRegionNeedsNativeTail(entry.node,amibaRegion);
        let tail=tailKind&&!regionNeedsTail&&resourcePlanning&&stateValue?.isDefaultStateValueEvaluator?.(evaluate)?port.turnTailSummary?.(entry.node,tailKind):null;
        if((tail?.bluePublicPick?.taskChoice||tail?.computerThenScoredBlue)&&(researchDataPurpose||deferredComputerIncome||amibaRegion))tail=null;
        if((tail?.incomeThenQuietEnd||tail?.computerThenQuietEnd||tail?.computerThenKnownBluePick||tail?.quietTaskChoice||tail?.incomeThenBlueCurrency||tail?.cappedTaskBlueCurrency||tail?.scoredCornerBlueCurrency||tail?.exactFixedBlueTie||tail?.computerFiveForeignBlue)&&tailNeedsNative)tail=null;
        if(!tailNeedsNative&&tail?.primaryOnly&&tail.firstActionId===alternative.firstActionId&&currentIndex!==0&&incumbent){
          if(now()-startedAt>=limits.milliseconds){stopReason="watchdog";break outer;}
          const currentValue=valueForNode(entry.node),upperBound=exactTailSum(currentValue,tail.netGain);
          if(upperBound!==null&&incumbent.value>upperBound){
            (entry.actionBounds||=[]).push({actionId:alternative.firstActionId,...incumbent,upperBound,
              proof:tail.proof,modelKey:evaluate.modelKey,boundKind:"fixed-data-primary-only",currentValue});
            dataPrimaryBoundPrunes++;continue;
          }
        }
        if(tail&&!alternative.resourcePlan?.goal.competingTransportCash&&!tail.primaryOnly&&tail.firstActionId===alternative.firstActionId
          &&(tail.netGain===0
            ||exactTailSum(valueForNode(entry.node),tail.netGain)!==null)){
          if(nodes.length+certificateNodes>=limits.nodes){stopReason="node-budget";break outer;}
          if(now()-startedAt>=limits.milliseconds){stopReason="watchdog";break outer;}
          const added=add(port.turnTailBoundary(entry.node,tail));turnTailProofs++;provedTurnTailInputs+=tail.requiredNativeInputs;
          entry.edges.push({actionId:tail.firstActionId,target:added.index,cost:tail.requiredNativeInputs,equivalent:added.equivalent,
            turnTailPlanValue:tail,actualNativeInputs:0,provedNativeInputs:tail.requiredNativeInputs,
            ...(tail.incomeThenBlueCurrency||tail.cappedTaskBlueCurrency||tail.scoredCornerBlueCurrency||tail.bluePublicPick?.scoredFundingCornerId?{provedResourcePlan:alternative.resourcePlan}:{})});
          continue;
        }
        if(useScanBound && incumbent && entry.node.status==="stable" && entry.node.legalActions.some(action=>action.actionId===alternative.firstActionId && action.family==="scan" && action.target?.kind==="standard-scan")){
          if(now()-startedAt>=limits.milliseconds){stopReason="watchdog";break outer;}
          const bound=port.standardScanValueBound?.(entry.node);
          if(bound&&legacyProof(entry.node)){const currentValue=valueForNode(entry.node),player=entry.node.observation.publicState.players.find(p=>p.playerId===evaluate.seatId),upperBound=currentValue+bound.valueDelta;
            if(!Number.isSafeInteger(bound.valueDelta*2))throw new TypeError("SEARCH_SCAN_BOUND_INVALID");
            if(now()-startedAt>=limits.milliseconds){stopReason="watchdog";break outer;}
            if(player.finalScore===player.score && [currentValue,upperBound].every(v=>Number.isSafeInteger(v*2)&&v>=0&&v<Number.MAX_SAFE_INTEGER/64) && incumbent.value>upperBound){
              (entry.actionBounds ||= []).push({actionId:alternative.firstActionId,...incumbent,upperBound,proof:bound.proof,modelKey:evaluate.modelKey,boundKind:"standard-scan-refill",currentValue,bound});scanActionPrunes+=1;continue;
            }
          }
        }
        const mayCloseFossil = resourcePlanning && realizationTies && !alternative.resourcePlan && !alternative.goalPlan;
        const pairedClaim = mayCloseFossil ? port.pairedChongClaimBoundary?.(entry.node, alternative.firstActionId) : null;
        const fossilBoundary = pairedClaim || (mayCloseFossil ? port.chongTaskPeekBoundary?.(entry.node, alternative.firstActionId) : null);
        if (fossilBoundary) {
          if (now() - startedAt >= limits.milliseconds) { stopReason = "watchdog"; break outer; }
          if (nodes.length + certificateNodes >= limits.nodes && !known.has(port.identity(fossilBoundary))) {
            stopReason = "node-budget"; break outer;
          }
          const added = add(fossilBoundary), proved = pairedClaim ? 2 : 1;
          if (added.equivalent) equivalents += 1;
          entry.edges.push({actionId: alternative.firstActionId, target: added.index, cost: proved,
            equivalent: added.equivalent, actualNativeInputs: 0, provedNativeInputs: proved,
            proof: pairedClaim ? "seti-shared-chong-trace-claim-value-v1" : "seti-unseen-chong-task-peek-boundary-v1"});
          continue;
        }
        if (!alternative.resourcePlan && !alternative.goalPlan && transitions + alternative.submissions > limits.transitions) stopReason = "transition-budget";
        else if (!alternative.resourcePlan && !alternative.goalPlan && nodes.length+certificateNodes >= limits.nodes) stopReason = "node-budget";
        else if (!alternative.resourcePlan && !alternative.goalPlan && pendingFrontier > limits.frontier) stopReason = "frontier-budget";
        else if (now() - startedAt >= limits.milliseconds) stopReason = "watchdog";
        if (stopReason) break outer;
        if(alternative.resourcePlan){
          const fixed=port.expandResourcePlan(entry.node,alternative.resourcePlan,(count,contexts,input,work)=>{
            if(now()-startedAt>=limits.milliseconds)return "watchdog";
            const inputs=work?work.newSubmissions+(input?work.nextNewInput:0):count+(input?1:0);
            // Intermediate identity counts only answer finite node/frontier
            // gates. The completed macro still records exact identities.
            if(limits.nodes===Infinity&&limits.frontier===Infinity)return transitions+inputs>limits.transitions?"transition-budget":null;
            const fresh=work?resourceStateAdditions([...work.sharedStates,...(work.nextNode?[work.nextNode]:[])]).size+(work.additionalStates||0):count+contexts+(input?1:0);
            if(transitions+inputs>limits.transitions)return "transition-budget";
            if(nodes.length+certificateNodes+fresh>limits.nodes)return "node-budget";
            if(pendingFrontier+Math.max(0,fresh-1)>limits.frontier)return "frontier-budget";
            return null;
          });
          const newInputs=fixed.newSubmissions??fixed.submissions;
          transitions+=newInputs;logicalResourceInputs+=fixed.submissions;sharedResourceInputHits+=fixed.submissions-newInputs;
          const fresh=fixed.sharedStates?resourceStateAdditions(fixed.sharedStates):null;
          if(fresh){for(const id of fresh)sharedInternalStates.add(id);certificateNodes+=fresh.size;}
          else certificateNodes+=fixed.submissions+fixed.contexts;
          peakFrontier=Math.max(peakFrontier,pendingFrontier+(fresh?Math.max(0,fresh.size-1):fixed.submissions+fixed.contexts-(fixed.complete?1:0)));
          if(!fixed.complete){entry.resourceAttempt={goal:fixed.goal,submissions:fixed.submissions,preparations:fixed.preparations};stopReason=fixed.stopReason;break outer;}
          if(!fixed.submissions)throw new Error("SEARCH_RESOURCE_PLAN_EMPTY");
          if(!fresh)certificateNodes-=1;const added=add(fixed.node,["income","analyze","blue-data"].includes(alternative.resourcePlan.goal.kind)?1:0);if(added.equivalent)equivalents+=1;
          entry.edges.push({actionId:alternative.firstActionId,target:added.index,cost:fixed.submissions,equivalent:added.equivalent,
            newInputs,sharedPath:fixed.sharedPath||[],resourcePlan:alternative.resourcePlan,goalStatus:fixed.goalStatus,fallbackReason:fixed.fallbackReason||null,
            preparations:fixed.preparations,steps:fixed.prefixes.map(p=>p.action.actionId)});
          resourceExecutions.set(entry.edges.at(-1),fixed);
          continue;
        }
        // A route estimate is a maximum. Charge the real fixed native inputs
        // one by one, using the same node/frontier accounting as the macro.
        let goalInputs=0,goalStopReason=null;
        const goalExecution = alternative.goalPlan ? port.expandGoalMovementPlan(entry.node, () => {
          if(transitions+goalInputs+1>limits.transitions)goalStopReason="transition-budget";
          else if(nodes.length+certificateNodes+goalInputs+1>limits.nodes)goalStopReason="node-budget";
          else if(pendingFrontier+goalInputs>limits.frontier)goalStopReason="frontier-budget";
          else if(now()-startedAt>=limits.milliseconds)goalStopReason="watchdog";
          if(goalStopReason)return false;
          goalInputs++;return true;
        }) : null;
        if (goalExecution) {
          if (goalExecution.complete && goalExecution.submissions < 1 || goalExecution.submissions > alternative.submissions
            || goalInputs !== goalExecution.submissions
            || goalExecution.prefixes.length !== goalExecution.submissions
            || goalExecution.prefixes.length && goalExecution.prefixes[0].action.actionId !== alternative.firstActionId) throw new Error("SEARCH_GOAL_PLAN_COST_INVALID");
          transitions += goalExecution.submissions;
          certificateNodes += goalExecution.submissions;
          peakFrontier = Math.max(peakFrontier,pendingFrontier+goalExecution.submissions-1);
          if (!goalExecution.complete) {
            entry.goalAttempt = { goal: goalExecution.goal, submissions: goalExecution.submissions };
            stopReason = goalStopReason || "watchdog"; break outer;
          }
          certificateNodes -= 1;
          const added = add(goalExecution.node);
          if (added.equivalent) equivalents += 1;
          entry.goalExecutions ||= new Map(); entry.goalExecutions.set(alternative.firstActionId,goalExecution);
          entry.edges.push({ actionId: alternative.firstActionId, target: added.index, cost: goalExecution.submissions,
            equivalent: added.equivalent, goalPlan: alternative.goalPlan, goalStatus: goalExecution.goalStatus,
            steps: goalExecution.prefixes.map(p => p.action.actionId) });
          continue;
        }
        if(cardPickPlanning&&!entry.selection&&!alternative.openingPass&&!alternative.borrowTileId){
          const fixed=port.expandWithCardPick(entry.node,alternative.firstActionId,count=>{
            if(now()-startedAt>=limits.milliseconds)return "watchdog";
            if(transitions+count+1>limits.transitions)return "transition-budget";
            if(nodes.length+certificateNodes+count+1>limits.nodes)return "node-budget";
            if(pendingFrontier+count>limits.frontier)return "frontier-budget";
            return null;
          });
          transitions+=fixed.submissions;certificateNodes+=fixed.submissions;
          peakFrontier=Math.max(peakFrontier,pendingFrontier+Math.max(0,fixed.submissions-1));
          if(!fixed.complete){entry.fixedCardAttempt={submissions:fixed.submissions,fixedChoices:fixed.fixedChoices};stopReason=fixed.stopReason;break outer;}
          if(!fixed.submissions)throw new Error("SEARCH_FIXED_CARD_PLAN_EMPTY");
          certificateNodes-=1;const added=add(fixed.node);if(added.equivalent)equivalents+=1;
          entry.fixedCardExecutions ||= new Map();entry.fixedCardExecutions.set(alternative.firstActionId,fixed);
          entry.edges.push({actionId:alternative.firstActionId,target:added.index,cost:fixed.submissions,equivalent:added.equivalent,
            fixedCardPlan:alternative.cardPickPlan||null,fixedChoices:fixed.fixedChoices,steps:fixed.prefixes.map(p=>p.action.actionId)});
          continue;
        }
        const macro = entry.selection ? port.expandSelection(entry.node, alternative.selectedIds)
          : alternative.openingPass ? port.expandOpeningPass(entry.node, alternative.firstActionId)
            : alternative.borrowTileId ? port.expandPostMainBorrow(entry.node, alternative.borrowTileId) : null;
        const child = macro ? macro.node : port.expand(entry.node, alternative.firstActionId);
        if (macro && macro.submissions !== alternative.submissions) throw new Error("SEARCH_MACRO_COST_MISMATCH");
        transitions += alternative.submissions;
        if (macro) { if (alternative.openingPass) openingPassMacros += 1;
          else if (alternative.borrowTileId) postMainBorrowMacros += 1; else selectionMacros += 1; }
        const added = add(child);
        if (entry.localPlan?.kind === "card-choice" && (child.status !== entry.localPlan.expectedStatus
          || nodes[added.index].value !== entry.localPlan.expectedValue)) throw new Error("SEARCH_CARD_CHOICE_WITNESS_MISMATCH");
        if (added.equivalent) equivalents += 1;
        entry.edges.push({ actionId: alternative.firstActionId, target: added.index,
          equivalent: added.equivalent, cost: alternative.submissions,
          ...(macro ? { ...(alternative.openingPass ? { openingPass: true } : alternative.borrowTileId ? { borrowTileId: alternative.borrowTileId } : { selectedIds: alternative.selectedIds }),
            proof: alternative.openingPass || alternative.borrowTileId ? macro.proof : alternative.proof,
            steps: macro.actions.map(action => action.actionId) } : {}) });
        if (now() - startedAt >= limits.milliseconds) {
          stopReason = "watchdog";
          break outer;
        }
      }
      entry.expanded = !entry.prunedBy;
      if (entry.queued) { entry.queued = false; pendingFrontier -= 1; }
      
    }

    // 在完整有向图上从叶逆向传播；保留回边，不能把 DFS 栈上的节点误判成无解。
    // 标量同值先比较有限叶的已兑现资本证据，再取最短路径；不沿边累加。
    // 距离仍打破同叶回路，第二排序不参与剪枝。
    if (!stopReason) {
      const parents = nodes.map(() => []);
      nodes.forEach((entry, index) => entry.edges.forEach(edge => parents[edge.target].push({ index, edge })));
      const covered = nodes.flatMap((entry, index) => entry.prunedBy || entry.prunedByBound || entry.actionBounds?.length ? [index] : []);
      for (const index of covered) nodes[index].covered = true;
      for (let head = 0; head < covered.length; head += 1) {
        for (const { index } of parents[covered[head]]) if (!nodes[index].covered) {
          nodes[index].covered = true;
          covered.push(index);
        }
      }
      // A next-round salary quote is a ranking forecast, never an upper
      // bound. Apply only after an unpruned current-turn graph has closed.
      if(finalDataSalary&&!covered.length){
        for(const entry of nodes)if(entry.salary){
          entry.value=stateValue.sumValueParts([entry.value,entry.salary.gain]);
          entry.salaryScore=entry.salary.score;
        }
      }
      const changed = nodes.flatMap((entry, index) => entry.value == null ? [] : [index]);
      // An opaque blind draw can close sooner than the same free displayed
      // Chong reward. Distance alone must not favor that information barrier.
      const chongOffer = root.legalActions.some(a => a.target?.kind === "residual-domain"
        && a.target.source === "display" && a.target.choiceId?.startsWith("chong:display:"))
        && root.legalActions.find(a => a.target?.kind === "residual-domain" && a.target.choiceId === "chong:blind");
      const knownChongIndex=root.observation?.publicState?.board?.aliens?.chongOffer?.displayedCardIndex;
      const nestedChongBlind=new Map();
      const chongBlindRank = (index, edge) => {
        if(!edge)return 0;
        if(index===0)return Number(edge.actionId===chongOffer?.actionId);
        const node=nodes[index].node;
        if(!Number.isSafeInteger(knownChongIndex)||node.status!=="decision")return 0;
        if(!nestedChongBlind.has(index)){
          const offered=node.legalActions.some(a=>a.target?.kind==="residual-domain"&&a.target.source==="display"
            &&a.target.choiceId===`chong:display:${knownChongIndex}`);
          const blind=offered&&node.legalActions.find(a=>a.target?.kind==="residual-domain"&&a.target.choiceId==="chong:blind");
          nestedChongBlind.set(index,blind?.actionId??null);
        }
        return Number(edge.actionId===nestedChongBlind.get(index));
      };
      // A quiet end is already proved on each side. Rank the two fixed
      // plans only if their settled immediate electricity is the same. Both
      // successors are one edge from an already valued boundary, so the
      // longer witness is settled before this choice propagates to parents.
      if (resourcePlanning && realizationTies && root.observation?.publicState?.roundNumber===3 && port.sameElectricityIncomeTie) {
        const quietEnd = entry => {
          const end=entry.edges[0]?.turnTailPlanValue;
          return entry.edges.length===1&&end?.kind==="end-turn"&&end.netGain===0&&end.markedTiles.length===0;
        };
        for (const entry of nodes) {
          const blue=entry.edges.find(e=>e.resourcePlan?.goal.kind==="blue-data");
          const income=entry.edges.find(e=>e.resourcePlan?.goal.kind==="income");
          if(blue?.goalStatus!=="completed"||income?.goalStatus!=="completed"||blue.fallbackReason||income.fallbackReason
            ||!quietEnd(nodes[income.target]))continue;
          let blueEnd=nodes[blue.target],multi=false;
          if(entry.edges.length===2){
            if(blue.steps.length!==(entry.node.status==="decision"?1:2)||income.steps.length!==blue.steps.length+1)continue;
          }else if(entry.edges.length===3&&entry.node.status==="decision"&&blue.steps.length===1){
            // The blue line may spend its other data on the first three computer slots.
            // Follow that sole completed plan only; a valuation shortcut or another choice
            // cannot stand in for the settled wallet.
            const prefix=entry.edges.find(e=>e.resourcePlan?.goal.id==="data:computer-prefix:3");
            const tail=blueEnd.edges.length===1&&blueEnd.edges[0];
            if(prefix?.goalStatus!=="completed"||prefix.fallbackReason||prefix.actionId!==income.actionId
              ||tail?.resourcePlan?.goal.id!=="data:computer-prefix:3"||tail.goalStatus!=="completed"||tail.fallbackReason
              ||prefix.steps.length+1!==tail.steps.length||income.steps.length!==tail.steps.length+2)continue;
            blueEnd=nodes[tail.target];multi=true;
          }else continue;
          if(quietEnd(blueEnd)&&port.sameElectricityIncomeTie(entry.node,blueEnd.node,nodes[income.target].node,income.resourcePlan.goal.incomeCardId,multi))
            entry.electricIncomeTie=income;
        }
      }
      for (let head = 0; head < changed.length; head += 1) {
        const target = nodes[changed[head]];
        for (const { index, edge } of parents[changed[head]]) {
          const parent = nodes[index];
          const distance = target.distance + edge.cost;
          // Carry the secondary cost to every parent. Switching a nested
          // choice from blind to public may lengthen the retained witness.
          const blindCount=(target.chongBlindCount??0)+chongBlindRank(index,edge);
          const blindRank=blindCount-(parent.chongBlindCount??0);
          const pickupRank=(target.pickupRank??0)-(parent.pickupRank??0);
          const incomeTieRank=Number(edge===parent.electricIncomeTie)
            -Number(Boolean(parent.best)&&parent.best===parent.electricIncomeTie);
          const shorter=distance < parent.distance || (distance === parent.distance && edge.actionId < parent.best?.actionId);
          const salaryTie=Number.isFinite(target.salaryScore)&&Number.isFinite(parent.salaryScore)
            ?target.salaryScore-parent.salaryScore:0;
          const finalTie=incomeTieRank>0 || incomeTieRank===0&&(salaryTie>0||salaryTie===0&&shorter);
          // A certified use of retained resources breaks a score tie before
          // favoring an immediately received but otherwise unbound reward.
          if (parent.value == null || target.value > parent.value
            || (target.value === parent.value && (target.preparationDebt < parent.preparationDebt
              || (target.preparationDebt === parent.preparationDebt && (pickupRank > 0
                || (pickupRank === 0 && (target.realization > parent.realization
                  || (target.realization === parent.realization && (target.landingCompanyRetained > parent.landingCompanyRetained
                    || (target.landingCompanyRetained === parent.landingCompanyRetained && (Number(Boolean(target.publicDataCard)) > Number(Boolean(parent.publicDataCard))
                      || (Boolean(target.publicDataCard) === Boolean(parent.publicDataCard)
                        && (blindRank < 0 || (blindRank === 0 && finalTie)))))))))))))) {
            parent.value = target.value;
            parent.realization = target.realization;
            parent.preparationDebt = target.preparationDebt;
            parent.landingCompanyRetained = target.landingCompanyRetained;
            parent.publicDataCard = target.publicDataCard;
            parent.chongBlindCount = blindCount;
            parent.pickupRank = target.pickupRank;
            parent.salaryScore=target.salaryScore;
            parent.distance = distance;
            parent.best = edge;
            changed.push(index);
          }
        }
      }
    }
    if (!stopReason && now() - startedAt >= limits.milliseconds) stopReason = "watchdog";
    const unresolved = nodes.flatMap((entry, index) => entry.expanded || entry.prunedBy || entry.prunedByBound ? [] : [{
      node: index, ...(entry.deferredPolicy?{policyPending:true}:{}), ...(entry.resourcePolicy?{resourceGoals:entry.alternatives.slice(entry.edges.length+(entry.actionBounds?.length||0)+(entry.blueClaimEquivalences?.length||0)).filter(a=>a.resourcePlan).map(a=>({goalId:a.resourcePlan.goal.id,mode:a.resourcePlan.mode,firstActionId:a.firstActionId,fallbackReason:a.resourcePlan.fallbackReason||null}))}:{}), actionIds: (entry.selection || entry.deferredPolicy ? entry.node.legalActions
        : entry.alternatives.slice(entry.edges.length+(entry.actionBounds?.length||0)+(entry.blueClaimEquivalences?.length||0)).map(alternative => ({ actionId: alternative.firstActionId })))
        .map(action => action.actionId),
      ...(entry.attainmentAttempt ? { attainmentAttempt: entry.attainmentAttempt } : {}),
      ...(entry.goalAttempt ? { goalAttempt: entry.goalAttempt } : {}),
      ...(entry.fixedCardAttempt ? { fixedCardAttempt: entry.fixedCardAttempt } : {}),
      ...(entry.resourceAttempt?{resourceAttempt:entry.resourceAttempt}:{}),
      ...(entry.selection ? { selectionPlansRemaining: entry.alternativeCount - entry.edges.length,
        selection: entry.selection } : {}),
    }]);
    const complete = !stopReason;
    function retainedWitness(index) {
      if (!complete) return null;
      const start = nodes[index].localPlan?.kind !== "card-choice" && (dominancePrunes || cardTradePrunes || postMainBorrowProofNodes || postMainValuePrunes || scanValuePrunes || scanActionPrunes) ? 0 : index;
      let current = start;
      for (let depth = 0; depth <= nodes.length; depth += 1) {
        const entry = nodes[current];
        if (BOUNDARIES.has(entry.node.status)) return { node: current, value: entry.value,
          ...(entry.node.planSummary?{kind:"reachable-plan-value-proof",planSummary:entry.node.planSummary}:{}),
          distance: nodes[start].distance, scope: start === index ? "local" : "global" };
        const edge = entry.best;
        if (!edge || !(nodes[edge.target].distance < entry.distance)) break;
        current = edge.target;
      }
      throw new Error("SEARCH_LOCAL_PLAN_WITNESS_MISSING");
    }
    const lines = nodes.map((entry, index) => ({
      node: index, status: entry.node.status, boundary: entry.node.boundary || null,
      ...(entry.node.planSummary?{planSummary:entry.node.planSummary}:{}),
      expanded: entry.expanded, alternatives:entry.deferredPolicy?null:entry.alternativeCount, edges: entry.edges,
      ...(entry.deferredPolicy?{policyPending:!entry.prunedByBound}:{}),
      distance: Number.isFinite(entry.distance) ? entry.distance : null,
      ...(entry.deferredPublicity?{deferredSectorPublicity:entry.deferredPublicity}:{}),
      ...(entry.deferredCargo?{deferredCargo:entry.deferredCargo}:{}),
      ...(entry.pickupFunding?{knownPickupFunding:entry.pickupFunding}:{}),
      ...(entry.salary&&Number.isFinite(entry.salaryScore)?{finalDataSalary:entry.salary}:{}),
      ...(entry.blueClaimEquivalences?{blueClaimEquivalences:entry.blueClaimEquivalences}:{}),
      ...(entry.cargoClaimEquivalences?{cargoClaimEquivalences:entry.cargoClaimEquivalences}:{}),
      ...(entry.quietClaimEquivalences?{quietClaimEquivalences:entry.quietClaimEquivalences}:{}),
      ...(entry.researchData?{researchData:entry.researchData}:{}),
      ...(entry.researchScan?{researchScan:entry.researchScan}:{}),
      ...(entry.researchIncome?{deferredComputerIncome:entry.researchIncome}:{}),
      ...(entry.regionFollowup?{knownAmibaRegion:entry.regionFollowup}:{}),
      ...(entry.paidScanAnalysis?{paidScanAnalysis:entry.paidScanAnalysis}:{}),
      ...(entry.scanTimingQuote?{knownScanTiming:entry.scanTimingQuote}:{}),
      ...(entry.analysisFundingQuote?{knownAnalysisFunding:entry.analysisFundingQuote}:{}),
      ...(entry.matchedScanQuote?{matchedAnalysisScan:entry.matchedScanQuote}:{}),
      ...(entry.transportQuote?{knownResearchTransport:entry.transportQuote}:{}),
      ...(entry.preparedTransport?{knownTransportPreparation:entry.preparedTransport}:{}),
      ...(entry.displayTransportQuote?{knownDisplayedTransport:entry.displayTransportQuote}:{}),
      ...(entry.landingCompanyRetained?{landingCompanyRetained:entry.landingCompanyRetained}:{}),
      ...(entry.publicDataCard?{retainedPublicDataCard:entry.publicDataCard}:{}),
      value: entry.value, realization: entry.realization ?? null, preparationDebt:entry.preparationDebt??null, completion: entry.prunedBy || entry.prunedByBound ? "proof-pruned"
        : entry.value == null ? (stopReason ? "pending" : entry.covered ? "covered-by-global-pruning" : "unreachable") : "reachable",
      ...(entry.prunedBy ? { prunedBy: entry.prunedBy } : {}),
      ...(entry.prunedByBound ? { prunedByBound: entry.prunedByBound } : {}),
      ...(entry.localPlan ? { localPlan: entry.localPlan,
        excludedActions: entry.localPlan.excludedActionIds.map(actionId => ({ actionId,
          proof: entry.localPlan.proof, retainedActionIds: entry.localPlan.retainedActionIds,
          witness: retainedWitness(index), completion: complete ? "covered-by-retained-search" : "pending-retained-search",
          modelKey: evaluate.modelKey })) } : {}),
      ...(entry.edges.some(edge => edge.openingPass) ? { normalizedPreparations: entry.edges.filter(edge => edge.openingPass)
        .map(edge => ({ actionId: edge.actionId, proof: edge.proof, steps: edge.steps,
          omittedContinuationFamilies: "all-except-pass", witness: retainedWitness(index), modelKey: evaluate.modelKey })) } : {}),
      ...(entry.borrowPlan ? { borrowPlan: { ...entry.borrowPlan, witness: retainedWitness(index),
        completion: complete ? "covered-by-origin-search" : "pending-origin-search", modelKey: evaluate.modelKey } } : {}),
      ...(entry.movementPolicy ? { movementPolicy: entry.movementPolicy } : {}),
      ...(entry.pickPolicy ? { cardPickPolicy: entry.pickPolicy } : {}),
      ...(entry.resourcePolicy?{resourcePolicy:entry.resourcePolicy}:{}),
      ...(entry.decisionPolicy?{decisionPolicy:entry.decisionPolicy}:{}),
      ...(entry.actionBounds ? { actionBounds: entry.actionBounds } : {}),
      ...(entry.attainedPlan ? { attainedPlan: entry.attainedPlan } : {}),
      ...(entry.attainmentAttempt ? { attainmentAttempt: entry.attainmentAttempt } : {}),
      ...(entry.goalAttempt ? { goalAttempt: entry.goalAttempt } : {}),
      ...(entry.fixedCardAttempt ? { fixedCardAttempt: entry.fixedCardAttempt } : {}),
      ...(entry.resourceAttempt?{resourceAttempt:entry.resourceAttempt}:{}),
      ...(entry.selection ? { selection: entry.selection, orderedExitCount: entry.alternativeCount } : {}),
    }));
    const roots = root.legalActions.map(action => {
      const excluded = lines[0].excludedActions?.find(exclusion => exclusion.actionId === action.actionId);
      if (excluded) return { actionId: action.actionId, target: null, value: null,
        completion: complete ? "proof-pruned" : "pending-retained-search", valueType: "not-executed", prunedByPlan: excluded };
      const actionBound=nodes[0].actionBounds?.find(bound=>bound.actionId===action.actionId);
      if(actionBound)return {actionId:action.actionId,target:null,value:null,valueType:"not-executed",completion:"proof-pruned",prunedByActionBound:actionBound};
      const transportEdge=nodes[0].edges.some(e=>e.actionId===action.actionId&&e.resourcePlan?.goal.kind==="transport-data-prep");
      if(!transportEdge&&nodes[0].pickPolicy?.excludedActionIds.includes(action.actionId))return{actionId:action.actionId,target:null,value:null,valueType:"not-executed",
        completion:"excluded-by-card-pick-policy",policy:nodes[0].pickPolicy.policy,goal:nodes[0].pickPolicy.goal,isEquivalence:false};
      if (nodes[0].movementPolicy?.excludedActionIds.includes(action.actionId)
        && !nodes[0].edges.some(e=>e.actionId===action.actionId&&(["held-landing-route","cargo-research-corner"].includes(e.resourcePlan?.goal.kind)||e.resourcePlan?.goal.movementFunding))) return {
        actionId: action.actionId, target: null, value: null, valueType: "not-executed",
        completion: "excluded-by-movement-policy", policy: nodes[0].movementPolicy.policy,
        chosenGoal: nodes[0].movementPolicy.chosenGoal, isEquivalence: false };
      if(nodes[0].resourcePolicy?.excludedActionIds.includes(action.actionId)&&!nodes[0].edges.some(e=>e.actionId===action.actionId))return{actionId:action.actionId,target:null,value:null,valueType:"not-executed",completion:"excluded-by-resource-policy",policy:nodes[0].resourcePolicy.policy,isEquivalence:false};
      if(!transportEdge&&nodes[0].decisionPolicy?.excludedActionIds.includes(action.actionId))return{actionId:action.actionId,target:null,value:null,valueType:"not-executed",completion:"excluded-by-local-decision-policy",policy:nodes[0].decisionPolicy.policy,isEquivalence:false};
      const selection = nodes[0].selection;
      // 纯点击的强连通部分可到达同一完整出口集；confirm 直接离开，只对应当前选择。
      const edge = selection && action.target?.confirm ? nodes[0].edges.find(edge =>
        JSON.stringify(edge.selectedIds) === JSON.stringify(selection.selectedIds))
        : nodes[0].edges.filter(edge => edge.actionId === action.actionId).sort((a,b)=>(nodes[b.target].value??-Infinity)-(nodes[a.target].value??-Infinity)||(nodes[a.target].preparationDebt??0)-(nodes[b.target].preparationDebt??0)||(nodes[b.target].realization??0)-(nodes[a.target].realization??0)||nodes[b.target].landingCompanyRetained-nodes[a.target].landingCompanyRetained||Number(Boolean(nodes[b.target].publicDataCard))-Number(Boolean(nodes[a.target].publicDataCard))||(nodes[a.target].chongBlindCount??0)-(nodes[b.target].chongBlindCount??0)
          ||(Number.isFinite(nodes[a.target].salaryScore)&&Number.isFinite(nodes[b.target].salaryScore)
            ?nodes[b.target].salaryScore-nodes[a.target].salaryScore:0)||nodes[a.target].distance+a.cost-nodes[b.target].distance-b.cost)[0];
      if (selection && !action.target?.confirm) return {
        actionId: action.actionId, target: null, value: nodes[0].value,
        completion: stopReason ? "pending" : nodes[0].value == null ? "unreachable" : "complete",
        proof: selection.proof, equivalentExitSet: true,
      };
      const resourcePlan=edge?.resourcePlan||edge?.provedResourcePlan;
      return {
        actionId: action.actionId, target: edge?.target ?? null,
        value: edge ? nodes[edge.target].value : null, realization: edge ? nodes[edge.target].realization ?? null : null, preparationDebt:edge?nodes[edge.target].preparationDebt??null:null,
        ...(edge?.turnTailPlanValue?{valueType:"proved-plan-value",turnTailPlanValue:edge.turnTailPlanValue}:{}),
        ...(edge?.knownIncomePlan?{valueType:"proved-plan-value",knownIncomePlan:edge.knownIncomePlan}:{}),
        ...(resourcePlan?{kind:"resource-goal-plan",goal:resourcePlan.goal,resourceGoalCount:nodes[0].edges.filter(e=>e.actionId===action.actionId&&(e.resourcePlan||e.provedResourcePlan)).length}:{}),
        ...(edge?.goalPlan ? {kind:"goal-plan",plan:edge.goalPlan} : {}),
        completion: stopReason || !edge ? "pending" : edge.knownIncomePlan||edge.turnTailPlanValue?"proved-plan-value":edge.openingPass ? "covered-by-opening-normal-form" : cardTradePrunes ? "covered-by-global-pruning"
          : scanValuePrunes || scanActionPrunes ? "covered-by-global-scan-bound" : postMainValuePrunes||movementValuePrunes||dataPrimaryBoundPrunes ? "covered-by-global-value-bound" : postMainBorrowProofNodes ? "covered-by-global-borrow-simulation" : dominancePrunes ? "covered-by-global-dominance"
          : nodes[edge.target].value == null ? "unreachable" : "complete",
        ...(dominancePrunes || cardTradePrunes || postMainBorrowProofNodes || postMainValuePrunes ||movementValuePrunes||dataPrimaryBoundPrunes|| scanValuePrunes || scanActionPrunes || edge?.openingPass ? { valueType: "attained-lower-bound" } : {}),
        ...(edge?.openingPass ? { normalForm: edge.proof } : {}),
      };
    });
    // The last-round wallet is only useful when it can still buy an action.
    // At an exact tie against an unproductive launch, keep the completed
    // funded scan that has already increased the official score projection.
    let fundedScanOverBareLaunch = null;
    const launchEdge = nodes[0].best;
    const launch = root.legalActions.find(a => a.actionId === launchEdge?.actionId && a.family === "launch");
    if (complete && !unresolved.length && realizationTies && root.status === "stable" && launch
      && root.observation.publicState.roundNumber === 4 && launchEdge.cost === 1 && nodes[0].realization === 0) {
      const state = root.observation.publicState, seat = launch.actorId;
      const p = state.players.find(x => x.playerId === seat);
      const scoreAt = node => observationForValue(node).publicState.players.find(x => x.playerId === seat)?.finalScore;
      const launched = nodes[launchEdge.target], end = launched.best;
      if (p?.energy === 0 && p.handCount === 0 && state.activePlayerIds.every(id => id === seat || state.passedPlayerIds.includes(id))
        && launched.edges.length === 1 && end?.cost === 1 && end.actionId.startsWith("end_turn:")
        && nodes[end.target].node.status === "turn-boundary" && scoreAt(nodes[end.target].node) === p.finalScore) {
        const alternatives = [];
        for (const edge of nodes[0].edges) {
          const t = nodes[edge.target], goal = edge.resourcePlan?.goal, finish = t.best;
          if (edge.goalStatus !== "completed" || goal?.kind !== "scan-flow" || edge.fallbackReason
            || !edge.actionId.startsWith("quick_trade:") || t.value !== launched.value
            || t.realization !== launched.realization || t.preparationDebt !== launched.preparationDebt
            || t.pickupRank !== launched.pickupRank || t.landingCompanyRetained !== launched.landingCompanyRetained
            || Boolean(t.publicDataCard) !== Boolean(launched.publicDataCard) || t.chongBlindCount !== launched.chongBlindCount
            || !finish || finish.cost !== 1 || !finish.actionId.startsWith("end_turn:")) continue;
          const last = nodes[finish.target];
          if (!["turn-boundary", "information-barrier"].includes(last.node.status)) continue;
          const score = scoreAt(last.node);
          if (score > p.finalScore) alternatives.push({edge, score, distance: edge.cost+t.distance});
        }
        alternatives.sort((a,b) => b.score-a.score || a.distance-b.distance || a.edge.actionId.localeCompare(b.edge.actionId));
        const selected = alternatives[0];
        if (selected) {
          nodes[0].best = selected.edge;
          nodes[0].distance = selected.distance;
          lines[0].distance = selected.distance;
          fundedScanOverBareLaunch = { sectorId:selected.edge.resourcePlan.goal.nebulaId,
            launchProjectedScore:p.finalScore, scanProjectedScore:selected.score };
        }
      }
    }

    // A shorter public sector is a useful tie-break, only after both
    // exact current-turn plans close with the same order and the same value.
    let publicBluePairChoice=null;
    if(complete&&!unresolved.length&&realizationTies&&root.observation?.publicState?.roundNumber===3){
      const entry=nodes[0],best=entry.best;
      const trace=edge=>{
        const goal=edge?.resourcePlan?.goal,execution=resourceExecutions.get(edge);
        if(!goal?.publicBluePair||!execution||edge.goalStatus!=='completed'||edge.fallbackReason)return null;
        const actions=execution.prefixes.map(p=>p.action);
        const pair=actions.filter(a=>a.target?.choiceId?.startsWith('public:')&&a.target?.nebulaId);
        if(pair.length!==2||pair.some((a,i)=>a.target.cardInstanceId!==goal.publicBluePair[i]||a.target.nebulaId!==goal.nebulaId))return null;
        return {goal,other:actions.filter(a=>!pair.includes(a)).map(a=>a.actionId)};
      };
      const chosen=trace(best);
      if(chosen){
        const previous=nodes[best.target];
        for(const e of entry.edges){
          const target=nodes[e.target],next=trace(e);
          if(!next||next.goal.publicBlueCapacity>=chosen.goal.publicBlueCapacity
            ||next.goal.publicBluePair.some((id,i)=>id!==chosen.goal.publicBluePair[i])
            ||JSON.stringify(next.other)!==JSON.stringify(chosen.other)
            ||target.value!==previous.value||target.realization!==previous.realization
            ||target.preparationDebt!==previous.preparationDebt||target.pickupRank!==previous.pickupRank
            ||target.landingCompanyRetained!==previous.landingCompanyRetained
            ||Boolean(target.publicDataCard)!==Boolean(previous.publicDataCard)
            ||(target.chongBlindCount??0)!==(previous.chongBlindCount??0)
            ||target.distance+e.cost!==entry.distance)continue;
          entry.best=e;
          publicBluePairChoice={from:chosen.goal.nebulaId,to:next.goal.nebulaId,cards:next.goal.publicBluePair,
            oldOpenSlots:chosen.goal.publicBlueCapacity,newOpenSlots:next.goal.publicBlueCapacity};
          break;
        }
      }
    }
    // A proved swap can realize permanent electricity at the same V and
    // immediate wallet as the shorter blue-slot line.
    if(complete&&!unresolved.length&&realizationTies&&nodes[0].pickPolicy?.companySwap?.reason==='compare-funded-fourth-slot-energy'){
      const entry=nodes[0],best=entry.best,swap=entry.pickPolicy.companySwap;
      const action=root.legalActions.find(a=>a.family==='industry'&&a.target?.abilityId==='deepspace_swap_cards');
      const company=entry.edges.find(edge=>edge.actionId===action?.actionId);
      const leaf=edge=>{
        let next=nodes[edge.target];
        while(next.best&&nodes[next.best.target].distance<next.distance)next=nodes[next.best.target];
        return next.node.status==='turn-boundary'?next.node:null;
      };
      if(company&&best?.resourcePlan?.goal.kind==='blue-data'){
        const a=nodes[best.target],b=nodes[company.target];
        const blueEnd=leaf(best),incomeEnd=leaf(company);
        if(blueEnd&&incomeEnd&&a.value===b.value&&a.realization===b.realization
          &&a.preparationDebt===b.preparationDebt&&a.pickupRank===b.pickupRank
          &&a.landingCompanyRetained===b.landingCompanyRetained
          &&Boolean(a.publicDataCard)===Boolean(b.publicDataCard)&&a.chongBlindCount===b.chongBlindCount
          &&port.tiedKnownEnergySwap?.(root,blueEnd,incomeEnd,swap)){
          entry.best=company;
          entry.distance=b.distance+company.cost;
        }
      }
    }
    let scanBeforeOrbit=null, retainRegionCard=null, retainedRegionPrefix=null, continuationNativeInputs=0;
    let visibleFossilTransport=null;
    if(complete&&!stopReason&&!unresolved.length&&resourcePlanning&&realizationTies&&scanOrbitBudget
      &&stateValue?.isDefaultStateValueEvaluator?.(evaluate)&&root.status==="decision"){
      const source=port.visibleFossilTransportSource?.();
      const current=source&&roots.find(r=>r.actionId===source.action.actionId&&r.completion==="complete");
      if(current&&current.actionId!==nodes[0].best?.actionId){
        const deadline=Math.min(startedAt+limits.milliseconds,scanOrbitBudget.deadline);
        const admit=(inputs,total)=>now()<deadline-15&&total<scanOrbitBudget.nativeInputs
          &&transitions+inputs<limits.transitions&&nodes.length+inputs<limits.nodes;
        const before=port.getDiagnostics().submissionCount;
        if(admit(0,before)){
          const proof=port.quoteVisibleFossilTransport(source,evaluate,admit);
          continuationNativeInputs=port.getDiagnostics().submissionCount-before;
          transitions+=continuationNativeInputs;
          if(proof?.value>nodes[0].value&&now()<deadline){
            visibleFossilTransport={...proof,nativeInputs:continuationNativeInputs,currentValue:current.value,
              previousValue:nodes[0].value,previousActionId:nodes[0].best.actionId};
            roots[roots.indexOf(current)]={...current,value:proof.value,completion:"proved-native-continuation",
              valueType:"attained-lower-bound",proof:"visible-fossil-transport"};
          }
          if(now()>=deadline)stopReason="watchdog";
        }
      }
    }
    const visibleBest=nodes[0].best;
    const orbitGoal=visibleBest?.resourcePlan?.goal;
    if(complete&&!unresolved.length&&retainedRegionSource&&visibleBest
      &&(retainedRegionSource.cash?planReuse&&visibleBest.actionId!==retainedRegionSource.firstId:
        retainedRegionSource.cornerId===visibleBest.actionId
        &&roots.some(r=>r.actionId===retainedRegionSource.firstId&&r.completion==="complete"))){
      const deadline=Math.min(startedAt+limits.milliseconds,scanOrbitBudget.deadline);
      const maySubmit=(inputs,total)=>now()<deadline-15&&total<scanOrbitBudget.nativeInputs&&transitions+inputs<limits.transitions
        &&(!retainedRegionSource.cash||nodes.length+inputs<limits.nodes);
      const before=port.getDiagnostics().submissionCount;
      if(maySubmit(0,before)){
        const proof=port.quoteRetainedRegionCard(retainedRegionSource,evaluate,maySubmit);
        continuationNativeInputs=port.getDiagnostics().submissionCount-before;
        transitions+=continuationNativeInputs;
        if(proof?.value>nodes[0].value&&now()<deadline){
          const {prefix,...quote}=proof;
          retainRegionCard={...quote,actionId:retainedRegionSource.firstId,
            visibleActionId:visibleBest.actionId,visibleValue:nodes[0].value,nativeInputs:continuationNativeInputs};
          retainedRegionPrefix=prefix;
          if(prefix){
            const i=roots.findIndex(r=>r.actionId===retainRegionCard.actionId);
            roots[i]={actionId:retainRegionCard.actionId,value:quote.value,completion:"proved-native-continuation",
              valueType:"attained-lower-bound",proof:regionCashGoal};
          }
        }
        if(now()>=deadline)stopReason="watchdog";
      }
    }
    if(complete&&!unresolved.length&&realizationTies&&scanOrbitBudget&&orbitGoal?.family==="orbit"
      &&root.status==="stable"&&root.observation.publicState.roundNumber===4&&port.quoteScanBeforeOrbit){
      const scanAction=root.legalActions.find(a=>a.family==="scan");
      const scanRoot=scanAction&&roots.find(r=>r.actionId===scanAction.actionId);
      const scanEdges=scanRoot?.completion==="complete"?nodes[0].edges.filter(e=>e.actionId===scanAction.actionId
        &&e.target===scanRoot.target&&e.goalStatus==="completed"&&e.resourcePlan?.goal.kind==="scan-flow"):[];
      const scanEdge=scanEdges.length===1?scanEdges[0]:null;
      const quietTail=edge=>{
        let index=edge.target;
        for(let i=0;i<16;i++){
          const entry=nodes[index],next=entry.best;
          if(BOUNDARIES.has(entry.node.status)){
            const tail=entry.node.planSummary;
            return entry.node.status==="turn-tail-value"&&tail.kind==="end-turn"&&tail.netGain===0&&tail.markedTiles.length===0
              ?entry.node:null;
          }
          if(!next||nodes[next.target].distance>=entry.distance)return null;
          index=next.target;
        }
        return null;
      };
      if(scanEdge&&visibleBest.goalStatus==="completed"){
        const scanTail=quietTail(scanEdge),orbitTail=quietTail(visibleBest);
        const deadline=Math.min(startedAt+limits.milliseconds,scanOrbitBudget.deadline);
        const maySubmit=(inputs,total)=>now()<deadline-15&&total<scanOrbitBudget.nativeInputs&&transitions+inputs<limits.transitions;
        if(scanTail&&orbitTail){
          const before=port.getDiagnostics().submissionCount;
          if(maySubmit(0,before)){
            const proof=port.quoteScanBeforeOrbit(scanTail,orbitTail,orbitGoal,maySubmit);
            continuationNativeInputs=port.getDiagnostics().submissionCount-before;
            transitions+=continuationNativeInputs;
            if(proof?.score>nodes[0].value&&now()<deadline){
              scanBeforeOrbit={...proof,actionId:scanAction.actionId,visibleActionId:visibleBest.actionId,
                visibleValue:nodes[0].value,currentTurnValue:scanRoot.value,nativeInputs:continuationNativeInputs};
            }
            if(now()>=deadline)stopReason="watchdog";
          }
        }
      }
    }
    // PASS gives up every remaining turn of this round. In round two,
    // compare that opportunity only after the current-turn search closes.
    // This is a policy preference, not a bound on future scan rewards.
    let scanBeforePass=null;
    const passAction=root.legalActions.find(a=>a.actionId===nodes[0].best?.actionId&&a.family==="pass");
    if(complete&&!stopReason&&!unresolved.length&&realizationTies&&resourcePlanning&&scanPlanning&&root.status==="stable"&&passAction){
      const state=root.observation.publicState,seat=passAction.actorId,player=state.players.find(p=>p.playerId===seat);
      if(state.roundNumber===2&&state.currentPlayerId===seat&&state.activePlayerIds.length===4
        &&state.activePlayerIds.every(id=>id===seat||state.passedPlayerIds.includes(id))
        &&!player?.mainActionCompleted&&player?.handCount>=2&&player.additionalPublicScan>=1){
        const main=new Set(root.legalActions.filter(a=>a.phase==="main"&&a.family!=="pass").map(a=>a.actionId));
        const bestMain=roots.reduce((v,r)=>main.has(r.actionId)&&Number.isFinite(r.value)?Math.max(v,r.value):v,-Infinity);
        const scan=root.legalActions.find(a=>a.family==="scan"&&main.has(a.actionId));
        const quote=roots.find(r=>r.actionId===scan?.actionId),cost=quote?.goal?.required;
        const loss=nodes[0].value-quote?.value,maxOpportunityCost=2;
        if(quote?.completion==="complete"&&quote.goal?.kind==="scan-flow"&&quote.goal.nebulaId&&quote.value===bestMain
          &&Number.isSafeInteger(cost?.credits)&&Number.isSafeInteger(cost?.energy)&&cost.credits>=0&&cost.energy>=0
          &&player.credits>=cost.credits+1&&player.energy>=cost.energy+1
          &&loss>=0&&loss<=maxOpportunityCost){
          scanBeforePass={policy:"round-two-uncontested-scan-opportunity-v1",actionId:scan.actionId,passActionId:passAction.actionId,
            passValue:nodes[0].value,scanValue:quote.value,loss,maxOpportunityCost,sectorId:quote.goal.nebulaId,
            realization:quote.realization,preparationDebt:quote.preparationDebt};
        }
      }
    }
    const evidence = complete && nodes[0].selection ? nodes[0].edges.map(edge => ({
      selectedIds: edge.selectedIds, value: nodes[edge.target].value, realization: nodes[edge.target].realization, preparationDebt:nodes[edge.target].preparationDebt,
      distance: nodes[edge.target].value == null ? null : nodes[edge.target].distance,
    })) : null;
    let accepted = complete && !stopReason && now() - startedAt < limits.milliseconds;
    let certificate = accepted && evidence && modelKey && nodes[0].best
      ? port.rememberSelection?.(root, evidence, modelKey) || null : null;
    let planCertificate = null;
    // The existing certificate starts with the visible winner. A proved
    // override must let the real scan menu build a fresh continuation.
    if (accepted && planReuse && nodes[0].best && !scanBeforeOrbit && !retainRegionCard && !scanBeforePass && !visibleFossilTransport) {
      const entries = [];
      let current = 0;
      while (entries.length < 32 && !BOUNDARIES.has(nodes[current].node.status)) {
        const entry = nodes[current], best = entry.best;
        if (!best) throw new Error("SEARCH_PLAN_WITNESS_MISSING");
        const roots = entry.node.legalActions.map(action => {
          const edge = entry.edges.find(edge => edge.actionId === action.actionId);
          const policyExclusion = edge?.resourcePlan?.goal.kind==="transport-data-prep"?null:
            entry.decisionPolicy?.excludedActionIds.includes(action.actionId)?entry.decisionPolicy.policy:entry.pickPolicy?.excludedActionIds.includes(action.actionId)?entry.pickPolicy.policy
            :entry.movementPolicy?.excludedActionIds.includes(action.actionId) ? entry.movementPolicy.policy : null;
          const exclusion = policyExclusion || (entry.localPlan?.excludedActionIds.includes(action.actionId) ? entry.localPlan.proof : entry.actionBounds?.find(bound=>bound.actionId===action.actionId)?.proof
            ||entry.blueClaimEquivalences?.find(bound=>bound.actionId===action.actionId)?.proof||null);
          return { actionId: action.actionId, value: exclusion ? null : edge ? nodes[edge.target].value : null,
            valueType: exclusion ? "not-executed" : "attained-lower-bound", completion: "covered-by-prior-complete-window",
            sourceNode: current, ...(exclusion ? policyExclusion ? { policy: exclusion, isEquivalence: false } : { proof: exclusion } : {}),
            ...(entry.selection ? { proof: entry.selection.proof, equivalentExitSet: !action.target?.confirm } : {}) };
        });
        entries.push({ node: entry.node, actionId: best.actionId, value: entry.value, realization: entry.realization, preparationDebt:entry.preparationDebt, distance: entry.distance, sourceNode: current, roots });
        if(best.knownIncomePlan&&port.hasMovementIntent?.(entry.node)){
          const plan=entry.resourcePolicy.plans.find(p=>p.goal.id===best.knownIncomePlan.goal.id);
          if(!plan)throw new Error("SEARCH_WINNING_INCOME_PLAN_MISSING");
          const fixed=port.expandResourcePlan(entry.node,plan,(count,contexts,input,work)=>{
            if(now()-startedAt>=limits.milliseconds)return "watchdog";
            const inputs=work?work.newSubmissions+(input?work.nextNewInput:0):count+(input?1:0);
            // Intermediate identity counts only answer finite node/frontier
            // gates. The completed macro still records exact identities.
            if(limits.nodes===Infinity&&limits.frontier===Infinity)return transitions+inputs>limits.transitions?"transition-budget":null;
            const fresh=work?resourceStateAdditions([...work.sharedStates,...(work.nextNode?[work.nextNode]:[])]).size+(work.additionalStates||0):count+contexts+(input?1:0);
            if(transitions+inputs>limits.transitions)return "transition-budget";
            if(nodes.length+certificateNodes+fresh>limits.nodes)return "node-budget";
            if(pendingFrontier+Math.max(0,fresh-1)>limits.frontier)return "frontier-budget";
            return null;
          });
          const newInputs=fixed.newSubmissions??fixed.submissions,fresh=resourceStateAdditions(fixed.sharedStates);
          transitions+=newInputs;winningIncomeInputs+=newInputs;logicalResourceInputs+=fixed.submissions;sharedResourceInputHits+=fixed.submissions-newInputs;
          for(const id of fresh)sharedInternalStates.add(id);certificateNodes+=fresh.size;
          peakFrontier=Math.max(peakFrontier,pendingFrontier+Math.max(0,fresh.size-1));
          if(!fixed.complete){
            stopReason=fixed.stopReason;accepted=false;
            const attempt={goal:plan.goal,submissions:fixed.submissions,preparations:fixed.preparations,stopReason};
            unresolved.push({node:current,actionIds:[best.actionId],winningPlanAttempt:attempt});lines[current].winningPlanAttempt=attempt;
            break;
          }
          if(fixed.submissions!==best.knownIncomePlan.requiredNativeInputs||!BOUNDARIES.has(fixed.node.status)
            ||valueForNode(fixed.node)!==entry.value)throw new Error("SEARCH_WINNING_INCOME_WITNESS_MISMATCH");
          winningIncomePlans++;
          best.actualNativeInputs=newInputs;best.materializedWinningPlan={goalId:plan.goal.id,steps:fixed.prefixes.map(p=>p.action.actionId),value:entry.value,status:fixed.node.status};
          entries.at(-1).committedGoal=plan.goal.id;
          for(let i=1;i<fixed.prefixes.length&&entries.length<32;i++){
            const prefix=fixed.prefixes[i];
            entries.push({node:prefix.node,actionId:prefix.action.actionId,value:entry.value,realization:entry.realization,preparationDebt:entry.preparationDebt,distance:entry.distance-i,
              sourceNode:`winning-income:${current}:${i}`,committedGoal:plan.goal.id,roots:prefix.node.legalActions.map(action=>({actionId:action.actionId,
                value:action.actionId===prefix.action.actionId?entry.value:null,valueType:action.actionId===prefix.action.actionId?"attained-lower-bound":"not-executed",
                completion:"committed-goal-plan-execution",policy:"seti-goal-resource-preparation-v3",goalId:plan.goal.id,isEquivalence:false}))});
          }
          current=best.target;continue;
        }
        if(best.knownIncomePlan||best.turnTailPlanValue){current=best.target;continue;}
        if(best.resourcePlan){
          const macro=resourceExecutions.get(best);
          const committedGoal=["held-landing-route","cargo-research-corner"].includes(best.resourcePlan.goal.kind)?best.resourcePlan.goal.id:null;
          if(committedGoal)entries.at(-1).committedGoal=committedGoal;
          for(let i=1;i<macro.prefixes.length&&entries.length<32;i++){
            const prefix=macro.prefixes[i];
            entries.push({node:prefix.node,actionId:prefix.action.actionId,value:entry.value,realization:entry.realization,preparationDebt:entry.preparationDebt,distance:entry.distance-i,
              sourceNode:`resource:${current}:${i}`,...(committedGoal?{committedGoal}:{}),roots:prefix.node.legalActions.map(action=>({actionId:action.actionId,
                value:action.actionId===prefix.action.actionId?entry.value:null,valueType:action.actionId===prefix.action.actionId?"attained-lower-bound":"not-executed",
                completion:"committed-goal-plan-execution",policy:"seti-goal-resource-preparation-v1",goalId:best.resourcePlan.goal.id,isEquivalence:false}))});
          }
          current=best.target;continue;
        }
        if(entry.fixedCardExecutions?.has(best.actionId)){
          const fixed=entry.fixedCardExecutions.get(best.actionId);
          for(let i=1;i<fixed.prefixes.length&&entries.length<32;i++){
            const prefix=fixed.prefixes[i],policy=fixed.fixedChoices.find(choice=>choice.prefix===i)?.policy||"seti-purpose-card-pick-policy-v1";entries.push({node:prefix.node,actionId:prefix.action.actionId,value:entry.value,realization:entry.realization,preparationDebt:entry.preparationDebt,distance:entry.distance-i,
              sourceNode:`fixed-card:${current}:${i}`,roots:prefix.node.legalActions.map(action=>({actionId:action.actionId,
                value:action.actionId===prefix.action.actionId?entry.value:null,valueType:action.actionId===prefix.action.actionId?"attained-lower-bound":"not-executed",
                completion:"fixed-plan-execution",policy,isEquivalence:false}))});
          }
          current=best.target;continue;
        }
        if (best.goalPlan) {
          const macro = entry.goalExecutions.get(best.actionId);
          for (let i=1;i<macro.prefixes.length && entries.length<32;i+=1) {
            const prefix=macro.prefixes[i];
            entries.push({node:prefix.node,actionId:prefix.action.actionId,value:entry.value,realization:entry.realization,preparationDebt:entry.preparationDebt,distance:entry.distance-i,
              sourceNode:`goal:${current}:${i}`,roots:prefix.node.legalActions.map(action=>({actionId:action.actionId,
                value:action.actionId===prefix.action.actionId?entry.value:null,valueType:action.actionId===prefix.action.actionId?"attained-lower-bound":"not-executed",
                completion:"committed-goal-plan-execution",policy:"seti-goal-movement-policy-v1",isEquivalence:false}))});
          }
          current=best.target; continue;
        }
        if (best.optimalPlan) {
          if(resourcePlanning)break;
          const macro = entry.optimalAttainment;
          for (let i=1; i<macro.prefixes.length && entries.length<32; i+=1) {
            const prefix = macro.prefixes[i];
            entries.push({ node: prefix.node, actionId: prefix.action.actionId, value: entry.value, realization: entry.realization, preparationDebt:entry.preparationDebt, distance: prefix.distance,
              sourceNode: `attainment:${current}:${i}`, roots: prefix.node.legalActions.map(action => ({
                actionId: action.actionId, value: action.actionId === prefix.action.actionId ? entry.value : null,
                valueType: action.actionId === prefix.action.actionId ? "attained-lower-bound" : "not-executed",
                completion: "covered-by-attained-value-shortest-plan", proof: macro.proof, sourceNode: current, sourcePrefix: i })) });
          }
          break;
        }
        if (best.cost !== 1) break;
        current = best.target;
      }
      planCertificate = accepted ? port.rememberPlan(entries, planKey, { searchVersion: VERSION, rootNode: 0,
        nodeCount: nodes.length+certificateNodes, graphNodeCount: nodes.length, certificateNodeCount: certificateNodes, boundaryWitness: retainedWitness(0), rootValue: nodes[0].value }) : null;
    }
    if(accepted&&retainedRegionPrefix){
      const value=retainRegionCard.value,entries=retainedRegionPrefix.map(({node,action},i)=>({
        node,actionId:action.actionId,value,distance:retainedRegionPrefix.length-i,sourceNode:`retained-region:${i}`,committedGoal:regionCashGoal,
        roots:node.legalActions.map(a=>({actionId:a.actionId,value:a.actionId===action.actionId?value:null,
          valueType:a.actionId===action.actionId?"attained-lower-bound":"not-executed",
          completion:"committed-goal-plan-execution",goalId:regionCashGoal,isEquivalence:false})),
      }));
      certificateNodes+=entries.length-1;
      planCertificate=port.rememberPlan(entries,planKey,{searchVersion:VERSION,rootNode:0,
        nodeCount:nodes.length+certificateNodes,graphNodeCount:nodes.length,certificateNodeCount:certificateNodes,rootValue:value,proof:regionCashGoal});
      if(now()>=scanOrbitBudget.deadline){stopReason="watchdog";accepted=false;}
    }
    const elapsed = now() - startedAt;
    accepted = accepted && elapsed < limits.milliseconds;
    if (!accepted) certificate = null;
    return {
      schemaVersion: VERSION, complete: accepted,
      actionId: accepted ? visibleFossilTransport?.actionId || retainRegionCard?.actionId || scanBeforeOrbit?.actionId || scanBeforePass?.actionId || nodes[0].best?.actionId || null : null,
      selectionPlan: accepted && nodes[0].best?.selectedIds ? {
        selectedIds: nodes[0].best.selectedIds, cardIds: nodes[0].selection.cardIds,
        proof: nodes[0].selection.proof, complete: true,
      } : null,
      selectionContinuation: certificate,
      planContinuation: accepted ? planCertificate?.token || null : null,
      planEvidence: accepted && planCertificate ? { evidenceId: planCertificate.evidenceId,
        proof: "seti-complete-window-best-prefix-reuse-v1", nodeCount: nodes.length+certificateNodes } : null,
      value: accepted ? retainedRegionPrefix ? retainRegionCard.value : visibleFossilTransport?.value ?? scanBeforePass?.scanValue ?? nodes[0].value : null,
      ...(accepted&&scanBeforeOrbit?{scanBeforeOrbit}:{}),
      ...(accepted&&visibleFossilTransport?{visibleFossilTransport}:{}),
      ...(accepted&&retainRegionCard?{retainRegionCard}:{}),
      ...(accepted&&scanBeforePass?{scanBeforePass}:{}),
      ...(accepted&&fundedScanOverBareLaunch?{fundedScanOverBareLaunch}:{}),
      ...(accepted&&publicBluePairChoice?{publicBluePairChoice}:{}),
      realization: accepted ? scanBeforePass ? scanBeforePass.realization : nodes[0].realization ?? null : null,
      preparationDebt:accepted?scanBeforePass ? scanBeforePass.preparationDebt : nodes[0].preparationDebt??null:null,
      stopReason: stopReason || (!accepted ? "watchdog" : nodes[0].value == null ? "no-reachable-boundary" : null),
      scope,
      roots, lines, unresolved,
      ...(resourcePlanning?{sharedPrefixGraph:port.getResourcePrefixGraph?.()||null}:{}),
      candidates: Array.from(nodes[0].alternatives, a => a.resourcePlan?{kind:"resource-goal-plan",plan:a.resourcePlan,firstActionId:a.firstActionId}:a.goalPlan ? {kind:"goal-plan",plan:a.goalPlan,firstActionId:a.firstActionId}
        : a.cardPickPlan?{kind:a.cardPickPlan.kind,plan:a.cardPickPlan,firstActionId:a.firstActionId}:{kind:"action",actionId:a.firstActionId}),
      diagnostics: { realizationTies:realizationTies?"funded-preparation-debt-and-latest-native-purpose-capital":"off", valueEvaluations,valueCacheHits, finalMarkPlanning:finalMarkPlanning,scanPlanning:scanPlanning, resourcePlanning:resourcePlanning?"goal-bound-greedy-preparation":"off", cardPickPlanning:cardPickPlanning?"purpose-bound-fixed-plan":"off", movementPlanning: movementPlanning ? "goal-directed-policy" : "off", movementPolicyNodes, movementDirectionsExcluded, routeGeometryNodes,
        incomePlanProofs,provedIncomeInputs,turnTailProofs,provedTurnTailInputs,movementValuePrunes,dataPrimaryBoundPrunes,
        winningIncomePlans,winningIncomeInputs,deferredMovementPlans:nodes.filter(e=>e.movementDeferred).length,
        nativeExecutions:port.getDiagnostics?.().submissionCount??null,
        ...(continuationNativeInputs?{continuationNativeInputs}:{}),logicalResourceInputs,sharedResourceInputHits,sharedResourceInternalStates:sharedInternalStates.size,
        localFinalMarkStates:nodes.filter(e=>e.decisionPolicy?.kind==="fixed-final-mark").length,
        localFinalMarkExcluded:nodes.reduce((n,e)=>n+(e.decisionPolicy?.kind==="fixed-final-mark"?e.decisionPolicy.excludedActionIds.length:0),0),
        fixedDataChoiceStates:nodes.filter(e=>e.decisionPolicy?.kind==="fixed-data-choice").length,
        fixedDataChoicesExcluded:nodes.reduce((n,e)=>n+(e.decisionPolicy?.kind==="fixed-data-choice"?e.decisionPolicy.excludedActionIds.length:0),0),
        branchingStates:nodes.filter(e=>!BOUNDARIES.has(e.node.status)&&e.alternativeCount>1).length,
        singleAlternativeStates:nodes.filter(e=>!BOUNDARIES.has(e.node.status)&&e.alternativeCount===1).length,
        disabledBorrowStarts:nodes.reduce((n,e)=>n+e.node.legalActions.filter(a=>resourcePlanning&&a.family==="industry"&&a.target?.abilityId==="turing_borrow_tech").length,0),
        disabledRemoveTechIncomeStarts:nodes.reduce((n,e)=>n+e.node.legalActions.filter(a=>resourcePlanning&&a.family==="industry"&&a.target?.abilityId==="helios_remove_tech_income").length,0),
        scanPurposePlans:nodes.reduce((n,e)=>n+e.edges.filter(x=>x.resourcePlan?.goal.kind==="scan-flow").length,0),
        resourceGoalPlans:nodes.reduce((n,e)=>n+e.edges.filter(x=>x.resourcePlan).length,0),
        resourcePreparationInputs:nodes.reduce((n,e)=>n+e.edges.filter(x=>x.resourcePlan).reduce((v,x)=>v+x.cost,0),0),
        resourceFallbacks:nodes.reduce((n,e)=>n+e.edges.filter(x=>x.fallbackReason).length,0),
        resourceExcludedActions:nodes.reduce((n,e)=>n+(e.resourcePolicy?.excludedActionIds.length||0),0),
        transitions, nodes: nodes.length+certificateNodes, graphNodes: nodes.length, certificateNodes,
        postMainOptimalPlans, postMainOptimalPlanSteps, equivalents, selectionMacros, peakFrontier,
        dominancePrunes, resourceDominance: useResourceDominance ? "enabled"
          : resourceDominance ? movementPlanning ? "disabled-for-movement-policy" : "disabled-for-selection-certificate" : "off",
        moneyCapacityPrunes, moneyCapacityDominance: useMoneyCapacity ? "enabled"
          : moneyCapacityDominance ? movementPlanning ? "disabled-for-movement-policy" : "disabled-for-selection-certificate" : "off",
        postMainValuePrunes, scanValuePrunes, scanActionPrunes,
        cardTradePrunes, cardTradePruning: useCardTradePruning ? "enabled"
          : cardTradePruning ? "disabled-for-selection-certificate" : "off",
        postMainProofNodes, postMainExcludedActions, postMainPruning: postMainPruning ? "enabled" : "off",
        openingProofNodes, openingExcludedActions, openingPruning: openingPruning ? "enabled" : "off",
        openingPassMacros, postMainBorrowProofNodes, postMainBorrowExcludedChoices, postMainBorrowMacros,
        cardChoiceProofNodes, cardChoiceExcludedActions, cardCornerProofNodes, cardCornerExcludedActions,
        preMainDataProofNodes, preMainDataExcludedActions,
        cardChoiceEquivalence: cardChoiceEquivalence ? "enabled" : "off",
        ...(useResourceDominance || useMoneyCapacity || useCardTradePruning || postMainPruning || openingPruning || cardChoiceEquivalence
          ? { resourceModelKey: evaluate.modelKey } : {}),
        continuation: reused ? (reused.hit ? "validation-watchdog" : reused.reason) : "not-requested",
        planContinuation: reusedPlan ? (reusedPlan.hit ? "validation-watchdog" : reusedPlan.reason) : planReuse ? "not-requested" : "off",
        milliseconds: elapsed, limits: configuredLimits },
    };
  }

  return Object.freeze({ VERSION, DEFAULT_BUDGET, searchDecision });
});
