'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),{open,short,writeZ}=require('./controlled-r3'),read=f=>JSON.parse(fs.readFileSync(f)),seat='player-white';
const baseline=read('reports/iteration/free-analyze-random20-funded-planet-20261111/summary-463fc442-20261111.json');
const rows=[];
for(const row of baseline.rows){
 const rec=read('reports/research/'+row.f),cut=rec.roundEnds[2],cp=read(cut.checkpointPath),save=read(rec.savePath);
 const m=open(cp.coreState.compositionEnvelope),offers=[];
 try{
  for(let i=cp.replayCursor.stepIndex;i<save.replaySteps.length;i++){
   const a=save.replaySteps[i].action;
   if(a.actorId===seat&&a.family==='choose_target'&&a.target?.choiceId?.startsWith('scan4:')){
    const legal=m.menu(),launch=legal.find(a=>a.target?.choiceId==='scan4:launch'),skip=legal.find(a=>a.target?.choiceId==='scan4:skip'),f=m.facts();
    if(launch&&skip&&f.round===4&&!f.probes.length){
     const u=m.automatic(),choices=u.roots.filter(r=>[launch.actionId,skip.actionId].includes(r.actionId));
     offers.push({input:i+1,root:m.save(),actual:a,assets:short(m),choices,chosen:u.a,n:u.n,ms:u.ms,complete:u.complete,
       exactShape:f.wallet.availableData===3&&f.computer.length===4&&f.blue.length===0&&f.tech.ownedTiles.blue2&&f.tech.ownedTiles.blue1});
    }
   }
   m.apply(a);
  }
  const end=m.save();
  if(row.board!==11)assert.deepEqual(JSON.parse(end.committedState),JSON.parse(save.committedState));
  rows.push({board:row.board,record:row.f,offers});
 }finally{m.dispose();}
}
console.log(JSON.stringify(rows.filter(r=>r.offers.length).map(r=>[r.board,r.offers.map(o=>[o.input,o.actual.summary,o.assets.wallet,o.exactShape,o.choices.map(c=>c.value)])])));writeZ(process.argv[2],{rows});
