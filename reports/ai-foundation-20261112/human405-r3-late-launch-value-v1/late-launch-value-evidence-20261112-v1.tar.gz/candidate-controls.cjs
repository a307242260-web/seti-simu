'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ}=require('./controlled-r3');
const [cohort,dark,out]=process.argv.slice(2),rows=[];
for(const r of readZ(cohort).rows)for(const o of r.offers){
 const m=open(o.root);
 try{
  const u=m.automatic();assert(u.complete&&u.n<=256&&u.ms<=600);
  assert.equal(u.a.actionId,o.chosen.actionId);assert.equal(u.n,o.n);
  assert.equal(JSON.stringify(u.roots.filter(r=>o.choices.some(x=>x.actionId===r.actionId))),JSON.stringify(o.choices));
  rows.push({board:r.board,input:o.input,n:u.n,ms:u.ms});
 }finally{m.dispose();}
}
const roots=[];
for(const r of readZ(dark).rows.filter(r=>r.mode==='launch')){
 const m=open(r.cut),accepted=[];
 try{
  const a=m.automatic();assert(a.complete&&a.n<=256&&a.ms<=600);
  assert.equal(a.a.target.choiceId,'scan4:launch');accepted.push(m.apply(a.a));
  const w=m.automatic(a.checkpoint),c=m.automatic();
  for(const u of [w,c])assert(u.complete&&u.n<=256&&u.ms<=600&&u.a.family==='place_data');
  assert.equal(c.a.actionId,w.a.actionId);
  roots.push({swap:r.swap,root:r.cut,atLaunch:[a.n,a.ms,a.value],cold:[c.n,c.ms,c.value],warm:[w.n,w.ms,w.value],accepted});
 }finally{m.dispose();}
}
console.log(JSON.stringify({rows,roots:roots.map(r=>[r.swap,r.atLaunch,r.cold,r.warm])}));writeZ(out,{rows,roots});
