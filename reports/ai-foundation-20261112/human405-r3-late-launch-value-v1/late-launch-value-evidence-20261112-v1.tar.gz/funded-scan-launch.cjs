'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [o1file,o3file,out]=process.argv.slice(2),k=require(path.resolve('randomizer/game/production-kernel')),seat='player-white';
const o1=readZ(o1file),o3=readZ(o3file),seeds=[['early-scan-landing',o1.origin],['relaunch-direct-landing',o3.common.end],['scan-launch-landing',o3.common.end]],rows=[];
for(const [label,origin] of seeds.filter(([name])=>name==='scan-launch-landing'))for(const swap of [null,[0,4],[1,6]]){
 const early=label==='early-scan-landing',combo=label==='scan-launch-landing',s=JSON.parse(origin.committedState),deck=s.cards.drawPileCardIds;
 if(swap){assert(deck[swap[0]]&&deck[swap[1]]);[deck[swap[0]],deck[swap[1]]]=[deck[swap[1]],deck[swap[0]]];}
 const e=swap?{...origin,committedState:JSON.stringify(s)}:origin,m=open(e);
 try{
  const view=m.owner(seat),menu=m.menu(),rng=m.facts().rng,known=new Set(m.player().hand.map(c=>c.id));
  const baseline=rows.find(r=>r.label===label);
  if(baseline){assert.deepEqual(view,baseline.view);assert.deepEqual(menu,baseline.menu);assert.deepEqual(rng,baseline.rng);}
  const actions=[],take=a=>(actions.push(a),a),pay=()=>{if(m.menu()[0].actorId!==seat)m.advanceOpponents(actions);};
  const endTurn=()=>{take(m.act('end_turn'));pay();};
  take(m.act('pass'));pay();take(m.act('choose_card',a=>a.target.kind==='pass-reserve-card'&&a.target.cardId==='b_111.webp'));pay();
  const r4=short(m);
  const route=()=>k.getProbeRouteRequirements(m.state(),seat).candidates.find(r=>r.planetId==='saturn'&&r.endpointFamily==='land'&&r.endpointTarget.type==='planet');
  if(early){
   const p=route(),dir=p.path[0],b16=m.player().hand.find(c=>c.cardId==='b_16.webp');assert(known.has(b16.id));
   take(m.play('b_16.webp'));
   take(m.act('choose_target',a=>a.target.rocketId===p.rocketId&&a.target.deltaX===dir.deltaX&&a.target.deltaY===dir.deltaY));
   take(m.act('choose_target',a=>a.target.nebulaId==='sector-2-a'));
  }else if(combo){
   const prior=m.state().cards.publicCards.map(c=>c.id);
   take(m.act('scan'));
   take(m.act('choose_target',a=>a.target.nebulaId==='sector-2-b'));
   take(m.act('choose_card',a=>a.summary==='dlc_20.png → 巴纳德'&&prior.includes(a.target.cardInstanceId)));
   take(m.act('choose_card',a=>a.summary==='dlc_15.png → 天狼星A'&&prior.includes(a.target.cardInstanceId)));
   take(m.act('choose_target',a=>a.target.choiceId==='scan4:launch'));
   if(m.c.inspect().session)throw Error('unexpected optional follow-up');
   for(const slot of ['blue2','computer','blue1']){
    take(m.act('place_data'));
    take(m.act('choose_target',a=>a.target.target===slot||slot==='blue2'&&a.target.blueSlot===1||slot==='blue1'&&a.target.blueSlot===3));
   }
  }else take(m.act('launch'));
  const afterFirst=short(m);
  endTurn();const tail=route();
  if(combo)take(m.act('quick_trade',a=>a.target.tradeId==='credits-for-energy'));
  for(const d of tail.path){
   take(m.act('move',a=>a.target.rocketId===tail.rocketId&&a.target.deltaX===d.deltaX&&a.target.deltaY===d.deltaY));
   take(m.act('choose_payment',a=>a.target.choiceId==='energy'));
  }
  take(m.act('land'));
  assert(m.state().planets.planets.saturn.landingMarkers.some(x=>x.playerId===seat));
  const after=short(m),end=m.save();m.restore(e);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  rows.push({label,swap,root:e,view,menu,rng,r4,afterFirst,after,tail:tail.required,actions,end,main:2});
  console.log(JSON.stringify([label,swap,r4.wallet,after.wallet,tail.required,after.hand]));
 }finally{m.dispose();}
}
writeZ(out,{rows});
