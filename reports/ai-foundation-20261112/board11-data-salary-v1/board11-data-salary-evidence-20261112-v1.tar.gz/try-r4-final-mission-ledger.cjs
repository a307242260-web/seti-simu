'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
const [from,out,mode]=process.argv.slice(2);
const science=path.resolve('randomizer/game/effects/science-session.js'),moduleScience=new Module(science,module);
moduleScience.filename=science;moduleScience.paths=Module._nodeModulePaths(path.dirname(science));
let rawScience=fs.readFileSync(science,'utf8');
const speciesKey='|| !["阿米巴", "虫"].includes(slot.alienId)) return false;';
assert.equal(rawScience.split(speciesKey).length,2);
rawScience=rawScience.replace(speciesKey,'|| !["阿米巴", "虫", "奥陌陌"].includes(slot.alienId)) return false;');
moduleScience._compile(rawScience,science);moduleScience.loaded=true;require.cache[science]=moduleScience;
const residual=path.resolve('randomizer/game/effects/residual-domain-session.js'),moduleRes=new Module(residual,module);
moduleRes.filename=residual;moduleRes.paths=Module._nodeModulePaths(path.dirname(residual));
let rawRes=fs.readFileSync(residual,'utf8');
const traceKey='const owner=actor(source,head?.ownerId),traceType=paired?selected.target.traceType:"pink";';
assert.equal(rawRes.split(traceKey).length,2);
rawRes=rawRes.replace(traceKey,'const owner=actor(source,head?.ownerId),traceType=paired?selected.target.traceType:session.journal.actions[0]?.action?.family==="analyze"?"blue":"pink";')
 .replace('if(session.queue.length!==1||session.journal.actions[0]?.action?.family!=="land")return null;',
  'if(session.queue.length!==1||!["land","analyze"].includes(session.journal.actions[0]?.action?.family))return null;');
const completed='||turn.currentPlayerId!==head.ownerId||!owner?.mainActionCompleted||owner.passCompletionPending';
const onlyPlain=rawRes.indexOf('  function previewPlainPinkTrace(');
const next=rawRes.indexOf('  function previewLastPlainPinkTrace(',onlyPlain);
assert(rawRes.slice(onlyPlain,next).includes(completed));
rawRes=rawRes.slice(0,onlyPlain)+rawRes.slice(onlyPlain,next).replace(completed,
 '||turn.currentPlayerId!==head.ownerId||!owner||!owner.mainActionCompleted&&session.journal.actions[0]?.action?.family!=="analyze"||owner.passCompletionPending')+rawRes.slice(next);
rawRes=rawRes.replace('head.payload?.traceType!==(paired?null:"pink")','head.payload?.traceType!==(paired?null:traceType)');
const bonusTest=`turn.roundNumber===4&&turn.cardTurnEventBonuses.every(b=>b.id==="aomomo9-aomomo-signal-score"
        &&b.eventType==="signalMarked"&&b.duration==="flow"&&b.ownerId===ownerId
        &&b.rewards?.length===1&&b.rewards[0].type==="gain_resources"
        &&Object.keys(b.rewards[0].options?.gain||{}).length===1&&b.rewards[0].options.gain.score===2)`;
const endBlock='      || turn.cardTurnEventBonuses?.length\n      || (stationaryCargo';
assert.equal(rawRes.split(endBlock).length,2);
rawRes=rawRes.replace(endBlock,'      || turn.cardTurnEventBonuses?.length&&!('+bonusTest+')\n      || (stationaryCargo');
const tailBonus=bonusTest.replaceAll('ownerId','ownerId').replace('b.ownerId===ownerId','b.ownerId===head.ownerId');
const traceBlock='||turn.passedPlayerIds.includes(owner.id)||turn.cardTurnEventBonuses?.length';
const traceStart=rawRes.indexOf('  function previewPlainPinkTrace('),traceEnd=rawRes.indexOf('  function previewLastPlainPinkTrace(',traceStart);
assert(rawRes.slice(traceStart,traceEnd).includes(traceBlock));
rawRes=rawRes.slice(0,traceStart)+rawRes.slice(traceStart,traceEnd).replace(traceBlock,traceBlock+'&&!('+tailBonus+')')+rawRes.slice(traceEnd);
const traceSource='session.journal.actions[0]?.action?.family!=="scan"';
const beforeRefill=rawRes.indexOf('  function previewPinkTraceBeforeRefill('),afterRefill=rawRes.indexOf('  function previewQuietAmibaYellowLanding(',beforeRefill);
assert(rawRes.slice(beforeRefill,afterRefill).includes(traceSource));
rawRes=rawRes.slice(0,beforeRefill)+rawRes.slice(beforeRefill,afterRefill).replace(traceSource,
 `(${traceSource}&&!(session.journal.actions[0]?.action?.family==="play_card"&&session.workingState.turn.cardTurnEventBonuses.length
    &&session.workingState.turn.cardTurnEventBonuses.every(b=>b.id==="aomomo9-aomomo-signal-score"&&b.eventType==="signalMarked")))`)+rawRes.slice(afterRefill);
rawRes=rawRes.replace('    const owner=actor(source,head?.ownerId),traceType=paired?',
 `    const b32=head?.payload?.cardEffect?.id==="b32-yellow-trace"
      &&head.payload.cardEffect.options?.targetRule==="playerHasSameTrace"
      &&head.payload.cardEffect.options?.allowedTraceTypes?.length===1
      &&head.payload.cardEffect.options.allowedTraceTypes[0]==="yellow"
      &&head.payload.cardEffect.options?.repeat===1&&Object.keys(head.payload.cardEffect.options).length===3;
    const owner=actor(source,head?.ownerId),traceType=b32?"yellow":paired?`)
 .replace('||head.payload?.traceType!==(paired?null:traceType)||Object.keys(head.payload).length!==(paired?2:1)',
 '||!b32&&(head.payload?.traceType!==(paired?null:traceType)||Object.keys(head.payload).length!==(paired?2:1))')
 .replace('!["land","analyze"].includes(session.journal.actions[0]?.action?.family)',
 '(!["land","analyze"].includes(session.journal.actions[0]?.action?.family)&&session.queue[0]?.payload?.cardEffect?.id!=="b32-yellow-trace")');
const copyAt='  function previewQuietEndHandoffs(';
const startCopy=rawRes.indexOf(copyAt),endCopy=rawRes.indexOf('  function listFinalMarkChoices(',startCopy);
const copyBefore='const state={...root,turn:{...turn},aliens:copyForkData(root.aliens),finalScoring:copyForkData(root.finalScoring),';
assert(rawRes.slice(startCopy,endCopy).includes(copyBefore));
rawRes=rawRes.slice(0,startCopy)+rawRes.slice(startCopy,endCopy).replace(copyBefore,`
    const sourceBoard=root.finalScoring;
    const reuse=turn.cardTurnEventBonuses?.length&&(${bonusTest})
      &&Array.isArray(sourceBoard.thresholds)&&["a","b","c","d"].every(id=>Array.isArray(sourceBoard.tiles?.[id]?.marks))
      &&sourceBoard.tileVariants;
    const board=reuse?{...sourceBoard,tiles:{...sourceBoard.tiles},tileVariants:{...sourceBoard.tileVariants}}:copyForkData(sourceBoard);
    const state={...root,turn:{...turn},aliens:reuse?root.aliens:copyForkData(root.aliens),finalScoring:board,`)+rawRes.slice(endCopy);
moduleRes._compile(rawRes,residual);moduleRes.loaded=true;require.cache[residual]=moduleRes;
const p=path.resolve('randomizer/game/ai/analysis-port.js'),m=new Module(p,module);
m.filename=p;m.paths=Module._nodeModulePaths(path.dirname(p));
let raw=fs.readFileSync(p,'utf8');
const mark='    function previewQuietAlienDisplay(node,stored,action){';
assert.equal(raw.split(mark).length,2);
raw=raw.replace(mark,`    function previewQuietAomomoCard(node,stored,action){
      const s=stored.envelope.session?.session,head=s?.queue[0],tail=s?.queue[1],source=action.target?.source;
      if(!resourcePlanning||!cardPickPlanning||node.status!=="decision"||action.family!=="choose_card"
        ||!["display","blind","cancel"].includes(source)||stored.informationBarrier&&stored.informationBarrier.code!=="hidden_card_reveal"
        ||s?.phase!=="awaiting_input"||s.failure||s.interruptContext||s.irreversibleBarrier&&s.irreversibleBarrier.code!=="hidden_card_reveal"||s.undoFrames.length
        ||head?.type!=="residual_alien_card_decision"||head.kind!=="decision"||head.ownerId!==seatId||head.allowQuickActions
        ||head.payload.speciesId!=="aomomo"||head.payload.source!=="trace_reward"||s.queue.length>2
        ||tail&&(tail.type!==scienceSession.EFFECT_TYPES.PUBLIC_REFILL||tail.kind!=="effect"||tail.ownerId!==seatId
          ||tail.allowQuickActions||Object.keys(tail.payload).length))return null;
      const state=s.workingState,t=state.turn,p=state.players.players.find(q=>q.id===seatId),deck=state.aliens.aomomo;
      if(t.roundNumber!==4||t.currentPlayerId!==seatId||t.gameEnded||!p.mainActionCompleted||p.passCompletionPending
        ||t.cardTurnEventBonuses?.length||t.passedPlayerIds.includes(seatId)||!knownRootAlienIds.has("奥陌陌")
        ||p.reservedCards.some(c=>!knownCards(stored.envelope).has(c.id))||localPlans.hasPendingFossilArrival(state)
        ||!deck?.revealInitialized)return null;
      const player={...p,resources:{...p.resources},hand:[...p.hand],reservedCards:structuredClone(p.reservedCards)};
      const next={...state,meta:{...quietSavedMeta(state.meta,s.baseVersion+1),sequences:{...state.meta.sequences}},
        players:{...state.players,players:state.players.players.map(q=>q===p?player:q)},
        aliens:{...state.aliens,aomomo:{...deck,cardDeck:[...deck.cardDeck]}}};
      let random=false;
      const result=residualSession.resolveAlienCardSelection(next,head,action,()=>{random=true;return 0;});
      const expected=source!=="cancel";
      if(!result.ok||random||(result.irreversible?.code==="hidden_alien_card")!==expected
        ||(result.events?.length||0)!==Number(expected))return null;
      const augmented=residualSession.augmentEffectResult(next,result,head);
      if((augmented.spawnedEffects?.length||0)||(augmented.events?.length||0)!==Number(expected))return null;
      const barrier=expected?{effectId:head.effectId,revision:s.revision+1,...result.irreversible}:s.irreversibleBarrier||null;
      return tail?prepareQuietPublicRefill(stored,s,next,1,0,2)
        :{envelope:provedCommittedEnvelope(stored,next),inspection:{phase:"idle",session:null},barrier};
    }

`+mark+`
      if(stored.envelope.session?.session?.queue[0]?.payload?.speciesId==="aomomo")
        return previewQuietAomomoCard(node,stored,action);`);
raw=raw.replace('function prepareQuietPublicRefill(stored,session,state,refillIndex=1,extraEffects=0){\n      const missing=state.cards.publicCards.filter(c=>!c).length;\n      if(missing!==1)return null;',
 'function prepareQuietPublicRefill(stored,session,state,refillIndex=1,extraEffects=0,maxMissing=1){\n      const missing=state.cards.publicCards.filter(c=>!c).length;\n      if(missing<1||missing>maxMissing)return null;');
const pink='        &&requested.family==="choose_target"&&(requested.target?.traceType==="pink"||pairedTrace&&requested.target?.traceType)';
assert.equal(raw.split(pink).length,2);
raw=raw.replace(pink,'        &&requested.family==="choose_target"&&(requested.target?.traceType==="pink"||pairedTrace&&requested.target?.traceType\n          ||requested.target?.traceType==="blue"&&taskSession.journal.actions[0]?.action?.family==="analyze")');
raw=raw.replace('1,Number(pinkBeforeRefill.regionSettled));','1,Number(pinkBeforeRefill.regionSettled),2);');
raw=raw.replace('||requested.target?.traceType==="blue"&&taskSession.journal.actions[0]?.action?.family==="analyze")',
 '||requested.target?.traceType==="blue"&&taskSession.journal.actions[0]?.action?.family==="analyze"\n          ||requested.target?.traceType==="yellow"&&taskSession.queue[0]?.payload?.cardEffect?.id==="b32-yellow-trace")');
const check='      if((!pick?.fixed||pick.selectedActionId!==action.actionId)\n';
assert.equal(raw.split(check).length,2);
raw=raw.replace(check,`      if(!(species==="amiba"&&s.workingState.turn.roundNumber===4&&head.payload.source==="trace_reward"
        &&!stored.informationBarrier&&!fossil&&!trace&&!pairedTrigger)
        &&(!pick?.fixed||pick.selectedActionId!==action.actionId)
`);
const spot='      if(alienDisplay){\n        restoreEnvelope(alienDisplay.envelope);';
assert.equal(raw.split(spot).length,2);
const gate='    function quietEarlySameSeatHandover(state) {';
assert.equal(raw.split(gate).length,2);
raw=raw.replace(gate,`    function quietFinalMarkSameSeat(state){
      const t=state.turn;
      return t.roundNumber===4
        &&knownRootAlienIds.has("奥陌陌")&&Object.values(state.aliens.aliens).every(slot=>!slot.revealed||knownRootAlienIds.has(slot.alienId));
    }

`+gate)
 .replace('markSource?.turn.roundNumber===3&&quietEarlySameSeatHandover(markSource)',
  'markSource&&(quietFinalMarkSameSeat(markSource)||markSource.turn.roundNumber===3&&quietEarlySameSeatHandover(markSource))')
 .replace('markState.turn.roundNumber===3&&quietEarlySameSeatHandover(markState)&&quietEndMarkTail',
  '(quietFinalMarkSameSeat(markState)||markState.turn.roundNumber===3&&quietEarlySameSeatHandover(markState))&&quietEndMarkTail');
const can='    function quietSignalBonusesOnly(state){';
assert.equal(raw.split(can).length,2);
raw=raw.replace(can,`    function quietAomomoSignalForData(t){
      const turn=t,ownerId=seatId;
      return ${bonusTest};
    }

`+can);
const dataBonuses='owner.passCompletionPending || t.cardTurnEventBonuses?.length&&!quietSignalBonusesOnly(state)';
assert.equal(raw.split(dataBonuses).length,3);
raw=raw.replaceAll(dataBonuses,dataBonuses+'&&!quietAomomoSignalForData(t)');
function replaceRange(a,b,change){
 const first=raw.indexOf(a),last=raw.indexOf(b,first+1);assert(first>=0&&last>first);
 raw=raw.slice(0,first)+change(raw.slice(first,last))+raw.slice(last);
}
replaceRange('    function previewQuietAomomoCard(', '    function previewQuietAlienDisplay(',x=>x.replace(
 '||t.cardTurnEventBonuses?.length||','||t.cardTurnEventBonuses?.length&&!quietAomomoSignalForData(t)||'));
replaceRange('    function previewQuietPublicScan(', '    function previewQuietScan4Action(',x=>x
 .replace('const markerTail=', 'const aomomoScan=source==="play_card"&&s.queue.length===3&&s.workingState.turn.cardTurnEventBonuses.length&&quietAomomoSignalForData(s.workingState.turn);\n      const markerTail=')
 .replace('&&!b9&&!markerTail||','&&!b9&&!markerTail&&!aomomoScan||')
 .replace('||t.cardTurnEventBonuses?.length||','||t.cardTurnEventBonuses?.length&&!aomomoScan||')
 .replace('const state={...root,meta:', 'const state={...root,...(aomomoScan?{turn:{...t,cardTurnEventBonuses:structuredClone(t.cardTurnEventBonuses)}}:{}),meta:')
 .replace('      if(repeatOnly&&!repeat||events.some',
 `      if(aomomoScan){
        const adjusted=residualSession.augmentEffectResult(state,{ok:true,events},head);
        if(adjusted.spawnedEffects.length||adjusted.events.length!==events.length)return null;
        events=adjusted.events;
      }
      if(repeatOnly&&!repeat||events.some`));
replaceRange('    function previewQuietScan4Action(', '    function',x=>x
 .replace('if(source==="scan"', 'const aomomoScan=source==="play_card"&&s.queue.length===2&&s.workingState.turn.cardTurnEventBonuses.length&&quietAomomoSignalForData(s.workingState.turn);\n      if(source==="scan"')
 .replace('source==="play_card"&&(s.queue.length','source==="play_card"&&!aomomoScan&&(s.queue.length')
 .replace('||t.cardTurnEventBonuses?.length||','||t.cardTurnEventBonuses?.length&&!aomomoScan||')
 .replace('if(events.some(e=>cardEffects.collectMatchingTriggers(player,e).length))return null;',
 'if(events.some(e=>cardEffects.collectMatchingTriggers(player,e).length||aomomoScan&&e.type==="signalMarked"))return null;'));
replaceRange('    function previewDataRewardMenu(', '    function rememberDataRewardMenu(',x=>x
 .replace('|| t.cardTurnEventBonuses?.length ||','|| t.cardTurnEventBonuses?.length&&!quietAomomoSignalForData(t) ||')
 .replaceAll('structuredClone(', 'copyForkData('));
replaceRange('    function previewCurrencyIncome(', '    function previewQuietFinalDataPlacement(',x=>x
 .replace('||t.cardTurnEventBonuses?.length||','||t.cardTurnEventBonuses?.length&&!quietAomomoSignalForData(t)||')
 .replaceAll('structuredClone(', 'copyForkData('));
replaceRange('    function previewQuietFinalDataPlacement(', '    const quietEndMarkQueue=',x=>x.replaceAll('structuredClone(', 'copyForkData('));
replaceRange('    function previewQuietPublicScan(', '    function previewQuietScan4Action(',x=>x.replaceAll('structuredClone(', 'copyForkData('));
const trial=process.env.SETI_BOARD11_CPU_TRIAL||'';
const cpu={dataHits:0,dataMiss:0,alienHits:0,dataBoardHits:0};
if(trial.includes('tokens')){
 const start='        function tokenIdentity(token, pool) {';
 const tail='        } };\n      }),';
 const left=raw.indexOf(start),right=raw.indexOf(tail,left);
 assert(left>0&&right>left);
 raw=raw.slice(0,left)+`
        let normalized=Object.isFrozen(player.dataState)?forwardDataIdentity.get(player.dataState):null;
        if(!normalized){
          normalized=normalizedDataIdentity(player.dataState);
          if(Object.isFrozen(player.dataState))forwardDataIdentity.set(player.dataState,normalized);
          globalThis.$setiCpu.dataMiss++;
        }else globalThis.$setiCpu.dataHits++;
        return {...player,dataState:normalized};
`+raw.slice(right+'        } };\n'.length);
 const tag='  function forwardIdentity(';
 raw=raw.replace(tag,`  const forwardDataIdentity=new WeakMap();
  function normalizedDataIdentity(dataState){
    function tokenIdentity(token,pool){
      const result={...token};delete result.id;delete result.index;
      if(pool)delete result.slotIndex;
      return result;
    }
    return {...dataState,
      poolTokens:dataState.poolTokens.map(token=>tokenIdentity(token,true)),
      placedTokens:dataState.placedTokens.map(token=>tokenIdentity(token,false))
        .sort((a,b)=>(a.placementKind<b.placementKind?-1:a.placementKind>b.placementKind?1:0)
          ||(a.placementSlot??a.blueSlot)-(b.placementSlot??b.blueSlot))};
  }
`+tag);
}
if(trial.includes('bucket')){
 const start=raw.indexOf('    function physicalCollisionKey('),end=raw.indexOf('    function internPhysicalIdentity(',start);
 assert(start>=0&&end>start);
 raw=raw.slice(0,start)+`
    const collisionAlienBytes=new WeakMap(),collisionDataBytes=new WeakMap();
    function physicalCollisionKey(envelope){
      const state=readIdentityState(envelope),board=state.aliens;
      let alien=Object.isFrozen(board)?collisionAlienBytes.get(board):null;
      if(alien)globalThis.$setiCpu.alienHits++;
      else{
        const grids=[board.amiba,board.chong].map(species=>[1,2].map(id=>{
          const grid=species?.traceSlotsByAlienSlotId?.[id];
          return grid&&["blue","pink","yellow"].map(color=>[1,2,3,4].map(position=>{
            const mark=grid[color]?.[position];return mark&&[mark.sequence,mark.playerId];
          }));
        }));
        const symbols=board.amiba?.symbolSlots;
        alien=JSON.stringify([grids,symbols&&Object.keys(symbols).sort().map(key=>[key,typeof symbols[key]==="string"?symbols[key]:null]),
          [1,2].map(id=>["blue","pink","yellow"].map(color=>{
            const t=board.aliens[id]?.traces?.[color];
            return t&&[t.firstPlaced,t.ownerPlayerColor,t.neutral,t.extraCount,t.extraMarkers?.length];
          }))]).slice(1,-1);
        if(Object.isFrozen(board))collisionAlienBytes.set(board,alien);
      }
      let nebula=Object.isFrozen(state.data)?collisionDataBytes.get(state.data):null;
      if(nebula)globalThis.$setiCpu.dataBoardHits++;
      else{
        nebula=JSON.stringify(data.NEBULA_IDS.map(id=>state.data.nebulae[id]?.tokens.map(t=>[t.replacementOrder,t.replacedByPlayerId])));
        if(Object.isFrozen(state.data))collisionDataBytes.set(state.data,nebula);
      }
      return "["+alien+","+JSON.stringify(state.players.players.map(p=>[p.blueBonusResources?.credits,p.blueBonusResources?.energy]))+","+nebula+"]";
    }
`+raw.slice(end);
}
if(trial.includes('quiet-value')){
 const tag='    function valueObservation(node) {';
 assert.equal(raw.split(tag).length,2);
 raw=raw.replace(tag,`    function quietFinalValue(node){
      if(!["turn-boundary","other-owner","information-barrier"].includes(node.status))return null;
      const stored=nodes.get(node);
      if(!stored?.envelope||stored.envelope.session||stored.informationBarrier
        &&!["hidden_card_reveal","hidden_alien_card","tech_bonus_reveal"].includes(stored.informationBarrier.code))return null;
      const state=readIdentityState(stored.envelope),t=state.turn,p=state.players.players.find(q=>q.id===seatId);
      if(t.roundNumber!==4||t.gameEnded||!p||p.passCompletionPending||t.passedPlayerIds.includes(seatId)
        ||p.reservedCards.some(c=>!knownCards(stored.envelope).has(c.id))
        ||Object.values(state.aliens.aliens).some(s=>s.revealed&&!knownRootAlienIds.has(s.alienId)))return null;
      const board=state.finalScoring,tiles=Object.values(board.tiles||{});
      if(!Number.isSafeInteger(p.resources.score)||!Array.isArray(board.thresholds)||!tiles.length
        ||!["a","b","c","d"].every(id=>board.tiles[id]?.id===id&&Array.isArray(board.tiles[id].marks))
        ||!board.tileVariants
        ||!board.thresholds.every(n=>Number.isSafeInteger(n)&&(n>p.resources.score||tiles.some(tile=>
          tile.marks?.some(m=>m.playerId===seatId&&Number(m.threshold)===n)))))return null;
      const probe=state.pieces.rockets.some(r=>r.surface==="solar-board"&&(r.kind||"standard")==="standard"&&r.fossilId==null&&r.playerId===seatId);
      const ready=probe&&readPlanningState(stored);
      const mission=probe?resourceDemand.planningCapital(ready,ready.players.players.find(q=>q.id===seatId)):0;
      if(probe)globalThis.$setiCpu.fastMissions=(globalThis.$setiCpu.fastMissions||0)+1;
      const wallet=p.resources,parts=[wallet.credits,wallet.energy,wallet.publicity/2,wallet.availableData/2,wallet.additionalPublicScan/2,p.hand.length];
      if(!parts.every(n=>Number.isSafeInteger(n*2)))return null;
      const finalScore=endScoring.computePlayerFinalScore({...state,finalScoring:{...board,tiles:{...board.tiles},tileVariants:{...board.tileVariants}},
        players:state.players.players,currentPlayer:p,cardEffects,
        getCardTypeCode:c=>cardEffects.getRuntimeCardTypeCode(c,cardEffects.getCardModel(c)?.cardType)},p).totalScore;
      globalThis.$setiCpu.fastLeaves=(globalThis.$setiCpu.fastLeaves||0)+1;
      return {value:stateValue.sumValueParts([finalScore,...parts,mission]),unrealizedPurposeValue:mission,purposePreparationDebt:0};
    }

`+tag);
 const exportKey='releaseBoundaryObservation, valueObservation, landingCompanyRetained';
 assert.equal(raw.split(exportKey).length,2);raw=raw.replace(exportKey,'releaseBoundaryObservation, valueObservation, quietFinalValue, landingCompanyRetained');
 const f=path.resolve('randomizer/game/ai/decision-search.js'),search=new Module(f,module);
 search.filename=f;search.paths=Module._nodeModulePaths(path.dirname(f));
 let sc=fs.readFileSync(f,'utf8');
 const root='    const observationForValue=node=>';
 assert.equal(sc.split(root).length,2);
 sc=sc.replace(root,`    const quietLeaves=new WeakMap();
    function quietLeaf(node){
      if(!realizationTies||!resourcePlanning||!port.quietFinalValue)return null;
      if(quietLeaves.has(node))return quietLeaves.get(node);
      const q=port.quietFinalValue(node);
      if(q&&${mode==='value-audit'}){
        const observed=port.valueObservation(node);
        globalThis.$checkQuietValue(q,evaluate.details(observed));
      }
      quietLeaves.set(node,q);return q;
    }
`+root);
 sc=sc.replace('return valueOf(observationForValue(node));','return quietLeaf(node)?.value??valueOf(observationForValue(node));')
  .replaceAll('const observation=observationForValue(node);','const quiet=quietLeaf(node);if(quiet)return 0;const observation=observationForValue(node);')
  .replace('if(quiet)return 0;const observation=observationForValue(node);','if(quiet)return -quiet.unrealizedPurposeValue;const observation=observationForValue(node);')
  .replace('port.releaseBoundaryObservation?.(node);','{if(!quietLeaf(node))port.releaseBoundaryObservation?.(node);}');
 search._compile(sc,f);search.loaded=true;require.cache[f]=search;
 globalThis.$checkQuietValue=(a,b)=>{assert.deepEqual(a,b);cpu.fastAudits=(cpu.fastAudits||0)+1;};
}
globalThis.$setiCpu=cpu;
if(mode==='audit'){
 const markChecks=[['if(markMenu){','markMenu.envelope',true],['if(markCommit){','provedCommittedEnvelope(stored,markCommit)',false]];
 for(const [tag,envelope,init] of markChecks){
  assert.equal(raw.split(tag).length,2);
  raw=raw.replace(tag,tag+`
        if(${init?'markSource':'markState'}.turn.roundNumber===4){
          const comp=fork.composition||fork,prev=loadedEnvelope,count=submissionCount;
          restoreEnvelope(stored.envelope,true);
          const {result}=executeCurrent(requested),actual=snapshot(comp);
          globalThis.$alienPickAudit?.(actual,${envelope},result.irreversibleBarrier,null,requested);
          submissionCount=count;
          if(prev)restoreEnvelope(prev);
        }`);
 }
 const scanChecks=[['if(publicScan){','publicScan.envelope',null],['if(scanAction){',
   'scanAction.prepared?.envelope||provedCommittedEnvelope(stored,scanAction.next)','scanAction.barrier']];
 for(const [tag,envelope,barrier] of scanChecks){
  assert.equal(raw.split(tag).length,2);
  raw=raw.replace(tag,tag+`
        if(taskSession.workingState.turn.cardTurnEventBonuses?.some(b=>b.id==="aomomo9-aomomo-signal-score")){
          const comp=fork.composition||fork,prev=loadedEnvelope,count=submissionCount;
          restoreEnvelope(stored.envelope,true);
          const {result}=executeCurrent(requested),actual=snapshot(comp);
          globalThis.$alienPickAudit?.(actual,${envelope},result.irreversibleBarrier,${barrier||'null'},requested);
          submissionCount=count;
          if(prev)restoreEnvelope(prev);
        }`);
 }
 const dataChecks=[['if(rewardMenu){','taskSession?.workingState','rewardMenu',null],
  ['if(currencyIncome){','taskSession?.workingState','provedCommittedEnvelope(stored,currencyIncome)',null],
  ['if (menuPreview) {','quietSource','menuPreview',null],
  ['if (fixedData) {','taskSession?.workingState','provedCommittedEnvelope(stored,fixedData.state)',null],
  ['if(endPrelude?.finished){','readIdentityState(stored.envelope)','provedCommittedEnvelope(stored,endPrelude.finished)',null]];
 for(const [tag,state,envelope] of dataChecks){
  assert.equal(raw.split(tag).length,2);
  raw=raw.replace(tag,tag+`
        if(${state}?.turn.cardTurnEventBonuses?.some(b=>b.id==="aomomo9-aomomo-signal-score")){
          const comp=fork.composition||fork,prev=loadedEnvelope,count=submissionCount;
          restoreEnvelope(stored.envelope,true);
          const {result}=executeCurrent(requested),actual=snapshot(comp);
          globalThis.$alienPickAudit?.(actual,${envelope},result.irreversibleBarrier,null,requested);
          submissionCount=count;
          if(prev)restoreEnvelope(prev);
        }`);
 }
 const menuSpot='      if(traceCardMenu){';
 assert.equal(raw.split(menuSpot).length,2);
 raw=raw.replace(menuSpot,menuSpot+`
        if(taskSession.journal.actions[0]?.action?.family==="analyze"||taskSession.queue[0]?.payload?.cardEffect?.id==="b32-yellow-trace"){
          const comp=fork.composition||fork,prev=loadedEnvelope,count=submissionCount;
          restoreEnvelope(stored.envelope,true);
          const {result}=executeCurrent(requested),actual=snapshot(comp);
          globalThis.$alienPickAudit?.(actual,traceCardMenu.prepared.envelope,result.irreversibleBarrier,null,requested);
          submissionCount=count;
          if(prev)restoreEnvelope(prev);
        }`);
 const checks=[['if(plainPink){','plainPink',null],['if(pinkRefill){','pinkRefill.envelope','pinkRefill.barrier']];
 for(const [spot,expr,barrier] of checks){
  assert.equal(raw.split(spot).length,2);
  const envelope=barrier?expr:`provedCommittedEnvelope(stored,${expr})`;
  raw=raw.replace(spot,spot+`
        if(taskSession.journal.actions[0]?.action?.family===${barrier?'"scan"':'"analyze"'}||taskSession.workingState.turn.cardTurnEventBonuses?.length||taskSession.queue[0]?.payload?.cardEffect?.id==="b32-yellow-trace"){
          const comp=fork.composition||fork,prev=loadedEnvelope,count=submissionCount;
          restoreEnvelope(stored.envelope,true);
          const {result}=executeCurrent(requested),actual=snapshot(comp);
          globalThis.$alienPickAudit?.(actual,${envelope},result.irreversibleBarrier,${barrier||'null'},requested);
          submissionCount=count;
          if(prev)restoreEnvelope(prev);
        }`);
 }
 raw=raw.replace(spot,`      if(alienDisplay){
        if(taskSession.queue[0].payload.speciesId==="aomomo"||!cardPickSpec(node)?.fixed){
          const comp=fork.composition||fork,prev=loadedEnvelope,count=submissionCount;
          restoreEnvelope(stored.envelope,true);
          const {result}=executeCurrent(requested),actual=snapshot(comp);
          globalThis.$alienPickAudit?.(actual,alienDisplay.envelope,result.irreversibleBarrier,alienDisplay.barrier,requested);
          submissionCount=count;
          if(prev)restoreEnvelope(prev);
        }
        restoreEnvelope(alienDisplay.envelope);`);
}
const physical=[];
if(mode==="profile"){
 const spot='      submissionCount += 1;';
 assert.equal(raw.split(spot).length,2);
 raw=raw.replace(spot,`      globalThis.$r4Physical?.(current,head,session);
`+spot);
 globalThis.$r4Physical=(a,h,s)=>physical.push([a.family,a.summary,h?.type||null,s?.journal?.actions[0]?.action?.summary||null, {
  queue:s?.queue?.map(x=>x.type),barrier:s?.irreversibleBarrier?.code, payload:h?.payload,
  undo:s?.undoFrames?.length, target:a.target, round:s?.workingState?.turn?.roundNumber,
  main:s?.workingState?.players.players.find(p=>p.id==='player-white')?.mainActionCompleted }]);
}
if(mode==="baseline"){
 delete require.cache[science];delete require.cache[residual];
}else{
 m._compile(raw,p);m.loaded=true;require.cache[p]=m;
}

const audits=[];
globalThis.$alienPickAudit=(actual,projected,barrierA,barrierB,a)=>{
 const x=JSON.parse(actual.committedState),y=JSON.parse(projected.committedState);
 assert.deepEqual(x,y,a.summary);
 const normalize=e=>JSON.parse(JSON.stringify(e,(k,v)=>{
  if(['sessionId','effectId','parentEffectId','groupId','decisionId'].includes(k)&&typeof v==='string'){
    const id=e?.session?.sessionId;
    return id&&(v===id||v.startsWith(id+':'))?'effect-session-local'+v.slice(id.length):v;
  }
  return v;
 }));
 assert.deepEqual(normalize(actual.session),normalize(projected.session),a.summary);
 assert.deepEqual(barrierA?.code??null,barrierB?.code??null,a.summary);
 audits.push(a.summary);
};
const {open,readZ,writeZ}=require('./controlled-r3');
const evidence=readZ(from);
const row=evidence.continuation||evidence.results.find(x=>x.stop?.kind==='gate');
const start=mode==="suffix"?(process.argv[5]===undefined?evidence.results.find(x=>x.board===11&&x.label==="fill-and-free-analyze"):evidence.results[Number(process.argv[5])]).root4:row.stop.root;
const model=open(start);
try{
 const q=model.automatic();assert.deepEqual(model.save(),start);
 const result={a:q.a?.summary,v:q.value,n:q.n,ms:q.ms,complete:q.complete,roots:q.roots,lines:q.lines,diagnostics:q.diagnostics,analysis:q.analysis,audits,cpu};
 console.log(JSON.stringify({a:result.a,v:result.v,n:result.n,ms:result.ms,roots:result.roots.length,audits:audits.length,cpu}));
 if(["continue","suffix"].includes(mode)&&q.complete&&q.n<=256&&q.ms<=600){
  const actions=[],checks=[];let cp,stop;
  for(let i=0;i<210;i++){
   if(model.state().turn.gameEnded){stop='terminal';break;}
   if(model.menu()[0]?.actorId!=='player-white'){model.advanceOpponents(actions);continue;}
   const x=i===0?q:model.automatic(cp);
   const xq={n:x.n,ms:x.ms,complete:x.complete,a:x.a?.summary,v:x.value};
   if(!x.complete||!x.a||x.n>256||x.ms>600){stop={kind:'gate',...xq,root:model.save()};break;}
   checks.push(xq);cp=x.checkpoint;actions.push(model.apply(x.a));
  }
  assert(stop);
  const end=model.save(),terminal=stop==='terminal'?model.state().match.finalScores.find(x=>x.playerId==='player-white').totalScore:null;
  model.restore(start);actions.forEach(x=>model.apply(x));assert.deepEqual(model.save(),end);
  result.continuation={actions,checks,stop,terminal,end};
  console.log(JSON.stringify({stop:typeof stop==='string'?stop:{...stop,root:undefined},terminal,steps:actions.length,
    peak:[Math.max(0,...checks.map(x=>x.n)),Math.max(0,...checks.map(x=>x.ms))]}));
 }
 if(mode==="profile")result.physical=physical;
 writeZ(out,result);
}finally{model.dispose();}
