'use strict';
const path=require('node:path'),assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const load=p=>require(path.resolve(p));
const {createAnalysisPort}=load('randomizer/game/ai/analysis-port'),{evaluateStateValue,createStateValueEvaluator}=load('randomizer/game/ai/state-value');
const [from,out]=process.argv.slice(2),seat='player-white',r=readZ(from).results.find(x=>x.board===11),rows=[];
const m=open(r.root),q=m.automatic();
const compare=(kind,which)=>{
 m.restore(r.root);
 const before=m.save(),port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
 try{
  let node=port.openRoot();port.setResourcePlanning(true);port.setMovementPlanning(true);port.setCardPickPlanning(true);
  port.setDecisionPlanning({finalMarkPlanning:true,scanPlanning:true});
  const act=a=>{
   assert(a,JSON.stringify(node.legalActions.map(y=>y.summary)));
   node=port.expand(node,a.actionId);
  };
  if(kind==='pass')act(node.legalActions.find(a=>a.family==='pass'));
  else if(kind==='blue'){
   act(node.legalActions.find(a=>a.family==='place_data'));
   act(node.legalActions.find(a=>a.target?.blueSlot===2));
   act(node.legalActions.find(a=>a.family==='pass'));
  }else{
   for(const x of r.branches.rows[0].prefix)act(node.legalActions.find(a=>a.actionId===x.actionId));
   act(node.legalActions.find(a=>a.target.alienSlotId===which&&a.target.traceType==='blue'));
   if(node.status==='stable')act(node.legalActions.find(a=>a.family==='end_turn'));
  }
  const observation=port.valueObservation(node),evalr=evaluateStateValue(observation,seat),value=createStateValueEvaluator(seat)(observation);
  assert.equal(value,evalr.total);assert.deepEqual(m.save(),before);
  const owner=observation.publicState.players.find(p=>p.playerId===seat);
  rows.push({kind,which,boundary:node.boundary,status:node.status,value,components:evalr.components,
   cash:owner.credits,energy:owner.energy,pool:owner.availableData,dataIncome:owner.income.availableData,
   gained:Math.min(owner.income.availableData,6-owner.availableData),
   salaryCorrection:3*Math.min(owner.income.availableData,6-owner.availableData)-.5*Math.max(0,owner.income.availableData+owner.availableData-6),
   knownHand:observation.selfState.hand.map(c=>({hidden:c.hidden??false,cardId:c.cardId??null})),
   handCount:owner.handCount,score:owner.score,observation});
 }finally{port.close();}
};
try{
 compare('pass',0);compare('blue',0);
 compare('analyze',1);
 compare('analyze',2);
 const goals=q.lines[0].edges.filter(x=>x.resourcePlan?.goal.kind==='analyze').map(x=>({edge:x,value:q.lines[x.target].value}));
 console.log(JSON.stringify({roots:q.roots.map(x=>[x.actionId,x.value]),goals:goals.map(x=>x.value),
  rows:rows.map(({observation,...x})=>x)}));
 writeZ(out,{rows,goals,root:r.root});
}finally{m.dispose();}
