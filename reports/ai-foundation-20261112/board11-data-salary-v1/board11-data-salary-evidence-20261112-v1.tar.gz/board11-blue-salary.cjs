'use strict';
const {open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const assert=require('node:assert/strict'),[from,out]=process.argv.slice(2),r=readZ(from).results.find(x=>x.board===11);
const chooseBlue=({act})=>{act('place_data');act('choose_target',a=>a.target?.blueSlot===2);};
const trials=runCases(r.root,[['blue-before-pass',chooseBlue]]);
const results=trials.rows.filter(x=>x.settled).map(row=>{
 const m=open(row.settled.state),actions=[];
 try{
  actions.push(m.act('pass'),m.act('choose_card',a=>a.summary==='b_9.webp'));m.advanceOpponents(actions);
  const root4=m.save(),start=short(m);
  m.restore(row.settled.state);actions.forEach(a=>m.apply(a));assert.deepEqual(m.save(),root4);
  return {board:11,label:'fill-and-free-analyze',case:row.label,root4,start,row};
 }finally{m.dispose();}
});
writeZ(out,{results});
