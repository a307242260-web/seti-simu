'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),assert=require('node:assert/strict');
function install(file,patch){
 const p=path.resolve(file),m=new Module(p,module);
 m.filename=p;m.paths=Module._nodeModulePaths(path.dirname(p));
 m._compile(patch(fs.readFileSync(p,'utf8')),p);m.loaded=true;require.cache[p]=m;
}
install('randomizer/game/ai/analysis-port.js',s=>{
 const key='    function valueObservation(node) {';
 assert.equal(s.split(key).length,2);
 s=s.replace(key,`    function finalDataSalarySource(){
      const stored=nodes.get(openedRoot);
      if(!stored?.envelope||rootObservation?.publicState.roundNumber!==3)return null;
      const state=readIdentityState(stored.envelope),t=state.turn,p=state.players.players.find(q=>q.id===seatId);
      if(t.activePlayerIds.some(id=>id!==seatId&&!t.passedPlayerIds.includes(id))
        ||!p.income.availableData||p.mainActionCompleted||p.passCompletionPending
        ||p.resources.credits||p.resources.energy||p.resources.availableData<players.RESOURCE_LIMITS.availableData-2
        ||!industryCatalog.getPlayerIndustryDefinition(p)?.passiveIds.includes("deepspace_free_analyze")
        ||openedRoot.legalActions.some(a=>a.phase==="main"&&!["pass","analyze"].includes(a.family)))return null;
      const claims=p.reservedCards.flatMap(c=>{
        if(!knownRootCardIds.has(c.id))return [];
        const rule=endScoring.resolveCardEndGameRule(c,cardEffects);
        return rule?.kind==="remainingResource"&&rule.resource==="availableData"&&rule.scorePer>0?[{id:c.id,multiplier:rule.scorePer}]:[];
      });
      return claims.length===1?claims[0]:null;
    }
    function finalDataSalaryQuote(node,source){
      if(node.status!=="turn-boundary"&&!(node.status==="information-barrier"
        &&["hidden_pass_reserve_offer","alien_reveal_turn_end"].includes(node.boundary)))return null;
      const stored=nodes.get(node),state=readIdentityState(stored.envelope),p=state.players.players.find(q=>q.id===seatId);
      if(!p?.reservedCards.some(c=>c.id===source.id)||state.turn.roundNumber!==3)return null;
      const score=p.resources.score,pool=p.resources.availableData,income=p.income.availableData;
      if(![score,pool,income].every(Number.isSafeInteger)||pool<0||pool>players.RESOURCE_LIMITS.availableData||income<=0)return null;
      const keep=Math.min(income,players.RESOURCE_LIMITS.availableData-pool);
      return {score,keep,overflow:income-keep,gain:source.multiplier*keep-(income-keep)*stateValue.DEFAULT_WEIGHTS.availableData};
    }
`+key);
 return s.replace('releaseBoundaryObservation, valueObservation, landingCompanyRetained',
  'releaseBoundaryObservation, valueObservation, finalDataSalarySource, finalDataSalaryQuote, landingCompanyRetained');
});
install('randomizer/game/ai/decision-search.js',s=>{
 const src='    const knownPickupFunding=';
 s=s.replace(src,'    const finalDataSalary=resourcePlanning&&realizationTies&&port.finalDataSalarySource?.();\n'+src);
 s=s.replace('const value = forecast?stateValue.sumValueParts([baseValue,forecast]):baseValue;',
 `const salary=finalDataSalary&&port.finalDataSalaryQuote(node,finalDataSalary);
      const value = forecast||salary?stateValue.sumValueParts([baseValue,forecast,salary?.gain||0]):baseValue;`);
 s=s.replace('movementPolicy, pickPolicy, resourcePolicy, decisionPolicy, queuePriority, deferredPublicity,','movementPolicy, pickPolicy, resourcePolicy, decisionPolicy, queuePriority, salary, salaryScore:salary?.score, deferredPublicity,');
 s=s.replace('const finalTie=incomeTieRank>0 || incomeTieRank===0&&shorter;',
 `const salaryTie=process.env.SETI_SALARY_TIE==="secured"&&Number.isFinite(target.salaryScore)&&Number.isFinite(parent.salaryScore)
            ?target.salaryScore-parent.salaryScore:0;
          const finalTie=incomeTieRank>0 || incomeTieRank===0&&(salaryTie>0||salaryTie===0&&shorter);`);
 const rootsTail='||(nodes[a.target].chongBlindCount??0)-(nodes[b.target].chongBlindCount??0)||nodes[a.target].distance';
 assert.equal(s.split(rootsTail).length,2);
 s=s.replace(rootsTail,`||(nodes[a.target].chongBlindCount??0)-(nodes[b.target].chongBlindCount??0)
          ||(process.env.SETI_SALARY_TIE==="secured"&&Number.isFinite(nodes[a.target].salaryScore)&&Number.isFinite(nodes[b.target].salaryScore)
            ?nodes[b.target].salaryScore-nodes[a.target].salaryScore:0)||nodes[a.target].distance`);
 s=s.replace('parent.pickupRank = target.pickupRank;','parent.pickupRank = target.pickupRank;\n            parent.salaryScore=target.salaryScore;');
 s=s.replace('...(entry.pickupFunding?{knownPickupFunding:entry.pickupFunding}:{}),','...(entry.pickupFunding?{knownPickupFunding:entry.pickupFunding}:{}),\n      ...(entry.salary?{finalDataSalary:entry.salary}:{}),');
 return s;
});
const {open,readZ,writeZ,runCases,short}=require('./controlled-r3');
const [from,out,batch]=process.argv.slice(2),r=readZ(from).results.find(x=>x.board===11);
const world=[];
for(const swap of process.env.SETI_SALARY_COVERAGE_ONLY?[]:[null,[0,3],[3,5]]){
 const raw=JSON.parse(r.root.committedState);
 if(swap){const deck=raw.aliens.aomomo.initialConfiguration.cardDeck,[i,j]=swap;[deck[i],deck[j]]=[deck[j],deck[i]];}
 const root=swap?{...r.root,committedState:JSON.stringify(raw)}:r.root,m=open(root);
 try{
  const view=m.owner('player-white'),q=m.automatic();
  const cases=runCases(root,[['autonomous-with-salary',()=>{}]]);
  const entry=cases.rows[0],first=entry.actions.slice(0,8).map(x=>x.action.summary);
  if(world.length){
   assert.deepEqual(view,world[0].view);
   assert.deepEqual([q.a.actionId,q.value,q.roots,q.lines],[world[0].q.a.actionId,world[0].q.value,world[0].q.roots,world[0].q.lines]);
  }
  assert(q.n<=256&&q.ms<=600&&entry.replayExact);
  if(process.env.SETI_SALARY_TIE==="secured")assert.equal(q.roots.find(x=>x.actionId===q.a.actionId)?.goal?.kind,"analyze");
  world.push({swap,view,q,first,entry});
  console.log(JSON.stringify({swap,tie:process.env.SETI_SALARY_TIE||null,v:q.value,n:q.n,first,
    roundEnd:entry.settled?.summary?.wallet,hand:entry.settled?.summary?.hand}));
 }finally{m.dispose();}
}
const coverage=[];
if(batch){
 const read=f=>JSON.parse(fs.readFileSync(f)),seat='player-white';
 const list=[...read(batch).rows,{board:0,f:'812cbda0.39065c78.quick-400.json'}];
 const {createAnalysisPort}=require(path.resolve('randomizer/game/ai/analysis-port'));
 for(const {board,f} of list){
  const rec=read('reports/research/'+f),sv=read(rec.savePath),cp=read(rec.roundEnds[1].checkpointPath),m=open(cp.coreState.compositionEnvelope);
  const matches=[];let visited=0;
  try{
   for(let i=cp.replayCursor.stepIndex;i<=rec.roundEnds[2].beforeInput-1;i++){
    const action=sv.replaySteps[i].action;
    if(action.actorId===seat){
     visited++;
     const p=m.player(),t=m.state().turn;
     if(p.income.availableData>0&&p.resources.availableData>=4&&p.reservedCards.length){
      const port=createAnalysisPort({composition:m.c,seatId:seat,maxCacheEntries:0});
      try{port.openRoot();const source=port.finalDataSalarySource();if(source)matches.push({input:i+1,choice:action.summary,source,root:m.save()});}
      finally{port.close();}
     }
    }
    if(i===rec.roundEnds[2].beforeInput-1)break;
    m.apply(action);
   }
   assert.deepEqual(m.save(),read(rec.roundEnds[2].checkpointPath).coreState.compositionEnvelope);
   coverage.push({board,visited,matches});
  }finally{m.dispose();}
 }
 console.log(JSON.stringify({coverage:coverage.map(({board,visited,matches})=>[board,visited,matches.map(x=>[x.input,x.choice])])}));
}
writeZ(out,{world,coverage});
