'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{readZ}=require('./controlled-r3');
const scenario=require(path.resolve('tools/research-free-analyze-random20')),read=p=>JSON.parse(fs.readFileSync(p));
const [manifest,batch,out]=process.argv.slice(2),record=f=>read('reports/research/'+f);
const rows=[];
for(const run of read(manifest)){
 const ref=run.board===0?'4539c186.ff577dea.quick-400.json':read(batch).rows.find(x=>x.board===15).record;
 const old=record(ref),now=record(run.record),a=read(old.savePath),b=read(now.savePath),x=a.replaySteps.map(s=>s.action),y=b.replaySteps.map(s=>s.action);
 const cuts=now.roundEnds.slice(0,run.board===0?3:2).map((cut,i)=>{
  const lhs=read(old.roundEnds[i].checkpointPath),rhs=read(cut.checkpointPath);
  assert.equal(lhs.replayCursor.stepIndex,rhs.replayCursor.stepIndex);assert.deepEqual(lhs.coreState.compositionEnvelope,rhs.coreState.compositionEnvelope);
  return rhs;
 });
 const firstChange=y.findIndex((a,i)=>JSON.stringify(a)!==JSON.stringify(x[i]));
 const peak=run.peak;assert(peak[0]<=256&&peak[1]<=600&&run.wallMs<180000);
 if(!run.board){
  assert.equal(firstChange,-1);assert.equal(x.length,y.length);assert.deepEqual(now.roundEnds.map(r=>r.score),[15,48,118]);
  assert.deepEqual(now.metrics.searches.map(s=>[s.value,s.diagnostics.nativeExecutions]),old.metrics.searches.map(s=>[s.value,s.diagnostics.nativeExecutions]));
 }else{
  assert.equal(firstChange+1,112);assert.equal(y[firstChange].family,'scan');assert(now.terminal);
  const config={seed:now.seed,activePlayerCount:now.activePlayerCount,aiDifficulty:now.aiDifficulty,agentType:now.agentType,compactReplay:true};
  const env=scenario.createEnvironment(config,now.scenario);
  try{
   const opening=scenario.initialize(env,config,now.scenario);assert.deepEqual(opening.map(x=>x.action),y.slice(0,opening.length));
   const targets=new Map(cuts.map(c=>[c.replayCursor.stepIndex,c.coreState.compositionEnvelope]));
   for(let i=opening.length;i<y.length;i++){
    if(targets.has(i))assert.deepEqual(env.createCheckpoint().coreState.compositionEnvelope,targets.get(i));
    const a=y[i],legal=env.legalActions().find(x=>x.actionId===a.actionId&&x.actorId===a.actorId);
    assert(legal,a.summary);assert.deepEqual(JSON.parse(JSON.stringify(legal)),a);
    const result=env.step(legal);assert(result.ok,result.error);
   }
   const final=env.createCheckpoint().coreState.compositionEnvelope;
   assert.deepEqual(JSON.parse(final.committedState),JSON.parse(b.committedState));assert.equal(final.session,null);
   const controlled=readZ(path.join(__dirname,'trial-paired-scan-0-ff577dea-20261112-v1.json.gz')).rows[0];
   assert.deepEqual(JSON.parse(final.committedState),JSON.parse(controlled.end.committedState));
   assert.equal(run.score,158);
  }finally{env.dispose();}
 }
 rows.push({...run,priorRecord:ref,priorScore:old.summary.scores['player-white'],inputs:y.length,
  equalNativeRoundEnds:cuts.length,firstChange:firstChange<0?null:{input:firstChange+1,old:x[firstChange].summary,new:y[firstChange].summary},
  independentContinuousReplay:!!run.board});
}
fs.writeFileSync(out,JSON.stringify(rows,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(rows));
