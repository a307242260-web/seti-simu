'use strict';
const {readZ,writeZ,runCases,open}=require('./controlled-r3');
const [file,out]=process.argv.slice(2),groups=[];
for(const r of readZ(file).rows.filter(r=>r.board===13||r.board===17)){
 const x=r.hits[0],m=open(x.root);let u;
 try{u=m.automatic();console.log(JSON.stringify({board:r.board,step:x.input,choice:u.a.summary,value:u.value,n:u.n,
  oranges:u.roots.filter(r=>m.menu().some(a=>a.actionId===r.actionId&&['orange1','orange3'].includes(a.target?.tileId))).map(r=>[m.menu().find(a=>a.actionId===r.actionId)?.target.tileId,r.value,r.completion])}));}
 finally{m.dispose();}
 const cases=['orange1','orange3'].map(t=>[t,h=>h.act('choose_target',a=>a.target.tileId===t)]);
 groups.push({board:r.board,source:r.name,input:x.input,root:x.root,first:{choice:u.a,value:u.value,n:u.n},...runCases(x.root,cases)});
}
writeZ(out,{groups});
