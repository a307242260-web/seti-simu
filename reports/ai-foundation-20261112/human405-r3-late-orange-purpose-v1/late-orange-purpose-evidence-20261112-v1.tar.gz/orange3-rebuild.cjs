'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [fourth,upstream,out]=process.argv.slice(2),k=require(path.resolve('randomizer/game/production-kernel')),seat='player-white';
const root=readZ(upstream).rows[29].root;
const o3=readZ(fourth).rows.filter(r=>r.label==='force-6'),m=open(root),rows=[];
const r3=()=>{
 m.restore(root);const actions=[m.act('choose_target',a=>a.target.tileId==='orange3'),m.act('end_turn')];
 if(m.menu()[0].actorId!==seat)m.advanceOpponents(actions);
 const end=m.save();assert.deepEqual(end,o3[0].origin);return {actions,end};
};
const common=r3();
try{
 for(const row of o3)for(const kind of ['launch-only','launch-and-B16-Sirius','launch-and-B16-Procyon']){
  m.restore(row.start);
  const actions=[m.act('launch')],front=[short(m)];
  if(kind!=='launch-only'){
   actions.push(m.act('end_turn'));
   if(m.menu()[0].actorId!==seat)m.advanceOpponents(actions);
   assert.equal(m.facts().turn,5);
   const plan=k.getProbeRouteRequirements(m.state(),seat).candidates.find(r=>r.planetId==='saturn'&&r.endpointFamily==='land'&&r.endpointTarget.type==='planet');
   assert(plan&&plan.path.length);
   const dir=plan.path[0];actions.push(m.play('b_16.webp'));
   actions.push(m.act('choose_target',a=>a.target.rocketId===plan.rocketId&&a.target.deltaX===dir.deltaX&&a.target.deltaY===dir.deltaY));
   const s=kind.endsWith('Sirius')?'sector-2-a':'sector-1-a';
   actions.push(m.act('choose_target',a=>a.target.nebulaId===s));
   front.push(short(m));
  }
  const start=m.save(),prefix=actions.length,checks=[],main=[];let stop,cp,firstLanding;
  for(let i=0;i<230;i++){
   if(m.state().turn.gameEnded){stop={kind:'terminal'};break;}
   if(m.menu()[0].actorId!==seat){m.advanceOpponents(actions);continue;}
   const u=m.automatic(cp),a=u.a,x={n:u.n,ms:u.ms,complete:u.complete,value:u.value,a:a?.summary};
   if(!a||!u.complete||u.n>256||u.ms>600){stop={kind:'gate',...x,root:m.save(),roots:u.roots};break;}
   if(a.phase==='main')main.push([m.facts().turn,a.family,a.summary,a.target]);
   const before=a.family==='land'&&!firstLanding?m.state().planets.planets:null;
   cp=u.checkpoint;checks.push(x);actions.push(m.apply(a));
   if(before){
    const after=m.state().planets.planets;
    const planet=Object.keys(before).find(k=>before[k].landingMarkers.length!==after[k].landingMarkers.length);
    if(planet)firstLanding={planet,after:short(m)};
   }
  }
  assert(stop);
  const end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore;
  m.restore(row.start);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  const peak=[Math.max(0,...checks.map(x=>x.n)),Math.max(0,...checks.map(x=>x.ms))];
  console.log(JSON.stringify({reserve:row.reserve,kind,terminal,firstLanding,stop:{...stop,root:undefined,roots:undefined},main,peak}));
  rows.push({reserve:row.reserve,kind,root:row.start,front,start,prefix,actions,checks,main,firstLanding,stop,end,terminal,peak});
 }
 writeZ(out,{root,common,rows});
}finally{m.dispose();}
