'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [file,out]=process.argv.slice(2),seat='player-white',read=f=>JSON.parse(fs.readFileSync(f)),rows=[];
for(const g of readZ(file).groups){
 const rec=read('reports/research/'+g.source),c=rec.roundEnds[2],replay=read(rec.savePath).replaySteps;
 const pick=replay.slice(c.beforeInput-1,c.beforeInput+20).find(x=>x.action.actorId===seat&&x.action.target?.kind==='pass-reserve-card').action.target.cardId;
 const ref=read(c.checkpointPath).coreState.compositionEnvelope;
 for(const r of g.rows){
  const origin=r.settled.state,m=open(origin),actions=[],checks=[],main=[];
  try{
   actions.push(m.act('pass'));
   if(m.menu()[0].actorId!==seat)m.advanceOpponents(actions);
   actions.push(m.act('choose_card',a=>a.target.kind==='pass-reserve-card'&&a.target.cardId===pick));
   if(m.menu()[0].actorId!==seat)m.advanceOpponents(actions);
   const start=m.save(),assets=short(m);
   let stop,cp;
   for(let i=0;i<230;i++){
    if(m.state().turn.gameEnded){stop={kind:'terminal'};break;}
    if(m.menu()[0].actorId!==seat){m.advanceOpponents(actions);continue;}
    const u=m.automatic(cp),a=u.a,x={n:u.n,ms:u.ms,complete:u.complete,value:u.value,a:a?.summary};
    if(!a||!u.complete||u.n>256||u.ms>600){stop={kind:'gate',...x,root:m.save(),roots:u.roots};break;}
    if(a.phase==='main')main.push([m.facts().turn,a.family,a.summary]);
    cp=u.checkpoint;checks.push(x);actions.push(m.apply(a));
   }
   assert(stop);
   const end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore;
   m.restore(origin);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
   const peak=[Math.max(0,...checks.map(x=>x.n)),Math.max(0,...checks.map(x=>x.ms))];
   const exact=JSON.stringify(origin)===JSON.stringify(ref);
   rows.push({board:g.board,tile:r.label,pick,exact,origin,start,assets,actions,checks,main,stop,end,terminal,peak});
   console.log(JSON.stringify({board:g.board,tile:r.label,pick,exact,assets,terminal,peak,stop:{...stop,root:undefined,roots:undefined}}));
  }finally{m.dispose();}
 }
}
writeZ(out,{rows});
