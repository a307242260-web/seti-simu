'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [o1file,o3file,out]=process.argv.slice(2),k=require(path.resolve('randomizer/game/production-kernel')),seat='player-white';
const o1=readZ(o1file),o3=readZ(o3file),seeds=[['orange1',o1.origin],['orange3',o3.common.end]],rows=[];
for(const [tile,origin] of seeds)for(const swap of [null,[0,4],[1,6]]){
 const s=JSON.parse(origin.committedState),deck=s.cards.drawPileCardIds;
 if(swap){assert(deck[swap[0]]&&deck[swap[1]]);[deck[swap[0]],deck[swap[1]]]=[deck[swap[1]],deck[swap[0]]];}
 const e=swap?{...origin,committedState:JSON.stringify(s)}:origin,m=open(e);
 try{
  const view=m.owner(seat),menu=m.menu(),rng=m.facts().rng;
  const baseline=rows.find(r=>r.tile===tile);
  if(baseline){assert.deepEqual(view,baseline.view);assert.deepEqual(menu,baseline.menu);assert.deepEqual(rng,baseline.rng);}
  const actions=[],take=a=>(actions.push(a),a),pay=()=>{if(m.menu()[0].actorId!==seat)m.advanceOpponents(actions);};
  const endTurn=()=>{take(m.act('end_turn'));pay();};
  take(m.act('pass'));pay();take(m.act('choose_card',a=>a.target.kind==='pass-reserve-card'&&a.target.cardId==='b_111.webp'));pay();
  let r4=short(m),main=0;
  if(tile==='orange3'){take(m.act('launch'));++main;endTurn();}
  const route=()=>k.getProbeRouteRequirements(m.state(),seat).candidates.find(r=>r.planetId==='saturn'&&r.endpointFamily==='land'&&r.endpointTarget.type==='planet');
  const p=route(),dir=p.path[0];
  take(m.play('b_16.webp'));++main;
  take(m.act('choose_target',a=>a.target.rocketId===p.rocketId&&a.target.deltaX===dir.deltaX&&a.target.deltaY===dir.deltaY));
  take(m.act('choose_target',a=>a.target.nebulaId==='sector-2-a'));
  const afterB16=short(m);
  endTurn();const tail=route();
  for(const d of tail.path){
   take(m.act('move',a=>a.target.rocketId===p.rocketId&&a.target.deltaX===d.deltaX&&a.target.deltaY===d.deltaY));
   take(m.act('choose_payment',a=>a.target.choiceId==='energy'));
  }
  take(m.act('land'));++main;
  assert(m.state().planets.planets.saturn.landingMarkers.some(x=>x.playerId===seat));
  const after=short(m),end=m.save();m.restore(e);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  rows.push({tile,swap,root:e,view,menu,rng,r4,afterB16,after,tail:tail.required,actions,end,main});
  console.log(JSON.stringify([tile,swap,main,r4.wallet,after.wallet,tail.required]));
 }finally{m.dispose();}
}
writeZ(out,{rows});
