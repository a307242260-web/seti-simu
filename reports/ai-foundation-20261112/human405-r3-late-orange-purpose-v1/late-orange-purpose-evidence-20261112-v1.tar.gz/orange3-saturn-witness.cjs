'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [file,out]=process.argv.slice(2),k=require(path.resolve('randomizer/game/production-kernel')),seat='player-white';
const src=readZ(file),rows=[];
for(const r of src.rows.filter(x=>x.kind.includes('B16'))){
 assert.equal(r.stop.kind,'gate');const m=open(r.stop.root);
 try{
  const q=k.getProbeRouteRequirements(m.state(),seat).candidates.find(r=>r.planetId==='saturn'&&r.endpointFamily==='land'&&r.endpointTarget.type==='planet');
  assert.equal(q.path.length,1);assert(q.required.energy<=m.facts().wallet.energy);
  const d=q.path[0],actions=[
   m.act('move',a=>a.target.rocketId===q.rocketId&&a.target.deltaX===d.deltaX&&a.target.deltaY===d.deltaY),
   m.act('choose_payment',a=>a.target.choiceId==='energy'),m.act('land')
  ];
  const landed=m.state().planets.planets.saturn.landingMarkers.some(x=>x.playerId===seat);
  assert(landed);
  const firstLanding=short(m),prefix=actions.length,checks=[],main=[];let stop,cp;
  for(let i=0;i<220;i++){
   if(m.state().turn.gameEnded){stop={kind:'terminal'};break;}
   if(m.menu()[0].actorId!==seat){m.advanceOpponents(actions);continue;}
   const u=m.automatic(cp),a=u.a,x={n:u.n,ms:u.ms,complete:u.complete,value:u.value,a:a?.summary};
   if(!a||!u.complete||u.n>256||u.ms>600){stop={kind:'gate',...x,root:m.save(),roots:u.roots};break;}
   if(a.phase==='main')main.push([m.facts().turn,a.family,a.summary]);
   cp=u.checkpoint;checks.push(x);actions.push(m.apply(a));
  }
  assert(stop);
  const end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore;
  m.restore(r.root);[...r.actions,...actions].forEach(m.apply);assert.deepEqual(m.save(),end);
  const peak=[Math.max(0,...checks.map(x=>x.n)),Math.max(0,...checks.map(x=>x.ms))];
  rows.push({kind:r.kind,reserve:r.reserve,root:r.stop.root,actions,checks,firstLanding,prefix,stop,end,terminal,peak,main});
  console.log(JSON.stringify({reserve:r.reserve,kind:r.kind,terminal,firstLanding,peak,stop:{...stop,root:undefined,roots:undefined},main}));
 }finally{m.dispose();}
}
writeZ(out,{rows});
