'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{open,short,writeZ}=require('./controlled-r3');
const read=f=>JSON.parse(fs.readFileSync(f)),seat='player-white',effect=require(path.resolve('randomizer/game/cards/effects'));
const cohort=read('reports/iteration/free-analyze-random20-funded-planet-20261111/summary-463fc442-20261111.json').rows.map(x=>[x.board,x.f]);
cohort.push(['standard','599c3f5b.93947ab2.quick-400.json']);
const rows=[];
for(const [board,name] of cohort){
 const r=read('reports/research/'+name),r2=read(r.roundEnds[1].checkpointPath),r3=read(r.roundEnds[2].checkpointPath),actual=read(r.savePath).replaySteps;
 const m=open(r2.coreState.compositionEnvelope),hits=[];
 try{
  for(let i=r2.replayCursor.stepIndex;i<r3.replayCursor.stepIndex;i++){
   const a=actual[i].action;
   if(a.actorId===seat&&a.family==='choose_target'&&a.target?.tileId&&m.facts().round===3){
    const legal=m.menu(),offers=['orange1','orange3'].map(t=>legal.find(a=>a.target.tileId===t));
    if(offers.every(Boolean)){
     const f=m.facts(),s=m.state();
     const held=m.player().hand.filter(c=>{
      const e=effect.buildPlayEffects(c);
      return e.some(x=>x.type==='card_move')&&e.some(x=>['card_scan_color_choice','card_planet_sector_scan','card_scan_nebula'].includes(x.type));
     }).map(c=>c.cardId);
     hits.push({input:i+1,actual:a.summary,held,active:s.turn.activePlayerIds,passed:s.turn.passedPlayerIds,start:short(m),root:m.save()});
    }
   }
   m.apply(a);
  }
  assert.deepEqual(m.save(),r3.coreState.compositionEnvelope);
  rows.push({board,name,hits});
 }finally{m.dispose();}
}
console.log(JSON.stringify(rows.filter(r=>r.hits.length).map(r=>[r.board,r.hits.map(h=>[h.input,h.actual,h.held,h.start.probes.length,h.start.wallet])])));writeZ(process.argv[2],{rows});
