'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [o1file,o3file,finishfile,out]=process.argv.slice(2),seat='player-white';
const a=readZ(o1file),b=readZ(o3file),c=readZ(finishfile);
const cases=a.rows.map(r=>({id:'orange1',reserve:r.reserve,sector:r.nebulaId,origin:r.opening,steps:[...r.prefix,...r.actions]}));
for(const row of c.rows){
 const r=b.rows.find(x=>x.reserve===row.reserve&&x.kind===row.kind);
 cases.push({id:'orange3',reserve:r.reserve,sector:r.kind.endsWith('Sirius')?'sector-2-a':'sector-1-a',origin:r.root,steps:[...r.actions,...row.actions]});
}
const rows=[];
for(const r of cases){
 const m=open(r.origin),cuts=[];let last=m.facts().turn;
 try{
  for(const [i,action] of r.steps.entries()){
   if(!m.save().session&&m.menu()[0].actorId===seat&&m.facts().turn>last){
    last=m.facts().turn;
    cuts.push({i,e:m.save(),assets:short(m),landedSaturn:m.state().planets.planets.saturn.landingMarkers.some(x=>x.playerId===seat)});
    if(cuts.length===3)break;
   }
   m.apply(action);
  }
  assert.equal(cuts.length,3);
  console.log(JSON.stringify([r.id,r.reserve,r.sector,cuts.map(c=>[c.assets.turn,c.assets.wallet,c.assets.established,c.assets.hand,c.landedSaturn])]));
  rows.push({...r,cuts});
 }finally{m.dispose();}
}
writeZ(out,{rows});
