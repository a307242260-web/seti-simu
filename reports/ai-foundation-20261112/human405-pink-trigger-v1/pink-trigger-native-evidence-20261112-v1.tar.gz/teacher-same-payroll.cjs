'use strict';
const {readZ,writeZ,short,open}=require('./controlled-r3'),assert=require('node:assert/strict');
const [timing,cargo,out]=process.argv.slice(2),t=readZ(timing),c=readZ(cargo),seat='player-white';
const roots=[
 ['delivered-06',t.results.rows.find(x=>x.label==='amiba-first-pink-2').settled.state],
 ['retained-07',c.holds.find(x=>x.id==='fossil_07').end3],
],rows=[];
const expected=['b_9.webp','b_60.webp'];
for(const [label,root] of roots){
 assert.equal(root.session,null);
 const m=open(root),before=m.owner(seat),state=JSON.parse(root.committedState),cards=state.cards.drawPileCardIds;
 const changes=[];
 for(const [i,id] of expected.entries()){
  const at=cards.indexOf(id);assert(at>=i,id);
  changes.push([i,at,cards[i],id]);[cards[i],cards[at]]=[cards[at],cards[i]];
 }
 const replay={...root,committedState:JSON.stringify(state)},moves=[],checks=[];
 let cp,stop;
 try{
  m.restore(replay);assert.deepEqual(m.owner(seat),before);const existing=new Set(m.player().hand.map(c=>c.cardId));
  moves.push(m.act('pass'));
  if(m.menu()[0].actorId!==seat)m.advanceOpponents(moves);
  moves.push(m.act('choose_card',a=>a.summary==='b_111.webp'));
  if(m.menu()[0].actorId!==seat)m.advanceOpponents(moves);
  const opening=short(m),salary=opening.hand.filter(id=>!existing.has(id)&&id!=='b_111.webp');
  assert.deepEqual(salary,expected);
  for(let i=0;i<190;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!==seat){m.advanceOpponents(moves);continue;}
   const q=m.automatic(cp);
   if(!q.complete||!q.a||q.n>256||q.ms>600){stop={gate:{action:q.a?.summary,n:q.n,ms:q.ms}};break;}
   cp=q.checkpoint;checks.push({n:q.n,ms:q.ms});moves.push(m.apply(q.a));
  }
  assert(stop);const end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore??null;
  m.restore(replay);moves.forEach(m.apply);assert.deepEqual(m.save(),end);
  const peak=[Math.max(0,...checks.map(x=>x.n)),Math.max(0,...checks.map(x=>x.ms))];
  rows.push({label,root,replay,changes,opening,terminal,stop,peak,moves,checks,end});
  console.log(JSON.stringify({label,terminal,stop,peak,opening}));
 }finally{m.dispose();}
}
writeZ(out,{rows});
