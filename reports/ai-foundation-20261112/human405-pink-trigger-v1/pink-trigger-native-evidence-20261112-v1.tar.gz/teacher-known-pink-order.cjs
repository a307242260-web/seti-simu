'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3'),path=require('node:path');
const [from,to]=process.argv.slice(2),study=readZ(from),V=require(path.resolve('randomizer/game/ai/state-value')),seat='player-white',rows=[];
for(const label of ['amiba-first-pink-1','dlc-first-pink-1']){
 const branch=study.results.rows.find(x=>x.label===label);
 for(const blue of label.startsWith('amiba')?['blue_3']:['blue_3','blue_1']){
  const root=branch.checkpoints['after-pink'].state,m=open(root),actions=[];
  const pick=x=>m.menu().find(a=>typeof x==='string'?a.summary===x:x.test(a.summary));
  const apply=x=>{const a=pick(x);assert(a,JSON.stringify(m.menu().map(a=>a.summary)));actions.push(m.apply(a));};
  const end=()=>{apply('结束回合');if(pick('标记 B'))apply('标记 B');};
  try{
   apply(/^获得展示的低重力研究$/);
   if(pick('结算 amiba_0.webp'))apply('结算 amiba_0.webp');
   end();
   if(label.startsWith('dlc')){
    apply('amiba_0.webp');apply(new RegExp('^'+blue));
    for(const slot of [5,6]){apply('放置数据');apply(new RegExp('放置位 '+slot+'$'));}
    end();
   }
   const endState=m.save(),o=m.owner(seat),v=V.evaluateStateValue(o,seat),assets=short(m);
   m.restore(root);actions.forEach(m.apply);assert.deepEqual(m.save(),endState);
   rows.push({label,blue,root,endState,v,assets,actions});
   console.log(JSON.stringify({label,blue,v,assets,actions:actions.map(a=>a.summary)}));
  }catch(err){rows.push({label,blue,error:String(err),actions});console.log(JSON.stringify({label,blue,error:String(err)}));}
  finally{m.dispose();}
 }
}
writeZ(to,{rows});
