'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short,runCases}=require('./controlled-r3');
const [from,to]=process.argv.slice(2),study=readZ(from),branch=study.results.rows.find(r=>r.label==='amiba-first-pink-2'),seat='player-white';
const m=open(study.source);branch.prefix.forEach(m.apply);
const at=branch.actions.findIndex(x=>x.action.target?.fossilId==='fossil_06');
assert(at>0);branch.actions.slice(0,at).forEach(x=>m.apply(x.action));
const root=m.save(),before=short(m),choice=m.automatic();
const gate=q=>q.complete&&q.a&&q.n<=256&&q.ms<=600;
assert(gate(choice));m.dispose();
const fit=runCases(root,[['07-autonomous-after-pick',({act})=>act('choose_target',a=>a.target.fossilId==='fossil_07')]]);
const holds=[];
for(const id of ['fossil_06','fossil_07']){
 const m=open(root),moves=[],take=a=>{assert(a);moves.push(m.apply(a));},checks=[],r4=[];
 try{
  take(m.menu().find(a=>a.target?.fossilId===id));
  take(m.menu().find(a=>a.family==='complete_task'&&a.summary==='完成 b_117.webp'));
  take(m.menu().find(a=>a.family==='end_turn'));
  const beforePass=short(m),end3=m.save();assert.equal(m.facts().probes[0]?.fossilId,id);
  assert(m.menu().some(a=>a.family==='pass'));
  take(m.menu().find(a=>a.family==='pass'));
  if(m.menu()[0].actorId!==seat)m.advanceOpponents(moves);
  take(m.menu().find(a=>a.family==='choose_card'&&a.summary==='b_111.webp'));
  if(m.menu()[0].actorId!==seat)m.advanceOpponents(moves);
  const start4=short(m),round4Root=m.save();
  let cp,stop,ownTurns=0;
  for(let i=0;i<150;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!==seat){m.advanceOpponents(moves);continue;}
   const q=m.automatic(cp);
   if(!gate(q)){stop={gate:{a:q.a?.summary,n:q.n,ms:q.ms,complete:q.complete}};break;}
   checks.push({a:q.a.summary,n:q.n,ms:q.ms});cp=q.checkpoint;
   const closed=q.a.family==='end_turn';take(q.a);
   if(closed){r4.push(short(m));ownTurns++;}
  }
  assert(stop);const end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore??null;
  m.restore(root);moves.forEach(m.apply);assert.deepEqual(m.save(),end);
  const row={id,beforePass,end3,round4Root,start4,r4,terminal,stop,moves,checks,end};holds.push(row);
  console.log(JSON.stringify({id,beforePass,terminal,stop,firstR4:r4[0],peak:[Math.max(0,...checks.map(x=>x.n)),Math.max(0,...checks.map(x=>x.ms))]}));
 }finally{m.dispose();}
}
writeZ(to,{root,before,choice:{a:choice.a.summary,n:choice.n,ms:choice.ms,roots:choice.roots},fit,holds});
