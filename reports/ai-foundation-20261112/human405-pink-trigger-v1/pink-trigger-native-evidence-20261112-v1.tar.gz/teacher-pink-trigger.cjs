'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short,runCases}=require('./controlled-r3'),path=require('node:path');
const [from,to]=process.argv.slice(2),study=readZ(from),V=require(path.resolve('randomizer/game/ai/state-value')),seat='player-white';
const a=study.results.rows.find(x=>x.label==='amiba-first-pink-2'),b=study.results.rows.find(x=>x.label==='dlc-first-pink-2');
const source=a.checkpoints['after-pink'].state,m=open(source),q=m.automatic();
assert(q.complete&&q.n<=256&&q.ms<=600);
const byName=(m,name)=>m.menu().find(x=>typeof name==='string'?x.summary===name:name.test(x.summary));
const facts=(m)=>{const o=m.owner(seat);return{...short(m),V:V.evaluateStateValue(o,seat).total,traces:o.publicState.board.aliens.slots,active:m.state().turn.activePlayerIds,passed:m.state().turn.passedPlayerIds,rng:m.facts().rng};};
m.dispose();
const skip=runCases(source,[['skip-one-trigger',({m,take,cut})=>{take(m.apply(byName(m,'跳过')));cut('after-trigger');}]]);
const pairs=[];
for(const [label,branch] of [['amiba-then-dlc',a],['dlc-then-amiba',b]]){
 const m=open(branch.checkpoints['after-pink'].state),state=m.save(),sequence=[],apply=name=>{const action=byName(m,name);assert(action,JSON.stringify(m.menu().map(x=>x.summary)));sequence.push(m.apply(action));};
 try{
  if(label==='amiba-then-dlc')apply('结算 amiba_0.webp');
  apply('结束回合');if(byName(m,'标记 B'))apply('标记 B');
  if(label==='dlc-then-amiba'){
   apply('amiba_0.webp');apply(/^blue_3/);
   for(const slot of [5,6]){apply('放置数据');apply(new RegExp('放置位 '+slot+'$'));}
   apply('结束回合');if(byName(m,'标记 B'))apply('标记 B');
  }
  const end=m.save(),assets=facts(m);m.restore(state);sequence.forEach(m.apply);assert.deepEqual(m.save(),end);
  pairs.push({label,origin:state,sequence,end,assets});
  console.log(JSON.stringify({label,assets,sequence:sequence.map(x=>x.summary)}));
 }catch(err){pairs.push({label,origin:state,sequence,error:String(err),assets:facts(m)});console.log(JSON.stringify({label,error:String(err)}));}finally{m.dispose();}
}
let matched=null;
if(pairs.every(p=>p.end))matched=runCases(pairs[1].end,[['matched-dlc-then-amiba',()=>{}]]);
writeZ(to,{source,triggerDecision:{n:q.n,ms:q.ms,roots:q.roots},skip,pairs,matched});
