'use strict';
const {readZ,writeZ,short,open}=require('./controlled-r3'),assert=require('node:assert/strict');
const [timing,cargo,out]=process.argv.slice(2),t=readZ(timing),c=readZ(cargo),seat='player-white',rows=[];
for(const [label,e] of [
 ['standard',t.results.rows.find(x=>x.label==='dlc-first-pink-1')],
 ['delivered-06',t.results.rows.find(x=>x.label==='amiba-first-pink-2')],
 ['delivered-07',c.fit.rows[0]],
]){
 const m=open(e.end),moves=[],checks=[],start=short(m),r4=[];
 let cp,stop;assert.equal(m.facts().round,4);
 try{
  for(let i=0;i<190;i++){
   if(m.state().turn.gameEnded){stop='terminal';break;}
   if(m.menu()[0].actorId!==seat){m.advanceOpponents(moves);continue;}
   const q=m.automatic(cp);
   if(!q.complete||!q.a||q.n>256||q.ms>600){stop={gate:{action:q.a?.summary,n:q.n,ms:q.ms}};break;}
   if(q.a.family==='pass')r4.push({ending:short(m)});
   cp=q.checkpoint;checks.push({n:q.n,ms:q.ms});moves.push(m.apply(q.a));
  }
  assert(stop);const end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore??null;
  m.restore(e.end);moves.forEach(m.apply);assert.deepEqual(m.save(),end);
  const peak=[Math.max(0,...checks.map(x=>x.n)),Math.max(0,...checks.map(x=>x.ms))];
  rows.push({label,start,root:e.end,r4,terminal,stop,peak,moves,checks,end});
  console.log(JSON.stringify({label,terminal,stop,peak,start,r4}));
 }finally{m.dispose();}
}
writeZ(out,{rows});
