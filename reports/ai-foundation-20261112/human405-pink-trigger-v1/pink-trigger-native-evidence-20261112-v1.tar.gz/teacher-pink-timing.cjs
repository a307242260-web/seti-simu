'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {readZ,writeZ,open,short,runCases}=require('./controlled-r3');
const [record,legacy,out]=process.argv.slice(2),old=readZ(legacy),read=f=>JSON.parse(fs.readFileSync(f)),ref=read(record);
const c=read(ref.roundEnds[1].checkpointPath),replay=read(ref.savePath).replaySteps.map(x=>x.action);
const m=open(c.coreState.compositionEnvelope);
replay.slice(c.replayCursor.stepIndex,171).forEach(m.apply);
const root=m.save(),cuts=[];
function diff(a,b,at='',out=[]){
 if(a===b||out.length>=16)return out;
 if(!a||!b||typeof a!=='object'||typeof b!=='object'){out.push([at,typeof a==='object'?null:a,typeof b==='object'?null:b]);return out;}
 for(const k of new Set([...Object.keys(a),...Object.keys(b)]))diff(a[k],b[k],at+'/'+k,out);
 return out;
}
const delta=diff({...root,committedState:JSON.parse(root.committedState)},{...old.origin,committedState:JSON.parse(old.origin.committedState)});
console.log(JSON.stringify({delta}));
const gate=q=>q.complete&&q.a&&q.n<=256&&q.ms<=600;
const summarize=(p,q)=>({action:q.a.summary,value:q.value,n:q.n,ms:q.ms,roots:q.roots.filter(r=>r.value!=null).map(r=>({action:p.menu().find(a=>a.actionId===r.actionId)?.summary,v:r.value}))});
const r=m.automatic();assert(gate(r));console.log(JSON.stringify({root:short(m),comparison:summarize(m,r)}));m.dispose();
const cases=[];
for(const order of ['dlc-first','amiba-first'])for(const slot of [1,2]){
 cases.push([order+'-pink-'+slot,({m,take,act,cut})=>{
  const before=order==='dlc-first'?replay.slice(171,174):old.timeline.slice(0,10);
  for(const a of before)take(m.apply(a));
  const q=m.automatic();assert(gate(q));const s=summarize(m,q);
  cuts.push({order,slot,source:m.save(),assets:short(m),comparison:s,menu:m.menu()});
  act('choose_target',a=>a.target.alienSlotId===slot&&a.target.traceType==='pink'&&(slot!==1||a.target.position===4));
  cut('after-pink');
 }]);
}
const results=runCases(root,cases);writeZ(out,{source:root,roots:cuts,results});
