'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,short}=require('./controlled-r3');
const k=require(path.resolve('randomizer/game/production-kernel')),seat='player-white';
const screen=readZ(__dirname+'/late-movement-cohort-0852ceb0-20261112-v2.json.gz').rows.find(r=>r.board===13);
const m=open(screen.root);
function auto(prefix){
 const start=m.save(),assets=short(m),actions=[],checks=[],main=[];let stop,checkpoint;
 for(let i=0;i<250;i++){
  if(m.state().turn.gameEnded){stop={kind:'terminal'};break;}
  if(m.menu()[0].actorId!==seat){m.advanceOpponents(actions);continue;}
  const u=m.automatic(checkpoint),a=u.a,x={n:u.n,ms:u.ms,complete:u.complete,value:u.value,family:a?.family,target:a?.target,a:a?.summary};
  if(!a||!u.complete||u.n>256||u.ms>600){stop={kind:'gate',...x,root:m.save()};break;}
  if(a.phase==='main')main.push([m.facts().round,m.facts().turn,a.family,a.summary,a.target]);
  checkpoint=u.checkpoint;checks.push(x);actions.push(m.apply(a));
 }
 assert(stop);
 const end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore;
 m.restore(screen.root);[...prefix,...actions].forEach(m.apply);assert.deepEqual(m.save(),end);
 return {start,assets,actions,checks,main,stop,terminal,end,peak:[Math.max(0,...checks.map(x=>x.n)),Math.max(0,...checks.map(x=>x.ms))]};
}
try{
 const recorded=readZ(__dirname+'/board13-movement-timing-0852ceb0-20261112-v1.json.gz');
 const control=recorded.rows.find(r=>r.id==='none'),b=screen.branches.find(x=>x.move.target.deltaY===1);
 const route=()=>k.getProbeRouteRequirements(m.state(),seat).candidates.find(r=>r.rocketId===3&&r.planetId==='uranus'&&r.endpointFamily==='orbit');
 const controlEnd=control.actions.findIndex(a=>a.family==='orbit');
 assert.equal(controlEnd,19);
 m.restore(control.start);control.actions.slice(0,24).forEach(m.apply);
 const cut0={summary:short(m),rng:m.facts().rng,save:m.save()};
 m.restore(b.cur.start);const fixed=[...b.cur.actions];
 for(const a of control.actions.slice(0,7))fixed.push(m.apply(a));
 fixed.push(m.act('end_turn'));
 if(m.menu()[0].actorId!==seat)m.advanceOpponents(fixed);
 assert.equal(m.facts().turn,5);
 const root=m.save(),available=short(m),go=route();
 for(const step of go.path){
  fixed.push(m.act('move',a=>a.target.rocketId===3&&a.target.deltaX===step.deltaX&&a.target.deltaY===step.deltaY));
  fixed.push(m.act('choose_payment',a=>a.target.choiceId==='energy'));
 }
 for(const a of control.actions.slice(controlEnd,24))fixed.push(m.apply(a));
 const cut1={summary:short(m),rng:m.facts().rng,save:m.save()};
 assert.deepEqual(cut1.rng,cut0.rng);
 for(const key of ['income','tech','established','hand','computer','blue','market'])assert.deepEqual(cut1.summary[key],cut0.summary[key]);
 const result=auto(fixed);
 console.log(JSON.stringify({available,route:go.required,wallet0:cut0.summary.wallet,wallet1:cut1.summary.wallet,terminal:result.terminal,peak:result.peak,stop:{...result.stop,root:undefined},main:result.main}));
 writeZ(process.argv[2],{root,cut0,cut1,fixed,available,route:go,...result});
}finally{m.dispose();}
