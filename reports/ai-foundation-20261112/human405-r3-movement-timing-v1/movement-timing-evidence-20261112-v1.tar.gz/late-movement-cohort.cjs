'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),{open,short,writeZ}=require('./controlled-r3');
const K=require(path.resolve('randomizer/game/production-kernel')),seat='player-white';
const read=f=>JSON.parse(fs.readFileSync(f));
const source='reports/iteration/free-analyze-random20-funded-planet-20261111/summary-463fc442-20261111.json';
const records=read(source).rows,rows=[];
const routes=m=>K.getProbeRouteRequirements(m.state(),seat).candidates
 .filter(r=>r.rocketId!==null&&r.rocketId!==undefined)
 .map(r=>({id:r.requirementId,rocket:r.rocketId,e:r.required.energy,c:r.required.credits,s:r.targetBenefit.score,path:r.path}));
for(const record of records){
 const rec=read('reports/research/'+record.f),c=rec.roundEnds.find(x=>x.round===3),root=read(c.checkpointPath).coreState.compositionEnvelope;
 const m=open(root);
 try{
  const at3=short(m),menu=m.menu();
  const eligible=menu.filter(a=>a.actorId===seat&&a.family==='move');
  let branches=[];
  if(eligible.length&&at3.wallet[2]>0){
   const rv=read(rec.savePath).replaySteps.slice(c.beforeInput-1,c.beforeInput+15)
    .find(x=>x.action.actorId===seat&&x.action.target?.kind==='pass-reserve-card')?.action.target.cardId;
   assert(rv);
   function pass(actions,fixed){
    actions.push(m.act('pass'));
    if(m.menu()[0].actorId!==seat)m.advanceOpponents(actions);
    assert.equal(m.menu()[0].target.kind,'pass-reserve-card');
    const pick=m.menu().find(a=>!fixed||a.target.cardId===fixed);
    assert(pick);
    actions.push(m.apply(pick));
    if(m.menu()[0].actorId!==seat)m.advanceOpponents(actions);
    assert.equal(m.facts().round,4);
    return {actions,pick:pick.target.cardId,open4:short(m),rng:m.facts().rng,routes:routes(m),start:m.save()};
   }
   const base=pass([],rv);
   branches=eligible.flatMap(move=>{
    m.restore(root);const actions=[m.apply(move)];
    const pay=m.menu().find(a=>a.family==='choose_payment'&&a.target.choiceId==='energy');
    if(!pay)return [];
    actions.push(m.apply(pay));const at=short(m),cost=at3.wallet[2]-at.wallet[2];
    assert(cost>0);
    const cur=pass(actions,base.pick);
    assert.deepEqual(cur.rng,base.rng);
    const r0=new Map(base.routes.map(r=>[r.id,r])),b=base.open4.wallet,v=cur.open4.wallet;
    const saving=cur.routes.filter(r=>r.rocket===move.target.rocketId&&r0.has(r.id))
      .flatMap(r=>{const old=r0.get(r.id),saved=old.e-r.e-cost;
        if(saved<=0)return [];
        return [{id:r.id,saved,requiredBefore:old.e,requiredAfter:r.e,score:r.s,
          unlock:v[2]>=r.e&&v[1]>=r.c&&b[2]<old.e&&b[1]>=old.c}];
      });
    return [{move,at,cost,saving,cur}];
   });
   rows.push({board:record.board,officialScore:record.score,at3,root,base,branches});
  }else rows.push({board:record.board,officialScore:record.score,at3,branches});
 }finally{m.dispose();}
}
writeZ(process.argv[2],{source,rows});
for(const r of rows)console.log(JSON.stringify({board:r.board,score:r.officialScore,remainingEnergy:r.at3.wallet[2],probes:r.at3.probes,paidMoves:r.branches.length,saving:r.branches.flatMap(b=>b.saving.map(s=>[b.move.summary,s.id,s.saved,s.unlock,s.score]))}));
