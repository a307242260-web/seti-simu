'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,writeZ,short}=require('./controlled-r3');
const k=require(path.resolve('randomizer/game/production-kernel')),seat='player-white';
const screen=readZ(__dirname+'/late-movement-cohort-0852ceb0-20261112-v2.json.gz').rows.find(r=>r.board===13);
const m=open(screen.root);
function auto(prefix){
 const start=m.save(),assets=short(m),actions=[],checks=[],main=[];let stop,checkpoint;
 for(let i=0;i<250;i++){
  if(m.state().turn.gameEnded){stop={kind:'terminal'};break;}
  if(m.menu()[0].actorId!==seat){m.advanceOpponents(actions);continue;}
  const u=m.automatic(checkpoint),a=u.a,x={n:u.n,ms:u.ms,complete:u.complete,value:u.value,family:a?.family,target:a?.target,a:a?.summary};
  if(!a||!u.complete||u.n>256||u.ms>600){stop={kind:'gate',...x,root:m.save()};break;}
  if(a.phase==='main')main.push([m.facts().round,m.facts().turn,a.family,a.summary,a.target]);
  checkpoint=u.checkpoint;checks.push(x);actions.push(m.apply(a));
 }
 assert(stop);
 const end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore;
 m.restore(screen.root);[...prefix,...actions].forEach(m.apply);assert.deepEqual(m.save(),end);
 return {start,assets,actions,checks,main,stop,terminal,end,peak:[Math.max(0,...checks.map(x=>x.n)),Math.max(0,...checks.map(x=>x.ms))]};
}
try{
 const b=screen.branches.find(x=>x.move.target.deltaY===1);
 const openAfter=()=>{
  m.restore(screen.base.start);
  const q=m.menu().find(a=>a.family==='move'&&a.target.rocketId===3&&a.target.deltaY===1);
  if(!q)return null;
  const actions=[...screen.base.actions,m.apply(q),m.act('choose_payment',a=>a.target.choiceId==='energy')];
  return {actions,start:m.save()};
 };
 const rows=[];
 const after=openAfter();
 for(const [id,state,prefix] of [['none',screen.base.start,screen.base.actions],['before',b.cur.start,b.cur.actions],...(after?[['after',after.start,after.actions]]:[])]){
  m.restore(state);const result=auto(prefix);rows.push({id,prefix,...result});
  console.log(JSON.stringify({id,assets:result.assets,first:result.checks[0],stop:{...result.stop,root:undefined},terminal:result.terminal,peak:result.peak,main:result.main}));
 }
 writeZ(process.argv[2],{source:screen,rows});
}finally{m.dispose();}
