from collections import Counter
from pathlib import Path
import gzip, json, sys
w, out = map(Path, sys.argv[1:])
source = w / 'source'
read=lambda p: json.loads(p.read_text())
rec=lambda n: read(source/'reports/research'/n)
corpus = read(source/'reports/iteration/free-analyze-random20-funded-planet-20261111/summary-463fc442-20261111.json')
def compact(x):
    return dict(score=x['score'], established=x['projectedFinalScore'], cash=x['resources']['credits'],energy=x['resources']['energy'], publicity=x['resources']['publicity'], data=x['resources']['availableData'], hand=x['hand'], income=x['income'], tech=x['technology'], probes=x['probes'], sectorWins=x['sectorWins'],scan=x['scanProgress'],computer=[t['placementSlot'] for t in x['data']['placedTokens'] if t['placementKind']=='computer'], blue=[t['blueSlot'] for t in x['data']['placedTokens'] if t['placementKind']=='blueBonus'],marks={k:[m['threshold'] for m in v['marks'] if m['playerId']=='player-white'] for k,v in x['finalScoring']['tiles'].items()}, traceSlots=x['alienTraceSlots'])
def white_final(state):
    p=next(p for p in state['players']['players'] if p['id']=='player-white')
    return {'scores': p['finalScoreBreakdown'], 'resources':p['resources'], 'hand':[c['cardId'] for c in p['hand']], 'played':[c['cardId'] for c in p.get('playedCards',[])]}
def ledger(label,n):
    r=rec(n); s=read(source/r['savePath']); actions=[x['action'] for x in s['replaySteps']]
    cut=r['roundEnds'][2]['beforeInput']; first=r['roundEnds'][1]['beforeInput']
    white=lambda seq: [(i+1,a) for i,a in seq if a['actorId']=='player-white']
    rounds={'r3':white(enumerate(actions[first-1:cut-1],first-1)), 'r4':white(enumerate(actions[cut-1:],cut-1))}
    state=json.loads(s['committedState'])
    return dict(label=label,record=n,sourceTerminal=r['terminal'],r2=compact(r['roundEnds'][1]),r3=compact(r['roundEnds'][2]),r4=compact(r['roundEnds'][3]) if r['terminal'] else None,terminal=white_final(state) if r['terminal'] else None,
        actionCounts={k:dict(Counter(a['family'] for _,a in v)) for k,v in rounds.items()},marks=[(i,a['target']['tileId']) for seq in rounds.values() for i,a in seq if (a.get('target') or {}).get('choiceId','').startswith('final:')],
        r3end=[(i,a['family'],a['summary']) for i,a in rounds['r3'][-15:]], r4main=[(i,a['family'],a['summary']) for i,a in rounds['r4'] if a['phase']=='main'])
rows=[ledger(r['board'],r['f']) for r in corpus['rows']]
extras=[ledger('09 verified new', '9f89c9c8.ff577dea.full.json'), ledger('11 verified new','3db2d755.d74f5aed.full.json'), ledger('standard','1db636c6.d74f5aed.quick-400.json')]
with gzip.open(w/'teacher-visible-transport-20261112/teacher-income-replay-v454-20261112-v1.json.gz') as f: teacher=json.load(f)['final']
out.write_text(json.dumps(dict(baseline=rows,comparisons=extras,teacher=teacher),ensure_ascii=False,indent=2)+'\n')
for x in [*rows,*extras]:
 a,b,t=x['r3'],x['r4'],x['terminal']
 if b:
    s=t['scores']
    print(x['label'],f"R3={a['score']}/{a['established']}",f"R4={b['score']}/{s['totalScore']}",'fin tile/card',s['tileScore'],s['cardScore'],'paid:',b['cash'],b['energy'],'pool:',b['data'],'computer',b['computer'],'hand',len(b['hand']),'tech',len(b['tech']['ownedTiles']),'r4 actions',[f'{k}:{x["actionCounts"]["r4"].get(k,0)}' for k in ('analyze','scan','research_tech','play_card','land','orbit')])
 else: print(x['label'],a['score'],a['established'])
