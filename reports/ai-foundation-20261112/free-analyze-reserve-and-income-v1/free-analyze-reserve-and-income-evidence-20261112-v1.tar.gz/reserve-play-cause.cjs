'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [source,out,altFam]=process.argv.slice(2),seat='player-white',rows=[];
const data=readZ(source), branch=data.rows.find(x=>x.card==='b_32.webp');
const m=open(branch.root);
try{
 const index=branch.actions.findIndex(a=>a.actorId===seat&&a.family==='play_card'&&a.summary==='b_32.webp');assert(index>0);
 branch.actions.slice(0,index).forEach(m.apply);
 const root=m.save(),q=m.automatic();assert(q.complete&&q.n<=256&&q.ms<=600);assert.equal(q.a.actionId,branch.actions[index].actionId);
 const s=short(m),menu=m.menu();
 const alternatives=menu.filter(x=>x.family===(altFam==='fill-analyze'?'place_data':altFam));
 if(!alternatives.length) console.log(JSON.stringify({case:data.caseLabel,infeasible:altFam,s,legal:menu.map(a=>[a.family,a.summary])}));
 for(const a of alternatives){
  m.restore(root);const actions=[m.apply(a)],checks=[],turns=[];let cp,stop;
  if(altFam==='fill-analyze'){
    actions.push(m.act('choose_target',a=>a.target.choiceId==='data:computer'));
    assert.equal(m.facts().computer.length,6);actions.push(m.act('analyze'));
  }
  for(let i=0;i<240;i++){
   if(m.state().turn.gameEnded){stop={kind:'terminal'};break;}
   if(m.menu()[0].actorId!==seat){m.advanceOpponents(actions);continue;}
   const u=m.automatic(cp),b=u.a,k={n:u.n,ms:u.ms,complete:u.complete,value:u.value,a:b?.summary};
   if(!u.complete||!b||u.n>256||u.ms>600){stop={kind:'gate',...k,root:m.save()};break;}
   if(b.phase==='main'&&b.family!=='pass')turns.push([m.facts().turn,b.family,b.summary]);
   cp=u.checkpoint;checks.push(k);actions.push(m.apply(b));
  }
  assert(stop);const end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)??null;
  m.restore(root);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  rows.push({a,end,terminal,stop,actions,checks,turns});
  const {root:_,...info}=stop;console.log(JSON.stringify({case:data.caseLabel,alternative:a.summary,terminal:terminal?.totalScore,original:branch.terminal?.totalScore,s,info,turns}));
 }
 writeZ(out,{source,case:data.caseLabel,root,s,q:{a:q.a,roots:q.roots,lines:q.lines,n:q.n,ms:q.ms,value:q.value},menu,rows});
}finally{m.dispose();}
