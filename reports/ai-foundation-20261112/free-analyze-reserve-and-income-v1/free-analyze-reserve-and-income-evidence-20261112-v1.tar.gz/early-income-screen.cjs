'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{open,short,writeZ}=require('./controlled-r3');
const cards=require(path.resolve('randomizer/game/cards/deck'));
const [summary,out]=process.argv.slice(2),seat='player-white';
const read=p=>JSON.parse(fs.readFileSync(p)),rec=f=>read('reports/research/'+f);
const rows=read(summary).rows.map(({board,f})=>({board,f}));
rows.push({board:'standard',f:'1db636c6.d74f5aed.quick-400.json'});
const all=[];
for(const {board,f} of rows){
 const r=rec(f),save=read(r.savePath),actions=save.replaySteps.map(s=>s.action),initial=read(r.roundEnds[0].checkpointPath),limits=r.roundEnds[1].beforeInput;
 const m=open(initial.coreState.compositionEnvelope),choices=[],switches=[];
 try{
  for(let i=initial.replayCursor.stepIndex;i<limits-1;i++){
   const a=actions[i],target=a.target;
   if(a.actorId===seat&&a.family==='choose_card'&&target?.choiceId?.startsWith('income:')){
    const p=m.player(),choicesNative=m.menu().filter(x=>x.family==='choose_card'&&x.target?.choiceId?.startsWith('income:')),hist=r.metrics.searches.find(x=>x.step===i+1);
    const options=choicesNative.map(x=>{
     const c=p.hand.find(c=>c.id===x.target.choiceId.slice(7));
     assert(c, x.target.choiceId);return {id:x.actionId,card:c.cardId,gain:cards.getIncomeGainForCard(c),q:hist?.roots.find(k=>k.actionId===x.actionId)?.value};
    }),selected=options.find(x=>x.id===a.actionId);assert(selected);
    const entry={input:i+1,selected,options,assets:short(m)};
    choices.push(entry);
    if(!selected.gain?.credits&&options.some(x=>x.gain?.credits)){
      switches.push({...entry,root:m.save(),sourceChoice:a.actionId});
    }
   }
   m.apply(a);
  }
  assert.equal(m.facts().round,2);
  const end=read(r.roundEnds[1].checkpointPath);assert.deepEqual(m.save(),end.coreState.compositionEnvelope);
  all.push({board,f,choices,switches});
  if(switches.length)console.log(JSON.stringify({board,choices:switches.map(x=>[x.input,x.selected.card,x.selected.gain,x.assets.wallet.slice(1),x.options.filter(y=>y.gain?.credits).map(y=>[y.card,y.q])])}));
 }finally{m.dispose();}
}
writeZ(out,{rows:all});
