'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [record,boardArg,out,swapArg]=process.argv.slice(2),seat='player-white',board=Number(boardArg);
const read=p=>JSON.parse(fs.readFileSync(p)),r=read('reports/research/'+record),cut=r.roundEnds[1],original=read(cut.checkpointPath).coreState.compositionEnvelope,rows=[];
const swap=swapArg?.split(',').map(Number);
let root=original;
if(swap){
 assert.equal(root.session,null);
 const s=JSON.parse(root.committedState),d=s.cards.drawPileCardIds,[i,j]=swap;
 assert(i!==j&&d[i]&&d[j]);[d[i],d[j]]=[d[j],d[i]];
 root={...root,committedState:JSON.stringify(s)};
}
{
 const m=open(root);
 try{
  const q=m.automatic(),offers=m.menu().filter(a=>['pass','scan'].includes(a.family));
  assert(q.complete&&q.n<=256&&q.ms<=600&&q.a.family==='pass');
  assert.equal(offers.length,2);
  if(swap){
   const t=open(original),base=readZ(out.replace(/-swap-[0-9,]+/,'')).rows[0].decision;
   try{assert.deepEqual(m.owner(seat),t.owner(seat));assert.deepEqual(m.menu(),t.menu());}
   finally{t.dispose();}
   assert.equal(JSON.stringify(q.roots),JSON.stringify(base.roots));
   assert.deepEqual([q.a.actionId,q.n,q.value],[base.a.actionId,base.n,base.value]);
  }
  const entry={root,input:cut.beforeInput,sourceChoice:q.a.actionId};
  for(const offer of offers){
   m.restore(entry.root);const first=offer;assert(first);
   const roundEnds=first.family==='pass'?{2:{summary:short(m),state:m.save()}}:{};
   const actions=[m.apply(first)],checks=[];let cp,stop;
   for(let i=0;i<350;i++){
    if(m.state().turn.gameEnded){stop={kind:'terminal'};break;}
    if(m.menu()[0].actorId!==seat){m.advanceOpponents(actions);continue;}
    const a=m.automatic(cp),b=a.a,x={n:a.n,ms:a.ms,complete:a.complete,value:a.value,a:b?.summary};
    if(!a.complete||!b||a.n>256||a.ms>600){stop={kind:'gate',...x,root:m.save(),round:m.facts().round};break;}
    if(b.family==='pass')roundEnds[m.facts().round]={summary:short(m),state:m.save()};
    cp=a.checkpoint;checks.push(x);actions.push(m.apply(b));
   }
   assert(stop);const end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore??null;
   m.restore(entry.root);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
   const peak=[Math.max(...checks.map(x=>x.n),0),Math.max(...checks.map(x=>x.ms),0)];
   rows.push({input:entry.input,offer,recorded:offer.actionId===entry.sourceChoice,root:entry.root,decision:{a:q.a,roots:q.roots,n:q.n,ms:q.ms,value:q.value},roundEnds,end,actions,checks,peak,terminal,stop});
   const {root:_,...state}=stop;
   console.log(JSON.stringify({board,swap,input:entry.input,offer:offer.summary,automatic:q.a?.summary,rounds:Object.entries(roundEnds).map(([k,x])=>[k,x.summary.wallet[0],x.summary.established,x.summary.income,x.summary.hand.length]),terminal,peak,stop:state}));
  }
 }finally{m.dispose();}
}
writeZ(out,{board,swap,rows});
