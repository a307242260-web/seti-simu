'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [w,caseLabel,out,swapArg]=process.argv.slice(2),seat='player-white';
const cases={9:'9f89c9c8.ff577dea.full.json',19:'493d2e1d.463fc442.full.json',7:'a11ac91b.463fc442.full.json',8:'ae6327ad.463fc442.full.json',standard:'1db636c6.d74f5aed.quick-400.json'};
const read=p=>JSON.parse(fs.readFileSync(p)),reserve=a=>a?.actorId===seat&&a.target?.kind==='pass-reserve-card';
const record=cases[caseLabel]?read('reports/research/'+cases[caseLabel]):null;
const teacher=record?null:readZ(w+'/teacher-visible-transport-20261112/teacher-income-replay-v454-20261112-v1.json.gz');
const cut=record?read(record.roundEnds[2].checkpointPath):null;
const originalOpening=record?cut.coreState.compositionEnvelope:teacher.end;
const swap=swapArg?.split(',').map(Number);
let opening=originalOpening,control;
if(swap){
  assert.equal(opening.session,null);
  const s=JSON.parse(opening.committedState), d=s.cards.drawPileCardIds, [i,j]=swap;
  assert(i!==j&&d[i]&&d[j]); [d[i],d[j]]=[d[j],d[i]];
  opening={...opening,committedState:JSON.stringify(s)};
  control=readZ(out.replace(/-swap-[0-9,]+/,''));
}
const m=open(opening),before=[];
if(swap){
 const v=open(originalOpening);
 try{assert.deepEqual(m.owner(seat),v.owner(seat));assert.deepEqual(m.menu(),v.menu());}
 finally{v.dispose();}
}
try{
 let recordedPick;
 if(record){
  const replay=read(record.savePath).replaySteps.map(s=>s.action);
  for(const a of replay.slice(cut.replayCursor.stepIndex)){
   if(reserve(a)){recordedPick=a;break;}
   before.push(m.apply(a));
  }
 }else{
  before.push(m.act('pass'));
  if(m.menu()[0].actorId!==seat)m.advanceOpponents(before);
 }
 const root=m.save(), offers=m.menu();assert.equal(offers.length,2);assert(offers.every(reserve));
 const decision=m.automatic();assert(decision.complete&&decision.n<=256&&decision.ms<=600);
 if(control){
  const v=open(control.rows[0].root);
  try{assert.deepEqual(m.owner(seat),v.owner(seat));assert.deepEqual(m.menu(),v.menu());}
  finally{v.dispose();}
  assert.equal(decision.a.actionId,control.decision.a.actionId);
  assert.equal(JSON.stringify(decision.roots),JSON.stringify(control.decision.roots));
  assert.equal(decision.value,control.decision.value);assert.equal(decision.n,control.decision.n);
 }
 const rows=[];
 for(const a of offers){
  m.restore(root);
  const actions=[m.apply(a)],checks=[],turns=[],walletAfterPick=m.facts().wallet;
  let cp, stop, first;
  if(m.menu()[0].actorId!==seat)m.advanceOpponents(actions);
  const start=m.save(),assets=short(m),rngAtOpen=m.facts().rng;
  for(let i=0;i<260;i++){
   if(m.state().turn.gameEnded){stop={kind:'terminal'};break;}
   if(m.menu()[0].actorId!==seat){m.advanceOpponents(actions);continue;}
   const u=m.automatic(cp),b=u.a,x={n:u.n,ms:u.ms,complete:u.complete,value:u.value,a:b?.summary};
   if(i===0)first={...x,roots:u.roots};
   if(!u.complete||!b||u.n>256||u.ms>600){stop={kind:'gate',...x,root:m.save()};break;}
   if(b.phase==='main'&&b.family!=='pass')turns.push([m.facts().turn,b.family,b.summary]);
   cp=u.checkpoint;checks.push(x);actions.push(m.apply(b));
  }
  assert(stop);const end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)??null;
  m.restore(opening);[...before,...actions].forEach(m.apply);assert.deepEqual(m.save(),end);
  const peak=[Math.max(...checks.map(x=>x.n),0),Math.max(...checks.map(x=>x.ms),0)];
  rows.push({card:a.target.cardId,sourceRecordChoice:recordedPick?.actionId===a.actionId,nativePick:a,root,start,first,assets,walletAfterPick,rngAtOpen,turns,end,actions,checks,peak,terminal,stop});
  const {root:_,...stopShort}=stop;
  console.log(JSON.stringify({caseLabel,swap,pick:a.target.cardId,sourceRecordChoice:recordedPick?.actionId===a.actionId,agentChoice:decision.a.actionId===a.actionId,value:decision.value,first:first&&[first.a,first.n,first.value],turns,terminal:terminal?.totalScore,peak,stop:stopShort}));
 }
 assert.deepEqual(rows[0].rngAtOpen,rows[1].rngAtOpen);
 assert.deepEqual(rows[0].assets.wallet,rows[1].assets.wallet);
 assert.deepEqual(rows[0].assets.market,rows[1].assets.market);
 writeZ(out,{caseLabel,swap,sourceRecord:cases[caseLabel],before,decision:{a:decision.a,roots:decision.roots,n:decision.n,ms:decision.ms,value:decision.value},rows});
} finally {m.dispose();}
