'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),{open,short,readZ,writeZ}=require('./controlled-r3');
const [screen,boardArg,out]=process.argv.slice(2),seat='player-white',board=Number(boardArg);
const r=readZ(screen).rows.find(r=>r.board===board),rows=[];
for(const entry of r.switches){
 const m=open(entry.root);
 try{
  const q=m.automatic(),offers=[entry.selected,...entry.options.filter(x=>x.gain?.credits)];
  for(const offer of offers){
   m.restore(entry.root);const first=m.menu().find(x=>x.actionId===offer.id);assert(first);
   const actions=[m.apply(first)],checks=[],roundEnds={};let cp,stop;
   for(let i=0;i<350;i++){
    if(m.state().turn.gameEnded){stop={kind:'terminal'};break;}
    if(m.menu()[0].actorId!==seat){m.advanceOpponents(actions);continue;}
    const a=m.automatic(cp),b=a.a,x={n:a.n,ms:a.ms,complete:a.complete,value:a.value,a:b?.summary};
    if(!a.complete||!b||a.n>256||a.ms>600){stop={kind:'gate',...x,root:m.save(),round:m.facts().round};break;}
    if(b.family==='pass')roundEnds[m.facts().round]={summary:short(m),state:m.save()};
    cp=a.checkpoint;checks.push(x);actions.push(m.apply(b));
   }
   assert(stop);const end=m.save(),terminal=m.state().match.finalScores?.find(x=>x.playerId===seat)?.totalScore??null;
   m.restore(entry.root);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
   const peak=[Math.max(...checks.map(x=>x.n),0),Math.max(...checks.map(x=>x.ms),0)];
   rows.push({input:entry.input,offer,recorded:offer.id===entry.sourceChoice,root:entry.root,decision:{a:q.a,roots:q.roots,n:q.n,ms:q.ms,value:q.value},roundEnds,end,actions,checks,peak,terminal,stop});
   const {root:_,...state}=stop;
   console.log(JSON.stringify({board,input:entry.input,offer,automatic:q.a?.summary,rounds:Object.entries(roundEnds).map(([k,x])=>[k,x.summary.wallet[0],x.summary.established,x.summary.income,x.summary.hand.length]),terminal,peak,stop:state}));
  }
 }finally{m.dispose();}
}
writeZ(out,{board,rows});
