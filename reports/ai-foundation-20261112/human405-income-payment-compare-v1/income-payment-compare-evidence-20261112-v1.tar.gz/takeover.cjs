'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,autonomous}=require('../v460-teacher-retain-cash-card-20261112/controlled-r3');
const [file,prior,out]=process.argv.slice(2),root=readZ(file).root,m=open(root),base=readZ(prior);
try{
 const r=autonomous(m),p=Math.max(...r.actions.map(a=>a.n||0)),ms=Math.max(...r.actions.map(a=>a.ms||0));
 const divergence=r.actions.findIndex((a,i)=>base.actions[i]?.action.actionId!==a.action.actionId);
 assert.equal(divergence,54);assert.equal(r.actions[divergence].action.summary,'收入 b_14.webp');
 console.log(JSON.stringify([r.stop,r.settled?.summary,p,ms,divergence+1,r.actions.filter(x=>x.action.summary.startsWith('收入')).map(x=>x.action.summary)]));
 writeZ(out,{root,...r,p,ms,divergence});
}finally{m.dispose()}
