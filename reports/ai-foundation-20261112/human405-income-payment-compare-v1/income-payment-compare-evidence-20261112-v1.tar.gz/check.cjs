'use strict';
const assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('../v460-teacher-retain-cash-card-20261112/controlled-r3');
const [input,out]=process.argv.slice(2),rows=[];
for(const r of readZ(input).rows){
 const m=open(r.root);
 try{
  const q=m.automatic(),menu=m.menu(),quotes=q.roots.map(x=>[menu.find(a=>a.actionId===x.actionId)?.summary,x.value,x.completion]);
  assert.deepEqual(m.save(),r.root);
  console.log(JSON.stringify([r.i,q.a?.summary,q.n,q.ms,q.complete,quotes]));
  rows.push({i:r.i,root:r.root,a:q.a,n:q.n,ms:q.ms,complete:q.complete,quotes,lines:q.lines,checkpoint:q.checkpoint});
 }finally{m.dispose();}
}
writeZ(out,{rows});
