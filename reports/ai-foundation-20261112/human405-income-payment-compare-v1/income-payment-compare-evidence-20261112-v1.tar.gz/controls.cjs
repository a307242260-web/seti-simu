'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),{open,readZ,writeZ}=require('../v460-teacher-retain-cash-card-20261112/controlled-r3');
const [file,r2,r3,out]=process.argv.slice(2),v=readZ(file).rows.find(r=>r.i===55),seat='player-white',m=open(v.root),obs=m.owner(seat),rows=[];
let ref;
try{
 for(const index of [0,5,9]){
  const root=structuredClone(v.root);
  const working=root.session.session.workingState,base=root.session.session.baseState,commit=JSON.parse(root.committedState);
  if(index){
   for(const s of [working,base,commit]){
    const p=s.cards.drawPileCardIds;[p[0],p[index]]=[p[index],p[0]];
   }
   root.committedState=JSON.stringify(commit);
  }
  m.restore(root);assert.deepEqual(m.owner(seat),obs);
  const q=m.automatic();assert(q.complete&&q.n<=256&&q.ms<=600);
  assert.equal(q.a.summary,'收入 b_14.webp');
  const compact=[q.a.actionId,q.n,q.roots];
  if(ref)assert.deepEqual(compact,ref);else ref=compact;
  assert.deepEqual(m.save(),root);
  rows.push({index,root,n:q.n,ms:q.ms,chosen:q.a.summary});
 }
 const cp=JSON.parse(fs.readFileSync(r2)),e=JSON.parse(fs.readFileSync(r3));
 m.restore(cp.coreState.compositionEnvelope);
 for(const {action} of e.replaySteps.slice(cp.replayCursor.stepIndex)){
  if(action.target?.choiceId?.startsWith('income:')){
   const q=m.automatic();assert(q.complete&&q.n<=256&&q.ms<=600);
   assert.equal(q.a.actionId,action.actionId);
   rows.push({standard:action.summary,n:q.n,ms:q.ms});
  }
  m.apply(action);
 }
 assert.deepEqual(m.save(),e.coreState.compositionEnvelope);
}finally{m.dispose();}
console.log(JSON.stringify(rows.map(({root,...row})=>row)));
writeZ(out,{rows});
