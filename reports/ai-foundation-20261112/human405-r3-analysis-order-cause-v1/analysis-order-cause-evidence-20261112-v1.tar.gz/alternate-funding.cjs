'use strict';
const assert=require('node:assert/strict'),{open,short,readZ,writeZ,runCases}=require('./controlled-r3');
const data=readZ(process.argv[2]),rows=[];
for(const label of ['A5-first','blue2-first','blue3-display-DLC20']){
 const row=data.rows.find(x=>x.label===label),e=row.terminalBeforePayment.e;
 const m=open(e);
 let market;
 try{
  market=short(m).market;
  console.log(JSON.stringify({label,market,assets:short(m),company:m.menu().some(a=>a.family==='industry'),buy:m.menu().some(a=>a.target?.tradeId==='publicity-for-card')}));
 }finally{m.dispose();}
 const c=market.includes('dlc_15.png')?'dlc_15.png':'dlc_17.png';
 const supply=(h,kind)=>{
  if(kind==='swap'){
   for(const a of h.m.swap(label==='blue3-display-DLC20'?'dlc_20.png':'amiba_9.webp',c))h.take(a);
  }else{
   h.act('quick_trade',a=>a.target.tradeId==='publicity-for-card');h.take(h.m.pick(c));
  }
  h.cut('got-data-payer');
 };
 function settle(h){
  for(const id of [c,'dlc_17.png','amiba_2.webp'].filter((c,i,a)=>a.indexOf(c)===i)){
   if(h.m.player().hand.some(x=>x.cardId===id))h.take(h.m.corner(id));
  }
  assert.equal(h.m.facts().wallet.availableData,4);
  for(let i=0;i<4;i++){h.act('place_data');h.act('choose_target',a=>a.target.target==='computer');}
  const payer=h.m.player().hand.find(c=>c.cardId==='dlc_25.png');
  h.act('choose_card',a=>a.target.choiceId===`income:${payer?.id}`);
  h.cut('salary');
 }
 const cases=[['swap',h=>supply(h,'swap')],['swap+salary',h=>{supply(h,'swap');settle(h);}]];
 if(shortFrom(e).wallet[3]>=3)cases.push(['buy+salary',h=>{supply(h,'buy');settle(h);}]);
 rows.push({label,...runCases(e,cases)});
}
function shortFrom(e){const m=open(e);try{return short(m);}finally{m.dispose();}}
writeZ(process.argv[3],{rows});
