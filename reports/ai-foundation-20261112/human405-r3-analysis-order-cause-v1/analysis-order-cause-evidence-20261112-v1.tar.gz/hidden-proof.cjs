'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{open,readZ,short,writeZ}=require('./controlled-r3');
const {buildRuleObservation}=require(path.resolve('randomizer/app/rule-observation'));
const seat='player-white',evalV=require(path.resolve('randomizer/game/ai/state-value')).createStateValueEvaluator(seat);
const data=readZ(process.argv[2]),line=data.rows.find(r=>r.label==='blue3-display-first'),o=data.root;
assert(!o.session);
const frames=[];
for(const swap of [null,[0,4],[1,6]]){
 const st=JSON.parse(o.committedState),p=st.cards.drawPileCardIds;
 if(swap){const [i,j]=swap;assert(p[i]&&p[j]&&p[i]!==p[j]);[p[i],p[j]]=[p[j],p[i]];}
 const root=swap?{...o,committedState:JSON.stringify(st)}:o;
 const m=open(root);
 try{
  const capture=()=>{
   const s=m.automatic(),r={observation:m.owner(seat),menu:m.menu(),rng:m.facts().rng,action:s.a.actionId,n:s.n,value:s.value,roots:s.roots,ms:s.ms};
   assert(s.complete&&s.n<=256&&s.ms<=600);
   return r;
  };
  const atRoot=capture(),actions=[];
  const k=line.actions.findIndex(a=>a.family==='play_card'&&a.summary==='amiba_5.webp');
  for(const a of line.actions.slice(0,k+1))actions.push(m.apply(a));
  const atPick=capture();
  if(swap){
   const drop=({ms,...r})=>r;
   assert.deepEqual(drop(atRoot),drop(frames[0].atRoot));
   assert.deepEqual(drop(atPick),drop(frames[0].atPick));
  }
  for(const a of line.actions.slice(k+1))actions.push(m.apply(a));
  const last=m.state(),tail=short(m),v=evalV(buildRuleObservation(last,last.meta.seed,seat,[],{valueOnly:true}));
  assert.equal(tail.income[1],4);assert.deepEqual(tail.hand,['amiba_9.webp','b_16.webp']);assert.equal(v,189);
  const end=m.save();m.restore(root);actions.forEach(m.apply);assert.deepEqual(m.save(),end);
  frames.push({swap,root,atRoot,atPick,actions,end,v,tail});
 }finally{m.dispose();}
}
console.log(JSON.stringify(frames.map(f=>[f.swap,f.atRoot.n,f.atPick.n,f.atRoot.value,f.atPick.value,f.v])));
writeZ(process.argv[3],{frames});
