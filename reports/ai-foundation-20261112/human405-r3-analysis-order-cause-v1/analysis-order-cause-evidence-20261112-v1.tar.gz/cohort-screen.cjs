'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{open,short,writeZ}=require('./controlled-r3');
const card=require(path.resolve('randomizer/game/cards/deck'));
const rules=require(path.resolve('randomizer/game/aliens/amiba'));
const read=p=>JSON.parse(fs.readFileSync(p)),seat='player-white';
const baseline=read('reports/iteration/free-analyze-random20-funded-planet-20261111/summary-463fc442-20261111.json');
const rows=[];
for(const r of baseline.rows){
 const rec=read('reports/research/'+r.f),moves=read(rec.savePath).replaySteps;
 const r2=read(rec.roundEnds[1].checkpointPath),r3=read(rec.roundEnds[2].checkpointPath),m=open(r2.coreState.compositionEnvelope);
 const alternatives=[],checks=[];
 try{
  for(let i=r2.replayCursor.stepIndex;i<r3.replayCursor.stepIndex;i++){
   const a=moves[i].action;
   if(a.actorId===seat&&a.phase==='main'){
    const f=m.facts();
    if(f.round===3&&!f.main&&f.computer.length===6&&f.hand.some(c=>c[1]==='amiba_5.webp')){
     const s=m.state(),menu=m.menu(),a5=menu.find(a=>a.family==='play_card'&&a.summary==='amiba_5.webp');
     const analyze=menu.find(a=>a.family==='analyze'),known=s.cards.publicCards.filter(c=>c&&card.getDiscardActionRewardForCard(c)?.dataCount===1);
     if(a5&&analyze){
      const before=rules.listSymbolsInRegion(s.aliens,'red'),after=structuredClone(s.aliens);
      const moved=rules.resolveRegionReward(after,'blue'),future=rules.listSymbolsInRegion(after,'red');
      const hit={input:i+1,actual:a.summary,start:short(m),eligibleWallet:f.wallet.credits===1&&f.wallet.energy===0&&f.wallet.availableData===0,
       known:known.map(c=>c.cardId),redBefore:before.map(r=>[r.slotId,r.reward]),redAfter:future.map(r=>[r.slotId,r.reward]),symbolMoves:moved.results.map(x=>x.move)};
      alternatives.push(hit);
      if(hit.eligibleWallet&&known.length&&future.some(r=>r.reward.dataCount===1)&&!before.some(r=>r.reward.dataCount===1))
       checks.push({input:i+1,root:m.save()});
     }
    }
   }
   m.apply(a);
  }
  // The already documented Board 11 checkpoint comparison may differ in one
  // neutral Amiba marker ordinal. Keep it explicit, rather than dropping it.
  const exact=JSON.stringify(m.save())===JSON.stringify(r3.coreState.compositionEnvelope);
  if(!exact)assert.equal(r.board,11);
  rows.push({board:r.board,record:r.f,alternatives,checks,exact});
 }finally{m.dispose();}
}
console.log(JSON.stringify(rows.map(r=>[r.board,r.alternatives.length,r.checks.length,r.exact])));
writeZ(process.argv[2],{rows});
