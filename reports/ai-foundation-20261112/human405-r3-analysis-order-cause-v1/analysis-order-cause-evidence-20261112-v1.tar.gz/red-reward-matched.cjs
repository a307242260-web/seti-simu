'use strict';
const assert=require('node:assert/strict'),{open,readZ,short,writeZ}=require('./controlled-r3');
const cards=require(require('node:path').resolve('randomizer/game/cards/deck'));
const src=readZ(process.argv[2]),root=src.root,m=open(root),seat='player-white';
const cases=[
 ['A5-first',null,'dlc_17.png'],
 ['blue2-first','blue2','dlc_17.png'],
 ['blue3-display-first','display','dlc_17.png'],
 ['blue3-cancel-first','cancel','dlc_17.png'],
 ['blue3-display-DLC20','display','dlc_20.png'],
];
const rows=[];
for(const [label,variant,pick] of cases){
 m.restore(root);const actions=[],take=a=>(actions.push(a),a),cut=()=>({e:m.save(),assets:short(m),full:m.facts(),menu:m.menu()});
 const analysis=(v)=>{
  take(m.act('analyze'));
  take(m.act('choose_target',a=>a.target.choiceId==='trace:1:blue:amiba:'+(v==='blue2'?2:3)));
  if(v!=='blue2')take(m.act('choose_card',a=>a.target.source==='display'&&a.target.cardIndex===2&&v==='display'||a.target.choiceId==='amiba:cancel'&&v==='cancel'));
  return cut();
 };
 const end=()=>{take(m.act('end_turn'));if(m.menu()[0].actorId!==seat)m.advanceOpponents(actions);};
 const a5=(card)=>{take(m.play('amiba_5.webp'));const decision=m.automatic();assert(decision.complete&&decision.n<=256&&decision.ms<=600);
  const offer=cut();take(m.pick(card));const red=cut();take(m.act('choose_target',a=>a.target.region==='red'));
  return {red,offer,decision:{choice:decision.a,roots:decision.roots,n:decision.n,ms:decision.ms},after:cut()};
 };
 try{
  let a,b;
  if(variant){a=analysis(variant);end();b=a5(pick);}
  else{b=a5(pick);end();a=analysis('display');}
  const terminalBeforePayment=cut();
  const dataPayers=[pick,'amiba_2.webp'].filter(id=>m.player().hand.some(c=>c.cardId===id&&cards.getDiscardActionRewardForCard(c)?.dataCount===1));
  const ledger={cornerPayers:dataPayers,startingPool:m.facts().wallet.availableData};
  // Apply only the corner inputs in the original witness; both are public
  // before the branch uses them. No blind card is used to complete the slot.
  for(const id of [pick,'amiba_2.webp']){
   const c=m.player().hand.find(c=>c.cardId===id);
   const input=c&&cards.getDiscardActionRewardForCard(c)?.dataCount===1&&m.menu().find(x=>x.family==='card_corner'&&x.target.cardInstanceId===c.id&&x.payload.kind==='resource');
   if(input)take(m.apply(input));
  }
  ledger.afterCorners=m.facts().wallet.availableData;
  const remaining=m.facts().wallet.availableData;
  for(let i=0;i<Math.min(4,remaining);i++){
   take(m.act('place_data'));take(m.act('choose_target',x=>x.target.target==='computer'));
  }
  const salary=m.menu().find(x=>x.target.choiceId===`income:${m.player().hand.find(c=>c.cardId==='dlc_25.png')?.id}`);
  if(salary)take(m.apply(salary));
  const result=cut();
  m.restore(root);actions.forEach(m.apply);assert.deepEqual(m.save(),result.e);
  const row={label,actions,a,b,terminalBeforePayment,ledger,salary:salary?.summary,result};rows.push(row);
  console.log(JSON.stringify({label,analysis:a.assets.wallet,red:b.red.menu.map(x=>x.summary),after:b.after.assets.wallet,ledger,salary:row.salary,end:result.assets.wallet,hand:result.assets.hand,income:result.assets.income,policy:[b.decision.choice.summary,b.decision.roots.map(x=>[b.offer.menu.find(k=>k.actionId===x.actionId)?.summary,x.value,x.completion])]}));
 }catch(e){
  console.log(label,String(e).slice(0,430));rows.push({label,error:String(e).slice(0,600),actions,at:cut()});
 }
}
m.dispose();
writeZ(process.argv[3],{root,rows});
