'use strict';
const assert=require('node:assert/strict'),{readZ,writeZ,runCases,open,short}=require('./controlled-r3');
const [input,out]=process.argv.slice(2),src=readZ(input),start=8,end=17;
const caseRows=src.rows.slice(start,end);
assert.equal(caseRows[0].action.family,'analyze');
const origin=caseRows[0].root;
const force=(h,n)=>{for(const r of caseRows.slice(0,n))h.take(h.m.apply(r.action));h.cut('before-autonomy');};
const cases=[['control',()=>{}],...([1,3,4,5,6,7,9].map(n=>['force-'+n,h=>force(h,n)]))];
cases.push(['force-A5-take-DLC20',h=>{force(h,5);h.take(h.m.pick('dlc_20.png'));h.cut('after-take');}]);
const m=open(origin),q=m.automatic();
try{
 assert(q.complete&&q.n<=256&&q.ms<=600);
 const a5=m.menu().find(a=>a.family==='play_card'&&a.summary==='amiba_5.webp');
 const analysis=m.menu().find(a=>a.family==='analyze');
 console.log(JSON.stringify({assets:short(m),a5:q.roots.filter(r=>r.actionId===a5.actionId),analysis:q.roots.filter(r=>r.actionId===analysis.actionId),n:q.n,ms:q.ms}));
 writeZ(out,{root:origin,opening:{roots:q.roots,lines:q.lines,diagnostics:q.diagnostics,choice:q.a,assets:short(m)},...runCases(origin,cases)});
}finally{m.dispose();}
