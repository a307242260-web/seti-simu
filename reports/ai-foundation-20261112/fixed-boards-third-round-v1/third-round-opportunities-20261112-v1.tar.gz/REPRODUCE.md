# 复查低分盘第三轮机会
Node 22，从 SETI 仓库根目录执行。解包到 CASE_DIR 并运行 `shasum -a 256 -c SHA256SUMS`。前两项用原策略 463fc4423，第三项用 V69：

```sh
summary=reports/iteration/free-analyze-random20-funded-planet-20261111/summary-463fc442-20261111.json
node "$CASE_DIR/third-round-controls.cjs" "$summary" "$CASE_DIR/r3-check.json.gz"
node "$CASE_DIR/fourth-round-controls.cjs" "$CASE_DIR/r3-check.json.gz" "$CASE_DIR/r4-check.json.gz"
node "$CASE_DIR/scan-launch-canaries.cjs" "$summary" "$CASE_DIR/scan-check.json.gz"
```

九个原生根和动作已存于 gzip 文件，不必重跑旧整局。时间随环境变化。第三轮参考动作从原存档重放到同一规则状态；独立反事实按完整原生信封复放。见证测试第一次在私有目录缺历史文件，补入 dev 的原始夹具后，该测试通过。
