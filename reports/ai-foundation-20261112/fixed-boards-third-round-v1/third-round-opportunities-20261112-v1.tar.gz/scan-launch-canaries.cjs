'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path');
const {open,readZ,writeZ,short}=require('./controlled-r3');
const [summary,out]=process.argv.slice(2),read=f=>JSON.parse(fs.readFileSync(f)),cases=[];
const s=read(summary);
for(const r of [...s.rows,{board:0,f:'2a26d03a.463fc442.quick-400.json'}]){
 const file='reports/research/'+r.f,d=read(file),save=read(d.savePath),c=read(d.roundEnds[1].checkpointPath);
 const start=c.replayCursor.stepIndex,end=d.roundEnds[2].beforeInput;
 for(let i=start;i<end;i++){const a=save.replaySteps[i].action;
  if(a.actorId==='player-white'&&a.target?.choiceId?.startsWith('scan4:'))cases.push({board:r.board,i,file,old:a,c,steps:save.replaySteps.map(x=>x.action)});
 }
}
const rows=[];
for(const x of cases){
 const m=open(x.c.coreState.compositionEnvelope);
 try{
  x.steps.slice(x.c.replayCursor.stepIndex,x.i).forEach(m.apply);
  const root=m.save(),q=m.automatic(),a=q.a;
  assert(q.complete&&a&&q.n<=256&&q.ms<=600,JSON.stringify([x.board,x.i,q.n,q.ms]));
  const row={board:x.board,input:x.i+1,root,old:x.old.summary,now:a.summary,n:q.n,ms:q.ms,roots:q.roots,assets:short(m)};
  rows.push(row);console.log(JSON.stringify({...row,root:undefined,assets:undefined,roots:undefined}));
 }finally{m.dispose();}
}
assert(rows.some(x=>x.board===9&&x.old==='跳过'&&x.now==='发射探测器'));writeZ(out,{rows});
