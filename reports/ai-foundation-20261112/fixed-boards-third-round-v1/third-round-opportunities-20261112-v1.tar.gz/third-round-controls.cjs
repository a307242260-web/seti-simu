'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),{open,short,writeZ}=require('./controlled-r3');
const [summary,out]=process.argv.slice(2), read=p=>JSON.parse(fs.readFileSync(p)), rows=[];
const cases=[
 [9,106,'scan-launch',['发射探测器']],
 [11,127,'analyze-pool',['放置数据','第一排放置位 5','放置数据','第一排放置位 6','分析']],
 [14,125,'launch-first',['发射']],
 [14,136,'salary-card',['收入 b_137.webp']],
 [15,112,'scan-first',['扫描']],
 [20,111,'scan-first',['扫描']],
 [14,118,'reserve-b126',['b_126.webp']],
 [15,105,'reserve-b96',['b_96.webp']],
 [20,104,'reserve-b66',['b_66.webp']],
];
const data=read(summary);
for(const [board,input,label,alternatives] of cases){
 const file='reports/research/'+data.rows.find(x=>x.board===board).f, record=read(file), save=read(record.savePath);
 const opening=read(record.roundEnds[1].checkpointPath),expected=read(record.roundEnds[2].checkpointPath).coreState.compositionEnvelope;
 const m=open(opening.coreState.compositionEnvelope), steps=save.replaySteps.map(x=>x.action),before=steps.slice(opening.replayCursor.stepIndex,input-1),after=steps.slice(input-1,record.roundEnds[2].beforeInput);
 const assets=()=>({short:short(m),known:m.facts(),main:m.player().mainActionCompleted});
 try{
  before.forEach(m.apply);const root=m.save(),initial=assets();
  after.forEach(m.apply);const restored=m.save(),matches=restored.committedState===expected.committedState;
  if(!matches){console.log(JSON.stringify({board,label,restoreDiff:'committedState',restored:short(m)}));}
  assert(matches,'baseline rule state differs: '+board);
  const sameSession=JSON.stringify(restored.session)===JSON.stringify(expected.session);
  const old=assets();m.restore(root);
  const quote=m.automatic(),admit=q=>q.a&&q.complete&&q.n<=256&&q.ms<=600;
  const quotes=[quote],accepted=[],frames=[];
  const firstAction=m.menu().find(a=>a.summary===alternatives[0]);assert(firstAction&&firstAction.actionId!==after[0].actionId);
  const first={n:quote.n,ms:quote.ms,a:quote.a?.summary,v:quote.value,old:after[0].summary,alternative:alternatives[0],altV:quote.roots?.find(x=>x.actionId===firstAction.actionId)?.value};
  let stop;
  if(!admit(quote))stop={gate:first};
  if(!stop)for(const name of alternatives){const a=m.menu().find(a=>a.summary===name);assert(a,JSON.stringify([label,name,m.menu().map(x=>x.summary)]));accepted.push({action:m.apply(a),fixed:true});}
  let cp;
  for(let i=0;!stop&&i<175;i++){
   if(m.menu()[0].actorId!=='player-white'){
    const a=[];m.advanceOpponents(a);accepted.push(...a.map(action=>({action,passive:true})));continue;
   }
   const q=m.automatic(cp);if(!admit(q)){
    stop={gate:{n:q.n,ms:q.ms,a:q.a?.summary,v:q.value,complete:q.complete}};quotes.push(q);break;
   }
   if(q.a.family==='pass'&&m.facts().round===3){stop='settled';break;}
   if(q.a.phase==='main'||q.a.family==='pass'||q.a.target?.choiceId?.startsWith('income:'))frames.push({a:q.a.summary,before:short(m),n:q.n,v:q.value});
   cp=q.checkpoint;accepted.push({action:m.apply(q.a),n:q.n,ms:q.ms});
  }
  assert(stop);const end=m.save(),now=assets();
  m.restore(root);accepted.forEach(a=>m.apply(a.action));assert.deepEqual(m.save(),end);m.restore(root);
  const peaks=[Math.max(first.n,...accepted.map(x=>x.n||0)),Math.max(first.ms,...accepted.map(x=>x.ms||0))];
  const result={board,input,label,file,root,initial,first,old,baselineSessionEqual:sameSession,baselineEnd:expected,now,end,stop,peaks,accepted,frames,quotes};
  rows.push(result);
  console.log(JSON.stringify({board,input,label,first,old:old.short,now:now.short,stop,peaks,actions:accepted.length}));
 }finally{m.dispose();}
}
writeZ(out,{source:'463fc44230e5cdc8b29765a0a109a73ae367bb48',rows});
