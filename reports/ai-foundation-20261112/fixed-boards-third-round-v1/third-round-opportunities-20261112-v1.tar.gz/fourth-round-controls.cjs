'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),{open,readZ,writeZ,short}=require('./controlled-r3');
const [input,out]=process.argv.slice(2),cases=readZ(input).rows.filter(x=>['scan-launch','analyze-pool','salary-card'].includes(x.label)||x.board===15&&x.label==='scan-first'),rows=[];
const seat='player-white',admit=q=>q.a&&q.complete&&q.n<=256&&q.ms<=600,score=m=>m.state().turn.gameEnded?m.state().match.finalScores.find(x=>x.playerId===seat):null;
for(const r of cases){
 const base=JSON.parse(fs.readFileSync(r.file)),save=JSON.parse(fs.readFileSync(base.savePath));
 const pass=save.replaySteps.findIndex((x,i)=>i>=base.roundEnds[2].beforeInput-1&&x.action.family==='pass'&&x.actorPlayerId===seat);
 assert(pass>=0);const old=save.replaySteps.slice(pass+1).find(x=>x.actorPlayerId===seat)?.action;
 assert(old.family==='choose_card'&&old.actorId===seat,JSON.stringify([r.board,old]));
 const m=open(r.end),prefix=[],accepted=[];
 try{
  prefix.push(m.act('pass'));
  if(m.menu()[0].actorId!==seat)m.advanceOpponents(prefix);
  prefix.push(m.act('choose_card',a=>a.summary===old.summary));
  if(m.menu()[0].actorId!==seat)m.advanceOpponents(prefix);
  const root=m.save(),checks=[],frames=[];let cp,stop;
  for(let i=0;i<190;i++){
   if(score(m)){stop='terminal';break;}
   if(m.menu()[0].actorId!==seat){const a=[];m.advanceOpponents(a);accepted.push(...a);continue;}
   const q=m.automatic(cp),stats={n:q.n,ms:q.ms,a:q.a?.summary,v:q.value,complete:q.complete};
   if(!admit(q)){stop={gate:stats};break;}
   if(q.a.phase==='main'||q.a.family==='pass')frames.push({a:q.a.summary,before:short(m)});
   cp=q.checkpoint;accepted.push(m.apply(q.a));checks.push(stats);
  }
  assert(stop);const end=m.save(),terminal=score(m);
  m.restore(r.end);prefix.forEach(m.apply);accepted.forEach(m.apply);assert.deepEqual(m.save(),end);
  const row={board:r.board,label:r.label,card:old.summary,baseline:base.summary.scores[seat],start:r.end,root,prefix,accepted,frames,checks,end,terminal,stop};
  rows.push(row);
  console.log(JSON.stringify({board:row.board,label:row.label,card:row.card,baseline:row.baseline,score:terminal?.totalScore,stop,
    peak:[Math.max(0,...checks.map(x=>x.n)),Math.round(Math.max(0,...checks.map(x=>x.ms)))],r4:frames.map(x=>x.a)}));
 }finally{m.dispose();}
}
writeZ(out,{rows});
